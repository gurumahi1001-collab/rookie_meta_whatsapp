@extends('layouts/layoutMaster')

@section('title', 'Sales Metrics')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss','resources/assets/vendor/libs/apex-charts/apex-charts.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection


@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/apex-charts/apexcharts.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js']),
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection


@section('content')
<style>
    .current-week-card {
        border: 2px solid #198754 !important;
        background: linear-gradient(135deg, #f3fff7, #ffffff) !important;
        box-shadow: 0 8px 20px rgba(25, 135, 84, .18) !important;
        transform: scale(1.01) !important;
        transition: .3s !important;
    }

    .current-week-card .week-performance-header {
        background: #198754;
        color: #fff;
        border-radius: 10px;
        padding: 12px 16px;
    }

    .current-week-card .week-performance-header .week-percent,
    .current-week-card .week-performance-header .fs-5,
    .current-week-card .week-performance-header small {
        color: #fff !important;
    }
</style>
<style>

    .executive-header{
        display:flex;
        justify-content:space-between;
        align-items:center;
        padding:20px;
        background:linear-gradient(
            135deg,
            #0F172A,
            #1E293B
        );
        color:white;
        border-radius:12px;
    }
    .metrics-dashboard {

        padding: 20px;
        background: #f4f7fb;
        min-height: 100vh;
    }

    .metrics-header {

        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        flex-wrap: wrap;
        gap: 15px;
    }

    .metrics-title {

        font-size: 28px;
        font-weight: 700;
        color: #111827;
        margin-bottom: 4px;
    }

    .metrics-subtitle {

        color: #6b7280;
        margin: 0;
    }

    .metrics-filters {

        display: flex;
        gap: 10px;
        align-items: center;
    }

    .search-box {

        width: 260px;
    }

    .year-filter {

        width: 170px;
    }

    .metrics-grid {

        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(500px, 1fr));
        gap: 20px;
    }

    .metric-card {

        background: #fff;
        border-radius: 24px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
        transition: 0.3s;
        border: 1px solid #eef2f7;
    }

    .metric-card:hover {

        transform: translateY(-4px);
    }

    .metric-header {

        padding: 20px;
        color: #fff;
        position: relative;
    }

    .metric-header-overlay {

        position: absolute;
        inset: 0;
        background: rgba(255, 255, 255, 0.06);
        backdrop-filter: blur(10px);
    }

    .metric-header-content {

        position: relative;
        z-index: 2;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .entity-info {

        display: flex;
        align-items: center;
        gap: 14px;
    }

    .entity-logo {

        width: 58px;
        height: 58px;
        border-radius: 18px;
        object-fit: cover;
        background: #fff;
        padding: 6px;
    }

    .entity-name {

        font-size: 18px;
        font-weight: 700;
    }

    .branch-name {

        opacity: 0.9;
        font-size: 13px;
    }

    .ai-badge {

        padding: 8px 14px;
        border-radius: 40px;
        font-size: 12px;
        font-weight: 700;
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(6px);
    }

    .metric-body {

        padding: 20px;
    }

    .metric-stats {

        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
        margin-bottom: 20px;
    }

    .metric-stat {

        background: #f8fafc;
        border-radius: 16px;
        padding: 14px;
    }

    .metric-label {

        color: #6b7280;
        font-size: 12px;
        margin-bottom: 6px;
    }

    .metric-value {

        font-size: 18px;
        font-weight: 700;
    }

    .progress-area {

        margin-bottom: 20px;
    }

    .progress-track {

        width: 100%;
        height: 12px;
        border-radius: 20px;
        background: #edf2f7;
        overflow: hidden;
    }

    .progress-fill {

        height: 100%;
        border-radius: 20px;
    }

    .quarter-grid {

        display: grid;
        gap: 14px;
    }

    .quarter-card {

        border: 1px solid #eef2f7;
        border-radius: 18px;
        overflow: hidden;
    }

    .quarter-header {

        padding: 14px 16px;
        background: #f8fafc;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
    }

    .quarter-title {

        font-weight: 700;
    }

    .quarter-body {

        padding: 16px;
    }

    .month-grid {

        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
    }

    .month-card {

        border: 1px solid #eef2f7;
        border-radius: 14px;
        padding: 12px;
        transition: 0.3s;
    }

    .month-card:hover {

        background: #f8fbff;
    }

    .month-name {

        font-weight: 700;
        margin-bottom: 8px;
    }

    .month-target {

        color: #111827;
        font-weight: 700;
        font-size: 15px;
    }

    .month-actual {

        color: #16a34a;
        font-weight: 700;
        margin-top: 4px;
    }

    .month-percent {

        margin-top: 10px;
        font-size: 12px;
        font-weight: 700;
    }

    @media(max-width:768px) {

        .metrics-grid {

            grid-template-columns: 1fr;
        }

        .metric-stats {

            grid-template-columns: 1fr;
        }

        .month-grid {

            grid-template-columns: 1fr;
        }
    }

    .metric-stat-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 14px;
        margin-bottom: 22px;
    }

    .metric-stat-card {
        background: #f8fafc;
        border-radius: 18px;
        padding: 18px;
    }

    .metric-big {
        font-size: 22px;
        font-weight: 800;
    }

    .overall-progress-wrap {
        margin-bottom: 20px;
    }

    .overall-progress-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .month-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
    }

    .month-badge {
        padding: 5px 12px;
        border-radius: 30px;
        font-size: 11px;
        font-weight: 700;
    }

    .metric-mini-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        margin-bottom: 12px;
    }

    .mini-box {
        background: #f8fafc;
        border-radius: 12px;
        padding: 10px;
    }

    .mini-box span {
        display: block;
        font-size: 11px;
        color: #64748b;
    }

    .mini-box strong {
        font-size: 14px;
    }

    .mini-progress {
        width: 100%;
        height: 8px;
        background: #edf2f7;
        border-radius: 20px;
        overflow: hidden;
    }

    .mini-progress-bar {
        height: 100%;
        border-radius: 20px;
    }

    .week-performance-card {
        border: 1px solid #e2e8f0;
        border-radius: 18px;
        padding: 18px;
        margin-bottom: 16px;
    }

    .week-performance-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
    }

    .week-metric-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 12px;
        margin-bottom: 14px;
    }

    .week-box {
        background: #f8fafc;
        padding: 14px;
        border-radius: 14px;
    }

    .week-box span {
        display: block;
        color: #64748b;
        font-size: 12px;
        margin-bottom: 4px;
    }

    .week-box strong {
        font-size: 15px;
    }

    @media(max-width:768px) {

        .metric-stat-grid {
            grid-template-columns: 1fr;
        }

        .week-metric-grid {
            grid-template-columns: 1fr;
        }

        .metric-mini-grid {
            grid-template-columns: 1fr;
        }

    }
</style>
<style>
    @media(max-width:992px) {

        .metric-stat-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .month-grid {
            grid-template-columns: 1fr;
        }

        .week-metric-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media(max-width:768px) {

        .metrics-grid {
            grid-template-columns: 1fr;
        }

        .metric-stat-grid,
        .week-metric-grid,
        .metric-mini-grid {
            grid-template-columns: 1fr;
        }

        .metric-header-content {
            flex-direction: column;
            align-items: flex-start;
        }

        .quarter-header {
            align-items: flex-start;
        }

        .quarter-percent {
            font-size: 16px;
        }

        .metric-big {
            font-size: 18px;
        }

        .entity-logo {
            width: 48px;
            height: 48px;
        }
    }
</style>
<style>
    .metric-card {
        min-width: 0;
        overflow: hidden;
    }

    .metric-stat-card,
    .month-card,
    .week-box,
    .quarter-card {
        min-width: 0;
    }

    .metric-big,
    .metric-value,
    .month-target,
    .month-actual,
    .week-box strong,
    .quarter-header span,
    .quarter-percent {

        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .quarter-header {

        display: flex;
        justify-content: space-between;
        align-items: center;

        gap: 12px;

        flex-wrap: wrap;
    }

    .quarter-header small {
        display: block;
        color: #64748b;
        margin-top: 2px;
        font-size: 12px;
        white-space: nowrap;
    }

    .quarter-right {
        flex-shrink: 0;
        text-align: right;
    }

    .quarter-percent {
        font-size: 20px;
        font-weight: 800;
        white-space: nowrap;
    }

    /* .month-card {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: 100%;
        cursor: pointer;
    } */

    .month-card {

        min-height: 240px;

        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    .month-grid {
        align-items: stretch;
    }

    .metric-mini-grid {
        flex: 1;
    }

    .metric-big {
        font-size: clamp(18px, 1.4vw, 24px);
        line-height: 1.2;
    }

    .metric-stat-grid {
        align-items: stretch;
    }

    .metric-stat-card {
        height: 100%;
    }

    .quarter-progress-wrap {
        padding: 0 16px 14px;
        background: #f8fafc;
    }

    .quarter-progress-track {
        width: 100%;
        height: 8px;
        border-radius: 20px;
        background: #e2e8f0;
        overflow: hidden;
    }

    .quarter-progress-fill {
        height: 100%;
        border-radius: 20px;
        transition: width .4s ease;
    }

    .month-name {
        font-size: 15px;
        line-height: 1.3;
    }

    .entity-name {
        line-height: 1.2;
    }

    .metric-header-content {
        gap: 12px;
    }

    .ai-badge {
        white-space: nowrap;
        flex-shrink: 0;
    }

    /* .metric-stat-grid {
        grid-template-columns: repeat(4, minmax(0, 1fr));
    }

    .month-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    } */
    .metric-stat-grid {

        display: grid;

        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));

        gap: 14px;
    }

    .month-grid {

        display: grid;

        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));

        gap: 12px;
    }

    .current-quarter {
        border: 2px solid #ab2b22 !important;
        box-shadow: 0 0 20px rgba(115, 103, 240, .2);
    }

    .current-month-card {
        border: 2px solid #28c76f !important;
        background: linear-gradient(135deg, #e9fff3, #ffffff);
    }

    .current-week {
        border: 2px solid #ff9f43 !important;
        background: #fff8ef;
    }
</style>
<style>
    .no-data-image {

        width: 180px;

        opacity: .95;

        margin-bottom: 18px;

        filter: drop-shadow(0 10px 20px rgba(0, 0, 0, .08));
    }

    .metrics-state-wrapper {

        grid-column: 1 / -1;
        width: 100%;

        min-height: 60vh;

        display: flex;

        align-items: center;

        justify-content: center;

        flex-direction: column;

    }

    .metrics-loader {

        width: 60px;
        height: 60px;

        border: 5px solid #e5e7eb;
        border-top-color: #ab2b22;

        border-radius: 50%;

        animation: spinLoader .8s linear infinite;
    }

    @keyframes spinLoader {

        to {
            transform: rotate(360deg);
        }
    }

    .no-data-image {

        width: 160px;
        opacity: .9;
    }

    .no-data-title {

        font-size: 22px;
        font-weight: 700;

        margin-top: 18px;

        color: #111827;
    }

    .no-data-subtitle {

        color: #6b7280;
        margin-top: 6px;
    }
</style>
@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Sales Metrics - <span class="target_label_year text-primary" id="target_label_year">({{ date('Y') }} - {{ date('Y')+1 }})</span></h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-trophy"></i> Business Strategy
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            Sales Metrics
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <!-- <a href="/targets" class="btn btn-sm fw-bold btn-primary text-white">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Update Target
                </a>
                @if($user_id == 0)
                <button type="button" class="btn btn-sm btn-primary" id="openAchieveModal">
                    <i class="mdi mdi-trending-up"></i> Fetch Achievement
                </button>
                <button type="button" class="btn btn-sm btn-primary" id="openIncentiveModal">
                    <i class="mdi mdi-trending-up"></i> Fetch Incentive
                </button>
                @endif -->
                <button class="btn btn-sm btn-primary"
                        onclick="openOverallComparison()">
                    <i class="mdi mdi-finance"></i>
                    Overall Analytics
                </button>


            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="metrics-dashboard">

            <div class="metrics-header">

                <div class="metrics-title-block">

                    <h3 class="metrics-title">
                        Sales Performance Metrics
                    </h3>

                    <!-- <p class="metrics-subtitle">
                        AI Driven Corporate Sales Analytics Dashboard
                    </p> -->

                </div>

                <div class="metrics-filters">

                    <input
                        type="text"
                        id="search_filter"
                        class="form-control search-box"
                        placeholder="Search Entity / Branch">

                    <input type="text" id="global_year_picker" class="form-control w-100px" value="<?php echo date('Y') ?>">



                    <button class="btn btn-primary"
                        onclick="loadThemes(1)">

                        Search

                    </button>

                </div>

            </div>

            <div id="metrics-grid" class="metrics-grid"></div>

        </div>
    </div>
</div>


<div class="modal fade" id="overallComparisonModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <!-- <div class="modal-dialog modal-dialog-scrollable" style="max-width:1500px;width:96%;"> -->
    <div class="modal-dialog modal-fullscreen-xl-down" style="max-width:1700px;width:98%;">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="px-6 d-flex align-items-center justify-content-between border-bottom-1">
                <div class="mb-2 text-black">
                    <span class="modal-title fs-3 fw-bold"><i class="mdi mdi-account-details-outline fs-4 me-2"></i>Financial Year Analytics Dashboard</span>
                </div>
                <div>
                   
                </div>
                
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom">
                <div class="modal-body">
                    <div class="row mb-5">
                        <div class="col-lg-4">
                             <label for="entity_filter">Entity</label>
                            <select  id="entity_filter" class="form-select select3" onchange="changeEntity()">
                               
                                <option value="">Select Entity</option>
                                @if(isset($entity_list))
                                    @foreach($entity_list as $elist)
                                        <option value="{{$elist->sno}}">{{$elist->entity_name}}</option>
                                    @endforeach
                                @endif

                            </select>
                        </div>
                        <div class="col-lg-4">
                            <label for="branch_filter">Branch</label>
                            <select id="branch_filter" class="form-select select3" onchange="branch_change_func()">
                                <option value="">Select Branch</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mt-5">
                             <div class="d-flex justify-content-end align-items-end mt-4">
                                <button class="btn btn-primary" id="compareBtn"><span class="mdi mdi-poll me-1"></span>Compare Analytics</button>
                            </div>
                        </div>
                        <div class="col-lg-12 mt-3">
                            <label for="financial_year_container">Financial Years</label>
                            <div id="financial_year_container" class="d-flex flex-wrap gap-3 mt-2">
                                <span class="ms-2"><span class="mdi mdi-finance me-2"></span>No Year Found</span> 
                            </div>
                        </div>
                    </div>

                    <div id="dashboardPlaceholder">
                        <div class="card shadow-sm border-0">
                            <div class="card-body text-center py-15">

                                <i class="bi bi-bar-chart-line-fill text-primary"
                                style="font-size:70px;"></i>

                                <h2 class="fw-bold mt-5">
                                    Financial Year Analytics
                                </h2>

                                <p class="text-muted fs-5">
                                    Select Entity, Branch and Financial Years to generate comparison analytics.
                                </p>

                            </div>
                        </div>
                    </div>
                    <div id="dashboardLoader" style="display:none">
                        <div class="text-center py-15">
                            <div class="spinner-border text-primary"
                                style="width:4rem;height:4rem">
                            </div>
                            <h5 class="mt-4">
                                Loading Analytics...
                            </h5>
                        </div>
                    </div>

                    <div id="dashboardContent" style="display:none">
                        <!-- cards -->
                        <div class="row g-4">
                            <div class="col-lg-3">
                                <div id="card_total"></div>
                            </div>
                            <div class="col-lg-3">
                                <div id="card_average"></div>
                            </div>
                            
                            <div class="col-lg-3">
                                <div id="card_best"></div>
                            </div>
                            <div class="col-lg-3">
                                <div id="card_worst"></div>
                            </div>
                        </div>
                        <!-- charts -->
                        <div class="row mt-4">
                            <div class="col-lg-12">
                                <div class="card shadow-sm border-0">
                                    <div class="card-header">
                                        <h4 class="mb-0">
                                            Monthly Financial Year Comparison
                                        </h4>
                                    </div>
                                    <div class="card-body">
                                        <div id="comparisonChart"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       <div class="card shadow-sm border-0 mt-5">
                            <div class="card-header">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h4 class="fw-bold mb-1">
                                            Financial Performance Trend
                                        </h4>
                                        <span class="text-muted fs-7">
                                            Year-over-Year Collection Analysis
                                        </span>
                                    </div>
                                    <i class="mdi mdi-chart-timeline-variant text-primary fs-2"></i>
                                </div>
                            </div>
                            <div class="card-body pt-4">
                                <div id="trendChartGlobal" style="height:420px;"></div>
                            </div>
                        </div>
                        <!-- table -->
                        <div class="card shadow-sm mt-5">
                            <div class="card-header">
                                <h4 class="mb-0">
                                    Monthly Financial Year Comparison
                                </h4>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover table-bordered align-middle mb-0">
                                        <thead id="performanceTableHeader"  class="sticky-top"></thead>

                                        <tbody id="performanceTableGlobal"></tbody>

                                    </table>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>



<div class="modal fade" id="weekMetricsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-fullscreen-lg-down modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <div class=" ">
                        <h4 id="weekModalTitle">
                            Weekly Performance
                        </h4>
                    </div>
                </div>
                
                <div class="row pe-9">
                    <small class="badge bg-label-success text-black border border-success fs-6 fw-semibold"
                        id="weekModalSubtitle">
                    </small>
                </div>
                
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                <div id="weekTotalContainer">

                </div>
                <div class="row g-3 mb-3">
                    <div id="weekMetricsContainer"></div>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="targetComparisonModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-fullscreen-lg-down modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <div>
                        <h3 id="modalTitle"></h3>
                    </div>
                </div>
                <div class=" mb-3">
                    <div class="row g-2">

                    </div>
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">

                <div class="row g-4 mb-5">

                    <div class="col-md-3">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-muted">Current FY</div>
                                <h2 class="fw-bold text-success text-nowrap" id="current_year_amount"> </h2>
                            </div>

                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-muted">Previous FY</div>
                                <h2 class="fw-bold text-primary text-nowrap" id="last_year_amount"></h2>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-muted"> Growth %</div>
                                <h2 class="fw-bold text-nowrap" id="growth_percentage"></h2>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body">
                                <div class="text-muted"> Achievement </div>
                                <h2 class="fw-bold text-warning text-nowrap" id="achievement_score"></h2>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="card border-0 shadow-sm mb-5">
                    <div class="card-header">
                        <h4>Monthly Collection Comparison</h4>
                    </div>
                    <div class="card-body">
                        <div id="monthlyComparisonChart"></div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-8">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header">
                                <h4>Financial Year Trend</h4>
                            </div>
                            <div class="card-body">
                                <div id="yearTrendChart"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header">
                                <h4>Achievement </h4>
                            </div>
                            <div class="card-body">
                                <div class="achievement-wrapper">
                                    <div id="achievementGauge"></div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
                <div class="card border-0 shadow-sm mt-5">
                    <div class="card-header">
                        <h4>Monthly Performance Matrix</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-row-bordered align-middle mb-0">
                            <thead class="sticky-top">
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary ">
                                    <th>Month</th>
                                    <th>Current FY</th>
                                    <th>Previous FY</th>
                                </tr>
                            </thead>
                            <tbody id="performanceTable"></tbody>
                        </table>
                    </div>
                </div>
                
               
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<script>
    
</script>

<script>
    $('#global_year_picker').datepicker({
        format: 'yyyy',
        viewMode: 'years',
        minViewMode: 'years',
        todayHighlight: true,
        autoclose: true,
        endDate: new Date(),
        orientation: 'bottom'
    })
</script>


<script>
    // function currencyFormat(value) {

    //     value = Number(value || 0);

    //     if (value >= 10000000) {

    //         return (value / 10000000).toFixed(2) + ' Cr';
    //     }

    //     if (value >= 100000) {

    //         return (value / 100000).toFixed(2) + ' L';
    //     }

    //     return new Intl.NumberFormat('en-IN', {
    //         maximumFractionDigits: 0
    //     }).format(value);
    // }
    
    function currencyFormat(value) {

        value = Number(value || 0);

        if (value >= 10000000) {

            return (Math.floor((value / 10000000) * 100) / 100).toFixed(2) + ' Cr';
        }

        if (value >= 100000) {

            return (Math.floor((value / 100000) * 100) / 100).toFixed(2) + ' L';
        }

        return new Intl.NumberFormat('en-IN', {
            maximumFractionDigits: 0
        }).format(value);
    }

    function progressColor(percent) {

        if (percent >= 100) {

            return '#16a34a';
        }

        if (percent >= 80) {

            return '#2563eb';
        }

        if (percent >= 60) {

            return '#f59e0b';
        }

        return '#dc2626';
    }

    function getMonthName(monthNo, year) {

        const monthNames = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        };

        let displayYear = year;

        if ([1, 2, 3].includes(parseInt(monthNo))) {
            displayYear = parseInt(year) + 1;
        }

        return `${monthNames[monthNo]} ${displayYear}`;
    }

    function getMonthNameOnly(monthNo) {

        const monthNames = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        };


        return `${monthNames[monthNo]}`;
    }

    function progressColor(percent) {

        if (percent >= 100) return '#16a34a';

        if (percent >= 80) return '#2563eb';

        if (percent >= 60) return '#f59e0b';

        return '#dc2626';
    }

    function renderMetricCard(item) {

        let quarterHtml = '';
        const selectedYear = parseInt($('#global_year_picker').val());

        const now = new Date();

        const currentMonthName = now.toLocaleString('default', {
            month: 'long'
        });

        const currentDate = now.getDate();

        const currentYear = now.getFullYear();

        let isCurrentMonth = false;

        let currentQuarter = '';

        item.quarters.forEach(q => {

            let monthHtml = '';

            q.months.forEach(m => {



                const monthName = getMonthName(m.month, item.year);
                const monthNameOnly = getMonthNameOnly(m.month);

                if (['April', 'May', 'June'].includes(currentMonthName)) {
                    currentQuarter = 'Q1';
                } else if (['July', 'August', 'September'].includes(currentMonthName)) {
                    currentQuarter = 'Q2';
                } else if (['October', 'November', 'December'].includes(currentMonthName)) {
                    currentQuarter = 'Q3';
                } else {
                    currentQuarter = 'Q4';
                }

                isCurrentMonth =
                    monthNameOnly === currentMonthName &&
                    selectedYear === currentYear;


                monthHtml += `

            <div class="month-card ${isCurrentMonth ? 'current-month-card' : ''}"
                onclick='openWeekModal(${JSON.stringify(JSON.stringify({
                    entity: item.entity_name,
                    month_target: m.target_amount,
                    month_actual: m.actual_amount,
                    presale_target: m.pre_sale_target,
                    presale_actual: m.pre_sale_actual,
                    postsale_target: m.post_sale_target,
                    postsale_actual: m.post_sale_actual,
                    achievement_percent: m.achievement_percent,
                    month: monthName,
                    quarter: q.quarter,
                    weeks: m.weeks
                }))})'>

                <div class="month-top">

                    <div class="month-name">
                        ${monthName}
                    </div>

                    <div class="month-badge"
                        style="background:${progressColor(m.achievement_percent)}20;
                        color:${progressColor(m.achievement_percent)}">

                        ${m.achievement_percent}%

                    </div>

                </div>

                <div class="metric-mini-grid">

                    <div class="mini-box">
                        <span>Target</span>
                        <strong data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(m.target_amount || 0)}">
                            ₹${currencyFormat(m.target_amount)}
                        </strong>
                    </div>

                    <div class="mini-box">
                        <span>Actual</span>
                        <strong class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(m.actual_amount || 0)}">
                            ₹${currencyFormat(m.actual_amount)}
                        </strong>
                    </div>

                    <div class="mini-box">
                        <span>Pre Sale</span>
                        <strong>
                            ${m.pre_sale_actual}
                            /
                            ${m.pre_sale_target}
                        </strong>
                    </div>

                    <div class="mini-box">
                        <span>Post Sale</span>
                        <strong>
                            ${m.post_sale_actual}
                            /
                            ${m.post_sale_target}
                        </strong>
                    </div>

                </div>

                <div class="mini-progress">

                    <div class="mini-progress-bar"
                        style="
                            width:${m.achievement_percent}%;
                            background:${progressColor(m.achievement_percent)}
                        ">
                    </div>

                </div>

            </div>
            `;
            });

            quarterHtml += `

        <div class="quarter-card ${q.quarter === currentQuarter && selectedYear === currentYear ? 'current-quarter' : ''}">

            <div class="quarter-header"
                data-bs-toggle="collapse"
                data-bs-target="#quarter_${item.id}_${q.quarter}">

                <div>

                    <div class="quarter-title">
                        ${q.quarter}
                    </div>

                    <span>
                       <span class="fw-bold text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(q.actual_amount || 0)}"> ₹${currencyFormat(q.actual_amount)}</span>
                        /
                        <span class="fw-bold text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(q.target_amount || 0)}">₹${currencyFormat(q.target_amount)}</span>
                    </span>

                </div>

                <div class="quarter-right">

                    <div class="quarter-percent"
                        style="color:${progressColor(q.achievement_percent || 0)}">

                        ${q.achievement_percent || 0}%

                    </div>

                </div>

            </div>

            <div class="quarter-progress-wrap">

                <div class="quarter-progress-track">

                    <div class="quarter-progress-fill"
                        style="
                            width:${q.achievement_percent || 0}%;
                            background:${progressColor(q.achievement_percent || 0)}
                        ">
                    </div>

                </div>

            </div>

            <div class="collapse "
                id="quarter_${item.id}_${q.quarter}">

                <div class="quarter-body">

                    <div class="month-grid ">

                        ${monthHtml}

                    </div>

                </div>

            </div>
            

        </div>

        `;
        });

        return `

        <div class="metric-card">

            <div class="metric-header"
                style="background:${item.entity_base_color || '#2563eb'}">

                <div class="metric-header-overlay"></div>

                <div class="metric-header-content">

                    <div class="entity-info">

                        <img src="/Entity_favicons/${item.company_id}/${item.entity_favicon}"
                            class="entity-logo">

                        <div>

                            <div class="entity-name">
                                ${item.entity_name}
                            </div>

                            <div class="branch-name">
                                ${item.branch_name}
                            </div>

                        </div>

                    </div>

                    <div class="d-flex align-items-center gap-2">

                        <div class="ai-badge">
                            ${item.ai_status}
                        </div>

                        <button
                            class="btn btn-sm btn-white rounded"
                            data-bs-toggle="tooltip"
                            title="Year Comparison"
                            onclick="openTargetComparisonModal(${item.id}, ${item.entity_id}, ${item.branch_id})">
                            <i class="mdi mdi-chart-line fs-5"></i>
                        </button>

                    </div>

                </div>

            </div>

            <div class="metric-body">

                <div class="metric-stat-grid">

                    <div class="metric-stat-card">

                        <span class="metric-label">
                            Annual Target
                        </span>

                        <div class="metric-big" data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(item.total_target || 0)}">
                            ₹${currencyFormat(item.total_target)}
                        </div>

                         <span class="metric-label">
                            Actual
                        </span>

                        <div class="metric-big text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(item.actual_amount || 0)}">
                            ₹${currencyFormat(item.actual_amount)}
                        </div>

                    </div>

                    

                    <div class="metric-stat-card">

                        <span class="metric-label">
                            Pre Sales
                        </span>

                        <div class="metric-big">
                            <span class="text-success">${item.actual_pre_sale}</span>
                            /
                            <span class=""> ${item.total_pre_sale}</span>
                        </div>

                         <span class="metric-label">
                            Post Sales
                        </span>

                        <div class="metric-big">
                            <span class="text-success">${item.actual_post_sale}</span>
                            /
                            <span class=""> ${item.total_post_sale}</span>
                        </div>

                    </div>

                    

                </div>

                <div class="overall-progress-wrap">

                    <div class="overall-progress-header">

                        <span>Overall Achievement</span>

                        <strong style="color:${progressColor(item.achievement_percent)}">

                            ${item.achievement_percent}%

                        </strong>

                    </div>

                    <div class="progress-track">

                        <div class="progress-fill"
                            style="
                                width:${item.achievement_percent}%;
                                background:${progressColor(item.achievement_percent)}
                            ">
                        </div>

                    </div>

                </div>

                <div class="quarter-grid">

                    ${quarterHtml}

                </div>

            </div>

        </div>

        `;
    }

    function noDataCard() {

        return `
            <div class="metrics-state-wrapper">
                <img
                     src="/assets/egc_images/no_data_found.png"
                    class="no-data-image">
                <div class="no-data-title">
                    No Sales Metrics Found
                </div>
                <div class="no-data-subtitle">
                    Try changing filters or selecting another financial year
                </div>
            </div>
        `;
    }

    function loadThemes(page = 1) {
        const search = $('#search_filter').val();
        const year = Number($('#global_year_picker').val());

        $('#target_label_year').text(year + '-' + (year + 1))

        $('#metrics-grid').html(`
            <div class="metrics-state-wrapper">
                <div class="metrics-loader"></div>
                <div class="mt-3 text-muted fw-semibold">
                    Loading Sales Intelligence...
                </div>
            </div>

        `);

        $.ajax({
            url: '/sales_metrics',
            type: 'GET',
            data: {
                page: page,
                search_filter: search,
                year: year
            },
            success: function(res) {
                let html = '';
                if (res.data.length > 0) {
                    res.data.forEach(item => {
                        html += renderMetricCard(item);
                    });
                } else {
                    html = noDataCard();
                }
                $('#metrics-grid').html(html);
                $('[data-bs-toggle="tooltip"]').tooltip();
            }

        });
    }

    loadThemes();
</script>
<script>
    function openWeekModal(data) {

        data = JSON.parse(data);

        $('#weekModalTitle').text(data.month);

        $('#weekModalSubtitle').text(
            `${data.entity} • ${data.quarter}`
        );

        let totalHTML ='';

        totalHTML = `

        <div class="week-performance-card">
            <div class="week-performance-header">
                <div class="d-flex gap-4 align-items-center">
                    <span class="fs-5 fw-semibold text-primary">
                        Overall ${data.month}
                    </span>
                </div>
                <div class="week-percent" style="color:${progressColor(data.achievement_percent)}">
                    ${data.achievement_percent}%
                </div>
            </div>
            <div class="week-metric-grid">
                <div class="week-box">
                    <span>Target</span>
                    <strong data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(data.month_target || 0)}">
                        ₹${currencyFormat(data.month_target)}
                    </strong>
                </div>
                <div class="week-box">
                    <span>Actual</span>
                    <strong class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(data.month_actual || 0)}">
                        ₹${currencyFormat(data.month_actual)}
                    </strong>
                </div>

                <div class="week-box">
                    <span>Pre Sale</span>
                    <strong>
                        ${data.presale_actual}
                        /
                        ${data.presale_target}
                    </strong>

                </div>

                <div class="week-box">

                    <span>Post Sale</span>

                    <strong>
                        ${data.postsale_actual}
                        /
                        ${data.postsale_target}
                    </strong>

                </div>

            </div>

            <div class="mini-progress">

                <div class="mini-progress-bar"
                    style="
                        width:${data.achievement_percent}%;
                        background:${progressColor(data.achievement_percent)}
                    ">
                </div>

            </div>

        </div>`;

         $('#weekTotalContainer').html(totalHTML);


        let html = '';

        data.weeks.forEach(w => {

            const today = new Date();
            today.setHours(0, 0, 0, 0);

            const startDate = new Date(w.week_start_date);
            const endDate = new Date(w.week_end_date);

            startDate.setHours(0, 0, 0, 0);
            endDate.setHours(23, 59, 59, 999);

            const isCurrentWeek = today >= startDate && today <= endDate;

            html += `

        <div class="week-performance-card ${isCurrentWeek ? 'current-week-card' : ''}">

            <div class="week-performance-header">

                <div class="d-flex gap-4 align-items-center">

                    <span class="fs-5 fw-semibold text-black">
                        Week ${w.week}
                    </span>

                    <small>
                        <span class="badge bg-info text-black me-1 fs-7"> ${w.week_start_date ? formatDateCommon(w.week_start_date) : '-'} </span>
                        <span class=""> → </span>
                        <span class="badge bg-danger fs-7 ms-1"> ${w.week_end_date ? formatDateCommon(w.week_end_date) : '-'} </span>
                        
                    </small>

                </div>

                <div class="week-percent"
                    style="color:${progressColor(w.achievement_percent)}">

                    ${w.achievement_percent}%

                </div>

            </div>

            <div class="week-metric-grid">

                <div class="week-box">

                    <span>Target</span>

                    <strong data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(w.target_amount || 0)}">
                        ₹${currencyFormat(w.target_amount)}
                    </strong>

                </div>

                <div class="week-box">

                    <span>Actual</span>

                    <strong class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(w.actual_amount || 0)}">
                        ₹${currencyFormat(w.actual_amount)}
                    </strong>

                </div>

                <div class="week-box">

                    <span>Pre Sale</span>

                    <strong>
                        ${w.pre_sale_actual}
                        /
                        ${w.pre_sale_target}
                    </strong>

                </div>

                <div class="week-box">

                    <span>Post Sale</span>

                    <strong>
                        ${w.post_sale_actual}
                        /
                        ${w.post_sale_target}
                    </strong>

                </div>

            </div>

            <div class="mini-progress">

                <div class="mini-progress-bar"
                    style="
                        width:${w.achievement_percent}%;
                        background:${progressColor(w.achievement_percent)}
                    ">
                </div>

            </div>

        </div>

        `;
        });

        $('#weekMetricsContainer').html(html);

        $('#weekMetricsModal').modal('show');
    }
</script>

<script>
    let monthlyChart = null;
    let trendChart = null;
    let gaugeChart = null;

function openTargetComparisonModal( targetId,entityId,branchId){
    $('#targetComparisonModal').modal('show');

    $.ajax({
        url:'/sales_metrics/comparison',
        type:'GET',
        data:{
            entity_id:entityId,
            branch_id:branchId,
            year:$('#global_year_picker').val()
        },

        success:function(res){
            $('#modalTitle').html(`
            FY ${res.previous_year}-${res.previous_year+1}
            vs
            FY ${res.current_year}-${res.current_year+1}
            Collection Analytics
            `);
            renderDashboard(res);
        }

    });

}
function renderDashboard(res)
{
    $('#current_year_amount').text( '₹' + new Intl.NumberFormat('en-IN').format(res.current_total));
    $('#last_year_amount').text('₹' + new Intl.NumberFormat('en-IN').format(res.previous_total));
    $('#growth_percentage').text(res.growth + '%');
    $('#achievement_score').text( res.achievement_score + '%');
    renderMonthlyChart(res);
    renderTrendChart(res);
    renderGauge(res);
    renderTable(res);
}
function renderMonthlyChart(res)
{
    if(monthlyChart){
        monthlyChart.destroy();
    }
    monthlyChart = new ApexCharts( document.querySelector("#monthlyComparisonChart"),
                        {
                            chart:{
                                type:'bar',
                                height:420,
                                toolbar:{
                                    show:true
                                }
                            },
                            series: [
                                {
                                    name: `FY ${res.previous_year}-${res.previous_year + 1}`,
                                    data: res.previous_data
                                },
                                {
                                    name: `FY ${res.current_year}-${res.current_year + 1}`,
                                    data: res.current_data
                                }
                            ],
                            xaxis:{
                                categories:res.months
                            },
                            tooltip: {
    shared: false,
    intersect: true,

    custom: function({ series, seriesIndex, dataPointIndex }) {

        const month = res.months[dataPointIndex];

        // Determine which FY is hovered
        let baseYear, fyLabel;

        if (seriesIndex === 0) {
            // Previous FY
            baseYear = res.previous_year;
            fyLabel = `FY ${res.previous_year}-${res.previous_year + 1}`;
        } else {
            // Current FY
            baseYear = res.current_year;
            fyLabel = `FY ${res.current_year}-${res.current_year + 1}`;
        }

        // Jan-Mar belong to next calendar year
        const displayYear =
            ['Jan', 'Feb', 'Mar'].includes(month)
                ? baseYear + 1
                : baseYear;

        const amount = series[seriesIndex][dataPointIndex];

        const color =
            seriesIndex === 0
                ? '#64748B'
                : '#1D4ED8';

        return `
            <div style="padding:10px;min-width:180px">
                <div style="font-weight:600;margin-bottom:8px">
                    ${month} ${displayYear}
                </div>

                <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">
                    <span style="
                        width:10px;
                        height:10px;
                        border-radius:50%;
                        background:${color};
                        display:inline-block;
                    "></span>

                    <span>${fyLabel}</span>
                </div>

                <div style="
                    font-weight:700;
                    font-size:14px;
                    color:${color};
                ">
                    ₹${new Intl.NumberFormat('en-IN').format(amount)}
                </div>
            </div>
        `;
    }
},
                            colors:[
                                '#64748B',
                                '#1D4ED8'
                            ],
                            plotOptions:{
                                bar:{
                                    borderRadius:8,
                                    columnWidth:'50%'
                                }
                            },dataLabels:{
                                enabled:false
                            }
                        }
                    );
    monthlyChart.render();
}
function renderTrendChart(res)
{
    if (trendChart) {
        trendChart.destroy();
    }

    trendChart = new ApexCharts(
        document.querySelector("#yearTrendChart"),
        {
            chart: {
                type: 'area',
                height: 380,
                toolbar: {
                    show: false
                }
            },

            series: [{
                name: 'Collection',
                data: res.trend_data
            }],

            xaxis: {
                categories: res.trend_labels
            },

            stroke: {
                curve: 'smooth',
                width: 4
            },

            markers: {
                size: 7,
                hover: {
                    size: 10
                }
            },

            fill: {
                type: 'gradient',
                gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.45,
                    opacityTo: 0.05,
                    stops: [0, 100]
                }
            },

            colors: ['#16A34A'],

            dataLabels: {
                enabled: false
            },

            yaxis: {
                labels: {
                    formatter: function(value) {
                        return '₹' +
                            (value / 100000).toFixed(1) + 'L';
                    }
                }
            },

            tooltip: {
                custom: function({
                    series,
                    seriesIndex,
                    dataPointIndex
                }) {

                    const amount =
                        series[seriesIndex][dataPointIndex];

                    const fy =
                        res.trend_labels[dataPointIndex];

                    return `
                        <div style="padding:10px">
                            <div style="font-weight:600">
                                ${fy}
                            </div>

                            <div style="margin-top:5px">
                                Collection
                            </div>

                            <div style="
                                color:#16A34A;
                                font-weight:700;
                                font-size:15px">
                                ₹${new Intl.NumberFormat('en-IN')
                                    .format(amount)}
                            </div>
                        </div>
                    `;
                }
            }
        }
    );

    trendChart.render();
}
function renderGauge(res)
{
    if(gaugeChart){
        gaugeChart.destroy();
    }

  gaugeChart = new ApexCharts(
    document.querySelector("#achievementGauge"),
    {
        chart: {
            type: 'radialBar',
            height: 350,
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 1500
            }
        },

        series: [res.achievement_score],

        colors: ['#16a34a'],

        fill: {
            type: 'gradient',
            gradient: {
                shade: 'light',
                type: 'horizontal',
                shadeIntensity: 0.5,
                gradientToColors: ['#22c55e'],
                inverseColors: false,
                opacityFrom: 1,
                opacityTo: 1,
                stops: [0, 100]
            }
        },

        stroke: {
            lineCap: 'round'
        },

        plotOptions: {
            radialBar: {

                startAngle: -135,
                endAngle: 135,

                hollow: {
                    size: '65%'
                },

                track: {
                    background: '#E5E7EB',
                    strokeWidth: '100%'
                },

                dataLabels: {

                    name: {
                        show: true,
                        offsetY: 30,
                        color: '#6B7280',
                        fontSize: '14px'
                    },

                    value: {
                        offsetY: -10,
                        fontSize: '38px',
                        fontWeight: 700,
                        formatter: function(val) {
                            return val + '%';
                        }
                    }

                }

            }
        },

        labels: ['Achievement']

    }
);

gaugeChart.render();
}
function renderTable(res)
{
    let html='';
    res.monthly_breakdown.forEach(row=>{
        html += `
        <tr>
            <td>${row.month}</td>
            <td>
                ₹${new Intl.NumberFormat('en-IN').format(row.current)}
            </td>
            <td>
                ₹${new Intl.NumberFormat('en-IN').format(row.previous)}
            </td>
        </tr>
        `;
    });

    $('#performanceTable').html(html);
}
</script>

<!-- global comparison -->

<script>

    function changeEntity() {
        var entity_id = $('#entity_filter').val();
        var branchDropdown = $('#branch_filter');
        branchDropdown.empty().append('<option value="" >Select Branch</option>');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });


                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }
   
</script>

<script>
    function branch_change_func () {
        let entityId = $('#entity_filter').val();
        let branchId = $('#branch_filter').val();
        $.ajax({
            url:'/sales_metrics/comparison/financial-years',
            type:'GET',
            data:{
                entity_id:entityId,
                branch_id:branchId
            },
            success:function(res){
                let html='';
                res.data.forEach(function(item){
                    html+=`
                    <div class="form-check form-check-inline mb-2">
                        <input class="form-check-input fy-checkbox" type="checkbox" value="${item.value}" checked>
                        <label class="form-check-label fw-semibold">${item.label}</label>
                    </div>
                    `;
                });
                $('#financial_year_container').html(html);
            }
        });
    }
</script>
<script>
    function openOverallComparison(){
        $('#overallComparisonModal').modal('show');
    
    }

  

    $('#compareBtn').click(function(){

        let btn=$(this);

        btn.prop('disabled',true);

        btn.html(`
            <span class="spinner-border spinner-border-sm me-2"></span>
            Comparing...
        `);

        $('#dashboardContent').hide();
        $('#dashboardPlaceholder').hide();
        $('#dashboardLoader').show();

        let years=[];

        $('.fy-checkbox:checked').each(function(){
            years.push($(this).val());
        });

        if ($('#entity_filter').val() == '') {
            toastr.warning('Please select Entity');
            $('#dashboardLoader').hide();
             $('#dashboardPlaceholder').show();
            btn.prop('disabled', false);
            btn.html(`
                <span class="mdi mdi-poll me-1"></span>
                Compare Analytics
            `);
            return;
        }
        if ($('#branch_filter').val() == '') {
            toastr.warning('Please select Branch');
             $('#dashboardLoader').hide();
             $('#dashboardPlaceholder').show();
            btn.prop('disabled', false);
            btn.html(`
                <span class="mdi mdi-poll me-1"></span>
                Compare Analytics
            `);
            return;
        }
        if(years.length == 0){
            toastr.warning('Please select at least one Financial Year');
             $('#dashboardLoader').hide();
            btn.prop('disabled', false);
            btn.html(`
                <span class="mdi mdi-poll me-1"></span>
                Compare Analytics
            `);
            return;
        }

        $.ajax({
            url:'/sales_metrics/comparison/dashboard',
            type:'POST',
            data:{
                entity_id:$('#entity_filter').val(),
                branch_id:$('#branch_filter').val(),
                financial_years:years,
                _token:$('meta[name=csrf-token]').attr('content')
            },
            success:function(res){
                $('#dashboardLoader').hide();
                $('#dashboardPlaceholder').hide();
                $('#dashboardContent').show();
                renderDashboardGlobal(res);

                btn.prop('disabled',false);

                btn.html(`
                    <span class="mdi mdi-poll me-1"></span>
                    Compare Analytics
                `);
               
            },
            error: function(error) {
                toastr.error('Unable to load analytics. Please try again.');
                console.error('Error fetching states:', error);
                 btn.prop('disabled',false);
                $('#dashboardLoader').hide();
                $('#dashboardContent').hide();
                $('#dashboardPlaceholder').show();
                 btn.html(`
                    <span class="mdi mdi-poll me-1"></span>
                    Compare Analytics
                `);
            },
            complete:function(){

                btn.prop('disabled',false);

                btn.html(`
                    <span class="mdi mdi-poll me-1"></span>
                    Compare Analytics
                `);

            }

        });

    });

    function renderDashboardGlobal(res){
        renderCards(res);
        renderComparisonChart(res);
        renderTrendChartGlobal(res);
        // renderGaugeGlobal(res);
        renderTableGlobal(res);
    }


    function renderCards(res)
    {
        let total = 0;

        res.cards.forEach(x => {
            total += Number(x.total);
        });

        $('#card_total').html(`
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-muted mb-2">
                        Total Collection
                    </div>
                    <h2 class="fw-bold text-success text-nowrap mb-6">
                        ₹${new Intl.NumberFormat('en-IN').format(total)}
                    </h2>
                </div>
            </div>
        `);

        $('#card_average').html(`
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-muted mb-2">
                        Average
                    </div>
                    <h2 class="fw-bold text-primary text-nowrap mb-6">
                        ₹${new Intl.NumberFormat('en-IN').format(res.average_collection)}
                    </h2>
                </div>
            </div>
        `);

        let growthColor =
            res.overall_growth >= 0
                ? 'success'
                : 'danger';

        let icon =
            res.overall_growth >= 0
                ? 'mdi-arrow-up-bold'
                : 'mdi-arrow-down-bold';

        // $('#card_growth').html(`
        //     <div class="card shadow-sm border-0 h-100">
        //         <div class="card-body">
        //             <div class="text-muted mb-2">
        //                 Growth
        //             </div>
        //             <h2 class="fw-bold text-${growthColor} text-nowrap">
        //                 <i class="mdi ${icon}"></i>
        //                 ${res.overall_growth}%
        //             </h2>
        //         </div>

        //     </div>
        // `);

        $('#card_best').html(`
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-muted">
                        Best Financial Year
                    </div>

                    <div class="fw-bold fs-3 mt-2 text-nowrap">
                        ${res.best_year.label}
                    </div>

                    <div class="text-success fs-5 text-nowrap">
                        ₹${new Intl.NumberFormat('en-IN').format(res.best_year.total)}
                    </div>
                </div>
            </div>
        `);

        $('#card_worst').html(`
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="text-muted">
                        Lowest Financial Year
                    </div>
                    <div class="fw-bold fs-3 mt-2 text-nowrap">
                        ${res.worst_year.label}
                    </div>
                    <div class="text-danger fs-5 text-nowrap">
                        ₹${new Intl.NumberFormat('en-IN').format(res.worst_year.total)}
                    </div>
                </div>
            </div>
        `);

    }

    let comparisonChart = null;

    function drawCurrentBadge(chart, res) {

        document.querySelectorAll(".current-badge").forEach(e => e.remove());

        const s = res.current_annotation.series_index;
        const d = res.current_annotation.month_index;

        const series = chart.el.querySelectorAll(".apexcharts-series")[s];

        if (!series) return;

        const bars = series.querySelectorAll("path");

        if (!bars[d]) return;

        const box = bars[d].getBBox();

        const svg = chart.el.querySelector("svg");

        const g = document.createElementNS("http://www.w3.org/2000/svg","g");
        g.setAttribute("class","current-badge");

        const rect = document.createElementNS("http://www.w3.org/2000/svg","rect");
        rect.setAttribute("x", box.x + 50);
        rect.setAttribute("y", box.y - 18);
        rect.setAttribute("width", 60);
        rect.setAttribute("height", 20);
        rect.setAttribute("rx", 5);
        rect.setAttribute("fill", "#FF4560");

        const text = document.createElementNS("http://www.w3.org/2000/svg","text");
        text.setAttribute("x", box.x + 80);
        text.setAttribute("y", box.y - 04);
        text.setAttribute("fill", "#fff");
        text.setAttribute("font-size", "10");
        text.setAttribute("font-weight", "700");
        text.setAttribute("text-anchor", "middle");
        text.textContent = "CURRENT";

        g.appendChild(rect);
        g.appendChild(text);

        svg.appendChild(g);
    }

    function renderComparisonChart(res)
    {
        if(comparisonChart){

            comparisonChart.destroy();

        }

        const ann = res.current_annotation;

        let annotations = {};

        const chartSeries = res.series.map(series => ({
            name: series.name,
            data: series.data.map((value, index) => ({
                x: res.months[index],
                y: value,
                fillColor: series.colors[index] || undefined
            }))
        }));
    
        comparisonChart = new ApexCharts(

            document.querySelector("#comparisonChart"),

            {

                chart:{
                    type:'bar',
                    height:450,
                    toolbar:{
                        show:true
                    },
                    events: {
                        mounted: function (chartContext) {
                            drawCurrentBadge(chartContext, res);
                        },
                        updated: function (chartContext) {
                            drawCurrentBadge(chartContext, res);
                        }
                    }
                },
                series:chartSeries,
                xaxis:{
                    categories:res.months
                },
                plotOptions:{
                    bar:{
                        borderRadius:8,
                        columnWidth:'55%'
                    }
                },
                legend:{
                    position:'top'
                },
                dataLabels: {
                    enabled: false,
                },

                tooltip:{
                    y:{
                        formatter:function(value){

                            return "₹"+new Intl.NumberFormat('en-IN').format(value);

                        }
                    }
                }

            }

        );

        comparisonChart.render();

    }

    let trendChartGlobal = null;

    function renderTrendChartGlobal(res)
    {
        if (trendChartGlobal) {
            trendChartGlobal.destroy();
        }

        trendChartGlobal = new ApexCharts(

            document.querySelector("#trendChartGlobal"),

            {

                chart: {
                    type: 'area',
                    height: 420,
                    toolbar: {
                        show: true
                    },
                    zoom: {
                        enabled: false
                    }
                },

                series: [{
                    name: 'Collection',
                    data: res.trend.data
                }],

                xaxis: {
                    categories: res.trend.labels
                },

                colors: ['#0d6efd'],

                stroke: {
                    curve: 'smooth',
                    width: 4
                },

                fill: {
                    type: 'gradient',
                    gradient: {
                        shadeIntensity: 1,
                        opacityFrom: 0.45,
                        opacityTo: 0.05,
                        stops: [0,100]
                    }
                },

                markers: {
                    size: 6,
                    hover:{
                        size:10
                    }
                },

                dataLabels:{
                    enabled:false
                },

                yaxis:{
                    labels:{
                        formatter:function(value){

                            return "₹"+(value/100000).toFixed(1)+"L";

                        }
                    }
                },

                tooltip:{
                    y:{
                        formatter:function(value){

                            return "₹"+new Intl.NumberFormat('en-IN').format(value);

                        }
                    }
                }

            }

        );

        trendChartGlobal.render();

    }

    let gaugeChartGlobal = null;

    function renderGaugeGlobal(res)
    {
        if (gaugeChartGlobal) {
            gaugeChartGlobal.destroy();
        }

        let color = '#16a34a';

        if (res.achievement < 60)
            color = '#dc2626';
        else if (res.achievement < 80)
            color = '#f59e0b';
        else
            color = '#16a34a';

        gaugeChartGlobal = new ApexCharts(
            document.querySelector("#achievementGaugeGlobal"),
            {
                chart:{
                    type:'radialBar',
                    height:360
                },
                series:[res.achievement],
                colors:[color],
                plotOptions:{
                    radialBar:{
                        startAngle:-135,
                        endAngle:135,
                        hollow:{
                            size:'65%'
                        },
                        track:{
                            background:'#E5E7EB',
                            strokeWidth:'100%'
                        },
                        dataLabels:{
                            name:{
                                show:true,
                                offsetY:30,
                                fontSize:'16px',
                                color:'#6B7280'
                            },
                            value:{
                                offsetY:-10,
                                fontSize:'42px',
                                fontWeight:700,
                                formatter:function(val){
                                    return val+'%';
                                }
                            }
                        }

                    }
                },
                fill:{
                    type:'gradient',
                    gradient:{
                        shade:'light',
                        type:'horizontal',
                        gradientToColors:[color],
                        opacityFrom:1,
                        opacityTo:1,
                        stops:[0,100]
                    }

                },
                stroke:{
                    lineCap:'round'
                },
                labels:['Achievement']
            }
        );

        gaugeChartGlobal.render();

    }
    function renderTableGlobal(res)
    {
        // Build Header
        let header = `
            <tr class="bg-primary text-white">
                <th class="text-white sticky-column">
                    Month
                </th>`;

        res.cards.forEach(year => {

            header += `
                <th class="text-center text-white">
                    ${year.label}
                </th>
            `;

        });

        header += `</tr>`;

        $('#performanceTableHeader').html(header);

        // Build Body
        let body = '';

        res.table.forEach(row => {

            body += `
                <tr>
                    <td class="fw-bold bg-light">
                        ${row.month}
                    </td>`;

            res.cards.forEach(year => {

                let value = row[year.label] ?? 0;

                body += `
                    <td class="text-end">
                        ₹${new Intl.NumberFormat('en-IN').format(value)}
                    </td>
                `;

            });

            body += `</tr>`;
        });

        $('#performanceTableGlobal').html(body);
    }
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0'); // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
</script>
@endsection