@extends('layouts/layoutMaster')

@section('title', 'Sales Target')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js']),
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    /* .cursor-pointer:hover {
        background-color: #f1f5f9 !important;
    } */

    .collapse.show+i {
        transform: rotate(180deg);
    }

    .collapse {
        transition: all 0.3s ease;
    }

    .modal-content {
        border-radius: 12px;
    }

    /* .table-hover tbody tr:hover {
        background: #f5f7fa;
    } */

    #achieveLoader {
        padding: 30px;
    }
</style>
<style>
    .target-matrix-wrapper {
        max-height: 75vh;
        overflow-x: auto;
        overflow-y: visible;
        border-radius: 12px;
        position: relative;
    }

    .target-matrix-table {
        min-width: 1800px;
        border-collapse: separate;
        border-spacing: 0;
    }

    .target-matrix-table thead th {
        position: sticky;
        top: 0;
        z-index: 10;
        text-align: center;
        vertical-align: middle;
    }

    .target-matrix-table td {
        overflow: visible !important;
        position: relative;
    }

    .quarter-header th {
        background: #ab2b22;
        color: #fff;
        font-size: 14px;
        font-weight: 700;
    }

    .month-header th {
        background: #edd2d0;
        color: #111;
        font-size: 13px;
    }

    .sticky-col {
        position: sticky !important;
        left: 0;
        z-index: 11 !important;
    }

    .sticky-col.bodyrow {
        background: #fff !important;
    }

    .entity-block {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .entity-logo {
        width: 42px;
        height: 42px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #eee;
    }

    .month-card {
        position: relative;
        min-width: 120px;
        background: #fff;
        border-radius: 12px;
        padding: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, .06);
        cursor: pointer;
        transition: .2s ease;
    }

    .month-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 18px rgba(0, 0, 0, .10);
    }

    .month-target {
        font-size: 18px;
        font-weight: 700;
        color: #111;
    }

    .month-sales {
        margin-top: 8px;
        display: flex;
        justify-content: space-between;
        font-size: 12px;
    }

    .pre-sale {
        color: #0d6efd;
        font-weight: 700;
    }

    .post-sale {
        color: #198754;
        font-weight: 700;
    }

    /* TOOLTIP */

    .month-tooltip {
        position: fixed;
        width: 360px;
        max-height: 420px;
        overflow-y: auto;

        background: #fff;
        border-radius: 16px;
        border: 1px solid #ececec;

        box-shadow: 0 15px 45px rgba(0, 0, 0, .18);

        z-index: 999999;

        display: none;
    }

    .tooltip-head {
        position: sticky;
        top: 0;
        background: linear-gradient(135deg, #ab2b22, #cf4338);
        color: #fff;
        padding: 14px 16px;
        border-radius: 16px 16px 0 0;
        z-index: 2;
    }

    .tooltip-quarter {
        font-size: 12px;
        opacity: .9;
    }

    .tooltip-month {
        font-size: 18px;
        font-weight: 700;
        margin-top: 2px;
    }

    .tooltip-body {
        padding: 14px;
    }

    .week-item {
        border: 1px solid #eee;
        border-radius: 12px;
        padding: 12px;
        margin-bottom: 14px;
        background: #fafafa;
    }

    .week-item:last-child {
        margin-bottom: 0;
    }

    .week-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
    }

    .week-title {
        font-size: 14px;
        font-weight: 700;
        color: #111;
    }

    .week-target {
        background: #e8f1ff;
        color: #0d6efd;
        padding: 5px 12px;
        border-radius: 30px;
        font-size: 11px;
        font-weight: 700;
    }

    .week-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
    }

    .week-box {
        background: #fff;
        border-radius: 10px;
        padding: 10px;
        border: 1px solid #eee;
    }

    .week-label {
        font-size: 11px;
        color: #777;
        margin-bottom: 4px;
        display: block;
    }

    .week-value {
        font-size: 13px;
        font-weight: 700;
        color: #111;
    }

    .month-tooltip::-webkit-scrollbar {
        width: 6px;
    }

    .month-tooltip::-webkit-scrollbar-thumb {
        background: #ccc;
        border-radius: 20px;
    }
</style>
<style>
    .incentive-accordion .accordion-item {
        border: 0;
        margin-bottom: 18px;
        border-radius: 24px !important;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0, 0, 0, .06);
        background: #fff;
    }

    .incentive-accordion .accordion-button {
        background: #fff;
        padding: 22px;
        box-shadow: none !important;
    }

    .incentive-accordion .accordion-button:not(.collapsed) {
        background:
            linear-gradient(135deg,
                rgba(115, 103, 240, .08),
                rgba(255, 255, 255, 1));
    }

    .incentive-accordion .accordion-button::after {
        background-size: 18px;
    }

    .staff-avatar {
        width: 58px;
        height: 58px;
        border-radius: 50%;
        background: linear-gradient(135deg, #ab2b22, #e2918b);
        color: #fff;
        font-size: 22px;
        font-weight: 700;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .staff-name {
        font-size: 18px;
        font-weight: 700;
        color: #111827;
    }

    .staff-role {
        font-size: 12px;
        color: #6b7280;
    }

    .reward-box {
        min-width: 140px;
        text-align: center;
        background: #f8fafc;
        border-radius: 18px;
        padding: 12px 18px;
    }

    .reward-label {
        font-size: 11px;
        color: #6b7280;
    }

    .reward-value {
        font-size: 24px;
        font-weight: 800;
        color: #28c76f;
    }

    .breakdown-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 16px;
    }

    .break-item {
        background: #f8fafc;
        border-radius: 18px;
        padding: 16px;
        border: 1px solid #eef2f7;
    }

    .break-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        /* margin-bottom: 10px; */
    }

    .break-label {
        font-size: 13px;
        font-weight: 600;
        color: #374151;
    }

    .break-value {
        font-size: 18px;
        font-weight: 700;
        color: #111827;
    }

    .break-progress {
        height: 8px;
        border-radius: 30px;
        overflow: hidden;
        background: #e5e7eb;
    }

    .break-progress-bar {
        height: 100%;
        border-radius: 30px;
        background: linear-gradient(90deg, #ab2b22, #e2918b);
    }

    .incentive-footer {
        border-top: 1px solid #eef2f7;
        margin-top: 20px;
        padding-top: 16px;
    }

    .footer-chip {
        padding: 10px 14px;
        border-radius: 14px;
        background: #f8fafc;
        font-size: 12px;
        color: #6b7280;
    }

    .footer-chip strong {
        color: #111827;
    }

    .currency-badge {
        padding: 6px 14px;
        border-radius: 30px;
        background: rgba(40, 199, 111, .12);
        color: #28c76f;
        font-size: 11px;
        font-weight: 700;
    }

    .zero-award {
        opacity: .65;
    }
</style>
<style>
    .incentive-loader-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        /* padding: 40px; */
    }


    .loader-circle-wrap {
        position: relative;
        width: 140px;
        height: 140px;
        margin: auto;
    }

    .loader-ring {
        transform: rotate(-90deg);
    }

    .loader-bg {
        fill: none;
        stroke: #edf2f7;
        stroke-width: 10;
    }

    .loader-progress {
        fill: none;
        stroke: #ab2b22;
        stroke-width: 10;
        stroke-linecap: round;
        stroke-dasharray: 377;
        stroke-dashoffset: 377;
        transition: stroke-dashoffset .4s ease;
    }

    .loader-center {
        position: absolute;
        inset: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    .loader-percent {
        font-size: 30px;
        font-weight: 800;
        color: #111827;
        line-height: 1;
    }

    .loader-status {
        font-size: 12px;
        color: #6b7280;
        margin-top: 6px;
    }

    .loader-title {
        font-size: 20px;
        font-weight: 700;
        color: #111827;
        margin-top: 24px;
    }

    .loader-subtitle {
        font-size: 13px;
        color: #6b7280;
        margin-top: 6px;
    }
</style>
<style>
    .week-modal-card {

        border: 1px solid #eee;

        border-radius: 16px;

        padding: 18px;

        margin-bottom: 18px;

        background: #fff;

        box-shadow: 0 4px 12px rgba(0, 0, 0, .05);
    }

    .week-modal-head {

        display: flex;

        justify-content: space-between;

        align-items: center;

        margin-bottom: 18px;
    }

    .week-modal-title {

        font-size: 18px;

        font-weight: 700;

        color: #111;
    }

    .week-modal-date {

        font-size: 13px;

        color: #777;

        margin-top: 4px;
    }

    .week-modal-target {

        background: #e8f1ff;

        color: #0d6efd;

        padding: 10px 18px;

        border-radius: 40px;

        font-size: 14px;

        font-weight: 700;
    }

    .week-modal-grid {

        display: grid;

        grid-template-columns: 1fr 1fr;

        gap: 15px;
    }

    .week-stat-card {

        border: 1px solid #eee;

        border-radius: 14px;

        padding: 16px;

        background: #fafafa;
    }

    .week-stat-label {

        font-size: 12px;

        color: #777;

        margin-bottom: 8px;
    }

    .week-stat-value {

        font-size: 22px;

        font-weight: 700;
    }

    .summary-mini-card {

        border: 2px solid;

        border-radius: 16px;

        padding: 20px;

        background: #fff;

        text-align: center;
    }

    .summary-mini-label {

        font-size: 13px;

        color: #777;

        margin-bottom: 8px;
    }

    .summary-mini-value {

        font-size: 28px;

        font-weight: 700;
    }
</style>
<style>
    .sticky_table thead th:not(:first-child):not(:last-child) {
        text-align: center;
        vertical-align: middle;
        white-space: nowrap;
        line-height: 1.2;
    }

    .sticky_table thead th:not(:first-child):not(:last-child) a {
        display: flex;
        flex-direction: column;
        text-decoration: none;
        color: inherit;
    }

    .sticky_table thead th:not(:first-child):not(:last-child) a div:first-child {
        font-weight: 600;
        font-size: 14px;

    }

    .sticky_table thead th:not(:first-child):not(:last-child) a div:last-child {
        font-size: 12px;
        color: #ccc;

    }

    .sticky_table tbody td {
        vertical-align: middle;
    }

    .sticky_table tbody td:first-child {
        position: sticky;
        left: 0;
        z-index: 2;
        background: #fff;
    }

    .sticky_table thead th:first-child {
        position: sticky;
        left: 0;
        z-index: 2;
        background: #ab2b22;
    }

    .sticky_table tbody td:last-child {
        position: sticky;
        right: 0;
        z-index: 2;
        background: #fff;


    }

    .sticky_table thead th:last-child {
        position: sticky;
        right: 0;
        padding: 2px;
        z-index: 2;
        background: #ab2b22;
    }
</style>
<style>
    .sticky_table {
        min-width: max-content;
    }

    .sticky_table thead th {
        white-space: nowrap;
        vertical-align: middle;
    }

    .sticky_table tbody td {
        vertical-align: middle;
        white-space: nowrap;
    }

    .sticky-col-left {
        position: sticky;
        left: 0;
        /* z-index: 5; */
        background: #fff !important;
    }

    .sticky-col-right {
        position: sticky;
        right: 0;
        /* z-index: 5; */
        background: #fff3cd !important;
    }

    .sticky_table thead .sticky-col-left {
        background: #ab2b22 !important;
        color: #fff;
    }

    .sticky_table thead .sticky-col-right {
        background: #ffc107 !important;
        color: #000;
    }

    .sticky_table tbody tr:hover td {
        background: #f8fbff;
    }

    .table-responsive {
        overflow: auto;
        max-height: 650px;
    }


</style>
@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Sales Target - <span class="target_label_year text-primary" id="target_label_year">({{ date('Y') }} - {{ date('Y')+1 }})</span></h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-trophy"></i> Business Strategy
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            Sales Target
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <a href="/targets" class="btn btn-sm fw-bold btn-primary text-white">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Update Target
                </a>
                <button type="button" class="btn btn-sm btn-primary" id="openOldCollectionModal">
                    <span class="mdi mdi-cash-edit"></span> Update Collection
                </button>
                @if($user_id == 0)
                <button type="button" class="btn btn-sm btn-primary" id="openAchieveModal">
                    <i class="mdi mdi-trending-up"></i> Fetch Achievement
                </button>
                <button type="button" class="btn btn-sm btn-primary" id="openIncentiveModal">
                    <i class="mdi mdi-trending-up"></i> Fetch Incentive
                </button>
                @endif

                <input type="text" id="global_year_picker" class="form-control w-100px" value="<?php echo date('Y') ?>" onchange="loadThemes(1)">
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadThemes(1)">
                            @php $options = [6,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Company..."
                                value="{{ $search_filter }}" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">

                <!-- <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Entity</th>
                            <th class="min-w-50px">Year</th>
                            <th class="min-w-100px">Target</th>
                            <th class="min-w-50px">Pre Sale</th>
                            <th class="min-w-50px">Post Sale</th>
                           
                        </tr>
                    </thead>
                    <tbody id="company-table-body" class="text-black fw-semibold fs-7">
                        <tr class="skeleton-loader" id="skeleton-loader">
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            <td class="skeleton-cell">
                                <div class="skeleton"></div>
                            </td>
                            
                        </tr>
                    </tbody>
                </table> -->
                <div class="table-responsive target-matrix-wrapper">

                    <table class="table table-bordered align-middle target-matrix-table">

                        <thead>

                            <!-- Quarter Header -->
                            <tr class="quarter-header">

                                <th rowspan="2" class="sticky-col head min-w-250px bg-primary">
                                    Entity / Year
                                </th>

                                <th colspan="3">Q1</th>
                                <th colspan="3">Q2</th>
                                <th colspan="3">Q3</th>
                                <th colspan="3">Q4</th>

                            </tr>

                            <!-- Month Header -->
                            <tr class="month-header">

                                <th>Apr</th>
                                <th>May</th>
                                <th>Jun</th>

                                <th>Jul</th>
                                <th>Aug</th>
                                <th>Sep</th>

                                <th>Oct</th>
                                <th>Nov</th>
                                <th>Dec</th>

                                <th>Jan</th>
                                <th>Feb</th>
                                <th>Mar</th>

                            </tr>

                        </thead>

                        <tbody id="company-table-body"></tbody>

                    </table>

                </div>
            </div>
            <div class="text-center my-3" id="pagination-container">
                <!-- Pagination buttons will appear here -->
            </div>
        </div>
    </div>
</div>

<!--begin::Modal View Entity--->
<div class="modal fade" id="kt_modal_view_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                    data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex align-items-center mb-2 gap-2">
                    <div class="avatar-stack">
                        <img src="{{ asset('assets/common/logo_small.png') }}" id="view_entity_logo" alt="user-avatar"
                            class="avatar-img" />
                    </div>
                    <div class="">
                        <span class="text-black fw-semibold fs-3">View Entity</span>
                    </div>
                </div>
            </div>

            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <div class="row mb-3">
                    <div class="nav-align-top nav-tabs-shadow mb-3">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab"
                                    data-bs-target="#basic_info_entity" aria-controls="basic_info_entity" aria-selected="true">
                                    Company Info
                                </button>
                            </li>
                            <li class="nav-item">
                                <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                    data-bs-target="#legaltax_entity" aria-controls="legaltax_entity" aria-selected="false">
                                    Legal / Tax
                                </button>
                            </li>
                            <li class="nav-item">
                                <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                    data-bs-target="#bankinfo_entity" aria-controls="bankinfo_entity"
                                    aria-selected="false">
                                    Bank Info
                                </button>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="basic_info_entity" role="tabpanel">
                            <div class="row ">
                                <div class="col-lg-12">
                                    <div class="row mb-4">
                                        <label class="col-5  text-dark fs-7 fw-semibold">Entity</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data-entity"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="" id="view_entityname" style="display:none;">
                                                Elysian Intelligence Business Solution
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Company</label>
                                        <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <div class="text-truncate max-w-75 text-black fs-6  fw-semibold view-data-entity"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="" id="view_companyname_entity" style="display:none;">Private
                                                Limited Company (Pvt Ltd)
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Email ID</label>
                                        <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <div class="text-truncate max-w-75 text-black fs-6  fw-semibold view-data-entity"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="" id="view_emailid_entity" style="display:none;">info@eibsglobal.com</div>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-6 fw-semibold">Website URL</label>
                                        <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <a href="" target="_blank"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom" class="view-data-entity"
                                                title="" id="view_website_tag_entity" style="display:none;">
                                                <div class="text-truncate max-w-75 text-black fs-7  fw-semibold" id="view_website">
                                                    https://eibsglobal.com/</div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Contact Person</label>
                                        <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <div class="text-truncate max-w-75 text-black fs-6  fw-semibold view-data-entity"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="" id="view_contactperson_entity" style="display:none;">
                                                Sankar Ganesh</div>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">C.P. Mobile No</label>
                                        <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                        <div class="col-6">
                                            <label class=" skeleton-loader-view max-w-75"></label>
                                            <label class="text-black fs-6 fw-semibold view-data-entity" id="view_cp_mobileno_entity" style="display:none;">9894444710</label>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                        <label class="col-1 fw-semibold fs-7">:</label>
                                        <div class="col-6">
                                            <label class="skeleton-loader-view max-w-75"></label>
                                            <label class="fw-semibold fs-6 text-black view-data-entity" id="view_description_entity" style="display:none;">-</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="legaltax_entity" role="tabpanel">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">GST No</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data-entity"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="" id="view_gstno_entity" style="display:none;">
                                                27AABCU9603R1ZV</div>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">CIN No</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data-entity"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="" id="view_cinno_entity" style="display:none;">U12345MH2005PTC123456
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">PAN No</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <div class="col-6">
                                            <div class="skeleton-loader-view max-w-75"></div>
                                            <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data-entity"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                title="" id="view_panno_entity" style="display:none;">
                                                AABCU9603R</div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="bankinfo_entity" role="tabpanel">
                            <div class="row ">
                                <div class="col-lg-12">
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Bank</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <div class="col-6">
                                            <label class=" skeleton-loader-view max-w-75"></label>
                                            <label class=" text-black fs-6 fw-semibold view-data-entity" id="view_bank_entity" style="display:none;">HDFC</label>
                                        </div>

                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Branch</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <div class="col-6">
                                            <label class="skeleton-loader-view max-w-75"></label>
                                            <label class="text-black fs-6 fw-semibold view-data-entity" id="view_branch_entity" style="display:none;">Anna Nagar</label>
                                        </div>

                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">IFSC Code</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <div class="col-6">
                                            <label class=" skeleton-loader-view max-w-75"></label>
                                            <label class=" text-black fs-6 fw-semibold view-data-entity" id="view_ifsccode_entity" style="display:none;">HDFC0002027</label>
                                        </div>

                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Account Holder</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <div class="col-6">
                                            <label class=" skeleton-loader-view max-w-75"></label>
                                            <label class=" text-black fs-6 fw-semibold view-data-entity" id="view_accountholder_entity" style="display:none;">Elysium Intelligence Business
                                                Solutions</label>
                                        </div>

                                    </div>
                                    <div class="row mb-4">
                                        <label class="col-5 text-dark fs-7 fw-semibold">Account No</label>
                                        <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                        <div class="col-6">
                                            <label class=" skeleton-loader-view max-w-75"></label>
                                            <label class=" text-black fs-6 fw-semibold view-data-entity" id="view_accountno_entity" style="display:none;">8574854578452</label>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal -View Entity-->


<div class="modal fade" id="achieveModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <span class="text-black fs-3 fw-bold"><i class="mdi mdi-chart-line"></i> Achievement Sync</span>
                </div>
                <div class=" mb-3">
                    <div class="row g-2">

                    </div>
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">

                <!-- FILTER SECTION -->
                <div class="row g-3 mb-3">

                    <div class="col-md-4">
                        <label>Entity</label>
                        <select id="entitySelect" class="form-select select3" onchange="changeEntity()">
                            <option value="">Select Entity</option>
                            @foreach($entity_list as $e)
                            <option value="{{ $e->sno }}" data-baseurl="{{ $e->entity_base_url }}">{{ $e->entity_name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class=" col-md-4">
                        <label>Branch</label>
                        <select id="branchSelect" class="form-select select3">
                            <option value="">Select Branch</option>
                        </select>
                    </div>

                    <!-- <div class="col-md-4">
                        <label>Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="achieveDate" name="achieveDate" placeholder="Select Date" class="form-control common_datepicker" readonly value="<?php echo date("d-M-Y"); ?>" />
                        </div>

                    </div> -->
                    <div class="col-md-4">
                        <label>From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-calendar-month-outline fs-4"></i>
                            </span>
                            <input type="text"
                                id="fromDate"
                                class="form-control common_datepicker"
                                readonly
                                value="{{ date('d-M-Y') }}">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label>To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-calendar-month-outline fs-4"></i>
                            </span>
                            <input type="text"
                                id="toDate"
                                class="form-control common_datepicker"
                                readonly
                                value="{{ date('d-M-Y') }}">
                        </div>
                    </div>

                </div>

                <!-- ACTION BUTTON -->
                <div class="d-flex gap-2 justify-content-end mb-3">
                    <div id="erp_total_data" class="d-none">
                        <div class="d-flex gap-2">
                            <div>
                                <label for="target_amount_erp">Collection</label>
                                <span id="target_amount_erp"></span>
                            </div>
                            <div>
                                <label for="target_pre_erp">Pre Sale</label>
                                <span id="target_pre_erp"></span>
                            </div>
                            <div>
                                <label for="target_post_erp">Post Sale</label>
                                <span id="target_post_erp"></span>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary px-4" id="fetchAchieveBtn">
                        <i class="mdi mdi-cloud-download-outline"></i> Fetch Data
                    </button>
                </div>

                <!-- LOADER -->
                <div id="achieveLoader" class="text-center d-none">
                    <div class="spinner-border text-primary"></div>
                    <p class="mt-2">Fetching ERP Data...</p>
                </div>

                <!-- DATA TABLE -->
                <div id="achieveTableWrapper" class="d-none max-h-600px table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="sticky-top">
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary ">
                                <th>#</th>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Pre Sale</th>
                                <th>Post Sale</th>
                            </tr>
                        </thead>
                        <tbody id="achieveTable"></tbody>
                    </table>
                </div>

            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-success px-4 d-none" id="saveAchieveBtn">
                    <i class="mdi mdi-check-circle-outline"></i> Confirm & Save
                </button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<div class="modal fade" id="updateCollectionModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <span class="text-black fs-3 fw-bold"> Update Collection Value</span>
                </div>
                <div class=" mb-3">
                    <div class="row g-2 me-3">
                        <span class="badge bg-info text-black rounded-circle fs-4 cursor-pointer"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="Refresh" onclick="refreshUpdateCollection()"><span class="mdi mdi-refresh"></span></span>
                    </div>
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                 <!-- STICKY UPDATE PANEL -->
                <div class="bg-white p-4">

                    <div class="row g-3 align-items-end">
                        <!-- MONTH -->
                        <div class="col-md-2">
                            <label class="form-label fw-semibold">Month</label>
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="mdi mdi-calendar"></i>
                                </span>
                                <input type="text" id="updateCollectionDate" class="form-control month_filter_common_class"  readonly value="{{ date('M-Y') }}" onchange="loadCollectionAmount()">
                            </div>
                        </div>
                        <!-- ENTITY -->
                        <div class="col-md-3">
                            <label class="form-label fw-semibold"> Entity</label>
                            <select id="entityCollectSelect"  class="form-select select3" onchange="changeCollectionEntity()">
                                <option value=""> Select Entity</option>
                                @foreach($entity_list as $e)
                                <option value="{{ $e->sno }}">
                                    {{ $e->entity_name }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                        <!-- BRANCH -->
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Branch</label>
                            <select id="branchCollectSelect" class="form-select select3" onchange="loadCollectionAmount()">
                                <option value="">Select Branch</option>
                            </select>
                        </div>
                        <!-- AMOUNT -->
                        <div class="col-md-2">
                            <label class="form-label fw-semibold">Collection</label>
                            <div class="input-group">
                                <span class="input-group-text">₹</span>
                                <input type="text" id="updateCollectionvalue"class="form-control text-end fw-bold" value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                            </div>
                        </div>
                        <!-- BUTTON -->
                        <div class="col-md-2">
                            <button class="btn btn-primary w-100" id="savecollectionBtn">
                                <span class="btn-text">
                                    <i class="mdi mdi-content-save-outline"></i>
                                    Update
                                </span>
                                <span class="spinner-border spinner-border-sm d-none"></span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- LOADER -->
                <div id="collectionLoader" class="text-center py-5 d-none">
                    <div class="spinner-border text-primary"></div>
                    <div class="mt-2 fw-semibold">Loading Collection Data...</div>
                </div>

                <!-- TABLE -->
                <div class="p-4">
                    <div class="table-responsive max-h-600px">
                        <table class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                            <thead class="sticky-top" id="collectionTableHead"> </thead>
                            <tbody class="text-black fw-semibold fs-7 attendance-body" id="collectionTableBody">
                                
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<div class="modal fade" id="incentiveModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <span class="text-black fs-3 fw-bold"><i class="mdi mdi-chart-line"></i> Incentive Sync</span>
                </div>
                <div class=" mb-3">
                    <div class="row g-2">

                    </div>
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">

                <!-- FILTER SECTION -->
                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <label>Entity</label>
                        <select id="entityIncentive" class="form-select select3" onchange="changeIncetiveEntity()">
                            <option value="">Select Entity</option>
                            @foreach($entity_list as $e)
                            <option value="{{ $e->sno }}" data-baseurl="{{ $e->entity_base_url }}">{{ $e->entity_name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class=" col-md-4">
                        <label>Branch</label>
                        <select id="branchIncentive" class="form-select select3" onchange="changeIncetiveBranch()">
                            <option value="">Select Branch</option>
                        </select>
                    </div>
                    <div class=" col-md-4">
                        <label>Role</label>
                        <select id="roleIncentive" class="form-select select3">
                            <option value="">Select Role</option>
                        </select>
                    </div>
                
                    <div class="col-md-4">
                        <label>Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text">
                                <i class="mdi mdi-calendar-month-outline fs-4"></i>
                            </span>
                            <input type="text"
                                class="form-control "
                                id="month_year"
                                readonly
                                value="{{ date('M-Y') }}">
                        </div>
                    </div>

                </div>

                <!-- ACTION BUTTON -->
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-primary px-4" id="fetchIncentiveBtn">
                        <i class="mdi mdi-cloud-download-outline"></i> Fetch Data
                    </button>
                </div>
             
                <div id="incentiveLoader" class="incentive-loader-wrapper d-none">

                    <div class="incentive-loader-card">

                        <div class="loader-circle-wrap">

                            <svg class="loader-ring" width="140" height="140">

                                <circle class="loader-bg"
                                    cx="70"
                                    cy="70"
                                    r="60">
                                </circle>

                                <circle class="loader-progress"
                                    cx="70"
                                    cy="70"
                                    r="60">
                                </circle>

                            </svg>

                            <div class="loader-center">

                                <div id="loaderPercent" class="loader-percent">
                                    0%
                                </div>

                                <div class="loader-status">
                                    Fetching...
                                </div>

                            </div>

                        </div>

                        <div class="loader-title">
                            Retrieving Incentive Data
                        </div>

                        <div class="loader-subtitle mb-3">
                            Please wait while we process ERP records
                        </div>

                    </div>

                </div>

                <div class="accordion incentive-accordion" id="incentiveCards"></div>

            </div>

        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="weekTargetModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 pt-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="">
                    <span class="text-black fs-3 fw-bold"><i class="mdi mdi-calendar-weekend"></i> Week Targets</span>
                </div>
                <div class=" mb-3">
                    <div class="row g-2">

                    </div>
                </div>
            </div>
            <!--begin::Modal body-->
            <div class="modal-body pt-5 pb-8 px-10 bg-white rounded-bottom min-h-150px">
                <div id="week_target_data"></div>
            </div>

        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<script>
    const months = [{
            name: 'April',
            q: 'Q1'
        }, {
            name: 'May',
            q: 'Q1'
        }, {
            name: 'June',
            q: 'Q1'
        },
        {
            name: 'July',
            q: 'Q2'
        }, {
            name: 'August',
            q: 'Q2'
        }, {
            name: 'September',
            q: 'Q2'
        },
        {
            name: 'October',
            q: 'Q3'
        }, {
            name: 'November',
            q: 'Q3'
        }, {
            name: 'December',
            q: 'Q3'
        },
        {
            name: 'January',
            q: 'Q4'
        }, {
            name: 'February',
            q: 'Q4'
        }, {
            name: 'March',
            q: 'Q4'
        }
    ];
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    // function buildRow(item, index) {

    //     var data = typeof item.data === 'string' ? JSON.parse(item.data) : item.data;
    //     var quarterData = typeof item.quarterData === 'string' ? JSON.parse(item.quarterData) : item.quarterData;

    //     let logoPath = item.entity_favicon ?
    //         `/Entity_favicons/${item.company_id}/${item.entity_favicon}` :
    //         '';

    //     let quarterRow = '';

    //     if (quarterData.length > 0) {

    //         quarterData.forEach((q, qi) => {

    //             let quarterId = `q_${item.sno}_${qi}`;
    //             let monthTable = '';

    //             // =========================
    //             // MONTH TABLE
    //             // =========================
    //             if (q.months && q.months.length > 0) {

    //                 q.months.forEach((m, mi) => {

    //                     let monthId = `m_${item.sno}_${qi}_${mi}`;
    //                     let monthName = getMonthName(m.month);

    //                     let weekRows = '';

    //                     if (m.weeks && m.weeks.length > 0) {
    //                         m.weeks.forEach((w) => {
    //                             weekRows += `
    //                             <tr>
    //                                 <td>
    //                                 <div>
    //                                     Week ${w.week}
    //                                 </div>
    //                                 </td>
    //                                 <td>${w.week_start_date || '-'}</td>
    //                                 <td>${w.week_end_date || '-'}</td>
    //                                 <td>
    //                                     <label class="fs-7 text-nowrap">
    //                                         <span class="mdi mdi-currency-rupee "></span>
    //                                         <span class="">${w.target_amount ? new Intl.NumberFormat('en-IN').format(w.target_amount) :'0'}</span>
    //                                     </label>
    //                                 </td>
    //                                 <td class="fs-7" >${w.pre_sale || 0}</td>
    //                                 <td class="fs-7" >${w.post_sale || 0}</td>
    //                             </tr>
    //                         `;
    //                         });
    //                     }

    //                     monthTable += `
    //                     <!-- MONTH ROW -->
    //                     <tr data-bs-toggle="collapse" data-bs-target="#${monthId}" class="cursor-pointer bg-light">
    //                         <td>${monthName}</td>
    //                         <td>
    //                         <label class="text-nowrap fs-7">
    //                             <span class="mdi mdi-currency-rupee "></span>
    //                             <span class="">${m.target_amount ? new Intl.NumberFormat('en-IN').format(m.target_amount) :'0'}</span>
    //                         </label>
    //                         </td>
    //                         <td class="fs-7" >${m.pre_sale || 0}</td>
    //                         <td class="fs-7" >${m.post_sale || 0}</td>
    //                     </tr>

    //                     <!-- MONTH DETAILS -->
    //                     <tr id="${monthId}" class="collapse">
    //                         <td colspan="4">
    //                             <table class="table table-sm table-bordered mb-2">
    //                                 <thead >
    //                                     <tr class="table-warning text-black">
    //                                         <th class="text-black">Week</th>
    //                                         <th class="text-black">Start</th>
    //                                         <th class="text-black">End</th>
    //                                         <th class="text-black">Target</th>
    //                                         <th class="text-black">Pre</th>
    //                                         <th class="text-black">Post</th>
    //                                     </tr>
    //                                 </thead>
    //                                 <tbody>
    //                                     ${weekRows || `<tr><td colspan="6" class="text-center">No Weeks</td></tr>`}
    //                                 </tbody>
    //                             </table>
    //                         </td>
    //                     </tr>
    //                 `;
    //                 });
    //             }

    //             // =========================
    //             // QUARTER TABLE ROW
    //             // =========================
    //             quarterRow += `
    //             <!-- QUARTER HEADER -->
    //             <tr class="cursor-pointer fw-bold" id="quarter_hd_${q.id}">

    //                 <td>
    //                     <div class="d-flex align-items-center gap-2">

    //                         ${q.months.length > 0 ? `
    //                             <a href="javascript:;" 
    //                             class="btn btn-sm btn-primary"
    //                             onclick="quarter_collapse_fuc(${q.id})">
    //                             <i class="mdi mdi-plus" id="quarter_${q.id}_plus_btton"></i>
    //                             </a>` : ''}
    //                         <span>${q.quarter}</span>
    //                         <div class="small">
    //                             ${months.filter(m => m.q == q.quarter).map(m => m.name).join(', ')}
    //                         </div>
    //                     </div>
    //                 </td>
    //                 <td>
    //                     <label class="fs-6 text-nowrap">
    //                         <span class="mdi mdi-currency-rupee "></span>
    //                         <span class="">${q.target_amount ? new Intl.NumberFormat('en-IN').format(q.target_amount) :'0'}</span>
    //                     </label>

    //                 <td class="fs-6" >${q.pre_sale || 0}</td>
    //                 <td class="fs-6" >${q.post_sale || 0}</td>
    //             </tr>

    //             <!-- QUARTER DETAILS -->
    //             <tr id="quarter_hd_${q.id}_tbox" style="display:none;">
    //                 <td colspan="4">

    //                     <table class="table table-bordered table-sm mb-0">
    //                         <thead class="table-dark">
    //                             <tr>
    //                                 <th>Month</th>
    //                                 <th>Target</th>
    //                                 <th>Pre Sale</th>
    //                                 <th>Post Sale</th>
    //                             </tr>
    //                         </thead>
    //                         <tbody>
    //                             ${monthTable || `<tr><td colspan="4" class="text-center">No Months</td></tr>`}
    //                         </tbody>
    //                     </table>

    //                 </td>
    //             </tr>
    //         `;
    //         });

    //     } else {
    //         quarterRow = `<tr><td colspan="4" class="text-center">No Data</td></tr>`;
    //     }

    //     // =========================
    //     // MAIN ROW
    //     // =========================
    //     return `
    //     <tr id="rev_prop_hd_${item.sno}">
    //         <td>
    //             <div class="d-flex align-items-center gap-2">

    //                 ${item.quarter_count > 0 ? `
    //                     <a href="javascript:;" 
    //                        class="btn btn-sm btn-primary"
    //                        onclick="rev_prop_fuc(${item.sno})">
    //                        <i class="mdi mdi-plus" id="rev_prop_${item.sno}_plus_btton"></i>
    //                     </a>` : ''}

    //                 <img src="${logoPath}"  class="w-px-40 h-px-40 rounded-circle border"/>

    //                 <div>${item.entity_name}</div>
    //             </div>
    //         </td>

    //         <td class="fw-bold text-primary">
    //             ${item.year} - ${item.next_year}
    //         </td>

    //         <td>
    //             <label class=" text-nowrap fs-5">
    //                 <span class="mdi mdi-currency-rupee "></span>
    //                 <span class="">${item.total_target ? new Intl.NumberFormat('en-IN').format(item.total_target) :'0'}</span>
    //             </label>

    //         </td>
    //         <td class="fs-5" >${item.total_pre_sale}</td>
    //         <td class="fs-5" >${item.total_post_sale}</td>
    //     </tr>

    //     <!-- EXPAND AREA -->
    //     <tr id="rev_prop_${item.sno}_tbox" style="display:none;">
    //         <td colspan="6">

    //             <div class="table-responsive">
    //                 <table class="table table-bordered">

    //                     <!-- QUARTER HEADER -->
    //                     <thead >
    //                         <tr class="text-start align-top  fw-bold fs-6 gs-0 " style="background-color:${hexToRgba(data.entity_base_color, 1)};">
    //                             <th>Quarter</th>
    //                             <th>Target</th>
    //                             <th>Pre Sale</th>
    //                             <th>Post Sale</th>
    //                         </tr>
    //                     </thead>

    //                     <tbody>
    //                         ${quarterRow}
    //                     </tbody>

    //                 </table>
    //             </div>

    //         </td>
    //     </tr>
    // `;
    // }

    function buildRow(item) {

        let logoPath = item.entity_favicon ?
            `/Entity_favicons/${item.company_id}/${item.entity_favicon}` :
            '';

        let quarterData = typeof item.quarterData === 'string' ?
            JSON.parse(item.quarterData) :
            item.quarterData;

        let monthMap = {};

        quarterData.forEach(q => {

            q.months.forEach(m => {

                monthMap[m.month] = m;

            });

        });

        const orderedMonths = [
            4, 5, 6,
            7, 8, 9,
            10, 11, 12,
            1, 2, 3
        ];

        let monthColumns = '';

        const monthNames = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        };

        function getQuarter(monthNo) {

            if ([4, 5, 6].includes(monthNo)) return 'Q1';
            if ([7, 8, 9].includes(monthNo)) return 'Q2';
            if ([10, 11, 12].includes(monthNo)) return 'Q3';

            return 'Q4';
        }

        function getFinancialYear(monthNo, startYear) {

            // Jan Feb Mar -> next year
            if ([1, 2, 3].includes(monthNo)) {
                return parseInt(startYear) + 1;
            }

            return startYear;
        }

        orderedMonths.forEach(monthNo => {

            let m = monthMap[monthNo];

            let monthName = monthNames[monthNo];

            let quarterName = getQuarter(monthNo);

            let displayYear = getFinancialYear(monthNo, item.year);

            let weekHtml = '';

            if (m?.weeks?.length > 0) {

                m.weeks.forEach(w => {

                    weekHtml += `

            <div class="week-item">

                <div class="week-header">

                    <div class="week-title">
                        Week ${w.week}
                    </div>

                    <div class="week-target">
                        ₹${w.target_amount
                            ? new Intl.NumberFormat('en-IN').format(w.target_amount)
                            : 0}
                    </div>

                </div>

                <div class="week-grid">

                    <div class="week-box">
                        <span class="week-label">Start</span>
                        <span class="week-value">
                            ${w.week_start_date || '-'}
                        </span>
                    </div>

                    <div class="week-box">
                        <span class="week-label">End</span>
                        <span class="week-value">
                            ${w.week_end_date || '-'}
                        </span>
                    </div>

                    <div class="week-box">
                        <span class="week-label">Pre Sale</span>
                        <span class="week-value text-primary">
                            ${w.pre_sale || 0}
                        </span>
                    </div>

                    <div class="week-box">
                        <span class="week-label">Post Sale</span>
                        <span class="week-value text-success">
                            ${w.post_sale || 0}
                        </span>
                    </div>

                </div>

            </div>
            `;
                });

            } else {

                weekHtml = `
            <div class="text-center text-muted py-3">
                No Weekly Data
            </div>
        `;
            }

            monthColumns += `

    <td>

        <div class="month-card" 
            onclick='openWeekTargetModal(${JSON.stringify(encodeURIComponent(JSON.stringify({
                    monthName,
                    displayYear,
                    quarterName,
                    target: m?.target_amount || 0,
                    pre_sale: m?.pre_sale || 0,
                    post_sale: m?.post_sale || 0,
                    weeks: m?.weeks || []
                }))
            )})'>

            <div class="month-target">
                ₹${m?.target_amount
                    ? new Intl.NumberFormat('en-IN').format(m.target_amount)
                    : 0}
            </div>

            <div class="month-sales">

                <div class="pre-sale">
                    Pre: ${m?.pre_sale || 0}
                </div>

                <div class="post-sale">
                    Post: ${m?.post_sale || 0}
                </div>

            </div>

            
            

        </div>

    </td>
    `;
        });

        return `

    <tr class="" >

        <td class="sticky-col bodyrow">

            <div class="entity-block">

                <img src="${logoPath}" class="entity-logo">

                <div>

                    <div class="fw-bold">
                        ${item.entity_name}
                    </div>

                    <div class="text-primary small">
                        ${item.year}-${item.next_year}
                    </div>

                    <div class="small text-success">
                        Total Target:
                        ₹${new Intl.NumberFormat('en-IN').format(item.total_target || 0)}
                    </div>

                </div>

            </div>

        </td>

        ${monthColumns}

    </tr>
    `;
    }

    function hexToRGBA(hex, opacity) {
        let r = 0,
            g = 0,
            b = 0;

        if (hex.length == 7) {
            r = parseInt(hex.substring(1, 3), 16);
            g = parseInt(hex.substring(3, 5), 16);
            b = parseInt(hex.substring(5, 7), 16);
        }

        return `rgba(${r}, ${g}, ${b}, ${opacity})`;
    }

    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const year = Number($('#global_year_picker').val());
        const url = `/manage_targets?page=${page}&sorting_filter=${perpage}&search_filter=${search}&year=${year}`;

        $('#target_label_year').text(year + '-' + (year + 1))

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('company-table-body').innerHTML = ''; // Clear old data
        document.getElementById('company-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if (res.data.length > 0) {
                    res.data.forEach((item, index) => {
                        document.getElementById('company-table-body').insertAdjacentHTML('beforeend', buildRow(item, index));
                    });

                } else {
                    document.getElementById('company-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                // $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                
            </tr>
            `;
    }

    function NoDataFound() {
        return `
            <tr><td colspan="5" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1); // Trigger the search when the user presses enter
        }
    }

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        loadThemes(1); // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1); // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);
</script>

<script>
    function viewmodel(id) {
        // Show skeleton loaders before fetch
        document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
            skeleton.style.display = 'block'; // Show skeleton loaders
        });

        // Hide actual data elements
        document.querySelectorAll('.view-data').forEach(element => {
            element.style.display = 'none'; // Hide actual data until it is loaded
        });

        fetch('/company_view/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    var logoPath = com.company_logo ? `/Company_logos/${com.company_logo}` : '/assets/common/logo_small.png';
                    document.getElementById('view_company_logo').src = logoPath;
                    document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                        skeleton.style.display = 'none'; // Hide skeleton loaders
                    });
                    document.querySelectorAll('.view-data').forEach(element => {
                        element.style.display = 'block'; // Show actual data
                    });

                    $('#view_companyname').html(com.company_name).attr('title', com.company_name);
                    $('#view_companytype').html(com.company_type_name + '(' + com.slug_name + ')'); //company_mail
                    $('#view_emailid').html(com.company_mail).attr('title', com.company_mail);
                    $('#view_website').html(com.company_website);
                    $('#view_website_tag').attr('title', com.company_website).attr('href', com
                        .company_website);
                    $('#view_websitelink').attr('href', com.company_website); //company_ct_person//company_ct_number
                    $('#view_contactperson').html(com.company_ct_person).attr('title', com.company_ct_person);
                    $('#view_cp_mobileno').html(com.company_ct_number);
                    $('#view_address').html(
                        (com.company_door_no || '') + ', ' +
                        (com.company_area || '') + ', ' +
                        (com.citiesname || '') + ', ' +
                        (com.statename || '') + ', ' +
                        (com.name || '')
                    );
                    $('#view_description').html(com.company_desc || '-');
                    $('#view_gstno').html(com.company_gst);
                    $('#view_cinno').html(com.company_cin);
                    $('#view_panno').html(com.company_pan);
                    $('#view_bank').html(com.company_bank_name);
                    $('#view_branch').html(com.company_bank_branch);
                    $('#view_accountholder').html(com.company_acc_holder);
                    $('#view_accountno').html(com.company_acc_no).attr('title', com.company_acc_no);
                    $('#view_ifsccode').html(com.company_ifsc);

                    $('[data-bs-toggle="tooltip"]').tooltip();
                } else {
                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
</script>

<script>
    function rev_prop_fuc(val) {
        var rev_prop_tbox = document.getElementById(`rev_prop_${val}_tbox`);
        var plus_button = document.getElementById(`rev_prop_${val}_plus_btton`);
        var header = document.getElementById(`rev_prop_hd_${val}`);

        if (rev_prop_tbox.style.display === "none" || rev_prop_tbox.style.display === "") {
            rev_prop_tbox.style.display = "table-row";
            plus_button.classList.remove("mdi-plus");
            plus_button.classList.add("mdi-minus");
            header.style.backgroundColor = "#f9f3c5db";

        } else {
            rev_prop_tbox.style.display = "none";
            plus_button.classList.remove("mdi-minus");
            plus_button.classList.add("mdi-plus");
            header.removeAttribute("style");
        }
    }

    function quarter_collapse_fuc(val) {
        var rev_prop_tbox = document.getElementById(`quarter_hd_${val}_tbox`);
        var plus_button = document.getElementById(`quarter_${val}_plus_btton`);
        var header = document.getElementById(`quarter_hd_${val}`);

        if (rev_prop_tbox.style.display === "none" || rev_prop_tbox.style.display === "") {
            rev_prop_tbox.style.display = "table-row";
            plus_button.classList.remove("mdi-plus");
            plus_button.classList.add("mdi-minus");
            header.style.backgroundColor = "#f9f3c5db";

        } else {
            rev_prop_tbox.style.display = "none";
            plus_button.classList.remove("mdi-minus");
            plus_button.classList.add("mdi-plus");
            header.removeAttribute("style");
        }
    }

    function hexToRgba(hex, alpha = 0.2) {
        hex = hex.replace('#', '');

        if (hex.length === 3) {
            hex = hex.split('').map(c => c + c).join('');
        }

        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);

        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    function getMonthName(monthNumber) {
        const months = [
            'January', 'February', 'March',
            'April', 'May', 'June',
            'July', 'August', 'September',
            'October', 'November', 'December'
        ];
        return months[monthNumber - 1];
    }
</script>
<script>
    function changeEntity() {
        var entity_id = $('#entitySelect').val();
        var branchDropdown = $('#branchSelect');
        branchDropdown.empty().append('<option value="" >Select Branch</option>');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });


                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }

    function changeIncetiveEntity() {
        var entity_id = $('#entityIncentive').val();
        var branchDropdown = $('#branchIncentive');
        branchDropdown.empty().append('<option value="" >Select Branch</option>');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });


                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }

    function changeIncetiveBranch() {
        var entity_id = $('#entityIncentive').val();
        var branchDropdown = $('#roleIncentive');
        branchDropdown.empty().append('<option value="" >Select Role</option>');
        if (entity_id) {
            $.ajax({
                url: "{{ route('incentive_role_by_entity') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erproleid', state.erp_role_id)
                                .text(state.role_name));
                        });


                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }
</script>
<script>
    // OPEN MODAL
    $('#openAchieveModal').click(function() {
        $('#achieveModal').modal('show');
        $('#achieveDate').val(new Date().toISOString().split('T')[0]);
    });
    // FETCH ERP DATA
    $('#fetchAchieveBtn').click(function() {

        // let date = $('#achieveDate').val();
        let from_date = $('#fromDate').val();
        let to_date = $('#toDate').val();

        let entityId = $('#entitySelect').val();
        let branchId = $('#branchSelect').val();
        let baseurl = $('#entitySelect option:selected').data('baseurl');
        let erpBranchId = $('#branchSelect option:selected').data('erpbranchid');

        if (!entityId || !branchId || !baseurl || !erpBranchId) {
            toastr.warning('Select Entity & Branch');
            return;
        }

        if (!from_date || !to_date) {
            toastr.warning('Select From & To Date');
            return;
        }

        $('#achieveLoader').removeClass('d-none');
        $('#achieveTableWrapper').addClass('d-none');
        $('#saveAchieveBtn').addClass('d-none');
        $('#erp_total_data').addClass('d-none');

        let totalCollection = 0;
        let totalPre = 0;
        let totalPost = 0;

        $.ajax({
            url: baseurl + 'api/get_achieve_values',
            type: 'POST',
            // data: {
            //     verify_key: 'egcsecret2030datagetapierp',
            //     branch_id: branchId,
            //     date: date
            // },
            data: {
                verify_key: 'egcsecret2030datagetapierp',
                branch_id: erpBranchId,
                from_date: from_date,
                to_date: to_date
                // date: date,
            },

            success: function(res) {

                let rows = '';
                let i = 1;



                res.data.forEach(item => {
                    totalCollection += item.amount;
                    totalPre += item.pre_sale;
                    totalPost += item.post_sale;
                    rows += `
                        <tr>
                            <td>${i++}</td>
                            <td>${item.date}</td>
                            <td>₹ ${item.amount ?  new Intl.NumberFormat('en-IN').format(item.amount) : 0}</td>
                            <td>${item.pre_sale}</td>
                            <td>${item.post_sale}</td>
                        </tr>
                    `;
                });

                $('#achieveTable').html(rows);

                $('#erp_total_data').removeClass('d-none');
                $('#target_amount_erp').text(totalCollection);
                $('#target_pre_erp').text(totalPre);
                $('#target_post_erp').text(totalPost);


                $('#achieveLoader').addClass('d-none');
                $('#achieveTableWrapper').removeClass('d-none');
                $('#saveAchieveBtn').removeClass('d-none');

                // store temp
                window.achievePayload = res.data;
            },

            error: function() {
                $('#achieveLoader').addClass('d-none');
                toastr.error('Failed to fetch ERP data');
                $('#erp_total_data').addClass('d-none');
            }
        });
    });

    // SAVE DATA
    $('#saveAchieveBtn').click(function() {

        let entity = $('#entitySelect').val();
        let branch = $('#branchSelect').val();

        $.ajax({

            url: '/save-achievement',
            type: 'POST',

            data: {
                _token: $("meta[name='csrf-token']").attr("content"),

                entity_id: entity,
                branch_id: branch,

                data: window.achievePayload
            },

            beforeSend: function() {
                $('#saveAchieveBtn').prop('disabled', true);
            },

            success: function(res) {

                if (res.status) {

                    toastr.success('Achievement Saved Successfully');

                    $('#achieveModal').modal('hide');

                } else {

                    toastr.error('Save Failed');
                }
            },

            error: function() {

                toastr.error('Something went wrong');
            },

            complete: function() {

                $('#saveAchieveBtn').prop('disabled', false);
            }
        });
    });
</script>
<script>
    let abortIncentiveController = new AbortController();
    let loaderInterval = null;

    function updateLoader(percent) {

        const circle = document.querySelector('.loader-progress');

        const radius = 60;
        const circumference = 2 * Math.PI * radius;

        const offset = circumference - ((percent / 100) * circumference);

        circle.style.strokeDashoffset = offset;

        $('#loaderPercent').text(percent + '%');




    }
    // OPEN MODAL
    $('#openIncentiveModal').click(function() {
        $('#incentiveModal').modal('show');
        $('#incentiveDate').val(new Date().toISOString().split('T')[0]);
    });
    // FETCH ERP DATA
    $('#fetchIncentiveBtn').click(function() {

        let month_year = $('#month_year').val();
        const verifyKey = 'egcsecret2030datagetapierp';

        let entityId = $('#entityIncentive').val();
        let branchId = $('#branchIncentive').val();
        let baseurl = $('#entityIncentive option:selected').data('baseurl');
        let erpBranchId = $('#branchIncentive option:selected').data('erpbranchid');
        let role_id = $('#roleIncentive option:selected').data('erproleid');

        if (!entityId || !branchId || !baseurl || !erpBranchId || !role_id) {
            toastr.warning('Select Entity & Branch');
            return;
        }

        if (!month_year) {
            toastr.warning('Select Month');
            return;
        }

        $('#incentiveLoader').removeClass('d-none');

        $('#incentiveCards').html('');
        updateLoader(0);

        let progress = 0;

        clearInterval(loaderInterval);

        loaderInterval = setInterval(() => {

            if (progress < 92) {

                progress += Math.floor(Math.random() * 8) + 2;

                if (progress > 92) {
                    progress = 92;
                } else if (progress >= 92 && progress < 98) {

                    progress += 0.4;

                    if (progress > 98) {
                        progress = 98;
                    }
                }

                updateLoader(Math.floor(progress));

                // updateLoader(progress);
            }

        }, 400);

        // abort previous request
        if (abortIncentiveController.signal) {
            abortIncentiveController.abort();
        }

        abortIncentiveController = new AbortController();
        const url = baseurl + `api/get_incentive_by_role?branch_id=${erpBranchId}&verify_key=${verifyKey}&role_id=${role_id}&month_year=${month_year}`;

        fetch(url, {
                headers: {
                    "X-Requested-With": "XMLHttpRequest"
                },
                signal: abortIncentiveController.signal
            })
            .then(res => res.json())
            .then(res => {
                clearInterval(loaderInterval);
                updateLoader(100);

                setTimeout(() => {

                    $('#incentiveLoader').addClass('d-none');

                }, 500);

                let html = '';

                res.data.forEach((item, index) => {

                    let initials = item.staff_name
                        .split(' ')
                        .map(x => x[0])
                        .join('')
                        .substring(0, 2);

                    let total = parseFloat(item.total_award) || 0;

                    let zeroClass = total <= 0 ? 'zero-award' : '';

                    let breakdownHtml = '';

                    Object.entries(item.breakdown).forEach(([key, value]) => {

                        let percent = total > 0 ?
                            ((value / total) * 100) :
                            0;

                        breakdownHtml += `
                            <div class="break-item">

                                <div class="break-top">

                                    <div class="break-label">
                                        ${key}
                                    </div>

                                    <div class="break-value">
                                        ₹ ${new Intl.NumberFormat('en-IN').format(value)}
                                    </div>

                                </div>

                            </div>
                        `;
                    });

                    html += `
                        <div class="accordion-item ${zeroClass}">

                            <h2 class="accordion-header" id="heading${index}">

                                <button class="accordion-button collapsed"
                                    type="button"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#collapse${index}">

                                    <div class="w-100">

                                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

                                            <!-- LEFT -->
                                            <div class="d-flex align-items-center gap-3">

                                                <div class="staff-avatar">
                                                    ${initials}
                                                </div>

                                                <div>

                                                    <div class="staff-name">
                                                        ${item.staff_name}
                                                    </div>

                                                    
                                                </div>

                                            </div>

                                            <!-- RIGHT -->
                                            <div class="d-flex align-items-center gap-3">

                                            

                                                <div class="reward-box">

                                                    <div class="reward-label">
                                                        Total Incentive
                                                    </div>

                                                    <div class="reward-value">
                                                        ₹ ${new Intl.NumberFormat('en-IN').format(total)}
                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </button>

                            </h2>

                            <div id="collapse${index}"
                                class="accordion-collapse collapse"
                                data-bs-parent="#incentiveCards">

                                <div class="accordion-body p-4">

                                    <!-- BREAKDOWN -->
                                    <div class="breakdown-grid">

                                        ${breakdownHtml}

                                    </div>

                                    <!-- FOOTER -->
                                    <div class="incentive-footer">

                                        <div class="d-flex flex-wrap gap-3">

                                            <div class="footer-chip">
                                                Updated :
                                                <strong>
                                                    ${item.last_updated}
                                                </strong>
                                            </div>

                                            <div class="footer-chip">
                                                Next Update :
                                                <strong>
                                                    ${item.next_update}
                                                </strong>
                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>
                    `;
                });

                $('#incentiveCards').html(html);

                html += `
                    <div class="text-end mt-5">
                        <button
                            type="button"
                            class="btn btn-success btn-lg"
                            onclick="saveIncentiveData()">
                            <i class="mdi mdi-content-save-all"></i>
                            Save Incentive Data
                        </button>
                    </div>
                    `;

                    $('#incentiveCards').html(html);

                $('#incentiveLoader').addClass('d-none');

                window.incentivePayload = res.data;
            }).catch(err => {
                clearInterval(loaderInterval);

                $('#incentiveLoader').addClass('d-none');
                if (err.name !== "AbortError") {

                    console.error(err);

                    $('#incentiveCards').html(`
                        <div class="alert alert-danger">
                            Failed to load incentive data
                        </div>
                    `);
                }
            });
    });


    function saveIncentiveData() {

        if (!window.incentivePayload || !window.incentivePayload.length) {
            toastr.warning('No incentive data found');
            return;
        }

        let monthYear = $('#month_year').val();
        let entity_id = $('#entityIncentive').val();
        let erp_branch_id = $('#branchIncentive option:selected').data('erpbranchid');

        $.ajax({
            url: "{{ route('staff.incentive.save') }}",
            type: "POST",
            data: {
                _token: "{{ csrf_token() }}",
                month_year: monthYear,
                entity_id: entity_id,
                erp_branch_id: erp_branch_id,
                incentives: window.incentivePayload
            },

            beforeSend: function () {

                Swal.fire({
                    title: 'Saving...',
                    text: 'Please wait',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

            },

            success: function (response) {

                Swal.close();

                if (response.status) {

                    toastr.success(response.message);

                } else {

                    toastr.error(response.message);
                }
            },

            error: function (xhr) {

                Swal.close();

                toastr.error('Failed to save incentive data');
                console.log(xhr.responseText);
            }
        });
    }
</script>

<script>

</script>
<script>
    let activeTooltipMonth = null;

    $(document).on('mouseenter', '.month-card', function() {

        const tooltip = $(this).find('.month-tooltip');

        if (!tooltip.length) return;

        $('.month-tooltip').hide();

        activeTooltipMonth = tooltip;

        $('body').append(tooltip);

        tooltip.show();

        const card = $(this);
        const offset = card.offset();

        let top = offset.top + card.outerHeight() + 14;
        let left = offset.left + (card.outerWidth() / 2) - (tooltip.outerWidth() / 2);

        const windowWidth = $(window).width();
        const windowHeight = $(window).height();
        const scrollTop = $(window).scrollTop();

        // RIGHT OVERFLOW
        if ((left + tooltip.outerWidth()) > (windowWidth - 20)) {
            left = windowWidth - tooltip.outerWidth() - 20;
        }

        // LEFT OVERFLOW
        if (left < 20) {
            left = 20;
        }

        // BOTTOM OVERFLOW
        if ((top + tooltip.outerHeight()) > (scrollTop + windowHeight - 20)) {

            top = offset.top - tooltip.outerHeight() - 14;
        }

        tooltip.css({
            top: top + 'px',
            left: left + 'px'
        });

    });

    $(document).on('mouseleave', '.month-card', function() {

        const tooltip = activeTooltipMonth;

        setTimeout(() => {

            if (tooltip && !tooltip.is(':hover')) {

                tooltip.hide();

                $(this).append(tooltip);
            }

        }, 150);

    });

    $(document).on('mouseleave', '.month-tooltip', function() {

        $(this).hide();

    });
</script>
<script>
    $('#global_year_picker').datepicker({
        format: 'yyyy',
        viewMode: 'years',
        minViewMode: 'years',
        todayHighlight: true,
        autoclose: true,
        endDate: new Date(),
        orientation: 'bottom'
    })
    // ALTER TABLE `egc_staff` ADD `salary_log_id` INT(11) NULL DEFAULT NULL AFTER `salary_type`;
</script>
<script>
    $('#month_year').datepicker({
        format: 'M-yyyy',
        viewMode: 'months',
        minViewMode: 'months',
        todayHighlight: true,
        autoclose: true,
        endDate: new Date(),
        orientation: 'bottom'
    })
</script>
<script>
    function openWeekTargetModal(encodedData) {

        let data = JSON.parse(
            decodeURIComponent(encodedData)
        );

        let weekHtml = '';

        /*
        |--------------------------------------------------------------------------
        | NO WEEK DATA
        |--------------------------------------------------------------------------
        */

        if (!data.weeks || data.weeks.length === 0) {

            weekHtml = `

                <div class="text-center py-10">

                    <i class="mdi mdi-calendar-remove fs-1 text-muted"></i>

                    <div class="mt-3 text-muted fw-semibold">
                        No Weekly Records Found
                    </div>

                </div>
            `;
        }

        /*
        |--------------------------------------------------------------------------
        | WEEK DATA
        |--------------------------------------------------------------------------
        */
        else {

            data.weeks.forEach(w => {

                weekHtml += `

                    <div class="week-modal-card">

                        <div class="week-modal-head">

                            <div>

                                <div class="week-modal-title">
                                    Week ${w.week}
                                </div>

                                <div class="week-modal-date">
                                    ${w.week_start_date || '-'}
                                    →
                                    ${w.week_end_date || '-'}
                                </div>

                            </div>

                            <div class="week-modal-target">

                                ₹${w.target_amount
                                    ? new Intl.NumberFormat('en-IN')
                                        .format(w.target_amount)
                                    : 0}

                            </div>

                        </div>

                        <div class="week-modal-grid">

                            <div class="week-stat-card">

                                <div class="week-stat-label">
                                    Pre Sale
                                </div>

                                <div class="week-stat-value text-primary">

                                    ${w.pre_sale || 0}

                                </div>

                            </div>

                            <div class="week-stat-card">

                                <div class="week-stat-label">
                                    Post Sale
                                </div>

                                <div class="week-stat-value text-success">

                                    ${w.post_sale || 0}

                                </div>

                            </div>

                        </div>

                    </div>
                `;
            });
        }

        /*
        |--------------------------------------------------------------------------
        | FINAL HTML
        |--------------------------------------------------------------------------
        */

        $('#week_target_data').html(`

            <div class="mb-5">

                <div class="d-flex justify-content-between align-items-center">

                    <div>

                        <div class="fs-2 fw-bold text-dark">

                            ${data.monthName} ${data.displayYear}

                        </div>

                        <div class="text-muted">

                            ${data.quarterName}

                        </div>

                    </div>

                    <div class="text-end">

                        <div class="fw-bold fs-3 text-primary">

                            ₹${new Intl.NumberFormat('en-IN')
                                .format(data.target)}

                        </div>

                        <small class="text-muted">
                            Monthly Target
                        </small>

                    </div>

                </div>

            </div>

            <div class="row mb-5">

                <div class="col-lg-6">

                    <div class="summary-mini-card border-primary">

                        <div class="summary-mini-label">
                            Pre Sale
                        </div>

                        <div class="summary-mini-value text-primary">

                            ${data.pre_sale || 0}

                        </div>

                    </div>

                </div>

                <div class="col-lg-6">

                    <div class="summary-mini-card border-success">

                        <div class="summary-mini-label">
                            Post Sale
                        </div>

                        <div class="summary-mini-value text-success">

                            ${data.post_sale || 0}

                        </div>

                    </div>

                </div>

            </div>

            ${weekHtml}

        `);

        $('#weekTargetModal').modal('show');
    }
</script>

<script>
$('#openOldCollectionModal').click(function () {
    $('#updateCollectionModal').modal('show');
    loadCollectionTable();
});

function refreshUpdateCollection(){

    $('#entityCollectSelect').val('').change();
    $('#branchCollectSelect').val('').change();
    $('#updateCollectionvalue').prop('readonly', false);
    $('#updateCollectionvalue').val(0);
    $('#savecollectionBtn').prop('disabled', false);

    loadCollectionTable();
}

function changeCollectionEntity() {
    let entity_id = $('#entityCollectSelect').val();
    let branchDropdown = $('#branchCollectSelect');
    branchDropdown.html(
        '<option value="">Select Branch</option>'
    );
    if (!entity_id) {
        return;
    }
    $('#collectionLoader').removeClass('d-none');

    $.ajax({
        url: "{{ route('entity_branch_dropdown_list') }}",
        type: "GET",
        data: {
            entity_id: entity_id
        },
        success: function(response) {
            if (response.status === 200) {
                response.data.forEach(function(item) {
                    branchDropdown.append(`
                        <option value="${item.sno}">
                            ${item.branch_name}
                        </option>
                    `);
                });
                loadCollectionTable();
            }
        },
        complete: function() {
            $('#collectionLoader').addClass('d-none');
        }
    });
}


function loadCollectionAmount() {

    let branch_id = $('#branchCollectSelect').val();
    let entity_id = $('#entityCollectSelect').val();
    let month_year = $('#updateCollectionDate').val();
    if (!branch_id || !entity_id) {
        return;
    }

    $('#updateCollectionvalue').prop('readonly', false);
    $('#savecollectionBtn').prop('disabled', false);

    $('#collectionLoader').removeClass('d-none');

    $.ajax({
        url: "/get-collection-data",
        type: "GET",
        data: {
            branch_id,
            entity_id,
            month_year
        },
        success: function(res) {
            if (res.collection_amount > 0 ){
                $('#updateCollectionvalue').val(
                    res.collection_amount || 0
                );
                $('#updateCollectionvalue').prop('readonly', true);
                $('#savecollectionBtn').prop('disabled', true);
            }else{
                $('#updateCollectionvalue').prop('readonly', false);
                $('#updateCollectionvalue').val(0);
                $('#savecollectionBtn').prop('disabled', false);
            }
            
            loadCollectionTable();
        },

        complete: function() {
            $('#collectionLoader').addClass('d-none');
        }
    });
}

$('#savecollectionBtn').click(function () {

    let btn = $(this);
    btn.prop('disabled', true);
    btn.find('.btn-text').addClass('d-none');
    btn.find('.spinner-border').removeClass('d-none');

    $.ajax({
        url: "/update-collection",
        type: "POST",
        data: {
            _token: "{{ csrf_token() }}",
            entity_id: $('#entityCollectSelect').val(),
            branch_id: $('#branchCollectSelect').val(),
            month_year: $('#updateCollectionDate').val(),
            amount: $('#updateCollectionvalue').val()
        },
        success: function(res) {
            if (res.status) {
                toastr.success(res.message);
                loadCollectionTable();
                loadCollectionAmount();
            } else {
                toastr.error(res.message);
            }
        },

        error: function() {
            toastr.error('Something went wrong');
        },

        complete: function() {
            btn.prop('disabled', false);
            btn.find('.btn-text').removeClass('d-none');
            btn.find('.spinner-border').addClass('d-none');
        }
    });
});

// function loadCollectionTable() {
//     let entity_id = $('#entityCollectSelect').val();
//     let branch_id = $('#branchCollectSelect').val();
//     $('#collectionLoader').removeClass('d-none');

//     $.ajax({
//         url: "/get-collection-table",
//         type: "GET",
//         data: {
//             entity_id,
//             branch_id
//         },
//         success: function(res) {

//             let html = '';

//             if (res.data.length > 0) {
//                 res.data.forEach((row) => {

//                     html += `
//                     <tr>

//                         <td class="sticky-left fw-bold bg-white">
//                             ${row.year}
//                             <div> ${row.entity_name || '-'}</div>
//                         </td>
//                         <td>${currencyFormat(row.apr)}</td>
//                         <td>${currencyFormat(row.may)}</td>
//                         <td>${currencyFormat(row.jun)}</td>
//                         <td>${currencyFormat(row.jul)}</td>
//                         <td>${currencyFormat(row.aug)}</td>
//                         <td>${currencyFormat(row.sep)}</td>
//                         <td>${currencyFormat(row.oct)}</td>
//                         <td>${currencyFormat(row.nov)}</td>
//                         <td>${currencyFormat(row.dece)}</td>
//                         <td>${currencyFormat(row.jan)}</td>
//                         <td>${currencyFormat(row.feb)}</td>
//                         <td>${currencyFormat(row.mar)}</td>

//                         <td class="sticky-right fw-bold bg-light-success">
//                             ${currencyFormat(row.total)}
//                         </td>

//                     </tr>
//                     `;
//                 });

//             } else {

//                 html = `
//                     <tr>
//                         <td colspan="15" class="text-center py-5">
//                             No Data Found
//                         </td>
//                     </tr>
//                 `;
//             }

//             $('#collectionTableBody').html(html);
//         },

//         complete: function() {

//             $('#collectionLoader').addClass('d-none');
//         }
//     });
// }


function loadCollectionTable() {

    let entity_id = $('#entityCollectSelect').val();
    let branch_id = $('#branchCollectSelect').val();

    $('#collectionLoader').removeClass('d-none');

    $.ajax({
        url: "/get-collection-table",
        type: "GET",
        data: {
            entity_id,
            branch_id
        },

        success: function(res) {
            let headHtml = `
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary attendance-header">
                    <th class="min-w-150px text-center sticky-col-left">
                        Month / Year
                    </th>
            `;

            res.branches.forEach(branch => {

                headHtml += `
                    <th class="min-w-125px text-center">
                        <div class="fw-bold text-white">
                            ${branch.branch_name}
                        </div>

                        <div class="fs-8 text-warning">
                            ${branch.entity_name}
                        </div>
                    </th>
                `;
            });

            headHtml += `
                    <th class="min-w-125px text-center bg-warning text-black sticky-col-right">
                        Total
                    </th>
                </tr>
            `;
            $('#collectionTableHead').html(headHtml);

            /*
            |--------------------------------------------------------------------------
            | BODY
            |--------------------------------------------------------------------------
            */

            let bodyHtml = '';

            if (res.data.length > 0) {
                res.data.forEach(row => {
                    bodyHtml += `
                        <tr>
                            <td class="sticky-col-left fw-bold bg-white">
                                ${row.month_year}
                            </td>
                    `;

                    res.branches.forEach(branch => {
                        let amount = row.branches[branch.sno] || 0;
                        bodyHtml += `
                            <td class="text-end">
                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(amount || 0)}">₹${currencyFormat(amount)}</span>
                            </td>
                        `;
                    });

                    bodyHtml += `
                            <td class="sticky-col-right fw-bold bg-light-warning text-end">
                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="₹${new Intl.NumberFormat('en-IN').format(row.total || 0)}">₹${currencyFormat(row.total)}</span>
                            </td>
                        </tr>
                    `;
                });

            } else {
                bodyHtml = `
                    <tr>
                        <td colspan="100"
                            class="text-center py-10">
                            No Data Found
                        </td>
                    </tr>
                `;
            }

            $('#collectionTableBody').html(bodyHtml);
             $('[data-bs-toggle="tooltip"]').tooltip();
        },
        complete: function() {
            $('#collectionLoader').addClass('d-none');
        }
    });
}

function currencyFormat(value) {

        value = Number(value || 0);

        if (value >= 10000000) {

            return (Math.floor((value / 10000000) * 100) / 100).toFixed(2) + ' Cr';
        }

        if (value >= 100000) {

            return (Math.floor((value / 100000) * 100) / 100).toFixed(2) + ' L';
        }

        return new Intl.NumberFormat('en-IN', {
            maximumFractionDigits: 0
        }).format(value);
    }
</script>
@endsection