@extends('layouts/layoutMaster')
@section('title', 'Documents')
@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection
@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection
@section('page-script')
@vite(['resources/assets/js/productivity-pending-tools.js'])
@endsection
@section('content')
@php($module='documents')
@php($title='Documents')
@php($icon='mdi-file-document-multiple-outline')
@include('content.productivity.partials.pending_tool', ['module'=>$module,'title'=>$title,'icon'=>$icon,'subtitle'=>'Controlled personal and official documents with versions and upload progress.'])
@endsection
