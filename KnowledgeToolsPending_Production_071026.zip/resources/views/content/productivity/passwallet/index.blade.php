@extends('layouts/layoutMaster')
@section('title', 'PassWallet')
@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection
@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection
@section('page-script')
@vite(['resources/assets/js/productivity-pending-tools.js'])
@endsection
@section('content')
@php($module='passwallet')
@php($title='PassWallet')
@php($icon='mdi-shield-key-outline')
@include('content.productivity.partials.pending_tool', ['module'=>$module,'title'=>$title,'icon'=>$icon,'subtitle'=>'Protected credentials with step-up verification, rotation and governed access.'])
@endsection
