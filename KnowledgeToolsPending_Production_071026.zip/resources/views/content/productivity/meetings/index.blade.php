@extends('layouts/layoutMaster')
@section('title', 'Meetings')
@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection
@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection
@section('page-script')
@vite(['resources/assets/js/productivity-pending-tools.js'])
@endsection
@section('content')
@php($module='meetings')
@php($title='Meetings')
@php($icon='mdi-calendar-account-outline')
@include('content.productivity.partials.pending_tool', ['module'=>$module,'title'=>$title,'icon'=>$icon,'subtitle'=>'Meetings, participants, RSVP and a responsive calendar.'])
@endsection
