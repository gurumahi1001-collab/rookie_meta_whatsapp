@extends('layouts/layoutMaster')
@section('title', 'Sticky Notes')
@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection
@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection
@section('page-script')
@vite(['resources/assets/js/productivity-pending-tools.js'])
@endsection
@section('content')
@php($module='notes')
@php($title='Sticky Notes')
@php($icon='mdi-note-multiple-outline')
@include('content.productivity.partials.pending_tool', ['module'=>$module,'title'=>$title,'icon'=>$icon,'subtitle'=>'Personal and shared notes with reminders, pinning and archive actions.'])
@endsection
