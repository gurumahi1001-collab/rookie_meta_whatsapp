@extends('layouts/layoutMaster')
@section('title', 'Tasks')
@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection
@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection
@section('page-script')
@vite(['resources/assets/js/productivity-pending-tools.js'])
@endsection
@section('content')
@php($module='tasks')
@php($title='Tasks')
@php($icon='mdi-format-list-checks')
@include('content.productivity.partials.pending_tool', ['module'=>$module,'title'=>$title,'icon'=>$icon,'subtitle'=>'Kanban work tracking with priorities, assignees and verification.'])
@endsection
