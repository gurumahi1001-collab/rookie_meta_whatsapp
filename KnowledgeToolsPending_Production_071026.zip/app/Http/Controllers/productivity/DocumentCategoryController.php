<?php

namespace App\Http\Controllers\productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DocumentCategoryController extends ProductivityBaseController
{
    private function canManage(Request $request): bool
    {
        return !$this->access->isAuditor($request) && ($this->access->isGroupAdmin($request) || $this->access->isCompanyAdmin($request));
    }

    public function data(Request $request)
    {
        $manager = $this->canManage($request);
        $q = DB::table('egc_tool_document_categories')->whereNull('deleted_at')->when(!$manager, fn($x) => $x->where('status', 0))->orderBy('category_name');
        if (!$manager && !$this->access->isGroupAdmin($request)) {
            $q->where(function($x){ $x->whereNull('company_id')->orWhere('company_id', $this->cid()); });
        } else {
            $this->applyScope($q, $request, 'company_id');
        }
        return $this->ok(['rows' => $q->get()]);
    }

    public function store(Request $request)
    {
        abort_unless($this->canManage($request), 403);
        $data = $request->validate(['company_id'=>['nullable','integer'],'category_name'=>['required','string','max:100'],'color'=>['nullable','string','max:20']]);
        $companyId = $this->access->isGroupAdmin($request) && filled($data['company_id'] ?? null) ? (int)$data['company_id'] : $this->cid();
        $exists = DB::table('egc_tool_document_categories')->whereNull('deleted_at')->where('company_id',$companyId)->whereRaw('LOWER(category_name)=LOWER(?)',[$data['category_name']])->exists();
        abort_if($exists,409,'A document category with this name already exists.');
        $id = DB::table('egc_tool_document_categories')->insertGetId(['company_id'=>$companyId,'category_name'=>trim($data['category_name']),'color'=>$data['color']??'#4A3E8E','status'=>0,'created_by'=>$this->uid(),'updated_by'=>$this->uid(),'created_at'=>now(),'updated_at'=>now()]);
        return $this->ok(['id'=>$id],'Category created.');
    }

    public function update(Request $request,int $id)
    {
        abort_unless($this->canManage($request),403);
        $cat=DB::table('egc_tool_document_categories')->where('sno',$id)->whereNull('deleted_at')->first(); abort_unless($cat,404);
        if(!$this->access->isGroupAdmin($request)) abort_unless($cat->company_id===null || (int)$cat->company_id===(int)$this->cid(),403);
        $data=$request->validate(['category_name'=>['required','string','max:100'],'color'=>['nullable','string','max:20']]);
        $exists=DB::table('egc_tool_document_categories')->whereNull('deleted_at')->where('sno','!=',$id)->where('company_id',$cat->company_id)->whereRaw('LOWER(category_name)=LOWER(?)',[$data['category_name']])->exists();
        abort_if($exists,409,'A document category with this name already exists.');
        DB::table('egc_tool_document_categories')->where('sno',$id)->update(['category_name'=>trim($data['category_name']),'color'=>$data['color']??$cat->color,'updated_by'=>$this->uid(),'updated_at'=>now()]);
        return $this->ok(null,'Category updated.');
    }

    public function status(Request $request,int $id)
    {
        abort_unless($this->canManage($request),403);
        $cat=DB::table('egc_tool_document_categories')->where('sno',$id)->whereNull('deleted_at')->first(); abort_unless($cat,404);
        if(!$this->access->isGroupAdmin($request)) abort_unless($cat->company_id===null || (int)$cat->company_id===(int)$this->cid(),403);
        $status=(int)$request->input('status',((int)$cat->status===0?1:0)); abort_unless(in_array($status,[0,1],true),422);
        DB::table('egc_tool_document_categories')->where('sno',$id)->update(['status'=>$status,'updated_by'=>$this->uid(),'updated_at'=>now()]);
        return $this->ok(['status'=>$status],$status===0?'Category activated.':'Category deactivated.');
    }

    public function delete(Request $request,int $id)
    {
        abort_unless($this->canManage($request),403);
        $cat=DB::table('egc_tool_document_categories')->where('sno',$id)->whereNull('deleted_at')->first(); abort_unless($cat,404);
        if(!$this->access->isGroupAdmin($request)) abort_unless($cat->company_id===null || (int)$cat->company_id===(int)$this->cid(),403);
        $used=DB::table('egc_tool_documents')->where('category',$cat->category_name)->whereNull('deleted_at')->where('status',0)->exists();
        abort_if($used,409,'This category is still used by active documents. Move those documents before deleting it.');
        DB::table('egc_tool_document_categories')->where('sno',$id)->update(['status'=>1,'deleted_at'=>now(),'updated_by'=>$this->uid(),'updated_at'=>now()]);
        return $this->ok(null,'Category deleted.');
    }
}
