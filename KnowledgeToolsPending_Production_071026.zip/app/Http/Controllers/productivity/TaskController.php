<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TaskController extends ProductivityBaseController
{
    public function index()
    {
        return view('content.productivity.tasks.index');
    }

    public function data(Request $request)
    {
        $query = Task::query()->whereNull('deleted_at');
        $this->applyReadableScope($query, $request, 'task');
        $uid = $this->uid();
        $query->where(function ($q) use ($uid) {
            $q->where('owner_user_id', $uid)
                ->orWhere('supervisor_user_id', $uid)
                ->orWhere('visibility', 'Group')
                ->orWhere(function($company) { $company->where('visibility','Company')->where('company_id',$this->cid()); })
                ->orWhereExists(function ($share) use ($uid) {
                    $share->selectRaw('1')->from('egc_tool_share_grants as sg')
                        ->where('sg.resource_type', 'task')->whereColumn('sg.resource_id', 'egc_tool_tasks.sno')
                        ->where('sg.status', 'active')
                        ->where(function ($g) use ($uid) {
                            $g->where(fn ($u) => $u->where('sg.grantee_type', 'user')->where('sg.grantee_id', (string) $uid))
                                ->orWhere(fn ($r) => $r->where('sg.grantee_type', 'role')->where('sg.grantee_id', $this->access->role()))
                                ->orWhere(fn ($c) => $c->where('sg.grantee_type', 'company')->where('sg.grantee_id', (string) ($this->cid() ?? -1)))
                                ->orWhere(fn ($g2) => $g2->where('sg.grantee_type', 'group')->where('sg.grantee_id', '0'));
                        })
                        ->where(fn ($e) => $e->whereNull('sg.expires_at')->orWhere('sg.expires_at', '>=', now()));
                })
                ->orWhereExists(function ($s) use ($uid) {
                    $s->selectRaw('1')->from('egc_tool_task_assignees as ta')->whereColumn('ta.task_id', 'egc_tool_tasks.sno')->where('ta.user_id', $uid);
                });
        });
        foreach (['priority', 'status', 'category'] as $filter) {
            if ($request->filled($filter)) $query->where($filter, $request->input($filter));
        }
        if ($request->filled('search')) {
            $s = trim((string) $request->input('search'));
            $query->where(fn ($q) => $q->where('title', 'like', "%{$s}%")->orWhere('description', 'like', "%{$s}%"));
        }
        return $this->ok(['rows' => $query->orderByRaw("FIELD(priority,'Urgent','High','Medium','Low')")->orderBy('due_at')->paginate(min(max((int) $request->get('per_page', 30), 10), 100))]);
    }

    public function show(int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canReadResource('task', $id, $task->owner_user_id, $task->company_id, $task->visibility), 403);
        return $this->ok([
            'task' => tap($task, fn($x) => $x->audience = $this->audienceCurrent('task', $id)),
            'assignees' => DB::table('egc_tool_task_assignees')->where('task_id', $id)->get(),
            'comments' => DB::table('egc_tool_task_comments')->where('task_id', $id)->orderBy('created_at')->get(),
        ]);
    }

    public function store(Request $request)
    {
        abort_unless($this->access->canWrite(), 403);
        $data = $this->validateData($request);
        $audienceMode = $data['audience_mode'] ?? null;
        unset($data['audience_mode'], $data['audience_company_ids'], $data['audience_entity_ids'], $data['audience_role_ids'], $data['audience_staff_ids'], $data['audience_clear']);
        if ($audienceMode) $data['visibility'] = 'Private';
        $this->assertCompany($data['company_id'] ?? null);
        $task = Task::create(array_merge($data, [
            'company_id' => $data['company_id'] ?? $this->cid(),
            'owner_user_id' => $this->uid(),
            'created_by' => $this->uid(),
            'updated_by' => $this->uid(),
        ]));
        $this->sync($task, $data['assignee_ids'] ?? []);
        $this->syncSupervisorGrant($task);
        $this->syncAudience($request, 'task', (int)$task->sno, (int)$task->owner_user_id);
        $this->audit($request, 'Tasks', 'created', 'task', $task->sno, null, $task->toArray());
        return $this->ok($task, 'Task created.');
    }

    public function update(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canManageResource('task', $id, $task->owner_user_id), 403);
        $data = $this->validateData($request);
        $audienceMode = $data['audience_mode'] ?? null;
        unset($data['audience_mode'], $data['audience_company_ids'], $data['audience_entity_ids'], $data['audience_role_ids'], $data['audience_staff_ids'], $data['audience_clear']);
        if ($audienceMode) $data['visibility'] = 'Private';
        $this->assertCompany($data['company_id'] ?? $task->company_id);
        $before = $task->toArray();
        $assignees = $data['assignee_ids'] ?? [];
        unset($data['assignee_ids']);
        $task->update(array_merge($data, ['updated_by' => $this->uid()]));
        $this->sync($task, $assignees);
        $this->syncSupervisorGrant($task);
        $this->syncAudience($request, 'task', $id, (int)$task->owner_user_id);
        $this->audit($request, 'Tasks', 'updated', 'task', $id, $before, $task->fresh()->toArray());
        return $this->ok($task->fresh(), 'Task updated.');
    }

    public function status(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canManageResource('task', $id, $task->owner_user_id), 403);
        $data = $request->validate(['status' => ['required', 'in:To Do,In Progress,On Hold,Pending Verification,Completed']]);
        $task->update(['status' => $data['status'], 'updated_by' => $this->uid()]);
        return $this->ok($task->fresh());
    }

    public function comment(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canReadResource('task', $id, $task->owner_user_id, $task->company_id, $task->visibility), 403);
        $data = $request->validate(['comment_text' => ['required', 'string', 'max:5000']]);
        $commentId = DB::table('egc_tool_task_comments')->insertGetId(['task_id' => $id, 'user_id' => $this->uid(), 'comment_text' => $data['comment_text'], 'created_at' => now()]);
        return $this->ok(['id' => $commentId], 'Comment added.');
    }

    public function verify(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($task->status === 'Pending Verification', 422, 'Task is not pending verification.');
        abort_unless($task->supervisor_user_id === $this->uid() || $this->access->isCompanyAdmin(), 403);
        $task->update(['status' => 'Completed', 'updated_by' => $this->uid()]);
        return $this->ok($task->fresh(), 'Task verified and completed.');
    }

    public function delete(Request $request, int $id)
    {
        $task = Task::findOrFail($id);
        abort_unless($this->access->canManageResource('task', $id, $task->owner_user_id), 403);
        $task->update(['deleted_at' => now(), 'updated_by' => $this->uid()]);
        return $this->ok(null, 'Task deleted.');
    }

    private function validateData(Request $request): array
    {
        return $request->validate([
            'company_id' => ['nullable', 'integer', 'min:1'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'title' => ['required', 'string', 'max:220'],
            'category' => ['required', 'string', 'max:80'],
            'priority' => ['required', 'in:Low,Medium,High,Urgent'],
            'due_at' => ['nullable', 'date'],
            'status' => ['nullable', 'in:To Do,In Progress,On Hold,Pending Verification,Completed'],
            'description' => ['nullable', 'string', 'max:10000'],
            'supervisor_user_id' => ['nullable', 'integer', 'exists:egc_staff,sno'],
            'verification_required' => ['nullable', 'boolean'],
            'assignee_ids' => ['nullable', 'array', 'max:500'],
            'assignee_ids.*' => ['integer', 'distinct', 'exists:egc_staff,sno'],
            'audience_mode' => ['nullable', 'in:company,entity,role,staff'],
            'audience_company_ids' => ['nullable', 'array'],
            'audience_entity_ids' => ['nullable', 'array'],
            'audience_role_ids' => ['nullable', 'array'],
            'audience_staff_ids' => ['nullable', 'array'],
            'audience_clear' => ['nullable', 'boolean'],
        ]);
    }

    private function assertCompany(?int $companyId): void
    {
        if ($companyId === null || $this->access->isGroupAdmin()) return;
        abort_unless((int) $companyId === (int) $this->cid(), 403, 'Cross-company task access is not permitted.');
    }

    private function syncSupervisorGrant(Task $task): void
    {
        DB::table('egc_tool_share_grants')->where('resource_type','task')->where('resource_id',$task->sno)->where('metadata_json','like','%"source":"task_supervisor"%')->update(['status'=>'revoked','revoked_by'=>$this->uid(),'revoked_at'=>now(),'updated_at'=>now()]);
        if ((int)($task->supervisor_user_id ?? 0) > 0 && (int)$task->supervisor_user_id !== $this->uid()) {
            DB::table('egc_tool_share_grants')->insert([
                'resource_type'=>'task','resource_id'=>$task->sno,'owner_user_id'=>$task->owner_user_id,'grantee_type'=>'user','grantee_id'=>(string)$task->supervisor_user_id,
                'permission'=>'Manage','status'=>'active','requested_by'=>$this->uid(),'approved_by'=>$this->uid(),'approval_required'=>0,'approved_at'=>now(),
                'metadata_json'=>json_encode(['source'=>'task_supervisor'],JSON_UNESCAPED_UNICODE),'created_at'=>now(),'updated_at'=>now(),
            ]);
        }
    }

    private function sync(Task $task, array $ids): void
    {
        DB::transaction(function () use ($task, $ids) {
            DB::table('egc_tool_task_assignees')->where('task_id', $task->sno)->delete();
            DB::table('egc_tool_share_grants')->where('resource_type','task')->where('resource_id',$task->sno)->where('metadata_json','like','%"source":"task_assignee"%')->update(['status'=>'revoked','revoked_by'=>$this->uid(),'revoked_at'=>now(),'updated_at'=>now()]);
            foreach ($this->ids($ids) as $userId) {
                DB::table('egc_tool_task_assignees')->insert(['task_id' => $task->sno, 'user_id' => $userId, 'created_at' => now()]);
                if ($userId !== $this->uid()) {
                    DB::table('egc_tool_share_grants')->insert([
                        'resource_type'=>'task','resource_id'=>$task->sno,'owner_user_id'=>$task->owner_user_id,
                        'grantee_type'=>'user','grantee_id'=>(string)$userId,'permission'=>'View','status'=>'active',
                        'requested_by'=>$this->uid(),'approved_by'=>$this->uid(),'approval_required'=>0,'approved_at'=>now(),
                        'metadata_json'=>json_encode(['source'=>'task_assignee'],JSON_UNESCAPED_UNICODE),'created_at'=>now(),'updated_at'=>now(),
                    ]);
                }
            }
        });
    }
}
