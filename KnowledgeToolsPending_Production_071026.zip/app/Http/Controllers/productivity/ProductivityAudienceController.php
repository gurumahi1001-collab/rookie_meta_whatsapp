<?php

namespace App\Http\Controllers\productivity;

use App\Services\Productivity\ProductivityAudienceService;
use Illuminate\Http\Request;

class ProductivityAudienceController extends ProductivityBaseController
{
    public function __construct(
        \App\Services\Productivity\ProductivityAccessService $access,
        private readonly ProductivityAudienceService $audience
    ) {
        parent::__construct($access);
    }

    public function options(Request $request)
    {
        abort_unless($this->access->canWrite($request), 403);
        return $this->ok($this->audience->options($request));
    }


}
