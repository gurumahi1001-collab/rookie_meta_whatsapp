<?php

namespace App\Services\Productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductivityAccessService
{
    private function currentUser(?Request $request = null)
    {
        if ($request && $request->user()) {
            return $request->user();
        }
        return auth()->user();
    }

    public function userId(?Request $request = null): int
    {
        $user = $this->currentUser($request);
        if (!$user) return 0;
        $id = (int) ($user->user_id ?? 0);
        if ($id > 0) return $id;
        try {
            $staff = $user->relationLoaded('staff') ? $user->staff : $user->staff()->first();
            if ($staff && (int) ($staff->sno ?? 0) > 0) return (int) $staff->sno;
        } catch (\Throwable $e) {}
        return (int) ($user->id ?? 0);
    }

    public function companyId(?Request $request = null): ?int
    {
        $user = $this->currentUser($request);
        if (!$user) return null;
        foreach ([(int)($user->company_id ?? 0)] as $id) {
            if ($id >= 0 && (($user->company_id ?? null) !== null && ($user->company_id ?? '') !== '')) return $id;
        }
        try {
            $staff = $user->relationLoaded('staff') ? $user->staff : $user->staff()->first();
            if ($staff && isset($staff->company_id) && $staff->company_id !== '') return (int) $staff->company_id;
        } catch (\Throwable $e) {}
        if (isset($user->company) && is_numeric($user->company)) return (int) $user->company;
        return null;
    }

    public function roleId(?Request $request = null): int
    {
        $user = $this->currentUser($request);
        return (int) ($user->role_id ?? 0);
    }

    public function role(?Request $request = null): string
    {
        $user = $this->currentUser($request);
        if (!$user) return 'Staff';
        $roleId = (int) ($user->role_id ?? 0);
        if ($roleId > 0) {
            $role = DB::table('egc_user_role')->where('sno', $roleId)->first();
            if ($role) return trim((string) $role->role_name);
        }
        foreach (['role_name','role'] as $key) {
            if (!empty($user->{$key})) return trim((string) $user->{$key});
        }
        return 'Staff';
    }

    public function normalizedRole(?Request $request = null): string
    {
        return strtolower(preg_replace('/[^a-z0-9]+/i', ' ', trim($this->role($request))));
    }

    public function isSuper(?Request $request = null): bool
    {
        $name = $this->normalizedRole($request);
        return $this->roleId($request) === 1 || in_array($name, [
            'super admin', 'superadmin', 'ceo', 'chief executive officer'
        ], true);
    }

    public function isGroupAdmin(?Request $request = null): bool
    {
        return $this->isSuper($request) || $this->normalizedRole($request) === 'group admin';
    }

    public function isCompanyAdmin(?Request $request = null): bool
    {
        return $this->isSuper($request) || in_array($this->normalizedRole($request), ['group admin','company admin'], true);
    }

    public function isModuleManager(?Request $request = null): bool { return $this->normalizedRole($request) === 'module manager'; }
    public function isAuditor(?Request $request = null): bool { return $this->normalizedRole($request) === 'auditor'; }
    public function canWrite(?Request $request = null): bool { return !$this->isAuditor($request); }
    public function canExport(?Request $request = null): bool { return $this->isGroupAdmin($request) || $this->isCompanyAdmin($request) || $this->isAuditor($request); }

    public function companyScope(Request $request, string $column = 'company_id'): array
    {
        if ($this->isGroupAdmin($request) || $this->isAuditor($request)) {
            $selected = $request->input('company_id');
            if ($selected !== null && $selected !== '' && $selected !== 'all') return [(int) $selected];
            return [];
        }
        $companyId = $this->companyId($request);
        return $companyId !== null ? [$companyId] : [];
    }

    public function applyCompanyScope($query, Request $request, string $column = 'company_id'): void
    {
        $scope = $this->companyScope($request, $column);
        if ($scope) {
            $query->whereIn($column, $scope);
        } elseif (!$this->isGroupAdmin($request) && !$this->isAuditor($request) && $this->companyId($request) === null) {
            $query->whereRaw('1=0');
        }
    }

    public function canReadResource(string $resourceType, int $resourceId, ?int $ownerId = null, ?int $companyId = null, ?string $visibility = null, ?Request $request = null): bool
    {
        $uid = $this->userId($request);
        if ($this->isSuper($request) || $this->isAuditor($request)) return true;
        if ($uid <= 0) return false;
        if ($ownerId !== null && (int) $ownerId === $uid) return true;
        if ($visibility === 'Group') return true;
        if ($visibility === 'Company' && $companyId !== null && (int) $companyId === (int) $this->companyId($request)) return true;
        if (DB::table('egc_tool_share_grants')
            ->where('resource_type', $resourceType)
            ->where('resource_id', $resourceId)
            ->where('status', 'active')
            ->where('metadata_json', 'like', '%"source":"productivity_audience"%')
            ->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at','>=',now()))
            ->get(['metadata_json'])
            ->contains(function ($row) use ($uid, $companyId, $request) {
                $meta = json_decode((string)$row->metadata_json, true) ?: [];
                $entityId = (int) ($request->user()?->entity_d ?? 0);
                $roleId = (int) ($request->user()?->role_id ?? 0);
                if (!$entityId || !$roleId) {
                    $staff = DB::table('egc_staff')->where('sno',$uid)->first(['entity_id','role_id']);
                    $entityId = $entityId ?: (int)($staff->entity_id ?? 0);
                    $roleId = $roleId ?: (int)($staff->role_id ?? 0);
                }
                $audience = app(\App\Services\Productivity\ProductivityAudienceService::class);
                return $audience->matches($meta, ['uid'=>$uid,'company_id'=>$companyId,'entity_id'=>$entityId,'role_id'=>$roleId]);
            })) return true;
        return DB::table('egc_tool_share_grants')
            ->where('resource_type', $resourceType)->where('resource_id', $resourceId)->where('status', 'active')
            ->where(function ($meta) { $meta->whereNull('metadata_json')->orWhere('metadata_json', 'not like', '%"source":"productivity_audience"%'); })
            ->where(function ($q) use ($uid, $request) {
                $companyId = $this->companyId($request); $role = $this->role($request);
                $q->where(fn($x) => $x->where('grantee_type','user')->where('grantee_id',(string)$uid))
                  ->orWhere(fn($x) => $x->where('grantee_type','role')->where('grantee_id',$role))
                  ->orWhere(fn($x) => $x->where('grantee_type','group')->where('grantee_id','0'))
                  ->when($companyId !== null, fn($x) => $x->orWhere(fn($y) => $y->where('grantee_type','company')->where('grantee_id',(string)$companyId)));
            })->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at','>=',now()))->exists();
    }

    /**
     * Apply the same per-resource visibility rules as applyReadableScope(),
     * but to a query builder. This is intentionally additive so the existing
     * boolean resource check remains backwards-compatible for BookMarks and
     * other Productivity tools.
     */
    public function applyReadableQueryScope(
        $query,
        string $resourceType,
        string $resourceIdColumn,
        ?string $ownerColumn = null,
        ?string $companyColumn = null,
        ?string $visibilityColumn = null,
        ?Request $request = null
    ): void {
        if ($this->isSuper($request) || $this->isAuditor($request)) {
            return;
        }

        $uid = $this->userId($request);
        if ($uid <= 0) {
            $query->whereRaw('1=0');
            return;
        }

        $companyId = $this->companyId($request);
        $role = $this->role($request);

        $query->where(function ($scope) use (
            $resourceType,
            $resourceIdColumn,
            $ownerColumn,
            $companyColumn,
            $visibilityColumn,
            $uid,
            $companyId,
            $role
        ) {
            if ($ownerColumn) {
                $scope->orWhere($ownerColumn, $uid);
            }

            if ($visibilityColumn) {
                $scope->orWhere($visibilityColumn, 'Group');
            }

            if ($visibilityColumn && $companyColumn && $companyId !== null) {
                $scope->orWhere(function ($company) use ($visibilityColumn, $companyColumn, $companyId) {
                    $company->where($visibilityColumn, 'Company')
                        ->where($companyColumn, $companyId);
                });
            }

            $scope->orWhereExists(function ($grant) use (
                $resourceType,
                $resourceIdColumn,
                $uid,
                $companyId,
                $role
            ) {
                $grant->selectRaw('1')
                    ->from('egc_tool_share_grants as g')
                    ->where('g.resource_type', $resourceType)
                    ->whereColumn('g.resource_id', $resourceIdColumn)
                    ->where('g.status', 'active')
                    ->where(function ($meta) { $meta->whereNull('g.metadata_json')->orWhere('g.metadata_json', 'not like', '%"source":"productivity_audience"%'); })
                    ->where(function ($grantee) use ($uid, $companyId, $role) {
                        $grantee->where(function ($x) use ($uid) {
                            $x->where('g.grantee_type', 'user')
                                ->where('g.grantee_id', (string) $uid);
                        })
                        ->orWhere(function ($x) use ($role) {
                            $x->where('g.grantee_type', 'role')
                                ->where('g.grantee_id', $role);
                        })
                        ->orWhere(function ($x) {
                            $x->where('g.grantee_type', 'group')
                                ->where('g.grantee_id', '0');
                        })
                        ->when($companyId !== null, function ($x) use ($companyId) {
                            $x->orWhere(function ($y) use ($companyId) {
                                $y->where('g.grantee_type', 'company')
                                    ->where('g.grantee_id', (string) $companyId);
                            });
                        });
                    })
                    ->where(function ($expiry) {
                        $expiry->whereNull('g.expires_at')
                            ->orWhere('g.expires_at', '>=', now());
                    });
            });

            // Knowledge-style dynamic audience metadata. This is additive:
            // existing user/role/company/group grants continue to work.
            $scope->orWhereExists(function ($audience) use ($resourceType, $resourceIdColumn, $uid, $companyId) {
                $audience->selectRaw('1')
                    ->from('egc_tool_share_grants as ag')
                    ->where('ag.resource_type', $resourceType)
                    ->whereColumn('ag.resource_id', $resourceIdColumn)
                    ->where('ag.status', 'active')
                    ->where('ag.metadata_json', 'like', '%"source":"productivity_audience"%')
                    ->where(function ($expiry) {
                        $expiry->whereNull('ag.expires_at')->orWhere('ag.expires_at', '>=', now());
                    })
                    ->where(function ($meta) use ($uid, $companyId) {
                        $entityId = (int) (auth()->user()->entity_d ?? 0);
                        $roleId = (int) (auth()->user()->role_id ?? 0);
                        if (!$entityId || !$roleId) {
                            $staff = DB::table('egc_staff')->where('sno', $uid)->first(['entity_id','role_id']);
                            $entityId = $entityId ?: (int)($staff->entity_id ?? 0);
                            $roleId = $roleId ?: (int)($staff->role_id ?? 0);
                        }
                        $meta->where(function ($x) use ($companyId) {
                            $x->where(function ($m) use ($companyId) {
                                $m->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(ag.metadata_json, '$.audience_mode')) = 'company'")
                                  ->where(function ($ids) use ($companyId) {
                                      if ($companyId !== null) $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.company_ids'), ?)", [json_encode((int)$companyId)]);
                                      $ids->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.company_ids'), ?)", ['"all"']);
                                  });
                            })->orWhere(function ($m) use ($entityId) {
                                $m->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(ag.metadata_json, '$.audience_mode')) = 'entity'")
                                  ->where(function ($ids) use ($entityId) {
                                      $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.entity_ids'), ?)", [json_encode((int)$entityId)])
                                          ->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.entity_ids'), ?)", ['"all"']);
                                  });
                            })->orWhere(function ($m) use ($entityId, $roleId) {
                                $m->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(ag.metadata_json, '$.audience_mode')) = 'role'")
                                  ->where(function ($ids) use ($entityId) {
                                      $ids->whereRaw("JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.entity_ids'), ?)", [json_encode((int)$entityId)])
                                          ->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.entity_ids'), ?)", ['"all"']);
                                  })
                                  ->where(function ($roles) use ($roleId) {
                                      $roles->whereRaw("JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.role_ids'), ?)", [json_encode((int)$roleId)])
                                          ->orWhereRaw("JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.role_ids'), ?)", ['"all"']);
                                  });
                            })->orWhere(function ($m) use ($uid) {
                                $m->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(ag.metadata_json, '$.audience_mode')) = 'staff'")
                                  ->whereRaw("JSON_CONTAINS(JSON_EXTRACT(ag.metadata_json, '$.staff_ids'), ?)", [json_encode((int)$uid)]);
                            });
                        });
                    });
            });
        });
    }

    public function canManageResource(string $resourceType, int $resourceId, ?int $ownerId = null, ?Request $request = null): bool
    {
        $uid = $this->userId($request);
        if ($this->isSuper($request)) return true;
        if ($ownerId !== null && (int)$ownerId === $uid) return true;
        $companyId = $this->companyId($request); $role = $this->role($request);
        return DB::table('egc_tool_share_grants')->where('resource_type',$resourceType)->where('resource_id',$resourceId)
            ->where('status','active')->where('permission','Manage')
            ->where(function($q) use ($uid,$companyId,$role) {
                $q->where(fn($x)=>$x->where('grantee_type','user')->where('grantee_id',(string)$uid))
                  ->orWhere(fn($x)=>$x->where('grantee_type','role')->where('grantee_id',$role))
                  ->orWhere(fn($x)=>$x->where('grantee_type','group')->where('grantee_id','0'))
                  ->when($companyId!==null,fn($x)=>$x->orWhere(fn($y)=>$y->where('grantee_type','company')->where('grantee_id',(string)$companyId)));
            })->where(fn($q)=>$q->whereNull('expires_at')->orWhere('expires_at','>=',now()))->exists();
    }

    public function audit(Request $request, string $module, string $action, ?string $resourceType=null, ?int $resourceId=null, $before=null, $after=null, array $meta=[], bool $sensitive=false): void
    {
        DB::table('egc_tool_audit_logs')->insert([
            'module_name'=>$module,'action'=>$action,'resource_type'=>$resourceType,'resource_id'=>$resourceId,
            'actor_user_id'=>$this->userId($request),'actor_name'=>optional($request->user())->name ?? optional($request->user())->staff_name,
            'ip_address'=>$request->ip(),'user_agent'=>substr((string)$request->userAgent(),0,1000),
            'before_json'=>$before ? json_encode($before, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE) : null,
            'after_json'=>$after ? json_encode($after, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE) : null,
            'meta_json'=>$meta ? json_encode($meta, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE) : null,
            'is_high_sensitivity'=>$sensitive ? 1 : 0,'created_at'=>now()
        ]);
    }

    public function applyReadableScope(string $resourceType, int $resourceId, ?int $ownerId = null, ?int $companyId = null, ?string $visibility = null, ?Request $request = null): bool
    {
        $uid = $this->userId($request);
        if ($this->isSuper($request) || $this->isAuditor($request)) return true;
        if ($uid <= 0) return false;
        if ($ownerId !== null && (int) $ownerId === $uid) return true;
        if ($visibility === 'Group') return true;
        if ($visibility === 'Company' && $companyId !== null && (int) $companyId === (int) $this->companyId($request)) return true;
        if (DB::table('egc_tool_share_grants')
            ->where('resource_type', $resourceType)
            ->where('resource_id', $resourceId)
            ->where('status', 'active')
            ->where('metadata_json', 'like', '%"source":"productivity_audience"%')
            ->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at','>=',now()))
            ->get(['metadata_json'])
            ->contains(function ($row) use ($uid, $companyId, $request) {
                $meta = json_decode((string)$row->metadata_json, true) ?: [];
                $entityId = (int) ($request->user()?->entity_d ?? 0);
                $roleId = (int) ($request->user()?->role_id ?? 0);
                if (!$entityId || !$roleId) {
                    $staff = DB::table('egc_staff')->where('sno',$uid)->first(['entity_id','role_id']);
                    $entityId = $entityId ?: (int)($staff->entity_id ?? 0);
                    $roleId = $roleId ?: (int)($staff->role_id ?? 0);
                }
                $audience = app(\App\Services\Productivity\ProductivityAudienceService::class);
                return $audience->matches($meta, ['uid'=>$uid,'company_id'=>$companyId,'entity_id'=>$entityId,'role_id'=>$roleId]);
            })) return true;
        return DB::table('egc_tool_share_grants')
            ->where('resource_type', $resourceType)->where('resource_id', $resourceId)->where('status', 'active')
            ->where(function ($q) use ($uid, $request) {
                $companyId = $this->companyId($request); $role = $this->role($request);
                $q->where(fn($x) => $x->where('grantee_type','user')->where('grantee_id',(string)$uid))
                  ->orWhere(fn($x) => $x->where('grantee_type','role')->where('grantee_id',$role))
                  ->orWhere(fn($x) => $x->where('grantee_type','group')->where('grantee_id','0'))
                  ->when($companyId !== null, fn($x) => $x->orWhere(fn($y) => $y->where('grantee_type','company')->where('grantee_id',(string)$companyId)));
            })->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at','>=',now()))->exists();
    }
}