<?php

namespace App\Services\Productivity;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Shared audience implementation for Productivity tools.
 *
 * Knowledge Panel remains the reference implementation. Other tools use the
 * same audience semantics without changing their existing visibility column:
 * company, entity, role or staff. Grants are stored as metadata on the
 * existing egc_tool_share_grants table, so no per-module audience tables are
 * required.
 */
class ProductivityAudienceService
{
    public function context(Request $request): array
    {
        $user = $request->user();
        $uid = (int) ($user?->user_id ?? 0);
        $companyId = $user?->company_id !== null ? (int) $user->company_id : null;
        $entityId = $user?->entity_d !== null ? (int) $user->entity_d : null;
        $roleId = $user?->role_id !== null ? (int) $user->role_id : null;

        if ($uid <= 0 && $user) {
            $uid = (int) ($user->id ?? 0);
        }

        if ($uid > 0 && ($companyId === null || $entityId === null || $roleId === null)) {
            $staff = DB::table('egc_staff')->where('sno', $uid)->first(['company_id', 'entity_id', 'role_id']);
            $companyId ??= $staff?->company_id !== null ? (int) $staff->company_id : null;
            $entityId ??= $staff?->entity_id !== null ? (int) $staff->entity_id : 0;
            $roleId ??= $staff?->role_id !== null ? (int) $staff->role_id : 0;
        }

        return [
            'uid' => $uid,
            'company_id' => $companyId,
            'entity_id' => $entityId ?? 0,
            'role_id' => $roleId ?? 0,
        ];
    }

    public function options(Request $request): array
    {
        $ctx = $this->context($request);
        $groupAdmin = (int) ($request->user()?->role_id ?? 0) === 1;
        if (!$groupAdmin) {
            $roleName = strtolower(trim((string) DB::table('egc_user_role')->where('sno', $ctx['role_id'])->value('role_name')));
            $groupAdmin = in_array($roleName, ['group admin', 'super admin', 'superadmin'], true);
        }

        $companies = DB::table('egc_company')
            ->where('status', 0)
            ->when(!$groupAdmin && $ctx['company_id'] !== null, fn ($q) => $q->where('sno', $ctx['company_id']))
            ->orderBy('company_name')
            ->get(['sno', 'company_name', 'company_short_name']);

        $entities = DB::table('egc_entity as e')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'e.company_id')
            ->where('e.status', 0)
            ->when(!$groupAdmin && $ctx['company_id'] !== null, fn ($q) => $q->where('e.company_id', $ctx['company_id']))
            ->orderBy('e.entity_name')
            ->get(['e.sno', 'e.entity_name', 'e.entity_short_name', 'e.company_id', 'c.company_name']);

        $roles = DB::table('egc_user_role as r')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 'r.entity_id')
            ->leftJoin('egc_company as c', 'c.sno', '=', 'r.company_id')
            ->where('r.status', 0)
            ->when(!$groupAdmin && $ctx['company_id'] !== null, fn ($q) => $q->where(function ($x) use ($ctx) {
                $x->where('r.company_id', $ctx['company_id'])->orWhere('e.company_id', $ctx['company_id']);
            }))
            ->orderBy('r.role_name')
            ->get(['r.sno', 'r.role_name', 'r.entity_id', 'r.company_id', 'e.entity_name', 'c.company_name']);

        $staff = DB::table('egc_staff as s')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 's.entity_id')
            ->leftJoin('egc_company as c', 'c.sno', '=', 's.company_id')
            ->where('s.status', 0)
            ->where('s.sno', '>', 0)
            ->when(!$groupAdmin && $ctx['company_id'] !== null, fn ($q) => $q->where('s.company_id', $ctx['company_id']))
            ->orderBy('s.staff_name')
            ->limit(1000)
            ->get(['s.sno', 's.staff_name', 's.staff_id', 's.email_id', 's.entity_id', 's.company_id', 'e.entity_name', 'c.company_name']);

        return [
            'group_admin' => $groupAdmin,
            'companies' => $companies,
            'entities' => $entities,
            'roles' => $roles,
            'staff' => $staff,
        ];
    }

    public function normalize(Request $request): array
    {
        $mode = strtolower(trim((string) $request->input('audience_mode', '')));
        if (!in_array($mode, ['company', 'entity', 'role', 'staff'], true)) {
            throw ValidationException::withMessages(['audience_mode' => 'Choose a valid audience type.']);
        }

        $audience = [
            'source' => 'productivity_audience',
            'audience_context' => 'resource',
            'audience_mode' => $mode,
            'company_ids' => [],
            'entity_ids' => [],
            'role_ids' => [],
            'staff_ids' => [],
        ];

        if ($mode === 'company') {
            $audience['company_ids'] = $this->ids($request->input('audience_company_ids', []), true);
        } elseif ($mode === 'entity') {
            $audience['entity_ids'] = $this->ids($request->input('audience_entity_ids', []), true);
        } elseif ($mode === 'role') {
            $audience['entity_ids'] = $this->ids($request->input('audience_entity_ids', []), true);
            $audience['role_ids'] = $this->ids($request->input('audience_role_ids', []), true);
        } else {
            $audience['entity_ids'] = $this->ids($request->input('audience_entity_ids', []), true);
            $audience['staff_ids'] = $this->ids($request->input('audience_staff_ids', []), false);
        }

        $hasSelection = match ($mode) {
            'company' => !empty($audience['company_ids']),
            'entity' => !empty($audience['entity_ids']),
            'role' => !empty($audience['entity_ids']) && !empty($audience['role_ids']),
            'staff' => !empty($audience['entity_ids']) && !empty($audience['staff_ids']),
        };

        if (!$hasSelection) {
            throw ValidationException::withMessages(['audience_mode' => 'Choose at least one audience option.']);
        }

        return $audience;
    }

    public function sync(Request $request, string $resourceType, int $resourceId, int $ownerUserId): ?array
    {
        if ($request->boolean('audience_clear')) {
            DB::table('egc_tool_share_grants')
                ->where('resource_type', $resourceType)
                ->where('resource_id', $resourceId)
                ->where('metadata_json', 'like', '%"source":"productivity_audience"%')
                ->update(['status' => 'revoked', 'revoked_by' => $this->userId($request), 'revoked_at' => now(), 'updated_at' => now()]);
            return null;
        }

        if (!$request->filled('audience_mode')) return null;

        $audience = $this->normalize($request);
        $this->assertAllowed($request, $audience);

        DB::transaction(function () use ($resourceType, $resourceId, $ownerUserId, $audience, $request) {
            DB::table('egc_tool_share_grants')
                ->where('resource_type', $resourceType)
                ->where('resource_id', $resourceId)
                ->where('metadata_json', 'like', '%"source":"productivity_audience"%')
                ->update(['status' => 'revoked', 'revoked_by' => $this->userId($request), 'revoked_at' => now(), 'updated_at' => now()]);

            DB::table('egc_tool_share_grants')->insert([
                'resource_type' => $resourceType,
                'resource_id' => $resourceId,
                'owner_user_id' => $ownerUserId,
                'grantee_type' => 'group',
                'grantee_id' => '0',
                'permission' => 'View',
                'status' => 'active',
                'requested_by' => $this->userId($request),
                'approved_by' => $this->userId($request),
                'approval_required' => 0,
                'approved_at' => now(),
                'metadata_json' => json_encode($audience, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        });

        return $audience;
    }

    public function current(string $resourceType, int $resourceId): ?array
    {
        $row = DB::table('egc_tool_share_grants')
            ->where('resource_type', $resourceType)
            ->where('resource_id', $resourceId)
            ->where('status', 'active')
            ->where('metadata_json', 'like', '%"source":"productivity_audience"%')
            ->latest('sno')
            ->first();

        return $row ? json_decode((string) $row->metadata_json, true) : null;
    }

    public function canReadMetadata(string $resourceType, int $resourceId, Request $request): bool
    {
        $row = DB::table('egc_tool_share_grants')
            ->where('resource_type', $resourceType)
            ->where('resource_id', $resourceId)
            ->where('status', 'active')
            ->where('metadata_json', 'like', '%"source":"productivity_audience"%')
            ->where(fn ($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>=', now()))
            ->latest('sno')
            ->first();

        if (!$row) return false;
        return $this->matches((array) (json_decode((string) $row->metadata_json, true) ?: []), $this->context($request));
    }

    private function assertAllowed(Request $request, array $audience): void
    {
        $ctx = $this->context($request);
        $groupAdmin = (int) ($request->user()?->role_id ?? 0) === 1;

        if ($audience['audience_mode'] === 'company') {
            if (in_array('all', $audience['company_ids'], true)) {
                abort_unless($groupAdmin, 403, 'Only Group Admin can target all companies.');
            } elseif (!$groupAdmin && $ctx['company_id'] !== null) {
                foreach ($audience['company_ids'] as $id) abort_unless((int) $id === (int) $ctx['company_id'], 403, 'Selected company is outside your scope.');
            }
            return;
        }

        $entityIds = $audience['entity_ids'];
        if (in_array('all', $entityIds, true)) abort_unless($groupAdmin, 403, 'Only Group Admin can target all entities.');

        $positiveEntities = array_values(array_filter($entityIds, fn ($id) => is_int($id) && $id > 0));
        if ($positiveEntities) {
            $q = DB::table('egc_entity')->whereIn('sno', $positiveEntities)->where('status', 0);
            if (!$groupAdmin && $ctx['company_id'] !== null) $q->where('company_id', $ctx['company_id']);
            abort_unless((int) $q->count() === count($positiveEntities), 422, 'One or more selected entities are outside your scope.');
        }

        if ($audience['audience_mode'] === 'role') {
            $roles = array_values(array_filter($audience['role_ids'], fn ($id) => is_int($id) && $id > 0));
            if ($roles) {
                $q = DB::table('egc_user_role')->whereIn('sno', $roles)->where('status', 0);
                if ($positiveEntities) $q->whereIn('entity_id', $positiveEntities);
                abort_unless((int) $q->count() === count($roles), 422, 'One or more selected roles are unavailable.');
            }
        }

        if ($audience['audience_mode'] === 'staff') {
            $staff = array_values(array_filter($audience['staff_ids'], fn ($id) => is_int($id) && $id > 0));
            if ($staff) {
                $q = DB::table('egc_staff')->whereIn('sno', $staff)->where('status', 0);
                if ($positiveEntities) $q->whereIn('entity_id', $positiveEntities);
                elseif (!$groupAdmin && $ctx['company_id'] !== null) $q->where('company_id', $ctx['company_id']);
                abort_unless((int) $q->count() === count($staff), 422, 'One or more selected staff members are unavailable.');
            }
        }
    }

    public function matches(array $meta, array $ctx): bool
    {
        if (($meta['source'] ?? null) !== 'productivity_audience') return false;
        return match ($meta['audience_mode'] ?? '') {
            'company' => in_array('all', (array) ($meta['company_ids'] ?? []), true) || in_array((int) $ctx['company_id'], array_map('intval', array_filter((array) ($meta['company_ids'] ?? []), 'is_numeric')), true),
            'entity' => in_array('all', (array) ($meta['entity_ids'] ?? []), true) || in_array((int) $ctx['entity_id'], array_map('intval', array_filter((array) ($meta['entity_ids'] ?? []), 'is_numeric')), true),
            'role' => (in_array('all', (array) ($meta['entity_ids'] ?? []), true) || in_array((int) $ctx['entity_id'], array_map('intval', array_filter((array) ($meta['entity_ids'] ?? []), 'is_numeric')), true))
                && (in_array('all', (array) ($meta['role_ids'] ?? []), true) || in_array((int) $ctx['role_id'], array_map('intval', array_filter((array) ($meta['role_ids'] ?? []), 'is_numeric')), true)),
            'staff' => in_array((int) $ctx['uid'], array_map('intval', array_filter((array) ($meta['staff_ids'] ?? []), 'is_numeric')), true),
            default => false,
        };
    }

    private function ids($value, bool $allowAll = false): array
    {
        if (!is_array($value)) $value = ($value === null || $value === '') ? [] : [$value];
        $out = [];
        foreach ($value as $item) {
            $item = trim((string) $item);
            if ($item === '') continue;
            if ($allowAll && $item === 'all') { $out[] = 'all'; continue; }
            if (preg_match('/^[0-9]+$/', $item)) $out[] = (int) $item;
        }
        return array_values(array_unique($out, SORT_REGULAR));
    }

    private function userId(Request $request): int
    {
        return $this->context($request)['uid'];
    }
}
