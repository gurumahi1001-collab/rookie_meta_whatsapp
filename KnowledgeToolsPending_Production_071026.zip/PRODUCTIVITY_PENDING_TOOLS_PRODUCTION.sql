-- Elysium ERP Productivity pending-tools production upgrade
-- MySQL 8.0+ / additive only. Run after the existing productivity/tool-management SQL.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS egc_tool_document_categories (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    category_name VARCHAR(100) NOT NULL,
    color VARCHAR(20) NULL DEFAULT '#4A3E8E',
    status TINYINT NOT NULL DEFAULT 0,
    created_by BIGINT NULL,
    updated_by BIGINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_doc_cat_company_status (company_id, status),
    KEY idx_doc_cat_name (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO egc_tool_document_categories (company_id, category_name, color, status, created_at, updated_at)
SELECT NULL, 'Education', '#2E7D32', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egc_tool_document_categories WHERE company_id IS NULL AND LOWER(category_name)=LOWER('Education') AND deleted_at IS NULL);

INSERT INTO egc_tool_document_categories (company_id, category_name, color, status, created_at, updated_at)
SELECT NULL, 'Bank', '#00796B', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egc_tool_document_categories WHERE company_id IS NULL AND LOWER(category_name)=LOWER('Bank') AND deleted_at IS NULL);

INSERT INTO egc_tool_document_categories (company_id, category_name, color, status, created_at, updated_at)
SELECT NULL, 'Identity', '#B52B25', 0, NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM egc_tool_document_categories WHERE company_id IS NULL AND LOWER(category_name)=LOWER('Identity') AND deleted_at IS NULL);

-- The current Portal & Apps production controller uses these additive fields.
SET @db := DATABASE();

SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_apps') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_apps' AND column_name='current_version_json'), 'ALTER TABLE egc_tool_portal_apps ADD COLUMN current_version_json JSON NULL AFTER current_version', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='package_path'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN package_path VARCHAR(1000) NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='package_original_name'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN package_original_name VARCHAR(255) NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='package_type'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN package_type VARCHAR(20) NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='original_size'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN original_size BIGINT UNSIGNED NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='stored_size'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN stored_size BIGINT UNSIGNED NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='sha256'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN sha256 VARCHAR(64) NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='build_number'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN build_number INT UNSIGNED NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='change_type'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN change_type VARCHAR(40) NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='release_notes'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN release_notes TEXT NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='force_update'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN force_update TINYINT(1) NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='is_stable'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN is_stable TINYINT(1) NOT NULL DEFAULT 1', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='is_latest'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN is_latest TINYINT(1) NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='released_at'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN released_at DATETIME NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_portal_app_versions' AND column_name='compressed'), 'ALTER TABLE egc_tool_portal_app_versions ADD COLUMN compressed TINYINT(1) NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS egc_tool_portal_app_media (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    app_id BIGINT UNSIGNED NOT NULL,
    version_id BIGINT UNSIGNED NULL,
    media_type VARCHAR(30) NOT NULL,
    path VARCHAR(1000) NOT NULL,
    original_name VARCHAR(255) NULL,
    mime_type VARCHAR(150) NULL,
    original_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
    stored_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
    width INT UNSIGNED NULL,
    height INT UNSIGNED NULL,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0,
    created_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_portal_media_app_type (app_id, media_type),
    KEY idx_portal_media_version_sort (version_id, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The audience implementation stores its metadata on the existing share table.
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.tables WHERE table_schema=@db AND table_name='egc_tool_share_grants') AND NOT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='egc_tool_share_grants' AND column_name='metadata_json'), 'ALTER TABLE egc_tool_share_grants ADD COLUMN metadata_json JSON NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
