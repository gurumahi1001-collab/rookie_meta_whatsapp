# Elysium ERP — Productivity Pending Tools Production Upgrade

## Scope

This patch completes the pending Productivity menus while leaving the already-completed Knowledge Panel, BookMarks and Portals & Apps UI files untouched.

Updated menus:

- PassWallet
- Meetings
- Tasks
- Sticky Notes
- My Money
- Events
- Documents

The UI follows the Knowledge Panel implementation pattern already present in the ERP:

- Bootstrap modal and form structure
- ERP theme colours
- `select3` / Select2 dropdown class
- AJAX-first rendering
- Bootstrap alerts/modals
- server-side validation and authorization
- no page reload after normal CRUD operations
- responsive layouts

## Important access change

Knowledge Panel audience rules are now reusable by the pending tools through `egc_tool_share_grants.metadata_json`.

Supported audience modes:

- Company
- Entity
- Role
- Staff

The existing `Private`, `Company`, and `Group` visibility values remain supported. A custom audience is stored as a private resource plus an audience grant, matching the Knowledge Panel safety model.

`My Money` remains private and is intentionally excluded from custom sharing.

## Settings inside the menu

PassWallet:

- Manage Categories
- Add
- Edit
- Activate / Deactivate
- Delete with usage protection

Documents:

- Manage Categories
- Add
- Edit
- Activate / Deactivate
- Delete with usage protection

These are rendered through AJAX modals rather than navigating to another settings page.

## Meetings

- Day / Week / Month / List presentation pattern
- Category chips
- RSVP panel
- Accept / Decline
- Conflict validation remains server-side
- Schedule/edit/cancel through AJAX
- Participant selection
- Audience selection

## Tasks

- Kanban status columns
- List view
- Priority filtering
- New/edit task modal
- Assignee selection
- Supervisor / verification flow
- Status changes and verification via AJAX
- Audience selection

## Sticky Notes

- Note grid / masonry cards
- Pin
- Archive
- Trash
- Search
- Reminder
- Colour
- Audience selection

The previous missing readable-scope enforcement in `NotesController::data()` is also corrected.

## My Money

- Quick transaction entry
- Transaction table
- Account-aware transaction creation
- Income / expense
- Commitments
- Budget/account endpoints remain AJAX-based
- Company validation added to write operations
- No audience/share controls because this tool is private by design

## Events

- Event list
- Event type filtering
- Registration/payment fields
- Reminder fields
- Add/edit/cancel
- Audience selection

## Documents

- Personal / Official separation
- Category sidebar
- Upload modal
- Upload progress bar using XHR
- Version upload
- Pin
- Temporary signed URL open
- Delete
- Audience selection
- Category management modal

## PassWallet

- Credential table
- Category filtering
- Step-up verification before reveal/change/delete
- Rotation information
- Category settings
- Audience selection

A validation mismatch in the existing controller (`Team` versus the database-supported `Group` visibility) is corrected.

## Portal/App schema safety

The production SQL/migration also includes additive schema checks for the current Portals & Apps implementation:

- `current_version_json`
- portal version package metadata
- compression metadata
- release metadata
- `egc_tool_portal_app_media`

These are additive only and do not delete or rewrite existing portal data.

## Deployment

1. Back up the production database.
2. Copy the changed application files into the matching paths.
3. Run either the Laravel migration or the SQL file — **not both for the same database**.
4. Clear Laravel caches:

```bash
php artisan optimize:clear
```

5. Rebuild frontend assets using the ERP's normal asset pipeline. This patch contains the source JS; `node_modules`/compiled production assets are intentionally not included.
6. Run your normal application smoke tests.

## Migration choice

Laravel:

```bash
php artisan migrate --force
```

Or execute:

```text
PRODUCTIVITY_PENDING_TOOLS_PRODUCTION.sql
```

Do not execute both against the same installation unless your deployment process explicitly tracks the resulting schema state.

## Production notes

The uploaded ERP archive does not contain the production `.env`, database credentials, Redis/S3 configuration, or installed frontend dependencies. Therefore this patch has been statically validated but cannot truthfully claim a live production database/browser run.

Validated locally:

- PHP syntax for changed PHP files
- JavaScript syntax with `node --check`
- route file PHP syntax
- migration PHP syntax

## Files

`routes_web.php` is an additive route update based on the uploaded ERP route file. Replace/merge it with the existing `routes/web.php` rather than creating a second route file.

`resources/views/content/productivity/partials/pending_tool.blade.php` is the shared production Blade shell for the seven pending menus.

`resources/assets/js/productivity-pending-tools.js` contains the AJAX UI/rendering logic.
