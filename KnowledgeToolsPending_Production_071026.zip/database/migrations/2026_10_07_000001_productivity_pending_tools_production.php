<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Document category master used by the Documents settings modal.
        if (!Schema::hasTable('egc_tool_document_categories')) {
            Schema::create('egc_tool_document_categories', function (Blueprint $table) {
                $table->bigIncrements('sno');
                $table->unsignedBigInteger('company_id')->nullable();
                $table->string('category_name', 100);
                $table->string('color', 20)->nullable()->default('#4A3E8E');
                $table->tinyInteger('status')->default(0);
                $table->unsignedBigInteger('created_by')->nullable();
                $table->unsignedBigInteger('updated_by')->nullable();
                $table->dateTime('created_at')->useCurrent();
                $table->dateTime('updated_at')->useCurrent()->useCurrentOnUpdate();
                $table->dateTime('deleted_at')->nullable();
                $table->index(['company_id', 'status'], 'idx_doc_cat_company_status');
                $table->index('category_name', 'idx_doc_cat_name');
            });
        }

        // Existing ERP installations may already have the original Portal/App
        // tables. The current production controller uses these additive fields.
        if (Schema::hasTable('egc_tool_portal_apps') && !Schema::hasColumn('egc_tool_portal_apps', 'current_version_json')) {
            Schema::table('egc_tool_portal_apps', function (Blueprint $table) {
                $table->json('current_version_json')->nullable()->after('current_version');
            });
        }

        if (Schema::hasTable('egc_tool_portal_app_versions')) {
            Schema::table('egc_tool_portal_app_versions', function (Blueprint $table) {
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'package_path')) $table->string('package_path', 1000)->nullable();
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'package_original_name')) $table->string('package_original_name', 255)->nullable();
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'package_type')) $table->string('package_type', 20)->nullable();
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'original_size')) $table->unsignedBigInteger('original_size')->default(0);
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'stored_size')) $table->unsignedBigInteger('stored_size')->default(0);
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'sha256')) $table->string('sha256', 64)->nullable();
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'build_number')) $table->unsignedInteger('build_number')->nullable();
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'change_type')) $table->string('change_type', 40)->nullable();
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'release_notes')) $table->text('release_notes')->nullable();
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'force_update')) $table->boolean('force_update')->default(false);
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'is_stable')) $table->boolean('is_stable')->default(true);
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'is_latest')) $table->boolean('is_latest')->default(false);
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'released_at')) $table->dateTime('released_at')->nullable();
                if (!Schema::hasColumn('egc_tool_portal_app_versions', 'compressed')) $table->boolean('compressed')->default(false);
            });
        }

        if (!Schema::hasTable('egc_tool_portal_app_media')) {
            Schema::create('egc_tool_portal_app_media', function (Blueprint $table) {
                $table->bigIncrements('sno');
                $table->unsignedBigInteger('app_id');
                $table->unsignedBigInteger('version_id')->nullable();
                $table->string('media_type', 30);
                $table->string('path', 1000);
                $table->string('original_name', 255)->nullable();
                $table->string('mime_type', 150)->nullable();
                $table->unsignedBigInteger('original_size')->default(0);
                $table->unsignedBigInteger('stored_size')->default(0);
                $table->unsignedInteger('width')->nullable();
                $table->unsignedInteger('height')->nullable();
                $table->unsignedInteger('sort_order')->default(0);
                $table->unsignedBigInteger('created_by')->nullable();
                $table->dateTime('created_at')->useCurrent();
                $table->dateTime('updated_at')->useCurrent()->useCurrentOnUpdate();
                $table->index(['app_id', 'media_type'], 'idx_portal_media_app_type');
                $table->index(['version_id', 'sort_order'], 'idx_portal_media_version_sort');
            });
        }

        if (Schema::hasTable('egc_tool_share_grants') && !Schema::hasColumn('egc_tool_share_grants', 'metadata_json')) {
            Schema::table('egc_tool_share_grants', function (Blueprint $table) {
                $table->json('metadata_json')->nullable();
            });
        }
    }

    public function down(): void
    {
        // Production-safe: this migration is additive and must not remove
        // existing ERP data during rollback. Administrators can remove the
        // new document-category table manually if a full rollback is required.
    }
};
