-- EGC ERP Portals & Apps production upload/version upgrade
-- MySQL 8.x. Idempotent column/table creation; affects only Portal/App tables.

SET @db := DATABASE();

-- Link is optional in the Portal/App registration form.
ALTER TABLE egc_tool_portal_apps MODIFY COLUMN app_url VARCHAR(2000) NULL;

DROP PROCEDURE IF EXISTS egc_portal_add_column_if_missing;
DELIMITER $$
CREATE PROCEDURE egc_portal_add_column_if_missing(IN p_table VARCHAR(128), IN p_column VARCHAR(128), IN p_definition TEXT)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND COLUMN_NAME = p_column
    ) THEN
        SET @stmt_sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
        PREPARE stmt FROM @stmt_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

CALL egc_portal_add_column_if_missing('egc_tool_portal_apps', 'current_version_json', 'JSON NULL');

CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'build_number', 'BIGINT UNSIGNED NULL');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'change_type', "VARCHAR(40) NOT NULL DEFAULT 'Release'");
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'release_notes', 'LONGTEXT NULL');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'package_path', 'VARCHAR(1000) NULL');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'package_original_name', 'VARCHAR(255) NULL');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'package_type', 'VARCHAR(12) NULL');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'package_mime', 'VARCHAR(120) NULL');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'original_size', 'BIGINT UNSIGNED NULL');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'stored_size', 'BIGINT UNSIGNED NULL');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'sha256', 'CHAR(64) NULL');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'compressed', 'TINYINT(1) NOT NULL DEFAULT 0');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'force_update', 'TINYINT(1) NOT NULL DEFAULT 0');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'is_stable', 'TINYINT(1) NOT NULL DEFAULT 1');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'is_latest', 'TINYINT(1) NOT NULL DEFAULT 1');
CALL egc_portal_add_column_if_missing('egc_tool_portal_app_versions', 'released_at', 'DATETIME NULL');

CREATE TABLE IF NOT EXISTS egc_tool_portal_app_media (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    app_id BIGINT UNSIGNED NOT NULL,
    version_id BIGINT UNSIGNED NULL,
    media_type ENUM('screenshot') NOT NULL,
    path VARCHAR(1000) NOT NULL,
    original_name VARCHAR(255) NULL,
    original_size BIGINT UNSIGNED NULL,
    stored_size BIGINT UNSIGNED NULL,
    mime VARCHAR(120) NULL,
    width INT UNSIGNED NULL,
    height INT UNSIGNED NULL,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0,
    caption VARCHAR(500) NULL,
    created_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_portal_media_app_type_sort (app_id, media_type, sort_order),
    KEY idx_portal_media_version_type (version_id, media_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Backfill API metadata for existing records. New uploads overwrite this value in PHP.
UPDATE egc_tool_portal_apps
SET current_version_json = JSON_OBJECT(
    'app_name', app_name,
    'version', current_version,
    'app_path_url', app_url,
    'platform', platform
)
WHERE current_version IS NOT NULL AND current_version <> '';

DROP PROCEDURE IF EXISTS egc_portal_add_column_if_missing;
