<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("ALTER TABLE egc_tool_portal_apps MODIFY app_url VARCHAR(2000) NULL");
        Schema::table('egc_tool_portal_apps', function (Blueprint $table) {
            $table->json('current_version_json')->nullable()->after('current_version');
        });

        Schema::table('egc_tool_portal_app_versions', function (Blueprint $table) {
            $table->unsignedBigInteger('build_number')->nullable()->after('version_no');
            $table->string('change_type', 40)->default('Release')->after('build_number');
            $table->longText('release_notes')->nullable()->after('bug_fix_details');
            $table->string('package_path', 1000)->nullable()->after('release_notes');
            $table->string('package_original_name', 255)->nullable()->after('package_path');
            $table->string('package_type', 12)->nullable()->after('package_original_name');
            $table->string('package_mime', 120)->nullable()->after('package_type');
            $table->unsignedBigInteger('original_size')->nullable()->after('package_mime');
            $table->unsignedBigInteger('stored_size')->nullable()->after('original_size');
            $table->string('sha256', 64)->nullable()->after('stored_size');
            $table->boolean('compressed')->default(false)->after('sha256');
            $table->boolean('force_update')->default(false)->after('compressed');
            $table->boolean('is_stable')->default(true)->after('force_update');
            $table->boolean('is_latest')->default(true)->after('is_stable');
            $table->timestamp('released_at')->nullable()->after('update_date');
        });

        Schema::create('egc_tool_portal_app_media', function (Blueprint $table) {
            $table->bigIncrements('sno');
            $table->unsignedBigInteger('app_id');
            $table->unsignedBigInteger('version_id')->nullable();
            $table->enum('media_type', ['screenshot']);
            $table->string('path', 1000);
            $table->string('original_name', 255)->nullable();
            $table->unsignedBigInteger('original_size')->nullable();
            $table->unsignedBigInteger('stored_size')->nullable();
            $table->string('mime', 120)->nullable();
            $table->unsignedInteger('width')->nullable();
            $table->unsignedInteger('height')->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->string('caption', 500)->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->timestamps();

            $table->index(['app_id', 'media_type', 'sort_order'], 'idx_portal_media_app_type_sort');
            $table->index(['version_id', 'media_type'], 'idx_portal_media_version_type');
        });

        DB::table('egc_tool_portal_apps')
            ->whereNotNull('current_version')
            ->update([
                'current_version_json' => DB::raw("JSON_OBJECT('app_name', app_name, 'version', current_version, 'app_path_url', app_url, 'platform', platform)")
            ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_tool_portal_app_media');

        Schema::table('egc_tool_portal_app_versions', function (Blueprint $table) {
            foreach ([
                'build_number','change_type','release_notes','package_path','package_original_name',
                'package_type','package_mime','original_size','stored_size','sha256','compressed',
                'force_update','is_stable','is_latest','released_at'
            ] as $column) {
                $table->dropColumn($column);
            }
        });

        Schema::table('egc_tool_portal_apps', function (Blueprint $table) {
            $table->dropColumn('current_version_json');
        });
    }
};
