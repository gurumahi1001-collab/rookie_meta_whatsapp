<?php

namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PortalAppVersion extends Model
{
    use HasFactory;

    protected $table = 'egc_tool_portal_app_versions';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];

    protected $casts = [
        'app_id' => 'integer',
        'updated_by' => 'integer',
        'update_date' => 'date',
        'released_at' => 'datetime',
        'original_size' => 'integer',
        'stored_size' => 'integer',
        'build_number' => 'integer',
        'force_update' => 'boolean',
        'is_stable' => 'boolean',
        'is_latest' => 'boolean',
        'compressed' => 'boolean',
    ];

    public function app()
    {
        return $this->belongsTo(PortalApp::class, 'app_id', 'sno');
    }

    public function media()
    {
        return $this->hasMany(PortalAppMedia::class, 'version_id', 'sno');
    }
}
