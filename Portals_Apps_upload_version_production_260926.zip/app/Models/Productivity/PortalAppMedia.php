<?php

namespace App\Models\Productivity;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PortalAppMedia extends Model
{
    use HasFactory;

    protected $table = 'egc_tool_portal_app_media';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    protected $guarded = [];

    protected $casts = [
        'app_id' => 'integer',
        'version_id' => 'integer',
        'original_size' => 'integer',
        'stored_size' => 'integer',
        'width' => 'integer',
        'height' => 'integer',
        'sort_order' => 'integer',
        'created_by' => 'integer',
    ];

    public function app()
    {
        return $this->belongsTo(PortalApp::class, 'app_id', 'sno');
    }

    public function version()
    {
        return $this->belongsTo(PortalAppVersion::class, 'version_id', 'sno');
    }

    public function getUrlAttribute(): ?string
    {
        if (!$this->path) return null;
        return asset('storage/' . ltrim($this->path, '/'));
    }
}
