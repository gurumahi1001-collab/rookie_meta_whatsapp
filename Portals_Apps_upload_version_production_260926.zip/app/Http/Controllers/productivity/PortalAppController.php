<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\PortalApp;
use App\Models\Productivity\PortalAppMedia;
use App\Models\Productivity\PortalAppVersion;
use App\Services\Productivity\PortalAppUploadService;
use App\Services\FavIcon\BookmarkFaviconService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Throwable;

class PortalAppController extends ProductivityBaseController
{
    public function __construct(
        \App\Services\Productivity\ProductivityAccessService $access,
        protected PortalAppUploadService $uploadService,
        protected BookmarkFaviconService $faviconService
    ) {
        parent::__construct($access);
    }

    public function index()
    {
        return view('content.productivity.portals.index');
    }

    public function data(Request $request): JsonResponse
    {
        $query = PortalApp::withoutGlobalScopes()
            ->from('egc_tool_portal_apps as a')
            ->leftJoin('egc_company as c', function ($join) {
                $join->on('c.sno', '=', 'a.company_id')->where('c.status', 0);
            })
            ->leftJoin('egc_staff as owner', 'owner.sno', '=', 'a.technical_owner_user_id')
            ->whereNull('a.deleted_at')
            ->select([
                'a.*',
                DB::raw("COALESCE(c.company_name, 'Group') as company_name"),
                'owner.staff_name as technical_owner_name',
            ])
            ->selectSub(function ($q) {
                $q->from('egc_tool_portal_launches as l')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('l.app_id', 'a.sno')
                    ->where('l.launched_at', '>=', now()->startOfMonth());
            }, 'opens_this_month')
            ->selectSub(function ($q) {
                $q->from('egc_tool_portal_subscriptions as sub')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('sub.app_id', 'a.sno')
                    ->where('sub.user_id', $this->uid());
            }, 'is_subscribed')
            ->selectSub(function ($q) {
                $q->from('egc_tool_portal_app_media as media')
                    ->selectRaw('COUNT(*)')
                    ->whereColumn('media.app_id', 'a.sno')
                    ->where('media.media_type', 'screenshot');
            }, 'screenshot_count');

        $this->applyScope($query, $request, 'a.company_id');

        if ($request->filled('status')) {
            $query->where('a.status', $request->input('status'));
        }
        if ($request->filled('platform')) {
            $query->where('a.platform', $request->input('platform'));
        }
        if ($request->filled('environment')) {
            $query->where('a.environment', $request->input('environment'));
        }
        if ($request->filled('search')) {
            $search = trim((string) $request->input('search'));
            $like = "%{$search}%";
            $query->where(function ($q) use ($like) {
                $q->where('a.app_name', 'like', $like)
                    ->orWhere('a.purpose', 'like', $like)
                    ->orWhere('a.app_url', 'like', $like)
                    ->orWhere('c.company_name', 'like', $like);
            });
        }

        $base = clone $query;
        $mostUsed = (clone $base)
            ->orderByDesc('opens_this_month')
            ->orderByDesc('a.most_used_score')
            ->orderBy('a.app_name')
            ->limit(3)
            ->get();

        $rows = $query
            ->orderBy('a.sort_order')
            ->orderBy('a.app_name')
            ->paginate(min(max((int) $request->get('per_page', 24), 12), 100));

        $rows->getCollection()->transform(fn ($app) => $this->decorateRow($app, $request));
        $mostUsed->transform(fn ($app) => $this->decorateRow($app, $request));

        return $this->ok([
            'rows' => $rows,
            'most_used' => $mostUsed,
            'summary' => [
                'registered' => (clone $base)->count(),
                'live' => (clone $base)->where('a.status', 'Live')->count(),
                'maintenance' => (clone $base)->where('a.status', 'Under Maintenance')->count(),
                'deprecated' => (clone $base)->where('a.status', 'Deprecated')->count(),
            ],
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $app = PortalApp::withoutGlobalScopes()
            ->leftJoin('egc_company as c', function ($join) {
                $join->on('c.sno', '=', 'egc_tool_portal_apps.company_id')->where('c.status', 0);
            })
            ->leftJoin('egc_staff as owner', 'owner.sno', '=', 'egc_tool_portal_apps.technical_owner_user_id')
            ->where('egc_tool_portal_apps.sno', $id)
            ->whereNull('egc_tool_portal_apps.deleted_at')
            ->select([
                'egc_tool_portal_apps.*',
                DB::raw("COALESCE(c.company_name, 'Group') as company_name"),
                'owner.staff_name as technical_owner_name',
            ])
            ->firstOrFail();

        $this->authorizeRead($request, $app);

        $versions = PortalAppVersion::query()
            ->from('egc_tool_portal_app_versions as v')
            ->leftJoin('egc_staff as s', 's.sno', '=', 'v.updated_by')
            ->where('v.app_id', $id)
            ->orderByDesc('v.update_date')
            ->orderByDesc('v.sno')
            ->get([
                'v.*',
                's.staff_name as updated_by_name',
            ])
            ->map(function ($version) use ($id) {
                $version->download_url = $version->package_path
                    ? route('productivity.portals.version.download', [$id, $version->sno])
                    : null;
                $version->formatted_original_size = $this->formatBytes((int) ($version->original_size ?? 0));
                $version->formatted_stored_size = $this->formatBytes((int) ($version->stored_size ?? 0));
                $version->saving_percent = ((int) ($version->original_size ?? 0) > 0 && (int) ($version->stored_size ?? 0) > 0)
                    ? round(max(0, 100 - (((int) $version->stored_size / (int) $version->original_size) * 100)), 1)
                    : 0;
                return $version;
            });

        $media = PortalAppMedia::query()
            ->where('app_id', $id)
            ->orderBy('sort_order')
            ->orderBy('sno')
            ->get()
            ->map(function (PortalAppMedia $item) {
                $item->url = $item->url;
                return $item;
            });

        $isSubscribed = DB::table('egc_tool_portal_subscriptions')
            ->where('app_id', $id)
            ->where('user_id', $this->uid())
            ->exists();

        $app->icon_url = $this->mediaUrl($app->icon_path);
        $app->can_manage = $this->access->canManageResource('portal', $id, (int) ($app->created_by ?? 0), $request);

        return $this->ok([
            'app' => $app,
            'versions' => $versions,
            'media' => $media,
            'is_subscribed' => $isSubscribed,
            'current_version_json' => $app->current_version_json ?: null,
        ]);
    }

    public function currentVersion(Request $request, int $id): JsonResponse
    {
        $app = PortalApp::withoutGlobalScopes()->where('sno', $id)->whereNull('deleted_at')->firstOrFail();
        $this->authorizeRead($request, $app);

        return response()->json([
            'status' => 200,
            'message' => 'Current version metadata.',
            'data' => $app->current_version_json ?: [
                'app_name' => $app->app_name,
                'version' => $app->current_version,
                'app_path_url' => $app->app_url,
            ],
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite($request), 403);

        $data = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'app_name' => ['required', 'string', 'max:180'],
            'app_url' => ['nullable', 'string', 'max:2000'],
            'purpose' => ['nullable', 'string', 'max:5000'],
            'platform' => ['nullable', 'in:Web Portal,Mobile App,Desktop'],
            'environment' => ['nullable', 'in:Production,Staging'],
            'status' => ['nullable', 'in:Live,Under Maintenance,Deprecated'],
            'technical_owner_user_id' => ['nullable', 'integer'],
            'passwallet_entry_id' => ['nullable', 'integer'],
            'version_no' => ['nullable', 'string', 'max:60'],
            'build_number' => ['nullable', 'integer', 'min:0', 'max:2147483647'],
            'change_type' => ['nullable', 'in:Release,New Features,Improvement,Bug Fix,Security,Maintenance'],
            'update_details' => ['nullable', 'string', 'max:20000'],
            'bug_fix_details' => ['nullable', 'string', 'max:20000'],
            'release_notes' => ['nullable', 'string', 'max:20000'],
            'force_update' => ['nullable', 'boolean'],
            'is_stable' => ['nullable', 'boolean'],
            'icon' => ['nullable', 'image', 'mimes:png,jpg,jpeg,webp', 'max:5120'],
            'screenshots' => ['nullable', 'array', 'max:8'],
            'screenshots.*' => ['image', 'mimes:png,jpg,jpeg,webp', 'max:5120'],
            'package_file' => ['nullable', 'file', 'max:1048576'],
        ]);

        $url = $this->normaliseUrl($data['app_url'] ?? null);
        $companyId = $this->normaliseCompanyId($data['company_id'] ?? null, $request);
        $ownerId = $this->normaliseTechnicalOwner($data['technical_owner_user_id'] ?? null, $companyId, $request);

        $platform = $data['platform'] ?? 'Web Portal';
        $versionNo = trim((string) ($data['version_no'] ?? ''));
        $hasPackage = $request->hasFile('package_file');
        if ($hasPackage && $versionNo === '') $versionNo = $this->nextVersionNumber(null);

        $hasVersionContent = $versionNo !== ''
            || $hasPackage
            || trim((string) ($data['update_details'] ?? '')) !== ''
            || trim((string) ($data['bug_fix_details'] ?? '')) !== ''
            || trim((string) ($data['release_notes'] ?? '')) !== '';

        $createdFiles = [];
        try {
            DB::beginTransaction();

            $nextSort = (int) PortalApp::query()->where('company_id', $companyId)->max('sort_order') + 1;
            $app = PortalApp::create([
                'company_id' => $companyId,
                'app_name' => trim($data['app_name']),
                'app_url' => $url,
                'purpose' => $this->nullableString($data['purpose'] ?? null),
                'platform' => $platform,
                'environment' => $data['environment'] ?? 'Production',
                'status' => $data['status'] ?? 'Live',
                'technical_owner_user_id' => $ownerId,
                'icon_path' => $iconPath,
                'passwallet_entry_id' => $data['passwallet_entry_id'] ?? null,
                'current_version' => null,
                'current_version_json' => null,
                'most_used_score' => 0,
                'sort_order' => $nextSort,
                'created_by' => $this->uid(),
                'updated_by' => $this->uid(),
            ]);

            if ($request->hasFile('icon')) {
                $icon = $this->uploadService->storeIcon($request->file('icon'), $app->sno);
                $createdFiles[] = $icon['path'];
                $app->update(['icon_path' => $icon['path']]);
            } elseif ($url) {
                $favicon = $this->faviconService->getFavicon($url);
                if ($favicon) $app->update(['icon_path' => $favicon]);
            }

            $version = null;
            if ($hasVersionContent) {
                $version = $this->createVersion($app, $request, $data, $versionNo);
                if ($request->hasFile('package_file')) {
                    $package = $this->uploadService->storePackage($request->file('package_file'), $app->sno, $version->sno);
                    $createdFiles[] = $package['path'];
                    $version->update([
                        'package_path' => $package['path'],
                        'package_original_name' => $package['original_name'],
                        'package_type' => $package['package_type'],
                        'package_mime' => $package['mime'],
                        'original_size' => $package['original_size'],
                        'stored_size' => $package['stored_size'],
                        'sha256' => $package['sha256'] ?? null,
                        'compressed' => $package['compressed'] ? 1 : 0,
                    ]);
                }
                $this->syncCurrentVersion($app->fresh(), $version->fresh());
            }

            $this->storeScreenshots($request, $app, $version, $createdFiles);
            DB::commit();

            $this->audit($request, 'Portals & Apps', 'portal_created', 'portal', $app->sno, null, $app->fresh()->toArray());
            return $this->ok($app->fresh(), 'Portal/App registered successfully.');
        } catch (Throwable $e) {
            DB::rollBack();
            foreach ($createdFiles as $path) $this->uploadService->delete($path);
            report($e);
            return $this->fail($e instanceof \RuntimeException ? $e->getMessage() : 'Unable to register the portal/app.', 422);
        }
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $app = PortalApp::findOrFail($id);
        $this->authorizeManage($request, $app);

        $data = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'app_name' => ['required', 'string', 'max:180'],
            'app_url' => ['nullable', 'string', 'max:2000'],
            'purpose' => ['nullable', 'string', 'max:5000'],
            'platform' => ['nullable', 'in:Web Portal,Mobile App,Desktop'],
            'environment' => ['nullable', 'in:Production,Staging'],
            'status' => ['nullable', 'in:Live,Under Maintenance,Deprecated'],
            'technical_owner_user_id' => ['nullable', 'integer'],
            'passwallet_entry_id' => ['nullable', 'integer'],
            'icon' => ['nullable', 'image', 'mimes:png,jpg,jpeg,webp', 'max:5120'],
            'screenshots' => ['nullable', 'array', 'max:8'],
            'screenshots.*' => ['image', 'mimes:png,jpg,jpeg,webp', 'max:5120'],
        ]);

        $before = $app->toArray();
        $url = $this->normaliseUrl($data['app_url'] ?? null);
        $companyId = $this->normaliseCompanyId($data['company_id'] ?? $app->company_id, $request);
        $ownerId = $this->normaliseTechnicalOwner($data['technical_owner_user_id'] ?? $app->technical_owner_user_id, $companyId, $request);
        $createdFiles = [];

        try {
            DB::beginTransaction();

            $iconPath = $app->icon_path;
            if ($request->hasFile('icon')) {
                $icon = $this->uploadService->storeIcon($request->file('icon'), $app->sno);
                $iconPath = $icon['path'];
                $createdFiles[] = $iconPath;
                $this->deleteStoredMaybeRemote($app->icon_path);
            } elseif ($url && ($url !== $app->app_url) && !$this->isStoredAsset($app->icon_path)) {
                $iconPath = $this->faviconService->getFavicon($url);
            }

            $app->update([
                'company_id' => $companyId,
                'app_name' => trim($data['app_name']),
                'app_url' => $url,
                'purpose' => $this->nullableString($data['purpose'] ?? null),
                'platform' => $data['platform'] ?? $app->platform,
                'environment' => $data['environment'] ?? $app->environment,
                'status' => $data['status'] ?? $app->status,
                'technical_owner_user_id' => $ownerId,
                'icon_path' => $iconPath,
                'passwallet_entry_id' => $data['passwallet_entry_id'] ?? $app->passwallet_entry_id,
                'updated_by' => $this->uid(),
            ]);

            $currentJson = $app->current_version_json;
            if (is_array($currentJson) && $currentJson) {
                $currentJson['app_name'] = trim($data['app_name']);
                $currentJson['platform'] = $data['platform'] ?? $app->platform;
                if (empty($currentJson['version_id'])) $currentJson['app_path_url'] = $url;
                $app->update(['current_version_json' => $currentJson]);
            }

            $this->storeScreenshots($request, $app, null, $createdFiles);
            DB::commit();

            $this->audit($request, 'Portals & Apps', 'portal_updated', 'portal', $id, $before, $app->fresh()->toArray());
            return $this->ok($app->fresh(), 'Portal/App updated.');
        } catch (Throwable $e) {
            DB::rollBack();
            foreach ($createdFiles as $path) $this->uploadService->delete($path);
            report($e);
            return $this->fail($e instanceof \RuntimeException ? $e->getMessage() : 'Unable to update the portal/app.', 422);
        }
    }

    public function version(Request $request, int $id): JsonResponse
    {
        $app = PortalApp::findOrFail($id);
        $this->authorizeManage($request, $app);

        $data = $request->validate([
            'version_no' => ['nullable', 'string', 'max:60'],
            'build_number' => ['nullable', 'integer', 'min:0', 'max:2147483647'],
            'change_type' => ['nullable', 'in:Release,New Features,Improvement,Bug Fix,Security,Maintenance'],
            'update_details' => ['nullable', 'string', 'max:20000'],
            'bug_fix_details' => ['nullable', 'string', 'max:20000'],
            'release_notes' => ['nullable', 'string', 'max:20000'],
            'update_date' => ['nullable', 'date'],
            'force_update' => ['nullable', 'boolean'],
            'is_stable' => ['nullable', 'boolean'],
            'package_file' => ['nullable', 'file', 'max:1048576'],
            'screenshots' => ['nullable', 'array', 'max:8'],
            'screenshots.*' => ['image', 'mimes:png,jpg,jpeg,webp', 'max:5120'],
        ]);

        $versionNo = trim((string) ($data['version_no'] ?? ''));
        if ($versionNo === '') $versionNo = $this->nextVersionNumber($app);

        $existing = PortalAppVersion::query()->where('app_id', $id)->where('version_no', $versionNo)->exists();
        abort_if($existing, 422, "Version {$versionNo} already exists for this application.");

        $createdFiles = [];
        try {
            DB::beginTransaction();
            $version = $this->createVersion($app, $request, $data, $versionNo);

            if ($request->hasFile('package_file')) {
                $package = $this->uploadService->storePackage($request->file('package_file'), $app->sno, $version->sno);
                $createdFiles[] = $package['path'];
                $version->update([
                    'package_path' => $package['path'],
                    'package_original_name' => $package['original_name'],
                    'package_type' => $package['package_type'],
                    'package_mime' => $package['mime'],
                    'original_size' => $package['original_size'],
                    'stored_size' => $package['stored_size'],
                    'sha256' => $package['sha256'] ?? null,
                    'compressed' => $package['compressed'] ? 1 : 0,
                ]);
            }

            $version->refresh();
            $this->storeScreenshots($request, $app, $version, $createdFiles);
            $this->syncCurrentVersion($app->fresh(), $version);
            DB::commit();

            $this->audit($request, 'Portals & Apps', 'portal_version_recorded', 'portal', $id, null, $version->fresh()->toArray());
            return $this->ok([
                'version' => $version->fresh(),
                'current_version_json' => $app->fresh()->current_version_json,
            ], "Version {$versionNo} recorded successfully.");
        } catch (Throwable $e) {
            DB::rollBack();
            foreach ($createdFiles as $path) $this->uploadService->delete($path);
            report($e);
            return $this->fail($e instanceof \RuntimeException ? $e->getMessage() : 'Unable to record this version.', 422);
        }
    }

    public function deleteMedia(Request $request, int $id, int $mediaId): JsonResponse
    {
        $app = PortalApp::findOrFail($id);
        $this->authorizeManage($request, $app);

        $media = PortalAppMedia::where('app_id', $id)->where('sno', $mediaId)->firstOrFail();
        $path = $media->path;
        $media->delete();
        $this->uploadService->delete($path);

        $this->audit($request, 'Portals & Apps', 'portal_media_deleted', 'portal', $id, ['media_id' => $mediaId, 'path' => $path], null);
        return $this->ok(null, 'Screenshot removed.');
    }

    public function downloadVersion(Request $request, int $id, int $versionId)
    {
        $app = PortalApp::withoutGlobalScopes()->where('sno', $id)->whereNull('deleted_at')->firstOrFail();
        $this->authorizeRead($request, $app);
        $version = PortalAppVersion::where('app_id', $id)->where('sno', $versionId)->firstOrFail();

        if (!$version->package_path || !Storage::disk('public')->exists($version->package_path)) {
            abort(404, 'Application package is not available.');
        }

        return response()->download(
            Storage::disk('public')->path($version->package_path),
            $version->package_original_name ?: ($app->app_name . '-' . $version->version_no . '.' . ($version->package_type ?: 'bin'))
        );
    }

    public function launch(Request $request, int $id): JsonResponse
    {
        $app = PortalApp::withoutGlobalScopes()->where('sno', $id)->whereNull('deleted_at')->firstOrFail();
        $this->authorizeRead($request, $app);

        $appPath = data_get($app->current_version_json, 'app_path_url') ?: $app->app_url;
        if (!$appPath) {
            abort(422, 'No portal URL or current application package is available to launch.');
        }

        DB::table('egc_tool_portal_launches')->insert([
            'app_id' => $id,
            'user_id' => $this->uid(),
            'launched_at' => now(),
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 1000),
        ]);
        $app->increment('most_used_score');

        $this->audit($request, 'Portals & Apps', 'portal_launched', 'portal', $id, null, null, ['url' => $appPath]);
        return $this->ok(['url' => $appPath], 'Portal/App launch recorded.');
    }

    public function subscribe(Request $request, int $id): JsonResponse
    {
        $app = PortalApp::withoutGlobalScopes()->where('sno', $id)->whereNull('deleted_at')->firstOrFail();
        $this->authorizeRead($request, $app);

        $exists = DB::table('egc_tool_portal_subscriptions')->where('app_id', $id)->where('user_id', $this->uid())->exists();
        if ($exists) {
            DB::table('egc_tool_portal_subscriptions')->where('app_id', $id)->where('user_id', $this->uid())->delete();
            $subscribed = false;
        } else {
            DB::table('egc_tool_portal_subscriptions')->insert([
                'app_id' => $id,
                'user_id' => $this->uid(),
                'company_id' => $app->company_id,
                'created_at' => now(),
            ]);
            $subscribed = true;
        }

        return $this->ok(['subscribed' => $subscribed], $subscribed ? 'Subscribed to portal.' : 'Portal subscription removed.');
    }

    public function exportXlsx(Request $request)
    {
        abort_unless($this->access->canExport($request), 403);
        abort_unless(class_exists(Spreadsheet::class) && class_exists(Xlsx::class), 503, 'XLSX support is not installed.');

        $query = PortalApp::withoutGlobalScopes()
            ->from('egc_tool_portal_apps as a')
            ->leftJoin('egc_company as c', function ($join) {
                $join->on('c.sno', '=', 'a.company_id')->where('c.status', 0);
            })
            ->leftJoin('egc_staff as s', 's.sno', '=', 'a.technical_owner_user_id')
            ->whereNull('a.deleted_at');
        $this->applyScope($query, $request, 'a.company_id');

        $rows = $query->orderBy('a.app_name')->get([
            'a.app_name', 'a.app_url', 'a.platform', 'a.environment', 'a.status', 'a.current_version',
            'a.purpose', 'a.current_version_json', 'c.company_name', 's.staff_name as technical_owner_name',
        ]);

        $sheet = (new Spreadsheet())->getActiveSheet();
        $sheet->fromArray(['Application','URL','Owning Company','Platform','Environment','Status','Version','Purpose','Technical Owner','Current Version JSON'], null, 'A1');
        $r = 2;
        foreach ($rows as $row) {
            $sheet->fromArray([
                $row->app_name, $row->app_url, $row->company_name ?: 'Group', $row->platform,
                $row->environment, $row->status, $row->current_version, $row->purpose,
                $row->technical_owner_name, is_array($row->current_version_json) ? json_encode($row->current_version_json, JSON_UNESCAPED_SLASHES) : $row->current_version_json,
            ], null, 'A' . $r++);
        }
        $sheet->getStyle('A1:J1')->getFont()->setBold(true);
        foreach (range('A','J') as $col) $sheet->getColumnDimension($col)->setAutoSize(true);

        $this->audit($request, 'Portals & Apps', 'export', 'portal', null, null, null, ['format' => 'xlsx', 'row_count' => $rows->count()]);
        $writer = new Xlsx($sheet->getParent());
        return response()->streamDownload(fn() => $writer->save('php://output'), 'portal_apps_' . now()->format('Ymd_His') . '.xlsx', ['Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);
    }

    private function createVersion(PortalApp $app, Request $request, array $data, string $versionNo): PortalAppVersion
    {
        return PortalAppVersion::create([
            'app_id' => $app->sno,
            'version_no' => $versionNo,
            'build_number' => $data['build_number'] ?? null,
            'change_type' => $data['change_type'] ?? 'Release',
            'update_details' => $this->nullableString($data['update_details'] ?? null),
            'bug_fix_details' => $this->nullableString($data['bug_fix_details'] ?? null),
            'release_notes' => $this->nullableString($data['release_notes'] ?? null),
            'updated_by' => $this->uid(),
            'update_date' => ($data['update_date'] ?? now()->toDateString()),
            'force_update' => !empty($data['force_update']),
            'is_stable' => array_key_exists('is_stable', $data) ? (bool) $data['is_stable'] : true,
            'is_latest' => true,
            'released_at' => now(),
        ]);
    }

    private function syncCurrentVersion(PortalApp $app, PortalAppVersion $version): void
    {
        PortalAppVersion::where('app_id', $app->sno)->where('sno', '!=', $version->sno)->update(['is_latest' => false]);

        $downloadUrl = $version->package_path
            ? route('productivity.portals.version.download', [$app->sno, $version->sno])
            : $app->app_url;
        $payload = [
            'app_name' => $app->app_name,
            'version' => $version->version_no,
            'app_path_url' => $downloadUrl,
            'version_id' => $version->sno,
            'build_number' => $version->build_number,
            'platform' => $app->platform,
            'package_type' => $version->package_type,
            'package_original_name' => $version->package_original_name,
            'package_size' => $version->stored_size,
            'updated_at' => now()->toIso8601String(),
        ];

        $app->update([
            'current_version' => $version->version_no,
            'current_version_json' => $payload,
            'updated_by' => $this->uid(),
        ]);
    }

    private function storeScreenshots(Request $request, PortalApp $app, ?PortalAppVersion $version, array &$createdFiles): void
    {
        if (!$request->hasFile('screenshots')) return;
        $start = (int) PortalAppMedia::where('app_id', $app->sno)->where('media_type', 'screenshot')->max('sort_order') + 1;
        foreach ($request->file('screenshots', []) as $index => $file) {
            $item = $this->uploadService->storeScreenshot($file, $app->sno, $version?->sno, $this->uid(), $start + $index);
            $createdFiles[] = $item['path'];
            PortalAppMedia::create($item);
        }
    }

    private function decorateRow($app, Request $request)
    {
        $app->icon_url = $this->mediaUrl($app->icon_path);
        $app->can_manage = $this->access->canManageResource('portal', (int) $app->sno, (int) ($app->created_by ?? 0), $request);
        $app->current_version_api = $app->current_version_json;
        return $app;
    }

    private function authorizeRead(Request $request, PortalApp $app): void
    {
        abort_unless($this->access->canReadResource('portal', (int) $app->sno, (int) ($app->created_by ?? 0), $app->company_id, 'Company', $request), 403);
    }

    private function authorizeManage(Request $request, PortalApp $app): void
    {
        abort_unless($this->access->canManageResource('portal', (int) $app->sno, (int) ($app->created_by ?? 0), $request), 403);
    }

    private function normaliseCompanyId($companyId, Request $request): ?int
    {
        if (!$this->access->isGroupAdmin($request)) return $this->cid();
        if ($companyId === null || $companyId === '' || $companyId === 'all') return null;
        $companyId = (int) $companyId;
        abort_unless(DB::table('egc_company')->where('sno', $companyId)->where('status', 0)->exists(), 422, 'Selected company is not active.');
        return $companyId;
    }

    private function normaliseTechnicalOwner($ownerId, ?int $companyId, Request $request): ?int
    {
        if ($ownerId === null || $ownerId === '') return null;
        $ownerId = (int) $ownerId;
        $owner = DB::table('egc_staff')->where('sno', $ownerId)->where('status', '!=', 2)->first(['sno','company_id']);
        abort_unless($owner, 422, 'Selected technical owner is not active.');
        if (!$this->access->isGroupAdmin($request) && $companyId && (int) $owner->company_id !== (int) $companyId) abort(403, 'Technical owner must belong to the selected company.');
        return $ownerId;
    }

    private function normaliseUrl(?string $value): ?string
    {
        $value = trim((string) $value);
        if ($value === '') return null;
        if (!preg_match('/^https?:\/\//i', $value)) $value = 'https://' . $value;
        abort_unless(filter_var($value, FILTER_VALIDATE_URL), 422, 'Please enter a valid portal/app URL.');
        abort_unless(in_array(strtolower((string) parse_url($value, PHP_URL_SCHEME)), ['http','https'], true), 422, 'Only HTTP and HTTPS URLs are supported.');
        return $value;
    }

    private function nextVersionNumber(?PortalApp $app): string
    {
        if (!$app) return '1.0.0';
        $latest = PortalAppVersion::where('app_id', $app->sno)->orderByDesc('sno')->value('version_no');
        if (!$latest || !preg_match('/^(\d+)\.(\d+)\.(\d+)$/', (string) $latest, $m)) return '1.0.0';
        return $m[1] . '.' . $m[2] . '.' . ((int) $m[3] + 1);
    }

    private function nullableString($value): ?string
    {
        $value = is_string($value) ? trim($value) : $value;
        return $value === '' ? null : $value;
    }

    private function isStoredAsset(?string $path): bool
    {
        return $path !== null && $path !== '' && !preg_match('/^https?:\/\//i', $path);
    }

    private function deleteStoredMaybeRemote(?string $path): void
    {
        if ($this->isStoredAsset($path)) $this->uploadService->delete($path);
    }

    private function mediaUrl(?string $path): ?string
    {
        if (!$path) return null;
        if (preg_match('/^https?:\/\//i', $path)) return $path;
        return asset('storage/' . ltrim($path, '/'));
    }

    private function formatBytes(int $bytes): string
    {
        if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
        if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
        if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
        return $bytes . ' B';
    }
}
