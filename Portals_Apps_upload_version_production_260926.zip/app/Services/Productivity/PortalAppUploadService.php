<?php

namespace App\Services\Productivity;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;
use ZipArchive;

class PortalAppUploadService
{
    private const MAX_PACKAGE_BYTES = 1073741824; // 1 GB
    private const MAX_REPACK_BYTES = 536870912;  // 512 MB uncompressed zip content
    private const MAX_REPACK_ENTRY_BYTES = 67108864; // 64 MB per zip entry
    private const IMAGE_MAX_BYTES = 5242880; // 5 MB per image
    private const IMAGE_MAX_WIDTH = 1800;
    private const IMAGE_QUALITY = 82;

    public function storeIcon(UploadedFile $file, int $appId): array
    {
        $this->assertImage($file);
        return $this->storeOptimizedImage($file, 'portals/' . $appId . '/media', 'icon');
    }

    public function storeScreenshot(UploadedFile $file, int $appId, ?int $versionId, int $userId, int $sortOrder = 0): array
    {
        $this->assertImage($file);
        $result = $this->storeOptimizedImage($file, 'portals/' . $appId . '/screenshots', 'screenshot');
        $result['media_type'] = 'screenshot';
        $result['app_id'] = $appId;
        $result['version_id'] = $versionId;
        $result['created_by'] = $userId;
        $result['sort_order'] = $sortOrder;
        return $result;
    }

    public function storePackage(UploadedFile $file, int $appId, int $versionId): array
    {
        $this->assertPackage($file);
        $extension = strtolower($file->getClientOriginalExtension());
        $originalSize = (int) $file->getSize();

        $base = 'portals/' . $appId . '/versions';
        $safeName = Str::uuid()->toString();

        // APK/AAB are signed application binaries. Repacking them would alter the
        // package bytes and can invalidate Android signing. ZIP source bundles can
        // safely be re-packed when they are within the bounded optimization window.
        if ($extension === 'zip') {
            $repacked = $this->tryCompressZip($file, $base, $safeName);
            if ($repacked) {
                return array_merge($repacked, [
                    'original_size' => $originalSize,
                    'compressed' => true,
                    'package_type' => 'zip',
                    'original_name' => $file->getClientOriginalName(),
                    'mime' => $file->getMimeType() ?: 'application/zip',
                ]);
            }
        }

        $path = $file->storeAs($base, $safeName . '.' . ($extension ?: 'bin'), 'public');
        return [
            'path' => $path,
            'original_size' => $originalSize,
            'stored_size' => (int) Storage::disk('public')->size($path),
            'compressed' => false,
            'package_type' => $extension ?: 'bin',
            'original_name' => $file->getClientOriginalName(),
            'mime' => $file->getMimeType() ?: 'application/octet-stream',
            'sha256' => hash_file('sha256', $file->getRealPath()),
        ];
    }

    public function delete(string $path): void
    {
        if ($path !== '') Storage::disk('public')->delete($path);
    }

    private function assertImage(UploadedFile $file): void
    {
        if (!$file->isValid() || (int) $file->getSize() > self::IMAGE_MAX_BYTES) {
            throw new RuntimeException('Each image must be a valid image up to 5 MB.');
        }

        $extension = strtolower($file->getClientOriginalExtension());
        if (!in_array($extension, ['png', 'jpg', 'jpeg', 'webp'], true)) {
            throw new RuntimeException('Images must be PNG, JPG or WebP.');
        }

        $info = @getimagesize($file->getRealPath());
        if (!$info || empty($info['mime'])) {
            throw new RuntimeException('The uploaded image could not be verified.');
        }
    }

    private function assertPackage(UploadedFile $file): void
    {
        if (!$file->isValid()) {
            throw new RuntimeException('The application package upload is invalid.');
        }
        if ((int) $file->getSize() > self::MAX_PACKAGE_BYTES) {
            throw new RuntimeException('Application package exceeds the 1 GB production limit.');
        }

        $extension = strtolower($file->getClientOriginalExtension());
        if (!in_array($extension, ['apk', 'aab', 'zip'], true)) {
            throw new RuntimeException('Application package must be APK, AAB or ZIP.');
        }
    }

    private function storeOptimizedImage(UploadedFile $file, string $directory, string $prefix): array
    {
        $originalSize = (int) $file->getSize();
        $target = null;
        $width = null;
        $height = null;

        if (function_exists('imagecreatefromstring') && function_exists('imagewebp')) {
            $raw = @file_get_contents($file->getRealPath());
            $source = $raw !== false ? @imagecreatefromstring($raw) : false;
            if ($source !== false) {
                $width = imagesx($source);
                $height = imagesy($source);
                if ($width > self::IMAGE_MAX_WIDTH) {
                    $newWidth = self::IMAGE_MAX_WIDTH;
                    $newHeight = (int) round($height * ($newWidth / $width));
                    $canvas = imagecreatetruecolor($newWidth, $newHeight);
                    imagealphablending($canvas, false);
                    imagesavealpha($canvas, true);
                    imagecopyresampled($canvas, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                    imagedestroy($source);
                    $source = $canvas;
                    $width = $newWidth;
                    $height = $newHeight;
                }

                $tmp = tempnam(sys_get_temp_dir(), 'egc_portal_img_');
                if ($tmp) {
                    if (@imagewebp($source, $tmp, self::IMAGE_QUALITY)) {
                        $target = $tmp;
                    } else {
                        @unlink($tmp);
                    }
                }
                imagedestroy($source);
            }
        }

        if ($target) {
            $path = $directory . '/' . Str::uuid()->toString() . '_' . $prefix . '.webp';
            Storage::disk('public')->put($path, file_get_contents($target));
            @unlink($target);
        } else {
            $extension = strtolower($file->getClientOriginalExtension()) ?: 'bin';
            $path = $file->storeAs($directory, Str::uuid()->toString() . '_' . $prefix . '.' . $extension, 'public');
            $info = @getimagesize($file->getRealPath());
            $width = $width ?: ($info[0] ?? null);
            $height = $height ?: ($info[1] ?? null);
        }

        return [
            'path' => $path,
            'original_size' => $originalSize,
            'stored_size' => (int) Storage::disk('public')->size($path),
            'mime' => Storage::disk('public')->mimeType($path) ?: 'image/webp',
            'width' => $width,
            'height' => $height,
            'sha256' => hash('sha256', Storage::disk('public')->get($path)),
        ];
    }

    private function tryCompressZip(UploadedFile $file, string $directory, string $safeName): ?array
    {
        if (!class_exists(ZipArchive::class)) return null;

        $source = new ZipArchive();
        if ($source->open($file->getRealPath()) !== true) return null;

        $total = 0;
        $entries = [];
        for ($i = 0; $i < $source->numFiles; $i++) {
            $stat = $source->statIndex($i);
            if (!$stat) {
                $source->close();
                return null;
            }
            $name = (string) ($stat['name'] ?? '');
            if ($this->unsafeZipEntryName($name)) {
                $source->close();
                throw new RuntimeException('The ZIP contains an unsafe file path.');
            }
            $size = (int) ($stat['size'] ?? 0);
            $total += $size;
            if ($total > self::MAX_REPACK_BYTES || $size > self::MAX_REPACK_ENTRY_BYTES) {
                $source->close();
                return null;
            }
            $entries[] = [$i, $name, $size];
        }

        $tmp = tempnam(sys_get_temp_dir(), 'egc_portal_zip_');
        if (!$tmp) {
            $source->close();
            return null;
        }
        @unlink($tmp);

        $target = new ZipArchive();
        if ($target->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            $source->close();
            return null;
        }

        foreach ($entries as [$index, $name, $size]) {
            $isDir = str_ends_with($name, '/');
            if ($isDir) {
                $target->addEmptyDir($name);
                continue;
            }
            $content = $source->getFromIndex($index);
            if ($content === false) {
                $target->close();
                $source->close();
                @unlink($tmp);
                return null;
            }
            $target->addFromString($name, $content);
            $target->setCompressionName($name, ZipArchive::CM_DEFLATE, 9);
        }

        $target->close();
        $source->close();

        if (!is_file($tmp)) return null;
        $compressedSize = filesize($tmp) ?: 0;
        if ($compressedSize <= 0 || $compressedSize >= (int) $file->getSize()) {
            @unlink($tmp);
            return null;
        }

        $path = $directory . '/' . $safeName . '.zip';
        Storage::disk('public')->put($path, file_get_contents($tmp));
        $sha256 = hash('sha256', Storage::disk('public')->get($path));
        @unlink($tmp);

        return [
            'path' => $path,
            'stored_size' => (int) Storage::disk('public')->size($path),
            'sha256' => $sha256,
        ];
    }

    private function unsafeZipEntryName(string $name): bool
    {
        if ($name === '' || str_starts_with($name, '/') || str_starts_with($name, '\\')) return true;
        $normalized = str_replace('\\', '/', $name);
        return in_array('..', explode('/', $normalized), true);
    }
}
