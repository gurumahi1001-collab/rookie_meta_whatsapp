# Portals & Apps — production deployment

## Files included

- `app/Http/Controllers/productivity/PortalAppController.php`
- `app/Models/Productivity/PortalApp.php`
- `app/Models/Productivity/PortalAppVersion.php`
- `app/Models/Productivity/PortalAppMedia.php`
- `app/Services/Productivity/PortalAppUploadService.php`
- `resources/views/content/productivity/portals/index.blade.php`
- `database/migrations/2026_09_26_000001_upgrade_portal_apps_uploads.php`
- `database/2026_09_26_portal_apps_upload_upgrade.sql`
- `routes/web.php` plus `routes_portals_apps.patch.txt`

The update is isolated to Portals & Apps. BookMarks, Credit Card, shared layout, shared access service and unrelated menu controllers are not modified.

## What this adds

- BookMarks-style frontend organization: config/routes, state, AJAX helper, skeleton/error handling, render/load/open functions and delegated events.
- Optional Portal/App link fields. Only App Name and Platform are required for the registry record; URL, company, owner, purpose, icon, screenshots, credential reference and release package are optional.
- Portal link icon lookup uses the existing ERP BookMarks favicon service/endpoint instead of a third-party favicon proxy.
- App icon preview and up to 8 screenshot previews before submission.
- APK/AAB/ZIP release uploads with browser-side validation and real XHR upload progress.
- Safe ZIP source-bundle recompression where possible. APK/AAB binaries are deliberately not recompressed because modifying a signed Android package can invalidate its signature.
- Release/version records support change type, What’s New, Bug Fixes, release notes, build number, package metadata, screenshots and optional upload.
- `current_version_json` stores the API-ready current release object containing `app_name`, `version`, `app_path_url` and additional release metadata.
- Current-version JSON endpoint and package download endpoint.
- Existing launch, subscribe, credential, sharing and XLSX export behavior remains AJAX-driven.

## Database

Run the SQL once OR run the Laravel migration, not both:

```bash
php artisan migrate --path=database/migrations/2026_09_26_000001_upgrade_portal_apps_uploads.php
```

The SQL patch is provided for controlled production/manual database deployment.

The change makes `egc_tool_portal_apps.app_url` nullable, adds `current_version_json`, adds release/package metadata to `egc_tool_portal_app_versions`, and creates `egc_tool_portal_app_media` for screenshots/media.

## Large-upload server configuration

Application validation allows files up to 1 GB, so the web stack must allow the same or a slightly larger request body. Example PHP settings:

```ini
upload_max_filesize=1024M
post_max_size=1100M
max_execution_time=900
max_input_time=900
memory_limit=512M
```

For Nginx, set an appropriate `client_max_body_size` (for example `1100m`) at the applicable site/location. Apache and proxy/load-balancer body limits must be raised similarly.

`ZipArchive` is used for safe ZIP recompression when available. GD is used for image-to-WebP optimization when available. When those extensions are unavailable, the service keeps the original supported media rather than failing the release.

## Upload safety

- APK/AAB are stored without byte-level recompression to preserve signing.
- ZIP recompression is bounded and rejects unsafe archive paths.
- Image uploads are type/size checked and optimized when GD is available.
- Release downloads pass through the authenticated controller permission check.
- Portal/App read/manage visibility continues to use the existing Productivity access model.

## Cache clear

After deployment:

```bash
php artisan optimize:clear
```

## Validation

The package was statically checked for PHP syntax, portal inline JavaScript syntax, route/controller contract consistency, and ZIP integrity. Live upload behavior still needs to be exercised on the production/staging server because maximum request sizes, PHP extensions, storage disk configuration and the live database are environment-specific.
