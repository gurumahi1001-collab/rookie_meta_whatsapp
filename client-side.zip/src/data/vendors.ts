export interface Vendor {
    id: string;
    initial: string;
    name: string;
    tagline: string;
    trn: string;
    category: string;
    currency: string;
    status:  | "PENDING"  | "APPROVED"  | "REJECTED"   | "DEACTIVE";
    contactName: string;
    contactRole: string;
    email: string;
    phone: string;
    locations: string;
    paymentTerms: string;
    creditLimit: string;
    bankInformation: VendorBankInformation;
}

export const VENDORS: Vendor[] = [
    {
        id: "v1",
        initial: "S",
        name: "Seiretsu JA Ltd",
        tagline: "Fibre Network Infrastructure",
        trn: "102-394-881",
        category: "Telecommunications",
        currency: "USD",
        status: "PENDING",
        contactName: "Marcus Sterling",
        contactRole: "VP of Network Infrastructure",
        email: "m.sterling@seiretsu.co.jm",
        phone: "+1 (876) 920-4100",
        locations:
            "Spalding Node 1 • Mandeville Trunk Route • Christiana Loop",
        paymentTerms: "Net 30 Days",
        creditLimit: "$250,000 USD",

        bankInformation: {
            bankName: "National Commercial Bank Jamaica",
            branch: "Mandeville Branch",
            accountHolderName: "Seiretsu JA Ltd",
            accountNumber: "00123456789",
            ifscCode: "NCBJ0001234",
            swiftCode: "JNCBJMKX",
        },
    },

    {
        id: "v2",
        initial: "F",
        name: "Flow Jamaica (C&W Cable & Wireless)",
        tagline: "Broadband & Carrier Infrastructure",
        trn: "001-827-902",
        category: "Telecommunications",
        currency: "USD",
        status: "APPROVED",
        contactName: "Rohan Patterson",
        contactRole: "Head of OSP Planning",
        email: "rohan.patterson@cwc.com",
        phone: "+1 (876) 926-1100",
        locations:
            "Kingston Corporate Area • Portmore Trunk",
        paymentTerms: "Net 45 Days",
        creditLimit: "$500,000 USD",

        bankInformation: {
            bankName: "Scotiabank Jamaica",
            branch: "Kingston Main Branch",
            accountHolderName:
                "Flow Jamaica (C&W Cable & Wireless)",
            accountNumber: "00234567890",
            ifscCode: "SCOT0002345",
            swiftCode: "NOSCJMKN",
        },
    },

    {
        id: "v3",
        initial: "C",
        name: "City Council - Kingston & St. Andrew Corporation",
        tagline: "Municipal & Smart Infrastructure",
        trn: "000-112-998",
        category: "Government",
        currency: "JMD",
        status: "DEACTIVE",
        contactName: "Dr. Evelyn Grant",
        contactRole: "Chief Technology Officer",
        email: "e.grant@ksac.gov.jm",
        phone: "+1 (876) 922-2580",
        locations:
            "Downtown Waterfront • New Kingston Loop • Cross Roads Junction",
        paymentTerms: "Net 60 Days",
        creditLimit: "$35,000,000 JMD",

        bankInformation: {
            bankName: "Bank of Nova Scotia Jamaica",
            branch: "New Kingston Branch",
            accountHolderName:
                "Kingston & St. Andrew Corporation",
            accountNumber: "00345678901",
            ifscCode: "BNSJ0003456",
            swiftCode: "NOSCJMKN",
        },
    },

    {
        id: "v4",
        initial: "D",
        name: "Digicel Metro Networks",
        tagline: "High Speed Optical Access",
        trn: "204-881-301",
        category: "ISP",
        currency: "USD",
        status: "APPROVED",
        contactName: "Nigel Clarke",
        contactRole: "Director of Network Engineering",
        email: "n.clarke@digicelgroup.com",
        phone: "+1 (876) 619-0000",
        locations:
            "Montego Bay Commercial Zone • Ocho Rios Resort Ring",
        paymentTerms: "Net 30 Days",
        creditLimit: "$300,000 USD",

        bankInformation: {
            bankName: "Jamaica National Bank",
            branch: "Montego Bay Branch",
            accountHolderName: "Digicel Metro Networks",
            accountNumber: "00456789012",
            ifscCode: "JNBS0004567",
            swiftCode: "JNBKJMKN",
        },
    },
];


export interface VendorBankInformation {
    bankName: string;
    branch: string;
    accountHolderName: string;
    accountNumber: string;
    ifscCode: string;
    swiftCode: string;
}
export interface VendorProfileStats {
    totalProjects: number;
    activeProjects: number;

    approvedQuotations: number;
    totalQuotations: number;
    approvedQuotationValue: number;

    totalInvoices: number;
    pendingInvoices: number;

    outstandingPayments: number;
}

export const VENDOR_PROFILE_STATS: Record<string, VendorProfileStats> = {
    v1: {
        totalProjects: 1,
        activeProjects: 1,

        approvedQuotations: 0,
        totalQuotations: 1,
        approvedQuotationValue: 0,

        totalInvoices: 2,
        pendingInvoices: 1,

        outstandingPayments: 42500,
    },

    v2: {
        totalProjects: 3,
        activeProjects: 2,

        approvedQuotations: 2,
        totalQuotations: 4,
        approvedQuotationValue: 87500,

        totalInvoices: 5,
        pendingInvoices: 2,

        outstandingPayments: 18500,
    },

    v3: {
        totalProjects: 4,
        activeProjects: 3,

        approvedQuotations: 2,
        totalQuotations: 5,
        approvedQuotationValue: 12500000,

        totalInvoices: 7,
        pendingInvoices: 2,

        outstandingPayments: 3250000,
    },

    v4: {
        totalProjects: 2,
        activeProjects: 1,

        approvedQuotations: 1,
        totalQuotations: 3,
        approvedQuotationValue: 42000,

        totalInvoices: 3,
        pendingInvoices: 1,

        outstandingPayments: 12000,
    },
};
