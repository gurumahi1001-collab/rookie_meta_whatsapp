import { BOQSection, SelectOption } from "../types/projectBOQ";

export const CATEGORY_TYPES: SelectOption[] = [
    {
        value: "Project Milestone",
        label: "Project Milestone",
    },
    {
        value: "Material Specifications",
        label: "Material Specifications",
    },
    {
        value: "Technical Services",
        label: "Technical Services",
    },
];

export const VENDOR_OPTIONS: SelectOption[] = [
    {
        value: "Seiretsu JA Ltd",
        label: "Seiretsu JA Ltd",
    },
    {
        value: "Caribbean Fiber Solutions",
        label: "Caribbean Fiber Solutions",
    },
    {
        value: "Kingston Telecom Services",
        label: "Kingston Telecom Services",
    },
    {
        value: "Island Network Infrastructure",
        label: "Island Network Infrastructure",
    },
];

export const UNIT_OPTIONS: SelectOption[] = [
    {
        value: "Unit",
        label: "Unit",
    },
    {
        value: "Meter",
        label: "Meter",
    },
    {
        value: "SqM",
        label: "SqM",
    },
    {
        value: "Each",
        label: "Each",
    },
    {
        value: "Hour",
        label: "Hour",
    },
    {
        value: "Day",
        label: "Day",
    },
    {
        value: "Km",
        label: "Km",
    },
    {
        value: "Lot",
        label: "Lot",
    },
    {
        value: "Site",
        label: "Site",
    },
];

export const BOQ_SECTIONS: BOQSection[] = [
    {
        id: 1,
        title: "Project Milestones & Civil Infrastructure",
        color: "bg-red-600",
        categoryType: "Project Milestone",
        category: "Civil Works",
    },
    {
        id: 2,
        title: "Material Specifications & Fiber Equipment",
        color: "bg-emerald-600",
        categoryType: "Material Specifications",
        category: "Fiber Optics",
    },
    {
        id: 3,
        title: "Technical Services & Human Resources",
        color: "bg-sky-600",
        categoryType: "Technical Services",
        category: "Technical Services",
    },
];


