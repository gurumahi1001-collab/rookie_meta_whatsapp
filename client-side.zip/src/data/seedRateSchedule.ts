import { RateItem } from "../types/rateSchedule";

export const CATEGORIES = [
    "Civil Works",
    "Permitting & Logistics",
    "Fiber Optics",
    "Hardware & Active Gears",
    "Materials",
    "Splicing & Testing",
    "Engineering Services",
    "Labour",
    "Services",
];

export const CAT_TYPES = [
    "Project Milestone",
    "Material Specifications",
    "Technical Services",
];

export const UNITS = [
    "Meter",
    "SqM",
    "Each",
    "Hour",
    "Day",
    "Km",
    "Site",
];

const seedRow = (
    subcategory: string,
    code: string,
    category: string,
    categoryType: string,
    description: string,
    unit: string,
    rate: number,
    effectiveDate: string
): RateItem => ({
    id: code,
    code,

    subcategory, // IMPORTANT

    category,
    categoryType,
    description,
    unit,

    standardRate: rate,
    effectiveDate,

    status: "active",

    history: [
        {
            rate,
            effectiveDate,
            updatedAt: effectiveDate,
            updatedBy: "System Import",
        },
    ],
    rate: 0,
    module: ""
});

export const initialRateData: RateItem[] = [
    // Civil Works
    seedRow("Trenching","C-001", "Civil Works", "Project Milestone","Trenching in Soft Soil (450mm depth)","Meter",1200,"2024-03-25"),
    seedRow("Trenching","C-002","Civil Works","Project Milestone","Trenching in Rock/Concrete (450mm depth)","Meter",3500,"2024-03-25"),
    seedRow("Reinstatement","C-004","Civil Works","Project Milestone","Concrete Reinstatement (Standard Mix)","SqM",4500,"2024-03-25"),
    seedRow("Backfilling","C-005","Civil Works","Project Milestone","Backfilling & Compaction","Meter",400,"2024-03-25"),
    // Fiber Optics
    seedRow("Fiber Cable Installation","F-001","Fiber Optics","Material Specifications","Supply & Installation of 48-Core ADSS Fiber","Meter",850,"2024-03-25"),
    seedRow("Fiber Cable Installation","F-002","Fiber Optics","Material Specifications","Supply & Installation of 96-Core ADSS Fiber","Meter",1450,"2024-03-25"),
    seedRow("Fiber Splicing","F-003","Fiber Optics","Material Specifications","Fusion Splicing (Per Core)","Each",450,"2024-03-25"),
    seedRow("Fiber Testing","F-004","Fiber Optics","Material Specifications","OTDR Trace & Certification","Each",2500,"2024-03-25"),
    // Labour
    seedRow("Skilled Labour","L-001","Labour","Technical Services","Skilled Technician (Fiber Splicing)","Hour",2500,"2024-03-25"),
    seedRow("General Labour","L-002","Labour","Technical Services","General Labourer (Trenching/Backfill)","Hour",850,"2024-03-25"),
    // =========================
    // Hardware & Active Gears
    // =========================
    seedRow(
        "OLT Installation",
        "E-001",
        "Hardware & Active Gears",
        "Material Specifications",
        "Installation of OLT Rack",
        "Each",
        15000,
        "2024-03-25"
    ),

    seedRow(
        "Heavy Equipment",
        "E-005",
        "Hardware & Active Gears",
        "Material Specifications",
        "JCB Backhoe Loader (with Operator)",
        "Hour",
        8500,
        "2024-03-25"
    ),

    // =========================
    // Materials
    // =========================
    seedRow(
        "Fiber Cable",
        "M-001",
        "Materials",
        "Material Specifications",
        "48-Core ADSS Fiber Optic Cable",
        "Meter",
        450,
        "2024-03-25"
    ),

    seedRow(
        "Distribution Equipment",
        "M-003",
        "Materials",
        "Material Specifications",
        "Fiber Distribution Hub (144 Port)",
        "Each",
        125000,
        "2024-03-25"
    ),

    // =========================
    // Services
    // =========================
    seedRow(
        "Site Survey",
        "S-001",
        "Services",
        "Technical Services",
        "Topographical Site Survey",
        "Km",
        45000,
        "2024-03-25"
    ),
];

export const todayIso = (): string =>
    new Date().toISOString().slice(0, 10);

export const fmtJmd = (n: number): string =>
    `J$${Number(n).toLocaleString()}`;
