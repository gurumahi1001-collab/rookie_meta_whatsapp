import React, { useEffect, useRef, useState } from 'react';

interface FileUploadProps {
    multiple?: boolean;
    accept?: string;
    value?: File[];
    onChange?: (files: File[]) => void;
    className?: string;
}

const FileUpload: React.FC<FileUploadProps> = ({
    multiple = false,
    accept = 'image/*',
    value = [],
    onChange,
    className = '',
}) => {
    const inputRef = useRef<HTMLInputElement>(null);

    const [files, setFiles] = useState<File[]>(value);

    useEffect(() => {
        setFiles(value);
    }, [value]);

    const handleFileChange = (
        e: React.ChangeEvent<HTMLInputElement>
    ) => {
        const selectedFiles = Array.from(e.target.files || []);

        if (!selectedFiles.length) return;

        const newFiles = multiple
            ? [...files, ...selectedFiles]
            : [selectedFiles[0]];

        setFiles(newFiles);
        onChange?.(newFiles);

        // Allows selecting the same file again
        if (inputRef.current) {
            inputRef.current.value = '';
        }
    };

    const removeFile = (index: number) => {
        const updatedFiles = files.filter((_, i) => i !== index);

        setFiles(updatedFiles);
        onChange?.(updatedFiles);
    };

    const openFilePicker = () => {
        inputRef.current?.click();
    };

    return (
        <div className={`flex flex-wrap gap-3 ${className}`}>

            {/* Upload Button */}
            <div
                onClick={openFilePicker}
                className="
                    flex h-16 w-16 shrink-0 cursor-pointer
                    items-center justify-center
                    rounded-xl border-2 border-dashed
                    border-slate-300
                    text-center text-[11px]
                    font-medium leading-tight
                    text-slate-400
                    transition
                    hover:border-primary
                    hover:text-primary
                "
            >
                <input
                    ref={inputRef}
                    type="file"
                    accept={accept}
                    multiple={multiple}
                    onChange={handleFileChange}
                    className="hidden"
                />

                Upload
                <br />
                File
            </div>

            {/* File Previews */}
            {files.map((file, index) => (
                <div
                    key={`${file.name}-${index}`}
                    className="
                        relative h-16 w-16
                        overflow-hidden rounded-xl
                        border border-slate-200
                        bg-slate-50
                    "
                >
                    {file.type.startsWith('image/') ? (
                        <img
                            src={URL.createObjectURL(file)}
                            alt={file.name}
                            className="h-full w-full object-contain"
                        />
                    ) : (
                        <div className="
                            flex h-full w-full
                            items-center justify-center
                            px-1 text-center
                            text-[9px] text-slate-500
                        ">
                            {file.name}
                        </div>
                    )}

                    {/* Remove */}
                    <button
                        type="button"
                        onClick={() => removeFile(index)}
                        className="
                            absolute right-0.5 top-0.5
                            flex h-4 w-4
                            items-center justify-center
                            rounded-full
                            bg-red-500
                            text-[10px] text-white
                        "
                    >
                        ×
                    </button>
                </div>
            ))}
        </div>
    );
};

export default FileUpload;