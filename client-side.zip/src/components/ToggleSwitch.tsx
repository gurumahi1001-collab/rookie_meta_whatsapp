export interface ToggleSwitchProps {
    checked: boolean;
    onChange: (checked: boolean) => void;
    disabled?: boolean;
    /** Accessible name — no visible label is rendered, so always pass something descriptive. */
    srLabel: string;
}

export default function ToggleSwitch({
    checked,
    onChange,
    disabled = false,
    srLabel,
}: ToggleSwitchProps) {
    return (
        <button
            type="button"
            role="switch"
            aria-checked={checked}
            aria-label={srLabel}
            disabled={disabled}
            onClick={() => onChange(!checked)}
            className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors duration-200 ease-in-out disabled:cursor-not-allowed disabled:opacity-50 ${checked ? "bg-red-600" : "bg-slate-300"
                }`}
        >
            <span
                className={`inline-block h-[18px] w-[18px] transform rounded-full bg-white shadow transition-transform duration-200 ease-in-out ${checked ? "translate-x-[22px]" : "translate-x-[3px]"
                    }`}
            />
        </button>
    );
}