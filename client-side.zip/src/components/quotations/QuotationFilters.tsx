import {
    MagnifyingGlassIcon,
    SquaresFourIcon,
    ListIcon,
} from "@phosphor-icons/react";

import Select, {
    type SingleValue,
    type StylesConfig,
} from "react-select";

/* TYPES */

interface SelectOption {
    value: string;
    label: string;
}

interface QuotationFiltersProps {
    query: string;
    setQuery: (value: string) => void;

    vendor: string;
    setVendor: (value: string) => void;

    
    // setStage: (value: string) => void;

    status: string;
    setStatus: (value: string) => void;

    view: "list" | "card";
    setView: (value: "list" | "card") => void;

    vendors: string[];
    
}

/* STATUS OPTIONS */

const statuses = [
    "All Statuses",
    "Draft",
    "Issued",
    "Form Issued",
    "Form Approved",
    "Form Submitted",
    "Form Rejected",
    "Rejected",
    "Awarded",
    "Not Responded",
    "Submitted",
    "Submitted",
];

/* REACT SELECT STYLES */

const getSelectStyles = (): StylesConfig<SelectOption, false> => ({
    control: (base, state) => ({
        ...base,

        minHeight: "42px",
        height: "42px",

        borderRadius: "8px",

        borderColor: state.isFocused
            ? "#fca5a5"
            : "#e2e8f0",

        backgroundColor: state.isFocused
            ? "#ffffff"
            : "#f8fafc",

        boxShadow: state.isFocused
            ? "0 0 0 1px #fca5a5"
            : "none",

        cursor: "pointer",

        "&:hover": {
            borderColor: "#fca5a5",
        },
    }),

    valueContainer: (base) => ({
        ...base,
        padding: "0 12px",
    }),

    singleValue: (base) => ({
        ...base,
        color: "#475569",
        fontSize: "14px",
        fontWeight: 400,
    }),

    placeholder: (base) => ({
        ...base,
        color: "#94a3b8",
        fontSize: "14px",
    }),

    input: (base) => ({
        ...base,
        color: "#334155",
        fontSize: "14px",
    }),

    indicatorSeparator: () => ({
        display: "none",
    }),

    dropdownIndicator: (base, state) => ({
        ...base,

        color: state.isFocused
            ? "#ef4444"
            : "#94a3b8",

        paddingRight: "10px",

        "&:hover": {
            color: "#ef4444",
        },
    }),

    menu: (base) => ({
        ...base,

        marginTop: "4px",

        borderRadius: "8px",

        overflow: "hidden",

        border: "1px solid #e2e8f0",

        boxShadow:
            "0 10px 25px rgba(15, 23, 42, 0.08)",

        zIndex: 50,
    }),

    menuList: (base) => ({
        ...base,
        padding: "4px",
    }),

    option: (base, state) => ({
        ...base,

        borderRadius: "6px",

        padding: "9px 10px",

        fontSize: "13px",

        cursor: "pointer",

        color: state.isSelected
            ? "#b91c1c"
            : "#475569",

        backgroundColor: state.isSelected
            ? "#fef2f2"
            : state.isFocused
                ? "#f8fafc"
                : "#ffffff",

        "&:active": {
            backgroundColor: "#fef2f2",
        },
    }),
});

/* COMPONENT */

const QuotationFilters = ({
    query,
    setQuery,

    vendor,
    setVendor,

    status,
    setStatus,

    view,
    setView,

    vendors,

}: QuotationFiltersProps) => {

    /* VENDOR OPTIONS */

    const vendorOptions: SelectOption[] = [
        {
            value: "All Vendors",
            label: "All Vendors",
        },

        ...vendors
            .filter((vendor) => vendor !== "All Vendors")
            .map((vendor) => ({
                value: vendor,
                label: vendor,
            })),
    ];

    /* WORKFLOW STAGE OPTIONS */



    /* STATUS OPTIONS */

    const statusOptions: SelectOption[] = statuses.map(
        (statusItem) => ({
            value: statusItem,
            label: statusItem,
        })
    );

    /* SELECTED VENDOR  */

    const selectedVendor =
        vendorOptions.find(
            (option) => option.value === vendor
        ) ??
        vendorOptions.find(
            (option) => option.value === "All Vendors"
        ) ??
        null;

    /* SELECTED STAGE */

    // const selectedStage =
    //     stageOptions.find(
    //         (option) => option.value === stage
    //     ) ??
    //     stageOptions.find(
    //         (option) => option.value === "All Stages"
    //     ) ??
    //     null;

    /* SELECTED STATUS

       Internally:
       "" = All Statuses

       UI:
       "All Statuses"  */

    const selectedStatus =
        status === ""
            ? statusOptions.find(
                (option) =>
                    option.value === "All Statuses"
            ) ?? null
            : statusOptions.find(
                (option) =>
                    option.value === status
            ) ?? null;

    /* VENDOR CHANGE */

    const handleVendorChange = (
        option: SingleValue<SelectOption>
    ) => {

        setVendor(
            option?.value ?? "All Vendors"
        );
    };

    /* STAGE CHANGE */

    const handleStageChange = (
        option: SingleValue<SelectOption>
    ) => {

        // setStage(
        //     option?.value ?? "All Stages"
        // );
    };

    /* STATUS CHANGE */

    const handleStatusChange = (
        option: SingleValue<SelectOption>
    ) => {

        /*
         * "All Statuses" means no status filter.
         */

        if (
            !option ||
            option.value === "All Statuses"
        ) {
            setStatus("");
            return;
        }

        setStatus(option.value);
    };

    /* RENDER */

    return (
        <div className="mb-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
                {/* SEARCH */}
                <div className="relative min-w-0 flex-1">
                    <MagnifyingGlassIcon
                        size={16}
                        weight="regular"
                        className="pointer-events-none absolute left-3.5 top-1/2 z-10 -translate-y-1/2 text-slate-400"
                    />
                    <input
                        type="text"
                        value={query}
                        onChange={(event) =>
                            setQuery(event.target.value)
                        }
                        placeholder="Search quote #, project or vendor..."
                        className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2.5 pl-10 pr-3 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-300 focus:bg-white"
                    />

                </div>

                {/* FILTERS */}

                <div className="flex flex-wrap items-center gap-2">

                    {/* VENDOR */}

                    <div className="w-full sm:w-[180px]">

                        <Select<SelectOption, false>
                            options={vendorOptions}
                            value={selectedVendor}
                            onChange={handleVendorChange}
                            placeholder="All Vendors"
                            styles={getSelectStyles()}
                            isSearchable
                            isClearable={false}
                            menuPlacement="auto"
                        />

                    </div>

                    {/* WORKFLOW STAGE */}

                    {/* <div className="w-full sm:w-[180px]">
                        <Select<SelectOption, false>
                            options={stageOptions}
                            value={selectedStage}
                            onChange={handleStageChange}
                            placeholder="All Stages"
                            styles={getSelectStyles()}
                            isSearchable={false}
                            isClearable={false}
                            menuPlacement="auto"
                        />
                    </div> */}

                    {/* STATUS */}
                    <div className="w-full sm:w-[190px]">
                        <Select<SelectOption, false>
                            options={statusOptions}
                            value={selectedStatus}
                            onChange={handleStatusChange}
                            placeholder="All Statuses"
                            styles={getSelectStyles()}
                            isSearchable={false}
                            isClearable={false}
                            menuPlacement="auto"
                        />

                    </div>
                </div>
            </div>
        </div>
    );
};

export default QuotationFilters;
