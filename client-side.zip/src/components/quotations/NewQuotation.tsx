import {
    useMemo,
    useState,
    useEffect,
    useRef,
} from "react";

import { ArrowLeftIcon, CheckIcon, DownloadSimpleIcon, FilePdfIcon, FileTextIcon, PlusIcon, TrashIcon, XIcon } from "@phosphor-icons/react";
import Select, { SingleValue, StylesConfig } from "react-select";
import { useLocation, useNavigate } from "react-router-dom";
import DataTable from "../DataTable";
import { VENDORS, Vendor } from "../../data/vendors";
import { CATEGORIES } from "../../data/seedRateSchedule";
import { Quotation, QuotationStatus, WorkflowStage } from "../../types/quotation";
import { ProjectBOQQuotation, quotations } from "../../data/quotations";

interface NewQuotationProps {
    onBack: () => void;
    onOpenMasterRate: () => void;
}

interface EditQuotationLocationState {
    quotation?: ProjectBOQQuotation;
}

export interface BOQRow {
    id: number;
    module: string;
    section: number;
    category: string;
    description: string;
    quantity: number;
    uom: string;
    materialCost: number;
    serviceCost: number;
    salesPrice: number;
    gct: number;

    totalInstallments: number;
    pendingInstallments: number;
    invoicesGenerated: number;
    invoicesPaid: number;
    balanceAmount: number;
}

interface ValidityOption {
    value: string;
    label: string;
}

interface VendorOption {
    value: string;
    label: string;
    vendor: Vendor;
}

interface BOQSection {
    id: number;
    title: string;
}

interface PaymentInstallment {
    id: string;
    name: string;
    amount: number;
    type: "advance" | "balance";
    dueDate: string;
    modules: PaymentOptions[];
    days: number[];
    installmentName: string;
}

interface PaymentScheduleForm {
    id: number;
    installmentName: string;
    modules: string[];
    amount: string;
    days: number[];
}

interface SavedPaymentSchedule {
    id: number;
    installments: PaymentScheduleForm[];
    savedAt: string;
}



type UploadedDocument = {
    id: string;
    name: string;
    type: string;
    size: number;
    file: File;
};

type PaymentOptions = {
    label: string;
    value: string;
};


type FormTemplateOption = {
    value: string;
    label: string;
};

const CURRENCY = "USD";

const validityOptions: ValidityOption[] = [
    { value: "15", label: "15 - Calendar Days" },
    { value: "30", label: "30 - Calendar Days" },
    { value: "60", label: "60 - Calendar Days" },
    { value: "90", label: "90 - Calendar Days" },
];

const boqSections: BOQSection[] = [
    { id: 1, title: "Project Milestones & Civil Infrastructure" },
    { id: 2, title: "Material Specifications & Fiber Equipment" },
    { id: 3, title: "Technical Services & Human Resources" },
];

const documentTypeOptions = [
    {
        value: "Contract",
        label: "Contract",
    },
    {
        value: "Quotation",
        label: "Quotation",
    },
    {
        value: "Invoice",
        label: "Invoice",
    },
    {
        value: "Technical Document",
        label: "Technical Document",
    },
    {
        value: "Drawing",
        label: "Drawing",
    },
    {
        value: "Specification",
        label: "Specification",
    },
    {
        value: "Other",
        label: "Other",
    },
];

const validitySelectStyles: StylesConfig<ValidityOption, false> = {
    control: (base, state) => ({
        ...base,
        minHeight: "42px",
        height: "42px",
        borderRadius: "8px",
        borderColor: state.isFocused ? "#fca5a5" : "#e2e8f0",
        backgroundColor: state.isFocused ? "#ffffff" : "#f8fafc",
        boxShadow: state.isFocused ? "0 0 0 1px #fca5a5" : "none",
        cursor: "pointer",
        "&:hover": {
            borderColor: "#fca5a5",
        },
    }),
    valueContainer: (base) => ({ ...base, padding: "0 12px" }),
    singleValue: (base) => ({ ...base, color: "#475569", fontSize: "14px" }),
    placeholder: (base) => ({ ...base, color: "#94a3b8", fontSize: "14px" }),
    indicatorSeparator: () => ({ display: "none" }),
    dropdownIndicator: (base, state) => ({
        ...base,
        color: state.isFocused ? "#ef4444" : "#94a3b8",
        paddingRight: "10px",
        "&:hover": {
            color: "#ef4444",
        },
    }),
    menu: (base) => ({
        ...base,
        marginTop: "4px",
        borderRadius: "8px",
        overflow: "hidden",
        border: "1px solid #e2e8f0",
        boxShadow: "0 10px 25px rgba(15, 23, 42, 0.08)",
        zIndex: 9999,
    }),
    menuList: (base) => ({ ...base, padding: "4px" }),
    option: (base, state) => ({
        ...base,
        borderRadius: "6px",
        padding: "9px 10px",
        fontSize: "13px",
        cursor: "pointer",
        color: state.isSelected ? "#b91c1c" : "#475569",
        backgroundColor: state.isSelected ? "#fef2f2" : state.isFocused ? "#f8fafc" : "#ffffff",
        "&:active": {
            backgroundColor: "#fef2f2",
        },
    }),
};

const vendorSelectStyles: StylesConfig<VendorOption, false> = {
    control: (base, state) => ({
        ...base,
        minHeight: "42px",
        height: "42px",
        borderRadius: "8px",
        borderColor: state.isFocused ? "#fca5a5" : "#e2e8f0",
        backgroundColor: state.isFocused ? "#ffffff" : "#f8fafc",
        boxShadow: state.isFocused ? "0 0 0 1px #fca5a5" : "none",
        cursor: "pointer",
        "&:hover": {
            borderColor: "#fca5a5",
        },
    }),
    valueContainer: (base) => ({ ...base, padding: "0 12px" }),
    singleValue: (base) => ({ ...base, color: "#475569", fontSize: "14px" }),
    placeholder: (base) => ({ ...base, color: "#94a3b8", fontSize: "14px" }),
    input: (base) => ({ ...base, color: "#475569", fontSize: "14px" }),
    indicatorSeparator: () => ({ display: "none" }),
    dropdownIndicator: (base, state) => ({
        ...base,
        color: state.isFocused ? "#ef4444" : "#94a3b8",
        paddingRight: "10px",
        "&:hover": {
            color: "#ef4444",
        },
    }),
    clearIndicator: (base) => ({
        ...base,
        color: "#94a3b8",
        "&:hover": {
            color: "#ef4444",
        },
    }),
    menu: (base) => ({
        ...base,
        marginTop: "4px",
        borderRadius: "8px",
        overflow: "hidden",
        border: "1px solid #e2e8f0",
        boxShadow: "0 10px 25px rgba(15, 23, 42, 0.08)",
        zIndex: 9999,
    }),
    menuList: (base) => ({
        ...base,
        padding: "4px",
        maxHeight: "240px",
    }),
    option: (base, state) => ({
        ...base,
        borderRadius: "6px",
        padding: "9px 10px",
        fontSize: "13px",
        cursor: "pointer",
        color: state.isSelected ? "#b91c1c" : "#475569",
        backgroundColor: state.isSelected ? "#fef2f2" : state.isFocused ? "#f8fafc" : "#ffffff",
        "&:active": {
            backgroundColor: "#fef2f2",
        },
    }),
};

const formTemplateSelectStyles: StylesConfig<FormTemplateOption, false> = {
    control: (base, state) => ({
        ...base,
        minHeight: "42px",
        height: "42px",
        borderRadius: "8px",
        borderColor: state.isFocused ? "#fca5a5" : "#e2e8f0",
        backgroundColor: state.isFocused ? "#ffffff" : "#f8fafc",
        boxShadow: state.isFocused ? "0 0 0 1px #fca5a5" : "none",
        cursor: "pointer",
        "&:hover": {
            borderColor: "#fca5a5",
        },
    }),
    valueContainer: (base) => ({
        ...base,
        padding: "0 12px",
    }),
    singleValue: (base) => ({
        ...base,
        color: "#475569",
        fontSize: "14px",
    }),
    placeholder: (base) => ({
        ...base,
        color: "#94a3b8",
        fontSize: "14px",
    }),
    input: (base) => ({
        ...base,
        color: "#475569",
        fontSize: "14px",
    }),
    indicatorSeparator: () => ({
        display: "none",
    }),
    dropdownIndicator: (base, state) => ({
        ...base,
        color: state.isFocused ? "#ef4444" : "#94a3b8",
        paddingRight: "10px",
        "&:hover": {
            color: "#ef4444",
        },
    }),
    clearIndicator: (base) => ({
        ...base,
        color: "#94a3b8",
        "&:hover": {
            color: "#ef4444",
        },
    }),
    menu: (base) => ({
        ...base,
        marginTop: "4px",
        borderRadius: "8px",
        overflow: "hidden",
        border: "1px solid #e2e8f0",
        boxShadow: "0 10px 25px rgba(15, 23, 42, 0.08)",
        zIndex: 9999,
    }),
    menuList: (base) => ({
        ...base,
        padding: "4px",
        maxHeight: "240px",
    }),
    option: (base, state) => ({
        ...base,
        borderRadius: "6px",
        padding: "9px 10px",
        fontSize: "13px",
        cursor: "pointer",
        color: state.isSelected ? "#b91c1c" : "#475569",
        backgroundColor: state.isSelected
            ? "#fef2f2"
            : state.isFocused
            ? "#f8fafc"
            : "#ffffff",
        "&:active": {
            backgroundColor: "#fef2f2",
        },
    }),
};

const initialBOQRows: BOQRow[] = [
    {
        id: 1,
        section: 1,
        module: "Pole Installation",
        category: "Civil Works",
        description: "Pole Attachment Clamps & Supports",
        quantity: 120,
        uom: "Unit",
        materialCost: 25,
        serviceCost: 30,
        salesPrice: 95,
        gct: 15,
        totalInstallments: 0,
        pendingInstallments: 0,
        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 0
    },
    {
        id: 2,
        section: 2,
        module: "Fiber Cable Installation",
        category: "Fiber Optics",
        description: "96-Core ADSS Single Mode Fiber Cable",
        quantity: 10000,
        uom: "Meters",
        materialCost: 1.2,
        serviceCost: 1.5,
        salesPrice: 4.5,
        gct: 15,
        totalInstallments: 0,
        pendingInstallments: 0,
        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 0
    },
    {
        id: 3,
        section: 3,
        module: "Fiber Splicing",
        category: "Splicing & Testing",
        description: "Precision Core Fusion Splicing",
        quantity: 96,
        uom: "Unit",
        materialCost: 8,
        serviceCost: 20,
        salesPrice: 60,
        gct: 15,
        totalInstallments: 0,
        pendingInstallments: 0,
        invoicesGenerated: 0,
        invoicesPaid: 0,
        balanceAmount: 0
    },
];
const paymentModules = [
    { value: "mobilization", label: "Mobilization" },
    { value: "material_supply", label: "Material Supply" },
    { value: "civil_works", label: "Civil Works" },
    { value: "electrical_works", label: "Electrical Works" },
    { value: "plumbing_works", label: "Plumbing Works" },
    { value: "installation", label: "Installation" },
    { value: "testing_commissioning", label: "Testing & Commissioning" },
    { value: "final_handover", label: "Final Handover" },
];

const NewQuotation = ({
    onBack,
    onOpenMasterRate,
}: NewQuotationProps) => {
    const navigate = useNavigate();


    const location = useLocation();
    const { quotationId, editQuotation } = location.state || {};
    const [quotationReference, setQuotationReference] = useState("");
    const [showPdfPreview, setShowPdfPreview] = useState(false);
    const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);
    const [projectName, setProjectName] = useState("");
    const [projectLocation, setProjectLocation] = useState("");
    const [validityPeriod, setValidityPeriod] = useState("30");
    const [scopeSummary, setScopeSummary] = useState("");
    const [terms, setTerms] = useState("");
    const [boqRows, setBoqRows] = useState<BOQRow[]>(initialBOQRows);
    const [vendorName, setVendorName] = useState("");
    const [isSigned, setIsSigned] = useState(false);
    const [signedAt, setSignedAt] = useState<Date | null>(null);
    const [currency, setCurrency] = useState<"USD" | "JMD">("USD");
    const [isSaving, setIsSaving] = useState(false);
    const [saveMessage, setSaveMessage] = useState("");
    const [quotationCounter, setQuotationCounter] = useState(1);
    const [showPaymentSchedule, setShowPaymentSchedule] = useState(false);
    const [formTemplate, setFormTemplate] = useState("");

    const [savedPaymentSchedules, setSavedPaymentSchedules] = useState<SavedPaymentSchedule[]>([]);
    const [editingPaymentScheduleId, setEditingPaymentScheduleId] = useState<number | null>(null);
    // const [selectedQuotationId, setSelectedQuotationId] = useState("");


const formTemplateOptions: FormTemplateOption[] = Array.from(
    new Set(
        quotations
            .map((quotation) => quotation.formTemplate?.trim())
            .filter((template): template is string => Boolean(template))
    )
).map((template) => ({
    value: template,
    label: template,
}));

// const selectedFormTemplate = formTemplateOptions.find(
//     (option) =>
//         option.value ===
//         quotations.find(
//             (quotation) => quotation.id === selectedQuotationId
//         )?.formTemplate
// );
    const handleEditPaymentSchedule = (
        schedule: SavedPaymentSchedule
    ) => {
        setPaymentSchedule(
            schedule.installments.map((installment) => ({
                id: installment.id,
                installmentName: installment.installmentName,
                modules: [...installment.modules],
                amount: installment.amount,
                days: [...installment.days],
            }))
        );

        setEditingPaymentScheduleId(schedule.id);
        setShowPaymentSchedule(true);
    };



    const handleSavePaymentSchedule = () => {
        // Check if there is at least one installment
        if (paymentSchedule.length === 0) {
            alert("Please add at least one installment.");
            return;
        }

        // Validate all installments
        const hasInvalidInstallment = paymentSchedule.some(
            (installment) =>
                !installment.installmentName.trim() ||
                !installment.amount ||
                installment.modules.length === 0 ||
                installment.days.length === 0
        );

        if (hasInvalidInstallment) {
            alert("Please complete all payment installment details.");
            return;
        }

        // Create a safe copy
        const installmentsToSave: PaymentScheduleForm[] =
            paymentSchedule.map((installment) => ({
                id: installment.id,
                installmentName: installment.installmentName,
                modules: [...installment.modules],
                amount: installment.amount,
                days: [...installment.days],
            }));

        // UPDATE existing schedule
        if (editingPaymentScheduleId !== null) {
            setSavedPaymentSchedules((previous) =>
                previous.map((schedule) =>
                    schedule.id === editingPaymentScheduleId
                        ? {
                            ...schedule,
                            installments: installmentsToSave,
                            savedAt: new Date().toLocaleString(),
                        }
                        : schedule
                )
            );

            setEditingPaymentScheduleId(null);
        } else {
            // SAVE new schedule
            const newSchedule: SavedPaymentSchedule = {
                id: Date.now(),
                installments: installmentsToSave,
                savedAt: new Date().toLocaleString(),
            };

            setSavedPaymentSchedules((previous) => [
                ...previous,
                newSchedule,
            ]);
        }

        // Reset form
        setPaymentSchedule([
            {
                id: Date.now(),
                installmentName: "",
                modules: [],
                amount: "",
                days: [],
            },
        ]);

        // Keep the payment schedule section visible
        setShowPaymentSchedule(true);
    };

    const [paymentSchedule, setPaymentSchedule] = useState<
        PaymentScheduleForm[]
    >([
        {
            id: Date.now(),
            installmentName: "",
            modules: [],
            amount: "",
            days: [],
        },
    ]);

    const addPaymentInstallment = () => {
        setPaymentSchedule((previous) => [
            ...previous,
            {
                id: Date.now() + Math.random(),
                installmentName: "",
                modules: [],
                amount: "",
                days: [],
            },
        ]);
    };


    const updatePaymentInstallment = (
        id: number,
        field: "installmentName" | "amount",
        value: string
    ) => {
        setPaymentSchedule((prev) =>
            prev.map((item) =>
                item.id === id
                    ? {
                        ...item,
                        [field]: value,
                    }
                    : item
            )
        );
    };


    const togglePaymentModule = (id: number, module: string) => {
        setPaymentSchedule((prev) =>
            prev.map((item) => {
                if (item.id !== id) return item;

                const modules = item.modules.includes(module)
                    ? item.modules.filter((m) => m !== module)
                    : [...item.modules, module];

                return {
                    ...item,
                    modules,
                };
            })
        );
    };

    const togglePaymentDays = (id: number, day: number) => {
        setPaymentSchedule((prev) =>
            prev.map((item) => {
                if (item.id !== id) return item;

                const days = item.days.includes(day)
                    ? item.days.filter((d) => d !== day)
                    : [...item.days, day];

                return {
                    ...item,
                    days,
                };
            })
        );
    };


    const [paymentToggle, setPaymentToggle] = useState<"amount" | "percentage">("amount");
    const [paymentInstallments, setPaymentInstallments] = useState<PaymentInstallment[]>([]);
    const [newInstallment, setNewInstallment] = useState({
        name: "",
        amount: 0,
        dueDate: "",
        type: "advance" as "advance" | "balance",
    });
    const USD_TO_JMD_RATE = 155.5;

    const [documentType, setDocumentType] = useState("");
    const [uploadedDocuments, setUploadedDocuments] = useState<
        UploadedDocument[]
    >([]);


    const editQuotationId = (location.state as { quotationId?: string, editQuotation?: Quotation } | null)?.quotationId ?? null;
    const editQuotationData = (location.state as { quotationId?: string, editQuotation?: Quotation } | null)?.editQuotation ?? null;
    const preSelectedVendorId = (location.state as { vendorId?: string, vendorName?: string, siteLocation?: string } | null)?.vendorId ?? null;
    const preSelectedVendorName = (location.state as { vendorId?: string, vendorName?: string, siteLocation?: string } | null)?.vendorName ?? null;
    const preSelectedSiteLocation = (location.state as { vendorId?: string, vendorName?: string, siteLocation?: string } | null)?.siteLocation ?? null;
    const isEditMode = Boolean(editQuotationId) || Boolean(editQuotationData);

    const formatCurrency = (value: number) => {
        return value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    };

    const displayAmount = (usdAmount: number) => {
        const amount = currency === "JMD" ? usdAmount * USD_TO_JMD_RATE : usdAmount;
        return formatCurrency(amount);
    };

    const vendorOptions = useMemo<VendorOption[]>(() =>
        VENDORS.map((vendor) => ({
            value: vendor.id,
            label: vendor.name,
            vendor,
        })),
        []
    );

    const selectedVendorOption = selectedVendor ? {
        value: selectedVendor.id,
        label: selectedVendor.name,
        vendor: selectedVendor,
    } : null;

    const selectedValidity = validityOptions.find((option) => option.value === validityPeriod) ?? null;

    const handleDocumentUpload = (
        files: FileList | null
    ) => {
        if (!files || files.length === 0) {
            return;
        }

        const newDocuments = Array.from(files).map((file) => ({
            id: `${Date.now()}-${file.name}`,
            name: file.name,
            type: documentType || "Document",
            size: file.size,
            file,
        }));

        setUploadedDocuments((previous) => [
            ...previous,
            ...newDocuments,
        ]);
    };

    const removeDocument = (id: string) => {
        setUploadedDocuments((previous) =>
            previous.filter((document) => document.id !== id)
        );
    };

    const formatFileSize = (bytes: number): string => {
        if (bytes === 0) {
            return "0 Bytes";
        }

        const units = [
            "Bytes",
            "KB",
            "MB",
            "GB",
        ];

        const index = Math.floor(
            Math.log(bytes) / Math.log(1024)
        );

        const size =
            bytes / Math.pow(1024, index);

        return `${size.toFixed(
            index === 0 ? 0 : 1
        )} ${units[index]}`;
    };

    const financialSummary = useMemo(() => {
        const materialCost = boqRows.reduce((total, row) => total + row.quantity * row.materialCost, 0);
        const serviceCost = boqRows.reduce((total, row) => total + row.quantity * row.serviceCost, 0);
        const salesTotal = boqRows.reduce((total, row) => total + row.quantity * row.salesPrice, 0);
        const grossProfit = salesTotal - materialCost - serviceCost;
        const margin = salesTotal > 0 ? (grossProfit / salesTotal) * 100 : 0;
        return { materialCost, serviceCost, salesTotal, grossProfit, margin };
    }, [boqRows]);

    const financialBreakdown = useMemo(() => {
        const boqSubtotal = financialSummary.salesTotal;
        const gctTax = boqSubtotal * 0.15;
        const siteMobilizationFee = 1500;
        const grandTotal = boqSubtotal + gctTax + siteMobilizationFee;
        const combinedBaseCost = financialSummary.materialCost + financialSummary.serviceCost;
        const materialPercentage = combinedBaseCost > 0 ? (financialSummary.materialCost / combinedBaseCost) * 100 : 0;
        const servicePercentage = combinedBaseCost > 0 ? (financialSummary.serviceCost / combinedBaseCost) * 100 : 0;
        const projectedNetRevenue = grandTotal;
        const grossProfit = projectedNetRevenue - combinedBaseCost;
        const grossMargin = projectedNetRevenue > 0 ? (grossProfit / projectedNetRevenue) * 100 : 0;

        return {
            boqSubtotal,
            gctTax,
            siteMobilizationFee,
            grandTotal,
            combinedBaseCost,
            projectedNetRevenue,
            grossProfit,
            grossMargin,
            materialPercentage,
            servicePercentage,
        };
    }, [financialSummary]);

    const updateBOQRow = <K extends keyof BOQRow>(
        id: number,
        field: K,
        value: BOQRow[K]
    ) => {
        setBoqRows((currentRows) =>
            currentRows.map((row) =>
                row.id === id ? { ...row, [field]: value } : row
            )
        );
    };

    const addBOQRow = (section: number) => {
        setBoqRows((currentRows) => {
            const nextId = currentRows.length > 0 ? Math.max(...currentRows.map((row) => row.id)) + 1 : 1;
            let category = "General";
            if (section === 1) {
                category = "Civil Works";
            } else if (section === 2) {
                category = "Fiber Optics";
            } else if (section === 3) {
                category = "Splicing & Testing";
            }
            const newRow: BOQRow = {
                id: nextId,
                section,
                module: "",
                category,
                description: "",
                quantity: 1,
                uom: "Unit",
                materialCost: 0,
                serviceCost: 0,
                salesPrice: 0,
                gct: 15,
                totalInstallments: 0,
                pendingInstallments: 0,
                invoicesGenerated: 0,
                invoicesPaid: 0,
                balanceAmount: 0
            };
            return [...currentRows, newRow];
        });
    };

    const removeBOQRow = (id: number) => {
        setBoqRows((currentRows) => currentRows.filter((row) => row.id !== id));
    };

    const getSectionTotal = (section: number) => {
        return boqRows.filter((row) => row.section === section).reduce((total, row) => total + row.quantity * row.salesPrice, 0);
    };

    const handleNumberChange = (value: string) => {
        if (value === "") { return 0; }
        const parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : 0;
    };

    const handleBack = () => {
        navigate("/quotation");
    };

    const handleOpenMasterRate = () => {
        navigate("/master-rate");
    };

    const loadQuotationForEdit = () => {
        if (!isEditMode) return;

        const quotation = editQuotationData
            ? editQuotationData
            : (() => {
                try {
                    const existingQuotations: Quotation[] = JSON.parse(
                        localStorage.getItem("quotations") || "[]"
                    );

                    return existingQuotations.find(
                        (q) => q.id === editQuotationId
                    );
                } catch (error) {
                    console.error(
                        "Error loading quotation from localStorage:",
                        error
                    );
                    return undefined;
                }
            })();

        if (!quotation) {
            console.warn("Quotation not found:", editQuotationId);
            return;
        }

        // Existing quotation reference
        setQuotationReference(quotation.quotationNo ?? "");

        // Existing project name
        setProjectName(quotation.projectTitle ?? "");

        // Existing currency
        if (quotation.currency === "USD" || quotation.currency === "JMD") {
            setCurrency(quotation.currency);
        }

        // Existing project location if available
        if ("projectLocation" in quotation) {
            setProjectLocation(
                (quotation as Quotation & {
                    projectLocation?: string;
                }).projectLocation ?? ""
            );
        }

        /**
         * Resolve vendor.
         *
         * Priority:
         * 1. quotation.vendor ID
         * 2. quotation.vendor name
         * 3. quotation.vendorName
         */
        const vendorValue = String(quotation.vendor ?? "").trim();
        const quotationVendorName = String(
            quotation.vendorName ?? ""
        ).trim();

        const matchedVendor = VENDORS.find((vendor) => {
            const vendorId = String(vendor.id).trim().toLowerCase();
            const vendorName = String(vendor.name).trim().toLowerCase();

            const value = vendorValue.toLowerCase();
            const name = quotationVendorName.toLowerCase();

            return (
                vendorId === value ||
                vendorName === value ||
                vendorId === name ||
                vendorName === name
            );
        });

        if (matchedVendor) {
            setSelectedVendor(matchedVendor);
        } else {
            console.warn("Vendor could not be matched:", {
                vendor: quotation.vendor,
                vendorName: quotation.vendorName,
                availableVendors: VENDORS,
            });
        }
    };

    const moduleOptions = [
        { value: "mobilization", label: "Mobilization" },
        { value: "material_supply", label: "Material Supply" },
        { value: "civil_works", label: "Civil Works" },
    ];

    const loadPreSelectedVendor = () => {
        if (isEditMode) return;

        if (preSelectedVendorId) {
            const vendor = VENDORS.find((v) => v.id === preSelectedVendorId);
            if (vendor) {
                setSelectedVendor(vendor);
            }
        } else if (preSelectedVendorName) {
            const vendor = VENDORS.find((v) => v.name === preSelectedVendorName);
            if (vendor) {
                setSelectedVendor(vendor);
            }
        }

        if (preSelectedSiteLocation) {
            setProjectLocation(preSelectedSiteLocation);
        }
    };

    useEffect(() => {
        loadQuotationForEdit();
        loadPreSelectedVendor();
    }, [
        editQuotationId,
        editQuotationData,
        preSelectedVendorId,
        preSelectedVendorName,
        preSelectedSiteLocation,
    ]); 

    useEffect(() => {
    if (isEditMode && editQuotationData) {
        setFormTemplate(editQuotationData.formTemplate ?? "");
    } else {
        setFormTemplate("");
    }
}, [isEditMode, editQuotationData]);

    useEffect(() => {
        if (!isEditMode) {
            setFormTemplate("");
            return;
        }

        const quotation =
            editQuotationData ??
            quotations.find((item) => item.id === editQuotationId);

        setFormTemplate(quotation?.formTemplate?.trim() ?? "");
    }, [isEditMode, editQuotationId, editQuotationData]);

    useEffect(() => {
        if (showPaymentSchedule && paymentScheduleRef.current) {
            paymentScheduleRef.current.scrollIntoView({
                behavior: "smooth",
                block: "start",
            });
        }
    }, [showPaymentSchedule]);


    useEffect(() => {
        const existingQuotations: Quotation[] = JSON.parse(localStorage.getItem("quotations") || "[]");
        if (existingQuotations.length > 0) {
            const maxCounter = existingQuotations.reduce((max, q) => {
                const match = q.quotationNo.match(/QT-\d+-(\d+)/);
                if (match) {
                    const num = parseInt(match[1], 10);
                    return num > max ? num : max;
                }
                return max;
            }, 0);
            setQuotationCounter(maxCounter + 1);
        }
    }, []);

    const buildQuotation = (
        workflowStage: WorkflowStage,
        status: QuotationStatus
    ): Quotation => {
        const today = new Date();
        const quotationDate = today.toISOString().split("T")[0];
        const validUntilDate = new Date(today);
        validUntilDate.setDate(validUntilDate.getDate() + Number(validityPeriod));
        const validUntil = validUntilDate.toISOString().split("T")[0];

        const generateId = () => {
            if (isEditMode && editQuotationId) {
                return editQuotationId;
            }
            if (isEditMode && editQuotationData) {
                return editQuotationData.id;
            }
            try {
                return crypto.randomUUID();
            } catch {
                return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
            }
        };

        const generateQuotationNo = () => {
            if (quotationReference.trim()) {
                return quotationReference.trim();
            }
            const year = today.getFullYear();
            const counter = isEditMode ? parseInt(quotationReference.match(/\d+$/)?.[0] || "0") || quotationCounter : quotationCounter;
            return `QT-${year}-${String(counter).padStart(3, "0")}`;
        };

        const quotation: Quotation = {
            id: generateId(),
            quotationNo: generateQuotationNo(),
            vendor: selectedVendor?.id ?? "",
            vendorName: selectedVendor?.name ?? vendorName.trim(),
            projectTitle: projectName.trim(),
            date: quotationDate,
            grandTotal: financialBreakdown.grandTotal,
            currency: currency,
            margin: financialBreakdown.grossMargin,

            status,
            category: boqRows[0]?.category ?? "General",
            items: boqRows.length,
            progress: 0,
            validUntil,
            createdDate: quotationDate,
            clientName: selectedVendor?.name ?? vendorName.trim(),
            formTemplate: ""
        };

        return quotation;
    };

    const saveQuotationToStorage = (quotation: Quotation) => {
        const existingQuotations: Quotation[] = JSON.parse(localStorage.getItem("quotations") || "[]");

        if (isEditMode && editQuotationId) {
            const updatedQuotations = existingQuotations.map((q) =>
                q.id === editQuotationId ? quotation : q
            );
            localStorage.setItem("quotations", JSON.stringify(updatedQuotations));
        } else if (isEditMode && editQuotationData) {
            const updatedQuotations = existingQuotations.map((q) =>
                q.id === editQuotationData.id ? quotation : q
            );
            localStorage.setItem("quotations", JSON.stringify(updatedQuotations));
        } else {
            const updatedQuotations = [...existingQuotations, quotation];
            localStorage.setItem("quotations", JSON.stringify(updatedQuotations));
        }

        window.dispatchEvent(new StorageEvent("storage", {
            key: "quotations",
            newValue: JSON.stringify(localStorage.getItem("quotations")),
        }));
    };

    const handleSaveDraft = () => {
        setIsSaving(true);
        setSaveMessage("");

        try {
            const quotation = buildQuotation("Draft", "Draft");
            saveQuotationToStorage(quotation);
            if (!isEditMode) {
                setQuotationCounter((prev) => prev + 1);
            }
            setSaveMessage("Quotation saved as draft.");
            setTimeout(() => {
                navigate("/quotation");
            }, 500);
        } catch (error) {
            console.error("Error saving quotation:", error);
            setSaveMessage("Failed to save quotation.");
        } finally {
            setIsSaving(false);
        }
    };

    const handleSubmitForApproval = () => {
        setSaveMessage("");

        if (!selectedVendor) {
            setSaveMessage("Please select an enterprise vendor.");
            return;
        }

        if (!projectName.trim()) {
            setSaveMessage("Please enter the project name / contract title.");
            return;
        }

        if (boqRows.length === 0) {
            setSaveMessage("Please add at least one BOQ item.");
            return;
        }

        setIsSaving(true);

        try {
            const quotation = buildQuotation("Submitted for Approval", "Draft");
            saveQuotationToStorage(quotation);
            if (!isEditMode) {
                setQuotationCounter((prev) => prev + 1);
            }
            setSaveMessage("Quotation submitted for approval.");
            setTimeout(() => {
                navigate("/quotation");
            }, 500);
        } catch (error) {
            console.error("Error submitting quotation:", error);
            setSaveMessage("Failed to submit quotation.");
        } finally {
            setIsSaving(false);
        }
    };

    const netTotal = Number(financialBreakdown.grandTotal) || 0;

    const totalInstallmentAmount = paymentInstallments.reduce(
        (total, installment) => total + Number(installment.amount || 0),
        0
    );

    const remainingBalance = Math.max(
        0,
        netTotal - totalInstallmentAmount
    );
    const remainingPercentage =
        netTotal > 0
            ? (remainingBalance / netTotal) * 100
            : 0;

    const addInstallment = () => {
        if (!newInstallment.name || newInstallment.amount <= 0 || remainingBalance <= 0 || !newInstallment.dueDate) {
            return;
        }

        const amountToAdd = Math.min(newInstallment.amount, remainingBalance);

        setPaymentInstallments([
            ...paymentInstallments,
            {
                id: crypto.randomUUID ? crypto.randomUUID() : `inst-${Date.now()}`,
                name: newInstallment.name,
                amount: amountToAdd,
                type: newInstallment.type,
                dueDate: newInstallment.dueDate,
                modules: [],
                days: [],
                installmentName: ""
            },
        ]);

        setNewInstallment({
            name: "",
            amount: 0,
            dueDate: "",
            type: "advance",
        });
    };

    const removeInstallment = (id: string) => {
        setPaymentInstallments(paymentInstallments.filter((inst) => inst.id !== id));
    };

    const handleSave = () => {
        // Save BOQ data here if needed
        console.log("BOQ saved");

        // Show Payment Schedule section
        setShowPaymentSchedule(true);
    };
    const paymentScheduleRef = useRef<HTMLElement | null>(null);

//     useEffect(() => {
//     const selectedQuotation = quotations.find(
//         (quotation) => quotation.id === selectedQuotationId
//     );

//     setFormTemplate(selectedQuotation?.formTemplate ?? "");
// }, [selectedQuotationId]);
    return (
        <div className="min-h-screen animate-slide-in-right">
            <div className="mb-6 flex flex-col gap-4 border-b border-slate-200 pb-5 lg:flex-row lg:items-center lg:justify-between">
                <div className="flex items-start gap-3">
                    <button
                        type="button"
                        onClick={handleBack}
                        className="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 transition hover:bg-slate-50 hover:text-slate-800"
                        aria-label="Go back"
                    >
                        <ArrowLeftIcon size={18} weight="bold" />
                    </button>

                    <div>
                        <h1 className="text-xl font-bold text-slate-900">
                            {isEditMode ? "Edit Commercial Quotation" : "Create Commercial Quotation"}
                        </h1>

                        <p className="mt-1 text-sm text-slate-500">
                            {isEditMode
                                ? "Update the commercial quotation and re-submit for approval."
                                : "Prepare a commercial quotation, configure BOQ pricing and submit it for approval."}
                        </p>
                    </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    {saveMessage && (
                        <span className={`text-xs font-medium ${saveMessage.includes("Failed") ? "text-red-600" : "text-emerald-600"}`}>
                            {saveMessage}
                        </span>
                    )}

                    <button
                        type="button"
                        onClick={() => setShowPdfPreview(true)}
                        className="flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 hover:text-red-600"
                    >
                        <FilePdfIcon size={17} weight="duotone" />
                        Preview Official PDF
                    </button>

                    <button
                        type="button"
                        onClick={handleSaveDraft}
                        disabled={isSaving}
                        className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-600 shadow-sm transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        {isSaving ? "Saving..." : "Save Draft"}
                    </button>

                    <button
                        type="button"
                        onClick={handleSubmitForApproval}
                        disabled={isSaving}
                        className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <CheckIcon size={16} weight="bold" />
                        {isSaving ? "Submitting..." : "Submit for Approval"}
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
                <div className="min-w-0 space-y-6">
                    <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="border-b border-slate-200 px-5 py-4">
                            <h2 className="text-sm font-bold uppercase tracking-wide text-slate-900">
                                1. Vendor &amp; Project Location Metadata
                            </h2>

                            <p className="mt-1 text-xs text-slate-500">
                                Enter the quotation and project information.
                            </p>
                        </div>

                        <div className="grid grid-cols-1 gap-5 p-5 md:grid-cols-2">
                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Select Enterprise Vendor
                                    <span className="ml-1 text-red-500">*</span>
                                </label>

                                <Select<VendorOption, false>
                                    options={vendorOptions}
                                    value={selectedVendorOption}
                                    onChange={(option: SingleValue<VendorOption>) => {
                                        setSelectedVendor(option?.vendor ?? null);
                                    }}
                                    styles={vendorSelectStyles}
                                    isSearchable={!isEditMode}
                                    isClearable={false}
                                    isDisabled={isEditMode}
                                    menuPlacement="auto"
                                    placeholder="Select enterprise vendor"
                                    noOptionsMessage={() => "No vendors found"}
                                    getOptionLabel={(option) => option.label}
                                    getOptionValue={(option) => option.value}
                                />

                            </div>

                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Quotation Reference Number
                                </label>

                                <input
                                    type="text"
                                    value={quotationReference}
                                    onChange={(e) => setQuotationReference(e.target.value)}
                                    placeholder="e.g. QT-2026-105"
                                    disabled={isEditMode}
                                    className={`w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm text-slate-700 outline-none transition ${isEditMode
                                            ? "cursor-not-allowed bg-slate-100 text-slate-500"
                                            : "bg-slate-50 focus:border-red-300 focus:bg-white"
                                        } placeholder:text-slate-400`}
                                />
                            </div>

                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Project Name / Contract Title
                                    <span className="ml-1 text-red-500">*</span>
                                </label>

                                <input
                                    type="text"
                                    value={projectName}
                                    onChange={(e) => setProjectName(e.target.value)}
                                    placeholder="Enter project or contract title"
                                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-300 focus:bg-white"
                                />
                            </div>

                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Project Site Location
                                </label>

                                <input
                                    type="text"
                                    value={projectLocation}
                                    onChange={(e) => setProjectLocation(e.target.value)}
                                    placeholder="Enter project site location"
                                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-300 focus:bg-white"
                                />
                            </div>

                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Validity Period
                                </label>

                                <Select<ValidityOption, false>
                                    options={validityOptions}
                                    value={selectedValidity}
                                    onChange={(option: SingleValue<ValidityOption>) => {
                                        setValidityPeriod(option?.value ?? "30");
                                    }}
                                    styles={validitySelectStyles}
                                    isSearchable={false}
                                    isClearable={false}
                                    menuPlacement="auto"
                                    placeholder="Select validity period"
                                />
                            </div>

                          <div>
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Form Template
                            </label>

                            <Select<FormTemplateOption, false>
                                options={formTemplateOptions}
                                value={
                                    formTemplate
                                        ? {
                                            value: formTemplate,
                                            label: formTemplate,
                                        }
                                        : null
                                }
                                onChange={(option: SingleValue<FormTemplateOption>) => {
                                    setFormTemplate(option?.value ?? "");
                                }}
                                styles={formTemplateSelectStyles}
                                isSearchable={!isEditMode}
                                isClearable={false}
                                isDisabled={isEditMode}
                                menuPlacement="auto"
                                placeholder="Select form template"
                                noOptionsMessage={() => "No form templates found"}
                                getOptionLabel={(option) => option.label}
                                getOptionValue={(option) => option.value}
                            />
                        </div>

                            <div className="md:col-span-2">
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Scope of Work Summary
                                </label>

                                <textarea
                                    rows={4}
                                    value={scopeSummary}
                                    onChange={(e) => setScopeSummary(e.target.value)}
                                    placeholder="Provide a brief summary of the scope of work..."
                                    className="w-full resize-none rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-300 focus:bg-white"
                                />
                            </div>
                        </div>
                    </section>

                    {/* 2. BOQ */}
                    <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
                            <div className="flex items-start gap-3">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                                    <FilePdfIcon size={18} weight="duotone" />
                                </div>

                                <div>
                                    <h2 className="text-sm font-bold uppercase tracking-wide text-slate-900">
                                        2. Bill of Quantities (BOQ) Schedule Editor
                                    </h2>

                                    <p className="mt-1 text-xs text-slate-500">
                                        Structured cost components
                                    </p>
                                </div>
                            </div>

                            <button
                                type="button"
                                onClick={handleSave}
                                className="inline-flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                            >
                                Save
                            </button>
                        </div>

                        {boqSections.map((section, sectionIndex) => (
                            <BOQSectionTable
                                key={section.id}
                                section={section}
                                sectionIndex={sectionIndex}
                                rows={boqRows}
                                onAddRow={addBOQRow}
                                onUpdateRow={updateBOQRow}
                                onRemoveRow={removeBOQRow}
                                getSectionTotal={getSectionTotal}
                                formatCurrency={formatCurrency}
                                handleNumberChange={handleNumberChange}
                            />
                        ))}
                    </section>


                    {/* 2.5 Payment Schedule - appears after BOQ Save */}
                    {showPaymentSchedule && (
                        <section
                            ref={paymentScheduleRef}
                            className="mt-6 rounded-2xl border border-slate-200 bg-white shadow-sm"
                        >
                            <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
                                <div>
                                    <h2 className="text-sm font-bold uppercase tracking-wide text-slate-900">
                                        Payment Schedule
                                    </h2>

                                    <p className="mt-1 text-xs text-slate-500">
                                        Define installment payments, applicable modules, amounts and payment timelines.
                                    </p>
                                </div>

                                <div className="flex items-center gap-2">
                                    {/* <button
                                        type="button"
                                        onClick={addPaymentInstallment}
                                        className="inline-flex items-center justify-center rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
                                    >
                                        + Add Installment
                                    </button> */}

                                    <button
                                        type="button"
                                        onClick={handleSavePaymentSchedule}
                                        className="inline-flex items-center justify-center rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2"
                                    >
                                        {editingPaymentScheduleId !== null ? "Update" : "Save"}
                                    </button>
                                </div>
                            </div>

                            <div className="space-y-5 p-5">
                                {paymentSchedule.map((installment, index) => (
                                    <div
                                        key={installment.id}
                                        className="rounded-xl border border-slate-200 bg-slate-50 p-5"
                                    >
                                        <div className="mb-4 flex items-center justify-between">
                                            <h3 className="text-sm font-bold text-slate-800">
                                                Installment {index + 1}
                                            </h3>
                                        </div>

                                        <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
                                            {/* Installment Name */}
                                            <div>
                                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                                    Installment Name
                                                </label>

                                                <input
                                                    type="text"
                                                    value={installment.installmentName}
                                                    onChange={(e) =>
                                                        updatePaymentInstallment(
                                                            installment.id,
                                                            "installmentName",
                                                            e.target.value
                                                        )
                                                    }
                                                    placeholder="e.g. Advance Payment"
                                                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-300"
                                                />
                                            </div>

                                            {/* Amount */}
                                            <div>
                                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                                    Amount
                                                </label>

                                                <input
                                                    type="number"
                                                    min="0"
                                                    value={installment.amount}
                                                    onChange={(e) =>
                                                        updatePaymentInstallment(
                                                            installment.id,
                                                            "amount",
                                                            e.target.value
                                                        )
                                                    }
                                                    placeholder="Enter amount"
                                                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-300"
                                                />
                                            </div>

                                            {/* Modules Multi Select */}
                                            <div className="lg:col-span-1">
                                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                                    Modules / Items
                                                </label>

                                                <Select
                                                    isMulti
                                                    options={paymentModules}
                                                    value={paymentModules.filter((module) =>
                                                        installment.modules.includes(module.value)
                                                    )}
                                                    onChange={(selectedOptions) => {
                                                        const selectedModules = selectedOptions.map(
                                                            (option) => option.value
                                                        );

                                                        setPaymentSchedule((prev) =>
                                                            prev.map((item) =>
                                                                item.id === installment.id
                                                                    ? {
                                                                        ...item,
                                                                        modules: selectedModules,
                                                                    }
                                                                    : item
                                                            )
                                                        );
                                                    }}
                                                    placeholder="Select modules..."
                                                    className="text-sm"
                                                    classNamePrefix="payment-select"
                                                    styles={{
                                                        control: (base, state) => ({
                                                            ...base,
                                                            minHeight: "42px",
                                                            borderRadius: "8px",
                                                            borderColor: state.isFocused
                                                                ? "#fca5a5"
                                                                : "#e2e8f0",
                                                            boxShadow: "none",
                                                            "&:hover": {
                                                                borderColor: "#fca5a5",
                                                            },
                                                        }),
                                                        multiValue: (base) => ({
                                                            ...base,
                                                            backgroundColor: "#fef2f2",
                                                            borderRadius: "6px",
                                                        }),
                                                        multiValueLabel: (base) => ({
                                                            ...base,
                                                            color: "#b91c1c",
                                                            fontWeight: 500,
                                                        }),
                                                        multiValueRemove: (base) => ({
                                                            ...base,
                                                            color: "#b91c1c",
                                                            ":hover": {
                                                                backgroundColor: "#fee2e2",
                                                                color: "#991b1b",
                                                            },
                                                        }),
                                                        option: (base, state) => ({
                                                            ...base,
                                                            backgroundColor: state.isSelected
                                                                ? "#dc2626"
                                                                : state.isFocused
                                                                    ? "#fef2f2"
                                                                    : "white",
                                                            color: state.isSelected
                                                                ? "white"
                                                                : "#334155",
                                                            cursor: "pointer",
                                                        }),
                                                        menu: (base) => ({
                                                            ...base,
                                                            zIndex: 50,
                                                        }),
                                                    }}
                                                />
                                            </div>

                                            {/* Payment Days */}
                                            <div className="lg:col-span-1">
                                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                                    Payment Timeline
                                                </label>

                                                <div className="flex items-center gap-2">
                                                    <input
                                                        type="number"
                                                        min="1"
                                                        value={installment.days[0] ?? ""}
                                                        onChange={(e) => {
                                                            const value = e.target.value;

                                                            setPaymentSchedule((prev) =>
                                                                prev.map((item) =>
                                                                    item.id === installment.id
                                                                        ? {
                                                                            ...item,
                                                                            days: value
                                                                                ? [Number(value)]
                                                                                : [],
                                                                        }
                                                                        : item
                                                                )
                                                            );
                                                        }}
                                                        placeholder="Enter number of days"
                                                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-300 focus:ring-1 focus:ring-red-200"
                                                    />

                                                    <span className="whitespace-nowrap text-sm text-slate-500">
                                                        Days
                                                    </span>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>
                    )}





                    <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="border-b border-slate-200 px-5 py-4">
                            <h2 className="text-sm font-bold uppercase tracking-wide text-slate-900">
                                3. Terms &amp; Conditions Presets
                            </h2>

                            <p className="mt-1 text-xs text-slate-500">
                                Add or customize the commercial terms for this quotation.
                            </p>
                        </div>

                        <div className="p-5">
                            <textarea
                                rows={7}
                                value={terms}
                                onChange={(e) => setTerms(e.target.value)}
                                placeholder="Enter terms and conditions..."
                                className="w-full resize-y rounded-lg border border-slate-200 bg-slate-50 px-3 py-3 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-300 focus:bg-white"
                            />
                        </div>
                    </section>
                </div>

                <aside className="space-y-5">
                    <section className="overflow-hidden rounded-2xl bg-slate-900 shadow-lg">
                        <div className="border-b border-slate-700 px-5 py-4">
                            <div className="flex items-start justify-between gap-3">
                                <div>
                                    <h2 className="text-sm font-bold text-white">
                                        Financial Summary &amp; Margin
                                    </h2>

                                    <p className="mt-1 text-xs text-slate-400">
                                        Real-time quotation profitability
                                    </p>
                                </div>

                                <div className="flex shrink-0 rounded-lg bg-slate-800 p-1">
                                    <button
                                        type="button"
                                        onClick={() => setCurrency("USD")}
                                        className={`rounded-md px-2.5 py-1 text-[9px] font-bold transition-colors ${currency === "USD"
                                            ? "bg-red-600 text-white"
                                            : "text-slate-400 hover:text-white"
                                            }`}
                                    >
                                        USD
                                    </button>

                                    <button
                                        type="button"
                                        onClick={() => setCurrency("JMD")}
                                        className={`rounded-md px-2.5 py-1 text-[9px] font-bold transition-colors ${currency === "JMD"
                                            ? "bg-red-600 text-white"
                                            : "text-slate-400 hover:text-white"
                                            }`}
                                    >
                                        JMD
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4 p-5">
                            {currency === "JMD" && (
                                <div className="rounded-lg border border-blue-900 bg-blue-950/40 px-3 py-2">
                                    <p className="text-[9px] font-semibold text-blue-300">
                                        Reference Exchange Rate: 1 USD = {USD_TO_JMD_RATE.toFixed(1)} JMD
                                    </p>
                                </div>
                            )}

                            <div>
                                <div className="mb-2 flex items-center justify-between">
                                    <span className="text-[9px] font-bold uppercase tracking-wide text-slate-500">
                                        Quotation Breakdown
                                    </span>

                                    <span className="text-[9px] font-semibold text-slate-500">
                                        {CURRENCY}
                                    </span>
                                </div>

                                <div className="space-y-2">
                                    <SummaryRow
                                        label="BOQ Line Items Subtotal:"
                                        value={financialBreakdown.boqSubtotal}
                                        formatCurrency={displayAmount}
                                    />

                                    <SummaryRow
                                        label="GCT Tax (15%):"
                                        value={financialBreakdown.gctTax}
                                        formatCurrency={displayAmount}
                                    />

                                    <SummaryRow
                                        label="Site Mobilization Fee:"
                                        value={financialBreakdown.siteMobilizationFee}
                                        formatCurrency={displayAmount}
                                    />
                                </div>
                            </div>

                            <div className="rounded-xl border border-red-900 bg-red-950/40 px-4 py-3.5">
                                <div className="flex items-center justify-between gap-3">
                                    <span className="text-xs font-semibold text-slate-300">
                                        Grand Total ({CURRENCY}):
                                    </span>

                                    <span className="whitespace-nowrap text-base font-bold text-red-400">
                                        {CURRENCY} {displayAmount(financialBreakdown.grandTotal)}
                                    </span>
                                </div>
                            </div>

                            <div className="border-t border-slate-800 pt-4">
                                <div className="mb-3 flex items-center justify-between gap-3">
                                    <div>
                                        <p className="text-[9px] font-bold uppercase tracking-widest text-slate-500">
                                            Estimation Intelligence
                                        </p>

                                        <p className="mt-1 text-xs font-semibold text-slate-300">
                                            Gross Margin
                                        </p>
                                    </div>

                                    <span className="text-xl font-bold text-emerald-400">
                                        {financialBreakdown.grossMargin.toFixed(1)}%
                                    </span>
                                </div>

                                <div className="h-2 overflow-hidden rounded-full bg-slate-700">
                                    <div
                                        className="h-full rounded-full bg-emerald-500 transition-all duration-300"
                                        style={{
                                            width: `${Math.min(Math.max(financialBreakdown.grossMargin, 0), 100)}%`,
                                        }}
                                    />
                                </div>
                            </div>

                            <div className="rounded-xl bg-slate-800 px-4 py-4">
                                <div className="flex items-center justify-between gap-3">
                                    <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">
                                        Cost Distribution Breakdown
                                    </p>

                                    <p className="whitespace-nowrap text-[9px] font-bold text-slate-300">
                                        {financialBreakdown.materialPercentage.toFixed(0)}% Mat /{" "}
                                        {financialBreakdown.servicePercentage.toFixed(0)}% Srv
                                    </p>
                                </div>

                                <div className="mt-3 flex h-2 overflow-hidden rounded-full bg-slate-700">
                                    <div
                                        className="h-full bg-blue-500 transition-all duration-300"
                                        style={{
                                            width: `${financialBreakdown.materialPercentage}%`,
                                        }}
                                    />

                                    <div
                                        className="h-full bg-violet-500 transition-all duration-300"
                                        style={{
                                            width: `${financialBreakdown.servicePercentage}%`,
                                        }}
                                    />
                                </div>

                                <div className="mt-4 grid grid-cols-2 gap-3">
                                    <div>
                                        <p className="text-[9px] text-slate-500">
                                            Estimated Materials
                                        </p>

                                        <p className="mt-1 text-xs font-bold text-white">
                                            {CURRENCY} {displayAmount(financialSummary.materialCost)}
                                        </p>
                                    </div>

                                    <div>
                                        <p className="text-[9px] text-slate-500">
                                            Estimated Services
                                        </p>

                                        <p className="mt-1 text-xs font-bold text-white">
                                            {CURRENCY} {displayAmount(financialSummary.serviceCost)}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-2">
                                <SummaryRow
                                    label="Combined Base Cost:"
                                    value={financialBreakdown.combinedBaseCost}
                                    formatCurrency={displayAmount}
                                />

                                <div className="flex items-center justify-between gap-4">
                                    <span className="text-xs text-slate-400">
                                        Projected Net Revenue:
                                    </span>

                                    <span className="whitespace-nowrap text-xs font-bold text-blue-400">
                                        {CURRENCY} {displayAmount(financialBreakdown.projectedNetRevenue)}
                                    </span>
                                </div>

                                <div className="flex items-center justify-between gap-4 border-t border-slate-800 pt-2">
                                    <span className="text-xs font-medium text-slate-300">
                                        Gross Profit:
                                    </span>

                                    <span className={`whitespace-nowrap text-sm font-bold ${financialBreakdown.grossProfit >= 0
                                        ? "text-emerald-400"
                                        : "text-red-400"
                                        }`}>
                                        {CURRENCY} {displayAmount(financialBreakdown.grossProfit)}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </section>




                    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                        <h3 className="text-xs font-bold uppercase tracking-wide text-slate-800">
                            Quotation Information
                        </h3>

                        <div className="mt-4 space-y-3">
                            <InfoRow label="Items" value={boqRows.length} />
                            <InfoRow label="Validity" value={`${validityPeriod} Days`} />
                            <InfoRow label="Currency" value={CURRENCY} />
                            <InfoRow label="Sections" value={boqSections.length} />
                        </div>
                    </section>

                    <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="border-b border-slate-200 px-5 py-4">
                            <div className="flex items-center justify-between gap-3">
                                <div>
                                    <h2 className="text-sm font-bold uppercase tracking-wide text-slate-900">
                                        Document Upload
                                    </h2>

                                    <p className="mt-1 text-[10px] leading-relaxed text-slate-500">
                                        Upload project documents and specify the document type
                                    </p>
                                </div>

                                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                                    <FileTextIcon size={16} weight="bold" />
                                </div>
                            </div>
                        </div>

                        <div className="p-4">
                            <div className="grid grid-cols-1 gap-3 sm:grid-cols-1">
                                <div>
                                    <label className="mb-1 block text-[9px] font-semibold text-slate-600">
                                        Document Type
                                    </label>

                                    <Select
                                        options={documentTypeOptions}
                                        value={
                                            documentTypeOptions.find(
                                                (option) =>
                                                    option.value === documentType
                                            ) || null
                                        }
                                        onChange={(selectedOption) =>
                                            setDocumentType(
                                                selectedOption?.value || ""
                                            )
                                        }
                                        placeholder="Select document type"
                                        isClearable
                                        className="text-[10px]"
                                        classNamePrefix="document-type"
                                        styles={{
                                            control: (base, state) => ({
                                                ...base,
                                                minHeight: "34px",
                                                height: "34px",
                                                borderRadius: "8px",
                                                borderColor: state.isFocused
                                                    ? "#fca5a5"
                                                    : "#e2e8f0",
                                                backgroundColor: state.isFocused
                                                    ? "#ffffff"
                                                    : "#f8fafc",
                                                boxShadow: "none",
                                                "&:hover": {
                                                    borderColor: "#fca5a5",
                                                },
                                            }),
                                            valueContainer: (base) => ({
                                                ...base,
                                                padding: "0 10px",
                                            }),
                                            singleValue: (base) => ({
                                                ...base,
                                                fontSize: "10px",
                                                color: "#334155",
                                            }),
                                            placeholder: (base) => ({
                                                ...base,
                                                fontSize: "10px",
                                                color: "#94a3b8",
                                            }),
                                            input: (base) => ({
                                                ...base,
                                                fontSize: "10px",
                                            }),
                                            option: (base, state) => ({
                                                ...base,
                                                fontSize: "10px",
                                                padding: "8px 10px",
                                                backgroundColor: state.isSelected
                                                    ? "#dc2626"
                                                    : state.isFocused
                                                        ? "#fef2f2"
                                                        : "#ffffff",
                                                color: state.isSelected
                                                    ? "#ffffff"
                                                    : "#334155",
                                                cursor: "pointer",
                                            }),
                                            menu: (base) => ({
                                                ...base,
                                                zIndex: 50,
                                            }),
                                            indicatorSeparator: () => ({
                                                display: "none",
                                            }),
                                            dropdownIndicator: (base) => ({
                                                ...base,
                                                padding: "0 8px",
                                                color: "#94a3b8",
                                            }),
                                            clearIndicator: (base) => ({
                                                ...base,
                                                padding: "0 4px",
                                                color: "#94a3b8",
                                            }),
                                        }}
                                    />
                                </div>

                                <div>
                                    <label className="mb-1 block text-[9px] font-semibold text-slate-600">
                                        Document
                                    </label>

                                    <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-dashed border-slate-200 bg-slate-50 px-3 py-2 transition hover:border-red-300 hover:bg-red-50/50">
                                        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-white text-red-500 shadow-sm">
                                            <DownloadSimpleIcon
                                                size={14}
                                                weight="bold"
                                            />
                                        </div>

                                        <div className="min-w-0 flex-1">
                                            <p className="text-[9px] font-semibold text-slate-600">
                                                Click to upload document
                                            </p>

                                            <p className="mt-0.5 truncate text-[8px] text-slate-400">
                                                PDF, Excel, Word or Image
                                            </p>
                                        </div>

                                        <input
                                            type="file"
                                            className="hidden"
                                            accept=".pdf,.xlsx,.xls,.csv,.doc,.docx,.jpg,.jpeg,.png"
                                            onChange={(e) =>
                                                handleDocumentUpload(
                                                    e.target.files
                                                )
                                            }
                                        />
                                    </label>
                                </div>
                            </div>

                            {uploadedDocuments.length > 0 && (
                                <div className="mt-4">
                                    <div className="mb-2 flex items-center justify-between">
                                        <p className="text-[9px] font-bold uppercase tracking-wide text-slate-400">
                                            Uploaded Documents
                                        </p>

                                        <span className="text-[9px] font-semibold text-slate-400">
                                            {uploadedDocuments.length}{" "}
                                            {uploadedDocuments.length === 1
                                                ? "Document"
                                                : "Documents"}
                                        </span>
                                    </div>

                                    <div className="space-y-2">
                                        {uploadedDocuments.map((document) => (
                                            <div
                                                key={document.id}
                                                className="flex items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5"
                                            >
                                                <div className="flex min-w-0 items-center gap-2.5">
                                                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-white text-red-500 shadow-sm">
                                                        <FileTextIcon
                                                            size={14}
                                                            weight="bold"
                                                        />
                                                    </div>

                                                    <div className="min-w-0">
                                                        <p className="truncate text-[10px] font-semibold text-slate-700">
                                                            {document.name}
                                                        </p>

                                                        <div className="mt-0.5 flex items-center gap-2">
                                                            <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[8px] font-semibold text-blue-600">
                                                                {document.type}
                                                            </span>

                                                            <span className="text-[8px] text-slate-400">
                                                                {formatFileSize(
                                                                    document.size
                                                                )}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <button
                                                    type="button"
                                                    onClick={() =>
                                                        removeDocument(
                                                            document.id
                                                        )
                                                    }
                                                    title="Remove document"
                                                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-slate-300 transition hover:bg-red-50 hover:text-red-500"
                                                >
                                                    <XIcon
                                                        size={13}
                                                        weight="bold"
                                                    />
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {savedPaymentSchedules.length > 0 && (
                                <div className="mt-4">
                                    <div className="mb-2 flex items-center justify-between">
                                        <p className="text-[9px] font-bold uppercase tracking-wide text-slate-400">
                                            Payment Schedule Logs
                                        </p>

                                        <span className="text-[9px] font-semibold text-slate-400">
                                            {savedPaymentSchedules.length}{" "}
                                            {savedPaymentSchedules.length === 1
                                                ? "Schedule"
                                                : "Schedules"}
                                        </span>
                                    </div>

                                    <div className="space-y-2">
                                        {savedPaymentSchedules.map((schedule, scheduleIndex) => (
                                            <div
                                                key={schedule.id}
                                                className="rounded-lg border border-slate-200 bg-slate-50 p-3"
                                            >
                                                <div className="flex items-center justify-between gap-3">
                                                    <div className="min-w-0">
                                                        <p className="text-[10px] font-bold text-slate-700">
                                                            Payment Schedule {scheduleIndex + 1}
                                                        </p>

                                                        <p className="mt-0.5 text-[8px] text-slate-400">
                                                            {schedule.installments.length}{" "}
                                                            {schedule.installments.length === 1
                                                                ? "Installment"
                                                                : "Installments"}{" "}
                                                            • Saved {schedule.savedAt}
                                                        </p>
                                                    </div>

                                                    <button
                                                        type="button"
                                                        onClick={() =>
                                                            handleEditPaymentSchedule(schedule)
                                                        }
                                                        className="inline-flex shrink-0 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-1.5 text-[9px] font-semibold text-slate-600 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
                                                    >
                                                        Edit
                                                    </button>
                                                </div>

                                                <div className="mt-3 space-y-1.5">
                                                    {schedule.installments.map(
                                                        (installment, installmentIndex) => (
                                                            <div
                                                                key={installment.id}
                                                                className="rounded-md border border-slate-200 bg-white px-3 py-2"
                                                            >
                                                                <div className="flex items-center justify-between gap-3">
                                                                    <div className="min-w-0">
                                                                        <p className="text-[9px] font-semibold text-slate-700">
                                                                            {installmentIndex + 1}.{" "}
                                                                            {installment.installmentName}
                                                                        </p>

                                                                        <p className="mt-0.5 text-[8px] text-slate-400">
                                                                            {installment.modules.join(
                                                                                ", "
                                                                            )}
                                                                        </p>
                                                                    </div>

                                                                    <div className="shrink-0 text-right">
                                                                        <p className="text-[9px] font-bold text-slate-700">
                                                                            $ {installment.amount}
                                                                        </p>

                                                                        <p className="text-[8px] text-slate-400">
                                                                            {installment.days[0]} Days
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        )
                                                    )}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                        </div>
                    </section>
                </aside>
            </div>

            {showPdfPreview && (
                <div
                    className="fixed inset-0 z-[100]"
                    onMouseDown={(event) => {
                        if (event.target === event.currentTarget) {
                            setShowPdfPreview(false);
                        }
                    }}
                >
                    <div className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-slate-700 bg-slate-950 px-4 shadow-xl">
                        <div className="flex items-center gap-3">
                            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-600 text-white">
                                <FilePdfIcon size={18} weight="duotone" />
                            </div>

                            <div>
                                <p className="text-sm font-bold text-white">
                                    Official PDF Preview
                                </p>

                                <p className="text-[10px] text-slate-400">
                                    {quotationReference || "QT-2026-578"} • A4 Document
                                </p>
                            </div>
                        </div>

                        <div className="flex items-center gap-2">
                            <button
                                type="button"
                                onClick={() => window.print()}
                                className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-xs font-bold text-white transition hover:bg-red-700"
                            >
                                <FilePdfIcon size={16} weight="duotone" />
                                Print / Save PDF
                            </button>

                            <button
                                type="button"
                                onClick={() => setShowPdfPreview(false)}
                                className="rounded-lg border border-slate-700 bg-slate-900 px-4 py-2 text-xs font-bold text-slate-300 transition hover:bg-slate-800 hover:text-white"
                            >
                                Close
                            </button>
                        </div>
                    </div>

                    <div className="pdf-preview-scroll relative h-[calc(100vh-64px)] overflow-auto bg-slate-950/40 px-4 py-8 backdrop-blur-md sm:px-8">
                        <div id="official-pdf" className="pdf-page mx-auto w-[210mm] min-h-[297mm] bg-white text-slate-900 shadow-2xl">
                            <div className="px-[16mm] pt-[12mm]">
                                <div className="flex items-start justify-between border-b-2 border-red-600 pb-4">
                                    <div className="flex items-start gap-3">
                                        <div className="flex h-11 w-11 items-center justify-center rounded-md bg-red-600">
                                            <span className="text-sm font-black text-white">
                                                AR
                                            </span>
                                        </div>

                                        <div>
                                            <h1 className="text-[15px] font-black tracking-tight text-slate-900">
                                                ARGUS Network Solutions
                                            </h1>

                                            <p className="mt-0.5 text-[7px] font-semibold uppercase tracking-widest text-slate-500">
                                                Carrier-Grade Fibre Optics & Infrastructure Engineering
                                            </p>

                                            <p className="mt-2 text-[7px] leading-relaxed text-slate-500">
                                                100 Hope Road, Kingston 6, Jamaica • Tel: +1 (876) 900-3000
                                            </p>

                                            <p className="mt-0.5 text-[7px] leading-relaxed text-slate-500">
                                                TRN: 002-991-440 • GCT Reg #129038
                                            </p>
                                        </div>
                                    </div>

                                    <div className="text-right">
                                        <div className="inline-flex rounded-sm bg-slate-900 px-3 py-1">
                                            <span className="text-[8px] font-black tracking-wider text-white">
                                                COMMERCIAL QUOTATION
                                            </span>
                                        </div>

                                        <p className="mt-2 text-[8px] font-bold text-red-600">
                                            {quotationReference || "QT-2026-578"}
                                        </p>

                                        <p className="mt-1 text-[7px] text-slate-500">
                                            Date: 2026-08-29
                                        </p>

                                        <p className="mt-0.5 text-[7px] text-slate-500">
                                            Validity: {validityPeriod} Days
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="px-[16mm] pt-5">
                                <div className="grid grid-cols-2 gap-3">
                                    <PdfInfoBox
                                        title="Prepared For (Vendor)"
                                        items={[
                                            ["Vendor", selectedVendor?.name || "Seiretsu JA Ltd"],
                                            ["Address", "Suite 400, PanJam Building, 60 Knutsford Boulevard, Kingston 5, Jamaica"],
                                            ["TRN", "102-394-881"],
                                            ["Attn", "Marcus Sterling"],
                                        ]}
                                    />

                                    <PdfInfoBox
                                        title="Project Specification"
                                        items={[
                                            ["Project", projectName || "Seiretsu JA Ltd Fibre Expansion Phase 2"],
                                            ["Location", projectLocation || "Spalding Node 1"],
                                            ["Scope", scopeSummary || "Turnkey outside plant (OSP) cable construction, pole attachments, and fiber splicing."],
                                        ]}
                                    />
                                </div>
                            </div>

                            <div className="px-[16mm] pt-5">
                                <PdfSectionTitle>
                                    BILL OF QUANTITIES (BOQ) SCHEDULE BREAKDOWN
                                </PdfSectionTitle>

                                <div className="mt-3 space-y-5">
                                    {boqSections.map((section) => {
                                        const sectionRows = boqRows.filter((row) => row.section === section.id);
                                        const sectionTotal = sectionRows.reduce((total, row) => total + row.quantity * row.salesPrice, 0);

                                        return (
                                            <div key={section.id}>
                                                <div className="mb-2">
                                                    <p className="text-[8px] font-black text-slate-900">
                                                        {section.id}. {section.title}
                                                    </p>
                                                </div>

                                                <div className="overflow-hidden border border-slate-300">
                                                    <DataTable<BOQRow>
                                                        minWidth="1090px"
                                                        className="w-full"
                                                        columns={[
                                                            {
                                                                key: "module",
                                                                label: "Module",
                                                                width: "140px",
                                                                render: (row) => (
                                                                    <div className="flex h-8 w-full min-w-0 items-center">
                                                                        <span className="truncate text-[10px] font-medium text-slate-700">
                                                                            {row.module || "-"}
                                                                        </span>
                                                                    </div>
                                                                ),
                                                            },
                                                            {
                                                                key: "category",
                                                                label: "Category",
                                                                width: "150px",
                                                                sortable: true,
                                                                render: (row) => (
                                                                    <div className="flex h-8 w-full min-w-0 items-center">
                                                                        <span className="truncate text-[10px] font-medium text-slate-700">
                                                                            {row.category || "-"}
                                                                        </span>
                                                                    </div>
                                                                ),
                                                            },
                                                            {
                                                                key: "description",
                                                                label: "Description",
                                                                width: "220px",
                                                                render: (row) => (
                                                                    <div className="flex h-8 w-full min-w-0 items-center">
                                                                        <span className="truncate text-[10px] font-medium text-slate-700">
                                                                            {row.description || "-"}
                                                                        </span>
                                                                    </div>
                                                                ),
                                                            },
                                                            {
                                                                key: "quantity",
                                                                label: "Qty",
                                                                width: "70px",
                                                                align: "right",
                                                                render: (row) => (
                                                                    <div className="flex h-8 w-full items-center justify-end">
                                                                        <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                                                            {row.quantity}
                                                                        </span>
                                                                    </div>
                                                                ),
                                                            },
                                                            {
                                                                key: "uom",
                                                                label: "UOM",
                                                                width: "75px",
                                                                align: "center",
                                                                render: (row) => (
                                                                    <div className="flex h-8 w-full items-center justify-center">
                                                                        <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                                                            {row.uom || "-"}
                                                                        </span>
                                                                    </div>
                                                                ),
                                                            },
                                                            {
                                                                key: "materialCost",
                                                                label: "Material Cost",
                                                                width: "105px",
                                                                align: "right",
                                                                render: (row) => (
                                                                    <div className="flex h-8 w-full items-center justify-end">
                                                                        <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                                                            {CURRENCY} {formatCurrency(row.materialCost)}
                                                                        </span>
                                                                    </div>
                                                                ),
                                                            },
                                                            {
                                                                key: "serviceCost",
                                                                label: "Service Cost",
                                                                width: "105px",
                                                                align: "right",
                                                                render: (row) => (
                                                                    <div className="flex h-8 w-full items-center justify-end">
                                                                        <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                                                            {CURRENCY} {formatCurrency(row.serviceCost)}
                                                                        </span>
                                                                    </div>
                                                                ),
                                                            },
                                                            {
                                                                key: "salesPrice",
                                                                label: "Sales Price",
                                                                width: "105px",
                                                                align: "right",
                                                                render: (row) => (
                                                                    <div className="flex h-8 w-full items-center justify-end">
                                                                        <span className="whitespace-nowrap text-[10px] font-semibold text-red-700">
                                                                            {CURRENCY} {formatCurrency(row.salesPrice)}
                                                                        </span>
                                                                    </div>
                                                                ),
                                                            },
                                                            {
                                                                key: "gct",
                                                                label: "TAX %",
                                                                width: "75px",
                                                                align: "center",
                                                                render: (row) => (
                                                                    <div className="flex h-8 w-full items-center justify-center">
                                                                        <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                                                            {row.gct}%
                                                                        </span>
                                                                    </div>
                                                                ),
                                                            },
                                                            {
                                                                key: "lineTotal",
                                                                label: "Line Total",
                                                                width: "115px",
                                                                align: "right",
                                                                render: (row) => {
                                                                    const lineTotal = row.quantity * row.salesPrice;
                                                                    return (
                                                                        <div className="flex h-8 w-full items-center justify-end">
                                                                            <span className="whitespace-nowrap text-right text-[10px] font-bold text-slate-800">
                                                                                {CURRENCY} {formatCurrency(lineTotal)}
                                                                            </span>
                                                                        </div>
                                                                    );
                                                                },
                                                            },
                                                        ]}
                                                        data={sectionRows}
                                                        rowKey={(row) => row.id}
                                                        emptyMessage='No items in this section. Click "Add Item" to add a BOQ item.'
                                                    />

                                                    <div className="flex items-center justify-between border-x border-b border-slate-300 bg-slate-50 px-2 py-2">
                                                        <span className="flex-1 text-right text-[10px] font-bold text-slate-700">
                                                            Section {section.id} Subtotal:
                                                        </span>

                                                        <span className="w-[13%] text-right text-[11px] font-black text-slate-900">
                                                            ${formatCurrency(sectionTotal)}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>

                            <div className="flex justify-end px-[16mm] pt-5">
                                <div className="w-[78mm] border border-slate-300">
                                    <div className="bg-slate-50 px-3 py-2">
                                        <p className="text-[10px] font-black uppercase tracking-wider text-slate-500">
                                            BOQ Value Contribution
                                        </p>
                                    </div>

                                    <div className="space-y-2 px-3 py-3">
                                        <PdfTotalRow
                                            label="1. Milestones:"
                                            value={`$${formatCurrency(getSectionTotal(1))}`}
                                            color="border-blue-500"
                                        />

                                        <PdfTotalRow
                                            label="2. Materials:"
                                            value={`$${formatCurrency(getSectionTotal(2))}`}
                                            color="border-emerald-500"
                                        />

                                        <PdfTotalRow
                                            label="3. Services:"
                                            value={`$${formatCurrency(getSectionTotal(3))}`}
                                            color="border-sky-500"
                                        />

                                        <div className="my-2 border-t border-slate-200" />

                                        <PdfTotalRow
                                            label="Subtotal:"
                                            value={`$${formatCurrency(financialBreakdown.boqSubtotal)}`}
                                        />

                                        <PdfTotalRow
                                            label="GCT Tax (15%):"
                                            value={`$${formatCurrency(financialBreakdown.gctTax)}`}
                                        />

                                        <PdfTotalRow
                                            label="Mobilization & Fees:"
                                            value={`$${formatCurrency(financialBreakdown.siteMobilizationFee)}`}
                                        />

                                        <div className="mt-2 flex items-center justify-between border-t-2 border-slate-900 pt-2">
                                            <span className="text-[9px] font-black text-slate-900">
                                                GRAND TOTAL (USD):
                                            </span>

                                            <span className="text-[10px] font-black text-red-600">
                                                ${formatCurrency(financialBreakdown.grandTotal)}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="px-[16mm] pt-5">
                                <PdfSectionTitle>
                                    COMMERCIAL TERMS & CONDITIONS
                                </PdfSectionTitle>

                                <div className="mt-2 rounded border border-slate-200 px-3 py-3">
                                    <ol className="list-decimal space-y-1 pl-4 text-[10px] leading-relaxed text-slate-600">
                                        <li>
                                            Quotation valid for {validityPeriod} calendar days from issue date.
                                        </li>

                                        <li>
                                            Payment terms: Net 30 days as per contract.
                                        </li>

                                        <li>
                                            All work tested and certified to ITU-T G.652.D standards.
                                        </li>

                                        <li>
                                            GCT of 15% applied.
                                        </li>

                                        {terms.trim() && (
                                            <li className="whitespace-pre-line">
                                                {terms}
                                            </li>
                                        )}
                                    </ol>
                                </div>
                            </div>

                            <div className="px-[16mm] pt-6">
                                <div className="grid grid-cols-2 gap-8">
                                    <div>
                                        <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                                            Authorised Signatory (Contractor)
                                        </p>

                                        <div className="border-slate-300 pt-1.5">
                                            <p className="text-[8px] font-bold text-slate-800">
                                                Sarah Johnson
                                            </p>

                                            <p className="text-[7px] text-slate-500">
                                                VP of Network Operations, ARGUS
                                            </p>
                                        </div>
                                    </div>

                                    <div>
                                        <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                                            Vendor Approval & Signature
                                        </p>

                                        {!isSigned ? (
                                            <>
                                                <div className="mt-5">
                                                    <input
                                                        type="text"
                                                        value={vendorName}
                                                        onChange={(e) => setVendorName(e.target.value)}
                                                        placeholder="Type Full Name to Sign"
                                                        className="h-8 w-full border-b border-slate-300 bg-transparent px-1 text-[9px] font-medium text-slate-800 outline-none placeholder:text-slate-400 focus:border-red-600"
                                                    />

                                                    <p className="mt-1 text-[7px] text-slate-400">
                                                        Type Full Name to Sign
                                                    </p>
                                                </div>

                                                <button
                                                    type="button"
                                                    disabled={!vendorName.trim()}
                                                    onClick={() => {
                                                        const name = vendorName.trim();
                                                        if (!name) return;
                                                        setVendorName(name);
                                                        setSignedAt(new Date());
                                                        setIsSigned(true);
                                                    }}
                                                    className={`mt-3 rounded px-3 py-1.5 text-[7px] font-bold text-white transition-colors ${vendorName.trim()
                                                        ? "bg-red-600 hover:bg-red-700"
                                                        : "cursor-not-allowed bg-slate-300"
                                                        }`}
                                                >
                                                    Sign & Approve Quotation
                                                </button>
                                            </>
                                        ) : (
                                            <div className="mt-4">
                                                <div className="flex items-center gap-2">
                                                    <div className="flex h-5 w-5 items-center justify-center rounded-full bg-green-100">
                                                        <span className="text-[9px] font-black text-green-600">
                                                            ✓
                                                        </span>
                                                    </div>

                                                    <p className="text-[8px] font-bold uppercase tracking-wide text-green-600">
                                                        Digitally Signed
                                                    </p>
                                                </div>

                                                <div className="mt-4 border-b border-slate-300 pb-2">
                                                    <p className="text-[11px] font-semibold text-slate-800">
                                                        {vendorName}
                                                    </p>
                                                </div>

                                                {signedAt && (
                                                    <div className="mt-2">
                                                        <p className="text-[7px] text-slate-400">
                                                            Signed Date & Time
                                                        </p>

                                                        <p className="mt-0.5 text-[7px] font-medium text-slate-600">
                                                            {signedAt.toLocaleDateString("en-US", {
                                                                year: "numeric",
                                                                month: "long",
                                                                day: "numeric",
                                                            })}
                                                            {" • "}
                                                            {signedAt.toLocaleTimeString("en-US", {
                                                                hour: "2-digit",
                                                                minute: "2-digit",
                                                                second: "2-digit",
                                                            })}
                                                        </p>
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div className="px-[16mm] pt-6">
                                <div className="flex items-center justify-center rounded border border-emerald-200 bg-emerald-50 px-4 py-3">
                                    <div className="text-center">
                                        <p className="text-[8px] font-black uppercase tracking-widest text-emerald-700">
                                            DIGITALLY SEALED & VERIFIED
                                        </p>

                                        <p className="mt-1 text-[6px] text-emerald-600">
                                            This quotation is prepared by ARGUS Network Solutions.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="mt-8 border-t border-slate-200 px-[16mm] py-4">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-[6px] font-bold uppercase tracking-widest text-slate-400">
                                            ARGUS Network Solutions
                                        </p>

                                        <p className="mt-0.5 text-[6px] text-slate-400">
                                            Carrier-Grade Fibre Optics & Infrastructure Engineering
                                        </p>
                                    </div>

                                    <div className="text-right">
                                        <p className="text-[6px] font-bold text-slate-500">
                                            {quotationReference || "QT-2026-578"}
                                        </p>

                                        <p className="mt-0.5 text-[6px] text-slate-400">
                                            Official Commercial Quotation
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

interface BOQSectionTableProps {
    section: BOQSection;
    sectionIndex: number;
    rows: BOQRow[];
    onAddRow: (section: number) => void;
    onUpdateRow: <K extends keyof BOQRow>(id: number, field: K, value: BOQRow[K]) => void;
    onRemoveRow: (id: number) => void;
    getSectionTotal: (section: number) => number;
    formatCurrency: (value: number) => string;
    handleNumberChange: (value: string) => number;
}

interface PdfInfoBoxProps {
    title: string;
    items: [string, string][];
}

const PdfInfoBox = ({ title, items }: PdfInfoBoxProps) => {
    return (
        <div className="overflow-hidden rounded border border-slate-200">
            <div className="border-b border-slate-200 bg-slate-50 px-3 py-2">
                <p className="text-[7px] font-black uppercase tracking-wider text-slate-600">
                    {title}
                </p>
            </div>

            <div className="space-y-2 px-3 py-3">
                {items.map(([label, value]) => (
                    <div key={label} className="grid grid-cols-[70px_minmax(0,1fr)] gap-2">
                        <span className="text-[7px] font-semibold text-slate-400">
                            {label}
                        </span>

                        <span className="text-[7px] leading-relaxed text-slate-700">
                            {value}
                        </span>
                    </div>
                ))}
            </div>
        </div>
    );
};

interface PdfSectionTitleProps {
    children: React.ReactNode;
}

const PdfSectionTitle = ({ children }: PdfSectionTitleProps) => {
    return (
        <div className="flex items-center gap-2">
            <div className="h-4 w-1 rounded-full bg-red-600" />
            <h2 className="text-[9px] font-black uppercase tracking-widest text-slate-900">
                {children}
            </h2>
        </div>
    );
};

interface PdfTotalRowProps {
    label: string;
    value: string;
    color?: string;
}

const PdfTotalRow = ({ label, value, color }: PdfTotalRowProps) => {
    return (
        <div className="flex items-center justify-between gap-3">
            <div className={`border-l-2 pl-2 ${color ?? "border-slate-300"}`}>
                <span className="text-[7px] font-semibold text-slate-600">
                    {label}
                </span>
            </div>

            <span className="whitespace-nowrap text-[7px] font-bold text-slate-800">
                {value}
            </span>
        </div>
    );
};

type CategoryOption = {
    value: string;
    label: string;
};

const BOQSectionTable = ({
    section,
    sectionIndex,
    rows,
    onAddRow,
    onUpdateRow,
    onRemoveRow,
    getSectionTotal,
    formatCurrency,
    handleNumberChange,
}: BOQSectionTableProps) => {
    const sectionRows = rows.filter((row) => row.section === section.id);

    const CATEGORY_OPTIONS: Record<number, CategoryOption[]> = {
        1: [
            { value: "Civil Works", label: "Civil Works" },
            { value: "Permitting", label: "Permitting" },
            { value: "Logistics", label: "Logistics" },
        ],
        2: [
            { value: "Fiber Optics", label: "Fiber Optics" },
            { value: "Hardware & Active Gears", label: "Hardware & Active Gears" },
            { value: "Materials", label: "Materials" },
        ],
        3: [
            { value: "Splicing & Testing", label: "Splicing & Testing" },
            { value: "Engineering Services", label: "Engineering Services" },
            { value: "Labour", label: "Labour" },
        ],
    };

    return (
        <div className={`p-5 ${sectionIndex > 0 ? "border-t border-slate-100" : ""}`}>
            <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-3">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-red-600 text-xs font-bold text-white">
                        {section.id}
                    </div>

                    <div>
                        <h3 className="text-xs font-bold uppercase text-slate-900">
                            {section.title}
                        </h3>

                        <p className="mt-0.5 text-[10px] uppercase text-slate-400">
                            Section Total: {CURRENCY} {formatCurrency(getSectionTotal(section.id))}
                        </p>
                    </div>
                </div>

                {/* <button
                    type="button"
                    onClick={() => onAddRow(section.id)}
                    className="flex items-center justify-center gap-1.5 rounded-lg bg-slate-100 px-3 py-2 text-[11px] font-semibold text-slate-600 transition hover:bg-slate-200 hover:text-red-600"
                >
                    <PlusIcon size={13} weight="bold" />
                    Add Item
                </button> */}
            </div>

            <DataTable<BOQRow>
                minWidth="1090px"
                className="w-full"
                columns={[
                    {
                        key: "module",
                        label: "Module",
                        width: "140px",
                        render: (row) => (
                            <div className="flex h-8 w-full min-w-0 items-center">
                                <span className="truncate text-[10px] font-medium text-slate-700">
                                    {row.module || "-"}
                                </span>
                            </div>
                        ),
                    },
                    {
                        key: "category",
                        label: "Category",
                        width: "150px",
                        sortable: true,
                        render: (row) => (
                            <div className="flex h-8 w-full min-w-0 items-center">
                                <span className="truncate text-[10px] font-medium text-slate-700">
                                    {row.category || "-"}
                                </span>
                            </div>
                        ),
                    },
                    {
                        key: "description",
                        label: "Description",
                        width: "220px",
                        render: (row) => (
                            <div className="flex h-8 w-full min-w-0 items-center">
                                <span className="truncate text-[10px] font-medium text-slate-700">
                                    {row.description || "-"}
                                </span>
                            </div>
                        ),
                    },
                    {
                        key: "quantity",
                        label: "Qty",
                        width: "70px",
                        align: "right",
                        render: (row) => (
                            <div className="flex h-8 w-full items-center justify-end">
                                <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                    {row.quantity}
                                </span>
                            </div>
                        ),
                    },
                    {
                        key: "uom",
                        label: "UOM",
                        width: "75px",
                        align: "center",
                        render: (row) => (
                            <div className="flex h-8 w-full items-center justify-center">
                                <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                    {row.uom || "-"}
                                </span>
                            </div>
                        ),
                    },
                    {
                        key: "materialCost",
                        label: "Material Cost",
                        width: "105px",
                        align: "right",
                        render: (row) => (
                            <div className="flex h-8 w-full items-center justify-end">
                                <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                    {CURRENCY} {formatCurrency(row.materialCost)}
                                </span>
                            </div>
                        ),
                    },
                    {
                        key: "serviceCost",
                        label: "Service Cost",
                        width: "105px",
                        align: "right",
                        render: (row) => (
                            <div className="flex h-8 w-full items-center justify-end">
                                <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                    {CURRENCY} {formatCurrency(row.serviceCost)}
                                </span>
                            </div>
                        ),
                    },
                    {
                        key: "salesPrice",
                        label: "Sales Price",
                        width: "105px",
                        align: "right",
                        render: (row) => (
                            <div className="flex h-8 w-full items-center justify-end">
                                <div className="flex items-center gap-1">
                                    <span className="text-[10px] font-medium text-slate-500">
                                        {CURRENCY}
                                    </span>

                                    <input
                                        type="number"
                                        value={row.salesPrice}
                                        onChange={(e) =>
                                            onUpdateRow(
                                                row.id,
                                                "salesPrice",
                                                Number(e.target.value)
                                            )
                                        }
                                        className="h-7 w-[75px] rounded border border-slate-300 bg-white px-2 text-right text-[10px] font-semibold text-red-700 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                                        min="0"
                                        step="0.01"
                                    />
                                </div>
                            </div>
                        ),
                    },
                    {
                        key: "gct",
                        label: "TAX %",
                        width: "75px",
                        align: "center",
                        render: (row) => (
                            <div className="flex h-8 w-full items-center justify-center">
                                <span className="whitespace-nowrap text-[10px] font-medium text-slate-700">
                                    {row.gct}%
                                </span>
                            </div>
                        ),
                    },
                    {
                        key: "lineTotal",
                        label: "Line Total",
                        width: "115px",
                        align: "right",
                        render: (row) => {
                            const lineTotal = row.quantity * row.salesPrice;
                            return (
                                <div className="flex h-8 w-full items-center justify-end">
                                    <span className="whitespace-nowrap text-right text-[10px] font-bold text-slate-800">
                                        {CURRENCY} {formatCurrency(lineTotal)}
                                    </span>
                                </div>
                            );
                        },
                    },
                ]}
                data={sectionRows}
                rowKey={(row) => row.id}
                emptyMessage='No items in this section. Click "Add Item" to add a BOQ item.'
            />
        </div>
    );
};

interface SummaryRowProps {
    label: string;
    value: number;
    formatCurrency: (value: number) => string;
}

function SummaryRow({ label, value, formatCurrency }: SummaryRowProps) {
    return (
        <div className="flex items-center justify-between gap-4">
            <span className="text-xs text-slate-400">
                {label}
            </span>

            <span className="whitespace-nowrap text-xs font-semibold text-slate-300">
                {CURRENCY} {formatCurrency(value)}
            </span>
        </div>
    );
}

interface InfoRowProps {
    label: string;
    value: string | number;
}

const InfoRow = ({ label, value }: InfoRowProps) => {
    return (
        <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">
                {label}
            </span>

            <span className="text-xs font-semibold text-slate-700">
                {value}
            </span>
        </div>
    );
};

export default NewQuotation;