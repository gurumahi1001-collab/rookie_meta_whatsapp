import {
    CheckIcon,
    EraserIcon,
    FileTextIcon,
    XIcon,
} from "@phosphor-icons/react";
import { useEffect, useRef, useState } from "react";

interface TermsConditionModalProps {
    open: boolean;
    onAccept: (signature: {
        signerName: string;
        signature: string;
        signedAt: string;
    }) => void;
    onClose?: () => void;
}

export default function TermsConditionModal({
    open,
    onAccept,
    onClose,
}: TermsConditionModalProps) {
    const [accepted, setAccepted] = useState(false);
    const [signerName, setSignerName] = useState("");
    const [isDrawing, setIsDrawing] = useState(false);
    const [hasSignature, setHasSignature] = useState(false);
    const [signatureFileName, setSignatureFileName] = useState("");


    const canvasRef = useRef<HTMLCanvasElement | null>(null);

    /*
     * Reset the form whenever the modal is opened.
     */
    useEffect(() => {
        if (open) {
            setAccepted(false);
            setSignerName("");
            setIsDrawing(false);
            setHasSignature(false);

            const canvas = canvasRef.current;

            if (canvas) {
                const context = canvas.getContext("2d");

                if (context) {
                    context.clearRect(
                        0,
                        0,
                        canvas.width,
                        canvas.height
                    );
                }
            }
        }
    }, [open]);

    if (!open) {
        return null;
    }

    /* =========================================================
       SIGNATURE HELPERS
    ========================================================= */

    const getCanvasCoordinates = (
        event:
            | React.MouseEvent<HTMLCanvasElement>
            | React.TouchEvent<HTMLCanvasElement>
    ) => {
        const canvas = canvasRef.current;

        if (!canvas) {
            return {
                x: 0,
                y: 0,
            };
        }

        const rect = canvas.getBoundingClientRect();

        /*
         * Scale coordinates because the canvas has a fixed
         * internal resolution but responsive CSS width.
         */
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;

        if ("touches" in event) {
            const touch = event.touches[0];

            return {
                x:
                    (touch.clientX - rect.left) *
                    scaleX,
                y:
                    (touch.clientY - rect.top) *
                    scaleY,
            };
        }

        return {
            x:
                (event.clientX - rect.left) *
                scaleX,
            y:
                (event.clientY - rect.top) *
                scaleY,
        };
    };

    const startDrawing = (
        event:
            | React.MouseEvent<HTMLCanvasElement>
            | React.TouchEvent<HTMLCanvasElement>
    ) => {
        event.preventDefault();

        const canvas = canvasRef.current;

        if (!canvas) {
            return;
        }

        const context = canvas.getContext("2d");

        if (!context) {
            return;
        }

        const { x, y } =
            getCanvasCoordinates(event);

        context.beginPath();
        context.moveTo(x, y);

        context.lineWidth = 2;
        context.lineCap = "round";
        context.lineJoin = "round";
        context.strokeStyle = "#0f172a";

        setIsDrawing(true);
    };

    const drawSignature = (
        event:
            | React.MouseEvent<HTMLCanvasElement>
            | React.TouchEvent<HTMLCanvasElement>
    ) => {
        if (!isDrawing) {
            return;
        }

        event.preventDefault();

        const canvas = canvasRef.current;

        if (!canvas) {
            return;
        }

        const context = canvas.getContext("2d");

        if (!context) {
            return;
        }

        const { x, y } =
            getCanvasCoordinates(event);

        context.lineWidth = 2;
        context.lineCap = "round";
        context.lineJoin = "round";
        context.strokeStyle = "#0f172a";

        context.lineTo(x, y);
        context.stroke();

        setHasSignature(true);
    };

    const stopDrawing = () => {
        setIsDrawing(false);
    };

    const clearSignature = () => {
        const canvas = canvasRef.current;

        if (!canvas) {
            return;
        }

        const context = canvas.getContext("2d");

        if (!context) {
            return;
        }

        context.clearRect(
            0,
            0,
            canvas.width,
            canvas.height
        );

        setHasSignature(false);
    };

    /* =========================================================
       ACCEPT TERMS
    ========================================================= */

    const handleAccept = () => {
        /*
         * All three conditions are mandatory:
         *
         * 1. Terms checkbox
         * 2. Signer name
         * 3. Electronic signature
         */
        if (!accepted) {
            return;
        }

        if (!signerName.trim()) {
            return;
        }

        if (!hasSignature) {
            return;
        }

        const canvas = canvasRef.current;

        if (!canvas) {
            return;
        }

        const signature =
            canvas.toDataURL("image/png");

        onAccept({
            signerName: signerName.trim(),
            signature,
            signedAt:
                new Date().toISOString(),
        });
    };

    const canAccept =
        accepted &&
        signerName.trim().length > 0 &&
        hasSignature;

    return (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-950/50 p-4 backdrop-blur-sm">
            <div className="flex max-h-[95vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl">

                {/* =================================================
                    HEADER
                ================================================= */}

                <div className="flex shrink-0 items-center justify-between border-b border-slate-200 px-6 py-5">
                    <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-700">
                            <FileTextIcon
                                size={20}
                                weight="duotone"
                            />
                        </div>

                        <div>
                            <h2 className="text-base font-bold text-slate-900">
                                Telecom Terms & Conditions
                            </h2>

                            <p className="mt-0.5 text-xs text-slate-500">
                                Please review and accept these
                                terms before continuing.
                            </p>
                        </div>
                    </div>

                    {onClose && (
                        <button
                            type="button"
                            onClick={onClose}
                            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                            aria-label="Close"
                        >
                            <XIcon size={18} />
                        </button>
                    )}
                </div>

                {/* =================================================
                    TERMS & CONDITIONS CONTENT
                ================================================= */}

                <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">
                    <div className="space-y-5 text-sm leading-6 text-slate-600">

                        {/* Introduction */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                Terms & Conditions
                            </h3>

                            <p>
                                These Terms & Conditions govern
                                the use of the telecom management
                                platform and the services, projects,
                                quotations, procurement activities,
                                vendor engagements, network
                                operations, billing and related
                                business processes managed through
                                the system.
                            </p>
                        </div>

                        {/* 1 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                1. Scope of Services
                            </h3>

                            <p>
                                The platform may be used to manage
                                telecom projects, network deployments,
                                infrastructure requirements, vendor
                                quotations, purchase orders, service
                                requests, invoices, assets, field
                                activities, maintenance activities
                                and other telecommunications-related
                                operations.
                            </p>
                        </div>

                        {/* 2 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                2. Telecom Services and Network Availability
                            </h3>

                            <p>
                                Telecom services may depend on
                                network availability, infrastructure
                                capacity, equipment, third-party
                                providers, regulatory approvals,
                                geographical coverage, maintenance
                                activities and other operational
                                conditions. Service availability
                                and performance are therefore
                                subject to the applicable service
                                level agreement (SLA), service order
                                or commercial agreement.
                            </p>
                        </div>

                        {/* 3 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                3. Network Maintenance and Service Interruptions
                            </h3>

                            <p>
                                Planned or emergency maintenance,
                                network upgrades, equipment failures,
                                fiber cuts, power failures,
                                congestion, environmental conditions
                                and other technical incidents may
                                result in temporary service
                                interruptions. Reasonable efforts
                                will be made to minimize the impact
                                and restore affected services as
                                soon as reasonably practicable.
                            </p>
                        </div>

                        {/* 4 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                4. Projects, Installations and Deployment
                            </h3>

                            <p>
                                Telecom deployment activities may
                                include fiber installation, wireless
                                infrastructure, towers, antennas,
                                ducts, cables, routers, switches,
                                transmission equipment, power
                                systems, data centers and other
                                network infrastructure.
                            </p>

                            <p className="mt-2">
                                Project timelines may depend on site
                                readiness, permits, right-of-way
                                approvals, material availability,
                                access permissions, weather
                                conditions, third-party dependencies
                                and other factors outside reasonable
                                operational control.
                            </p>
                        </div>

                        {/* 5 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                5. Vendor Quotations and Commercial Offers
                            </h3>

                            <p>
                                Vendors are responsible for ensuring
                                that quotations, proposals, pricing,
                                technical specifications, delivery
                                schedules, warranties and other
                                information submitted through the
                                platform are accurate and complete.
                            </p>

                            <p className="mt-2">
                                Submission of a quotation does not
                                by itself constitute acceptance or
                                create an obligation to purchase.
                                Orders and engagements become binding
                                only upon authorized approval,
                                purchase order, contract or other
                                applicable commercial agreement.
                            </p>
                        </div>

                        {/* 6 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                6. Equipment, Materials and Specifications
                            </h3>

                            <p>
                                Telecom equipment and materials
                                supplied for a project must comply
                                with the agreed technical
                                specifications, applicable standards,
                                quality requirements, certifications
                                and approved manufacturer or supplier
                                requirements.
                            </p>

                            <p className="mt-2">
                                Any substitution of equipment,
                                components or materials requires
                                appropriate technical and commercial
                                approval before implementation.
                            </p>
                        </div>

                        {/* 7 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                7. Service Levels and Performance
                            </h3>

                            <p>
                                Where applicable, service levels,
                                uptime commitments, response times,
                                restoration targets, latency
                                requirements and other performance
                                obligations will be governed by the
                                applicable SLA or service agreement.
                            </p>
                        </div>

                        {/* 8 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                8. Billing, Invoicing and Payments
                            </h3>

                            <p>
                                Charges, taxes, recurring fees,
                                installation charges, usage charges,
                                equipment costs and other applicable
                                fees will be determined by the
                                relevant quotation, purchase order,
                                contract or service agreement.
                            </p>

                            <p className="mt-2">
                                Invoices must accurately reflect the
                                services, equipment or deliverables
                                provided. Payment terms, invoice
                                disputes and applicable taxes will
                                be handled according to the applicable
                                commercial agreement.
                            </p>
                        </div>

                        {/* 9 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                9. Regulatory and Legal Compliance
                            </h3>

                            <p>
                                All parties must comply with
                                applicable telecommunications laws,
                                regulations, licensing requirements,
                                spectrum requirements, technical
                                standards, data protection laws,
                                safety requirements and directions
                                issued by relevant regulatory
                                authorities.
                            </p>
                        </div>

                        {/* 10 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                10. Site Access and Safety
                            </h3>

                            <p>
                                Personnel, contractors and vendors
                                performing telecom installation,
                                maintenance or field activities must
                                follow applicable health, safety,
                                security and site-access requirements.
                                Required permits, certifications,
                                protective equipment and site
                                approvals must be obtained before
                                carrying out work where applicable.
                            </p>
                        </div>

                        {/* 11 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                11. Data and Confidential Information
                            </h3>

                            <p>
                                Business information, customer
                                information, network information,
                                technical documents, pricing,
                                contracts, credentials and other
                                confidential information accessed
                                through the platform must be protected
                                from unauthorized access, disclosure,
                                alteration or misuse.
                            </p>
                        </div>

                        {/* 12 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                12. Cybersecurity and Acceptable Use
                            </h3>

                            <p>
                                Users must not attempt to gain
                                unauthorized access to systems,
                                network infrastructure, accounts,
                                devices or data. The platform must
                                not be used for unauthorized network
                                scanning, disruption, malicious
                                activity, fraudulent activity, abuse
                                of telecom services or any activity
                                that may compromise network or
                                information security.
                            </p>
                        </div>

                        {/* 13 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                13. Customer and Subscriber Information
                            </h3>

                            <p>
                                Where customer or subscriber
                                information is processed, users must
                                handle such information only for
                                authorized business purposes and in
                                accordance with applicable privacy
                                and data protection requirements.
                            </p>
                        </div>

                        {/* 14 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                14. Third-Party Services
                            </h3>

                            <p>
                                Certain telecom services,
                                infrastructure, connectivity, cloud
                                services, equipment, hosting, payment
                                services or other components may be
                                provided by third parties. Availability
                                and performance of third-party services
                                may be subject to their respective
                                terms, service levels and operational
                                limitations.
                            </p>
                        </div>

                        {/* 15 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                15. Force Majeure
                            </h3>

                            <p>
                                No party shall be considered in breach
                                for delays or failures caused by
                                circumstances beyond reasonable
                                control, including natural disasters,
                                severe weather, fire, flood,
                                earthquakes, war, civil disturbance,
                                power failures, major network
                                incidents, government actions,
                                regulatory restrictions, strikes or
                                widespread infrastructure failures.
                            </p>
                        </div>

                        {/* 16 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                16. Intellectual Property
                            </h3>

                            <p>
                                Software, platform features,
                                documentation, designs, trademarks,
                                processes and other intellectual
                                property remain the property of their
                                respective owners unless otherwise
                                agreed in writing.
                            </p>
                        </div>

                        {/* 17 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                17. Suspension and Termination
                            </h3>

                            <p>
                                Access to the platform or related
                                services may be suspended or terminated
                                where there is a material breach of
                                these terms, unauthorized use, security
                                risk, non-payment or other circumstances
                                permitted under the applicable
                                agreement.
                            </p>
                        </div>

                        {/* 18 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                18. Limitation of Liability
                            </h3>

                            <p>
                                Liability for service interruptions,
                                delays, equipment failures, data loss,
                                third-party dependencies or other
                                incidents shall be governed by the
                                applicable contract, SLA and applicable
                                law.
                            </p>
                        </div>

                        {/* 19 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                19. Changes to Terms
                            </h3>

                            <p>
                                These Terms & Conditions may be updated
                                from time to time to reflect changes in
                                services, technology, business processes,
                                regulatory requirements or applicable
                                law. Updated terms will become effective
                                in accordance with the applicable
                                notification or contractual
                                requirements.
                            </p>
                        </div>

                        {/* 20 */}

                        <div>
                            <h3 className="mb-2 font-bold text-slate-800">
                                20. Acceptance
                            </h3>

                            <p>
                                By clicking "Accept & Continue", you
                                confirm that you have read, understood
                                and agreed to comply with these Terms &
                                Conditions and any applicable service
                                agreements, purchase orders, SLAs and
                                related commercial documentation.
                            </p>
                        </div>

                        {/* Final Notice */}

                        <div className="rounded-lg border border-blue-100 bg-blue-50 p-4">
                            <p className="text-xs leading-5 text-blue-800">
                                These Terms & Conditions should be read
                                together with any applicable service
                                agreement, SLA, quotation, purchase
                                order, privacy policy and other
                                contractual documents governing the
                                relevant telecom service or transaction.
                            </p>
                        </div>
                    </div>
                </div>

                <div className="shrink-0 border-t border-slate-200 bg-white px-6 py-4">
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-4">
                {/* Signature Header */}
                <div className="mb-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                            <CheckIcon size={14} weight="bold" />
                        </div>

                        <div>
                            <h3 className="text-xs font-bold text-slate-900">
                                Electronic Signature
                            </h3>

                            <p className="text-[10px] text-slate-400">
                                Draw your signature or upload an existing one.
                            </p>
                        </div>
                    </div>

                    {hasSignature && (
                        <button
                            type="button"
                            onClick={clearSignature}
                            className="inline-flex items-center gap-1 text-[10px] font-semibold text-slate-400 transition hover:text-red-600"
                        >
                            <EraserIcon size={12} />
                            Clear
                        </button>
                    )}
                </div>

                {/* Signer Name */}
                <input
                    id="signer-name"
                    type="text"
                    value={signerName}
                    onChange={(event) =>
                        setSignerName(event.target.value)
                    }
                    placeholder="Signatory full name"
                    className="mb-3 w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-xs text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-red-500 focus:ring-2 focus:ring-red-100"
                />

                {/* Signature Pad + Upload - Same Row */}
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_auto]">
                    {/* Signature Board */}
                    <div>
                        <div className="overflow-hidden rounded-md border border-slate-200 bg-white">
                            <canvas
                                ref={canvasRef}
                                width={900}
                                height={70}
                                onMouseDown={startDrawing}
                                onMouseMove={drawSignature}
                                onMouseUp={stopDrawing}
                                onMouseLeave={stopDrawing}
                                onTouchStart={startDrawing}
                                onTouchMove={drawSignature}
                                onTouchEnd={stopDrawing}
                                className="h-[50px] w-full cursor-crosshair touch-none"
                            />
                        </div>

                        <p className="mt-1 text-[9px] text-slate-400">
                            Draw your signature or upload image
                        </p>
                    </div>

                    {/* Upload Signature */}
                   <div className="flex flex-col items-center justify-center mb-2">
                        {/* Selected File Name */}
                        {signatureFileName && (
                            <p
                                className=" max-w-[150px] truncate text-[9px] font-medium text-slate-500"
                                title={signatureFileName}
                            >
                                {signatureFileName}
                            </p>
                        )}

                        {/* Upload Button */}
                        <label className="inline-flex h-7 cursor-pointer items-center gap-1.5 rounded-md border border-red-200 bg-red-50 px-3 text-[10px] font-semibold text-red-600 transition hover:bg-red-100">
                            <span>↑</span>
                            {signatureFileName ? "Change Signature" : "Upload Signature"}

                            <input
                                type="file"
                                accept="image/png,image/jpeg"
                                className="hidden"
                                onChange={(event) => {
                                    const file = event.target.files?.[0];

                                    if (file) {
                                        setSignatureFileName(file.name);
                                        console.log(file);
                                    }
                                }}
                            />
                        </label>
                    </div>

                </div>

                {/* Divider */}
                <div className="my-4 border-t border-slate-200" />

                {/* Acceptance */}
                <div>
                    <h3 className="mb-2 text-xs font-bold text-slate-800">
                        Acceptance
                    </h3>

                    <label className="flex cursor-pointer items-start gap-3">
                        <input
                            type="checkbox"
                            checked={accepted}
                            onChange={(event) =>
                                setAccepted(event.target.checked)
                            }
                            className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer rounded border-slate-300 text-red-600 accent-red-500 focus:ring-red-500"
                        />

                        <span className="text-xs leading-5 text-slate-600">
                            I have read, understood, and agree to the{" "}
                            <span className="font-semibold text-slate-800">
                                Terms & Conditions
                            </span>{" "}
                            and confirm that the electronic signature provided
                            represents my acceptance.
                        </span>
                    </label>
                </div>
            </div>
            </div> 

            <div className="flex shrink-0 items-center justify-between gap-3 border-t border-slate-200 bg-slate-50 px-6 py-3">
                <div className="text-[10px] text-slate-400">
                    {!accepted && (
                        <span>
                            Please accept the Terms & Conditions.
                        </span>
                    )}

                    {accepted && !signerName.trim() && (
                        <span>
                            Please enter your full name.
                        </span>
                    )}

                    {accepted &&
                        signerName.trim() &&
                        !hasSignature && (
                            <span>
                                Please provide your signature. or Upload image
                            </span>
                        )}

                    {canAccept && (
                        <span className="font-medium text-emerald-600">
                            Ready to sign and continue.
                        </span>
                    )}
                </div>

                <div className="flex items-center gap-3">
                    {onClose && (
                        <button
                            type="button"
                            onClick={onClose}
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-600 transition hover:bg-slate-100"
                        >
                            Cancel
                        </button>
                    )}

                    <button
                        type="button"
                        onClick={handleAccept}
                        disabled={!canAccept}
                        className={`inline-flex items-center gap-2 rounded-lg px-5 py-2 text-xs font-bold text-white shadow-sm transition ${
                            canAccept
                                ? "bg-blue-600 hover:bg-blue-700"
                                : "cursor-not-allowed bg-slate-300"
                        }`}
                    >
                        <CheckIcon
                            size={15}
                            weight="bold"
                        />

                        Accept & Continue
                    </button>
                </div>
            </div>

            </div>
        </div>
    );
}
