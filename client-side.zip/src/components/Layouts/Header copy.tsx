import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { IRootState } from '../../store';
import { toggleRTL, toggleTheme, toggleSidebar } from '../../store/themeConfigSlice';
import { useTranslation } from 'react-i18next';
import i18next from 'i18next';
import Dropdown from '../Dropdown';
import IconMenu from '../Icon/IconMenu';
import IconCalendar from '../Icon/IconCalendar';
import IconEdit from '../Icon/IconEdit';
import IconChatNotification from '../Icon/IconChatNotification';
import IconSearch from '../Icon/IconSearch';
import IconXCircle from '../Icon/IconXCircle';
import IconSun from '../Icon/IconSun';
import IconMoon from '../Icon/IconMoon';
import IconLaptop from '../Icon/IconLaptop';
import IconMailDot from '../Icon/IconMailDot';
import IconArrowLeft from '../Icon/IconArrowLeft';
import IconInfoCircle from '../Icon/IconInfoCircle';
import IconBellBing from '../Icon/IconBellBing';
import IconUser from '../Icon/IconUser';
import IconMail from '../Icon/IconMail';
import IconLockDots from '../Icon/IconLockDots';
import IconLogout from '../Icon/IconLogout';
import IconMenuDashboard from '../Icon/Menu/IconMenuDashboard';
import IconCaretDown from '../Icon/IconCaretDown';
import IconMenuApps from '../Icon/Menu/IconMenuApps';
import IconMenuComponents from '../Icon/Menu/IconMenuComponents';
import IconMenuElements from '../Icon/Menu/IconMenuElements';
import IconMenuDatatables from '../Icon/Menu/IconMenuDatatables';
import IconMenuForms from '../Icon/Menu/IconMenuForms';
import IconMenuPages from '../Icon/Menu/IconMenuPages';
import IconMenuMore from '../Icon/Menu/IconMenuMore';
import { favIcon } from '../../assets/image';
import { useAuth } from '../../auth/AuthProvider';
import api from '../../api/axios';

const Header = () => {
    const location = useLocation();
    useEffect(() => {
        const selector = document.querySelector('ul.horizontal-menu a[href="' + window.location.pathname + '"]');
        if (selector) {
            selector.classList.add('active');
            const all: any = document.querySelectorAll('ul.horizontal-menu .nav-link.active');
            for (let i = 0; i < all.length; i++) {
                all[0]?.classList.remove('active');
            }
            const ul: any = selector.closest('ul.sub-menu');
            if (ul) {
                let ele: any = ul.closest('li.menu').querySelectorAll('.nav-link');
                if (ele) {
                    ele = ele[0];
                    setTimeout(() => {
                        ele?.classList.add('active');
                    });
                }
            }
        }
    }, [location]);

    const isRtl = useSelector((state: IRootState) => state.themeConfig.rtlClass) === 'rtl' ? true : false;

    const themeConfig = useSelector((state: IRootState) => state.themeConfig);
    const dispatch = useDispatch();
    const { user, role, signOut } = useAuth();

    const displayName =
        user?.displayName?.trim() ||
        user?.email?.split('@')[0] ||
        'User';

    const email = user?.email || '';
    const roleLabel =
        role?.name?.trim() ||
        role?.key?.trim() ||
        user?.userType ||
        'User';

    const profileImageUrl =
        user?.profileImage && user?.id
            ? `${String(api.defaults.baseURL || '').replace(/\/+$/, '')}/users/${encodeURIComponent(user.id)}/avatar?ts=${encodeURIComponent(
                  user.profileImage.uploadedAt || 'current',
              )}`
            : null;

    const profileInitials = displayName
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 2)
        .map((part) => part.charAt(0))
        .join('')
        .toUpperCase();


    const [notifications, setNotifications] = useState([
        {
            id: 1,
            profile: 'user-profile.jpeg',
            message: '<strong className="text-sm mr-1">John Doe</strong>invite you to <strong>Prototyping</strong>',
            time: '45 min ago',
        },
        {
            id: 2,
            profile: 'profile-34.jpeg',
            message: '<strong className="text-sm mr-1">Adam Nolan</strong>mentioned you to <strong>UX Basics</strong>',
            time: '9h Ago',
        },
        {
            id: 3,
            profile: 'profile-16.jpeg',
            message: '<strong className="text-sm mr-1">Anna Morgan</strong>Upload a file',
            time: '9h Ago',
        },
    ]);

    const removeNotification = (value: number) => {
        setNotifications(notifications.filter((user) => user.id !== value));
    };
    const handleLogout = async () => {
        await signOut();
    };


    return (
        <header className={`z-40 ${themeConfig.semidark && themeConfig.menu === 'horizontal' ? 'dark' : ''}`}>
            <div className="shadow-sm">
                <div className="relative bg-white flex w-full items-center px-5 py-2.5 dark:bg-black">
                    <div className="horizontal-logo flex lg:hidden justify-between items-center ltr:mr-2 rtl:ml-2">
                        <Link to="/" className="main-logo flex items-center shrink-0">
                            <img className="w-8 ltr:-ml-1 rtl:-mr-1 inline" src={favIcon} alt="logo" />
                            <span className="text-2xl ltr:ml-1.5 rtl:mr-1.5  font-bold text-primary  align-middle hidden md:inline dark:text-white-light transition-all duration-300">Argus</span>
                        </Link>
                        <button
                            type="button"
                            className="collapse-icon flex-none dark:text-[#d0d2d6] hover:text-primary dark:hover:text-primary flex lg:hidden ltr:ml-2 rtl:mr-2 p-2 rounded-full bg-white-light/40 dark:bg-dark/40 hover:bg-white-light/90 dark:hover:bg-dark/60"
                            onClick={() => {
                                dispatch(toggleSidebar());
                            }}
                        >
                            <IconMenu className="w-5 h-5" />
                        </button>
                    </div>

                    <div className="sm:flex-1 ltr:sm:ml-0 ltr:ml-auto sm:rtl:mr-0 rtl:mr-auto flex items-center space-x-1.5 lg:space-x-2 rtl:space-x-reverse dark:text-[#d0d2d6]">
                        <div className="sm:ltr:mr-auto sm:rtl:ml-auto">
                            {/* <button
                                type="button"
                                onClick={() => setSearch(!search)}
                                className="search_btn sm:hidden p-2 rounded-full bg-white-light/40 dark:bg-dark/40 hover:bg-white-light/90 dark:hover:bg-dark/60"
                            >
                                <IconSearch className="w-4.5 h-4.5 mx-auto dark:text-[#d0d2d6]" />
                            </button> */}
                        </div>
                        <div className="flex items-center gap-4">
                            {/* Notification Dropdown */}
                           <div className="shrink-0">
    <Dropdown
        offset={[0, 8]}
        placement={isRtl ? 'bottom-start' : 'bottom-end'}
        btnClassName="relative flex h-10 w-10 items-center justify-center rounded-full p-2 transition hover:bg-white-light/90 hover:text-primary dark:bg-dark/40 dark:hover:bg-dark/60"
        button={
            <span className="relative flex items-center justify-center">
                <IconBellBing />

                {/* Notification indicator */}
                {notifications.length > 0 && (
                    <span className="absolute -right-0.5 -top-0.5 flex h-3 w-3">
                        <span className="absolute -left-[3px] -top-[3px] inline-flex h-full w-full animate-ping rounded-full bg-success/50 opacity-75" />

                        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-success" />
                    </span>
                )}
            </span>
        }
    >
        <div className="w-[320px] overflow-hidden rounded-lg bg-white text-dark shadow-lg dark:bg-[#1b2e4b] dark:text-white-dark sm:w-[380px]">

            {/* =====================================================
                HEADER
            ====================================================== */}
            <div
                className="flex items-center justify-between border-b border-slate-200 px-4 py-3 dark:border-white/10"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex items-center gap-2">
                    <IconBellBing className="text-primary" />

                    <h4 className="text-base font-semibold">
                        Notifications
                    </h4>
                </div>

                {notifications.length > 0 && (
                    <span className="rounded-full bg-primary/10 px-2.5 py-1 text-[11px] font-semibold text-primary dark:bg-primary/20">
                        {notifications.length} New
                    </span>
                )}
            </div>

            {/* =====================================================
                NOTIFICATION LIST
            ====================================================== */}
            {notifications.length > 0 ? (
                <>
                    <div className="max-h-[380px] overflow-y-auto">

                        {notifications.map((notification) => (
                            <div
                                key={notification.id}
                                className="group border-b border-slate-100 px-4 py-3 transition hover:bg-slate-50 dark:border-white/10 dark:hover:bg-white/[0.04]"
                                onClick={(e) => e.stopPropagation()}
                            >
                                <div className="flex items-start gap-3">

                                    {/* =================================================
                                        PROFILE
                                    ================================================== */}
                                    <div className="relative shrink-0">
                                        <img
                                            src={`/assets/images/${notification.profile}`}
                                            alt="Profile"
                                            className="h-11 w-11 rounded-full object-cover"
                                        />

                                        <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-white bg-success dark:border-[#1b2e4b]" />
                                    </div>

                                    {/* =================================================
                                        CONTENT
                                    ================================================== */}
                                    <div className="min-w-0 flex-1">

                                        <div className="flex items-start gap-2">

                                            {/* Message */}
                                            <div className="min-w-0 flex-1">
                                                <h6
                                                    className="break-words text-sm font-medium leading-5 text-slate-700 dark:text-white-light"
                                                    dangerouslySetInnerHTML={{
                                                        __html: notification.message,
                                                    }}
                                                />

                                                <span className="mt-1 block text-[11px] font-normal text-slate-400 dark:text-gray-500">
                                                    {notification.time}
                                                </span>
                                            </div>

                                            {/* =================================================
                                                REMOVE BUTTON
                                            ================================================== */}
                                            <button
                                                type="button"
                                                aria-label="Remove notification"
                                                title="Remove notification"
                                                className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-neutral-300 opacity-0 transition hover:bg-danger/10 hover:text-danger group-hover:opacity-100"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    removeNotification(
                                                        notification.id
                                                    );
                                                }}
                                            >
                                                <IconXCircle  />
                                            </button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* =====================================================
                        READ ALL
                    ====================================================== */}
                    <div
                        className="border-t border-slate-200 bg-slate-50 p-3 dark:border-white/10 dark:bg-white/[0.02]"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <button
                            type="button"
                            className="btn btn-primary btn-small block w-full rounded-lg"
                        >
                            Read All Notifications
                        </button>
                    </div>
                </>
            ) : (
                /* =========================================================
                    EMPTY STATE
                ========================================================== */
                <div
                    className="flex min-h-[240px] flex-col items-center justify-center px-6 py-8 text-center"
                    onClick={(e) => e.stopPropagation()}
                >
                    <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary ring-4 ring-primary/10">
                        <IconInfoCircle
                            fill={true}
                            className="h-9 w-9"
                        />
                    </div>

                    <h5 className="text-sm font-semibold text-slate-700 dark:text-white-light">
                        No notifications
                    </h5>

                    <p className="mt-1 max-w-[220px] text-xs leading-5 text-slate-400">
                        You don't have any new notifications right now.
                    </p>
                </div>
            )}
        </div>
    </Dropdown>
</div>


                            {/* Divider */}
                            <div className="h-12 w-px bg-gray-100"></div>

                            {/* User Information */}
                            <div className="shrink-0 flex items-center gap-2">
                                <div className="ltr:pl-2 rtl:pr-2 truncate flex max-w-[220px] flex-col items-end">
                                    <h4 className="max-w-full truncate text-base font-medium" title={displayName}>
                                        {displayName}
                                    </h4>

                                    <span
                                        className="max-w-full truncate text-xs text-black/60 dark:text-dark-light/60"
                                        title={email}
                                    >
                                        {email}
                                    </span>

                                    <span className="max-w-full truncate text-[10px] font-semibold uppercase tracking-wide text-primary" title={roleLabel}>
                                        {roleLabel}
                                    </span>
                                </div>

                                {profileImageUrl ? (
                                    <img
                                        className="h-9 w-9 rounded-full object-cover ring-1 ring-slate-200 dark:ring-white/10"
                                        src={profileImageUrl}
                                        alt={`${displayName} profile`}
                                        onError={(event) => {
                                            event.currentTarget.style.display = 'none';
                                        }}
                                    />
                                ) : (
                                    <div
                                        className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary ring-1 ring-primary/10"
                                        aria-label={`${displayName} profile`}
                                    >
                                        {profileInitials || 'U'}
                                    </div>
                                )}

                                <button
                                    type="button"
                                    className="shrink-0 text-primary hover:text-secondary"
                                    title="Logout"
                                    onClick={handleLogout}
                                >
                                    <IconLogout className="h-4.5 w-4.5 rotate-90 ltr:mr-2 rtl:ml-2" />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
