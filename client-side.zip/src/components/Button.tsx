import { ButtonHTMLAttributes, ReactNode } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    children: ReactNode;
    variant?: "primary" | "secondary" | "danger" | "outline";
    loading?: boolean;
}

export default function Button({
    children,
    variant = "primary",
    loading = false,
    disabled,
    className = "",
    ...buttonProps
}: ButtonProps) {
    const variants = {
        primary:
            "bg-red-600 text-white shadow-sm shadow-red-600/20 hover:bg-red-700",

        secondary:
            "bg-slate-600 text-white shadow-sm shadow-slate-600/20 hover:bg-slate-700",

        danger:
            "bg-red-600 text-white shadow-sm shadow-red-600/20 hover:bg-red-700",

        outline:
            "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50",
    };

    return (
        <button
            type="button"
            disabled={disabled || loading}
            className={`
                inline-flex items-center justify-center gap-2
                rounded-lg px-5 py-2.5
                text-sm font-semibold
                transition-colors
                disabled:cursor-not-allowed
                disabled:opacity-60
                ${variants[variant]}
                ${className}
            `}
            {...buttonProps}
        >
            {children}
        </button>
    );
}