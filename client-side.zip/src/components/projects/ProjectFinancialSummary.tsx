import { useState } from "react";
import {
    CurrencyDollarIcon,
    ReceiptIcon,
    TrendUpIcon,
    TrendDownIcon,
    ChartPieSliceIcon,
    PackageIcon,
    UsersIcon,
    WarningCircleIcon,
    CaretDownIcon,
    CaretRightIcon,
} from "@phosphor-icons/react";
import React from "react";

const DEFAULT_HOURLY_RATE = 150;

export interface AssignedStaff {
    name: string;
    rate: number;
    hours: number;
    amount: number;
}
export interface FinancialTask {
    id: string;
    name: string;
    assignStaff?: string;
    estimatedHours: number;
    actualHours?: number;
    hourlyRate?: number;
    materialCost?: number;
    otherExpenses?: number;

    Assignstaff: AssignedStaff[];
}

export interface FinancialPhase {
    id: string;
    name: string;
    tasks: FinancialTask[];
}

interface ProjectFinancialSummaryProps {
    project: {
        projectName?: string;
        name?: string;
        projectValue: number;
        budget: number;
    };
    phases: FinancialPhase[];
}

function formatCurrency(value: number) {
    const sign = value < 0 ? "-" : "";
    return `${sign}$${Math.abs(value).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
}

export default function ProjectFinancialSummary({ project, phases }: ProjectFinancialSummaryProps) {
    const [expandedPhases, setExpandedPhases] = useState<Record<string, boolean>>({});
   const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);


    const togglePhase = (id: string) =>
        setExpandedPhases((prev) => ({ ...prev, [id]: !prev[id] }));

    const taskCosts = phases.flatMap((phase) =>
        phase.tasks.map((task) => {
            const rate = task.hourlyRate ?? DEFAULT_HOURLY_RATE;
            const estimatedHours = task.estimatedHours ?? 0;
            const actualHours = task.actualHours ?? 0;
            const materialCost = task.materialCost ?? 0;
            const otherExpenses = task.otherExpenses ?? 0;

            const estimatedLaborCost = estimatedHours * rate;
            const actualLaborCost = actualHours * rate;
            const actualCost = actualLaborCost + materialCost + otherExpenses;

            return {
                ...task,
                phaseId: phase.id,
                phaseName: phase.name,
                rate,
                estimatedHours,
                actualHours,
                materialCost,
                otherExpenses,
                estimatedLaborCost,
                actualLaborCost,
                actualCost,
                variance: actualCost - estimatedLaborCost,
            };
        })
    );

    // ---- Phase rollups ----
    const phaseCosts = phases.map((phase) => {
        const tasks = taskCosts.filter((t) => t.phaseId === phase.id);
        return {
            id: phase.id,
            name: phase.name,
            tasks,
            taskCount: tasks.length,
            estimatedHours: tasks.reduce((s, t) => s + t.estimatedHours, 0),
            actualHours: tasks.reduce((s, t) => s + t.actualHours, 0),
            materialCost: tasks.reduce((s, t) => s + t.materialCost, 0),
            otherExpenses: tasks.reduce((s, t) => s + t.otherExpenses, 0),
            estimatedCost: tasks.reduce((s, t) => s + t.estimatedLaborCost, 0),
            actualCost: tasks.reduce((s, t) => s + t.actualCost, 0),
        };
    });

    // ---- Project rollups ----
    const totalEstimatedHours = taskCosts.reduce((s, t) => s + t.estimatedHours, 0);
    const totalActualHours = taskCosts.reduce((s, t) => s + t.actualHours, 0);
    const totalLaborCost = taskCosts.reduce((s, t) => s + t.actualLaborCost, 0);
    const totalMaterialCost = taskCosts.reduce((s, t) => s + t.materialCost, 0);
    const totalOtherExpenses = taskCosts.reduce((s, t) => s + t.otherExpenses, 0);
    const totalEstimatedCost = taskCosts.reduce((s, t) => s + t.estimatedLaborCost, 0);
    const totalActualCost = taskCosts.reduce((s, t) => s + t.actualCost, 0);

    const projectValue = project.projectValue ?? 0;
    // A project only exists once its vendor quotation has been approved by the
    // super admin, so quotationValue is always present here.
    const quotationValue = project.budget ?? 0;

    const quotationUtilization = quotationValue > 0 ? Math.round((totalActualCost / quotationValue) * 100) : 0;
    const isOverQuotation = quotationUtilization > 100;
    const isNearQuotation = quotationUtilization >= 85 && !isOverQuotation;

    const margin = projectValue - totalActualCost;
    const marginPct = projectValue > 0 ? Math.round((margin / projectValue) * 100) : 0;

    // ---- Staff rollups ----
    const staffMap = new Map<string, { hours: number; cost: number; tasks: number }>();
    taskCosts.forEach((t) => {
        const key = t.assignStaff?.trim() || "Unassigned";
        const existing = staffMap.get(key) ?? { hours: 0, cost: 0, tasks: 0 };
        staffMap.set(key, {
            hours: existing.hours + t.actualHours,
            cost: existing.cost + t.actualCost,
            tasks: existing.tasks + 1,
        });
    });
    const staffCosts = Array.from(staffMap.entries())
        .map(([name, data]) => ({ name, ...data }))
        .sort((a, b) => b.cost - a.cost);

    const laborPct = totalActualCost > 0 ? (totalLaborCost / totalActualCost) * 100 : 0;
    const materialPct = totalActualCost > 0 ? (totalMaterialCost / totalActualCost) * 100 : 0;
    const otherPct = totalActualCost > 0 ? (totalOtherExpenses / totalActualCost) * 100 : 0;

    const hasData = taskCosts.length > 0;

    if (!hasData) {
        return (
            <div className="rounded-xl border border-dashed border-slate-200 bg-white px-6 py-16 text-center">
                <ChartPieSliceIcon size={28} className="mx-auto text-slate-300" />
                <p className="mt-3 text-sm font-semibold text-slate-600">No costing data yet</p>
                <p className="mt-1 text-xs text-slate-400">
                    Add tasks with hours and an hourly rate to see the project's financial summary here.
                </p>
            </div>
        );
    }

    return (
        <div className="lg:col-span-2 space-y-5">
            {/* ---- Top-line KPIs ---- */}
           <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <div className="h-full">
                    <FinanceKPI
                        label="Project Value"
                        value={formatCurrency(projectValue)}
                        icon={CurrencyDollarIcon}
                        tone="slate"
                    />
                </div>

                <div className="h-full">
                    <FinanceKPI
                        label="Quotation Value"
                        value={formatCurrency(quotationValue)}
                        sub="Approved by super admin"
                        icon={ReceiptIcon}
                        tone="slate"
                    />
                </div>

                <div className="h-full">
                    <FinanceKPI
                        label="Actual Cost"
                        value={formatCurrency(totalActualCost)}
                        sub={`of ${formatCurrency(quotationValue)} quotation`}
                        icon={isOverQuotation ? WarningCircleIcon : PackageIcon}
                        tone={isOverQuotation ? "red" : "emerald"}
                    />
                </div>
            </div>


            <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
                {/* ---- Left: quotation utilization + cost composition + phase breakdown ---- */}
                <div className="space-y-5 lg:col-span-2">
                    <div className="rounded-xl border border-slate-200 bg-white p-5">
                        <div className="flex items-center justify-between">
                            <p className="text-sm font-bold text-slate-900">Quotation utilization</p>
                            <span className="text-xs font-bold text-slate-500 tabular-nums">
                                {formatCurrency(totalActualCost)} / {formatCurrency(quotationValue)}
                            </span>
                        </div>
                        <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-slate-100">
                            <div
                                className={`h-full rounded-full transition-all ${isOverQuotation ? "bg-red-600" : isNearQuotation ? "bg-amber-500" : "bg-emerald-500"
                                    }`}
                                style={{ width: `${Math.min(quotationUtilization, 100)}%` }}
                            />
                        </div>
                        {isOverQuotation && (
                            <p className="mt-2 text-xs font-semibold text-red-600">
                                {quotationUtilization - 100}% over the approved quotation
                            </p>
                        )}

                        <div className="mt-5 border-t border-slate-100 pt-4">
                            <p className="text-xs font-semibold text-slate-500">Cost composition</p>
                            <div className="mt-2 flex h-2.5 overflow-hidden rounded-full bg-slate-100">
                                <div className="h-full bg-red-500" style={{ width: `${laborPct}%` }} />
                                <div className="h-full bg-amber-500" style={{ width: `${materialPct}%` }} />
                                <div className="h-full bg-slate-400" style={{ width: `${otherPct}%` }} />
                            </div>
                            <div className="mt-3 grid grid-cols-3 gap-3 text-xs">
                                <Legend color="bg-red-500" label="Labor" value={formatCurrency(totalLaborCost)} />
                                <Legend color="bg-amber-500" label="Materials" value={formatCurrency(totalMaterialCost)} />
                                <Legend color="bg-slate-400" label="Other" value={formatCurrency(totalOtherExpenses)} />
                            </div>
                        </div>
                    </div>

                    {/* ---- Phase-by-phase breakdown ---- */}
                    <div className="rounded-xl border border-slate-200 bg-white">
                        <div className="border-b border-slate-200 px-5 py-4">
                            <h2 className="text-sm font-bold text-slate-900">Cost by phase</h2>
                            <p className="mt-1 text-xs text-slate-400">
                                {totalActualHours.toLocaleString()} of {totalEstimatedHours.toLocaleString()} estimated hours logged
                            </p>
                        </div>

                        <div className="divide-y divide-slate-100">
                            {phaseCosts.map((phase) => {
                                const isExpanded = !!expandedPhases[phase.id];
                                const overEstimate = phase.actualCost > phase.estimatedCost && phase.estimatedCost > 0;

                                return (
                                    <div key={phase.id}>
                                        <button
                                            type="button"
                                            onClick={() => togglePhase(phase.id)}
                                            className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left transition hover:bg-slate-50"
                                        >
                                            <div className="flex items-center gap-2.5 min-w-0">
                                                {isExpanded ? (
                                                    <CaretDownIcon size={14} weight="bold" className="shrink-0 text-slate-400" />
                                                ) : (
                                                    <CaretRightIcon size={14} weight="bold" className="shrink-0 text-slate-400" />
                                                )}
                                                <div className="min-w-0">
                                                    <p className="text-sm font-semibold text-slate-800 truncate">{phase.name}</p>
                                                    <p className="text-xs text-slate-400">
                                                        {phase.taskCount} {phase.taskCount === 1 ? "task" : "tasks"} · {phase.actualHours}h logged
                                                    </p>
                                                </div>
                                            </div>

                                            <div className="text-right shrink-0">
                                                <p className="text-sm font-bold text-slate-900 tabular-nums">{formatCurrency(phase.actualCost)}</p>
                                                <p className={`text-xs font-medium ${overEstimate ? "text-red-600" : "text-slate-400"}`}>
                                                    est. {formatCurrency(phase.estimatedCost)}
                                                </p>
                                            </div>
                                        </button>

                                       {isExpanded && (
                                            <div className="bg-slate-50/60 px-5 pb-4">
                                                <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
                                                    <table className="w-full text-left text-xs">
                                                        <thead>
                                                            <tr className="border-b border-slate-200 bg-slate-50 text-slate-400">
                                                                <th className="px-3 py-2.5 font-semibold">
                                                                    Task Name
                                                                </th>
                                                                <th className="px-3 py-2.5 font-semibold text-right">
                                                                    Total Staff
                                                                </th>
                                                                <th className="px-3 py-2.5 font-semibold text-right">
                                                                    Hours
                                                                </th>
                                                                <th className="px-3 py-2.5 font-semibold text-right">
                                                                    Amount
                                                                </th>
                                                            </tr>
                                                        </thead>
<tbody className="divide-y divide-slate-100">
    {phase.tasks.map((task) => {
        const isTaskExpanded =
            expandedTaskId === task.id;

        // ============================================
        // STAFF DATA
        // ============================================
        const staffList = task.Assignstaff ?? [];

        // Total number of staff
        const totalStaff = staffList.length;

        // Total estimated hours
        const estimatedHours = staffList.reduce(
            (total: any, staff: { hours: any; }) => total + staff.hours,
            0
        );

        // Total labor amount
        const laborAmount = staffList.reduce(
            (total: any, staff: { amount: any; }) => total + staff.amount,
            0
        );

        // Material
        const materialAmount =
            task.materialCost ?? 0;

        // Other expenses
        const otherAmount =
            task.otherExpenses ?? 0;

        // Complete task total
        const totalAmount =
            laborAmount +
            materialAmount +
            otherAmount;

        return (
            <React.Fragment key={task.id}>

                {/* =================================================
                    TASK SUMMARY ROW
                ================================================== */}
                <tr
                    onClick={() =>
                        setExpandedTaskId(
                            isTaskExpanded
                                ? null
                                : task.id
                        )
                    }
                    className={`cursor-pointer transition ${
                        isTaskExpanded
                            ? 'bg-slate-50'
                            : 'hover:bg-slate-50'
                    }`}
                >
                    {/* Task Name */}
                    <td className="px-3 py-3">
                        <div className="flex items-center gap-2">
                            <span
                                className={`flex h-5 w-5 shrink-0 items-center justify-center rounded text-[10px] font-bold transition ${
                                    isTaskExpanded
                                        ? 'bg-primary text-white'
                                        : 'bg-slate-100 text-slate-500'
                                }`}
                            >
                                {isTaskExpanded
                                    ? '−'
                                    : '+'}
                            </span>

                            <span className="font-semibold text-slate-700">
                                {task.name}
                            </span>
                        </div>
                    </td>

                    {/* Total Staff */}
                    <td className="px-3 py-3 text-right text-slate-600 tabular-nums">
                        {totalStaff}
                    </td>

                    {/* Hours */}
                    <td className="px-3 py-3 text-right text-slate-600 tabular-nums">
                        {task.estimatedHours ?? estimatedHours}
                        {' / '}
                        {task.actualHours ?? 0}
                    </td>

                    {/* Amount */}
                    <td className="px-3 py-3 text-right font-bold text-slate-900 tabular-nums">
                        {formatCurrency(totalAmount)}
                    </td>
                </tr>

                {/* =================================================
                    TASK DETAILS - TREE LEVEL
                ================================================== */}
                {isTaskExpanded && (
                    <tr>
                        <td
                            colSpan={4}
                            className="bg-slate-50 px-3 pb-3 pt-0"
                        >
                            <div className="ml-7 overflow-hidden rounded-lg border border-slate-200 bg-white">

                                <table className="w-full text-left text-xs">

                                    {/* =========================
                                        DETAIL HEADER
                                    ========================== */}
                                    <thead>
                                        <tr className="border-b border-slate-200 bg-slate-50 text-slate-400">

                                            <th className="px-3 py-2 font-semibold">
                                                Staff Name
                                            </th>

                                            <th className="px-3 py-2 text-right font-semibold">
                                                Rate
                                            </th>

                                            <th className="px-3 py-2 text-right font-semibold">
                                                Hours
                                            </th>

                                            <th className="px-3 py-2 text-right font-semibold">
                                                Amount
                                            </th>

                                            <th className="px-3 py-2 text-right font-semibold">
                                                Material
                                            </th>

                                            <th className="px-3 py-2 text-right font-semibold">
                                                Other
                                            </th>

                                            <th className="px-3 py-2 text-right font-semibold">
                                                Total
                                            </th>
                                        </tr>
                                    </thead>

                                    {/* =========================
                                        DETAIL BODY
                                    ========================== */}
                                    <tbody className="divide-y divide-slate-100">

                                        {staffList.map(
                                            (staff: { amount: number; name: string | number | boolean | React.ReactElement<any, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | React.ReactPortal | Iterable<React.ReactNode> | null | undefined; rate: number; hours: string | number | boolean | React.ReactElement<any, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | React.ReactPortal | Iterable<React.ReactNode> | null | undefined; }, index: number) => {

                                                const staffTotal =
                                                    staff.amount +
                                                    (index === 0
                                                        ? materialAmount
                                                        : 0) +
                                                    (index === 0
                                                        ? otherAmount
                                                        : 0);

                                                return (
                                                    <tr
                                                        key={`${task.id}-staff-${index}`}
                                                        className="border-b border-slate-100"
                                                    >
                                                        {/* Staff */}
                                                        <td className="px-3 py-2.5 font-medium text-slate-600">
                                                            {staff.name}
                                                        </td>

                                                        {/* Rate */}
                                                        <td className="px-3 py-2.5 text-right text-slate-500 tabular-nums">
                                                            $
                                                            {staff.rate.toFixed(
                                                                2
                                                            )}
                                                            /hr
                                                        </td>

                                                        {/* Hours */}
                                                        <td className="px-3 py-2.5 text-right text-slate-500 tabular-nums">
                                                            {staff.hours}
                                                        </td>

                                                        {/* Amount */}
                                                        <td className="px-3 py-2.5 text-right text-slate-700 tabular-nums">
                                                            {formatCurrency(
                                                                staff.amount
                                                            )}
                                                        </td>

                                                        {/* Material */}
                                                        <td className="px-3 py-2.5 text-right text-slate-700 tabular-nums">
                                                            {index ===
                                                            0
                                                                ? formatCurrency(
                                                                      materialAmount
                                                                  )
                                                                : formatCurrency(
                                                                      0
                                                                  )}
                                                        </td>

                                                        {/* Other */}
                                                        <td className="px-3 py-2.5 text-right text-slate-700 tabular-nums">
                                                            {index ===
                                                            0
                                                                ? formatCurrency(
                                                                      otherAmount
                                                                  )
                                                                : formatCurrency(
                                                                      0
                                                                  )}
                                                        </td>

                                                        {/* Total */}
                                                        <td className="px-3 py-2.5 text-right font-bold text-slate-900 tabular-nums">
                                                            {formatCurrency(
                                                                staffTotal
                                                            )}
                                                        </td>
                                                    </tr>
                                                );
                                            }
                                        )}

                                        {/* No staff */}
                                        {staffList.length ===
                                            0 && (
                                            <tr>
                                                <td
                                                    colSpan={7}
                                                    className="px-3 py-5 text-center text-slate-400"
                                                >
                                                    No staff assigned
                                                </td>
                                            </tr>
                                        )}

                                        {/* =========================
                                            TASK TOTAL
                                        ========================== */}
                                        {staffList.length >
                                            0 && (
                                            <tr className="bg-slate-50">
                                                <td
                                                    colSpan={3}
                                                    className="px-3 py-2.5 text-right font-bold text-slate-600"
                                                >
                                                    Task Total
                                                </td>

                                                <td className="px-3 py-2.5 text-right font-bold text-slate-900">
                                                    {formatCurrency(
                                                        laborAmount
                                                    )}
                                                </td>

                                                <td className="px-3 py-2.5 text-right font-bold text-slate-900">
                                                    {formatCurrency(
                                                        materialAmount
                                                    )}
                                                </td>

                                                <td className="px-3 py-2.5 text-right font-bold text-slate-900">
                                                    {formatCurrency(
                                                        otherAmount
                                                    )}
                                                </td>

                                                <td className="px-3 py-2.5 text-right font-bold text-primary">
                                                    {formatCurrency(
                                                        totalAmount
                                                    )}
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </td>
                    </tr>
                )}
            </React.Fragment>
        );
    })}
</tbody>

                                                    </table>
                                                </div>
                                            </div>
                                        )}

                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>

                {/* ---- Right: staff cost breakdown ---- */}
                <div className="lg:col-span-2 rounded-xl border border-slate-200 bg-white">
                    <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
                        <div>
                            <h2 className="text-sm font-bold text-slate-900">Cost by staff</h2>
                            <p className="mt-1 text-xs text-slate-400">Labor + expenses per person</p>
                        </div>
                        <UsersIcon size={18} className="text-slate-300" />
                    </div>

                    <div className="space-y-3 px-5 py-5">
                        {staffCosts.map((staff) => {
                            const share = totalActualCost > 0 ? Math.round((staff.cost / totalActualCost) * 100) : 0;
                            return (
                                <div key={staff.name} className="rounded-lg border border-slate-100 bg-slate-50 px-4 py-3">
                                    <div className="flex items-center justify-between gap-3">
                                        <p className="truncate text-sm font-semibold text-slate-800">{staff.name}</p>
                                        <p className="shrink-0 text-sm font-bold text-slate-900 tabular-nums">
                                            {formatCurrency(staff.cost)}
                                        </p>
                                    </div>
                                    <div className="mt-1.5 flex items-center justify-between text-xs text-slate-400">
                                        <span>
                                            {staff.hours}h · {staff.tasks} {staff.tasks === 1 ? "task" : "tasks"}
                                        </span>
                                        <span>{share}% of total</span>
                                    </div>
                                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-200">
                                        <div className="h-full rounded-full bg-red-500" style={{ width: `${share}%` }} />
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
}

function FinanceKPI({
    label,
    value,
    sub,
    icon: Icon,
    tone = "slate",
}: {
    label: string;
    value: string;
    sub?: string;
    icon: React.ElementType;
    tone?: "slate" | "red" | "emerald" | "amber";
}) {
    const tones: Record<string, string> = {
        slate: "bg-slate-100 text-slate-600",
        red: "bg-red-50 text-red-600",
        emerald: "bg-emerald-50 text-emerald-600",
        amber: "bg-amber-50 text-amber-600",
    };

    return (
        <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${tones[tone]}`}>
                <Icon size={18} weight="bold" />
            </div>
            <p className="mt-3 text-[10px] font-semibold uppercase tracking-wide text-slate-400">{label}</p>
            <p className="mt-1 text-xl font-bold text-slate-900 tabular-nums">{value}</p>
            {sub && <p className="mt-0.5 text-xs text-slate-400">{sub}</p>}
        </div>
    );
}

function Legend({ color, label, value }: { color: string; label: string; value: string }) {
    return (
        <div className="flex items-center gap-2">
            <span className={`h-2 w-2 shrink-0 rounded-full ${color}`} />
            <div className="min-w-0">
                <p className="text-slate-400">{label}</p>
                <p className="font-semibold text-slate-700 tabular-nums">{value}</p>
            </div>
        </div>
    );
}