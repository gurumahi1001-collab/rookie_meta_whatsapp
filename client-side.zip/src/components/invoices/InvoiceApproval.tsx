import {
    CheckCircleIcon,
    ClockIcon,
    DownloadSimpleIcon,
    FileTextIcon,
    XCircleIcon,
    WarningCircleIcon,
    PaperPlaneTiltIcon,
} from "@phosphor-icons/react";
import React, { useState } from "react";
import IconDownload from "../Icon/IconDownload";
import InvoiceDetailsPanel from "./InvoiceDetailsPanel";

type InvoiceStatus =
    | "Draft"
    | "Submitted"
    | "Approved"
    | "Rejected"
    | "Paid"
    | "Overdue";

interface MilestoneModule {
    name: string;
    rate: string;
}

interface Invoice {
    id: string;
    invoiceNo: string;
    vendor: string;
    project: string;
    amount: string;
    dueDate: string;
    status: InvoiceStatus;
    rejectionRemarks?: string;
    milestoneName?: string;
    installmentAmount?: number;
    taxRate?: number;
    milestoneModules?: MilestoneModule[];
}

const initialInvoices: Invoice[] = [
    {
        id: "1",
        invoiceNo: "INV-2026-041",
        vendor: "Seiretsu JA Ltd",
        project: "Spalding Fiber FTTx Network Deployment",
        amount: "$42,500.00",
        dueDate: "2026-08-15",
        status: "Submitted",
    },
    {
        id: "2",
        invoiceNo: "INV-2026-028",
        vendor: "Seiretsu JA Ltd",
        project: "Spalding Fiber FTTx Network Deployment",
        amount: "$68,000.00",
        dueDate: "2026-07-01",
        status: "Paid",
    },
    {
        id: "3",
        invoiceNo: "INV-2026-012",
        vendor: "City Council - Kingston & St. Andrew Corporation",
        project: "Smart City Infrastructure",
        amount: "J$14,500,000.00",
        dueDate: "2026-08-30",
        status: "Submitted",
    },
    {
        id: "4",
        invoiceNo: "INV-2026-019",
        vendor: "Kingston Infrastructure Solutions",
        project: "Smart City Infrastructure",
        amount: "J$8,750,000.00",
        dueDate: "2026-09-15",
        status: "Draft",
    },
    {
        id: "5",
        invoiceNo: "INV-2026-021",
        vendor: "Jamaica Power & Engineering Ltd",
        project: "Commercial Building Electrical Upgrade",
        amount: "$125,750.00",
        dueDate: "2026-09-05",
        status: "Approved",
    },
    {
        id: "6",
        invoiceNo: "INV-2026-025",
        vendor: "ABC Construction Ltd",
        project: "Downtown Office Renovation",
        amount: "$95,500.00",
        dueDate: "2026-08-01",
        status: "Rejected",
    },
    {
        id: "7",
        invoiceNo: "INV-2026-031",
        vendor: "Metro Network Services",
        project: "Fiber Network Expansion",
        amount: "$58,200.00",
        dueDate: "2026-07-20",
        status: "Overdue",
    },
];

const InvoiceApproval = () => {
    const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices);
    const [search, setSearch] = useState("");
    const [statusFilter, setStatusFilter] = useState<InvoiceStatus | "ALL">("ALL");
    const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);

    const filteredInvoices = invoices.filter((invoice) => {
        const searchValue = search.toLowerCase();
        const matchesSearch =
            invoice.invoiceNo.toLowerCase().includes(searchValue) ||
            invoice.vendor.toLowerCase().includes(searchValue) ||
            invoice.project.toLowerCase().includes(searchValue);
        const matchesStatus = statusFilter === "ALL" || invoice.status === statusFilter;
        return matchesSearch && matchesStatus;
    });

    const selectedInvoice = invoices.find((inv) => inv.id === selectedInvoiceId) ?? null;

    const formatWithSamePrefix = (originalAmount: string, newValue: number) => {
        const prefixMatch = originalAmount.match(/^[^\d]*/);
        const prefix = prefixMatch ? prefixMatch[0] : "";
        return `${prefix}${newValue.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        })}`;
    };

    const updateInvoice = (id: string, updates: Partial<Invoice>) => {
        setInvoices((prev) =>
            prev.map((inv) => (inv.id === id ? { ...inv, ...updates } : inv))
        );
    };

    const handleApprove = (id: string, totalAmount: number) => {
        setInvoices((prev) =>
            prev.map((inv) =>
                inv.id === id
                    ? { ...inv, status: "Approved", amount: formatWithSamePrefix(inv.amount, totalAmount) }
                    : inv
            )
        );
    };

    const handleReject = (id: string, remarks: string) =>
        updateInvoice(id, { status: "Rejected", rejectionRemarks: remarks });

    const handleMarkAsPaid = (id: string, details: { amount: string }) => {
        const paidAmount = Number(details.amount);
        setInvoices((prev) =>
            prev.map((inv) =>
                inv.id === id
                    ? {
                        ...inv,
                        status: "Paid",
                        amount: Number.isFinite(paidAmount)
                            ? formatWithSamePrefix(inv.amount, paidAmount)
                            : inv.amount,
                    }
                    : inv
            )
        );
    };

    const statusConfig: Record<
        InvoiceStatus,
        {
            badge: string;
            icon: React.ReactNode;
            iconBg: string;
            iconColor: string;
            dot: string;
        }
    > = {
        Draft: {
            badge: "bg-slate-100 text-slate-700 border-slate-200",
            icon: <FileTextIcon size={14} weight="duotone" />,
            iconBg: "bg-slate-100",
            iconColor: "text-slate-500",
            dot: "bg-slate-400",
        },
        Submitted: {
            badge: "bg-blue-50 text-blue-700 border-blue-100",
            icon: <PaperPlaneTiltIcon size={14} weight="duotone" />,
            iconBg: "bg-blue-50",
            iconColor: "text-blue-600",
            dot: "bg-blue-500",
        },
        Approved: {
            badge: "bg-emerald-50 text-emerald-700 border-emerald-100",
            icon: <CheckCircleIcon size={14} weight="duotone" />,
            iconBg: "bg-emerald-50",
            iconColor: "text-emerald-600",
            dot: "bg-emerald-500",
        },
        Rejected: {
            badge: "bg-red-50 text-red-700 border-red-100",
            icon: <XCircleIcon size={14} weight="duotone" />,
            iconBg: "bg-red-50",
            iconColor: "text-red-600",
            dot: "bg-red-500",
        },
        Paid: {
            badge: "bg-purple-50 text-purple-700 border-purple-100",
            icon: <CheckCircleIcon size={14} weight="duotone" />,
            iconBg: "bg-purple-50",
            iconColor: "text-purple-600",
            dot: "bg-purple-500",
        },
        Overdue: {
            badge: "bg-orange-50 text-orange-700 border-orange-100",
            icon: <WarningCircleIcon size={14} weight="duotone" />,
            iconBg: "bg-orange-50",
            iconColor: "text-orange-600",
            dot: "bg-orange-500",
        },
    };

    return (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
            <div className="lg:col-span-5">
                <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="border-b border-slate-200 bg-white px-4 py-4">
                        <div className="mb-3 flex items-center justify-between">
                            <div>
                                <div className="flex items-center gap-2">
                                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
                                        <FileTextIcon
                                            size={18}
                                            weight="duotone"
                                        />
                                    </div>

                                    <div>
                                        <h3 className="text-sm font-bold text-slate-800">
                                            Invoice List
                                        </h3>

                                        <p className="text-[10px] text-slate-400">
                                            Review and manage invoices
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-slate-600">
                                {filteredInvoices.length} Invoices
                            </span>
                        </div>

                        <div className="relative">
                            <FileTextIcon
                                size={17}
                                weight="duotone"
                                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                            />

                            <input
                                type="text"
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                                placeholder="Search invoice, vendor or project..."
                                className="form-input w-full rounded-lg border-slate-200 py-2.5 pl-10 pr-3 text-xs focus:border-primary focus:ring-primary/20"
                            />
                        </div>
                    </div>

                    <div className="border-b border-slate-200 bg-slate-50/70 px-4 py-3">
                        <div className="flex items-center justify-between gap-3">
                            <span className="text-[11px] font-semibold text-slate-500">
                                Filter by status
                            </span>

                            <select
                                value={statusFilter}
                                onChange={(e) =>
                                    setStatusFilter(
                                        e.target.value as
                                        | InvoiceStatus
                                        | "ALL"
                                    )
                                }
                                className="form-select min-w-[130px] rounded-lg border-slate-200 bg-white py-1.5 text-[11px] font-semibold text-slate-600 focus:border-primary focus:ring-primary/20"
                            >
                                <option value="ALL">All Status</option>
                                <option value="Draft">Draft</option>
                                <option value="Submitted">Submitted</option>
                                <option value="Approved">Approved</option>
                                <option value="Rejected">Rejected</option>
                                <option value="Paid">Paid</option>
                                <option value="Overdue">Overdue</option>
                            </select>
                        </div>
                    </div>

                    <div className="max-h-[650px] overflow-y-auto">
                        {filteredInvoices.length > 0 ? (
                            <div className="space-y-2 p-3">
                                {filteredInvoices.map((invoice) => {
                                    const config =
                                        statusConfig[invoice.status];

                                    const isSelected =
                                        selectedInvoice?.id === invoice.id;

                                    return (
                                        <div
                                            key={invoice.id}
                                            onClick={() =>
                                                setSelectedInvoiceId(invoice.id)
                                            }
                                            className={`group relative cursor-pointer rounded-xl border p-3.5 transition-all duration-200 ${isSelected
                                                ? "border-primary/30 bg-primary/[0.04] shadow-sm"
                                                : "border-slate-100 bg-white hover:border-slate-200 hover:bg-slate-50/70 hover:shadow-sm"
                                                } `}
                                        >
                                            {isSelected && (
                                                <span className="absolute bottom-3 left-0 top-3 w-0.5 rounded-r-full bg-primary" />
                                            )}

                                            <div className="flex items-start gap-3">
                                                <div
                                                    className={`flex h10 w10 shrink-0 items-center justify-center rounded-lg ${config.iconBg} ${config.iconColor} `}
                                                >
                                                    {config.icon}
                                                </div>

                                                <div className="min-w-0 flex-1">
                                                    <div className="flex items-start justify-between gap-2">
                                                        <div className="min-w-0">
                                                            <p className="truncate text-xs font-bold text-slate-800">
                                                                {
                                                                    invoice.invoiceNo
                                                                }
                                                            </p>

                                                            <p className="mt-0.5 truncate text-[10px] font-medium text-slate-500">
                                                                {invoice.vendor}
                                                            </p>
                                                        </div>

                                                        <span
                                                            className={`inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-1 text-[9px] font-bold ${config.badge} `}
                                                        >
                                                            <span
                                                                className={`h-1.5 w-1.5 rounded-full ${config.dot} `}
                                                            />
                                                            {invoice.status}
                                                        </span>
                                                    </div>

                                                    <p
                                                        title={
                                                            invoice.project
                                                        }
                                                        className="mt-2 truncate text-[10px] text-slate-400"
                                                    >
                                                        {invoice.project}
                                                    </p>

                                                    <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2.5">
                                                        <div className="flex items-end gap-2">
                                                            <p className="text-[9px] font-medium uppercase tracking-wide text-slate-400">
                                                                Amount
                                                            </p>

                                                            <p className="mt-0.5 text-xs font-bold text-slate-800">
                                                                {invoice.amount}
                                                            </p>
                                                        </div>

                                                        <div className="flex items-end gap-3 text-right">
                                                            <div className="flex items-center justify-end gap-1 text-[9px] font-medium text-slate-400">
                                                                <ClockIcon
                                                                    size={
                                                                        11
                                                                    }
                                                                    weight="duotone"
                                                                />
                                                                Due Date
                                                            </div>

                                                            <p className="mt-0.5 text-[10px] font-semibold text-slate-600">
                                                                {
                                                                    invoice.dueDate
                                                                }
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        ) : (
                            <div className="p-10 text-center">
                                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-slate-100 text-slate-400">
                                    <FileTextIcon
                                        size={22}
                                        weight="duotone"
                                    />
                                </div>

                                <p className="mt-3 text-sm font-semibold text-slate-600">
                                    No invoices found
                                </p>

                                <p className="mt-1 text-xs text-slate-400">
                                    Try changing the search or status filter.
                                </p>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            <div className="lg:col-span-7">
                {selectedInvoice ? (
                    <InvoiceDetailsPanel
                        invoice={selectedInvoice}
                        statusConfig={statusConfig}
                        onApprove={(totalAmount) => handleApprove(selectedInvoice.id, totalAmount)}
                        onReject={(remarks) => handleReject(selectedInvoice.id, remarks)}
                        onMarkAsPaid={(details) => handleMarkAsPaid(selectedInvoice.id, details)}
                    />
                ) : (
                    <div className="flex min-h-[500px] items-center justify-center rounded-xl border border-dashed border-slate-200 bg-white p-6">
                        <div className="text-center">
                            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-xl bg-slate-50 text-slate-400">
                                <FileTextIcon
                                    size={28}
                                    weight="duotone"
                                />
                            </div>

                            <h3 className="mt-4 text-sm font-bold text-slate-700">
                                No Invoice Selected
                            </h3>

                            <p className="mt-2 max-w-md text-xs leading-5 text-slate-400">
                                Select an invoice from the list to view its
                                details, audit trace, itemized line list, and
                                approval status.
                            </p>
                        </div>
                    </div >
                )}
            </div >
        </div >
    );
};

export default InvoiceApproval;