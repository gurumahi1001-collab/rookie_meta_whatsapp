import { useEffect, useState } from "react";
import {
    FolderOpen,
    FileText,
    Receipt,
    CurrencyDollar,
    ArrowClockwise,
} from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";

import api from "../../api/axios";
import StatCard from "../StatCard";

type DashboardProject = {
    id: string;
    initial: string;
    name: string;
    vendor: string;
    status: string;
    progress: number;
};

type DashboardTask = {
    id: string;
    title: string;
    description: string;
    status: string;
    dueDate?: string | null;
    priority: string;
};

type VendorDashboard = {
    vendor: {
        id: string;
        name: string;
        currency?: string;
    };
    stats: {
        projectCount: number;
        pendingTaskCount: number;
        unpaidInvoiceCount: number;
        totalBilledValue: number;
        totalBilledDisplay: string;
        awardedQuotationCount: number;
    };
    projects: DashboardProject[];
    pendingTasks: DashboardTask[];
    compliance: {
        available: boolean;
        message?: string;
    };
};

const EMPTY_DASHBOARD: VendorDashboard = {
    vendor: {
        id: "",
        name: "Vendor Portal",
        currency: "",
    },
    stats: {
        projectCount: 0,
        pendingTaskCount: 0,
        unpaidInvoiceCount: 0,
        totalBilledValue: 0,
        totalBilledDisplay: "0.00",
        awardedQuotationCount: 0,
    },
    projects: [],
    pendingTasks: [],
    compliance: {
        available: false,
    },
};

export default function VendorSummary() {
    const navigate = useNavigate();
    const [dashboard, setDashboard] = useState<VendorDashboard>(EMPTY_DASHBOARD);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState("");

    const loadDashboard = async (showRefreshState = false) => {
        if (showRefreshState) setRefreshing(true);
        else setLoading(true);

        setError("");

        try {
            const response = await api.get("/vendor-portal/dashboard");
            setDashboard(response.data?.data ?? EMPTY_DASHBOARD);
        } catch (requestError: any) {
            const message =
                requestError?.response?.data?.message ||
                "Unable to load the vendor dashboard.";
            setError(message);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useEffect(() => {
        void loadDashboard();
    }, []);

    const formatTaskDate = (value?: string | null) => {
        if (!value) return "No due date";
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return "No due date";
        return date.toLocaleDateString(undefined, {
            day: "2-digit",
            month: "short",
            year: "numeric",
        });
    };

    return (
        <div className="p-3 sm:p-4 md:p-3">
            <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0">
                    <h1 className="text-2xl font-bold text-slate-900">
                        {dashboard.vendor.name}
                        {dashboard.vendor.name !== "Vendor Portal" ? " Portal" : ""}
                    </h1>
                    <p className="mt-1 max-w-3xl text-[12px] leading-relaxed text-slate-500 sm:text-[13px]">
                        Access submitted quotations, review field tasks, and track construction milestone invoices.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={() => void loadDashboard(true)}
                    disabled={loading || refreshing}
                    className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
                >
                    <ArrowClockwise size={15} weight="bold" />
                    {refreshing ? "Refreshing..." : "Refresh"}
                </button>
            </div>

            {error ? (
                <div className="mb-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                    {error}
                </div>
            ) : null}

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4 lg:grid-cols-4">
                <StatCard
                    label="My Fiber Projects"
                    value={loading ? "—" : dashboard.stats.projectCount}
                    icon={FolderOpen}
                    tone="amber"
                />
                <StatCard
                    label="My Pending Deliverables & Tasks"
                    value={loading ? "—" : dashboard.stats.pendingTaskCount}
                    icon={FileText}
                    tone="red"
                />
                <StatCard
                    label="Unpaid Invoices"
                    value={loading ? "—" : dashboard.stats.unpaidInvoiceCount}
                    icon={Receipt}
                    tone="green"
                />
                <StatCard
                    label="Total Billed Value"
                    value={loading ? "—" : dashboard.stats.totalBilledDisplay}
                    icon={CurrencyDollar}
                    tone="blue"
                />
            </div>

            <div className="mt-6 grid grid-cols-1 gap-5 xl:grid-cols-2">
                <div className="space-y-5">
                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="flex flex-col gap-3 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                            <div>
                                <h2 className="text-base font-bold text-slate-900">My Active Fiber Projects</h2>
                                <p className="mt-0.5 text-xs text-slate-500">Current fiber projects and their status</p>
                            </div>
                        </div>

                        <div className="divide-y divide-slate-100">
                            {dashboard.projects.length === 0 && !loading ? (
                                <div className="px-4 py-8 text-center text-xs text-slate-500">
                                    No active projects are currently assigned to this vendor.
                                </div>
                            ) : null}

                            {dashboard.projects.map((project) => (
                                <div
                                    key={project.id}
                                    onClick={() => navigate(`/projects/project_details/${project.id}`)}
                                    className="group cursor-pointer px-4 py-4 transition-colors duration-200 hover:bg-slate-50"
                                >
                                    <div className="flex items-start gap-3">
                                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-100 text-sm font-bold text-slate-700 transition-colors duration-200 group-hover:bg-red-600 group-hover:text-white">
                                            {project.initial}
                                        </div>
                                        <div className="min-w-0 flex-1">
                                            <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                                                <div className="min-w-0 flex-1">
                                                    <h3 className="text-sm font-bold leading-snug text-slate-900">{project.name}</h3>
                                                    <p className="mt-1 text-xs text-slate-500">{project.vendor}</p>
                                                </div>
                                                <span className="w-fit shrink-0 rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-600">
                                                    {project.status}
                                                </span>
                                            </div>
                                            <div className="mt-4">
                                                <div className="mb-1.5 flex items-center justify-between text-[11px]">
                                                    <span className="font-medium text-slate-500">Progress</span>
                                                    <span className="font-bold text-slate-700">{project.progress}%</span>
                                                </div>
                                                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                                                    <div
                                                        className="h-full rounded-full bg-red-600 transition-all"
                                                        style={{ width: `${project.progress}%` }}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                        <div className="flex flex-col gap-3 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                            <div className="flex items-center gap-2.5">
                                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
                                    <Receipt size={19} weight="bold" />
                                </div>
                                <div>
                                    <h2 className="text-base font-bold text-slate-900">My Pending Deliverables & Tasks</h2>
                                </div>
                            </div>
                        </div>

                        <div className="divide-y divide-slate-100">
                            {dashboard.pendingTasks.length === 0 && !loading ? (
                                <div className="px-4 py-8 text-center text-xs text-slate-500">
                                    No pending vendor tasks were found.
                                </div>
                            ) : null}

                            {dashboard.pendingTasks.map((task) => (
                                <div
                                    key={task.id}
                                    className="group flex items-center gap-3 border border-transparent px-4 py-3.5 transition-all duration-200 hover:bg-red-50"
                                >
                                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500 transition-colors duration-200 group-hover:bg-red-600 group-hover:text-white">
                                        <FileText size={17} weight="bold" />
                                    </div>
                                    <div className="min-w-0 flex-1">
                                        <h3 className="truncate text-sm font-semibold text-slate-800">{task.title}</h3>
                                        <p className="mt-0.5 truncate text-[11px] text-slate-500">{task.description}</p>
                                        <p className="mt-1 text-[10px] text-slate-400">Due: {formatTaskDate(task.dueDate)}</p>
                                    </div>
                                    <span className="shrink-0 rounded-full bg-amber-50 px-2 py-1 text-[10px] font-bold capitalize text-amber-600">
                                        {String(task.status).replaceAll("_", " ")}
                                    </span>
                                </div>
                            ))}
                        </div>

                        <div className="border-t border-slate-100 px-4 py-3">
                            <button
                                type="button"
                                onClick={() => navigate("/tasks")}
                                className="flex items-center gap-1.5 text-xs font-semibold text-red-600 transition hover:text-red-700"
                            >
                                Open Task Checklist
                            </button>
                        </div>
                    </div>
                </div>

                <div className="h-fit rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex flex-col gap-3 border-b border-slate-200 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                            <h2 className="text-base font-bold text-slate-900">Compliance & Quality Auditing</h2>
                            <p className="mt-0.5 text-xs text-slate-500">Vendor compliance requirements and quality standards</p>
                        </div>
                        <span className="flex w-fit items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-bold text-slate-600">
                            Informational
                        </span>
                    </div>

                    <div className="divide-y divide-slate-100">
                        <div className="px-4 py-4">
                            <div className="flex gap-3">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-600">
                                    <span className="text-sm font-black">i</span>
                                </div>
                                <div className="min-w-0 flex-1">
                                    <h3 className="text-sm font-bold text-slate-900">Compliance records</h3>
                                    <p className="mt-1 text-xs leading-relaxed text-slate-600">
                                        {dashboard.compliance.message || "Compliance records are available here when the corresponding backend module is enabled."}
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="px-4 py-4">
                            <div className="flex gap-3">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-50 text-blue-600">
                                    <span className="text-sm font-black">✓</span>
                                </div>
                                <div className="min-w-0 flex-1">
                                    <h3 className="text-sm font-bold text-slate-900">Awarded Quotations</h3>
                                    <p className="mt-1 text-xs leading-relaxed text-slate-600">
                                        {loading ? "Loading quotation status..." : `${dashboard.stats.awardedQuotationCount} awarded quotation(s) are linked to this vendor.`}
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="px-4 py-4">
                            <div className="flex gap-3">
                                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
                                    <span className="text-sm font-black">✓</span>
                                </div>
                                <div className="min-w-0 flex-1">
                                    <h3 className="text-sm font-bold text-slate-900">Portal access</h3>
                                    <p className="mt-1 text-xs leading-relaxed text-slate-600">
                                        This dashboard is scoped to the authenticated vendor account and does not expose other vendors’ data.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
