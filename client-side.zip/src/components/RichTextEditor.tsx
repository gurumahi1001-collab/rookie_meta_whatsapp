import { useEffect, useRef } from "react";
import Quill from "quill";
import "quill/dist/quill.snow.css";

interface RichTextEditorProps {
    value?: string;
    onChange?: (value: string) => void;
}

const RichTextEditor = ({
    value = "",
    onChange,
}: RichTextEditorProps) => {
    const editorRef = useRef<HTMLDivElement | null>(null);
    const toolbarRef = useRef<HTMLDivElement | null>(null);
    const quillRef = useRef<Quill | null>(null);

    const onChangeRef = useRef(onChange);

    // Always keep latest onChange
    useEffect(() => {
        onChangeRef.current = onChange;
    }, [onChange]);

    /*
     * Initialize Quill
     */
    useEffect(() => {
        if (
            !editorRef.current ||
            !toolbarRef.current ||
            quillRef.current
        ) {
            return;
        }

        const quill = new Quill(editorRef.current, {
            theme: "snow",

            modules: {
                toolbar: toolbarRef.current,
            },

            placeholder:
                "Enter your terms and conditions here...",
        });

        quillRef.current = quill;

        /*
         * Set initial value
         */
        if (value) {
            quill.root.innerHTML = value;
        }

        /*
         * Listen for changes
         */
        const handleChange = () => {
            const html = quill.root.innerHTML;

            onChangeRef.current?.(html);
        };

        quill.on("text-change", handleChange);

        /*
         * Cleanup
         */
        return () => {
            quill.off(
                "text-change",
                handleChange
            );

            quillRef.current = null;

            // Remove Quill-generated classes/content
            if (editorRef.current) {
                editorRef.current.innerHTML = "";
                editorRef.current.className = "";
            }

            // Remove any Quill event handlers
            if (toolbarRef.current) {
                toolbarRef.current
                    .querySelectorAll("button, select")
                    .forEach((element) => {
                        element.removeAttribute("data-ql-handler");
                    });
            }
        };
    }, []);

    /*
     * Update Quill when value changes
     */
    useEffect(() => {
        const quill = quillRef.current;

        if (!quill) {
            return;
        }

        const currentValue = quill.root.innerHTML;

        if (value !== currentValue) {
            quill.root.innerHTML = value || "";
        }
    }, [value]);

    return (
        <div className="w-full overflow-hidden rounded-lg border border-slate-200 bg-white">

            {/* ============================= */}
            {/* ONE QUILL TOOLBAR */}
            {/* ============================= */}

            <div
                ref={toolbarRef}
                className="ql-toolbar ql-snow"
            >
                <span className="ql-formats">
                    <select
                        className="ql-header"
                        defaultValue=""
                        title="Heading"
                    >
                        <option value="1">
                            Heading 1
                        </option>

                        <option value="2">
                            Heading 2
                        </option>

                        <option value="3">
                            Heading 3
                        </option>

                        <option value="">
                            Normal
                        </option>
                    </select>
                </span>

                <span className="ql-formats">
                    <button
                        type="button"
                        className="ql-bold"
                        title="Bold"
                    />

                    <button
                        type="button"
                        className="ql-italic"
                        title="Italic"
                    />

                    <button
                        type="button"
                        className="ql-underline"
                        title="Underline"
                    />
                </span>

                <span className="ql-formats">
                    <button
                        type="button"
                        className="ql-link"
                        title="Insert Link"
                    />
                </span>

                <span className="ql-formats">
                    <button
                        type="button"
                        className="ql-list"
                        value="ordered"
                        title="Ordered List"
                    />

                    <button
                        type="button"
                        className="ql-list"
                        value="bullet"
                        title="Bullet List"
                    />
                </span>

                <span className="ql-formats">
                    <button
                        type="button"
                        className="ql-clean"
                        title="Clear Formatting"
                    />
                </span>
            </div>

            {/* ============================= */}
            {/* ONE QUILL EDITOR */}
            {/* ============================= */}

            <div
                ref={editorRef}
                className="min-h-[280px]"
            />

        </div>
    );
};

export default RichTextEditor;
