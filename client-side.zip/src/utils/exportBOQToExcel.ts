import { BOQItemm } from "../types/projectBOQ";

interface BOQExportData {
    projectName: string;
    vendors: string;
    siteSurveyReference: string;
    date: string;
    projectSiteLocation: string;
    boqItems: BOQItemm[];
    subtotal: number;
    contingency: number;
    grandTotal: number;
    paymentInstallments: Array<{
        name: string;
        amount: number;
        type: string;
        dueDate: string;
    }>;
    totalInstallmentAmount: number;
    remainingBalance: number;
}

export const exportFullBOQData = (data: BOQExportData) => {
    if (!data.boqItems || data.boqItems.length === 0) {
        alert("No BOQ items to export");
        return;
    }

    // Create CSV rows
    const rows: string[][] = [];

    // Header section - Project Information
    rows.push(["PROJECT INFORMATION"]);
    rows.push([]);
    rows.push(["Project Name", data.projectName || "N/A"]);
    rows.push(["Project Site Location", data.projectSiteLocation || "N/A"]);
    rows.push(["Vendors", data.vendors || "N/A"]);
    rows.push(["Site Survey Reference", data.siteSurveyReference || "N/A"]);
    rows.push(["Date", data.date || "N/A"]);
    rows.push([]);

    // BOQ Items section
    rows.push(["BILL OF QUANTITIES (BOQ)"]);
    rows.push([]);
    rows.push([
        "S.No",
        "Module",
        "Category",
        "Description",
        "Unit",
        "Quantity",
        "Rate (J$)",
        "Total (J$)",
        "Category Type"
    ]);

    // BOQ Items
    data.boqItems.forEach((item, index) => {
        const total = (item.quantity || 0) * (item.rate || 0);
        rows.push([
            String(index + 1),
            item.module || "",
            item.category || "",
            item.description || "",
            item.unit || "",
            String(item.quantity || 0),
            String(item.rate || 0),
            String(total),
            item.categoryType || ""
        ]);
    });

    // Add empty row and summary
    rows.push([]);
    rows.push(["COST SUMMARY"]);
    rows.push([]);
    rows.push(["Sub-Total Items", `J$ ${formatCurrency(data.subtotal)}`]);
    rows.push(["Contingency (10%)", `J$ ${formatCurrency(data.contingency)}`]);
    rows.push(["Grand Total", `J$ ${formatCurrency(data.grandTotal)}`]);
    rows.push([]);

    // Payment Schedule
    if (data.paymentInstallments && data.paymentInstallments.length > 0) {
        rows.push(["PAYMENT SCHEDULE"]);
        rows.push([]);
        rows.push([
            "S.No",
            "Installment Name",
            "Amount (J$)",
            "Type",
            "Due Date"
        ]);

        data.paymentInstallments.forEach((installment, index) => {
            rows.push([
                String(index + 1),
                installment.name || "",
                String(installment.amount || 0),
                installment.type || "",
                installment.dueDate || ""
            ]);
        });

        rows.push([]);
        rows.push(["Total Installment Amount", `J$ ${formatCurrency(data.totalInstallmentAmount)}`]);
        rows.push(["Remaining Balance", `J$ ${formatCurrency(data.remainingBalance)}`]);
    }

    // Generate CSV
    const csvContent = rows
        .map(row => {
            if (row.length === 0) return "";
            return row
                .map(value =>
                    `"${String(value).replace(/"/g, '""')}"`
                )
                .join(",");
        })
        .filter(line => line !== "")
        .join("\n");

    // Create and download the file
    const blob = new Blob(['\uFEFF' + csvContent], {
        type: 'text/csv;charset=utf-8;'
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `BOQ_Full_Export_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
};

const formatCurrency = (value: number) => {
    return Number(value || 0).toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
};
