export const getInputClass = ({
    touched,
    error,
    disabled,
}: {
    touched?: boolean;
    error?: string;
    disabled?: boolean;
}): string => {
    return `
    w-full rounded-md border px-3 py-2 text-sm outline-none transition-colors
    ${disabled ? "bg-slate-100 cursor-not-allowed" : "bg-white"}
    ${touched && error
            ? "border-red-400 bg-red-50 focus:border-red-400 focus:ring-red-200"
            : "border-slate-200 focus:border-primary focus:ring-primary/30"
        }
    `;
};