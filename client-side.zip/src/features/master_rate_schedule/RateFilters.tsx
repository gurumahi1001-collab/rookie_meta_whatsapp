import { useCallback, useEffect, useMemo, useState } from "react";
import Select from "react-select";
import {
    FunnelIcon,
    MagnifyingGlassIcon,
    ArrowClockwiseIcon,
} from "@phosphor-icons/react";

import api from "../../api/axios";
import { getSelectStyles } from "../../utils/selectStyles";

interface RateFiltersProps {
    search: string;
    onSearchChange: (value: string) => void;
    category: string;
    onCategoryChange: (value: string) => void;
    resultCount: number;
}

interface SelectOption {
    value: string;
    label: string;
}

interface ApiResponse<T = unknown> {
    success?: boolean;
    message?: string;
    data?: T;
}

const MASTER_RATE_CATEGORY_ENDPOINT =
    "/master-rates/categories/active";

function getErrorMessage(
    error: unknown,
    fallback: string,
): string {
    const axiosError = error as {
        response?: {
            data?: {
                message?: string;
                error?: string;
            };
        };
        message?: string;
    };

    return (
        axiosError?.response?.data?.message ||
        axiosError?.response?.data?.error ||
        axiosError?.message ||
        fallback
    );
}

function normalizeCategoryName(
    value: unknown,
): string {
    if (typeof value === "string") {
        return value.trim();
    }

    if (!value || typeof value !== "object") {
        return "";
    }

    const item = value as Record<string, unknown>;

    return String(
        item.name ??
            item.category ??
            item.title ??
            "",
    ).trim();
}

function extractCategories(
    response: ApiResponse<unknown>,
): string[] {
    if (!Array.isArray(response.data)) {
        return [];
    }

    const unique = new Set<string>();

    response.data.forEach((item) => {
        const name = normalizeCategoryName(item);

        if (name) {
            unique.add(name);
        }
    });

    return Array.from(unique).sort((a, b) =>
        a.localeCompare(b),
    );
}

export default function RateFilters({
    search,
    onSearchChange,
    category,
    onCategoryChange,
    resultCount,
}: RateFiltersProps) {
    const [categories, setCategories] = useState<string[]>([]);
    const [loadingCategories, setLoadingCategories] =
        useState(true);
    const [categoryError, setCategoryError] =
        useState("");

    const loadCategories = useCallback(async () => {
        setLoadingCategories(true);
        setCategoryError("");

        try {
            const response = await api.get<
                ApiResponse<unknown[]>
            >(MASTER_RATE_CATEGORY_ENDPOINT);

            const nextCategories = extractCategories(
                response.data,
            );

            setCategories(nextCategories);

        } catch (error) {
            const message = getErrorMessage(
                error,
                "Unable to load master rate categories.",
            );

            setCategoryError(message);

            // Do not retain a stale category list from an earlier render.
            setCategories([]);

            if (category !== "all") {
                onCategoryChange("all");
            }
        } finally {
            setLoadingCategories(false);
        }
    }, []);

    useEffect(() => {
        void loadCategories();
    }, [loadCategories]);

    useEffect(() => {
        if (
            category !== "all" &&
            categories.length > 0 &&
            !categories.includes(category)
        ) {
            onCategoryChange("all");
        }
    }, [
        category,
        categories,
        onCategoryChange,
    ]);

    const categoryOptions = useMemo<SelectOption[]>(
        () => [
            { value: "all", label: "All Categories" },
            ...categories.map((name) => ({
                value: name,
                label: name,
            })),
        ],
        [categories],
    );

    const selected =
        categoryOptions.find(
            (option) => option.value === category,
        ) ?? categoryOptions[0];

    return (
        <div className="mb-4 flex items-center gap-3">
            <div className="relative flex-1">
                <MagnifyingGlassIcon
                    size={16}
                    className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                />

                <input
                    value={search}
                    onChange={(event) =>
                        onSearchChange(event.target.value)
                    }
                    placeholder="Search by code or description..."
                    className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-4 text-sm text-slate-700 placeholder:text-slate-400 focus:border-red-500 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                    aria-label="Search master rates"
                />
            </div>

            <div className="flex w-56 shrink-0 items-center gap-2">
                <FunnelIcon
                    size={16}
                    className="shrink-0 text-slate-400"
                />

                <div className="flex-1">
                    <Select
                        options={categoryOptions}
                        value={selected ?? null}
                        isLoading={loadingCategories}
                        isDisabled={loadingCategories}
                        isClearable={false}
                        onChange={(option) =>
                            onCategoryChange( option?.value ?? "all")
                        }
                        placeholder={
                            loadingCategories
                                ? "Loading categories..."
                                : "All Categories"
                        }
                        noOptionsMessage={() =>
                            categoryError
                                ? "Unable to load categories"
                                : "No active categories"
                        }
                        styles={getSelectStyles()}
                    />
                </div>
            </div>

            <span className="shrink-0 text-xs font-semibold uppercase tracking-wide text-slate-400">
                Showing {resultCount} item
                {resultCount === 1 ? "" : "s"}
            </span>

            {categoryError ? (
                <button
                    type="button"
                    onClick={() => void loadCategories()}
                    className="inline-flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-xs font-semibold text-red-600 hover:bg-red-50"
                    title={categoryError}
                >
                    <ArrowClockwiseIcon size={14} />
                    Retry
                </button>
            ) : null}
        </div>
    );
}
