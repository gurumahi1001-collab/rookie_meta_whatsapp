import {
    ArrowClockwiseIcon,
    CaretDownIcon,
    CaretLeftIcon,
    CaretRightIcon,
    ClockCounterClockwiseIcon,
    FunnelIcon,
    MagnifyingGlassIcon,
    SpinnerGapIcon,
    X,
} from "@phosphor-icons/react";
import React, {
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";
import api, {
    getApiErrorMessage,
} from "../../api/axios";

interface UserLogProps {
    open: boolean;
    user: {
        id: string;
        name?: string;
        email?: string;
        role?: string;
        status?: string;
    } | null;
    onClose: () => void;
}

type AuditActor = {
    id?: string | null;
    name?: string;
    email?: string;
    type?: string;
};

type AuditEntity = {
    type?: string;
    id?: string;
    name?: string;
};

type AuditRecord = {
    id: string;
    action?: string;
    module?: string;
    title?: string;
    description?: string;
    actor?: AuditActor;
    entity?: AuditEntity;
    vendorId?: string | null;
    ipAddress?: string;
    userAgent?: string;
    metadata?: Record<string, unknown> | null;
    changes?: Record<string, unknown> | null;
    status?: string;
    occurredAt?: string | null;
    createdAt?: string | null;
};

type AuditListResponse = {
    success?: boolean;
    data?: AuditRecord[];
    pagination?: {
        page?: number;
        limit?: number;
        total?: number;
        totalPages?: number;
        hasNextPage?: boolean;
        hasPreviousPage?: boolean;
    };
};

type AuditDetailResponse = {
    success?: boolean;
    data?: AuditRecord;
};

const PAGE_LIMIT = 20;
const MAX_SEARCH_LENGTH = 120;
const MAX_FILTER_LENGTH = 120;

function safeText(value: unknown, fallback = "-") {
    const text = String(value ?? "").trim();
    return text || fallback;
}

function formatDateTime(value?: string | null) {
    if (!value) return "-";

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "-";

    return new Intl.DateTimeFormat(undefined, {
        year: "numeric",
        month: "short",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
    }).format(date);
}

function formatJsonValue(value: unknown) {
    if (value === null || value === undefined) return "-";

    if (typeof value === "string") return value;
    if (
        typeof value === "number" ||
        typeof value === "boolean"
    ) {
        return String(value);
    }

    try {
        return JSON.stringify(value, null, 2);
    } catch {
        return "Unable to display details.";
    }
}

function initials(name?: string) {
    const value = safeText(name, "U");

    return value
        .split(/\s+/)
        .filter(Boolean)
        .map((part) => part[0])
        .join("")
        .slice(0, 2)
        .toUpperCase();
}

function actionTone(action?: string) {
    const normalized = String(action ?? "").toLowerCase();

    if (
        normalized.includes("login") ||
        normalized.includes("create") ||
        normalized.includes("success")
    ) {
        return "bg-emerald-50 text-emerald-700 ring-emerald-100";
    }

    if (
        normalized.includes("delete") ||
        normalized.includes("disable") ||
        normalized.includes("deactivate") ||
        normalized.includes("reject") ||
        normalized.includes("fail")
    ) {
        return "bg-red-50 text-red-700 ring-red-100";
    }

    if (
        normalized.includes("password") ||
        normalized.includes("reset") ||
        normalized.includes("lock")
    ) {
        return "bg-amber-50 text-amber-700 ring-amber-100";
    }

    return "bg-blue-50 text-blue-700 ring-blue-100";
}

function hasObjectContent(value?: object | null) {
    return Boolean(
        value &&
            typeof value === "object" &&
            Object.keys(value).length > 0,
    );
}

const UserLog: React.FC<UserLogProps> = ({
    open,
    user,
    onClose,
}) => {
    const [logs, setLogs] = useState<AuditRecord[]>([]);
    const [loading, setLoading] = useState(false);
    const [refreshing, setRefreshing] = useState(false);
    const [error, setError] = useState("");
    const [search, setSearch] = useState("");
    const [moduleFilter, setModuleFilter] = useState("");
    const [actionFilter, setActionFilter] = useState("");
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [page, setPage] = useState(1);
    const [total, setTotal] = useState(0);
    const [totalPages, setTotalPages] = useState(0);
    const [selectedLog, setSelectedLog] =
        useState<AuditRecord | null>(null);
    const [detailLoading, setDetailLoading] = useState(false);
    const [detailError, setDetailError] = useState("");
    const requestSequence = useRef(0);
    const abortControllerRef = useRef<AbortController | null>(null);

    const userId = user?.id || "";

    const loadLogs = useCallback(
        async (targetPage = page, isRefresh = false) => {
            if (!userId) return;

            const requestId = ++requestSequence.current;
            abortControllerRef.current?.abort();
            const controller = new AbortController();
            abortControllerRef.current = controller;
            setError("");

            if (isRefresh) {
                setRefreshing(true);
            } else {
                setLoading(true);
            }

            try {
                const response = await api.get<AuditListResponse>(
                    "/audit",
                    {
                        params: {
                            page: targetPage,
                            limit: PAGE_LIMIT,
                            actorUserId: userId,
                            ...(search.trim()
                                ? {
                                      search: search
                                          .trim()
                                          .slice(
                                              0,
                                              MAX_SEARCH_LENGTH,
                                          ),
                                  }
                                : {}),
                            ...(moduleFilter.trim()
                                ? {
                                      module: moduleFilter
                                          .trim()
                                          .slice(
                                              0,
                                              MAX_FILTER_LENGTH,
                                          ),
                                  }
                                : {}),
                            ...(actionFilter.trim()
                                ? {
                                      action: actionFilter
                                          .trim()
                                          .slice(
                                              0,
                                              MAX_FILTER_LENGTH,
                                          ),
                                  }
                                : {}),
                            ...(fromDate
                                ? { fromDate }
                                : {}),
                            ...(toDate
                                ? {
                                      toDate: `${toDate}T23:59:59.999`,
                                  }
                                : {}),
                        },
                    },
                );

                if (requestId !== requestSequence.current) {
                    return;
                }

                if (response.data?.success === false) {
                    throw new Error(
                        "Unable to load activity logs.",
                    );
                }

                const items = Array.isArray(response.data?.data)
                    ? response.data.data
                    : [];

                const pagination = response.data?.pagination;
                const resolvedPage = Number(pagination?.page) || targetPage;
                const resolvedTotal = Number(pagination?.total) || 0;
                const resolvedPages = Number(pagination?.totalPages) || 0;

                setLogs(items);
                setPage(resolvedPage);
                setTotal(resolvedTotal);
                setTotalPages(resolvedPages);
            } catch (err) {
                if (controller.signal.aborted || (err as { name?: string })?.name === "CanceledError" || (err as { name?: string })?.name === "AbortError") {
                    return;
                }

                if (requestId !== requestSequence.current) {
                    return;
                }

                setLogs([]);
                setTotal(0);
                setTotalPages(0);
                setError(
                    getApiErrorMessage(
                        err,
                        "Unable to load activity logs.",
                    ),
                );
            } finally {
                if (requestId === requestSequence.current) {
                    setLoading(false);
                    setRefreshing(false);
                }
            }
        },
        [
            actionFilter,
            fromDate,
            moduleFilter,
            page,
            search,
            toDate,
            userId,
        ],
    );

    useEffect(() => {
        if (!open || !userId) {
            requestSequence.current += 1;
            abortControllerRef.current?.abort();
            abortControllerRef.current = null;
            setLogs([]);
            setLoading(false);
            setRefreshing(false);
            setError("");
            setPage(1);
            setTotal(0);
            setTotalPages(0);
            setSelectedLog(null);
            setDetailError("");
            return;
        }

        setSearch("");
        setModuleFilter("");
        setActionFilter("");
        setFromDate("");
        setToDate("");
        setPage(1);
        setSelectedLog(null);
        setDetailError("");
    }, [open, userId]);

    useEffect(() => {
        if (!open || !userId) return;

        const timer = window.setTimeout(() => {
            void loadLogs(1);
        }, 250);

        return () => window.clearTimeout(timer);
    }, [
        actionFilter,
        fromDate,
        loadLogs,
        moduleFilter,
        open,
        search,
        toDate,
        userId,
    ]);

    const visibleLogs = useMemo(
        () =>
            [...logs].sort(
                (a, b) => {
                    const aTime = a.occurredAt
                        ? new Date(a.occurredAt).getTime()
                        : 0;
                    const bTime = b.occurredAt
                        ? new Date(b.occurredAt).getTime()
                        : 0;
                    return bTime - aTime;
                },
            ),
        [logs],
    );

    const canPrevious = page > 1;
    const canNext = page < totalPages;

    const resetFilters = () => {
        setSearch("");
        setModuleFilter("");
        setActionFilter("");
        setFromDate("");
        setToDate("");
        setPage(1);
    };

    const openDetail = async (log: AuditRecord) => {
        if (!log.id) return;

        setSelectedLog(log);
        setDetailError("");
        setDetailLoading(true);

        try {
            const response = await api.get<AuditDetailResponse>(
                `/audit/${encodeURIComponent(log.id)}`,
            );

            if (response.data?.success === false) {
                throw new Error(
                    "Unable to load activity details.",
                );
            }

            if (response.data?.data) {
                setSelectedLog(response.data.data);
            }
        } catch (err) {
            setDetailError(
                getApiErrorMessage(
                    err,
                    "Unable to load activity details.",
                ),
            );
        } finally {
            setDetailLoading(false);
        }
    };

    if (!open || !user) return null;

    return (
        <div className="fixed inset-0 z-[999]">
            <div
                className="absolute inset-0 bg-black/40"
                onClick={onClose}
            />

            <div className="absolute right-0 top-0 h-full w-full max-w-xl bg-white shadow-xl">
                <div className="flex h-full flex-col">
                    {/* Header */}
                    <div className="border-b border-slate-200 px-5 py-4">
                        <div className="flex items-start justify-between gap-4">
                            <div className="min-w-0">
                                <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">
                                    <ClockCounterClockwiseIcon size={13} />
                                    User activity
                                </div>

                                <h2 className="mt-1 truncate text-base font-semibold text-slate-800">
                                    Activity Logs
                                </h2>

                                <p className="mt-0.5 truncate text-xs text-slate-500">
                                    {safeText(user.name)} · {safeText(user.email)}
                                </p>
                            </div>

                            <div className="flex shrink-0 items-center gap-1">
                                <button
                                    type="button"
                                    onClick={() =>
                                        void loadLogs(page, true)
                                    }
                                    disabled={loading || refreshing}
                                    className="rounded-md p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 disabled:cursor-not-allowed disabled:opacity-50"
                                    aria-label="Refresh activity logs"
                                >
                                    <ArrowClockwiseIcon
                                        size={17}
                                        className={
                                            refreshing
                                                ? "animate-spin"
                                                : ""
                                        }
                                    />
                                </button>

                                <button
                                    type="button"
                                    onClick={onClose}
                                    className="rounded-md p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                                    aria-label="Close activity logs"
                                >
                                    <X size={18} />
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* User summary */}
                    <div className="border-b border-slate-200 bg-slate-50/60 px-5 py-4">
                        <div className="flex items-center gap-3">
                            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-slate-100 text-sm font-semibold text-slate-600">
                                {initials(user.name)}
                            </div>

                            <div className="min-w-0">
                                <p className="truncate text-sm font-semibold text-slate-800">
                                    {safeText(user.name)}
                                </p>
                                <p className="truncate text-xs text-slate-500">
                                    {safeText(user.role, "Role not assigned")}
                                </p>
                            </div>

                            <span
                                className={`ml-auto shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold ${
                                    String(user.status ?? "")
                                        .toLowerCase() === "active"
                                        ? "bg-green-50 text-green-600"
                                        : "bg-red-50 text-red-600"
                                }`}
                            >
                                {safeText(user.status)}
                            </span>
                        </div>
                    </div>

                    {/* Filters */}
                    <div className="border-b border-slate-200 px-5 py-3">
                        <div className="flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
                                <FunnelIcon size={14} />
                                Filters
                            </div>

                            <button
                                type="button"
                                onClick={resetFilters}
                                className="text-[11px] font-semibold text-slate-400 transition hover:text-slate-700"
                            >
                                Clear
                            </button>
                        </div>

                        <div className="mt-3 space-y-2">
                            <div className="relative">
                                <MagnifyingGlassIcon
                                    size={15}
                                    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                                />
                                <input
                                    type="text"
                                    value={search}
                                    maxLength={MAX_SEARCH_LENGTH}
                                    onChange={(event) => {
                                        setSearch(event.target.value);
                                        setPage(1);
                                    }}
                                    placeholder="Search activity, module, action..."
                                    className="h-9 w-full rounded-md border border-slate-200 bg-white pl-9 pr-3 text-xs text-slate-700 outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-100"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                                <input
                                    type="text"
                                    value={moduleFilter}
                                    maxLength={MAX_FILTER_LENGTH}
                                    onChange={(event) => {
                                        setModuleFilter(event.target.value);
                                        setPage(1);
                                    }}
                                    placeholder="Module"
                                    className="h-9 rounded-md border border-slate-200 bg-white px-3 text-xs text-slate-700 outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-100"
                                />

                                <input
                                    type="text"
                                    value={actionFilter}
                                    maxLength={MAX_FILTER_LENGTH}
                                    onChange={(event) => {
                                        setActionFilter(event.target.value);
                                        setPage(1);
                                    }}
                                    placeholder="Action"
                                    className="h-9 rounded-md border border-slate-200 bg-white px-3 text-xs text-slate-700 outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-100"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                                <label className="min-w-0">
                                    <span className="mb-1 block text-[10px] font-semibold text-slate-400">
                                        From
                                    </span>
                                    <input
                                        type="date"
                                        value={fromDate}
                                        onChange={(event) => {
                                            setFromDate(event.target.value);
                                            setPage(1);
                                        }}
                                        className="h-9 w-full rounded-md border border-slate-200 bg-white px-3 text-xs text-slate-700 outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-100"
                                    />
                                </label>

                                <label className="min-w-0">
                                    <span className="mb-1 block text-[10px] font-semibold text-slate-400">
                                        To
                                    </span>
                                    <input
                                        type="date"
                                        min={fromDate || undefined}
                                        value={toDate}
                                        onChange={(event) => {
                                            setToDate(event.target.value);
                                            setPage(1);
                                        }}
                                        className="h-9 w-full rounded-md border border-slate-200 bg-white px-3 text-xs text-slate-700 outline-none transition focus:border-slate-400 focus:ring-2 focus:ring-slate-100"
                                    />
                                </label>
                            </div>
                        </div>
                    </div>

                    {/* Timeline */}
                    <div className="min-h-0 flex-1 overflow-y-auto px-5 py-5">
                        {loading && (
                            <div className="flex min-h-[240px] items-center justify-center text-slate-400">
                                <div className="flex items-center gap-2 text-xs font-semibold">
                                    <SpinnerGapIcon
                                        size={17}
                                        className="animate-spin"
                                    />
                                    Loading activity...
                                </div>
                            </div>
                        )}

                        {!loading && error && (
                            <div className="rounded-lg border border-red-200 bg-red-50 p-4">
                                <p className="text-xs font-semibold text-red-700">
                                    {error}
                                </p>
                                <button
                                    type="button"
                                    onClick={() =>
                                        void loadLogs(page)
                                    }
                                    className="mt-3 inline-flex items-center gap-1.5 rounded-md border border-red-200 bg-white px-3 py-1.5 text-[11px] font-semibold text-red-700 transition hover:bg-red-100"
                                >
                                    <ArrowClockwiseIcon size={13} />
                                    Retry
                                </button>
                            </div>
                        )}

                        {!loading && !error && visibleLogs.length === 0 && (
                            <div className="flex min-h-[240px] flex-col items-center justify-center text-center">
                                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-100 text-slate-400">
                                    <ClockCounterClockwiseIcon size={21} />
                                </div>
                                <p className="mt-3 text-sm font-semibold text-slate-600">
                                    No activity found
                                </p>
                                <p className="mt-1 max-w-xs text-xs leading-5 text-slate-400">
                                    There are no audit events matching the current filters for this user.
                                </p>
                            </div>
                        )}

                        {!loading && !error && visibleLogs.length > 0 && (
                            <div className="relative">
                                <div className="absolute bottom-2 left-[7px] top-2 w-px bg-slate-200" />

                                <div className="space-y-5">
                                    {visibleLogs.map((log) => (
                                        <div
                                            key={log.id}
                                            className="relative flex gap-4"
                                        >
                                            <div
                                                className={`relative z-10 mt-1 h-4 w-4 shrink-0 rounded-full border-2 border-white ring-1 ${
                                                    actionTone(log.action)
                                                        .replace(
                                                            "bg-",
                                                            "ring-",
                                                        )
                                                } bg-slate-500`}
                                            />

                                            <div className="min-w-0 flex-1 rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
                                                <div className="flex items-start justify-between gap-3">
                                                    <div className="min-w-0">
                                                        <p className="text-sm font-semibold text-slate-700">
                                                            {safeText(
                                                                log.title,
                                                                safeText(
                                                                    log.action,
                                                                    "Activity",
                                                                ),
                                                            )}
                                                        </p>

                                                        <div className="mt-1 flex flex-wrap items-center gap-1.5">
                                                            <span
                                                                className={`inline-flex items-center rounded-full px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide ring-1 ${actionTone(
                                                                    log.action,
                                                                )}`}
                                                            >
                                                                {safeText(
                                                                    log.action,
                                                                    "event",
                                                                )}
                                                            </span>

                                                            {log.module && (
                                                                <span className="inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-[9px] font-semibold text-slate-500">
                                                                    {log.module}
                                                                </span>
                                                            )}
                                                        </div>
                                                    </div>

                                                    <span className="shrink-0 text-[10px] text-slate-400">
                                                        {formatDateTime(
                                                            log.occurredAt ||
                                                                log.createdAt,
                                                        )}
                                                    </span>
                                                </div>

                                                <p className="mt-2 text-xs leading-5 text-slate-500">
                                                    {safeText(
                                                        log.description,
                                                        "No additional description was recorded.",
                                                    )}
                                                </p>

                                                <div className="mt-3 flex items-center justify-between gap-2">
                                                    <div className="min-w-0 text-[10px] text-slate-400">
                                                        {log.entity?.name
                                                            ? `${log.entity.type || "Entity"}: ${log.entity.name}`
                                                            : "System activity"}
                                                    </div>

                                                    <button
                                                        type="button"
                                                        onClick={() =>
                                                            void openDetail(
                                                                log,
                                                            )
                                                        }
                                                        className="shrink-0 inline-flex items-center gap-1 text-[10px] font-semibold text-slate-500 transition hover:text-slate-800"
                                                    >
                                                        Details
                                                        <CaretDownIcon size={11} />
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Pagination */}
                    <div className="border-t border-slate-200 bg-white px-5 py-3">
                        <div className="flex items-center justify-between gap-3">
                            <p className="text-[10px] text-slate-400">
                                {total > 0
                                    ? `Showing ${
                                          (page - 1) * PAGE_LIMIT + 1
                                      }–${Math.min(
                                          page * PAGE_LIMIT,
                                          total,
                                      )} of ${total}`
                                    : "0 activity records"}
                            </p>

                            <div className="flex items-center gap-1">
                                <button
                                    type="button"
                                    disabled={!canPrevious || loading}
                                    onClick={() => {
                                        if (canPrevious) {
                                            const nextPage = page - 1;
                                            setPage(nextPage);
                                            void loadLogs(nextPage);
                                        }
                                    }}
                                    className="rounded-md border border-slate-200 p-1.5 text-slate-500 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
                                    aria-label="Previous page"
                                >
                                    <CaretLeftIcon size={14} />
                                </button>

                                <span className="min-w-[72px] text-center text-[10px] font-semibold text-slate-500">
                                    Page {page} / {Math.max(totalPages, 1)}
                                </span>

                                <button
                                    type="button"
                                    disabled={!canNext || loading}
                                    onClick={() => {
                                        if (canNext) {
                                            const nextPage = page + 1;
                                            setPage(nextPage);
                                            void loadLogs(nextPage);
                                        }
                                    }}
                                    className="rounded-md border border-slate-200 p-1.5 text-slate-500 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40"
                                    aria-label="Next page"
                                >
                                    <CaretRightIcon size={14} />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Detail modal */}
            {selectedLog && (
                <div className="absolute inset-0 z-[1001] flex items-center justify-center p-4">
                    <button
                        type="button"
                        aria-label="Close activity detail"
                        onClick={() => {
                            setSelectedLog(null);
                            setDetailError("");
                        }}
                        className="absolute inset-0 bg-black/30"
                    />

                    <div className="relative z-10 max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-xl bg-white shadow-2xl">
                        <div className="flex items-start justify-between gap-4 border-b border-slate-200 px-5 py-4">
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">
                                    Audit event
                                </p>
                                <h3 className="mt-1 text-base font-semibold text-slate-800">
                                    {safeText(
                                        selectedLog.title,
                                        safeText(
                                            selectedLog.action,
                                            "Activity details",
                                        ),
                                    )}
                                </h3>
                            </div>

                            <button
                                type="button"
                                onClick={() => {
                                    setSelectedLog(null);
                                    setDetailError("");
                                }}
                                className="rounded-md p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                                aria-label="Close details"
                            >
                                <X size={17} />
                            </button>
                        </div>

                        <div className="space-y-4 px-5 py-5">
                            {detailLoading && (
                                <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
                                    <SpinnerGapIcon
                                        size={16}
                                        className="animate-spin"
                                    />
                                    Loading latest audit details...
                                </div>
                            )}

                            {detailError && (
                                <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
                                    {detailError}
                                </div>
                            )}

                            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Action
                                    </p>
                                    <p className="mt-1 break-words text-xs font-semibold text-slate-700">
                                        {safeText(selectedLog.action)}
                                    </p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Module
                                    </p>
                                    <p className="mt-1 break-words text-xs font-semibold text-slate-700">
                                        {safeText(selectedLog.module)}
                                    </p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Occurred
                                    </p>
                                    <p className="mt-1 text-xs font-semibold text-slate-700">
                                        {formatDateTime(
                                            selectedLog.occurredAt ||
                                                selectedLog.createdAt,
                                        )}
                                    </p>
                                </div>

                                <div>
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Status
                                    </p>
                                    <p className="mt-1 text-xs font-semibold capitalize text-slate-700">
                                        {safeText(selectedLog.status)}
                                    </p>
                                </div>
                            </div>

                            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                                <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                    Description
                                </p>
                                <p className="mt-1 whitespace-pre-wrap break-words text-xs leading-5 text-slate-600">
                                    {safeText(
                                        selectedLog.description,
                                        "No description recorded.",
                                    )}
                                </p>
                            </div>

                            <div className="grid gap-3 md:grid-cols-2">
                                <div className="rounded-lg border border-slate-200 p-3">
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Actor
                                    </p>
                                    <p className="mt-1 text-xs font-semibold text-slate-700">
                                        {safeText(
                                            selectedLog.actor?.name,
                                            "System",
                                        )}
                                    </p>
                                    <p className="mt-0.5 break-all text-[11px] text-slate-400">
                                        {safeText(
                                            selectedLog.actor?.email,
                                            "No email recorded",
                                        )}
                                    </p>
                                </div>

                                <div className="rounded-lg border border-slate-200 p-3">
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Request context
                                    </p>
                                    <p className="mt-1 text-xs font-semibold text-slate-700">
                                        IP: {safeText(selectedLog.ipAddress)}
                                    </p>
                                    <p className="mt-0.5 break-words text-[11px] text-slate-400">
                                        {safeText(
                                            selectedLog.userAgent,
                                            "No user-agent recorded",
                                        )}
                                    </p>
                                </div>
                            </div>

                            {hasObjectContent(selectedLog.entity) && (
                                <div className="rounded-lg border border-slate-200 p-3">
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Entity
                                    </p>
                                    <div className="mt-2 grid gap-2 text-xs md:grid-cols-3">
                                        <span>
                                            <strong className="font-semibold text-slate-500">
                                                Type:
                                            </strong>{" "}
                                            {safeText(
                                                selectedLog.entity?.type,
                                            )}
                                        </span>
                                        <span className="break-all">
                                            <strong className="font-semibold text-slate-500">
                                                ID:
                                            </strong>{" "}
                                            {safeText(
                                                selectedLog.entity?.id,
                                            )}
                                        </span>
                                        <span className="break-words">
                                            <strong className="font-semibold text-slate-500">
                                                Name:
                                            </strong>{" "}
                                            {safeText(
                                                selectedLog.entity?.name,
                                            )}
                                        </span>
                                    </div>
                                </div>
                            )}

                            {hasObjectContent(selectedLog.changes) && (
                                <div>
                                    <p className="mb-2 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Changes
                                    </p>
                                    <pre className="max-h-64 overflow-auto rounded-lg bg-slate-950 p-3 text-[10px] leading-5 text-slate-200">
                                        {formatJsonValue(
                                            selectedLog.changes,
                                        )}
                                    </pre>
                                </div>
                            )}

                            {hasObjectContent(selectedLog.metadata) && (
                                <div>
                                    <p className="mb-2 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Metadata
                                    </p>
                                    <pre className="max-h-64 overflow-auto rounded-lg bg-slate-950 p-3 text-[10px] leading-5 text-slate-200">
                                        {formatJsonValue(
                                            selectedLog.metadata,
                                        )}
                                    </pre>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default UserLog;
