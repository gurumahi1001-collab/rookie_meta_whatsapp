// offcanvas/project_edit.tsx

import {
    XIcon,
} from "@phosphor-icons/react";
import { useEffect, useState } from "react";

export interface Project {
    id: string;
    projectName: string;
    location: string;
    vendorName: string;
    managerName: string;
    startDate: string;
    endDate: string;
    projectValue: number;
    budget: number;
    status:
        | "Planned"
        | "Completed"
        | "On Hold"
        | "Closed"
        | "In Progress";
    progress: number;
}

interface ProjectEditProps {
    isOpen: boolean;
    project: Project | null;
    onClose: () => void;
    onSave: (project: Project) => void;
}

export default function ProjectEdit({
    isOpen,
    project,
    onClose,
    onSave,
}: ProjectEditProps) {
    // Only editable fields
    const [vendorName, setVendorName] =
        useState("");

    const [managerName, setManagerName] =
        useState("");

    const [endDate, setEndDate] =
        useState("");

    /*
     * Populate editable fields whenever
     * the selected project changes.
     */
    useEffect(() => {
        if (!project) return;

        setVendorName(project.vendorName);
        setManagerName(project.managerName);
        setEndDate(
        formatDateForInput(project.endDate)
    );
    }, [project]);

    if (!isOpen || !project) {
        return null;
    }

    const handleSave = () => {
        const updatedProject: Project = {
            ...project,

            // Only these three values are changed
            vendorName,
            managerName,
            endDate,
        };

        onSave(updatedProject);
    };

    const formatDateForInput = (date: string) => {
    if (!date) return "";

    // Already in YYYY-MM-DD format
    if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return date;
    }

    // Convert "18 Aug 2026" -> "2026-08-18"
    const parsedDate = new Date(date);

    if (isNaN(parsedDate.getTime())) {
        return "";
    }

    const year = parsedDate.getFullYear();
    const month = String(
        parsedDate.getMonth() + 1
    ).padStart(2, "0");
    const day = String(
        parsedDate.getDate()
    ).padStart(2, "0");

    return `${year}-${month}-${day}`;
};

    return (
        <div className="fixed inset-0 z-50">
            {/* Overlay */}
            <div
                className="absolute inset-0 bg-black/30"
                onClick={onClose}
            />

            {/* Offcanvas */}
            <div className="absolute right-0 top-0 flex h-full w-full max-w-lg flex-col bg-white shadow-2xl">

                {/* Header */}
                <div className="flex items-center justify-between border-b border-slate-200 px-6 py-5">
                    <div>
                        <h2 className="text-lg font-bold text-slate-900">
                            Edit Project
                        </h2>

                        <p className="mt-1 text-sm text-slate-500">
                            Update vendor, manager and project end date.
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={onClose}
                        className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                    >
                        <XIcon size={20} />
                    </button>
                </div>

                {/* Body */}
                <div className="flex-1 overflow-y-auto px-6 py-6">
                    <div className="space-y-5">

                        {/* Project Name - Read Only */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                Project Name
                            </label>

                            <input
                                type="text"
                                value={project.projectName}
                                readOnly
                                className="h-10 w-full cursor-not-allowed rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-500 outline-none"
                            />
                        </div>

                        {/* Location - Read Only */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                Location
                            </label>

                            <input
                                type="text"
                                value={project.location}
                                readOnly
                                className="h-10 w-full cursor-not-allowed rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-500 outline-none"
                            />
                        </div>

                        {/* Vendor - Editable */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                Vendor
                            </label>

                            <input
                                type="text"
                                value={vendorName}
                                onChange={(e) =>
                                    setVendorName(
                                        e.target.value
                                    )
                                }
                                className="h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm text-slate-800 outline-none transition focus:border-red-500 focus:ring-2 focus:ring-red-100"
                            />
                        </div>

                        {/* Manager - Editable */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                Manager
                            </label>

                            <input
                                type="text"
                                value={managerName}
                                onChange={(e) =>
                                    setManagerName(
                                        e.target.value
                                    )
                                }
                                className="h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm text-slate-800 outline-none transition focus:border-red-500 focus:ring-2 focus:ring-red-100"
                            />
                        </div>

                        {/* Start Date - Read Only */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                Start Date
                            </label>

                            <input
                                type="date"
                                value={formatDateForInput(project.startDate)}
                                readOnly
                                className="h-10 w-full cursor-not-allowed rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-500 outline-none"
                            />
                        </div>

                        {/* End Date - Editable */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                End Date
                            </label>

                            <input
                                type="date"
                                value={endDate}
                                onChange={(e) =>
                                    setEndDate(
                                        e.target.value
                                    )
                                }
                                className="h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm text-slate-800 outline-none transition focus:border-red-500 focus:ring-2 focus:ring-red-100"
                            />
                        </div>

                        {/* Project Value - Read Only */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                Project Value
                            </label>

                            <input
                                type="text"
                                value={`$${project.projectValue.toLocaleString()}`}
                                readOnly
                                className="h-10 w-full cursor-not-allowed rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-500 outline-none"
                            />
                        </div>

                        {/* Budget - Read Only */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                Budget
                            </label>

                            <input
                                type="text"
                                value={`$${project.budget.toLocaleString()}`}
                                readOnly
                                className="h-10 w-full cursor-not-allowed rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-500 outline-none"
                            />
                        </div>

                        {/* Status - Read Only */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                Status
                            </label>

                            <input
                                type="text"
                                value={project.status}
                                readOnly
                                className="h-10 w-full cursor-not-allowed rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-500 outline-none"
                            />
                        </div>

                        {/* Progress - Read Only */}
                        <div>
                            <label className="mb-1.5 block text-sm font-medium text-slate-700">
                                Progress
                            </label>

                            <div className="flex h-10 items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 px-3">
                                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-200">
                                    <div
                                        className="h-full rounded-full bg-red-600"
                                        style={{
                                            width: `${project.progress}%`,
                                        }}
                                    />
                                </div>

                                <span className="text-sm font-semibold text-slate-600">
                                    {project.progress}%
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-end gap-3 border-t border-slate-200 bg-slate-50 px-6 py-4">
                    <button
                        type="button"
                        onClick={onClose}
                        className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
                    >
                        Cancel
                    </button>

                    <button
                        type="button"
                        onClick={handleSave}
                        className="rounded-lg bg-red-600 px-5 py-2 text-sm font-semibold text-white transition hover:bg-red-700"
                    >
                        Save Changes
                    </button>
                </div>
            </div>
        </div>
    );
}
