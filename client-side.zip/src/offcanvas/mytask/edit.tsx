import {
    ChangeEvent,
    ReactNode,
    useEffect,
    useMemo,
    useRef,
    useState,
} from 'react';

import {
    Check,
    Plus,
    Users,
    XIcon,
    Trash,
    ImageIcon,
} from '@phosphor-icons/react';

import IconMessageDots from '../../components/Icon/IconMessageDots';
import IconSend from '../../components/Icon/IconSend';
import { createPortal } from 'react-dom';
import { AssignedStaff } from '../../components/projects/project_overview';


// ============================================================
// TYPES
// ============================================================

type TaskStatus =
    | 'Pending'
    | 'In Progress'
    | 'On Hold'
    | 'Due Date'
    | 'Completed';

type TaskPriority =
    | 'Low'
    | 'Medium'
    | 'High'
    | 'Urgent';


// ============================================================
// WORK LOG
// ============================================================

export interface WorkLog {
    id: number;
    startedAt: string;
    stoppedAt: string;
    duration: number;
}

interface OtherExpense {
    id: number;
    name: string;
    amount: number;
    description?: string;
}

// ============================================================
// TASK
// ============================================================


export interface Task {
    id: number;
    name?: string;
    title: string;
    description: string;

    project: string;
    phase: string;

    Assignstaff: AssignedStaff[];

    startDate: string;
    dueDate: string;

    priority: TaskPriority;
    status: TaskStatus;
    progress: number;

     estimatedHours?: number;  

    timerStartedAt?: string | null;
    totalWorkedSeconds?: number;
    isTimerRunning?: boolean;
    workLogs?: WorkLog[];
}


// ============================================================
// MATERIAL
// ============================================================

interface Material {
    id: number;
    name: string;
    unitCost: number;
    quantity: number;
}


// ============================================================
// CONVERSATION
// ============================================================

interface Conversation {
    id: number;
    type: 'update' | 'question' | 'image';
    text: string;
    image?: string;
    createdAt: string;
}


// ============================================================
// DRAWER PROPS
// ============================================================

interface TaskDrawerProps {
    task: Task;
    onClose: () => void;
    onUpdateTask: (task: Task) => void;
    onEditTask?: (task: Task) => void;
}


// ============================================================
// OFF CANVAS PROPS
// ============================================================

export interface OffCanvasProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    subtitle?: string;
    children: ReactNode;
    footer?: ReactNode;
    widthClass?: string;
}


// ============================================================
// OFF CANVAS
// ============================================================

export function OffCanvas({
    isOpen,
    onClose,
    title,
    subtitle,
    children,
    footer,
    widthClass = 'max-w-md',
}: OffCanvasProps) {
return createPortal(
    <div
        className={`fixed inset-0 z-[9999] ${
            isOpen ? '' : 'pointer-events-none'
        }`}
        aria-hidden={!isOpen}
    >
        {/* Overlay */}
        <div
            onClick={onClose}
            className={`absolute inset-0 bg-slate-900/40 transition-opacity duration-300 ${
                isOpen ? 'opacity-100' : 'opacity-0'
            }`}
        />

        {/* Drawer */}
        <div
            role="dialog"
            aria-modal="true"
            className={`absolute right-0 top-0 flex h-screen w-full ${widthClass} flex-col bg-slate-50 shadow-2xl transition-transform duration-300 ease-in-out ${
                isOpen
                    ? 'translate-x-0'
                    : 'translate-x-full'
            }`}
        >
            {/* Header */}
            <div className="shrink-0 border-b border-slate-200 bg-white px-6 py-4">
                <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                        <h2 className="text-base font-bold text-slate-900">
                            {title}
                        </h2>

                        {subtitle && (
                            <p className="mt-1 truncate text-xs text-slate-400">
                                {subtitle}
                            </p>
                        )}
                    </div>

                    <button
                        type="button"
                        onClick={onClose}
                        aria-label="Close panel"
                        className="shrink-0 rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                    >
                        <XIcon size={18} />
                    </button>
                </div>
            </div>

            {/* Content */}
            <div className="min-h-0 flex-1 overflow-y-auto px-5 py-5">
                {children}
            </div>

            {/* Footer */}
            {footer && (
                <div className="shrink-0 border-t border-slate-200 bg-white px-6 py-3">
                    {footer}
                </div>
            )}
        </div>
    </div>,
    document.body
);

}


// ============================================================
// STATIC DATA
// ============================================================

const teamMembers = [
    'David Wilson',
    'Emily Davis',
    'John Smith',

];

const statusOptions: TaskStatus[] = [
    'Pending',
    'In Progress',
    'On Hold',
    'Due Date',
    'Completed',
];


// ============================================================
// EDIT / TASK DRAWER
// ============================================================

const Edit = ({
    task,
    onClose,
    onUpdateTask,
}: TaskDrawerProps) => {

    // ========================================================
    // DRAWER STATE
    // ========================================================

    const [isOpen, setIsOpen] =
        useState(false);

    const closeTimerRef =
        useRef<number | null>(null);


    // ========================================================
    // CURRENT TASK
    // ========================================================

    const [currentTask, setCurrentTask] =
        useState<Task>({
            ...task,
            status: task.status ?? 'Pending',
            progress: task.progress ?? 0,
            estimatedHours: task.estimatedHours ?? 0,
            totalWorkedSeconds:
                task.totalWorkedSeconds ?? 0,
            timerStartedAt:
                task.timerStartedAt ?? null,
            isTimerRunning:
                task.isTimerRunning ?? false,
            workLogs:
                task.workLogs ?? [],
        });


        const [otherExpenses, setOtherExpenses] =
    useState<OtherExpense[]>([]);

const [expenseForm, setExpenseForm] = useState({
    name: '',
    amount: '',
    description: '',
});

const otherExpensesTotal = useMemo(
    () =>
        otherExpenses.reduce(
            (total, expense) => total + expense.amount,
            0
        ),
    [otherExpenses]
);

const handleAddExpense = () => {
    const name = expenseForm.name.trim();
    const amount = Number(expenseForm.amount);
    const description = expenseForm.description.trim();

    if (!name || amount <= 0) {
        return;
    }

    setOtherExpenses((current) => [
        ...current,
        {
            id: Date.now(),
            name,
            amount,
            description,
        },
    ]);

    setExpenseForm({
        name: '',
        amount: '',
        description: '',
    });
};

const handleDeleteExpense = (expenseId: number) => {
    setOtherExpenses((current) =>
        current.filter(
            (expense) => expense.id !== expenseId
        )
    );
};
    // ========================================================
    // TIMER STATE
    // ========================================================

    const [isTimerRunning, setIsTimerRunning] =
        useState<boolean>(
            task.isTimerRunning ?? false
        );

    const [elapsedSeconds, setElapsedSeconds] =
        useState<number>(
            task.totalWorkedSeconds ?? 0
        );

    const timerRef =
        useRef<number | null>(null);

    const timerStartedAtRef =
        useRef<string | null>(
            task.timerStartedAt ?? null
        );


    // ========================================================
    // ASSIGNEES
    // ========================================================

    const [showAssigneeMenu, setShowAssigneeMenu] =
        useState(false);

const [selectedAssignees, setSelectedAssignees] = useState<string[]>(
    task?.Assignstaff?.map((staff) => staff.name) ?? []
);

        
    const validAssignees = selectedAssignees.filter((name) =>
        teamMembers.includes(name)
    );


    useEffect(() => {
    if (task?.Assignstaff) {
        setSelectedAssignees(
            task.Assignstaff.map((staff) => staff.name)
        );
    } else {
        setSelectedAssignees([]);
    }
}, [task]);

    // ========================================================
    // MATERIALS
    // ========================================================

    const [materials, setMaterials] =
        useState<Material[]>([]);

    const [materialForm, setMaterialForm] =
        useState({
            name: '',
            unitCost: '',
            quantity: '',
        });


    // ========================================================
    // TABS
    // ========================================================

const [activeTab, setActiveTab] =
    useState<
        'description' | 'material' | 'expenses'
    >('description');


    // ========================================================
    // CONVERSATION
    // ========================================================

    const [conversations, setConversations] =
        useState<Conversation[]>([]);

    const [message, setMessage] =
        useState('');

    const [composerMode, setComposerMode] =
        useState<'update' | 'question'>(
            'update'
        );

    const [selectedImage, setSelectedImage] =
        useState<string | null>(null);

    const fileInputRef =
        useRef<HTMLInputElement>(null);


    // ========================================================
    // OPEN DRAWER ANIMATION
    // ========================================================

    useEffect(() => {
        const frame =
            requestAnimationFrame(() => {
                setIsOpen(true);
            });

        return () => {
            cancelAnimationFrame(frame);

            if (
                closeTimerRef.current !== null
            ) {
                window.clearTimeout(
                    closeTimerRef.current
                );
            }
        };
    }, []);


    // ========================================================
    // CLOSE DRAWER
    // ========================================================

    const handleClose = () => {
        if (!isOpen) {
            return;
        }

        setIsOpen(false);

        if (
            closeTimerRef.current !== null
        ) {
            window.clearTimeout(
                closeTimerRef.current
            );
        }

        closeTimerRef.current =
            window.setTimeout(() => {
                onClose();
            }, 300);
    };


    // ========================================================
    // UPDATE CURRENT TASK
    // ========================================================

    const updateCurrentTask = (
        updatedTask: Task
    ) => {
        setCurrentTask(updatedTask);

        onUpdateTask(updatedTask);
    };


    // ========================================================
    // TIMER - LIVE DISPLAY
    // ========================================================

    useEffect(() => {
        if (!isTimerRunning) {
            return;
        }

        const updateTimer = () => {
            const startedAt =
                timerStartedAtRef.current;

            if (!startedAt) {
                return;
            }

            const startTime =
                new Date(
                    startedAt
                ).getTime();

            const now = Date.now();

            const sessionSeconds =
                Math.max(
                    0,
                    Math.floor(
                        (now - startTime) /
                            1000
                    )
                );

            const previousTotal =
                currentTask.totalWorkedSeconds ??
                0;

            setElapsedSeconds(
                previousTotal +
                    sessionSeconds
            );
        };

        // Immediately update
        updateTimer();

        timerRef.current =
            window.setInterval(
                updateTimer,
                1000
            );

        return () => {
            if (
                timerRef.current !== null
            ) {
                window.clearInterval(
                    timerRef.current
                );

                timerRef.current = null;
            }
        };
    }, [
        isTimerRunning,
        currentTask.totalWorkedSeconds,
    ]);


    // ========================================================
    // FORMAT TIMER
    // ========================================================

    const formatHours = (seconds: number) => {
    return (seconds / 3600).toFixed(2);
};

    const formatDuration = (
        totalSeconds: number
    ) => {
        const hours =
            Math.floor(
                totalSeconds / 3600
            );

        const minutes =
            Math.floor(
                (totalSeconds % 3600) / 60
            );

        const seconds =
            totalSeconds % 60;

        return [
            hours
                .toString()
                .padStart(2, '0'),

            minutes
                .toString()
                .padStart(2, '0'),

            seconds
                .toString()
                .padStart(2, '0'),
        ].join(':');
    };


    // ========================================================
    // START TIMER
    // ========================================================

    const handleStartTimer = () => {
        if (isTimerRunning) {
            return;
        }

        const startedAt =
            new Date().toISOString();

        timerStartedAtRef.current =
            startedAt;

        setIsTimerRunning(true);

        const updatedTask: Task = {
            ...currentTask,

            status: 'In Progress',

            progress:
                currentTask.progress === 0
                    ? 10
                    : currentTask.progress,

            timerStartedAt:
                startedAt,

            isTimerRunning: true,
        };

        setCurrentTask(updatedTask);

        onUpdateTask(updatedTask);
    };


    // ========================================================
    // STOP TIMER
    // ========================================================

    const handleStopTimer = () => {
        if (
            !isTimerRunning ||
            !timerStartedAtRef.current
        ) {
            return;
        }

        const startedAt =
            timerStartedAtRef.current;

        const stoppedAt =
            new Date().toISOString();

        const startTime =
            new Date(
                startedAt
            ).getTime();

        const stopTime =
            new Date(
                stoppedAt
            ).getTime();

        const sessionDuration =
            Math.max(
                0,
                Math.floor(
                    (stopTime -
                        startTime) /
                        1000
                )
            );

        const previousTotal =
            currentTask.totalWorkedSeconds ??
            0;

        const newTotal =
            previousTotal +
            sessionDuration;

        const newWorkLog: WorkLog = {
            id: Date.now(),

            startedAt,

            stoppedAt,

            duration:
                sessionDuration,
        };

        const updatedTask: Task = {
            ...currentTask,

            totalWorkedSeconds:
                newTotal,

            timerStartedAt: null,

            isTimerRunning: false,

            workLogs: [
                ...(currentTask.workLogs ??
                    []),
                newWorkLog,
            ],
        };

        setElapsedSeconds(newTotal);

        setIsTimerRunning(false);

        timerStartedAtRef.current =
            null;

        setCurrentTask(updatedTask);

        onUpdateTask(updatedTask);
    };


    // ========================================================
    // STATUS CHANGE
    // ========================================================

    const handleStatusChange = (
        status: TaskStatus
    ) => {

        let progress =
            currentTask.progress;

        if (status === 'Completed') {
            progress = 100;
        } else if (
            status === 'Pending' &&
            currentTask.status ===
                'Completed'
        ) {
            progress = 0;
        } else if (
            status === 'In Progress' &&
            progress === 0
        ) {
            progress = 10;
        }

        const updatedTask: Task = {
            ...currentTask,

            status,

            progress,
        };

        updateCurrentTask(
            updatedTask
        );
    };


    // ========================================================
    // ASSIGNEE
    // ========================================================

    const toggleAssignee = (
        member: string
    ) => {
        setSelectedAssignees(
            (current) =>
                current.includes(member)
                    ? current.filter(
                          (name) =>
                              name !==
                              member
                      )
                    : [
                          ...current,
                          member,
                      ]
        );
    };


    const saveAssignees = () => {
    const updatedAssignStaff: AssignedStaff[] = selectedAssignees.map(
        (staffName) => {
            const existingStaff = currentTask.Assignstaff?.find(
                (staff) => staff.name === staffName
            );

            return (
                existingStaff ?? {
                    name: staffName,
                    rate: 0,
                    hours: 0,
                    amount: 0,
                }
            );
        }
    );

    updateCurrentTask({
        ...currentTask,
        Assignstaff: updatedAssignStaff,
    });

    setShowAssigneeMenu(false);
};



    // ========================================================
    // MATERIAL
    // ========================================================

    const handleAddMaterial = () => {
        const name =
            materialForm.name.trim();

        const unitCost =
            Number(
                materialForm.unitCost
            );

        const quantity =
            Number(
                materialForm.quantity
            );

        if (
            !name ||
            unitCost <= 0 ||
            quantity <= 0
        ) {
            return;
        }

        setMaterials((current) => [
            ...current,

            {
                id: Date.now(),

                name,

                unitCost,

                quantity,
            },
        ]);

        setMaterialForm({
            name: '',
            unitCost: '',
            quantity: '',
        });
    };


    const handleDeleteMaterial = (
        materialId: number
    ) => {
        setMaterials((current) =>
            current.filter(
                (material) =>
                    material.id !==
                    materialId
            )
        );
    };


    const actualSpend = useMemo(
        () =>
            materials.reduce(
                (
                    total,
                    material
                ) =>
                    total +
                    material.unitCost *
                        material.quantity,

                0
            ),

        [materials]
    );


    // ========================================================
    // CONVERSATION
    // ========================================================

    const handlePostUpdate = () => {
        const text =
            message.trim();

        if (!text) {
            return;
        }

        setConversations(
            (current) => [
                ...current,

                {
                    id: Date.now(),

                    type: composerMode,

                    text,

                    createdAt:
                        new Date().toLocaleString(),
                },
            ]
        );

        setMessage('');
    };


    const handleDeleteConversation = (
        conversationId: number
    ) => {
        setConversations(
            (current) =>
                current.filter(
                    (conversation) =>
                        conversation.id !==
                        conversationId
                )
        );
    };


    // ========================================================
    // IMAGE
    // ========================================================

    const handleImageClick = () => {
        fileInputRef.current?.click();
    };


    const handleImageChange = (
        e: ChangeEvent<HTMLInputElement>
    ) => {
        const file =
            e.target.files?.[0];

        if (!file) {
            return;
        }

        const reader =
            new FileReader();

        reader.onload = () => {
            setSelectedImage(
                reader.result as string
            );
        };

        reader.readAsDataURL(file);
    };


    const handlePostImage = () => {
        if (!selectedImage) {
            return;
        }

        setConversations(
            (current) => [
                ...current,

                {
                    id: Date.now(),

                    type: 'image',

                    text:
                        'Image attachment',

                    image:
                        selectedImage,

                    createdAt:
                        new Date().toLocaleString(),
                },
            ]
        );

        setSelectedImage(null);

        if (
            fileInputRef.current
        ) {
            fileInputRef.current.value =
                '';
        }
    };


    // ========================================================
    // RENDER
    // ========================================================

return (
    <OffCanvas
        isOpen={isOpen}
        onClose={handleClose}
        title="Task Details"
        subtitle={currentTask.title}
        widthClass="max-w-2xl"
        footer={
            <div className="flex items-center justify-end">
                <button
                    type="button"
                    onClick={handleClose}
                    className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
                >
                    Close
                </button>
            </div> 
        }
    >
        <div className="space-y-5">

            {/* =====================================================
                TASK INFORMATION
            ====================================================== */}
            <div className="rounded-xl border border-slate-200 bg-white p-5">
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                            Project
                        </p>
                        <p className="mt-1.5 text-sm font-semibold text-slate-700">
                            {currentTask.project}
                        </p>
                    </div>

                    <div>
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                            Phase
                        </p>
                        <p className="mt-1.5 text-sm font-semibold text-slate-700">
                            {currentTask.phase}
                        </p>
                    </div>

                    <div>
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                            Start Date
                        </p>
                        <p className="mt-1.5 text-sm font-medium text-slate-700">
                            {currentTask.startDate}
                        </p>
                    </div>

                    <div>
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                            Due Date
                        </p>
                        <p className="mt-1.5 text-sm font-medium text-slate-700">
                            {currentTask.dueDate}
                        </p>
                    </div>
                </div>
            </div>

            {/* =====================================================
                STATUS
            ====================================================== */}
            <div className="rounded-xl border border-slate-200 bg-white p-5">
                <div className="mb-4">
                    <h3 className="text-sm font-bold text-slate-800">
                        Status
                    </h3>

                    <p className="mt-1 text-xs text-slate-400">
                        Update the current status of this task.
                    </p>
                </div>

                <div className="flex flex-wrap gap-2">
                    {statusOptions.map((status) => {
                        const isSelected =
                            currentTask.status === status;

                        return (
                            <button
                                key={status}
                                type="button"
                                onClick={() =>
                                    handleStatusChange(status)
                                }
                                className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                                    isSelected
                                        ? 'bg-primary text-white shadow-sm'
                                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                                }`}
                            >
                                {isSelected && (
                                    <Check
                                        size={13}
                                        weight="bold"
                                    />
                                )}

                                {status}
                            </button>
                        );
                    })}
                </div>
            </div>

            {/* =====================================================
                WORK TIMER
            ====================================================== */}
            <div className="rounded-xl border border-slate-200 bg-white p-5">

                {/* Header */}
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                        <div className="flex items-center gap-2">
                            <h3 className="text-sm font-bold text-slate-800">
                                Work Timer
                            </h3>

                            <div
                                className={`h-2.5 w-2.5 rounded-full ${
                                    isTimerRunning
                                        ? 'animate-pulse bg-emerald-500'
                                        : 'bg-slate-300'
                                }`}
                            />
                        </div>

                        <p className="mt-1 text-xs text-slate-400">
                            Track time spent working on this task.
                        </p>
                    </div>

                    <div className="flex items-center gap-3">
                        <div
                            className={`rounded-lg border px-3 py-2 ${
                                isTimerRunning
                                    ? 'border-emerald-200 bg-emerald-50'
                                    : 'border-slate-200 bg-slate-50'
                            }`}
                        >
                            <p
                                className={`font-mono text-sm font-bold ${
                                    isTimerRunning
                                        ? 'text-emerald-700'
                                        : 'text-slate-700'
                                }`}
                            >
                                {formatDuration(elapsedSeconds)}
                            </p>
                        </div>

                        {!isTimerRunning ? (
                            <button
                                type="button"
                                onClick={handleStartTimer}
                                className="inline-flex items-center justify-center rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
                            >
                                Start Timer
                            </button>
                        ) : (
                            <button
                                type="button"
                                onClick={handleStopTimer}
                                className="inline-flex items-center justify-center rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700"
                            >
                                Stop Timer
                            </button>
                        )}
                    </div>
                </div>

                {/* Time Summary */}
                <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">

                    {/* Running Timer */}
                    <div
                        className={`rounded-xl border p-4 ${
                            isTimerRunning
                                ? 'border-emerald-100 bg-emerald-50'
                                : 'border-slate-200 bg-slate-50'
                        }`}
                    >
                        <div className="flex items-center justify-between">
                            <p
                                className={`text-[10px] font-semibold uppercase tracking-wide ${
                                    isTimerRunning
                                        ? 'text-emerald-500'
                                        : 'text-slate-400'
                                }`}
                            >
                                Running Timer
                            </p>

                            <div
                                className={`h-2 w-2 rounded-full ${
                                    isTimerRunning
                                        ? 'animate-pulse bg-emerald-500'
                                        : 'bg-slate-300'
                                }`}
                            />
                        </div>

                        <p
                            className={`mt-2 font-mono text-xl font-bold ${
                                isTimerRunning
                                    ? 'text-emerald-700'
                                    : 'text-slate-700'
                            }`}
                        >
                            {formatDuration(elapsedSeconds)}
                        </p>

                        <p
                            className={`mt-1 text-[10px] ${
                                isTimerRunning
                                    ? 'text-emerald-500'
                                    : 'text-slate-400'
                            }`}
                        >
                            {isTimerRunning
                                ? 'Timer is running'
                                : 'Timer stopped'}
                        </p>
                    </div>

                    {/* Estimated Hours */}
                    <div className="rounded-xl border border-blue-100 bg-blue-50 p-4">
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-blue-500">
                            Estimated Hours
                        </p>

                        <p className="mt-2 font-mono text-xl font-bold text-blue-700">
                            {(currentTask.estimatedHours ?? 0).toFixed(2)}h
                        </p>

                        <p className="mt-1 text-[10px] text-blue-500">
                            Planned time
                        </p>
                    </div>

                    {/* Worked Hours */}
                    <div className="rounded-xl border border-emerald-100 bg-emerald-50 p-4">
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-emerald-500">
                            Worked Hours
                        </p>

                        <p className="mt-2 font-mono text-xl font-bold text-emerald-700">
                            {formatHours(elapsedSeconds)}h
                        </p>

                        <p className="mt-1 text-[10px] text-emerald-500">
                            {formatDuration(elapsedSeconds)}
                        </p>
                    </div>

                    {/* Remaining Hours */}
                    <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                            Remaining Hours
                        </p>

                        <p
                            className={`mt-2 font-mono text-xl font-bold ${
                                elapsedSeconds / 3600 >=
                                (currentTask.estimatedHours ?? 0)
                                    ? 'text-red-600'
                                    : 'text-slate-700'
                            }`}
                        >
                            {Math.max(
                                0,
                                (currentTask.estimatedHours ?? 0) -
                                    elapsedSeconds / 3600
                            ).toFixed(2)}
                            h
                        </p>

                        <p className="mt-1 text-[10px] text-slate-400">
                            Based on worked time
                        </p>
                    </div>
                </div>

                {/* Work Logs */}
                {currentTask.workLogs &&
                    currentTask.workLogs.length > 0 && (
                        <div className="mt-5 border-t border-slate-100 pt-5">
                            <div className="mb-3 flex items-center justify-between">
                                <h4 className="text-xs font-bold uppercase tracking-wide text-slate-500">
                                    Work Logs
                                </h4>

                                <span className="text-[10px] font-medium text-slate-400">
                                    {currentTask.workLogs.length}{' '}
                                    {currentTask.workLogs.length === 1
                                        ? 'Session'
                                        : 'Sessions'}
                                </span>
                            </div>

                            <div className="space-y-2">
                                {currentTask.workLogs
                                    .slice()
                                    .reverse()
                                    .map((log) => (
                                        <div
                                            key={log.id}
                                            className="rounded-lg bg-slate-50 px-3 py-3"
                                        >
                                            <div className="flex items-center justify-between gap-3">
                                                <div className="min-w-0">
                                                    <p className="text-xs font-semibold text-slate-700">
                                                        Work Session
                                                    </p>

                                                    <p className="mt-1 text-[10px] text-slate-400">
                                                        {new Date(
                                                            log.startedAt
                                                        ).toLocaleString()}
                                                        {' → '}
                                                        {new Date(
                                                            log.stoppedAt
                                                        ).toLocaleString()}
                                                    </p>
                                                </div>

                                                <span className="shrink-0 font-mono text-xs font-bold text-slate-700">
                                                    {formatDuration(
                                                        log.duration
                                                    )}
                                                </span>
                                            </div>
                                        </div>
                                    ))}
                            </div>
                        </div>
                    )}
            </div>

            {/* =====================================================
                ASSIGN STAFF
            ====================================================== */}
            <div className="rounded-xl border border-slate-200 bg-white p-5">
                <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                        <h3 className="text-sm font-bold text-slate-800">
                            Assign Staff
                        </h3>

                       <p className="mt-1 max-w-md text-xs leading-5 text-slate-500">
                            {validAssignees.length > 0
                                ? validAssignees.join(', ')
                                : 'No staff assigned'}
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={() =>
                            setShowAssigneeMenu((value) => !value)
                        }
                        className="inline-flex shrink-0 items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-50"
                    >
                        <Users size={15} />
                        Manage Assignees
                    </button>
                </div>

                {showAssigneeMenu && (
                    <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-4">
                        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                            {teamMembers.map((member) => (
                                <label
                                    key={member}
                                    className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-white px-3 py-2.5 transition hover:border-slate-300 hover:bg-slate-50"
                                >
                                    <input
                                        type="checkbox"
                                        checked={selectedAssignees.includes(
                                            member
                                        )}
                                        onChange={() =>
                                            toggleAssignee(member)
                                        }
                                        className="h-4 w-4 rounded border-slate-300 text-primary focus:ring-primary"
                                    />

                                    <span className="text-sm font-medium text-slate-700">
                                        {member}
                                    </span>
                                </label>
                            ))}
                        </div>

                        <button
                            type="button"
                            onClick={saveAssignees}
                            className="mt-4 w-full rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90"
                        >
                            Save Assignees
                        </button>
                    </div>
                )}
            </div>

            {/* =====================================================
                DESCRIPTION / MATERIAL / EXPENSES
            ====================================================== */}
            <div className="rounded-xl border border-slate-200 bg-white">

                {/* Tabs */}
                <div className="border-b border-slate-200 px-5">
                    <div className="flex items-center gap-6 overflow-x-auto">
                        <button
                            type="button"
                            onClick={() => setActiveTab('description')}
                            className={`relative shrink-0 py-3.5 text-sm font-semibold transition ${
                                activeTab === 'description'
                                    ? 'text-primary'
                                    : 'text-slate-500 hover:text-slate-700'
                            }`}
                        >
                            Description

                            {activeTab === 'description' && (
                                <span className="absolute inset-x-0 bottom-0 h-0.5 rounded-full bg-primary" />
                            )}
                        </button>

                        <button
                            type="button"
                            onClick={() => setActiveTab('material')}
                            className={`relative shrink-0 py-3.5 text-sm font-semibold transition ${
                                activeTab === 'material'
                                    ? 'text-primary'
                                    : 'text-slate-500 hover:text-slate-700'
                            }`}
                        >
                            Material Used

                            {activeTab === 'material' && (
                                <span className="absolute inset-x-0 bottom-0 h-0.5 rounded-full bg-primary" />
                            )}
                        </button>

                        <button
                            type="button"
                            onClick={() => setActiveTab('expenses')}
                            className={`relative shrink-0 py-3.5 text-sm font-semibold transition ${
                                activeTab === 'expenses'
                                    ? 'text-primary'
                                    : 'text-slate-500 hover:text-slate-700'
                            }`}
                        >
                            Other Expenses

                            {activeTab === 'expenses' && (
                                <span className="absolute inset-x-0 bottom-0 h-0.5 rounded-full bg-primary" />
                            )}
                        </button>
                    </div>
                </div>

                {/* Tab Content */}
                <div className="p-5">

                    {/* Description */}
                    {activeTab === 'description' && (
                        <div>
                            <h3 className="text-sm font-bold text-slate-800">
                                Description
                            </h3>

                            <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-600">
                                {currentTask.description ||
                                    'No description available.'}
                            </p>
                        </div>
                    )}

                    {/* Material */}
                    {activeTab === 'material' && (
                        <div>
                            <div className="flex items-start justify-between gap-4">
                                <div className="min-w-0">
                                    <h3 className="text-sm font-bold text-slate-800">
                                        Material Used
                                    </h3>

                                    <p className="mt-1 text-xs text-slate-500">
                                        Add materials used for this task.
                                    </p>
                                </div>

                                <div className="shrink-0 rounded-lg bg-slate-50 px-3 py-2 text-right">
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Task Actual Spend
                                    </p>

                                    <p className="mt-0.5 text-lg font-bold text-slate-800">
                                        ${actualSpend.toFixed(2)}
                                    </p>
                                </div>
                            </div>

                            {/* Material Form */}
                            <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
                                <div className="grid grid-cols-1 gap-4 md:grid-cols-3">

                                    <div>
                                        <label className="mb-1.5 block text-xs font-semibold text-slate-600">
                                            Material Name
                                        </label>

                                        <input
                                            type="text"
                                            value={materialForm.name}
                                            onChange={(e) =>
                                                setMaterialForm((prev) => ({
                                                    ...prev,
                                                    name: e.target.value,
                                                }))
                                            }
                                            placeholder="96-Core ADSS Fiber"
                                            className="form-input w-full rounded-lg border-slate-200 bg-white text-sm"
                                        />
                                    </div>

                                    <div>
                                        <label className="mb-1.5 block text-xs font-semibold text-slate-600">
                                            Unit Cost ($)
                                        </label>

                                        <input
                                            type="number"
                                            min="0"
                                            step="0.01"
                                            value={materialForm.unitCost}
                                            onChange={(e) =>
                                                setMaterialForm((prev) => ({
                                                    ...prev,
                                                    unitCost:
                                                        e.target.value,
                                                }))
                                            }
                                            placeholder="0.00"
                                            className="form-input w-full rounded-lg border-slate-200 bg-white text-sm"
                                        />
                                    </div>

                                    <div>
                                        <label className="mb-1.5 block text-xs font-semibold text-slate-600">
                                            Quantity
                                        </label>

                                        <input
                                            type="number"
                                            min="0"
                                            step="1"
                                            value={materialForm.quantity}
                                            onChange={(e) =>
                                                setMaterialForm((prev) => ({
                                                    ...prev,
                                                    quantity:
                                                        e.target.value,
                                                }))
                                            }
                                            placeholder="1"
                                            className="form-input w-full rounded-lg border-slate-200 bg-white text-sm"
                                        />
                                    </div>
                                </div>

                                <div className="mt-4 flex justify-end">
                                    <button
                                        type="button"
                                        onClick={handleAddMaterial}
                                        className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90"
                                    >
                                        <Plus size={16} />
                                        Add Material to Task
                                    </button>
                                </div>
                            </div>

                            {/* Allocated Materials */}
                            <div className="mt-6 border-t border-slate-100 pt-5">
                                <h4 className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-500">
                                    Allocated Materials
                                </h4>

                                {materials.length === 0 ? (
                                    <div className="rounded-lg border border-dashed border-slate-200 px-4 py-8 text-center">
                                        <p className="text-sm text-slate-400">
                                            No materials logged to this task
                                            yet.
                                        </p>
                                    </div>
                                ) : (
                                    <div className="space-y-2">
                                        {materials.map((material) => (
                                            <div
                                                key={material.id}
                                                className="flex items-center justify-between gap-4 rounded-lg border border-slate-100 bg-slate-50 px-3 py-3"
                                            >
                                                <div className="min-w-0">
                                                    <p className="truncate text-sm font-semibold text-slate-700">
                                                        {material.name}
                                                    </p>

                                                    <p className="mt-1 text-xs text-slate-500">
                                                        $
                                                        {material.unitCost.toFixed(
                                                            2
                                                        )}
                                                        {' × '}
                                                        {material.quantity}
                                                    </p>
                                                </div>

                                                <div className="flex shrink-0 items-center gap-3">
                                                    <p className="text-sm font-bold text-slate-700">
                                                        $
                                                        {(
                                                            material.unitCost *
                                                            material.quantity
                                                        ).toFixed(2)}
                                                    </p>

                                                    <button
                                                        type="button"
                                                        onClick={() =>
                                                            handleDeleteMaterial(
                                                                material.id
                                                            )
                                                        }
                                                        className="rounded-lg p-1.5 text-red-500 transition hover:bg-red-50"
                                                        title="Delete material"
                                                    >
                                                        <Trash size={16} />
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Other Expenses */}
                    {activeTab === 'expenses' && (
                        <div>
                            <div className="flex items-start justify-between gap-4">
                                <div className="min-w-0">
                                    <h3 className="text-sm font-bold text-slate-800">
                                        Other Expenses
                                    </h3>

                                    <p className="mt-1 text-xs text-slate-500">
                                        Add any additional expenses related
                                        to this task.
                                    </p>
                                </div>

                                <div className="shrink-0 rounded-lg bg-slate-50 px-3 py-2 text-right">
                                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                        Total Expenses
                                    </p>

                                    <p className="mt-0.5 text-lg font-bold text-slate-800">
                                        ${otherExpensesTotal.toFixed(2)}
                                    </p>
                                </div>
                            </div>

                            {/* Expense Form */}
                            <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
                                <div className="grid grid-cols-1 gap-4 md:grid-cols-3">

                                    <div>
                                        <label className="mb-1.5 block text-xs font-semibold text-slate-600">
                                            Expense Name
                                        </label>

                                        <input
                                            type="text"
                                            value={expenseForm.name}
                                            onChange={(e) =>
                                                setExpenseForm((prev) => ({
                                                    ...prev,
                                                    name: e.target.value,
                                                }))
                                            }
                                            placeholder="Travel / Transport"
                                            className="form-input w-full rounded-lg border-slate-200 bg-white text-sm"
                                        />
                                    </div>

                                    <div>
                                        <label className="mb-1.5 block text-xs font-semibold text-slate-600">
                                            Amount ($)
                                        </label>

                                        <input
                                            type="number"
                                            min="0"
                                            step="0.01"
                                            value={expenseForm.amount}
                                            onChange={(e) =>
                                                setExpenseForm((prev) => ({
                                                    ...prev,
                                                    amount:
                                                        e.target.value,
                                                }))
                                            }
                                            placeholder="0.00"
                                            className="form-input w-full rounded-lg border-slate-200 bg-white text-sm"
                                        />
                                    </div>

                                    <div>
                                        <label className="mb-1.5 block text-xs font-semibold text-slate-600">
                                            Description
                                        </label>

                                        <input
                                            type="text"
                                            value={
                                                expenseForm.description
                                            }
                                            onChange={(e) =>
                                                setExpenseForm((prev) => ({
                                                    ...prev,
                                                    description:
                                                        e.target.value,
                                                }))
                                            }
                                            placeholder="Expense details"
                                            className="form-input w-full rounded-lg border-slate-200 bg-white text-sm"
                                        />
                                    </div>
                                </div>

                                <div className="mt-4 flex justify-end">
                                    <button
                                        type="button"
                                        onClick={handleAddExpense}
                                        className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90"
                                    >
                                        <Plus size={16} />
                                        Add Expense to Task
                                    </button>
                                </div>
                            </div>

                            {/* Expense List */}
                            <div className="mt-6 border-t border-slate-100 pt-5">
                                <h4 className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-500">
                                    Logged Expenses
                                </h4>

                                {otherExpenses.length === 0 ? (
                                    <div className="rounded-lg border border-dashed border-slate-200 px-4 py-8 text-center">
                                        <p className="text-sm text-slate-400">
                                            No other expenses logged to this
                                            task yet.
                                        </p>
                                    </div>
                                ) : (
                                    <div className="space-y-2">
                                        {otherExpenses.map((expense) => (
                                            <div
                                                key={expense.id}
                                                className="flex items-center justify-between gap-4 rounded-lg border border-slate-100 bg-slate-50 px-3 py-3"
                                            >
                                                <div className="min-w-0">
                                                    <p className="truncate text-sm font-semibold text-slate-700">
                                                        {expense.name}
                                                    </p>

                                                    {expense.description && (
                                                        <p className="mt-1 truncate text-xs text-slate-500">
                                                            {
                                                                expense.description
                                                            }
                                                        </p>
                                                    )}
                                                </div>

                                                <div className="flex shrink-0 items-center gap-3">
                                                    <p className="text-sm font-bold text-slate-700">
                                                        $
                                                        {expense.amount.toFixed(
                                                            2
                                                        )}
                                                    </p>

                                                    <button
                                                        type="button"
                                                        onClick={() =>
                                                            handleDeleteExpense(
                                                                expense.id
                                                            )
                                                        }
                                                        className="rounded-lg p-1.5 text-red-500 transition hover:bg-red-50"
                                                        title="Delete expense"
                                                    >
                                                        <Trash size={16} />
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* =====================================================
                CONVERSATION
            ====================================================== */}
            <div className="rounded-xl border border-slate-200 bg-white p-5">

                {/* Header */}
                <div className="mb-5">
                    <h3 className="text-sm font-bold text-slate-800">
                        Conversation
                    </h3>

                    <p className="mt-1 text-xs text-slate-500">
                        Post updates and ask questions about this task.
                    </p>
                </div>

                {/* Conversation List */}
                {conversations.length === 0 ? (
                    <div className="mb-5 rounded-xl border border-dashed border-slate-200 px-4 py-8 text-center">
                        <IconMessageDots className="mx-auto text-slate-300" />

                        <p className="mt-2 text-sm text-slate-400">
                            No updates yet. Start the conversation!
                        </p>
                    </div>
                ) : (
                    <div className="mb-5 space-y-3">
                        {conversations.map((conversation) => (
                            <div
                                key={conversation.id}
                                className="rounded-xl border border-slate-100 bg-slate-50 p-4"
                            >
                                <div className="flex items-start gap-3">

                                    {/* Avatar */}
                                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-white">
                                        {selectedAssignees[0]
                                            ?.split(' ')
                                            .map((name) => name[0])
                                            .join('')
                                            .slice(0, 2) || 'U'}
                                    </div>

                                    {/* Conversation Info */}
                                    <div className="min-w-0 flex-1">
                                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                                            <p className="text-xs font-bold text-slate-700">
                                                {selectedAssignees[0] ||
                                                    'Assigned Staff'}
                                            </p>

                                            <p className="text-[10px] text-slate-400">
                                                {conversation.createdAt}
                                            </p>
                                        </div>

                                        <span className="mt-1 inline-flex rounded-full bg-white px-2 py-1 text-[10px] font-semibold text-primary">
                                            {conversation.type === 'question'
                                                ? 'Question'
                                                : conversation.type === 'image'
                                                ? 'Image'
                                                : 'Update'}
                                        </span>
                                    </div>

                                    {/* Delete */}
                                    <button
                                        type="button"
                                        onClick={() =>
                                            handleDeleteConversation(
                                                conversation.id
                                            )
                                        }
                                        title="Delete conversation"
                                        className="shrink-0 rounded-md p-1.5 text-red-500 transition hover:bg-red-50"
                                    >
                                        <Trash size={15} />
                                    </button>
                                </div>

                                {conversation.image ? (
                                    <img
                                        src={conversation.image}
                                        alt="Task attachment"
                                        className="mt-3 max-h-64 w-full rounded-lg object-cover"
                                    />
                                ) : (
                                    <p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-slate-600">
                                        {conversation.text}
                                    </p>
                                )}
                            </div>
                        ))}
                    </div>
                )}

                {/* Composer Mode */}
                <div className="mb-3 flex flex-wrap items-center gap-2">
                    <button
                        type="button"
                        onClick={() => setComposerMode('update')}
                        className={`rounded-lg px-3 py-2 text-xs font-semibold transition ${
                            composerMode === 'update'
                                ? 'bg-primary text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                    >
                        Post Update
                    </button>

                    <button
                        type="button"
                        onClick={() => setComposerMode('question')}
                        className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition ${
                            composerMode === 'question'
                                ? 'bg-primary text-white'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                    >
                        <IconMessageDots />
                        Ask Question
                    </button>
                </div>

                {/* Message */}
                <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    rows={4}
                    placeholder={
                        composerMode === 'question'
                            ? 'Ask a question about this task...'
                            : 'Type your update...'
                    }
                    className="form-textarea w-full resize-none rounded-lg border-slate-200 text-sm"
                />

                {/* Composer Footer */}
                <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">

                    <div className="min-w-0">
                        <input
                            ref={fileInputRef}
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleImageChange}
                        />

                        <button
                            type="button"
                            onClick={handleImageClick}
                            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-600 transition hover:bg-slate-50"
                        >
                            <ImageIcon size={15} />
                            Image
                        </button>

                        {selectedImage && (
                            <div className="mt-3 flex items-start gap-3">
                                <div className="relative">
                                    <img
                                        src={selectedImage}
                                        alt="Selected"
                                        className="h-20 w-20 rounded-lg object-cover"
                                    />

                                    <button
                                        type="button"
                                        onClick={() =>
                                            setSelectedImage(null)
                                        }
                                        className="absolute -right-2 -top-2 rounded-full bg-red-500 p-1 text-white"
                                    >
                                        <XIcon size={12} />
                                    </button>
                                </div>

                                <button
                                    type="button"
                                    onClick={handlePostImage}
                                    className="rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-white"
                                >
                                    Post Image
                                </button>
                            </div>
                        )}
                    </div>

                    <button
                        type="button"
                        onClick={handlePostUpdate}
                        className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90"
                    >
                        <IconSend />

                        {composerMode === 'question'
                            ? 'Ask Question'
                            : 'Post Update'}
                    </button>
                </div>
            </div>
        </div>
    </OffCanvas>
);

};


export default Edit;
