import { useEffect, useMemo, useState } from "react";

import {
    X,
    Plus,
    Trash,
    CaretDown,
    CaretUp,
} from "@phosphor-icons/react";

import { Buildings } from "@phosphor-icons/react";
import OffCanvas from "../../components/OffCanvas";
import type {
    SurveyModule,
    SurveyField,
} from "../../components/SurveyReport/SurveyStorage";

type SurveyFieldType = SurveyField["type"];

// type SurveyFieldType =
//     | "text"
//     | "number"
//     | "radio"
//     | "select"
//     | "textarea"
//     | "checkbox_group";

type NewFieldOption = {
    id: string;
    label: string;
    value: string;
};

type NewFieldDraft = {
    id: string;
    label: string;
    type: SurveyFieldType;
    required: boolean;
    placeholder: string;
    helpText: string;
    options: NewFieldOption[];
};

type NewFieldGroupDraft = {
    id: string;
    title: string;
    fields: NewFieldDraft[];
};

type NewSectionDraft = {
    id: string;
    number: string;
    title: string;
    fieldGroups: NewFieldGroupDraft[];
};

type AddModuleProps = {
    open: boolean;
    onClose: () => void;
    onCreate: (module: SurveyModule) => void;
    onUpdate: (module: SurveyModule) => void;
    editingModule?: SurveyModule | null;
    templateName?: string;
    modules: SurveyModule[];
};

const createId = (): string => {
    return crypto.randomUUID();
};

const createOptionId = (): string => {
    return crypto.randomUUID();
};

const slugify = (value: string): string => {
    return value
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "");
};

const createEmptyField = (): NewFieldDraft => ({
    id: createId(),
    label: "",
    type: "text",
    required: false,
    placeholder: "",
    helpText: "",
    options: [],
});

const createEmptyGroup = (): NewFieldGroupDraft => ({
    id: createId(),
    title: "",
    fields: [],
});

const createEmptySection = (
    sectionNumber: number
): NewSectionDraft => ({
    id: createId(),
    number: String(sectionNumber),
    title: "",
    fieldGroups: [],
});

export default function AddModule({
    open,
    onClose,
    onCreate,
    onUpdate,
    editingModule,
    templateName = "",
    modules,
}: AddModuleProps) {
    const [title, setTitle] = useState("");
    const [code, setCode] = useState("");
    const [zone, setZone] = useState("");
    const [description, setDescription] = useState("");
    const [sections, setSections] = useState<NewSectionDraft[]>([]);
    const [expandedFields, setExpandedFields] = useState<string[]>([]);

    const resetForm = () => {
    setTitle("");
    setCode("");
    setZone("");
    setDescription("");
    setSections([]);
    setExpandedFields([]);
};

useEffect(() => {
    if (!open) {
        return;
    }

    // 1. Try editingModule first (direct edit)
    // 2. Otherwise try to find a module whose name matches templateName
    const matchedModule = editingModule
        ? editingModule
        : templateName
        ? modules.find(
              (m) =>
                  m.name.trim().toLowerCase() ===
                  templateName.trim().toLowerCase()
          ) ?? null
        : null;

    if (!matchedModule) {
        resetForm();
        return;
    }

    setTitle(matchedModule.name ?? "");
    setCode(matchedModule.code ?? "");
    setZone(matchedModule.zone ?? "");
    setDescription(matchedModule.description ?? "");

    setSections(
        (matchedModule.sections ?? []).map((section, sectionIndex) => ({
            id: section.id,
            number: section.number ?? String(sectionIndex + 1),
            title: section.title ?? "",
            fieldGroups: (section.fieldGroups ?? []).map((group) => ({
                id: group.id,
                title: group.title ?? "",
                fields: (group.fields ?? []).map((field) => ({
                    id: field.id,
                    label: field.label ?? "",
                    type: field.type,
                    required: field.required ?? false,
                    placeholder: field.placeholder ?? "",
                    helpText: field.helpText ?? "",
                    options: (field.options ?? []).map((option) => ({
                        id: String(option.id),
                        label: option.label ?? "",
                        value: option.value ?? "",
                    })),
                })),
            })),
        }))
    );

    setExpandedFields([]);
// eslint-disable-next-line react-hooks/exhaustive-deps
}, [open, editingModule, templateName, modules]);

    const addSection = () => {setSections((current) => [...current,createEmptySection(current.length + 1),]);};

    const removeSection = (sectionId: string) => {setSections((current) =>current.filter((section) => section.id !== sectionId));};


    
    const updateSection = (sectionId: string,updates: Partial<NewSectionDraft>) => {setSections((current) =>current.map((section) =>
        section.id === sectionId
                    ? { ...section, ...updates }
                    : section
            )
        );
    };

//     const availableModules = useMemo(() => {
//     if (!templateName) {
//         return modules;
//     }

//     return modules.filter((module) =>
//         module.templateNames?.some(
//             (name) =>
//                 name.trim().toLowerCase() ===
//                 templateName.trim().toLowerCase()
//         )
//     );
// }, [modules, templateName]);

    const addGroup = (sectionId: string) => {
        setSections((current) =>
            current.map((section) => {
                if (section.id !== sectionId) {
                    return section;
                }

                return {
                    ...section,
                    fieldGroups: [...section.fieldGroups, createEmptyGroup()],
                };
            })
        );
    };

    const removeGroup = (sectionId: string, groupId: string) => {
        setSections((current) =>
            current.map((section) => {
                if (section.id !== sectionId) {
                    return section;
                }

                return {
                    ...section,
                    fieldGroups: section.fieldGroups.filter(
                        (group) => group.id !== groupId
                    ),
                };
            })
        );
    };

    const updateGroup = (
        sectionId: string,
        groupId: string,
        updates: Partial<NewFieldGroupDraft>
    ) => {
        setSections((current) =>
            current.map((section) => {
                if (section.id !== sectionId) {
                    return section;
                }

                return {
                    ...section,
                    fieldGroups: section.fieldGroups.map((group) =>
                        group.id === groupId
                            ? { ...group, ...updates }
                            : group
                    ),
                };
            })
        );
    };

    const addField = (sectionId: string, groupId: string) => {
        const newField = createEmptyField();

        setSections((current) =>
            current.map((section) => {
                if (section.id !== sectionId) {
                    return section;
                }

                return {
                    ...section,
                    fieldGroups: section.fieldGroups.map((group) => {
                        if (group.id !== groupId) {
                            return group;
                        }

                        return {
                            ...group,
                            fields: [...group.fields, newField],
                        };
                    }),
                };
            })
        );

        setExpandedFields((current) => [...current, newField.id]);
    };

    const removeField = (
        sectionId: string,
        groupId: string,
        fieldId: string
    ) => {
        setSections((current) =>
            current.map((section) => {
                if (section.id !== sectionId) {
                    return section;
                }

                return {
                    ...section,
                    fieldGroups: section.fieldGroups.map((group) => {
                        if (group.id !== groupId) {
                            return group;
                        }

                        return {
                            ...group,
                            fields: group.fields.filter(
                                (field) => field.id !== fieldId
                            ),
                        };
                    }),
                };
            })
        );

        setExpandedFields((current) =>
            current.filter((id) => id !== fieldId)
        );
    };

    const updateField = (
        sectionId: string,
        groupId: string,
        fieldId: string,
        updates: Partial<NewFieldDraft>
    ) => {
        setSections((current) =>
            current.map((section) => {
                if (section.id !== sectionId) {
                    return section;
                }

                return {
                    ...section,
                    fieldGroups: section.fieldGroups.map((group) => {
                        if (group.id !== groupId) {
                            return group;
                        }

                        return {
                            ...group,
                            fields: group.fields.map((field) =>
                                field.id === fieldId
                                    ? { ...field, ...updates }
                                    : field
                            ),
                        };
                    }),
                };
            })
        );
    };

    const addOption = (
        sectionId: string,
        groupId: string,
        fieldId: string
    ) => {
        const option: NewFieldOption = {
            id: createOptionId(),
            label: "",
            value: "",
        };

        setSections((current) =>
            current.map((section) => {
                if (section.id !== sectionId) {
                    return section;
                }

                return {
                    ...section,
                    fieldGroups: section.fieldGroups.map((group) => {
                        if (group.id !== groupId) {
                            return group;
                        }

                        return {
                            ...group,
                            fields: group.fields.map((field) => {
                                if (field.id !== fieldId) {
                                    return field;
                                }

                                return {
                                    ...field,
                                    options: [...field.options, option],
                                };
                            }),
                        };
                    }),
                };
            })
        );
    };

    const updateOption = (
        sectionId: string,
        groupId: string,
        fieldId: string,
        optionId: string,
        updates: Partial<NewFieldOption>
    ) => {
        setSections((current) =>
            current.map((section) => {
                if (section.id !== sectionId) {
                    return section;
                }

                return {
                    ...section,
                    fieldGroups: section.fieldGroups.map((group) => {
                        if (group.id !== groupId) {
                            return group;
                        }

                        return {
                            ...group,
                            fields: group.fields.map((field) => {
                                if (field.id !== fieldId) {
                                    return field;
                                }

                                return {
                                    ...field,
                                    options: field.options.map((option) =>
                                        option.id === optionId
                                            ? { ...option, ...updates }
                                            : option
                                    ),
                                };
                            }),
                        };
                    }),
                };
            })
        );
    };

    const removeOption = (
        sectionId: string,
        groupId: string,
        fieldId: string,
        optionId: string,
    ) => {
        setSections((current) =>
            current.map((section) => {
                if (section.id !== sectionId) {
                    return section;
                }

                return {
                    ...section,
                    fieldGroups: section.fieldGroups.map((group) => {
                        if (group.id !== groupId) {
                            return group;
                        }

                        return {
                            ...group,
                            fields: group.fields.map((field) =>
                                field.id === fieldId
                                    ? {
                                          ...field,
                                          options: field.options.filter(
                                              (option) =>
                                                  option.id !== optionId
                                          ),
                                      }
                                    : field
                            ),
                        };
                    }),
                };
            })
        );
    };

    const toggleField = (fieldId: string) => {
        setExpandedFields((current) =>
            current.includes(fieldId)
                ? current.filter((id) => id !== fieldId)
                : [...current, fieldId]
        );
    };
    
  const saveModule = () => {
    if (!title.trim()) {
        return;
    }

    const totalFields = sections.reduce(
        (total, section) =>
            total +
            section.fieldGroups.reduce(
                (groupTotal, group) =>
                    groupTotal + group.fields.length,
                0
            ),
        0
    );

    const moduleId =
        editingModule?.id || createId();

    const moduleCode =
        code.trim() ||
        editingModule?.code ||
        `MOD-${Date.now()}`;

const updatedModule: SurveyModule = {
    id: moduleId,
    code: moduleCode,
    zone: zone.trim() || "CUSTOM",
    name: title.trim(),
    description: description.trim(),
    icon: editingModule?.icon || Buildings,
    fields: totalFields,
    repeatable: editingModule?.repeatable || false,
    unitLabel: editingModule?.unitLabel,
    hasConditional: editingModule?.hasConditional || false,
    sections: sections.map((section) => ({
        id: section.id,
        title: section.title.trim(),
        fieldGroups: section.fieldGroups.map((group) => ({
            id: group.id,
            title: group.title.trim(),
            fields: group.fields.map((field) => ({
                id: field.id,
                name: slugify(field.label),
                label: field.label.trim(),
                type: field.type as SurveyField["type"],
                required: field.required,
                placeholder: field.placeholder.trim() || undefined,
                helpText: field.helpText.trim() || undefined,
                options: field.options.map((option) => ({
                    id: option.id,
                    label: option.label.trim(),
                    value: slugify(option.value || option.label),
                })),
            })),
        })),
    })),
};

    if (editingModule) {
        onUpdate(updatedModule);
    } else {
        onCreate(updatedModule);
    }

    resetForm();
    onClose();
};

    // const resetForm = () => {
    //     setTitle("");
    //     setCode("");
    //     setZone("");
    //     setDescription("");
    //     setSections([]);
    //     setExpandedFields([]);
    // };

    const handleClose = () => {
        resetForm();
        onClose();
    };

    if (!open) {
        return null;
    }

    

    return ( <OffCanvas
        isOpen={open}
        onClose={handleClose}
        title={editingModule ? "Edit Module" : "Create Module"}  
        subtitle="Create a completely custom survey structure."
        widthClass="max-w-3xl"
        footer={
            <div className="flex items-center justify-between gap-3">
                <div className="text-xs text-slate-400">
                    {sections.length} section
                    {sections.length !== 1 ? "s" : ""} ·{" "}
                    {sections.reduce(
                        (total, section) =>
                            total + section.fieldGroups.length,
                        0
                    )}{" "}
                    groups
                </div>

                <div className="flex items-center gap-2">
                    <button
                        type="button"
                        onClick={handleClose}
                        className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                    >
                        Cancel
                    </button>

                    <button
                        type="button"
                        onClick={saveModule}
                        disabled={!title.trim()}
                        className="rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                        {editingModule ? "Update Module" : "Create Module"}
                    </button>
                </div> 
            </div>
        } 
    >

 
        <div className="fixed inset-0 z-50">
            <button
                type="button"
                aria-label="Close drawer"
                onClick={handleClose}
                className="absolute inset-0 bg-slate-950/30"
            />

            <aside className="absolute right-0 top-0 flex h-full w-full max-w-3xl flex-col bg-white shadow-2xl">
                <div className="flex shrink-0 items-center justify-between border-b border-slate-200 px-5 py-4">
                    <div>
                        <h2 className="text-base font-semibold text-slate-900">
                            {editingModule
                                ? "Edit Module"
                                : "Create Module"}
                        </h2>

                        <p className="mt-1 text-xs text-slate-500">
                             {editingModule
        ? "Update the existing survey module structure."
        : "Create a completely custom survey structure."}
                        </p>
                    </div>

                   {/* <button
                        type="button"
                        onClick={saveModule}
                        disabled={!title.trim()}
                        className="rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                        {editingModule ? "Update Module" : "Create Module"}
                    </button> */}
                </div>

                <div className="flex-1 overflow-y-auto p-5">
                    <div className="space-y-7">
                        <section>
                            <div className="mb-3">
                                <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                                    Module Details
                                </h3>

                                <p className="mt-1 text-xs text-slate-400">
                                    Define the basic information for this
                                    module.
                                </p>
                            </div>

                            <div className="space-y-4">
                                <div>
                                    <label className="text-xs font-medium text-slate-700">
                                        Module Title
                                    </label>

                                    <input
                                        value={title}
                                        onChange={(e) =>
                                            setTitle(e.target.value)
                                        }
                                        placeholder="e.g. Central Office Inspection"
                                        className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
                                    />
                                </div>

                                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                                    <div>
                                        <label className="text-xs font-medium text-slate-700">
                                            Module Code
                                        </label>

                                        <input
                                            value={code}
                                            onChange={(e) =>
                                                setCode(e.target.value)
                                            }
                                            placeholder="e.g. MOD-07"
                                            className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
                                        />
                                    </div>

                                    <div>
                                        <label className="text-xs font-medium text-slate-700">
                                            Zone
                                        </label>

                                        <input
                                            value={zone}
                                            onChange={(e) =>
                                                setZone(e.target.value)
                                            }
                                            placeholder="e.g. CO"
                                            className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="text-xs font-medium text-slate-700">
                                        Description
                                    </label>

                                    <textarea
                                        value={description}
                                        onChange={(e) =>
                                            setDescription(e.target.value)
                                        }
                                        placeholder="Describe the purpose of this module..."
                                        rows={3}
                                        className="mt-1.5 w-full resize-none rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
                                    />
                                </div>
                            </div>
                        </section>

                        <section>
                            <div className="flex items-start justify-between gap-3">
                                <div>
                                    <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                                        Sections
                                    </h3>

                                    <p className="mt-1 text-xs text-slate-400">
                                        Create your own section names and
                                        structure.
                                    </p>
                                </div>

                                <button
                                    type="button"
                                    onClick={addSection}
                                    className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 transition hover:border-amber-400 hover:text-amber-600"
                                >
                                    <Plus size={13} />
                                    Add Section
                                </button>
                            </div>

                            {sections.length === 0 && (
                                <div className="mt-4 rounded-xl border border-dashed border-slate-300 py-10 text-center">
                                    <p className="text-sm text-slate-500">
                                        No sections created.
                                    </p>

                                    <p className="mt-1 text-xs text-slate-400">
                                        Start by adding a section.
                                    </p>

                                    <button
                                        type="button"
                                        onClick={addSection}
                                        className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-2 text-xs font-medium text-white hover:bg-slate-800"
                                    >
                                        <Plus size={13} />
                                        Add Section
                                    </button>
                                </div>
                            )}

                            <div className="mt-4 space-y-5">
                                {sections.map((section) => (
                                    <div
                                        key={section.id}
                                        className="rounded-xl border border-slate-200 bg-slate-50 p-4"
                                    >
                                        <div className="flex items-start gap-3">
                                            <div className="w-20 shrink-0">
                                                <label className="text-[11px] font-medium text-slate-500">
                                                    Section #
                                                </label>

                                                <input
                                                    value={section.number}
                                                    onChange={(e) =>
                                                        updateSection(
                                                            section.id,
                                                            {
                                                                number: e
                                                                    .target
                                                                    .value,
                                                            }
                                                        )
                                                    }
                                                    className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-sm outline-none focus:border-amber-400"
                                                />
                                            </div>

                                            <div className="min-w-0 flex-1">
                                                <label className="text-[11px] font-medium text-slate-500">
                                                    Section Title
                                                </label>

                                                <input
                                                    value={section.title}
                                                    onChange={(e) =>
                                                        updateSection(
                                                            section.id,
                                                            {
                                                                title: e
                                                                    .target
                                                                    .value,
                                                            }
                                                        )
                                                    }
                                                    placeholder="e.g. General Facility & Environmental Checks"
                                                    className="mt-1.5 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-amber-400"
                                                />
                                            </div>

                                            <button
                                                type="button"
                                                onClick={() =>
                                                    removeSection(section.id)
                                                }
                                                className="mt-5 shrink-0 rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
                                                title="Delete section"
                                            >
                                                <Trash size={15} />
                                            </button>
                                        </div>

                                        <div className="mt-5">
                                            <div className="mb-3 flex items-center justify-between">
                                                <div>
                                                    <div className="text-xs font-semibold text-slate-700">
                                                        Groups / Categories
                                                    </div>

                                                    <div className="mt-0.5 text-[11px] text-slate-400">
                                                        Use any name that
                                                        makes sense for your
                                                        survey.
                                                    </div>
                                                </div>

                                                <button
                                                    type="button"
                                                    onClick={() =>
                                                        addGroup(section.id)
                                                    }
                                                    className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-600 hover:text-amber-700"
                                                >
                                                    <Plus size={13} />
                                                    Add Group
                                                </button>
                                            </div>

                                            {section.fieldGroups.length ===
                                                0 && (
                                                <div className="rounded-lg border border-dashed border-slate-300 bg-white py-7 text-center">
                                                    <p className="text-xs text-slate-400">
                                                        No groups or
                                                        categories yet.
                                                    </p>

                                                    <button
                                                        type="button"
                                                        onClick={() =>
                                                            addGroup(
                                                                section.id
                                                            )
                                                        }
                                                        className="mt-3 text-xs font-medium text-amber-600"
                                                    >
                                                        + Create first group
                                                    </button>
                                                </div>
                                            )}

                                            <div className="space-y-4">
                                                {section.fieldGroups.map(
                                                    (group) => (
                                                        <div
                                                            key={group.id}
                                                            className="rounded-lg border border-slate-200 bg-white p-4"
                                                        >
                                                            <div className="flex items-start gap-2">
                                                                <div className="min-w-0 flex-1">
                                                                    <label className="text-[11px] font-medium text-slate-500">
                                                                        Group
                                                                        /
                                                                        Category
                                                                        Name
                                                                    </label>

                                                                    <input
                                                                        value={group.title}
                                                                        onChange={(e) =>
                                                                            updateGroup(section.id,group.id,
                                                                                {title: e.target.value,})}
                                                                        placeholder="e.g. CO Facility Access & Security"
                                                                        className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none focus:border-amber-400"
                                                                    />
                                                                </div>

                                                                <button
                                                                    type="button"
                                                                    onClick={() => removeGroup(section.id,group.id)}
                                                                    className="mt-5 rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-600"
                                                                    title="Delete group"
                                                                >
                                                                    <Trash size={14} />
                                                                </button>
                                                            </div>

                                                            <div className="mt-4">
                                                                <div className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                                                                    Fields
                                                                </div>

                                                                <div className="space-y-2">
                                                                    {group.fields.map(
                                                                        (field, fieldIndex ) => {
                                                                            const isExpanded = expandedFields.includes(field.id);
                                                                            const supportsOptions = 
                                                                                field.type ===
                                                                                    "radio" ||
                                                                                field.type ===
                                                                                    "select" ||
                                                                                field.type ===
                                                                                    "checkbox_group";

                                                                            return (
                                                                                <div
                                                                                    key={
                                                                                        field.id
                                                                                    }
                                                                                    className="overflow-hidden rounded-lg border border-slate-200"
                                                                                >
                                                                                    <div className="flex items-center gap-2 bg-slate-50 px-3 py-2.5">
                                                                                        <span className="w-5 shrink-0 text-center font-mono text-[10px] text-slate-400">
                                                                                            {fieldIndex +
                                                                                                1}
                                                                                        </span>

                                                                                        <input
                                                                                            value={
                                                                                                field.label
                                                                                            }
                                                                                            onChange={(
                                                                                                e
                                                                                            ) =>
                                                                                                updateField(
                                                                                                    section.id,
                                                                                                    group.id,
                                                                                                    field.id,
                                                                                                    {
                                                                                                        label: e
                                                                                                            .target
                                                                                                            .value,
                                                                                                    }
                                                                                                )
                                                                                            }
                                                                                            placeholder="Enter field name"
                                                                                            className="min-w-0 flex-1 rounded-md border border-slate-300 bg-white px-2.5 py-2 text-xs outline-none focus:border-amber-400"
                                                                                        />

                                                                                        <span className="hidden shrink-0 rounded-md bg-slate-100 px-2 py-1 text-[10px] text-slate-500 sm:inline">
                                                                                            {
                                                                                                field.type
                                                                                            }
                                                                                        </span>

                                                                                        <button
                                                                                            type="button"
                                                                                            onClick={() =>
                                                                                                toggleField(
                                                                                                    field.id
                                                                                                )
                                                                                            }
                                                                                            className="rounded-md p-1.5 text-slate-400 hover:bg-white hover:text-slate-700"
                                                                                        >
                                                                                            {isExpanded ? (
                                                                                                <CaretUp
                                                                                                    size={
                                                                                                        14
                                                                                                    }
                                                                                                />
                                                                                            ) : (
                                                                                                <CaretDown
                                                                                                    size={
                                                                                                        14
                                                                                                    }
                                                                                                />
                                                                                            )}
                                                                                        </button>

                                                                                        <button
                                                                                            type="button"
                                                                                            onClick={() =>
                                                                                                removeField(
                                                                                                    section.id,
                                                                                                    group.id,
                                                                                                    field.id
                                                                                                )
                                                                                            }
                                                                                            className="rounded-md p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600"
                                                                                        >
                                                                                            <Trash
                                                                                                size={
                                                                                                    13
                                                                                                }
                                                                                            />
                                                                                        </button>
                                                                                    </div>

                                                                                    {isExpanded && (
                                                                                        <div className="space-y-4 border-t border-slate-200 bg-white p-3">
                                                                                            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                                                                                                <div>
                                                                                                    <label className="text-[11px] font-medium text-slate-500">
                                                                                                        Field
                                                                                                        Type
                                                                                                    </label>

                                                                                                    <select
                                                                                                        value={
                                                                                                            field.type
                                                                                                        }
                                                                                                        onChange={(
                                                                                                            e
                                                                                                        ) =>
                                                                                                            updateField(
                                                                                                                section.id,
                                                                                                                group.id,
                                                                                                                field.id,
                                                                                                                {
                                                                                                                    type: e
                                                                                                                        .target
                                                                                                                        .value as SurveyFieldType,

                                                                                                                    options:
                                                                                                                        e
                                                                                                                            .target
                                                                                                                            .value ===
                                                                                                                            "radio" ||
                                                                                                                        e
                                                                                                                            .target
                                                                                                                            .value ===
                                                                                                                            "select" ||
                                                                                                                        e
                                                                                                                            .target
                                                                                                                            .value ===
                                                                                                                            "checkbox_group"
                                                                                                                            ? field.options
                                                                                                                            : [],
                                                                                                                }
                                                                                                            )
                                                                                                        }
                                                                                                        className="mt-1.5 w-full rounded-lg border border-slate-300 px-2.5 py-2 text-xs outline-none focus:border-amber-400"
                                                                                                    >
                                                                                                        <option value="text">
                                                                                                            Text
                                                                                                        </option>

                                                                                                        <option value="number">
                                                                                                            Number
                                                                                                        </option>

                                                                                                        <option value="radio">
                                                                                                            Radio
                                                                                                        </option>

                                                                                                        <option value="select">
                                                                                                            Dropdown
                                                                                                        </option>

                                                                                                        <option value="textarea">
                                                                                                            Long
                                                                                                            Text
                                                                                                        </option>

                                                                                                        <option value="checkbox_group">
                                                                                                            Checkbox
                                                                                                            Group
                                                                                                        </option>
                                                                                                    </select>
                                                                                                </div>

                                                                                                <div className="flex items-end">
                                                                                                    <label className="flex h-9 cursor-pointer items-center gap-2 text-xs text-slate-600">
                                                                                                        <input
                                                                                                            type="checkbox"
                                                                                                            checked={
                                                                                                                field.required
                                                                                                            }
                                                                                                            onChange={(
                                                                                                                e
                                                                                                            ) =>
                                                                                                                updateField(
                                                                                                                    section.id,
                                                                                                                    group.id,
                                                                                                                    field.id,
                                                                                                                    {
                                                                                                                        required:
                                                                                                                            e
                                                                                                                                .target
                                                                                                                                .checked,
                                                                                                                    }
                                                                                                                )
                                                                                                            }
                                                                                                            className="h-4 w-4 rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                                                                                                        />

                                                                                                        Required
                                                                                                    </label>
                                                                                                </div>
                                                                                            </div>

                                                                                            <div>
                                                                                                <label className="text-[11px] font-medium text-slate-500">
                                                                                                    Placeholder
                                                                                                </label>

                                                                                                <input
                                                                                                    value={
                                                                                                        field.placeholder
                                                                                                    }
                                                                                                    onChange={(
                                                                                                        e
                                                                                                    ) =>
                                                                                                        updateField(
                                                                                                            section.id,
                                                                                                            group.id,
                                                                                                            field.id,
                                                                                                            {
                                                                                                                placeholder:
                                                                                                                    e
                                                                                                                        .target
                                                                                                                        .value,
                                                                                                            }
                                                                                                        )
                                                                                                    }
                                                                                                    placeholder="Optional placeholder..."
                                                                                                    className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-xs outline-none focus:border-amber-400"
                                                                                                />
                                                                                            </div>

                                                                                            <div>
                                                                                                <label className="text-[11px] font-medium text-slate-500">
                                                                                                    Help
                                                                                                    Text
                                                                                                </label>

                                                                                                <input
                                                                                                    value={
                                                                                                        field.helpText
                                                                                                    }
                                                                                                    onChange={(
                                                                                                        e
                                                                                                    ) =>
                                                                                                        updateField(
                                                                                                            section.id,
                                                                                                            group.id,
                                                                                                            field.id,
                                                                                                            {
                                                                                                                helpText:
                                                                                                                    e
                                                                                                                        .target
                                                                                                                        .value,
                                                                                                            }
                                                                                                        )
                                                                                                    }
                                                                                                    placeholder="Optional instruction for the technician..."
                                                                                                    className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2 text-xs outline-none focus:border-amber-400"
                                                                                                />
                                                                                            </div>

                                                                                            {supportsOptions && (
                                                                                                <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                                                                                                    <div className="flex items-center justify-between">
                                                                                                        <div>
                                                                                                            <div className="text-xs font-medium text-slate-700">
                                                                                                                Options
                                                                                                            </div>

                                                                                                            <div className="mt-0.5 text-[10px] text-slate-400">
                                                                                                                Define
                                                                                                                the
                                                                                                                choices
                                                                                                                available
                                                                                                                to
                                                                                                                the
                                                                                                                technician.
                                                                                                            </div>
                                                                                                        </div>

                                                                                                        <button
                                                                                                            type="button"
                                                                                                            onClick={() =>
                                                                                                                addOption(
                                                                                                                    section.id,
                                                                                                                    group.id,
                                                                                                                    field.id
                                                                                                                )
                                                                                                            }
                                                                                                            className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-600 hover:text-amber-700"
                                                                                                        >
                                                                                                            <Plus
                                                                                                                size={
                                                                                                                    12
                                                                                                                }
                                                                                                            />
                                                                                                            Add
                                                                                                            Option
                                                                                                        </button>
                                                                                                    </div>

                                                                                                    {field
                                                                                                        .options
                                                                                                        .length ===
                                                                                                        0 && (
                                                                                                        <div className="mt-3 rounded-md border border-dashed border-slate-300 py-3 text-center text-[11px] text-slate-400">
                                                                                                            No
                                                                                                            options
                                                                                                            added
                                                                                                            yet.
                                                                                                        </div>
                                                                                                    )}

                                                                                                    <div className="mt-3 space-y-2">
                                                                                                        {field.options.map(
                                                                                                            (
                                                                                                                option
                                                                                                            ) => (
                                                                                                                <div
                                                                                                                    key={
                                                                                                                        option.id
                                                                                                                    }
                                                                                                                    className="flex items-center gap-2"
                                                                                                                >
                                                                                                                    <input
                                                                                                                        value={
                                                                                                                            option.label
                                                                                                                        }
                                                                                                                        onChange={(
                                                                                                                            e
                                                                                                                        ) =>
                                                                                                                            updateOption(
                                                                                                                                section.id,
                                                                                                                                group.id,
                                                                                                                                field.id,
                                                                                                                                option.id,
                                                                                                                                {
                                                                                                                                    label: e
                                                                                                                                        .target
                                                                                                                                        .value,
                                                                                                                                }
                                                                                                                            )
                                                                                                                        }
                                                                                                                        placeholder="Option label"
                                                                                                                        className="min-w-0 flex-1 rounded-md border border-slate-300 px-2.5 py-2 text-xs"
                                                                                                                    />

                                                                                                                    <input
                                                                                                                        value={
                                                                                                                            option.value
                                                                                                                        }
                                                                                                                        onChange={(
                                                                                                                            e
                                                                                                                        ) =>
                                                                                                                            updateOption(
                                                                                                                                section.id,
                                                                                                                                group.id,
                                                                                                                                field.id,
                                                                                                                                option.id,
                                                                                                                                {
                                                                                                                                    value: e
                                                                                                                                        .target
                                                                                                                                        .value,
                                                                                                                                }
                                                                                                                            )
                                                                                                                        }
                                                                                                                        placeholder="Value"
                                                                                                                        className="w-28 rounded-md border border-slate-300 px-2.5 py-2 text-xs"
                                                                                                                    />

                                                                                                                    <button
                                                                                                                        type="button"
                                                                                                                        onClick={() =>
                                                                                                                            removeOption(
                                                                                                                                section.id,
                                                                                                                                group.id,
                                                                                                                                field.id,
                                                                                                                                option.id
                                                                                                                            )
                                                                                                                        }
                                                                                                                        className="rounded-md p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600"
                                                                                                                    >
                                                                                                                        <Trash
                                                                                                                            size={
                                                                                                                                13
                                                                                                                            }
                                                                                                                        />
                                                                                                                    </button>
                                                                                                                </div>
                                                                                                            )
                                                                                                        )}
                                                                                                    </div>
                                                                                                </div>
                                                                                            )}
                                                                                        </div>
                                                                                    )}
                                                                                </div>
                                                                            );
                                                                        }
                                                                    )}
                                                                </div>

                                                                <button
                                                                    type="button"
                                                                    onClick={() =>
                                                                        addField(
                                                                            section.id,
                                                                            group.id
                                                                        )
                                                                    }
                                                                    className="mt-3 inline-flex items-center gap-1.5 text-xs font-medium text-amber-600 hover:text-amber-700"
                                                                >
                                                                    <Plus
                                                                        size={
                                                                            13
                                                                        }
                                                                    />
                                                                    Add Field
                                                                </button>
                                                            </div>
                                                        </div>
                                                    )
                                                )}
                                            </div>

                                            <button
                                                type="button"
                                                onClick={() =>
                                                    addGroup(section.id)
                                                }
                                                className="mt-4 w-full rounded-lg border border-dashed border-slate-300 py-2.5 text-xs font-medium text-slate-500 transition hover:border-amber-400 hover:text-amber-600"
                                            >
                                                <Plus
                                                    size={13}
                                                    className="mr-1 inline"
                                                />
                                                Add Group / Category
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>
                    </div>
                </div>

                <div className="flex shrink-0 items-center justify-between gap-3 border-t border-slate-200 bg-white px-5 py-4">
                    <div className="text-xs text-slate-400">
                        {sections.length} section
                        {sections.length !== 1 ? "s" : ""} ·{" "}
                        {sections.reduce(
                            (total, section) =>
                                total + section.fieldGroups.length,
                            0
                        )}{" "}
                        groups
                    </div>

                    <div className="flex items-center gap-2">
                        <button
                            type="button"
                            onClick={handleClose}
                            className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={saveModule}
                            disabled={!title.trim()}
                            className="rounded-lg bg-red-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                             {editingModule ? "Update Module" : "Create Module"}
                        </button>
                    </div>
                </div>
            </aside>
        </div>
           </OffCanvas>
    );
    
}