import { useEffect, useState } from "react";
import TermsConditionModal from "../components/TermsConditionModal";
import UnderDevelopment from "./UnderDevelopment";
import Summary from "../components/admin_dashboard/summary";


const Dashboard = () => {
    const [showTermsModal, setShowTermsModal] = useState(false);
    const [termsAccepted, setTermsAccepted] = useState(false);

    useEffect(() => {
        const accepted = localStorage.getItem(
            "terms_conditions_accepted"
        );

        if (accepted === "true") {
            setTermsAccepted(true);
        } else {
            setShowTermsModal(true);
        }
    }, []);

    const handleAcceptTerms = () => {
        localStorage.setItem(
            "terms_conditions_accepted",
            "true"
        );

        setTermsAccepted(true);
        setShowTermsModal(false);
    };

    return (
        <>
            {termsAccepted && <Summary />}

            <TermsConditionModal
                open={showTermsModal}
                onAccept={handleAcceptTerms}
            />
        </>
    );
};

export default Dashboard;