import {
    useCallback,
    useEffect,
    useState,
} from "react";

import {
    CheckCircleIcon,
    SpinnerGapIcon,
    WarningCircleIcon,
    XCircleIcon,
} from "@phosphor-icons/react";

import RichTextEditor from "../../components/RichTextEditor";
import api from "../../api/axios";

/*
|--------------------------------------------------------------------------
| Types
|--------------------------------------------------------------------------
*/

interface TermsConditionData {
    id?: string;
    title: string;
    content: string;
    status?: boolean;
    sortOrder?: number;
    createdAt?: string | null;
    updatedAt?: string | null;
}

interface ApiResponse<T = unknown> {
    success?: boolean;
    message?: string;
    data?: T;
}

/*
|--------------------------------------------------------------------------
| Constants
|--------------------------------------------------------------------------
*/

const COMMON_ENDPOINT =
    "/settings/common";

const SETTING_TYPE =
    "terms_condition";

/*
|--------------------------------------------------------------------------
| Default Content
|--------------------------------------------------------------------------
|
| Preserved from the existing UI exactly as the initial fallback.
|
|--------------------------------------------------------------------------
*/

const DEFAULT_TITLE =
    "Default Terms & Conditions";

const DEFAULT_CONTENT = `
        <h2>Terms & Conditions</h2>

<p>
    These Terms & Conditions apply to all quotations, proposals, commercial
    offers and vendor offers issued through the company. By accepting a
    quotation, purchase order or service proposal, the customer or vendor
    agrees to comply with these Terms & Conditions together with any
    applicable contract, service agreement or SLA.
</p>

<h3>1. Quotation Validity</h3>

<p>
    All quotations are valid only for the period specified in the quotation.
    After the expiry of the validity period, prices, availability, delivery
    schedules and other commercial terms may be subject to change.
</p>

<h3>2. Pricing and Taxes</h3>

<p>
    All prices stated in the quotation are based on the information and
    requirements available at the time of preparation. Applicable taxes,
    duties, government charges, regulatory fees, shipping, installation and
    other additional charges will be applied as required unless specifically
    stated otherwise in the quotation.
</p>

<h3>3. Product and Service Availability</h3>

<p>
    All equipment, materials, connectivity services and other telecom
    services are subject to availability. Product specifications, models,
    manufacturers and delivery schedules may be subject to change due to
    supplier availability, manufacturing constraints or other circumstances
    beyond the company's reasonable control.
</p>
`;

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getErrorMessage(
    error: unknown,
    fallback: string,
): string {
    const axiosError =
        error as {
            response?: {
                data?: {
                    message?: string;
                    error?: string;
                };
            };
            message?: string;
        };

    return (
        axiosError?.response?.data
            ?.message ||
        axiosError?.response?.data
            ?.error ||
        axiosError?.message ||
        fallback
    );
}

function normalizeTermsCondition(
    value: unknown,
): TermsConditionData | null {
    if (
        !value ||
        typeof value !== "object"
    ) {
        return null;
    }

    const item =
        value as Record<
            string,
            unknown
        >;

    const id =
        String(
            item.id ??
                item._id ??
                "",
        ).trim();

    const title =
        String(
            item.title ??
                "",
        );

    const content =
        String(
            item.content ??
                "",
        );

    if (!id && !title) {
        return null;
    }

    return {
        id:
            id || undefined,

        title,

        content,

        status:
            item.status ===
            undefined
                ? true
                : Boolean(
                      item.status,
                  ),

        sortOrder:
            typeof item.sortOrder ===
            "number"
                ? item.sortOrder
                : undefined,

        createdAt:
            item.createdAt
                ? String(
                      item.createdAt,
                  )
                : null,

        updatedAt:
            item.updatedAt
                ? String(
                      item.updatedAt,
                  )
                : null,
    };
}

function extractTermsCondition(
    response: ApiResponse<
        TermsConditionData[]
        | TermsConditionData
    >,
): TermsConditionData | null {
    const data =
        response?.data;

    /*
     * Current backend returns an array for the common-settings list.
     */
    if (
        Array.isArray(data)
    ) {
        return (
            data
                .map(
                    normalizeTermsCondition,
                )
                .filter(
                    (
                        item,
                    ): item is TermsConditionData =>
                        item !== null,
                )
                .find(
                    (
                        item,
                    ) =>
                        item.status !==
                            false,
                ) ||
            data
                .map(
                    normalizeTermsCondition,
                )
                .find(
                    (
                        item,
                    ): item is TermsConditionData =>
                        item !== null,
                ) ||
            null
        );
    }

    return normalizeTermsCondition(
        data,
    );
}

function hasEditorContent(
    html: string,
): boolean {
    if (
        typeof html !==
        "string"
    ) {
        return false;
    }

    const tempDiv =
        document.createElement(
            "div",
        );

    tempDiv.innerHTML =
        html;

    return Boolean(
        tempDiv.textContent?.trim(),
    );
}

/*
|--------------------------------------------------------------------------
| Component
|--------------------------------------------------------------------------
*/

const TermsCondition =
    () => {
        const [
            title,
            setTitle,
        ] = useState(
            DEFAULT_TITLE,
        );

        const [
            content,
            setContent,
        ] = useState(
            DEFAULT_CONTENT,
        );

        const [
            recordId,
            setRecordId,
        ] = useState<
            string | null
        >(null);

        const [
            loading,
            setLoading,
        ] = useState(true);

        const [
            saving,
            setSaving,
        ] = useState(false);

        const [
            error,
            setError,
        ] = useState("");

        const [
            pageError,
            setPageError,
        ] = useState("");

        const [
            successMessage,
            setSuccessMessage,
        ] = useState("");

        /*
        |--------------------------------------------------------------------------
        | Load
        |--------------------------------------------------------------------------
        */

        const loadTermsCondition =
            useCallback(
                async () => {
                    setLoading(
                        true,
                    );

                    setPageError(
                        "",
                    );

                    try {
                        const response =
                            await api.get<
                                ApiResponse<
                                    TermsConditionData[]
                                >
                            >(
                                COMMON_ENDPOINT,
                                {
                                    params: {
                                        type:
                                            SETTING_TYPE,
                                        page: 1,
                                        limit: 100,
                                    },
                                },
                            );

                        const record =
                            extractTermsCondition(
                                response.data,
                            );

                        if (
                            record
                        ) {
                            setRecordId(
                                record.id ||
                                    null,
                            );

                            setTitle(
                                record.title ||
                                    DEFAULT_TITLE,
                            );

                            setContent(
                                record.content ||
                                    "",
                            );
                        } else {
                            /*
                             * No backend record yet.
                             *
                             * Preserve the current UI's initial
                             * default content so the screen remains
                             * useful before the first save.
                             */
                            setRecordId(
                                null,
                            );

                            setTitle(
                                DEFAULT_TITLE,
                            );

                            setContent(
                                DEFAULT_CONTENT,
                            );
                        }
                    } catch (loadError) {
                        const message =
                            getErrorMessage(
                                loadError,
                                "Unable to load Terms & Conditions.",
                            );

                        setPageError(
                            message,
                        );
                    } finally {
                        setLoading(
                            false,
                        );
                    }
                },
                [],
            );

        /*
        |--------------------------------------------------------------------------
        | Initial Load
        |--------------------------------------------------------------------------
        */

        useEffect(() => {
            void loadTermsCondition();
        }, [
            loadTermsCondition,
        ]);

        /*
        |--------------------------------------------------------------------------
        | Clear Messages
        |--------------------------------------------------------------------------
        */

        useEffect(() => {
            if (
                !successMessage
            ) {
                return;
            }

            const timeout =
                window.setTimeout(
                    () => {
                        setSuccessMessage(
                            "",
                        );
                    },
                    3500,
                );

            return () =>
                window.clearTimeout(
                    timeout,
                );
        }, [
            successMessage,
        ]);

        /*
        |--------------------------------------------------------------------------
        | Save
        |--------------------------------------------------------------------------
        */

        const handleSave =
            useCallback(
                async () => {
                    /*
                     * Validate title.
                     */
                    if (
                        !title.trim()
                    ) {
                        setError(
                            "Terms & Conditions title is required.",
                        );

                        return;
                    }

                    /*
                     * Validate editor content.
                     */
                    if (
                        !hasEditorContent(
                            content,
                        )
                    ) {
                        setError(
                            "Terms & Conditions content is required.",
                        );

                        return;
                    }

                    if (
                        saving
                    ) {
                        return;
                    }

                    setError(
                        "",
                    );

                    setSuccessMessage(
                        "",
                    );

                    setSaving(
                        true,
                    );

                    try {
                        const payload =
                            {
                                title:
                                    title.trim(),

                                content:
                                    content,
                            };

                        /*
                         * Existing record -> PATCH.
                         */
                        if (
                            recordId
                        ) {
                            const response =
                                await api.patch<
                                    ApiResponse<TermsConditionData>
                                >(
                                    `${COMMON_ENDPOINT}/${encodeURIComponent(
                                        recordId,
                                    )}`,
                                    payload,
                                    {
                                        params: {
                                            type:
                                                SETTING_TYPE,
                                        },
                                    },
                                );

                            const updated =
                                normalizeTermsCondition(
                                    response
                                        .data
                                        ?.data,
                                );

                            if (
                                updated
                            ) {
                                setRecordId(
                                    updated.id ||
                                        recordId,
                                );

                                setTitle(
                                    updated.title,
                                );

                                setContent(
                                    updated.content,
                                );
                            }

                            setSuccessMessage(
                                response
                                    .data
                                    ?.message ||
                                    "Terms & Conditions saved successfully.",
                            );

                            return;
                        }

                        /*
                         * No record yet -> POST.
                         */
                        const response =
                            await api.post<
                                ApiResponse<TermsConditionData>
                            >(
                                COMMON_ENDPOINT,
                                payload,
                                {
                                    params: {
                                        type:
                                            SETTING_TYPE,
                                    },
                                },
                            );

                        const created =
                            normalizeTermsCondition(
                                response
                                    .data
                                    ?.data,
                            );

                        if (
                            created
                        ) {
                            setRecordId(
                                created.id ||
                                    null,
                            );

                            setTitle(
                                created.title,
                            );

                            setContent(
                                created.content,
                            );
                        } else {
                            /*
                             * Backend may return no created
                             * document. Reload to resolve the
                             * canonical record ID.
                             */
                            await loadTermsCondition();
                        }

                        setSuccessMessage(
                            response
                                .data
                                ?.message ||
                                "Terms & Conditions saved successfully.",
                        );
                    } catch (saveError) {
                        setError(
                            getErrorMessage(
                                saveError,
                                "Unable to save Terms & Conditions.",
                            ),
                        );
                    } finally {
                        setSaving(
                            false,
                        );
                    }
                },
                [
                    content,
                    loadTermsCondition,
                    recordId,
                    saving,
                    title,
                ],
            );

        /*
        |--------------------------------------------------------------------------
        | Clear
        |--------------------------------------------------------------------------
        |
        | Preserve the existing UI behavior:
        | only the editor content is cleared.
        |
        |--------------------------------------------------------------------------
        */

        const handleClear =
            useCallback(() => {
                if (
                    saving
                ) {
                    return;
                }

                setContent(
                    "",
                );

                setError(
                    "",
                );

                setSuccessMessage(
                    "",
                );
            }, [
                saving,
            ]);

        /*
        |--------------------------------------------------------------------------
        | Title Change
        |--------------------------------------------------------------------------
        */

        const handleTitleChange =
            useCallback(
                (
                    value: string,
                ) => {
                    setTitle(
                        value,
                    );

                    if (
                        error
                    ) {
                        setError(
                            "",
                        );
                    }
                },
                [error],
            );

        /*
        |--------------------------------------------------------------------------
        | Content Change
        |--------------------------------------------------------------------------
        */

        const handleContentChange =
            useCallback(
                (
                    value: string,
                ) => {
                    setContent(
                        value,
                    );

                    if (
                        error
                    ) {
                        setError(
                            "",
                        );
                    }
                },
                [error],
            );

        /*
        |--------------------------------------------------------------------------
        | Render
        |--------------------------------------------------------------------------
        */

        return (
            <div className="space-y-4">
                {/* ================================= */}
                {/* Header */}
                {/* ================================= */}

                <div className="flex flex-col gap-2 border-b border-slate-200 pb-2 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <h2 className="text-lg font-bold text-slate-900">
                            Terms &
                            Conditions
                        </h2>

                        <p className="mt-1 text-xs text-slate-500">
                            Manage the
                            terms and
                            conditions
                            available
                            for
                            quotations
                            and vendor
                            offers.
                        </p>
                    </div>
                </div>

                {/* ================================= */}
                {/* Status Messages */}
                {/* ================================= */}

                {pageError && (
                    <div className="flex items-start justify-between gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
                        <div className="flex items-start gap-3">
                            <WarningCircleIcon
                                size={
                                    18
                                }
                                weight="duotone"
                                className="mt-0.5 shrink-0 text-red-600"
                            />

                            <div>
                                <p className="text-xs font-bold text-red-700">
                                    Unable
                                    to load
                                    Terms &
                                    Conditions
                                </p>

                                <p className="mt-1 text-[11px] leading-5 text-red-600">
                                    {
                                        pageError
                                    }
                                </p>
                            </div>
                        </div>

                        <button
                            type="button"
                            onClick={() =>
                                void loadTermsCondition()
                            }
                            disabled={
                                loading
                            }
                            className="rounded-lg border border-red-200 bg-white px-3 py-2 text-xs font-bold text-red-700 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            Retry
                        </button>
                    </div>
                )}

                {successMessage && (
                    <div className="flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3">
                        <CheckCircleIcon
                            size={
                                18
                            }
                            weight="duotone"
                            className="mt-0.5 shrink-0 text-emerald-600"
                        />

                        <p className="text-xs font-semibold text-emerald-700">
                            {
                                successMessage
                            }
                        </p>
                    </div>
                )}

                {/* ================================= */}
                {/* Main Card */}
                {/* ================================= */}

                <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
                    {/* Loading */}

                    {loading ? (
                        <div className="flex min-h-[320px] items-center justify-center">
                            <div className="flex flex-col items-center gap-3">
                                <SpinnerGapIcon
                                    size={
                                        26
                                    }
                                    weight="bold"
                                    className="animate-spin text-red-600"
                                />

                                <p className="text-xs font-semibold text-slate-500">
                                    Loading
                                    Terms &
                                    Conditions...
                                </p>
                            </div>
                        </div>
                    ) : (
                        <>
                            {/* ================================= */}
                            {/* Title */}
                            {/* ================================= */}

                            <div className="mb-5">
                                <label
                                    htmlFor="terms-title"
                                    className="mb-1.5 block text-xs font-semibold text-slate-700"
                                >
                                    Title

                                    <span className="ml-1 text-red-500">
                                        *
                                    </span>
                                </label>

                                <input
                                    id="terms-title"
                                    type="text"
                                    value={
                                        title
                                    }
                                    onChange={(
                                        event,
                                    ) =>
                                        handleTitleChange(
                                            event
                                                .target
                                                .value,
                                        )
                                    }
                                    maxLength={
                                        250
                                    }
                                    disabled={
                                        saving
                                    }
                                    placeholder="e.g. Standard Terms & Conditions"
                                    className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 disabled:cursor-not-allowed disabled:bg-slate-100 ${
                                        error &&
                                        !title.trim()
                                            ? "border-red-300 focus:border-red-400"
                                            : "border-slate-200 focus:border-red-300"
                                    }`}
                                />

                                <div className="mt-1 flex justify-end">
                                    <span className="text-[10px] font-medium text-slate-400">
                                        {
                                            title.length
                                        }
                                        /
                                        250
                                    </span>
                                </div>
                            </div>

                            {/* ================================= */}
                            {/* Editor */}
                            {/* ================================= */}

                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Terms &
                                    Conditions

                                    <span className="ml-1 text-red-500">
                                        *
                                    </span>
                                </label>

                                <div
                                    className={
                                        error &&
                                        !hasEditorContent(
                                            content,
                                        )
                                            ? "rounded-lg ring-1 ring-red-300"
                                            : ""
                                    }
                                >
                                    <RichTextEditor
                                        value={
                                            content
                                        }
                                        onChange={
                                            handleContentChange
                                        }
                                    />
                                </div>

                                {error && (
                                    <div className="mt-1.5 flex items-start gap-1.5">
                                        <XCircleIcon
                                            size={
                                                13
                                            }
                                            weight="duotone"
                                            className="mt-0.5 shrink-0 text-red-500"
                                        />

                                        <p className="text-[10px] font-medium text-red-500">
                                            {
                                                error
                                            }
                                        </p>
                                    </div>
                                )}
                            </div>

                            {/* ================================= */}
                            {/* Actions */}
                            {/* ================================= */}

                            <div className="mt-5 flex flex-col-reverse gap-2 border-t border-slate-200 pt-4 sm:flex-row sm:items-center sm:justify-end">
                                <button
                                    type="button"
                                    onClick={
                                        handleClear
                                    }
                                    disabled={
                                        saving
                                    }
                                    className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
                                >
                                    Clear
                                </button>

                                <button
                                    type="button"
                                    onClick={() =>
                                        void handleSave()
                                    }
                                    disabled={
                                        saving
                                    }
                                    className="inline-flex min-w-[190px] items-center justify-center gap-2 rounded-lg bg-red-600 px-5 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                                >
                                    {saving ? (
                                        <>
                                            <SpinnerGapIcon
                                                size={
                                                    15
                                                }
                                                weight="bold"
                                                className="animate-spin"
                                            />

                                            Saving...
                                        </>
                                    ) : (
                                        <>
                                            <CheckCircleIcon
                                                size={
                                                    15
                                                }
                                                weight="bold"
                                            />

                                            Save Terms &
                                            Conditions
                                        </>
                                    )}
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        );
    };

export default TermsCondition;