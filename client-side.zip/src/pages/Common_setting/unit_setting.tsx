import {
    useCallback,
    useEffect,
    useState,
} from "react";
import {
    ArrowsOutIcon,
    PencilSimpleIcon,
    PlusIcon,
    TrashIcon,
} from "@phosphor-icons/react";

import ToggleSwitch from "../../components/ToggleSwitch";
import DataTable, { DataTableColumn } from "../../components/DataTable";
import api from "../../api/axios";

export interface Unit {
    id: string;
    name: string;
    description: string;
    status: boolean;
    sortOrder?: number;
    createdAt?: string | null;
    updatedAt?: string | null;
}

interface UnitFormData {
    name: string;
    description: string;
}

interface UnitErrors {
    name?: string;
    description?: string;
}

interface ApiResponse<T = unknown> {
    success?: boolean;
    message?: string;
    data?: T;
    pagination?: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
}

interface DeleteResult {
    id: string;
    deleted: boolean;
}

const COMMON_ENDPOINT = "/settings/common";
const SETTING_TYPE = "unit";

const emptyForm: UnitFormData = {
    name: "",
    description: "",
};

function getErrorMessage(error: unknown, fallback: string): string {
    const axiosError = error as {
        response?: {
            data?: {
                message?: string;
                error?: string;
            };
        };
        message?: string;
    };

    return (
        axiosError?.response?.data?.message ||
        axiosError?.response?.data?.error ||
        axiosError?.message ||
        fallback
    );
}

function normalizeUnit(value: unknown): Unit | null {
    if (!value || typeof value !== "object") {
        return null;
    }

    const item = value as Record<string, unknown>;
    const id = String(item.id ?? item._id ?? "").trim();

    if (!id) {
        return null;
    }

    return {
        id,
        name: String(item.name ?? ""),
        description: String(item.description ?? ""),
        status: Boolean(item.status),
        sortOrder: typeof item.sortOrder === "number" ? item.sortOrder : undefined,
        createdAt: item.createdAt ? String(item.createdAt) : null,
        updatedAt: item.updatedAt ? String(item.updatedAt) : null,
    };
}

function extractUnits(response: ApiResponse<Unit[]>): Unit[] {
    const source = Array.isArray(response?.data) ? response.data : [];

    return source
        .map(normalizeUnit)
        .filter((item): item is Unit => item !== null);
}

export default function UnitSetting() {
    const [units, setUnits] = useState<Unit[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [editingUnit, setEditingUnit] = useState<Unit | null>(null);
    const [formData, setFormData] = useState<UnitFormData>(emptyForm);
    const [deleteUnit, setDeleteUnit] = useState<Unit | null>(null);
    const [errors, setErrors] = useState<UnitErrors>({});

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [deleting, setDeleting] = useState(false);
    const [togglingId, setTogglingId] = useState<string | null>(null);
    const [pageError, setPageError] = useState("");

    const loadUnits = useCallback(async () => {
        setLoading(true);
        setPageError("");

        try {
            const response = await api.get<ApiResponse<Unit[]>>(COMMON_ENDPOINT, {
                params: {
                    type: SETTING_TYPE,
                    page: 1,
                    limit: 100,
                },
            });

            setUnits(extractUnits(response.data));
        } catch (error) {
            const message = getErrorMessage(error, "Unable to load units.");
            setUnits([]);
            setPageError(message);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        void loadUnits();
    }, [loadUnits]);

    const openAddForm = useCallback(() => {
        setEditingUnit(null);
        setFormData({ ...emptyForm });
        setErrors({});
        setPageError("");
        setShowForm(true);
    }, []);

    const openEditForm = useCallback((unit: Unit) => {
        setEditingUnit(unit);
        setFormData({
            name: unit.name,
            description: unit.description,
        });
        setErrors({});
        setPageError("");
        setShowForm(true);
    }, []);

    const closeForm = useCallback(() => {
        if (saving) return;

        setShowForm(false);
        setEditingUnit(null);
        setFormData({ ...emptyForm });
        setErrors({});
    }, [saving]);

    const validateForm = useCallback(() => {
        const nextErrors: UnitErrors = {};
        const name = formData.name.trim();
        const description = formData.description.trim();

        if (!name) {
            nextErrors.name = "Unit name is required.";
        } else if (name.length > 100) {
            nextErrors.name = "Unit name cannot exceed 100 characters.";
        }

        if (!description) {
            nextErrors.description = "Description is required.";
        } else if (description.length > 1000) {
            nextErrors.description = "Description cannot exceed 1000 characters.";
        }

        const duplicateUnit = units.some(
            (unit) =>
                unit.name.trim().toLowerCase() === name.toLowerCase() &&
                unit.id !== editingUnit?.id,
        );

        if (duplicateUnit) {
            nextErrors.name = "A unit with this name already exists.";
        }

        setErrors(nextErrors);
        return Object.keys(nextErrors).length === 0;
    }, [editingUnit, formData, units]);

    const handleSave = useCallback(async () => {
        if (saving || !validateForm()) return;

        setSaving(true);
        setPageError("");

        try {
            const payload = {
                name: formData.name.trim(),
                description: formData.description.trim(),
                ...(editingUnit ? {} : { status: true }),
            };

            if (editingUnit) {
                const response = await api.patch<ApiResponse<Unit>>(
                    `${COMMON_ENDPOINT}/${encodeURIComponent(editingUnit.id)}`,
                    payload,
                    { params: { type: SETTING_TYPE } },
                );

                const updated = normalizeUnit(response.data?.data);

                if (updated) {
                    setUnits((previous) =>
                        previous.map((unit) =>
                            unit.id === updated.id ? updated : unit,
                        ),
                    );
                } else {
                    await loadUnits();
                }
            } else {
                const response = await api.post<ApiResponse<Unit>>(
                    COMMON_ENDPOINT,
                    payload,
                    { params: { type: SETTING_TYPE } },
                );

                const created = normalizeUnit(response.data?.data);

                if (created) {
                    setUnits((previous) => [...previous, created]);
                } else {
                    await loadUnits();
                }
            }

            setShowForm(false);
            setEditingUnit(null);
            setFormData({ ...emptyForm });
            setErrors({});
        } catch (error) {
            const message = getErrorMessage(
                error,
                editingUnit
                    ? "Unable to update unit."
                    : "Unable to create unit.",
            );

            if (
                message.toLowerCase().includes("already exists") ||
                message.toLowerCase().includes("duplicate")
            ) {
                setErrors((previous) => ({
                    ...previous,
                    name: message,
                }));
            } else {
                setPageError(message);
            }
        } finally {
            setSaving(false);
        }
    }, [editingUnit, formData, loadUnits, saving, validateForm]);

    const handleToggle = useCallback(
        async (unit: Unit, checked: boolean) => {
            if (togglingId === unit.id) return;

            const previousStatus = unit.status;

            setUnits((previous) =>
                previous.map((item) =>
                    item.id === unit.id
                        ? { ...item, status: checked }
                        : item,
                ),
            );
            setTogglingId(unit.id);
            setPageError("");

            try {
                const response = await api.patch<ApiResponse<Unit>>(
                    `${COMMON_ENDPOINT}/${encodeURIComponent(unit.id)}`,
                    { status: checked },
                    { params: { type: SETTING_TYPE } },
                );

                const updated = normalizeUnit(response.data?.data);

                if (updated) {
                    setUnits((previous) =>
                        previous.map((item) =>
                            item.id === updated.id ? updated : item,
                        ),
                    );
                }
            } catch (error) {
                setUnits((previous) =>
                    previous.map((item) =>
                        item.id === unit.id
                            ? { ...item, status: previousStatus }
                            : item,
                    ),
                );
                setPageError(
                    getErrorMessage(error, "Unable to update unit status."),
                );
            } finally {
                setTogglingId(null);
            }
        },
        [togglingId],
    );

    const handleDelete = useCallback(async () => {
        if (!deleteUnit || deleting) return;

        setDeleting(true);
        setPageError("");

        try {
            await api.delete<ApiResponse<DeleteResult>>(
                `${COMMON_ENDPOINT}/${encodeURIComponent(deleteUnit.id)}`,
                { params: { type: SETTING_TYPE } },
            );

            setUnits((previous) =>
                previous.filter((unit) => unit.id !== deleteUnit.id),
            );
            setDeleteUnit(null);
        } catch (error) {
            setPageError(
                getErrorMessage(error, "Unable to delete unit."),
            );
        } finally {
            setDeleting(false);
        }
    }, [deleteUnit, deleting]);

    const columns: DataTableColumn<Unit>[] = [
        {
            key: "name",
            label: "Unit",
            sortable: true,
            width: "30%",
            render: (row) => (
                <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                        <ArrowsOutIcon
                            size={17}
                            weight="duotone"
                        />
                    </div>

                    <div className="min-w-0">
                        <p className="truncate text-xs font-bold text-slate-800">
                            {row.name}
                        </p>

                        <p className="mt-0.5 text-[10px] font-medium text-slate-400">
                            {row.id}
                        </p>
                    </div>
                </div>
            ),
        },
        {
            key: "description",
            label: "Description",
            sortable: true,
            width: "45%",
            render: (row) => (
                <span className="text-xs leading-5 text-slate-500">
                    {row.description}
                </span>
            ),
        },
        {
            key: "status",
            label: "Status",
            sortable: true,
            align: "center",
            width: "15%",
            render: (row) => (
                <div className="flex items-center justify-center">
                    <ToggleSwitch
                        checked={row.status}
                        onChange={(checked) =>
                            void handleToggle(
                                row,
                                checked
                            )
                        }
                        disabled={
                            togglingId === row.id
                        }
                        srLabel={`Toggle ${row.name} status`}
                    />
                </div>
            ),
        },
        {
            key: "actions",
            label: "Actions",
            align: "center",
            width: "10%",
            render: (row) => (
                <div className="flex items-center justify-center gap-1">
                    <button
                        type="button"
                        onClick={() =>
                            openEditForm(row)
                        }
                        disabled={saving || deleting}
                        title={`Edit ${row.name}`}
                        aria-label={`Edit ${row.name}`}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                    >
                        <PencilSimpleIcon
                            size={16}
                            weight="duotone"
                        />
                    </button>

                    <button
                        type="button"
                        onClick={() =>
                            setDeleteUnit(row)
                        }
                        disabled={deleting}
                        title={`Delete ${row.name}`}
                        aria-label={`Delete ${row.name}`}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                    >
                        <TrashIcon
                            size={16}
                            weight="duotone"
                        />
                    </button>
                </div>
            ),
        },
    ];

    return (
        <div className="space-y-5">
            <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 className="text-lg font-bold text-slate-900">
                        Units
                    </h2>

                    <p className="mt-1 text-xs text-slate-500">
                        Manage the units of measurement
                        available across your enterprise
                        system.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={openAddForm}
                    disabled={loading || saving}
                    className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700"
                >
                    <PlusIcon
                        size={16}
                        weight="bold"
                    />

                    Add Unit
                </button>
            </div>

            {showForm && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
                    <div className="mb-5">
                        <h3 className="text-sm font-bold text-slate-900">
                            {editingUnit
                                ? "Edit Unit"
                                : "Add Unit"}
                        </h3>

                        <p className="mt-1 text-xs text-slate-500">
                            {editingUnit
                                ? "Update the unit information."
                                : "Create a new unit of measurement."}
                        </p>
                    </div>

                    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                        {editingUnit && (
                            <div>
                                <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                    Unit ID
                                </label>

                                <input
                                    type="text"
                                    value={
                                        editingUnit.id
                                    }
                                    disabled
                                    className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2.5 text-sm font-medium text-slate-500 outline-none"
                                />
                            </div>
                        )}

                        <div>
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Unit Name
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <input
                                type="text"
                                value={formData.name}
                                onChange={(event) => {
                                    setFormData(
                                        (previous) => ({
                                            ...previous,
                                            name: event
                                                .target
                                                .value,
                                        })
                                    );

                                    if (errors.name) {
                                        setErrors(
                                            (previous) => ({
                                                ...previous,
                                                name: undefined,
                                            })
                                        );
                                    }
                                }}
                                placeholder="e.g. Meter"
                                className={`w-full rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.name
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.name && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {errors.name}
                                </p>
                            )}
                        </div>

                        <div className="md:col-span-2">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Description
                                <span className="ml-1 text-red-500">
                                    *
                                </span>
                            </label>

                            <textarea
                                rows={3}
                                value={
                                    formData.description
                                }
                                onChange={(event) => {
                                    setFormData(
                                        (previous) => ({
                                            ...previous,
                                            description:
                                                event.target
                                                    .value,
                                        })
                                    );

                                    if (
                                        errors.description
                                    ) {
                                        setErrors(
                                            (previous) => ({
                                                ...previous,
                                                description:
                                                    undefined,
                                            })
                                        );
                                    }
                                }}
                                placeholder="Enter a description for this unit..."
                                className={`w-full resize-none rounded-lg border bg-white px-3 py-2.5 text-sm text-slate-700 outline-none transition placeholder:text-slate-400 ${
                                    errors.description
                                        ? "border-red-300 focus:border-red-400"
                                        : "border-slate-200 focus:border-red-300"
                                }`}
                            />

                            {errors.description && (
                                <p className="mt-1 text-[10px] font-medium text-red-500">
                                    {
                                        errors.description
                                    }
                                </p>
                            )}
                        </div>
                    </div>

                    <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
                        <button
                            type="button"
                            onClick={closeForm}
                            className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                        >
                            Cancel
                        </button>

                        <button
                            type="button"
                            onClick={() => void handleSave()}
                            disabled={saving}
                            className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                        >
                            {editingUnit
                                ? "Save Changes"
                                : "Add Unit"}
                        </button>
                    </div>
                </div>
            )}

            {pageError && (
                <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-xs font-medium text-red-600">
                    {pageError}
                </div>
            )}

            <DataTable<Unit>
                columns={columns}
                data={units}
                rowKey={(row) => row.id}
                minWidth="760px"
                emptyMessage={
                    loading
                        ? "Loading units..."
                        : "No units found. Click Add Unit to create one."
                }
            />

            {deleteUnit && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-900/40 p-4 backdrop-blur-[2px]">
                    <div className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
                        <div className="p-5">
                            <div className="flex items-start gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600">
                                    <TrashIcon
                                        size={19}
                                        weight="duotone"
                                    />
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold text-slate-900">
                                        Delete Unit
                                    </h3>

                                    <p className="mt-1 text-xs leading-5 text-slate-500">
                                        Are you sure you
                                        want to delete{" "}
                                        <span className="font-bold text-slate-700">
                                            {
                                                deleteUnit.name
                                            }
                                        </span>
                                        ? This action
                                        cannot be undone.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 border-t border-slate-200 bg-slate-50 px-5 py-4">
                            <button
                                type="button"
                                onClick={() =>
                                    setDeleteUnit(null)
                                }
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={() => void handleDelete()}
                                disabled={deleting}
                                className="rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-red-700"
                            >
                                Delete Unit
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
