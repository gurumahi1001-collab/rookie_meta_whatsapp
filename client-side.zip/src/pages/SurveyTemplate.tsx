import React, { useState } from "react";


import SurveyList from "../components/SurveyReport/SurveyList";
import SurveyPack from "../components/SurveyReport/SurveyPack";
import SurveyReport from "../components/SurveyReport/SurveyReport";

const SurveyTemplate = () => {
    const [activeTab, setActiveTab] = useState<
        "list" | "pack" | "report"
    >("list");

    return (
        <div className="w-full">

            {activeTab === "list" && (
                <SurveyList />
            )}

            {activeTab === "pack" && (
                <SurveyPack />
            )}

            {activeTab === "report" && (
                <SurveyReport />
            )}
        </div>
    );
};

export default SurveyTemplate;