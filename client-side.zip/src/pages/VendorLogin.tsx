import React, { useState } from "react";
import { ArrowRightIcon, EyeClosedIcon, EyeIcon, LockIcon, MailboxIcon } from "@phosphor-icons/react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";
import logo from "../assets/img/logo.png";

function getErrorMessage(error: any) {
    return (
        error?.response?.data?.message ||
        "Unable to sign in. Please check your credentials and try again."
    );
}

const VendorLogin = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async (event: React.FormEvent) => {
        event.preventDefault();
        setError("");

        const normalizedEmail = email.trim().toLowerCase();
        if (!normalizedEmail || !password) {
            setError("Email and password are required.");
            return;
        }

        setSubmitting(true);
        try {
            await api.post("/auth/vendor/login", {
                email: normalizedEmail,
                password,
            });

            navigate("/vendor_dashboard", { replace: true });
        } catch (requestError) {
            setError(getErrorMessage(requestError));
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <div className="min-h-screen w-full flex items-center justify-center bg-[#F5F7FA] px-6 py-10">
            <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-sm ring-1 ring-slate-200">
                <div className="mb-8 flex items-center justify-center">
                    <img src={logo} alt="Argus" className="h-12 w-auto" />
                </div>

                <div className="text-center">
                    <div className="text-[10px] font-semibold uppercase tracking-[0.25em] text-slate-400">
                        Vendor Portal
                    </div>
                    <h1 className="mt-2 text-2xl font-bold text-[#0F1E3D]">Welcome back</h1>
                    <p className="mt-2 text-sm text-slate-500">
                        Sign in to your Argus vendor workspace.
                    </p>
                </div>

                {error && (
                    <div className="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                        {error}
                    </div>
                )}

                <form onSubmit={handleSubmit} className="mt-8 space-y-5">
                    <div>
                        <label className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-slate-500">
                            Email
                        </label>
                        <div className="relative">
                            <MailboxIcon className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                            <input
                                type="email"
                                required
                                autoComplete="email"
                                value={email}
                                onChange={(event) => setEmail(event.target.value)}
                                placeholder="vendor@company.com"
                                className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-3.5 text-sm text-[#0F1E3D] outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/15"
                            />
                        </div>
                    </div>

                    <div>
                        <label className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-slate-500">
                            Password
                        </label>
                        <div className="relative">
                            <LockIcon className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                            <input
                                type={showPassword ? "text" : "password"}
                                required
                                autoComplete="current-password"
                                value={password}
                                onChange={(event) => setPassword(event.target.value)}
                                placeholder="••••••••"
                                className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-10 pr-11 text-sm text-[#0F1E3D] outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/15"
                            />
                            <button
                                type="button"
                                onClick={() => setShowPassword((value) => !value)}
                                aria-label={showPassword ? "Hide password" : "Show password"}
                                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0F1E3D]"
                            >
                                {showPassword ? (
                                    <EyeClosedIcon className="h-4 w-4" />
                                ) : (
                                    <EyeIcon className="h-4 w-4" />
                                )}
                            </button>
                        </div>
                    </div>

                    <button
                        type="submit"
                        disabled={submitting}
                        className="group flex w-full items-center justify-center gap-2 rounded-xl bg-[#123A8F] py-3 text-sm font-semibold text-white transition hover:bg-[#0F2F73] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        {submitting ? "Signing in…" : "Sign in to Vendor Portal"}
                        {!submitting && <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />}
                    </button>
                </form>

                <button
                    type="button"
                    onClick={() => navigate("/")}
                    className="mt-5 w-full text-center text-sm text-slate-500 transition hover:text-[#0F1E3D]"
                >
                    Back to internal sign in
                </button>
            </div>
        </div>
    );
};

export default VendorLogin;
