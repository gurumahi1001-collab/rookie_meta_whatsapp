import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import DataTable, { DataTableColumn } from "../components/DataTable";
import DataCard from "../components/DataCard";
import OffCanvas from "../components/OffCanvas";
import AddMemberForm from "../offcanvas/users/AddMemberForm";
import Avatar from "../components/Avatar";
import Button from "../components/Button";
import { TeamMember } from "../types/user";
import {
    ClockCounterClockwiseIcon,
    LayoutIcon,
    ListIcon,
    MagnifyingGlassIcon,
    MailboxIcon,
    PenNibIcon,
    UserPlusIcon,
    CaretLeftIcon,
    CaretRightIcon,
    SpinnerGapIcon,
} from "@phosphor-icons/react";
import UserLog from "../offcanvas/users/User_log";
import api, { getApiErrorMessage } from "../api/axios";
import { useAuth } from "../auth/AuthProvider";

type ApiRole = {
    id?: string;
    _id?: string;
    key?: string;
    code?: string;
    name?: string;
    userType?: string;
    realm?: string;
    status?: string;
    active?: boolean;
    isSystem?: boolean;
    system?: boolean;
};

type ApiUser = {
    id: string;
    email: string;
    name?: string;
    displayName?: string;
    userType?: "admin" | "internal" | "vendor";
    role?: ApiRole | string | null;
    roleId?: string | null;
    vendor?: unknown;
    vendorId?: string | null;
    status?: "active" | "inactive";
    lastLoginAt?: string | null;
    createdAt?: string | null;
    updatedAt?: string | null;
    profileImage?: {
        mimeType?: string | null;
        uploadedAt?: string | null;
    } | null;
};

type UsersListResponse = {
    success?: boolean;
    message?: string;
    data?: ApiUser[];
    pagination?: {
        page?: number;
        limit?: number;
        total?: number;
        pages?: number;
    };
    summary?: {
        active?: number;
        inactive?: number;
        total?: number;
    };
};

type RolesResponse = {
    success?: boolean;
    message?: string;
    data?: ApiRole[];
};

const ACTIVE_STATUSES = ["All", "Active", "Inactive"] as const;

function toUiStatus(
    status?: string,
): "Active" | "Inactive" {
    return String(status || "").toLowerCase() === "active"
        ? "Active"
        : "Inactive";
}

function toBackendStatus(
    status: "Active" | "Inactive",
): "active" | "inactive" {
    return status === "Inactive"
        ? "inactive"
        : "active";
}

function roleName(
    role: ApiRole | string | null | undefined,
): string {
    if (!role) {
        return "Unassigned";
    }

    if (typeof role === "string") {
        return role;
    }

    return (
        role.name ||
        role.key ||
        role.code ||
        "Unassigned"
    );
}

function mapUserToMember(
    user: ApiUser,
): TeamMember {
    return {
        id: user.id,
        name:
            user.displayName ||
            user.name ||
            "",
        email: user.email,
        password: "",
        role: roleName(user.role) as TeamMember["role"],
        hourlyrate: "",
        status: toUiStatus(user.status),
        department: "",
        location: "",
        privileges: [],
        imageUrl: user.profileImage
            ? `${String(api.defaults.baseURL || "").replace(/\/+$/, "")}/users/${encodeURIComponent(user.id)}/avatar?ts=${encodeURIComponent(
                  user.profileImage.uploadedAt ||
                      String(Date.now()),
              )}`
            : null,
    };
}

function mapMemberPayload(
    member: TeamMember,
    roleId: string | null,
) {
    const payload: Record<string, unknown> = {
        email: member.email.trim(),
        displayName: member.name.trim(),
        userType: "admin",
        roleId: roleId || undefined,
        status: toBackendStatus(member.status),
    };

    if (member.password.trim()) {
        payload.password =
            member.password.trim();
    }

    return payload;
}

function StatusPill({
    status,
}: {
    status: "Active" | "Inactive";
}) {
    return (
        <span
            className={`inline-flex rounded-full border px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ${
                status === "Active"
                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                    : "border-red-200 bg-red-50 text-red-600"
            }`}
        >
            {status}
        </span>
    );
}

export default function Users() {
    const { user: currentUser, reloadSession } = useAuth();

    const [members, setMembers] =
        useState<TeamMember[]>([]);

    const [roles, setRoles] =
        useState<ApiRole[]>([]);

    const [view, setView] =
        useState<"table" | "cards">("table");

    const [search, setSearch] =
        useState("");

    const [searchQuery, setSearchQuery] =
        useState("");

    const [page, setPage] =
        useState(1);

    const pageSize = 25;

    const [totalUsers, setTotalUsers] =
        useState(0);

    const [totalPages, setTotalPages] =
        useState(1);

    const [summaryActive, setSummaryActive] =
        useState(0);

    const [summaryInactive, setSummaryInactive] =
        useState(0);

    const usersRequestSequence =
        useRef(0);

    const usersAbortController =
        useRef<AbortController | null>(null);

    const [roleFilter, setRoleFilter] =
        useState<string>("All");

    const [statusFilter, setStatusFilter] =
        useState<
            (typeof ACTIVE_STATUSES)[number]
        >("All");

    const [loading, setLoading] =
        useState(true);

    const [saving, setSaving] =
        useState(false);

    const [error, setError] =
        useState("");

    const [notice, setNotice] =
        useState("");

    const [isAddOpen, setIsAddOpen] =
        useState(false);

    const [selectedMember, setSelectedMember] =
        useState<TeamMember | null>(null);

    const [activityDrawerOpen, setActivityDrawerOpen] =
        useState(false);

    const [activityMember, setActivityMember] =
        useState<TeamMember | null>(null);

    const loadRoles = useCallback(
        async () => {
            const response =
                await api.get<RolesResponse>(
                    "/settings/roles",
                );

            if (response.data?.success === false) {
                throw new Error(
                    response.data?.message ||
                        "Unable to load available roles.",
                );
            }

            const list =
                Array.isArray(response.data?.data)
                    ? response.data.data
                    : [];

            setRoles(
                list.filter((role) => {
                    const status = String(role.status || "").toLowerCase();
                    const type = String(role.userType || role.realm || "").toLowerCase();

                    return (
                        status !== "inactive" &&
                        role.active !== false &&
                        (!type || type === "admin" || type === "internal")
                    );
                }),
            );
        },
        [],
    );

    const loadUsers = useCallback(
        async (targetPage = page) => {
            usersAbortController.current?.abort();
            const controller = new AbortController();
            usersAbortController.current = controller;

            const requestSequence = ++usersRequestSequence.current;

            setLoading(true);
            setError("");

            try {
                const response = await api.get(
                    "/users",
                    {
                        params: {
                            page: targetPage,
                            limit: pageSize,
                            userType: "admin",
                            search: searchQuery.trim() || undefined,
                            roleId: roleFilter === "All" ? undefined : roleFilter,
                            status:
                                statusFilter === "All"
                                    ? undefined
                                    : toBackendStatus(statusFilter),
                        },
                        signal: controller.signal,
                    },
                );

                if (requestSequence !== usersRequestSequence.current) {
                    return;
                }

                if (response.data?.success === false) {
                    throw new Error(
                        response.data?.message ||
                            "Unable to load users.",
                    );
                }

                const result =
                    (response.data?.data || {}) as UsersListResponse;

                const users =
                    Array.isArray(result.data)
                        ? result.data
                        : [];

                setMembers(users.map(mapUserToMember));

                const pagination = result.pagination || {};
                const nextTotal = Number(pagination.total || 0);
                const nextPages = Math.max(
                    1,
                    Number(pagination.pages || 1),
                );
                const serverPage = Math.max(
                    1,
                    Number(pagination.page || targetPage),
                );

                setTotalUsers(nextTotal);
                setTotalPages(nextPages);
                setPage(serverPage);
                setSummaryActive(Number(result.summary?.active || 0));
                setSummaryInactive(Number(result.summary?.inactive || 0));
            } catch (err) {
                if ((err as { name?: string })?.name === "CanceledError" ||
                    (err as { code?: string })?.code === "ERR_CANCELED" ||
                    (err as { name?: string })?.name === "AbortError") {
                    return;
                }

                if (requestSequence === usersRequestSequence.current) {
                    setError(
                        getApiErrorMessage(
                            err,
                            "Unable to load users.",
                        ),
                    );
                    setMembers([]);
                    setTotalUsers(0);
                    setTotalPages(1);
                    setSummaryActive(0);
                    setSummaryInactive(0);
                }
            } finally {
                if (requestSequence === usersRequestSequence.current) {
                    setLoading(false);
                }
            }
        },
        [
            page,
            pageSize,
            roleFilter,
            searchQuery,
            statusFilter,
        ],
    );

    useEffect(() => {
        const timer = window.setTimeout(() => {
            setSearchQuery(search.trim());
        }, 350);

        return () => window.clearTimeout(timer);
    }, [search]);

    const activeFilterKey = useMemo(
        () => `${searchQuery}::${roleFilter}::${statusFilter}`,
        [searchQuery, roleFilter, statusFilter],
    );

    const lastFilterKey = useRef<string | null>(null);

    useEffect(() => {
        let cancelled = false;

        const loadInitialRoles = async () => {
            try {
                await loadRoles();
            } catch (err) {
                if (!cancelled) {
                    setError(
                        getApiErrorMessage(
                            err,
                            "Unable to load roles.",
                        ),
                    );
                }
            }
        };

        void loadInitialRoles();

        return () => {
            cancelled = true;
        };
    }, [loadRoles]);

    useEffect(() => {
        if (lastFilterKey.current !== activeFilterKey) {
            lastFilterKey.current = activeFilterKey;

            if (page !== 1) {
                setPage(1);
                return;
            }
        }

        void loadUsers(page);

        return () => {
            usersAbortController.current?.abort();
        };
    }, [activeFilterKey, loadUsers, page]);

    useEffect(() => {
        if (!notice) {
            return;
        }

        const timer =
            window.setTimeout(
                () => setNotice(""),
                3500,
            );

        return () =>
            window.clearTimeout(
                timer,
            );
    }, [notice]);

    const roleOptions =
        useMemo(
            () =>
                roles
                    .map((role) => ({
                        id: String(role.id || role._id || ""),
                        name: String(
                            role.name ||
                                role.key ||
                                role.code ||
                                "",
                        ).trim(),
                    }))
                    .filter((role) => role.id && role.name)
                    .sort((a, b) => a.name.localeCompare(b.name)),
            [roles],
        );

    const roleIdByName =
        useMemo(() => {
            const map = new Map<string, string>();

            roles.forEach((role) => {
                const id = String(role.id || role._id || "");
                const name = String(
                    role.name ||
                        role.key ||
                        role.code ||
                        "",
                ).trim();

                if (id && name) {
                    map.set(name, id);
                }
            });

            return map;
        }, [roles]);

    const filteredMembers = members;

    const activeCount = summaryActive;

    const handleSaveMember =
        async (
            member: TeamMember,
        ) => {
            setSaving(true);
            setError("");

            try {
                const roleId =
                    roleIdByName.get(
                        member.role,
                    ) || null;

                if (!roleId) {
                    throw new Error(
                        "Please select a valid active role.",
                    );
                }

                const payload =
                    mapMemberPayload(
                        member,
                        roleId,
                    );

                let savedUser: ApiUser | undefined;

                if (selectedMember) {
                    const response =
                        await api.patch(
                            `/users/${encodeURIComponent(
                                member.id,
                            )}`,
                            payload,
                        );

                    if (response.data?.success === false) {
                        throw new Error(
                            response.data?.message ||
                                "Unable to update the user.",
                        );
                    }

                    savedUser =
                        response.data?.data as
                        | ApiUser
                        | undefined;
                } else {
                    const response =
                        await api.post(
                            "/users",
                            {
                                ...payload,
                                password:
                                    member.password.trim(),
                            },
                        );

                    if (response.data?.success === false) {
                        throw new Error(
                            response.data?.message ||
                                "Unable to create the user.",
                        );
                    }

                    savedUser =
                        response.data?.data as
                        | ApiUser
                        | undefined;
                }

                const userId =
                    savedUser?.id ||
                    member.id;

                if (!userId) {
                    throw new Error("User was saved but the user ID was not returned.");
                }

                let imageUploadFailed = false;

                if (member.imageFile) {
                    try {
                        const formData =
                            new FormData();
                        formData.append("image", member.imageFile);

                        const imageResponse =
                            await api.post(
                                `/users/${encodeURIComponent(
                                    userId,
                                )}/avatar`,
                                formData,
                            );

                        if (imageResponse.data?.success === false) {
                            throw new Error(
                                imageResponse.data?.message ||
                                    "Unable to save the profile image.",
                            );
                        }

                        savedUser =
                            imageResponse.data?.data as
                            | ApiUser
                            | undefined;
                    } catch (imageError) {
                        imageUploadFailed = true;
                        console.error("[UserManagement] profile image upload failed", imageError);
                    }
                } else if (member.removeImage && selectedMember?.imageUrl) {
                    try {
                        const imageResponse =
                            await api.delete(
                                `/users/${encodeURIComponent(
                                    userId,
                                )}/avatar`,
                            );

                        if (imageResponse.data?.success === false) {
                            throw new Error(
                                imageResponse.data?.message ||
                                    "Unable to remove the profile image.",
                            );
                        }

                        savedUser =
                            imageResponse.data?.data as
                            | ApiUser
                            | undefined;
                    } catch (imageError) {
                        imageUploadFailed = true;
                        console.error("[UserManagement] profile image removal failed", imageError);
                    }
                }

                await loadUsers(page);

                if (currentUser?.id === userId) {
                    await reloadSession();
                }

                setNotice(
                    imageUploadFailed
                        ? selectedMember
                            ? "User updated, but the profile image could not be saved."
                            : "User created, but the profile image could not be saved."
                        : selectedMember
                            ? "User updated successfully."
                            : "User created successfully.",
                );

                setSelectedMember(null);
                setIsAddOpen(false);
            } catch (err) {
                setError(
                    getApiErrorMessage(
                        err,
                        "Unable to save the user.",
                    ),
                );
            } finally {
                setSaving(false);
            }
        };

    const handleOpenAdd = () => {
        setSelectedMember(null);
        setIsAddOpen(true);
        setError("");
    };

    const handleOpenEdit = (
        member: TeamMember,
    ) => {
        setSelectedMember(member);
        setIsAddOpen(true);
        setError("");
    };

    const handleCloseForm = () => {
        if (saving) {
            return;
        }

        setSelectedMember(null);
        setIsAddOpen(false);
    };

    const handleOpenActivityLog = (
        member: TeamMember,
    ) => {
        setActivityMember(member);
        setActivityDrawerOpen(true);
    };

    const handleCloseActivityLog = () => {
        setActivityDrawerOpen(false);
        setActivityMember(null);
    };

    const columns: DataTableColumn<TeamMember>[] =
        [
            {
                key: "member",
                label: "Member",
                sortable: true,
                render: (row) => (
                    <div className="flex items-center gap-3">
                        <Avatar
                            name={row.name}
                            size={38}
                            imageUrl={row.imageUrl}
                        />

                        <div className="min-w-0">
                            <p className="font-bold text-slate-900 group-hover:text-red-600">
                                {row.name}
                            </p>

                            <p className="text-xs text-slate-400">
                                {row.email}
                            </p>
                        </div>
                    </div>
                ),
            },

            {
                key: "role",
                label: "Role",
                sortable: true,
                render: (row) => (
                    <p className="font-bold text-slate-800">
                        {row.role}
                    </p>
                ),
            },

            {
                key: "status",
                label: "Status",
                align: "center",
                render: (row) => (
                    <div className="flex items-center justify-center">
                        <StatusPill
                            status={
                                row.status
                            }
                        />
                    </div>
                ),
            },

            {
                key: "hourlyrate",
                label: "Hourly Rate",
                align: "center",
                render: (row) => (
                    <div className="flex items-center justify-center">
                        <span className="font-semibold text-slate-800">
                            {row.hourlyrate ||
                                "—"}
                        </span>
                    </div>
                ),
            },

            {
                key: "menu",
                label: "Actions",
                align: "right",
                render: (row) => (
                    <div className="flex items-center justify-end gap-1.5">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                handleOpenActivityLog(
                                    row,
                                )
                            }
                            className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                            title="View Log"
                        >
                            <ClockCounterClockwiseIcon
                                size={16}
                            />
                        </Button>

                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                handleOpenEdit(
                                    row,
                                )
                            }
                            className="h-8 w-8 !rounded-md !p-0 text-slate-400 hover:text-slate-600"
                            title="Edit"
                        >
                            <PenNibIcon
                                size={16}
                            />
                        </Button>
                    </div>
                ),
            },
        ];

    return (
        <>
            <div className="mb-6 flex items-start justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">
                        User Management
                    </h1>

                    <p className="mt-1 text-xs text-slate-400">
                        {loading
                            ? "Loading directory..."
                            : `${totalUsers} users · ${activeCount} active · ${summaryInactive} inactive`}
                    </p>
                </div>

                <div className="flex items-start justify-end gap-2">
                    <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white p-1 shadow-sm">
                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                setView("table")
                            }
                            className={`!border-0 !px-3 !py-1.5 text-xs ${
                                view ===
                                "table"
                                    ? "!bg-slate-900 !text-white"
                                    : "!bg-transparent !text-slate-500 hover:!bg-slate-50 hover:!text-slate-700"
                            }`}
                        >
                            <ListIcon size={14} />
                            Table
                        </Button>

                        <Button
                            type="button"
                            variant="outline"
                            onClick={() =>
                                setView("cards")
                            }
                            className={`!border-0 !px-3 !py-1.5 text-xs ${
                                view ===
                                "cards"
                                    ? "!bg-slate-900 !text-white"
                                    : "!bg-transparent !text-slate-500 hover:!bg-slate-50 hover:!text-slate-700"
                            }`}
                        >
                            <LayoutIcon size={14} />
                            Cards
                        </Button>
                    </div>

                    <Button
                        type="button"
                        variant="primary"
                        onClick={handleOpenAdd}
                        className="!px-4 !py-2.5"
                        disabled={
                            loading ||
                            saving
                        }
                    >
                        <UserPlusIcon size={16} />
                        Add Member
                    </Button>
                </div>
            </div>

            {error && (
                <div className="mb-4 flex items-start justify-between gap-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                    <span>
                        {error}
                    </span>

                    <button
                        type="button"
                        onClick={() =>
                            setError("")
                        }
                        className="font-bold text-red-500 hover:text-red-700"
                    >
                        ×
                    </button>
                </div>
            )}

            {notice && (
                <div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">
                    {notice}
                </div>
            )}

            <div className="flex gap-6">
                <aside className="w-64 shrink-0 space-y-4">
                    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                        <span className="mb-2 block text-[10px] font-black uppercase tracking-wide text-slate-400">
                            Search Directory
                        </span>

                        <div className="relative">
                            <MagnifyingGlassIcon
                                size={15}
                                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                            />

                            <input
                                type="text"
                                value={search}
                                onChange={(event) =>
                                    setSearch(
                                        event.target.value,
                                    )
                                }
                                placeholder="Name or role..."
                                className="w-full rounded-lg border border-slate-200 py-2.5 pl-9 pr-3 text-sm text-slate-700 placeholder:text-slate-400 focus:border-red-500 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                            />
                        </div>

                        <span className="mb-2 mt-5 block text-[10px] font-black uppercase tracking-wide text-slate-400">
                            Filter by Role
                        </span>

                        <div className="space-y-1">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => setRoleFilter("All")}
                                className={`!w-full !justify-between !border-0 !px-3 !py-2 text-sm ${
                                    roleFilter === "All"
                                        ? "!bg-transparent !text-red-600"
                                        : "!bg-transparent !text-slate-600 hover:!bg-slate-50"
                                }`}
                            >
                                All
                                {roleFilter === "All" && (
                                    <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
                                )}
                            </Button>

                            {roleOptions.map((role) => (
                                <Button
                                    key={role.id}
                                    type="button"
                                    variant="outline"
                                    onClick={() => setRoleFilter(role.id)}
                                    className={`!w-full !justify-between !border-0 !px-3 !py-2 text-sm ${
                                        roleFilter === role.id
                                            ? "!bg-transparent !text-red-600"
                                            : "!bg-transparent !text-slate-600 hover:!bg-slate-50"
                                    }`}
                                >
                                    {role.name}
                                    {roleFilter === role.id && (
                                        <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
                                    )}
                                </Button>
                            ))}

                            {!loading &&
                                roleOptions.length ===
                                    0 && (
                                    <p className="px-3 py-2 text-xs text-slate-400">
                                        No active roles found.
                                    </p>
                                )}
                        </div>

                        <span className="mb-2 mt-5 block text-[10px] font-black uppercase tracking-wide text-slate-400">
                            Filter by Status
                        </span>

                        <div className="space-y-1">
                            {ACTIVE_STATUSES.map(
                                (status) => (
                                    <Button
                                        key={status}
                                        type="button"
                                        variant="outline"
                                        onClick={() =>
                                            setStatusFilter(
                                                status,
                                            )
                                        }
                                        className={`!w-full !justify-between !border-0 !px-3 !py-2 text-sm ${
                                            statusFilter ===
                                            status
                                                ? "!bg-transparent !text-red-600"
                                                : "!bg-transparent !text-slate-600 hover:!bg-slate-50"
                                        }`}
                                    >
                                        <span className="flex items-center gap-2">
                                            {status !==
                                                "All" && (
                                                <span
                                                    className={`h-2 w-2 rounded-full ${
                                                        status ===
                                                        "Active"
                                                            ? "bg-emerald-500"
                                                            : "bg-red-500"
                                                    }`}
                                                />
                                            )}

                                            {status}
                                        </span>

                                        {statusFilter ===
                                            status && (
                                            <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
                                        )}
                                    </Button>
                                ),
                            )}
                        </div>
                    </div>
                </aside>

                <main className="min-w-0 flex-1 space-y-4">
                    {loading && filteredMembers.length > 0 && (
                        <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-500 shadow-sm">
                            <SpinnerGapIcon size={15} className="animate-spin" />
                            Refreshing user directory...
                        </div>
                    )}

                    {loading && filteredMembers.length === 0 ? (
                        <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-400 shadow-sm">
                            <SpinnerGapIcon size={20} className="mx-auto mb-2 animate-spin" />
                            Loading users...
                        </div>
                    ) : filteredMembers.length === 0 ? (
                        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center shadow-sm">
                            <p className="text-sm font-semibold text-slate-700">
                                No users found
                            </p>

                            <p className="mt-1 text-xs text-slate-400">
                                Try another search or filter.
                            </p>
                        </div>
                    ) : view === "table" ? (
                        <DataTable
                            columns={
                                columns
                            }
                            data={
                                filteredMembers
                            }
                            rowKey={(
                                row,
                            ) =>
                                row.id
                            }
                            footer={
                                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-white px-4 py-3">
                                    <p className="text-xs text-slate-400">
                                        {totalUsers === 0
                                            ? "0 results"
                                            : `Showing ${(page - 1) * pageSize + 1}-${Math.min(page * pageSize, totalUsers)} of ${totalUsers}`}
                                    </p>

                                    <div className="flex items-center gap-2">
                                        <Button
                                            type="button"
                                            variant="outline"
                                            onClick={() => setPage((value) => Math.max(1, value - 1))}
                                            disabled={page <= 1 || loading}
                                            className="!h-8 !w-8 !rounded-md !p-0"
                                            title="Previous page"
                                        >
                                            <CaretLeftIcon size={14} />
                                        </Button>

                                        <span className="min-w-20 text-center text-xs font-semibold text-slate-600">
                                            Page {page} of {totalPages}
                                        </span>

                                        <Button
                                            type="button"
                                            variant="outline"
                                            onClick={() => setPage((value) => Math.min(totalPages, value + 1))}
                                            disabled={page >= totalPages || loading}
                                            className="!h-8 !w-8 !rounded-md !p-0"
                                            title="Next page"
                                        >
                                            <CaretRightIcon size={14} />
                                        </Button>
                                    </div>
                                </div>
                            }
                        />
                    ) : (
                        <div className="grid grid-cols-1 items-stretch gap-5 sm:grid-cols-2 xl:grid-cols-2">
                            {filteredMembers.map(
                                (
                                    member,
                                ) => (
                                    <div
                                        key={
                                            member.id
                                        }
                                        className="flex min-w-0"
                                    >
                                        <DataCard
                                            className="w-full min-w-0"
                                            title={
                                                member.name
                                            }
                                            subtitle={
                                                member.role
                                            }
                                            avatar={
                                                <Avatar
                                                    name={
                                                        member.name
                                                    }
                                                    size={
                                                        48
                                                    }
                                                    online={
                                                        member.status ===
                                                        "Active"
                                                    }
                                                />
                                            }
                                            badge={{
                                                text:
                                                    member.status,
                                                color:
                                                    member.status ===
                                                    "Active"
                                                        ? "green"
                                                        : "red",
                                                position:
                                                    "top-right",
                                            }}
                                            actions={[
                                                {
                                                    id: "log",
                                                    label: (
                                                        <ClockCounterClockwiseIcon
                                                            size={
                                                                16
                                                            }
                                                        />
                                                    ),
                                                    onClick:
                                                        () =>
                                                            handleOpenActivityLog(
                                                                member,
                                                            ),
                                                    variant:
                                                        "link",
                                                },
                                                {
                                                    id: "edit",
                                                    label: (
                                                        <PenNibIcon
                                                            size={
                                                                16
                                                            }
                                                        />
                                                    ),
                                                    onClick:
                                                        () =>
                                                            handleOpenEdit(
                                                                member,
                                                            ),
                                                    variant:
                                                        "link",
                                                },
                                            ]}
                                            fields={[
                                                {
                                                    label: "Email",
                                                    fullWidth: true,
                                                    value: (
                                                        <div className="flex w-full min-w-0 items-start gap-2">
                                                            <MailboxIcon
                                                                size={
                                                                    13
                                                                }
                                                                className="mt-0.5 shrink-0 text-slate-400"
                                                            />

                                                            <span className="min-w-0 flex-1 break-all text-xs font-semibold leading-5 text-slate-600">
                                                                {
                                                                    member.email
                                                                }
                                                            </span>
                                                        </div>
                                                    ),
                                                },
                                            ]}
                                        />
                                    </div>
                                ),
                            )}
                        </div>
                    )}
                </main>
            </div>

            <UserLog
                open={
                    activityDrawerOpen
                }
                user={
                    activityMember
                }
                onClose={
                    handleCloseActivityLog
                }
            />

            <OffCanvas
                isOpen={
                    isAddOpen
                }
                onClose={
                    handleCloseForm
                }
                title={
                    selectedMember
                        ? "Edit User"
                        : "Add User"
                }
                subtitle={
                    selectedMember
                        ? "Update user details and access"
                        : "Invite a user and configure their access"
                }
            >
                <AddMemberForm
                    member={
                        selectedMember
                    }
                    onSubmit={
                        handleSaveMember
                    }
                    onCancel={
                        handleCloseForm
                    }
                />
            </OffCanvas>
        </>
    );
}
