import { useCallback, useEffect, useMemo, useState } from "react";
import {
  CheckIcon,
  FloppyDiskBackIcon,
  PlusIcon,
  ShieldIcon,
  TrashIcon,
  XIcon,
} from "@phosphor-icons/react";
import ConfirmModal from "../../components/ConfirmModal";
import Button from "../../components/Button";
import Field from "../../components/Field";
import api from "../../api/axios";

type PermissionActions = {
  view: boolean;
  add: boolean;
  edit: boolean;
  delete: boolean;
};

const PERMISSION_ACTIONS = [
  "view",
  "add",
  "edit",
  "delete",
] as const;

type PermissionAction =
  (typeof PERMISSION_ACTIONS)[number];

function isActionSupported(
  permission: RolePermission,
  action: PermissionAction,
): boolean {
  return permission.supportedActions?.[action] === true;
}

function isAllSelected(
  permission: RolePermission,
): boolean {
  const supported = permission.supportedActions ?? {
    view: false,
    add: false,
    edit: false,
    delete: false,
  };

  const actions = permission.actions ?? {
    view: false,
    add: false,
    edit: false,
    delete: false,
  };

  const supportedCount = PERMISSION_ACTIONS.filter(
    (action) => supported[action],
  ).length;

  if (supportedCount === 0) {
    return false;
  }

  return PERMISSION_ACTIONS.every(
    (action) => !supported[action] || actions[action] === true,
  );
}

type RolePermission = {
  id: string;
  key: string;
  name: string;
  description: string;
  category: string;
  sortOrder: number;
  system: boolean;
  active: boolean;
  supportedActions: PermissionActions;
  actions: PermissionActions;
  all: boolean;
};

interface Role {
  id: string;
  key: string;
  name: string;
  description: string;
  members: number;
  active: boolean;
  system: boolean;
  ownerRole: boolean;
  realm: string;
  allowedUserTypes: string[];
  permissions: Record<string, RolePermission>;
}

type ApiError = {
  response?: {
    data?: {
      message?: string;
    };
  };
};

function getApiErrorMessage(error: unknown, fallback: string): string {
  const message = (error as ApiError)?.response?.data?.message;
  return typeof message === "string" && message.trim()
    ? message.trim()
    : fallback;
}

function toPermissionMap(
  permissions: RolePermission[],
): Record<string, RolePermission> {
  return permissions.reduce<Record<string, RolePermission>>((acc, permission) => {
    acc[permission.key] = permission;
    return acc;
  }, {});
}

function normalizeRoles(payload: unknown): Role[] {
  const root = payload as
    | {
        data?:
          | Array<{
              id: string;
              key: string;
              name: string;
              description?: string;
              members?: number;
              active?: boolean;
              system?: boolean;
              ownerRole?: boolean;
              realm?: string;
              allowedUserTypes?: string[];
            }>
          | {
              data?: Array<{
                id: string;
                key: string;
                name: string;
                description?: string;
                members?: number;
                active?: boolean;
                system?: boolean;
                ownerRole?: boolean;
                realm?: string;
                allowedUserTypes?: string[];
              }>;
            };
      }
    | undefined;

  const rawRoles = Array.isArray(root?.data)
    ? root.data
    : root?.data && Array.isArray(root.data.data)
      ? root.data.data
      : [];

  return rawRoles.map((role) => ({
    id: String(role.id),
    key: role.key,
    name: role.name,
    description: role.description ?? "",
    members: Number(role.members ?? 0),
    active: role.active !== false,
    system: role.system === true,
    ownerRole: role.ownerRole === true,
    realm: role.realm ?? "internal",
    allowedUserTypes: Array.isArray(role.allowedUserTypes)
      ? role.allowedUserTypes
      : [],
    permissions: {},
  }));
}

export default function RolesPermissions() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [selectedRoleId, setSelectedRoleId] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [creating, setCreating] = useState(false);
  const [loadingRolePermissions, setLoadingRolePermissions] = useState(false);
  const [showRoleForm, setShowRoleForm] = useState(false);
  const [deleteRole, setDeleteRole] = useState<Role | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [successMessage, setSuccessMessage] = useState<string>("");
  const [roleForm, setRoleForm] = useState({
    name: "",
    description: "",
  });

  const selectedRole = roles.find(
    (role) => role.id === selectedRoleId,
  );

  const permissionRows = useMemo(
    () => Object.values(selectedRole?.permissions ?? {}),
    [selectedRole],
  );

  const showError = useCallback((message: string) => {
    setErrorMessage(message);
    setSuccessMessage("");
  }, []);

  const showSuccess = useCallback((message: string) => {
    setSuccessMessage(message);
    setErrorMessage("");
  }, []);

  const clearError = useCallback(() => {
    setErrorMessage("");
  }, []);

  const clearSuccess = useCallback(() => {
    setSuccessMessage("");
  }, []);

  const loadRolePermissions = useCallback(async (roleId: string) => {
    if (!roleId) {
      return;
    }

    setLoadingRolePermissions(true);
    try {
      const response = await api.get(`/settings/roles/${roleId}/permissions`);
      const matrix = response.data?.data;
      const permissions = Array.isArray(matrix?.permissions)
        ? (matrix.permissions as RolePermission[])
        : [];

      setRoles((previous) =>
        previous.map((role) =>
          role.id === roleId
            ? {
                ...role,
                ...(matrix?.role ?? {}),
                id: String(matrix?.role?.id ?? role.id),
                permissions: toPermissionMap(permissions),
              }
            : role,
        ),
      );
    } catch (error) {
      showError(
        getApiErrorMessage(
          error,
          "Unable to load permissions for the selected role.",
        ),
      );
    } finally {
      setLoadingRolePermissions(false);
    }
  }, [showError]);

  const loadRoles = useCallback(async () => {
    setLoading(true);
    clearError();
    try {
      const [rolesResponse] = await Promise.all([
        api.get("/settings/roles", {
          params: {
            active: true,
            page: 1,
            limit: 100,
          },
        }),
      ]);

      const nextRoles = normalizeRoles(rolesResponse.data);
      setRoles(nextRoles);

      if (nextRoles.length === 0) {
        setSelectedRoleId("");
        return;
      }

      const currentSelected = nextRoles.find(
        (role) => role.id === selectedRoleId,
      );
      const nextSelectedId = currentSelected?.id ?? nextRoles[0].id;
      setSelectedRoleId(nextSelectedId);

    } catch (error) {
      showError(
        getApiErrorMessage(
          error,
          "Unable to load roles and permissions.",
        ),
      );
    } finally {
      setLoading(false);
    }
  }, [clearError, loadRolePermissions, selectedRoleId, showError]);

  useEffect(() => {
    void loadRoles();
    // Initial load only. Role changes load their matrix separately.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedRoleId || loading) {
      return;
    }

    void loadRolePermissions(selectedRoleId);
  }, [loadRolePermissions, selectedRoleId, loading]);

  const updatePermission = (
    permissionKey: string,
    permission: keyof PermissionActions,
  ) => {
    if (!selectedRole) {
      return;
    }

    if (selectedRole.ownerRole) {
      showError("Workspace Owner permissions are protected.");
      return;
    }

    clearSuccess();

    const currentPermission = selectedRole.permissions[permissionKey];
    if (!currentPermission || !isActionSupported(currentPermission, permission)) {
      return;
    }

    setRoles((previous) =>
      previous.map((role) => {
        if (role.id !== selectedRole.id) {
          return role;
        }

        const permissionRow = role.permissions[permissionKey];
        return {
          ...role,
          permissions: {
            ...role.permissions,
            [permissionKey]: {
              ...permissionRow,
              actions: {
                ...permissionRow.actions,
                [permission]: !permissionRow.actions[permission],
              },
              all: isAllSelected({
                ...permissionRow,
                actions: {
                  ...permissionRow.actions,
                  [permission]: !permissionRow.actions[permission],
                },
              }),
            },
          },
        };
      }),
    );
  };

  const toggleModulePermissions = (permissionKey: string) => {
    if (!selectedRole) {
      return;
    }

    if (selectedRole.ownerRole) {
      showError("Workspace Owner permissions are protected.");
      return;
    }

    clearSuccess();

    setRoles((previous) =>
      previous.map((role) => {
        if (role.id !== selectedRole.id) {
          return role;
        }

        const permission = role.permissions[permissionKey];
        if (!permission) {
          return role;
        }

        const supported = permission.supportedActions;
        const supportedCount = PERMISSION_ACTIONS.filter(
          (action) => supported?.[action] === true,
        ).length;

        if (supportedCount === 0) {
          return role;
        }

        const allSelected = isAllSelected(permission);
        const nextValue = !allSelected;
        const actions = {
          view: supported.view ? nextValue : false,
          add: supported.add ? nextValue : false,
          edit: supported.edit ? nextValue : false,
          delete: supported.delete ? nextValue : false,
        };

        return {
          ...role,
          permissions: {
            ...role.permissions,
            [permissionKey]: {
              ...permission,
              actions,
              all: nextValue,
            },
          },
        };
      }),
    );
  };

  const addRole = async () => {
    if (!roleForm.name.trim() || creating) {
      return;
    }

    setCreating(true);
    try {
      const response = await api.post("/settings/roles", {
        name: roleForm.name.trim(),
        description: roleForm.description.trim(),
        realm: "both",
        allowedUserTypes: ["admin", "internal"],
      });

      const created = response.data?.data as {
        id: string;
        key: string;
        name: string;
        description?: string;
        members?: number;
        active?: boolean;
        system?: boolean;
        ownerRole?: boolean;
        realm?: string;
        allowedUserTypes?: string[];
      } | undefined;

      if (!created?.id) {
        throw new Error("Role creation returned an invalid response.");
      }

      const newRole: Role = {
        id: String(created.id),
        key: created.key,
        name: created.name,
        description: created.description ?? "",
        members: Number(created.members ?? 0),
        active: created.active !== false,
        system: created.system === true,
        ownerRole: created.ownerRole === true,
        realm: created.realm ?? "both",
        allowedUserTypes: Array.isArray(created.allowedUserTypes)
          ? created.allowedUserTypes
          : ["admin", "internal"],
        permissions: {},
      };

      setRoles((previous) => [...previous, newRole]);
      setSelectedRoleId(newRole.id);
      setRoleForm({ name: "", description: "" });
      setShowRoleForm(false);
      showSuccess(
        "Role created successfully.",
      );
    } catch (error) {
      showError(
        getApiErrorMessage(error, "Unable to create the role."),
      );
    } finally {
      setCreating(false);
    }
  };

  const openDeleteModal = (role: Role) => {
    setDeleteRole(role);
  };

  const closeDeleteModal = () => {
    if (!deleteLoading) {
      setDeleteRole(null);
    }
  };

  const confirmDelete = async () => {
    if (!deleteRole || deleteLoading) {
      return;
    }

    if (deleteRole.system || deleteRole.ownerRole) {
      showError("System roles cannot be deleted.");
      return;
    }

    setDeleteLoading(true);
    try {
      await api.delete(`/settings/roles/${deleteRole.id}`);

      const remaining = roles.filter(
        (role) => role.id !== deleteRole.id,
      );
      setRoles(remaining);
      setDeleteRole(null);

      const nextRole = remaining[0];
      setSelectedRoleId(nextRole?.id ?? "");
      showSuccess(
        "Role deleted successfully.",
      );
    } catch (error) {
      showError(
        getApiErrorMessage(error, "Unable to delete the role."),
      );
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleSave = async () => {
    if (!selectedRole || saving) {
      return;
    }

    if (selectedRole.ownerRole) {
      showError("Workspace Owner permissions are protected.");
      return;
    }

    const assignments = Object.values(selectedRole.permissions)
      .filter((permission) =>
        permission.supportedActions.view ||
        permission.supportedActions.add ||
        permission.supportedActions.edit ||
        permission.supportedActions.delete,
      )
      .filter((permission) =>
        permission.actions.view ||
        permission.actions.add ||
        permission.actions.edit ||
        permission.actions.delete,
      )
      .map((permission) => ({
        permissionId: permission.id,
        actions: permission.actions,
      }));

    setSaving(true);
    try {
      const response = await api.put(
        `/settings/roles/${selectedRole.id}/permissions`,
        { assignments },
      );

      if (
        response.data?.success === false
      ) {
        throw new Error(
          response.data?.message ||
            "Unable to save role permissions.",
        );
      }

      const matrix = response.data?.data;

      if (
        !matrix ||
        !Array.isArray(
          matrix.permissions,
        )
      ) {
        throw new Error(
          "Role permissions were saved, but the server returned an invalid matrix response.",
        );
      }
      const permissions = Array.isArray(matrix?.permissions)
        ? (matrix.permissions as RolePermission[])
        : [];

      setRoles((previous) =>
        previous.map((role) =>
          role.id === selectedRole.id
            ? {
                ...role,
                ...(matrix?.role ?? {}),
                permissions: toPermissionMap(permissions),
              }
            : role,
        ),
      );

      showSuccess(
        "Role permissions updated successfully.",
      );
    } catch (error) {
      showError(
        getApiErrorMessage(
          error,
          "Unable to save role permissions.",
        ),
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
        <div className="flex items-start gap-4">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
            <ShieldIcon size={20} />
          </div>

          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Roles & Permissions
            </h2>
          </div>
        </div>

        <Button
          onClick={() => setShowRoleForm(true)}
        >
          <PlusIcon size={17} />
          Add Role
        </Button>
      </div>

      {errorMessage && (
        <div
          role="alert"
          className="mt-4 flex items-start justify-between gap-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
        >
          <div>
            <p className="font-semibold">Unable to complete the request</p>
            <p className="mt-1 text-red-600">{errorMessage}</p>
          </div>
          <button
            type="button"
            onClick={clearError}
            className="shrink-0 text-red-500 hover:text-red-700"
            aria-label="Dismiss error"
          >
            <XIcon size={18} />
          </button>
        </div>
      )}

      {successMessage && (
        <div
          role="status"
          className="mt-4 flex items-start justify-between gap-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700"
        >
          <div>
            <p className="font-semibold">
              Update successful
            </p>
            <p className="mt-1 text-emerald-600">
              {successMessage}
            </p>
          </div>

          <button
            type="button"
            onClick={clearSuccess}
            className="shrink-0 text-emerald-500 hover:text-emerald-700"
            aria-label="Dismiss success message"
          >
            <XIcon size={18} />
          </button>
        </div>
      )}

      {/* Add Role Form */}
      {showRoleForm && (
        <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-800">
                Add New Role
              </h3>

              <p className="mt-1 text-xs text-slate-500">
                Create a role and configure its permissions.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowRoleForm(false)}
              className="text-slate-400 hover:text-slate-700"
            >
              <XIcon size={18} />
            </button>
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <Field
              label="Role Name"
              placeholder="e.g. Project Manager"
              value={roleForm.name}
              onChange={(e) =>
                setRoleForm((prev) => ({
                  ...prev,
                  name: e.target.value,
                }))
              }
            />

            <Field
              label="Description"
              placeholder="Describe this role"
              value={roleForm.description}
              onChange={(e) =>
                setRoleForm((prev) => ({
                  ...prev,
                  description: e.target.value,
                }))
              }
            />
          </div>

          <div className="mt-5 flex justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => setShowRoleForm(false)}
            >
              Cancel
            </Button>

            <Button
            onClick={addRole}
            disabled={creating || !roleForm.name.trim()}
          >
              <PlusIcon size={16} />
              Create Role
            </Button>
          </div>
        </div>
      )}

      {/* Roles */}
      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[280px_1fr]">

        {/* Role List */}
        <div className="overflow-hidden rounded-xl border border-slate-200">
          <div className="border-b border-slate-200 bg-slate-50 px-4 py-3">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              Roles
            </h3>
          </div>

          <div className="divide-y divide-slate-100">
            {roles.map((role) => (
              <button
                key={role.id}
                type="button"
                onClick={() =>
                  setSelectedRoleId(role.id)
                }
                className={`w-full px-4 py-4 text-left transition-colors ${selectedRoleId === role.id
                  ? "bg-red-50"
                  : "hover:bg-slate-50"
                  }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p
                      className={`truncate text-sm font-semibold ${selectedRoleId === role.id
                        ? "text-red-600"
                        : "text-slate-800"
                        }`}
                    >
                      {role.name}
                    </p>

                    <p className="mt-1 line-clamp-2 text-xs text-slate-400">
                      {role.description}
                    </p>

                    <p className="mt-2 text-xs text-slate-500">
                      {role.members}{" "}
                      {role.members === 1
                        ? "member"
                        : "members"}
                    </p>
                  </div>

                  {selectedRoleId === role.id && (
                    <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-red-600" />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Permissions */}
        {selectedRole && (
          <div className="min-w-0">
            <div className="mb-4">
              <h3 className="text-base font-bold text-slate-900">
                {selectedRole.name}
              </h3>

              <p className="mt-1 text-sm text-slate-500">
                {selectedRole.description}
              </p>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full min-w-[650px] text-left text-sm">
                <thead>
                  <tr className="bg-slate-50 text-xs font-semibold uppercase tracking-wide text-slate-400">
                    <th className="px-4 py-3">
                      Module
                    </th>

                    <th className="px-4 py-3 text-center">
                      View
                    </th>

                    <th className="px-4 py-3 text-center">
                      Add
                    </th>

                    <th className="px-4 py-3 text-center">
                      Edit
                    </th>

                    <th className="px-4 py-3 text-center">
                      Delete
                    </th>

                    <th className="px-4 py-3 text-center">
                      All
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {permissionRows.map((module) => {
                    const permission = module;

                    const allSelected = isAllSelected(permission);

                    return (
                      <tr key={module.key}>
                        <td className="px-4 py-3.5 font-medium text-slate-800">
                          {module.name}
                        </td>

                        {(
                          [
                            "view",
                            "add",
                            "edit",
                            "delete",
                          ] as const
                        ).map((action) => (
                          <td
                            key={action}
                            className="px-4 py-3.5 text-center"
                          >
                            <button
                              type="button"
                              disabled={
                                selectedRole.ownerRole ||
                                !isActionSupported(permission, action) ||
                                loadingRolePermissions ||
                                saving
                              }
                              onClick={() =>
                                updatePermission(
                                  module.key,
                                  action
                                )
                              }
                              aria-label={`${module.name} ${action} permission`}
                              aria-pressed={
                                permission.actions[action] === true
                              }
                              className={`mx-auto flex h-6 w-6 items-center justify-center rounded-md border transition-colors ${
                                !isActionSupported(permission, action)
                                  ? "cursor-not-allowed border-slate-200 bg-slate-50 text-transparent"
                                  : permission.actions[action]
                                    ? "border-red-600 bg-red-600 text-white"
                                    : "border-slate-300 bg-white text-transparent hover:border-red-400"
                              }`}
                            >
                              <CheckIcon
                                size={14}
                                weight="bold"
                              />
                            </button>
                          </td>
                        ))}

                        <td className="px-4 py-3.5 text-center">
                          <button
                            type="button"
                            disabled={
                              selectedRole.ownerRole ||
                              !PERMISSION_ACTIONS.some(
                                (action) =>
                                  permission.supportedActions?.[action] === true,
                              ) ||
                              loadingRolePermissions ||
                              saving
                            }
                            onClick={() =>
                              toggleModulePermissions(
                                module.key
                              )
                            }
                            aria-label={`${module.name} all permissions`}
                            aria-pressed={allSelected}
                            className={`mx-auto flex h-6 w-6 items-center justify-center rounded-md border transition-colors ${
                              !PERMISSION_ACTIONS.some(
                                (action) =>
                                  permission.supportedActions?.[action] === true,
                              )
                                ? "cursor-not-allowed border-slate-200 bg-slate-50 text-transparent"
                                : allSelected
                                  ? "border-red-600 bg-red-600 text-white"
                                  : "border-slate-300 bg-white text-transparent hover:border-red-400"
                            }`}
                          >
                            <CheckIcon
                              size={14}
                              weight="bold"
                            />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Delete Role */}
            {selectedRole.name !== "Workspace Owner" && (
              <div className="mt-4 flex justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => openDeleteModal(selectedRole)}
                >
                  <TrashIcon size={16} className="text-red-600" />
                  Delete Role
                </Button>
                <Button onClick={handleSave} disabled={saving || loadingRolePermissions}>
                  <FloppyDiskBackIcon size={16} />
                  Save Changes
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      <ConfirmModal
        open={Boolean(deleteRole)}
        title="Delete Role"
        message={
          deleteRole
            ? `Are you sure you want to delete \"${deleteRole.name}\"? This role will be deactivated and cannot be assigned to new users.`
            : undefined
        }
        onConfirm={confirmDelete}
        onCancel={closeDeleteModal}
        loading={deleteLoading}
      />

    </div>
  );
}