import { useCallback, useEffect, useState } from "react";
import {
    EyeIcon,
    EyeSlashIcon,
    FloppyDiskBackIcon,
    KeyIcon,
    PencilSimpleIcon,
    PlusIcon,
    TrashIcon,
    XIcon,
    WarningCircleIcon,
    CheckCircleIcon,
    XCircleIcon,
    SpinnerGapIcon,
} from "@phosphor-icons/react";

import ConfirmModal from "../../components/ConfirmModal";
import Field from "../../components/Field";
import Button from "../../components/Button";
import api, {
    getApiErrorMessage,
} from "../../api/axios";

/*
|--------------------------------------------------------------------------
| API Contract
|--------------------------------------------------------------------------
*/

interface ApiConfig {
    id: string;
    label: string;
    code?: string | null;
    baseUrl?: string | null;
    key: string;
    keyLast4?: string;
    description: string;
    active: boolean;
    system?: boolean;
    sortOrder?: number;
    createdAt?: string | null;
    updatedAt?: string | null;
}

interface ApiResponse<T = unknown> {
    success?: boolean;
    message?: string;
    code?: string;
    data?: T;
    pagination?: {
        page?: number;
        limit?: number;
        total?: number;
        totalPages?: number;
    };
}

interface FormState {
    label: string;
    key: string;
    description: string;
}

type ToastState = {
    type: "success" | "error" | null;
    message: string;
};

const ENDPOINT =
    "/settings/api-configurations";

const EMPTY_FORM: FormState = {
    label: "",
    key: "",
    description: "",
};

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function extractData<T>(
    response: ApiResponse<T>,
): T | undefined {
    return response?.data;
}

function normalizeApiConfig(
    value: unknown,
): ApiConfig | null {
    if (
        !value ||
        typeof value !== "object"
    ) {
        return null;
    }

    const item =
        value as Record<
            string,
            unknown
        >;

    const id =
        String(
            item.id ??
                item._id ??
                "",
        ).trim();

    if (!id) {
        return null;
    }

    return {
        id,

        label:
            String(
                item.label ??
                    item.name ??
                    "",
            ),

        code:
            item.code == null
                ? null
                : String(
                      item.code,
                  ),

        baseUrl:
            item.baseUrl == null
                ? null
                : String(
                      item.baseUrl,
                  ),

        key:
            String(
                item.key ??
                    "••••••••••••",
            ),

        keyLast4:
            item.keyLast4
                ? String(
                      item.keyLast4,
                  )
                : "",

        description:
            String(
                item.description ??
                    "",
            ),

        active:
            item.active ===
            true,

        system:
            item.system ===
            true,

        sortOrder:
            typeof item.sortOrder ===
            "number"
                ? item.sortOrder
                : undefined,

        createdAt:
            item.createdAt
                ? String(
                      item.createdAt,
                  )
                : null,

        updatedAt:
            item.updatedAt
                ? String(
                      item.updatedAt,
                  )
                : null,
    };
}

function extractConfigs(
    response: ApiResponse<
        unknown[]
    >,
): ApiConfig[] {
    const source =
        Array.isArray(
            response?.data,
        )
            ? response.data
            : [];

    return source
        .map(
            normalizeApiConfig,
        )
        .filter(
            (
                item,
            ): item is ApiConfig =>
                item !== null,
        );
}

/*
|--------------------------------------------------------------------------
| Component
|--------------------------------------------------------------------------
*/

export default function ApiConfigurations() {
    const [
        apiConfigs,
        setApiConfigs,
    ] = useState<ApiConfig[]>(
        [],
    );

    const [
        showForm,
        setShowForm,
    ] = useState(false);

    const [
        editingId,
        setEditingId,
    ] = useState<string | null>(
        null,
    );

    const [
        deleteId,
        setDeleteId,
    ] = useState<string | null>(
        null,
    );

    const [
        visibleKeys,
        setVisibleKeys,
    ] = useState<string[]>(
        [],
    );

    const [
        form,
        setForm,
    ] = useState<FormState>(
        EMPTY_FORM,
    );

    const [
        loading,
        setLoading,
    ] = useState(true);

    const [
        saving,
        setSaving,
    ] = useState(false);

    const [
        deleting,
        setDeleting,
    ] = useState(false);

    const [
        togglingId,
        setTogglingId,
    ] = useState<string | null>(
        null,
    );

    const [
        error,
        setError,
    ] = useState("");

    const [
        fieldError,
        setFieldError,
    ] = useState("");

    const [
        toast,
        setToast,
    ] = useState<ToastState>({
        type: null,
        message: "",
    });

    /*
    |--------------------------------------------------------------------------
    | Toast
    |--------------------------------------------------------------------------
    */

    const showToast =
        useCallback(
            (
                type:
                    | "success"
                    | "error",
                message: string,
            ) => {
                setToast({
                    type,
                    message,
                });

                window.setTimeout(
                    () => {
                        setToast(
                            (
                                previous,
                            ) =>
                                previous.message ===
                                message
                                    ? {
                                          type:
                                              null,
                                          message:
                                              "",
                                      }
                                    : previous,
                        );
                    },
                    3500,
                );
            },
            [],
        );

    /*
    |--------------------------------------------------------------------------
    | Load
    |--------------------------------------------------------------------------
    */

    const loadApiConfigs =
        useCallback(
            async () => {
                setLoading(
                    true,
                );

                setError("");

                try {
                    const response =
                        await api.get<
                            ApiResponse<
                                unknown[]
                            >
                        >(
                            ENDPOINT,
                            {
                                params: {
                                    page: 1,
                                    limit: 100,
                                    sort: "sortOrder",
                                    sortOrder:
                                        "asc",
                                },
                            },
                        );

                    setApiConfigs(
                        extractConfigs(
                            response.data,
                        ),
                    );
                } catch (loadError) {
                    const message =
                        getApiErrorMessage(
                            loadError,
                            "Unable to load API configurations.",
                        );

                    setError(
                        message,
                    );

                    setApiConfigs(
                        [],
                    );
                } finally {
                    setLoading(
                        false,
                    );
                }
            },
            [],
        );

    useEffect(() => {
        void loadApiConfigs();
    }, [loadApiConfigs]);

    /*
    |--------------------------------------------------------------------------
    | Form Helpers
    |--------------------------------------------------------------------------
    */

    const updateForm = (
        field: keyof FormState,
        value: string,
    ) => {
        setForm(
            (
                previous,
            ) => ({
                ...previous,
                [field]:
                    value,
            }),
        );

        setFieldError("");
    };

    const resetForm =
        useCallback(() => {
            setShowForm(
                false,
            );

            setEditingId(
                null,
            );

            setForm({
                ...EMPTY_FORM,
            });

            setFieldError("");
        }, []);

    const openAddForm =
        () => {
            setEditingId(
                null,
            );

            setForm({
                ...EMPTY_FORM,
            });

            setFieldError("");
            setError("");
            setShowForm(
                true,
            );
        };

    const openEditForm = (
        configuration: ApiConfig,
    ) => {
        /*
         * IMPORTANT:
         *
         * The backend deliberately returns only a masked API key.
         * Never place that masked value into the editable secret field,
         * otherwise saving without a new key would overwrite the real
         * credential with the mask.
         *
         * Blank key therefore means:
         *   "keep existing secret".
         */
        setEditingId(
            configuration.id,
        );

        setForm({
            label:
                configuration.label,

            key: "",

            description:
                configuration.description,
        });

        setFieldError("");
        setError("");
        setShowForm(
            true,
        );
    };

    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    const validateForm =
        useCallback(() => {
            const label =
                form.label.trim();

            const key =
                form.key.trim();

            const description =
                form.description.trim();

            if (!label) {
                setFieldError(
                    "API label is required.",
                );
                return false;
            }

            if (
                label.length >
                150
            ) {
                setFieldError(
                    "API label cannot exceed 150 characters.",
                );
                return false;
            }

            if (
                !editingId &&
                !key
            ) {
                setFieldError(
                    "API key is required when adding a new configuration.",
                );
                return false;
            }

            if (
                key.length >
                4000
            ) {
                setFieldError(
                    "API key is too long.",
                );
                return false;
            }

            if (
                description.length >
                1000
            ) {
                setFieldError(
                    "Description cannot exceed 1000 characters.",
                );
                return false;
            }

            /*
             * Prevent obvious duplicate labels in the UI.
             * Backend still remains the authority.
             */
            const duplicate =
                apiConfigs.some(
                    (
                        item,
                    ) =>
                        item.label
                            .trim()
                            .toLowerCase() ===
                            label.toLowerCase() &&
                        item.id !==
                            editingId,
                );

            if (
                duplicate
            ) {
                setFieldError(
                    "An API configuration with this label already exists.",
                );
                return false;
            }

            return true;
        }, [
            apiConfigs,
            editingId,
            form,
        ]);

    /*
    |--------------------------------------------------------------------------
    | Save
    |--------------------------------------------------------------------------
    */

    const handleSave =
        async () => {
            if (
                saving ||
                !validateForm()
            ) {
                return;
            }

            setSaving(
                true,
            );

            setFieldError("");
            setError("");

            try {
                /*
                 * API Configuration backend contract accepts:
                 *
                 *   label
                 *   key
                 *   description
                 *
                 * Sending no key during edit preserves the current
                 * credential according to updateApiConfiguration().
                 */
                const payload: Record<
                    string,
                    unknown
                > = {
                    label:
                        form.label.trim(),

                    description:
                        form.description.trim(),
                };

                if (
                    form.key.trim()
                ) {
                    payload.key =
                        form.key.trim();
                }

                if (
                    editingId
                ) {
                    const response =
                        await api.patch<
                            ApiResponse<unknown>
                        >(
                            `${ENDPOINT}/${encodeURIComponent(
                                editingId,
                            )}`,
                            payload,
                        );

                    const updated =
                        normalizeApiConfig(
                            extractData(
                                response.data,
                            ),
                        );

                    if (
                        updated
                    ) {
                        setApiConfigs(
                            (
                                previous,
                            ) =>
                                previous.map(
                                    (
                                        item,
                                    ) =>
                                        item.id ===
                                        updated.id
                                            ? updated
                                            : item,
                                ),
                        );
                    } else {
                        await loadApiConfigs();
                    }

                    showToast(
                        "success",
                        response
                            .data
                            ?.message ||
                            "API configuration updated successfully.",
                    );
                } else {
                    const response =
                        await api.post<
                            ApiResponse<unknown>
                        >(
                            ENDPOINT,
                            {
                                ...payload,
                                key:
                                    form.key.trim(),
                                active:
                                    true,
                            },
                        );

                    const created =
                        normalizeApiConfig(
                            extractData(
                                response.data,
                            ),
                        );

                    if (
                        created
                    ) {
                        setApiConfigs(
                            (
                                previous,
                            ) => [
                                ...previous,
                                created,
                            ],
                        );
                    } else {
                        await loadApiConfigs();
                    }

                    showToast(
                        "success",
                        response
                            .data
                            ?.message ||
                            "API configuration created successfully.",
                    );
                }

                resetForm();
            } catch (saveError) {
                const message =
                    getApiErrorMessage(
                        saveError,
                        editingId
                            ? "Unable to update API configuration."
                            : "Unable to create API configuration.",
                    );

                setFieldError(
                    message,
                );
            } finally {
                setSaving(
                    false,
                );
            }
        };

    /*
    |--------------------------------------------------------------------------
    | Delete
    |--------------------------------------------------------------------------
    */

    const openDeleteModal =
        (id: string) => {
            const target =
                apiConfigs.find(
                    (
                        item,
                    ) =>
                        item.id ===
                        id,
                );

            if (
                target?.system
            ) {
                showToast(
                    "error",
                    "System API configurations cannot be deleted.",
                );
                return;
            }

            setDeleteId(
                id,
            );
        };

    const closeDeleteModal =
        () => {
            if (
                deleting
            ) {
                return;
            }

            setDeleteId(
                null,
            );
        };

    const confirmDelete =
        async () => {
            if (
                !deleteId ||
                deleting
            ) {
                return;
            }

            const target =
                apiConfigs.find(
                    (
                        item,
                    ) =>
                        item.id ===
                        deleteId,
                );

            if (
                target?.system
            ) {
                setDeleteId(
                    null,
                );

                showToast(
                    "error",
                    "System API configurations cannot be deleted.",
                );

                return;
            }

            setDeleting(
                true,
            );

            try {
                const response =
                    await api.delete<
                        ApiResponse<unknown>
                    >(
                        `${ENDPOINT}/${encodeURIComponent(
                            deleteId,
                        )}`,
                    );

                setApiConfigs(
                    (
                        previous,
                    ) =>
                        previous.filter(
                            (
                                item,
                            ) =>
                                item.id !==
                                deleteId,
                        ),
                );

                setVisibleKeys(
                    (
                        previous,
                    ) =>
                        previous.filter(
                            (
                                item,
                            ) =>
                                item !==
                                deleteId,
                        ),
                );

                setDeleteId(
                    null,
                );

                showToast(
                    "success",
                    response
                        .data
                        ?.message ||
                        "API configuration deleted successfully.",
                );
            } catch (deleteError) {
                showToast(
                    "error",
                    getApiErrorMessage(
                        deleteError,
                        "Unable to delete API configuration.",
                    ),
                );
            } finally {
                setDeleting(
                    false,
                );
            }
        };

    /*
    |--------------------------------------------------------------------------
    | Status
    |--------------------------------------------------------------------------
    */

    const toggleStatus =
        async (
            id: string,
        ) => {
            if (
                togglingId ===
                id
            ) {
                return;
            }

            const configuration =
                apiConfigs.find(
                    (
                        item,
                    ) =>
                        item.id ===
                        id,
                );

            if (
                !configuration
            ) {
                return;
            }

            const nextActive =
                !configuration.active;

            setApiConfigs(
                (
                    previous,
                ) =>
                    previous.map(
                        (
                            item,
                        ) =>
                            item.id ===
                            id
                                ? {
                                      ...item,
                                      active:
                                          nextActive,
                                  }
                                : item,
                    ),
            );

            setTogglingId(
                id,
            );

            try {
                const response =
                    await api.patch<
                        ApiResponse<unknown>
                    >(
                        `${ENDPOINT}/${encodeURIComponent(
                            id,
                        )}/status`,
                        {
                            active:
                                nextActive,
                        },
                    );

                const updated =
                    normalizeApiConfig(
                        extractData(
                            response.data,
                        ),
                    );

                if (
                    updated
                ) {
                    setApiConfigs(
                        (
                            previous,
                        ) =>
                            previous.map(
                                (
                                    item,
                                ) =>
                                    item.id ===
                                    updated.id
                                        ? updated
                                        : item,
                            ),
                    );
                }

                showToast(
                    "success",
                    response
                        .data
                        ?.message ||
                        "API configuration status updated successfully.",
                );
            } catch (statusError) {
                /*
                 * Roll back optimistic update.
                 */
                setApiConfigs(
                    (
                        previous,
                    ) =>
                        previous.map(
                            (
                                item,
                            ) =>
                                item.id ===
                                id
                                    ? {
                                          ...item,
                                          active:
                                              configuration.active,
                                      }
                                    : item,
                        ),
                );

                showToast(
                    "error",
                    getApiErrorMessage(
                        statusError,
                        "Unable to update API configuration status.",
                    ),
                );
            } finally {
                setTogglingId(
                    null,
                );
            }
        };

    /*
    |--------------------------------------------------------------------------
    | Key Visibility
    |--------------------------------------------------------------------------
    |
    | The backend intentionally never returns the plaintext secret from
    | normal list/get endpoints.
    |
    | Therefore:
    |
    |   hidden  -> masked key from backend
    |   visible -> same masked key
    |
    | This avoids creating a client-side secret exposure path.
    |
    |--------------------------------------------------------------------------
    */

    const toggleKeyVisibility =
        (id: string) => {
            setVisibleKeys(
                (
                    previous,
                ) =>
                    previous.includes(
                        id,
                    )
                        ? previous.filter(
                              (
                                  item,
                              ) =>
                                  item !==
                                  id,
                          )
                        : [
                              ...previous,
                              id,
                          ],
            );
        };

    const deleteTarget =
        deleteId
            ? apiConfigs.find(
                  (
                      item,
                  ) =>
                      item.id ===
                      deleteId,
              )
            : null;

    return (
        <>
            <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
                    <div className="flex items-start gap-4">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600">
                            <KeyIcon
                                size={
                                    20
                                }
                            />
                        </div>

                        <div>
                            <h2 className="text-lg font-bold text-slate-900">
                                API Configurations
                            </h2>

                            <p className="mt-1 text-xs text-slate-500">
                                Manage external API credentials used by the platform.
                            </p>
                        </div>
                    </div>

                    <Button
                        onClick={
                            openAddForm
                        }
                        disabled={
                            loading ||
                            saving
                        }
                    >
                        <PlusIcon
                            size={
                                17
                            }
                        />
                        Add API
                    </Button>
                </div>

                {/* Toast */}
                {toast.message && (
                    <div
                        className={`mt-5 flex items-start gap-3 rounded-xl border px-4 py-3 ${
                            toast.type ===
                            "success"
                                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                : "border-red-200 bg-red-50 text-red-700"
                        }`}
                        role="status"
                    >
                        {toast.type ===
                        "success" ? (
                            <CheckCircleIcon
                                size={
                                    18
                                }
                                className="mt-0.5 shrink-0"
                            />
                        ) : (
                            <XCircleIcon
                                size={
                                    18
                                }
                                className="mt-0.5 shrink-0"
                            />
                        )}

                        <span className="text-xs font-semibold">
                            {
                                toast.message
                            }
                        </span>
                    </div>
                )}

                {/* Global Error */}
                {error && (
                    <div className="mt-5 flex items-start justify-between gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
                        <div className="flex items-start gap-2">
                            <WarningCircleIcon
                                size={
                                    18
                                }
                                className="mt-0.5 shrink-0 text-red-600"
                            />

                            <span className="text-xs font-semibold text-red-700">
                                {
                                    error
                                }
                            </span>
                        </div>

                        <button
                            type="button"
                            onClick={() =>
                                setError(
                                    "",
                                )
                            }
                            className="text-red-400 hover:text-red-700"
                            aria-label="Dismiss error"
                        >
                            <XIcon
                                size={
                                    16
                                }
                            />
                        </button>
                    </div>
                )}

                {/* Add / Edit Form */}
                {showForm && (
                    <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-5">
                        <div className="mb-5 flex items-center justify-between">
                            <div>
                                <h3 className="text-sm font-bold text-slate-800">
                                    {editingId
                                        ? "Edit API Configuration"
                                        : "Add API Configuration"}
                                </h3>

                                <p className="mt-1 text-xs text-slate-500">
                                    {editingId
                                        ? "Update the label and description. Enter a new API key only when rotating the credential."
                                        : "Enter the API details below."}
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={
                                    saving
                                        ? undefined
                                        : resetForm
                                }
                                disabled={
                                    saving
                                }
                                className="text-slate-400 transition-colors hover:text-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
                                aria-label="Close API configuration form"
                            >
                                <XIcon
                                    size={
                                        18
                                    }
                                />
                            </button>
                        </div>

                        {fieldError && (
                            <div className="mb-5 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-xs font-semibold text-red-700">
                                {
                                    fieldError
                                }
                            </div>
                        )}

                        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
                            <Field
                                label="API Label"
                                placeholder="e.g. Weather API"
                                value={
                                    form.label
                                }
                                onChange={(
                                    event,
                                ) =>
                                    updateForm(
                                        "label",
                                        event
                                            .target
                                            .value,
                                    )
                                }
                                disabled={
                                    saving
                                }
                            />

                            <Field
                                label="API Key"
                                type="password"
                                placeholder={
                                    editingId
                                        ? "Leave blank to keep existing key"
                                        : "Enter API key"
                                }
                                value={
                                    form.key
                                }
                                onChange={(
                                    event,
                                ) =>
                                    updateForm(
                                        "key",
                                        event
                                            .target
                                            .value,
                                    )
                                }
                                disabled={
                                    saving
                                }
                            />

                            <div className="md:col-span-2">
                                <Field
                                    label="Description"
                                    type="textarea"
                                    rows={
                                        3
                                    }
                                    placeholder="Describe what this API is used for"
                                    value={
                                        form.description
                                    }
                                    onChange={(
                                        event,
                                    ) =>
                                        updateForm(
                                            "description",
                                            event
                                                .target
                                                .value,
                                        )
                                    }
                                    disabled={
                                        saving
                                    }
                                />
                            </div>
                        </div>

                        <div className="mt-5 flex justify-end gap-3">
                            <Button
                                variant="outline"
                                onClick={
                                    resetForm
                                }
                                disabled={
                                    saving
                                }
                            >
                                Cancel
                            </Button>

                            <Button
                                onClick={() =>
                                    void handleSave()
                                }
                                loading={
                                    saving
                                }
                            >
                                <FloppyDiskBackIcon
                                    size={
                                        16
                                    }
                                />

                                {editingId
                                    ? "Update API"
                                    : "Save API"}
                            </Button>
                        </div>
                    </div>
                )}

                {/* API List */}
                <div className="mt-6 space-y-3">
                    {loading ? (
                        <div className="flex min-h-[230px] items-center justify-center rounded-xl border border-slate-200 bg-white">
                            <div className="flex flex-col items-center gap-3">
                                <SpinnerGapIcon
                                    size={
                                        26
                                    }
                                    className="animate-spin text-red-600"
                                />

                                <p className="text-xs font-semibold text-slate-500">
                                    Loading API configurations...
                                </p>
                            </div>
                        </div>
                    ) : apiConfigs.length ===
                      0 ? (
                        <div className="rounded-xl border border-dashed border-slate-300 px-6 py-10 text-center">
                            <KeyIcon
                                size={
                                    28
                                }
                                className="mx-auto text-slate-300"
                            />

                            <p className="mt-3 text-sm font-semibold text-slate-600">
                                No API configurations
                            </p>

                            <p className="mt-1 text-xs text-slate-400">
                                Add an API configuration to get started.
                            </p>
                        </div>
                    ) : (
                        apiConfigs.map(
                            (
                                configuration,
                            ) => {
                                const keyVisible =
                                    visibleKeys.includes(
                                        configuration.id,
                                    );

                                return (
                                    <div
                                        key={
                                            configuration.id
                                        }
                                        className="rounded-xl border border-slate-200 px-5 py-4"
                                    >
                                        <div className="flex items-start justify-between gap-5">
                                            {/* API Information */}
                                            <div className="flex min-w-0 items-start gap-4">
                                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
                                                    <KeyIcon
                                                        size={
                                                            18
                                                        }
                                                    />
                                                </div>

                                                <div className="min-w-0">
                                                    <div className="flex flex-wrap items-center gap-2">
                                                        <p className="text-sm font-semibold text-slate-800">
                                                            {
                                                                configuration.label
                                                            }
                                                        </p>

                                                        <span
                                                            className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                                                                configuration.active
                                                                    ? "bg-green-50 text-green-600"
                                                                    : "bg-slate-100 text-slate-500"
                                                            }`}
                                                        >
                                                            {configuration.active
                                                                ? "Active"
                                                                : "Inactive"}
                                                        </span>

                                                        {configuration.system && (
                                                            <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-500">
                                                                System
                                                            </span>
                                                        )}
                                                    </div>

                                                    <p className="mt-1 text-sm text-slate-500">
                                                        {
                                                            configuration.description
                                                        }
                                                    </p>

                                                    {/* API Key */}
                                                    <div className="mt-3 flex items-center gap-2">
                                                        <code className="rounded-md bg-slate-100 px-2.5 py-1 text-xs text-slate-600">
                                                            {configuration.key ||
                                                                "••••••••••••"}
                                                        </code>

                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                toggleKeyVisibility(
                                                                    configuration.id,
                                                                )
                                                            }
                                                            className="text-slate-400 hover:text-slate-700"
                                                            title={
                                                                keyVisible
                                                                    ? "Hide API key"
                                                                    : "Show API key"
                                                            }
                                                            aria-label={
                                                                keyVisible
                                                                    ? "Hide API key"
                                                                    : "Show API key"
                                                            }
                                                        >
                                                            {keyVisible ? (
                                                                <EyeSlashIcon
                                                                    size={
                                                                        16
                                                                    }
                                                                />
                                                            ) : (
                                                                <EyeIcon
                                                                    size={
                                                                        16
                                                                    }
                                                                />
                                                            )}
                                                        </button>
                                                    </div>

                                                    {keyVisible && (
                                                        <p className="mt-1 text-[10px] text-slate-400">
                                                            Secret values remain masked by the server and are never returned by normal list requests.
                                                        </p>
                                                    )}
                                                </div>
                                            </div>

                                            {/* Actions */}
                                            <div className="flex shrink-0 items-center gap-2">
                                                <Button
                                                    variant={
                                                        configuration.active
                                                            ? "outline"
                                                            : "primary"
                                                    }
                                                    onClick={() =>
                                                        void toggleStatus(
                                                            configuration.id,
                                                        )
                                                    }
                                                    disabled={
                                                        togglingId ===
                                                        configuration.id
                                                    }
                                                >
                                                    {togglingId ===
                                                    configuration.id ? (
                                                        <SpinnerGapIcon
                                                            size={
                                                                15
                                                            }
                                                            className="animate-spin"
                                                        />
                                                    ) : null}

                                                    {configuration.active
                                                        ? "Disable"
                                                        : "Enable"}
                                                </Button>

                                                <Button
                                                    variant="outline"
                                                    onClick={() =>
                                                        openEditForm(
                                                            configuration,
                                                        )
                                                    }
                                                    disabled={
                                                        saving ||
                                                        deleting
                                                    }
                                                    title="Edit API configuration"
                                                >
                                                    <PencilSimpleIcon
                                                        size={
                                                            16
                                                        }
                                                    />
                                                </Button>

                                                <Button
                                                    variant="outline"
                                                    onClick={() =>
                                                        openDeleteModal(
                                                            configuration.id,
                                                        )
                                                    }
                                                    disabled={
                                                        configuration.system ||
                                                        deleting
                                                    }
                                                    title={
                                                        configuration.system
                                                            ? "System API configurations cannot be deleted"
                                                            : "Delete API configuration"
                                                    }
                                                >
                                                    <TrashIcon
                                                        size={
                                                            16
                                                        }
                                                    />
                                                </Button>
                                            </div>
                                        </div>
                                    </div>
                                );
                            },
                        )
                    )}
                </div>
            </div>

            <ConfirmModal
                open={
                    deleteId !==
                    null
                }
                title="Delete API Configuration"
                message={
                    deleteTarget
                        ? `Are you sure you want to delete "${deleteTarget.label}"? This action cannot be undone.`
                        : ""
                }
                confirmText="Delete API"
                onConfirm={() =>
                    void confirmDelete()
                }
                onCancel={
                    closeDeleteModal
                }
                loading={
                    deleting
                }
            />
        </>
    );
}
