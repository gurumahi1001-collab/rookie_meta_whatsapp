@extends('layouts/layoutMaster')
@section('title', 'BookMarks')
@section('content')
@php($module='bookmarks')
@php($title='BookMarks')
<div class="egpk-app" data-egpk-module="{{ $module }}" data-egpk-title="{{ $title }}">
    <div class="egpk-header">
        <div class="egpk-header-main">
            <div class="egpk-title-wrap">
                <span class="egpk-title-icon"><i class="mdi mdi-tools"></i></span>
                <div>
                    <div class="egpk-breadcrumb">Tool Management <span>/</span> Productivity Suite</div>
                    <h1 class="egpk-page-title">{{ $title }}</h1>
                </div>
            </div>
            <div class="egpk-header-actions">
                <button type="button" class="btn btn-light btn-sm egpk-header-btn" id="egpkGlobalSearchBtn">
                    <i class="mdi mdi-magnify"></i><span class="d-none d-md-inline">Search</span>
                </button>
                <button type="button" class="btn btn-light btn-sm egpk-header-btn" id="egpkToolLauncher">
                    <i class="mdi mdi-view-grid-outline"></i><span class="d-none d-md-inline">Tools</span>
                </button>
                <button type="button" class="btn btn-light btn-sm egpk-header-btn position-relative" id="egpkNotificationBtn">
                    <i class="mdi mdi-bell-outline"></i>
                    <span class="egpk-notification-badge d-none" id="egpkNotificationCount">0</span>
                </button>
            </div>
        </div>
    </div>

    <div class="egpk-tool-launcher d-none" id="egpkToolLauncherPanel">
        <div class="egpk-tool-launcher-head">
            <div>
                <div class="egpk-section-kicker">TOOL MANAGEMENT</div>
                <div class="fw-bold">Elysium Productivity Tools</div>
            </div>
            <button type="button" class="btn-close" id="egpkToolLauncherClose"></button>
        </div>
        <div class="egpk-tool-launcher-grid" id="egpkToolLauncherGrid"></div>
    </div>

    <div class="egpk-notification-panel d-none" id="egpkNotificationPanel">
        <div class="egpk-panel-head">
            <div class="fw-bold">Notifications</div>
            <button class="btn btn-link btn-sm p-0" id="egpkNotificationsRead">Mark all read</button>
        </div>
        <div id="egpkNotificationList" class="egpk-notification-list"></div>
    </div>

    <div class="egpk-global-search d-none" id="egpkGlobalSearchPanel">
        <div class="egpk-global-search-inner">
            <div class="input-group">
                <span class="input-group-text bg-white"><i class="mdi mdi-magnify"></i></span>
                <input type="text" id="egpkGlobalSearchInput" class="form-control" placeholder="Search contacts, bookmarks, knowledge, portals...">
                <button type="button" class="btn btn-light" id="egpkGlobalSearchClose"><i class="mdi mdi-close"></i></button>
            </div>
            <div id="egpkGlobalSearchResults" class="egpk-global-results"></div>
        </div>
    </div>

    <div class="egpk-tool-nav-wrap">
        <div class="egpk-tool-nav" id="egpkToolNav"></div>
    </div>

    <div class="egpk-content-shell">
        <div class="egpk-hero">
            <div>
                <div class="egpk-section-kicker">ELYSIUM ERP · TOOL MANAGEMENT</div>
                <h2 id="egpkHeroTitle">{{ $title }}</h2>
                <p id="egpkHeroSubtitle">Shared productivity workspace with company-aware access, global search and governed sharing.</p>
            </div>
            <div id="egpkHeroActions" class="d-flex flex-wrap gap-2"></div>
        </div>

        <div id="egpkStats" class="row g-3 mb-3"></div>

        <div class="egpk-toolbar-card mb-3">
            <div class="row g-2 align-items-center">
                <div class="col-12 col-lg-5">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-white"><i class="mdi mdi-magnify"></i></span>
                        <input type="search" id="egpkSearch" class="form-control" placeholder="Search this tool...">
                        <button type="button" class="btn btn-light" id="egpkSearchClear"><i class="mdi mdi-close"></i></button>
                    </div>
                </div>
                <div class="col-6 col-lg-2">
                    <select id="egpkCompany" class="form-select form-select-sm"><option value="all">All Companies</option></select>
                </div>
                <div class="col-6 col-lg-2" id="egpkFilterSlot"></div>
                <div class="col-12 col-lg-3 d-flex justify-content-lg-end gap-2">
                    <button class="btn btn-outline-secondary btn-sm" id="egpkRefresh"><i class="mdi mdi-refresh"></i> Refresh</button>
                    <div class="btn-group btn-group-sm" id="egpkViewSwitcher"></div>
                </div>
            </div>
        </div>

        <div id="egpkFlash" class="alert d-none mb-3"></div>
        <div id="egpkWorkspace" class="position-relative"></div>
    </div>

    <div class="modal fade" id="egpkFormModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="egpkFormTitle">Create</h5>
                        <div class="small text-muted" id="egpkFormSubtitle"></div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="egpkForm">
                    <div class="modal-body" id="egpkFormBody"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm" id="egpkFormSubmit"><i class="mdi mdi-content-save-outline"></i> Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="egpkViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="egpkViewTitle">Details</h5>
                        <div class="small text-muted" id="egpkViewSubtitle"></div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="egpkViewBody"></div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="egpkShareModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title">Share</h5>
                        <div class="small text-muted">Share with a user, role, company or the whole group.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="egpkShareForm">
                        <input type="hidden" id="egpkShareType">
                        <input type="hidden" id="egpkShareId">
                        <div class="row g-3">
                            <div class="col-md-4"><label class="form-label">Share With</label><select class="form-select" id="egpkShareGranteeType"><option value="user">User</option><option value="role">Role</option><option value="company">Company</option><option value="group">Group</option></select></div>
                            <div class="col-md-4"><label class="form-label">Recipient</label><select class="form-select" id="egpkShareGranteeId"></select></div>
                            <div class="col-md-4"><label class="form-label">Permission</label><select class="form-select" id="egpkSharePermission"><option value="View">View</option><option value="Manage">Manage</option></select></div>
                            <div class="col-md-6"><label class="form-label">Expiry</label><input type="datetime-local" class="form-control" id="egpkShareExpiry"></div>
                        </div>
                    </form>
                    <div class="mt-4"><div class="egpk-section-title">Active / Pending Shares</div><div id="egpkShareList"></div></div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Close</button><button type="button" class="btn btn-primary btn-sm" id="egpkShareSave">Share</button></div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="egpkConfirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="egpkConfirmTitle">Confirm</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body" id="egpkConfirmBody"></div>
            <div class="modal-footer"><button class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button class="btn btn-danger btn-sm" id="egpkConfirmYes">Confirm</button></div>
        </div></div>
    </div>

    <div class="modal fade" id="egpkStepupModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Security Verification</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body"><div class="alert alert-warning py-2 small">Sensitive PassWallet actions require fresh ERP verification.</div><label class="form-label">ERP Password</label><input id="egpkStepupPassword" type="password" autocomplete="current-password" class="form-control"></div>
            <div class="modal-footer"><button class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary btn-sm" id="egpkStepupConfirm">Verify</button></div>
        </div></div>
    </div>

    <div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index:1085">
        <div class="toast" id="egpkToast" role="alert"><div class="toast-body"></div></div>
    </div>
</div>
<style>
:root{
 --egpk-red:#b52b25;--egpk-red-dark:#8f1d1d;--egpk-gold:#f5a623;--egpk-navy:#1f3864;
 --egpk-purple:#4a3e8e;--egpk-bg:#f5f6fa;--egpk-card:#fff;--egpk-border:#e1e5ee;
 --egpk-text:#202533;--egpk-muted:#758099;--egpk-success:#2e7d32;--egpk-warning:#b8860b;
}
.egpk-app{position:relative;color:var(--egpk-text);font-size:13px;background:var(--egpk-bg);min-height:calc(100vh - 70px);padding:10px 12px 22px}
.egpk-header{background:#fff;border:1px solid var(--egpk-border);border-radius:10px;margin-bottom:10px;box-shadow:0 3px 12px rgba(40,50,80,.04)}
.egpk-header-main{min-height:58px;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;gap:12px}
.egpk-title-wrap{display:flex;align-items:center;gap:10px;min-width:0}.egpk-title-icon{width:38px;height:38px;display:grid;place-items:center;border-radius:10px;background:linear-gradient(145deg,var(--egpk-red),var(--egpk-red-dark));color:#fff;box-shadow:0 4px 10px rgba(143,29,29,.18)}
.egpk-title-icon i{font-size:20px}.egpk-breadcrumb{font-size:10px;color:var(--egpk-muted);font-weight:700}.egpk-breadcrumb span{margin:0 4px;color:#aeb5c5}.egpk-page-title{font-size:18px;line-height:1.2;margin:2px 0 0;font-weight:800;color:#202533}.egpk-header-actions{display:flex;gap:6px}.egpk-header-btn{height:36px;min-width:36px;border-color:var(--egpk-border)!important;color:var(--egpk-navy)!important;border-radius:8px!important}.egpk-notification-badge{position:absolute;top:2px;right:2px;min-width:15px;height:15px;padding:0 4px;border-radius:10px;background:var(--egpk-red);color:#fff;font-size:9px;display:grid;place-items:center;font-weight:800}
.egpk-tool-nav-wrap{margin-bottom:10px}.egpk-tool-nav{display:flex;gap:5px;overflow:auto;padding:2px 0 4px;scrollbar-width:thin}.egpk-tool-nav a{display:flex;align-items:center;gap:5px;padding:7px 9px;border:1px solid var(--egpk-border);background:#fff;border-radius:8px;color:#596277;text-decoration:none;white-space:nowrap;font-size:10px;font-weight:800}.egpk-tool-nav a:hover{border-color:#c8cfe0;background:#fafbfe;color:var(--egpk-red)}.egpk-tool-nav a.active{background:var(--egpk-red);border-color:var(--egpk-red);color:#fff;box-shadow:0 3px 8px rgba(181,43,37,.15)}
.egpk-tool-launcher,.egpk-notification-panel{position:absolute;right:20px;top:64px;width:min(430px,calc(100vw - 40px));background:#fff;border:1px solid var(--egpk-border);border-radius:12px;box-shadow:0 18px 45px rgba(31,56,100,.22);z-index:1080}.egpk-tool-launcher-head,.egpk-panel-head{padding:11px 13px;border-bottom:1px solid var(--egpk-border);display:flex;align-items:center;justify-content:space-between}.egpk-section-kicker{font-size:9px;letter-spacing:.08em;color:var(--egpk-muted);font-weight:900}.egpk-tool-launcher-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:10px}.egpk-tool-tile{border:1px solid #edf0f5;border-radius:9px;padding:10px 5px;text-align:center;text-decoration:none;color:#27304a}.egpk-tool-tile:hover{background:#fafbfe;border-color:#d7dcea}.egpk-tool-tile i{font-size:20px;display:block;margin-bottom:5px;color:var(--egpk-red)}.egpk-tool-tile span{font-size:9px;font-weight:800;line-height:1.15;display:block}.egpk-notification-list{max-height:400px;overflow:auto}.egpk-notification-row{display:flex;gap:9px;padding:10px 13px;border-bottom:1px solid #f0f2f7}.egpk-notification-row:last-child{border-bottom:0}.egpk-notification-dot{width:28px;height:28px;border-radius:8px;display:grid;place-items:center;flex:0 0 auto}.egpk-notification-text{font-size:10.5px;line-height:1.4}.egpk-notification-time{font-size:9px;color:var(--egpk-muted);margin-top:2px}
.egpk-global-search{position:absolute;left:0;right:0;top:62px;z-index:1085}.egpk-global-search-inner{background:#fff;border:1px solid var(--egpk-border);border-radius:10px;box-shadow:0 14px 35px rgba(31,56,100,.16);padding:9px}.egpk-global-results{margin-top:7px;max-height:400px;overflow:auto}.egpk-global-result{display:block;padding:9px 11px;border-bottom:1px solid #f0f2f7;text-decoration:none;color:var(--egpk-text)}.egpk-global-result:hover{background:#fafbfe}.egpk-global-result strong{font-size:10.5px}.egpk-global-result small{display:block;color:var(--egpk-muted);margin-top:2px}
.egpk-content-shell{min-width:0}.egpk-hero{background:linear-gradient(100deg,var(--egpk-red-dark),var(--egpk-red));color:#fff;border-radius:12px;padding:16px 18px;display:flex;justify-content:space-between;gap:15px;align-items:center;box-shadow:0 7px 22px rgba(143,29,29,.12)}.egpk-hero h2{margin:3px 0 3px;font-size:20px;font-weight:900}.egpk-hero p{margin:0;color:#f6dedb;font-size:10px}.egpk-hero .egpk-section-kicker{color:#f8d8d4}.egpk-hero .btn-primary{background:var(--egpk-gold)!important;border-color:var(--egpk-gold)!important;color:#222!important}.egpk-hero .btn-light{color:var(--egpk-navy)!important}
.egpk-stat-card{height:100%;background:#fff;border:1px solid var(--egpk-border);border-radius:10px;padding:11px 12px;box-shadow:0 3px 10px rgba(40,50,80,.03)}.egpk-stat-label{font-size:8.5px;text-transform:uppercase;letter-spacing:.05em;color:var(--egpk-muted);font-weight:900}.egpk-stat-value{font-size:19px;font-weight:900;color:var(--egpk-navy);margin-top:4px}.egpk-stat-meta{font-size:8.5px;color:var(--egpk-muted);margin-top:2px}
.egpk-toolbar-card{background:#fff;border:1px solid var(--egpk-border);border-radius:10px;padding:9px}.egpk-toolbar-card .form-control,.egpk-toolbar-card .form-select{font-size:11px;min-height:34px}.egpk-toolbar-card .btn{font-size:10px}.egpk-filter-chip{display:inline-flex;align-items:center;gap:5px;background:#f2f4f8;border:1px solid #e4e7ef;padding:4px 7px;border-radius:99px;font-size:8.5px;font-weight:700;color:#5e677c}
.egpk-card{background:#fff;border:1px solid var(--egpk-border);border-radius:11px;box-shadow:0 4px 13px rgba(31,56,100,.035)}.egpk-card-head{padding:11px 13px;border-bottom:1px solid var(--egpk-border);display:flex;justify-content:space-between;align-items:center;gap:8px}.egpk-card-title{font-size:11px;font-weight:900;color:#28324a}.egpk-card-body{padding:12px}.egpk-section-title{font-size:11px;font-weight:900;color:#28324a;margin-bottom:8px}
.egpk-table-wrap{overflow:auto}.egpk-table{width:100%;min-width:950px;border-collapse:separate;border-spacing:0}.egpk-table thead th{position:sticky;top:0;z-index:3;background:var(--egpk-red);color:#fff;border:0;padding:9px 10px;font-size:8.5px;text-transform:uppercase;letter-spacing:.04em;font-weight:900}.egpk-table tbody td{padding:9px 10px;border-bottom:1px solid #edf0f5;font-size:10px;vertical-align:middle}.egpk-table tbody tr:hover{background:#fbfcfe}.egpk-table .primary{font-weight:800;color:#25314b}.egpk-table .secondary{display:block;color:var(--egpk-muted);font-size:8.5px;margin-top:2px}.egpk-action-btn{width:29px;height:29px;padding:0!important;border-radius:7px!important;display:inline-grid!important;place-items:center}.egpk-action-btn i{font-size:14px}
.egpk-badge{display:inline-flex;align-items:center;gap:4px;border-radius:99px;padding:4px 7px;font-size:8px;font-weight:900}.egpk-badge-red{background:#fdeceb;color:#aa2a24}.egpk-badge-green{background:#e7f6ed;color:#2e7d32}.egpk-badge-amber{background:#fff2d7;color:#9b6b00}.egpk-badge-blue{background:#eaf2ff;color:#1f618d}.egpk-badge-purple{background:#eeeafe;color:#4a3e8e}.egpk-badge-slate{background:#eef1f5;color:#596277}
.egpk-list-empty{padding:45px 20px;text-align:center;color:var(--egpk-muted)}.egpk-list-empty i{font-size:34px;display:block;margin-bottom:8px;color:#c2c7d4}.egpk-loading{padding:45px;text-align:center;color:var(--egpk-muted)}.egpk-error{padding:22px;text-align:center;background:#fff5f4;border:1px solid #f3cbc7;color:#9a2f29;border-radius:10px}
.egpk-board-grid{display:grid;grid-template-columns:repeat(4,minmax(220px,1fr));gap:9px;overflow:auto}.egpk-board{background:#fff;border:1px solid var(--egpk-border);border-radius:10px;min-width:220px}.egpk-board-head{padding:9px 10px;border-left:4px solid var(--egpk-purple);border-bottom:1px solid var(--egpk-border);display:flex;justify-content:space-between;align-items:center}.egpk-board-head strong{font-size:10.5px}.egpk-board-list{padding:4px}.egpk-bookmark-item{display:flex;gap:8px;align-items:center;padding:7px;border-bottom:1px solid #f2f4f7;text-decoration:none;color:#27304a}.egpk-bookmark-item:last-child{border-bottom:0}.egpk-bookmark-item:hover{background:#fafbfe}.egpk-favicon{width:18px;height:18px;border-radius:4px;object-fit:contain;background:#f3f5f8}.egpk-favicon-wrap{position:relative;display:grid;place-items:center;flex:0 0 auto;border:1px solid #e7eaf0;background:#f7f8fb;border-radius:8px;overflow:hidden}.egpk-favicon-img{position:absolute;inset:4px;width:calc(100% - 8px);height:calc(100% - 8px);object-fit:contain;border-radius:4px}.egpk-favicon-fallback{font-size:14px;color:#8a91a3;line-height:1}.egpk-bookmark-board-description{min-height:33px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.egpk-favicon-preview{display:flex;align-items:center;gap:9px;padding:9px;border:1px solid var(--egpk-border);border-radius:9px;background:#fff}.egpk-favicon-preview-icon{width:42px;height:42px;flex:0 0 42px;border-radius:9px;background:#f7f8fb;display:grid;place-items:center;position:relative;font-size:20px;color:#8b92a1;overflow:hidden}.egpk-favicon-preview-icon img{position:absolute;inset:5px;width:calc(100% - 10px);height:calc(100% - 10px);object-fit:contain}.egpk-bookmark-title{font-size:9.5px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.egpk-bookmark-domain{font-size:8px;color:var(--egpk-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.egpk-feed-grid{display:grid;grid-template-columns:minmax(0,1fr) 290px;gap:10px}.egpk-post{padding:13px}.egpk-post-title{font-size:13px;font-weight:900;color:#26314b}.egpk-post-body{font-size:10px;line-height:1.7;margin-top:7px}.egpk-post-meta{font-size:8.5px;color:var(--egpk-muted)}.egpk-post-actions{display:flex;gap:6px;margin-top:10px}.egpk-chip-btn{border:1px solid var(--egpk-border);background:#fff;border-radius:7px;padding:5px 8px;font-size:8.5px;font-weight:800;color:#596277}.egpk-chip-btn:hover{background:#f7f8fb}.egpk-media-preview{margin-top:9px;border:1px solid var(--egpk-border);border-radius:9px;padding:10px;background:#fafbfc}
.egpk-kanban{display:grid;grid-template-columns:repeat(5,minmax(190px,1fr));gap:8px;overflow:auto}.egpk-kanban-col{background:#eff2f7;border-radius:10px;padding:7px;min-height:320px}.egpk-kanban-head{font-size:9px;font-weight:900;color:#4b556d;padding:5px}.egpk-task{background:#fff;border:1px solid var(--egpk-border);border-radius:8px;padding:9px;margin-bottom:6px}.egpk-task-title{font-size:9.5px;font-weight:800}.egpk-task-meta{font-size:8px;color:var(--egpk-muted);margin-top:4px}.egpk-note-grid{display:grid;grid-template-columns:repeat(4,minmax(180px,1fr));gap:9px}.egpk-note{min-height:170px;border-radius:10px;padding:11px;box-shadow:0 5px 14px rgba(30,40,70,.07);position:relative}.egpk-note h6{font-size:11px;font-weight:900}.egpk-note p{font-size:9px;line-height:1.55}.egpk-money-summary{font-size:17px;font-weight:900}.egpk-money-positive{color:#2e7d32}.egpk-money-negative{color:#b02418}
.egpk-calendar-toolbar{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px;border-bottom:1px solid var(--egpk-border)}.egpk-calendar-title{font-size:14px;font-weight:900}.egpk-calendar-grid{display:grid;grid-template-columns:repeat(7,minmax(120px,1fr));min-width:840px}.egpk-day-head{padding:8px;background:#f5f7fb;border-right:1px solid #e9edf4;border-bottom:1px solid #e9edf4;text-align:center;font-size:8px;font-weight:900;color:#6e778a;text-transform:uppercase}.egpk-day-cell{min-height:115px;border-right:1px solid #edf0f5;border-bottom:1px solid #edf0f5;padding:6px;background:#fff}.egpk-day-cell.muted{background:#fafbfc;color:#b2b8c4}.egpk-day-no{font-size:9px;font-weight:900;color:#60697e;margin-bottom:5px}.egpk-event-pill{display:block;border-radius:5px;padding:4px 5px;margin-bottom:4px;font-size:7.8px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}.egpk-event-pill:hover{filter:brightness(.98);transform:translateY(-1px)}.egpk-event-pill.red{background:#fdeceb;color:#a62d27}.egpk-event-pill.gold{background:#fff1d7;color:#956700}.egpk-event-pill.green{background:#e7f6ed;color:#2e7d32}.egpk-event-pill.blue{background:#e9f2ff;color:#1f618d}.egpk-event-pill.purple{background:#efeafd;color:#4a3e8e}
.egpk-form-section{border:1px solid var(--egpk-border);border-radius:9px;padding:11px;margin-bottom:10px}.egpk-form-section-title{font-size:10px;font-weight:900;text-transform:uppercase;color:#4b556d;letter-spacing:.05em;margin-bottom:10px}.egpk-form-section .form-label{font-size:9px;font-weight:800;color:#586278;margin-bottom:4px}.egpk-form-section .form-control,.egpk-form-section .form-select{font-size:10px}.egpk-modal .modal-content{border:0;border-radius:12px;overflow:hidden}.egpk-modal .modal-header{border-bottom:1px solid var(--egpk-border)}.egpk-modal .modal-title{font-size:15px;font-weight:900}.egpk-modal .modal-body{background:#fbfcfe}.egpk-detail-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.egpk-detail{background:#fff;border:1px solid var(--egpk-border);border-radius:8px;padding:9px}.egpk-detail label{display:block;font-size:8px;color:var(--egpk-muted);font-weight:900;text-transform:uppercase}.egpk-detail strong{display:block;font-size:10px;color:#28324a;margin-top:3px;word-break:break-word}
.egpk-pagination{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:9px 0}.egpk-pagination .btn{font-size:9px}.egpk-pager-info{font-size:8.5px;color:var(--egpk-muted)}
.egpk-table .check-cell{width:30px}.egpk-bulkbar{display:flex;align-items:center;gap:7px;padding:8px;border:1px dashed #ccd2df;background:#fafbfe;border-radius:8px;margin-bottom:8px}.egpk-bulkbar span{font-size:8.5px;color:#5f687a;font-weight:800}
.egpk-skeleton{height:36px;background:linear-gradient(90deg,#f0f2f6 25%,#f8f9fb 50%,#f0f2f6 75%);background-size:300px 100%;animation:egpkShimmer 1.2s linear infinite;border-radius:6px;margin:7px 0}@keyframes egpkShimmer{from{background-position:-300px 0}to{background-position:300px 0}}
@media(max-width:1200px){.egpk-stat-grid{grid-template-columns:repeat(3,1fr)}.egpk-board-grid{grid-template-columns:repeat(3,minmax(220px,1fr))}.egpk-note-grid{grid-template-columns:repeat(3,minmax(180px,1fr))}}
@media(max-width:992px){.egpk-hero{align-items:flex-start;flex-direction:column}.egpk-feed-grid{grid-template-columns:1fr}.egpk-detail-grid{grid-template-columns:repeat(2,1fr)}.egpk-board-grid{grid-template-columns:repeat(2,minmax(220px,1fr))}.egpk-note-grid{grid-template-columns:repeat(2,minmax(180px,1fr))}}
@media(max-width:768px){.egpk-app{padding:7px}.egpk-header-main{align-items:flex-start}.egpk-header-actions{gap:4px}.egpk-tool-launcher{right:7px;top:60px}.egpk-global-search{top:60px}.egpk-tool-launcher-grid{grid-template-columns:repeat(3,1fr)}.egpk-stat-grid{grid-template-columns:repeat(2,1fr)}.egpk-page-title{font-size:15px}.egpk-title-icon{width:34px;height:34px}.egpk-hero h2{font-size:17px}.egpk-note-grid{grid-template-columns:1fr}.egpk-detail-grid{grid-template-columns:1fr}.egpk-toolbar-card .col-lg-3{justify-content:flex-start!important}}
@media(max-width:480px){.egpk-tool-launcher-grid{grid-template-columns:repeat(2,1fr)}.egpk-stat-grid{grid-template-columns:1fr 1fr}.egpk-header-btn{padding-left:8px!important;padding-right:8px!important}.egpk-hero{padding:13px}.egpk-tool-nav a{font-size:9px;padding:6px 8px}}

</style>
<script type="application/json" id="egpkRouteConfig">{!! json_encode([
    'module' => $module,
    'csrf' => csrf_token(),
    'routes' => [
        'dashboard'=>route('productivity.dashboard.data'),'companies'=>route('productivity.companies'),'users'=>route('productivity.users'),'global'=>route('productivity.global.search'),'notifications'=>route('productivity.notifications'),'notificationsRead'=>route('productivity.notifications.read'),
        'contacts'=>[
            'data'=>route('productivity.contacts.data'),'categories'=>route('productivity.contacts.categories'),'store'=>route('productivity.contacts.store'),'show'=>url('/productivity/contactbook'),'update'=>url('/productivity/contactbook'),'delete'=>url('/productivity/contactbook'),'restore'=>url('/productivity/contactbook'),'star'=>url('/productivity/contactbook'),'bulk'=>route('productivity.contacts.bulk'),'searchHistory'=>route('productivity.contacts.search.history'),'saveSearch'=>route('productivity.contacts.search.save'),'merge'=>route('productivity.contacts.merge'),'exportCsv'=>route('productivity.contacts.export.csv'),'exportXlsx'=>route('productivity.contacts.export.xlsx'),'vcard'=>route('productivity.contacts.export.vcard'),'import'=>route('productivity.contacts.import'),'googleImport'=>route('productivity.contacts.google.import'),'googleConnect'=>route('productivity.contacts.google.connect'),'googleCallback'=>route('productivity.contacts.google.callback')
        ],
        'bookmarks'=>[
            'data'=>route('productivity.bookmarks.data'),'boards'=>route('productivity.bookmarks.boards'),'board'=>url('/productivity/bookmarks/board'),'show'=>url('/productivity/bookmarks'),'favicon'=>route('productivity.bookmarks.favicon'),'faviconImage'=>route('productivity.bookmarks.favicon.image'),'boardStore'=>route('productivity.bookmarks.board.store'),'boardUpdate'=>url('/productivity/bookmarks/boards'),'boardDelete'=>url('/productivity/bookmarks/boards'),'categoryStore'=>url('/productivity/bookmarks/boards'),'categoryUpdate'=>url('/productivity/bookmarks/categories'),'categoryDelete'=>url('/productivity/bookmarks/categories'),'store'=>route('productivity.bookmarks.store'),'quick'=>route('productivity.bookmarks.quick'),'update'=>url('/productivity/bookmarks'),'importHtml'=>route('productivity.bookmarks.import.html'),'open'=>url('/productivity/bookmarks'),'health'=>url('/productivity/bookmarks'),'delete'=>url('/productivity/bookmarks'),'moveCopy'=>url('/productivity/bookmarks')
        ],
        'passwallet'=>['data'=>route('productivity.passwallet.data'),'categories'=>route('productivity.passwallet.categories'),'store'=>route('productivity.passwallet.store'),'show'=>url('/productivity/passwallet'),'update'=>url('/productivity/passwallet'),'reveal'=>url('/productivity/passwallet'),'copyAudit'=>url('/productivity/passwallet'),'history'=>url('/productivity/passwallet'),'shares'=>url('/productivity/passwallet'),'delete'=>url('/productivity/passwallet'),'generator'=>route('productivity.passwallet.generator'),'attachment'=>url('/productivity/passwallet'),'attachments'=>url('/productivity/passwallet'),'stepup'=>route('productivity.passwallet.stepup'),'lockdown'=>url('/productivity/passwallet/lockdown')],
        'knowledge'=>['data'=>route('productivity.knowledge.data'),'categories'=>route('productivity.knowledge.categories'),'store'=>route('productivity.knowledge.store'),'show'=>url('/productivity/knowledge'),'update'=>url('/productivity/knowledge'),'like'=>url('/productivity/knowledge'),'save'=>url('/productivity/knowledge'),'reply'=>url('/productivity/knowledge'),'report'=>url('/productivity/knowledge'),'follow'=>url('/productivity/knowledge/categories'),'media'=>url('/productivity/knowledge'),'moderate'=>url('/productivity/knowledge')],
        'portals'=>['data'=>route('productivity.portals.data'),'store'=>route('productivity.portals.store'),'show'=>url('/productivity/portals'),'update'=>url('/productivity/portals'),'version'=>url('/productivity/portals'),'launch'=>url('/productivity/portals'),'subscribe'=>url('/productivity/portals'),'exportXlsx'=>route('productivity.portals.export.xlsx')],
        'meetings'=>['data'=>route('productivity.meetings.data'),'calendar'=>route('productivity.meetings.calendar'),'store'=>route('productivity.meetings.store'),'show'=>url('/productivity/meetings'),'update'=>url('/productivity/meetings'),'reschedule'=>url('/productivity/meetings'),'rsvp'=>url('/productivity/meetings'),'delete'=>url('/productivity/meetings')],
        'tasks'=>['data'=>route('productivity.tasks.data'),'store'=>route('productivity.tasks.store'),'show'=>url('/productivity/tasks'),'update'=>url('/productivity/tasks'),'status'=>url('/productivity/tasks'),'comment'=>url('/productivity/tasks'),'verify'=>url('/productivity/tasks'),'delete'=>url('/productivity/tasks')],
        'notes'=>['data'=>route('productivity.notes.data'),'show'=>url('/productivity/notes'),'store'=>route('productivity.notes.store'),'update'=>url('/productivity/notes'),'action'=>url('/productivity/notes')],
        'money'=>['data'=>route('productivity.money.data'),'account'=>route('productivity.money.account'),'transaction'=>route('productivity.money.transaction'),'budget'=>route('productivity.money.budget'),'commitment'=>route('productivity.money.commitment')],
        'events'=>['data'=>route('productivity.events.data'),'calendar'=>route('productivity.events.calendar'),'store'=>route('productivity.events.store'),'show'=>url('/productivity/events'),'update'=>url('/productivity/events'),'delete'=>url('/productivity/events')],
        'documents'=>['data'=>route('productivity.documents.data'),'upload'=>route('productivity.documents.upload'),'version'=>url('/productivity/documents'),'versions'=>url('/productivity/documents'),'url'=>url('/productivity/documents'),'pin'=>url('/productivity/documents'),'delete'=>url('/productivity/documents')],
        'shares'=>['data'=>route('productivity.shares.data'),'pending'=>route('productivity.shares.pending'),'store'=>route('productivity.shares.store'),'approve'=>url('/productivity/shares'),'revoke'=>url('/productivity/shares')],
        'reports'=>['data'=>route('productivity.reports.data'),'csv'=>route('productivity.reports.csv'),'xlsx'=>route('productivity.reports.xlsx')],
        'admin'=>['data'=>route('productivity.admin.data'),'category'=>route('productivity.admin.category')]
    ]
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) !!}</script>
<script>
(function ($, window, document) {
    'use strict';

    const root = document.querySelector('.egpk-app');
    if (!root) return;

    let config = {};
    try {
        const raw = document.getElementById('egpkRouteConfig');
        config = JSON.parse(raw ? raw.textContent : '{}');
    } catch (e) {
        console.error('EGPK configuration error', e);
        return;
    }

    const moduleName = config.module || root.dataset.egpkModule || 'dashboard';
    const routes = config.routes || {};
    const state = {
        page: 1,
        perPage: 25,
        search: '',
        company: 'all',
        selected: [],
        view: 'table',
        currentId: null,
        currentType: null,
        currentBoard: null,
        pending: null,
        calendarDate: new Date(),
        calendarItems: []
    };

    const tools = [
        ['dashboard', 'Dashboard', 'mdi-view-dashboard-outline', '/productivity/'],
        ['contacts', 'ContactBook', 'mdi-contacts-outline', '/productivity/contactbook'],
        ['bookmarks', 'BookMarks', 'mdi-bookmark-outline', '/productivity/bookmarks'],
        ['passwallet', 'PassWallet', 'mdi-wallet-lock-outline', '/productivity/passwallet'],
        ['knowledge', 'Knowledge Panel', 'mdi-school-outline', '/productivity/knowledge'],
        ['portals', 'Portals & Apps', 'mdi-application-braces-outline', '/productivity/portals'],
        ['meetings', 'Meetings', 'mdi-calendar-account-outline', '/productivity/meetings'],
        ['tasks', 'Tasks', 'mdi-format-list-checks', '/productivity/tasks'],
        ['notes', 'Sticky Notes', 'mdi-note-multiple-outline', '/productivity/notes'],
        ['money', 'My Money', 'mdi-cash-multiple', '/productivity/money'],
        ['events', 'Events', 'mdi-calendar-star', '/productivity/events'],
        ['documents', 'Documents', 'mdi-file-document-multiple-outline', '/productivity/documents'],
        ['reports', 'Reports', 'mdi-chart-box-outline', '/productivity/reports'],
        ['admin', 'Admin', 'mdi-shield-crown-outline', '/productivity/admin']
    ];

    const moduleMeta = {
        dashboard: { icon: 'mdi-view-dashboard-outline', desc: 'Unified overview of governed productivity resources.' },
        contacts: { icon: 'mdi-contacts-outline', desc: 'Canonical contacts with search, import, sharing and activity.' },
        bookmarks: { icon: 'mdi-bookmark-outline', desc: 'Boards, categories and visual bookmarks with collaboration.' },
        passwallet: { icon: 'mdi-wallet-lock-outline', desc: 'Protected credentials with controlled sharing and audit.' },
        knowledge: { icon: 'mdi-school-outline', desc: 'Rich internal knowledge, media, interaction and discovery.' },
        portals: { icon: 'mdi-application-braces-outline', desc: 'Company-wise portal and application registry.' },
        meetings: { icon: 'mdi-calendar-account-outline', desc: 'Meetings, participants, RSVP and calendar.' },
        tasks: { icon: 'mdi-format-list-checks', desc: 'Work tracking with priorities, assignees and verification.' },
        notes: { icon: 'mdi-note-multiple-outline', desc: 'Personal and shared notes with reminders and actions.' },
        money: { icon: 'mdi-cash-multiple', desc: 'Private personal money, budgets and commitments.' },
        events: { icon: 'mdi-calendar-star', desc: 'Events, registrations and attendance tracking.' },
        documents: { icon: 'mdi-file-document-multiple-outline', desc: 'Controlled personal and official documents.' },
        reports: { icon: 'mdi-chart-box-outline', desc: 'Role-scoped operational and audit reporting.' },
        admin: { icon: 'mdi-shield-crown-outline', desc: 'Governance, shares, categories and audit oversight.' }
    };

    const $ws = $('#egpkWorkspace');
    const $stats = $('#egpkStats');
    const $filter = $('#egpkFilterSlot');
    const $search = $('#egpkSearch');
    const formModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egpkFormModal'));
    const viewModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egpkViewModal'));
    const shareModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egpkShareModal'));
    const confirmModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egpkConfirmModal'));
    const stepupModal = () => bootstrap.Modal.getOrCreateInstance(document.getElementById('egpkStepupModal'));

    function esc(value) {
        return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function url(base, id, suffix) {
        let v = String(base || '').replace(/\/$/, '');
        if (id !== undefined && id !== null && id !== '') {
            if (v.includes('__ID__')) v = v.replace('__ID__', encodeURIComponent(id));
            else v += '/' + encodeURIComponent(id);
        }
        if (suffix) v += '/' + suffix.replace(/^\//, '');
        return v;
    }

    function query(params) {
        const sp = new URLSearchParams();
        Object.keys(params || {}).forEach(k => {
            const v = params[k];
            if (v !== undefined && v !== null && v !== '') sp.set(k, v);
        });
        return sp.toString();
    }

    function ajax(method, endpoint, data, opts) {
        const options = opts || {};
        const isForm = data instanceof FormData;
        return $.ajax({
            url: endpoint,
            method: method || 'GET',
            data: data || {},
            processData: !isForm,
            contentType: isForm ? false : 'application/x-www-form-urlencoded; charset=UTF-8',
            headers: Object.assign({
                'X-CSRF-TOKEN': config.csrf,
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }, options.headers || {}),
            dataType: 'json',
            timeout: options.timeout || 30000
        }).then(function (res) {
            if (!res || (res.status !== undefined && Number(res.status) >= 400)) {
                return $.Deferred().reject(res || { message: 'Unexpected response.' }).promise();
            }
            return res;
        }).catch(function (xhr) {
            const dataObj = xhr && xhr.responseJSON ? xhr.responseJSON : xhr;
            if (xhr && xhr.status === 419) return $.Deferred().reject({ message: 'Your session expired. Refresh the page and try again.', status: 419 }).promise();
            if (xhr && xhr.status === 429) return $.Deferred().reject({ message: 'Too many requests. Please retry in a moment.', status: 429 }).promise();
            if (dataObj && dataObj.errors) {
                const first = Object.values(dataObj.errors)[0];
                if (Array.isArray(first) && first[0]) dataObj.message = first[0];
            }
            if (dataObj && dataObj.message) return $.Deferred().reject(dataObj).promise();
            return $.Deferred().reject({ message: 'Server request failed.' }).promise();
        });
    }

    function download(method, endpoint, data, fallbackName) {
        const isForm = data instanceof FormData;
        const d = isForm ? data : (data || {});
        return $.ajax({
            url: endpoint, method: method || 'GET', data: d, processData: !isForm,
            contentType: isForm ? false : 'application/x-www-form-urlencoded; charset=UTF-8',
            headers: {'X-CSRF-TOKEN': config.csrf, 'Accept': '*/*', 'X-Requested-With': 'XMLHttpRequest'},
            xhrFields: {responseType: 'blob'}, timeout: 60000
        }).done(function(blob, status, xhr) {
            let filename = fallbackName || 'download';
            const cd = xhr.getResponseHeader('Content-Disposition') || '';
            const m = cd.match(/filename[^;=]*=(?:UTF-8''|\"?)([^;\"]+)/i);
            if (m && m[1]) filename = decodeURIComponent(m[1].replace(/\"/g, ''));
            const objectUrl = window.URL.createObjectURL(blob);
            const a = document.createElement('a'); a.href = objectUrl; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
            window.setTimeout(function(){window.URL.revokeObjectURL(objectUrl);}, 500);
        }).fail(function(xhr) {
            let message = 'Download failed.';
            if (xhr && xhr.responseJSON && xhr.responseJSON.message) message = xhr.responseJSON.message;
            notify(message, 'error');
        });
    }

    function notify(message, type) {
        const toast = bootstrap.Toast.getOrCreateInstance(document.getElementById('egpkToast'), { delay: 3200 });
        const el = document.getElementById('egpkToast');
        $(el).removeClass('bg-success bg-danger bg-warning bg-dark text-white');
        el.classList.add(type === 'error' ? 'bg-danger' : type === 'warning' ? 'bg-warning' : 'bg-success', 'text-white');
        $(el).find('.toast-body').text(message || 'Done.');
        toast.show();
    }

    function loading() { $ws.html('<div class="egpk-card"><div class="egpk-loading"><span class="spinner-border spinner-border-sm me-2"></span>Loading…</div></div>'); }
    function empty(icon, message, actionHtml) { return '<div class="egpk-list-empty"><i class="mdi ' + (icon || 'mdi-information-outline') + '"></i><div class="fw-bold mb-1">' + esc(message || 'No records found') + '</div>' + (actionHtml || '') + '</div>'; }
    function errorBox(message) { return '<div class="egpk-error"><i class="mdi mdi-alert-circle-outline me-1"></i>' + esc(message || 'Unable to load data.') + '</div>'; }

    function badge(value) {
        const s = String(value || '').toLowerCase();
        let cls = 'egpk-badge-slate';
        if (['active','live','completed','accepted','healthy','published','present','ok'].includes(s)) cls = 'egpk-badge-green';
        else if (['overdue','failed','cancelled','deprecated','broken','declined','urgent'].includes(s)) cls = 'egpk-badge-red';
        else if (['pending','under maintenance','tentative','warning','high','in progress'].includes(s)) cls = 'egpk-badge-amber';
        else if (['company','group','production'].includes(s)) cls = 'egpk-badge-blue';
        else if (['private','manage','view','staging'].includes(s)) cls = 'egpk-badge-purple';
        return '<span class="egpk-badge ' + cls + '">' + esc(value || '-') + '</span>';
    }

    function statCard(label, value, meta, icon) {
        return '<div class="col-6 col-xl-2"><div class="egpk-stat-card"><div class="d-flex justify-content-between gap-2"><div><div class="egpk-stat-label">' + esc(label) + '</div><div class="egpk-stat-value">' + esc(value) + '</div><div class="egpk-stat-meta">' + esc(meta || '') + '</div></div><i class="mdi ' + esc(icon || 'mdi-chart-box-outline') + ' fs-4 text-muted"></i></div></div></div>';
    }

    if (moduleName === 'meetings' || moduleName === 'events') state.view = 'calendar';

    function renderTools() {
        const nav = tools.map(t => '<a class="' + (t[0] === moduleName ? 'active' : '') + '" href="' + esc(t[3]) + '"><i class="mdi ' + t[2] + '"></i>' + esc(t[1]) + '</a>').join('');
        $('#egpkToolNav').html(nav);
        $('#egpkToolLauncherGrid').html(tools.map(t => '<a class="egpk-tool-tile" href="' + esc(t[3]) + '"><i class="mdi ' + t[2] + '"></i><span>' + esc(t[1]) + '</span></a>').join(''));
        const m = moduleMeta[moduleName] || moduleMeta.dashboard;
        $('#egpkHeroTitle').text(root.dataset.egpkTitle || tools.find(t => t[0] === moduleName)?.[1] || moduleName);
        $('#egpkHeroSubtitle').text(m.desc);
        $('#egpkHeroActions').empty();
        if (['contacts','bookmarks','passwallet','knowledge','portals','meetings','tasks','notes','money','events','documents','admin'].includes(moduleName)) {
            $('#egpkHeroActions').append('<button type="button" class="btn btn-primary btn-sm" id="egpkPrimaryAction"><i class="mdi mdi-plus"></i> ' + (moduleName === 'money' ? 'Quick Entry' : moduleName === 'bookmarks' ? 'New Board' : 'New Entry') + '</button>');
        }
        if (moduleName === 'reports') $('#egpkHeroActions').append('<button type="button" class="btn btn-light btn-sm" id="egpkExportQuick"><i class="mdi mdi-download-outline"></i> Export</button>');
        if (moduleName !== 'dashboard') $('#egpkHeroActions').append('<button type="button" class="btn btn-light btn-sm" id="egpkAdvancedAction"><i class="mdi mdi-tune-variant"></i> More actions</button>');
        $('#egpkAdvancedAction').off('click.egpk').on('click.egpk', openAdvancedOperations);
        $('#egpkExportQuick').off('click.egpk').on('click.egpk', function(){dispatchAction('report-xlsx');});
    }

    function loadCompanies() {
        return ajax('GET', routes.companies).done(function (res) {
            const list = Array.isArray(res.data) ? res.data : [];
            const html = '<option value="all">All Companies</option>' + list.map(c => '<option value="' + esc(c.sno) + '">' + esc(c.company_short_name || c.company_name) + '</option>').join('');
            $('#egpkCompany').html(html).val(state.company);
        });
    }

    function loadNotifications() {
        return ajax('GET', routes.notifications).done(function (res) {
            const payload = res.data || {};
            const rows = Array.isArray(payload.items) ? payload.items : (Array.isArray(payload.notifications) ? payload.notifications : (Array.isArray(payload) ? payload : []));
            const unread = Number(payload.unread || 0);
            $('#egpkNotificationCount').text(unread).toggleClass('d-none', unread < 1);
            $('#egpkNotificationList').html(rows.length ? rows.map(n => '<div class="egpk-notification-row"><div class="egpk-notification-dot bg-light"><i class="mdi mdi-bell-outline"></i></div><div><div class="egpk-notification-text">' + esc(n.message || n.title || '') + '</div><div class="egpk-notification-time">' + esc(n.time_ago || n.created_at || '') + '</div></div></div>').join('') : empty('mdi-bell-off-outline','No notifications')); 
        }).fail(function(){ /* notification failure must not block module */ });
    }

    function globalSearch(term) {
        if (!term || term.length < 2) { $('#egpkGlobalSearchResults').empty(); return; }
        ajax('GET', routes.global + '?' + query({ q: term, term: term })).done(function (res) {
            const rows = Array.isArray(res.data) ? res.data : [];
            $('#egpkGlobalSearchResults').html(rows.length ? rows.map(x => '<a href="' + esc(x.url || '#') + '" class="egpk-global-result"><strong>' + esc(x.title || x.name || '-') + '</strong><small>' + esc(x.module || x.type || '') + (x.meta ? ' · ' + esc(x.meta) : '') + '</small></a>').join('') : empty('mdi-magnify-close','No matching results'));
        }).fail(function(){ $('#egpkGlobalSearchResults').html(errorBox('Global search failed.')); });
    }

    function setFilterSlot(html) { $filter.html(html || ''); }
    function setViewSwitcher(views) {
        $('#egpkViewSwitcher').html((views || []).map(v => '<button type="button" class="btn btn-outline-secondary ' + (state.view === v[0] ? 'active' : '') + '" data-egpk-view="' + esc(v[0]) + '"><i class="mdi ' + v[2] + '"></i> ' + esc(v[1]) + '</button>').join(''));
    }
    function commonParams(extra) { return Object.assign({ page: state.page, per_page: state.perPage, search: state.search, company_id: state.company === 'all' ? '' : state.company }, extra || {}); }
    function pagination(page, lastPage, total) {
        const p = Number(page || 1), l = Number(lastPage || 1);
        if (l <= 1) return '<div class="egpk-pagination"><div class="egpk-pager-info">' + esc(total || 0) + ' record(s)</div></div>';
        return '<div class="egpk-pagination"><div class="egpk-pager-info">Page ' + p + ' of ' + l + ' · ' + esc(total || 0) + ' record(s)</div><div class="btn-group"><button class="btn btn-light btn-sm" data-page="' + Math.max(1,p-1) + '" ' + (p <= 1 ? 'disabled' : '') + '>&laquo;</button><button class="btn btn-light btn-sm" data-page="' + Math.min(l,p+1) + '" ' + (p >= l ? 'disabled' : '') + '>&raquo;</button></div></div>';
    }

    function bindDelegates() {
        $('#egpkWorkspace').off('click.egpk').on('click.egpk', '[data-egpk-action]', function (e) {
            e.preventDefault();
            const a = $(this).data('egpk-action');
            const id = $(this).data('id');
            const type = $(this).data('type');
            const extra = $(this).data();
            dispatchAction(a, id, type, extra);
        }).on('click.egpk', '[data-page]', function(){ state.page = Number($(this).data('page')) || 1; loadModule(); });
    }

    function openForm(title, subtitle, body, submitHandler) {
        $('#egpkFormTitle').text(title || 'Create');
        $('#egpkFormSubtitle').text(subtitle || '');
        $('#egpkFormBody').html(body || '');
        $('#egpkForm').off('submit.egpk').on('submit.egpk', function(e){ e.preventDefault(); submitHandler($(this)); });
        formModal().show();
        hydrateUserSelects();
    }

    function field(name,label,value,type,options) {
        const o = options || {};
        if (type === 'select') return '<div class="col-md-' + (o.col || 6) + '"><label class="form-label">' + esc(label) + (o.required ? ' <span class="text-danger">*</span>' : '') + '</label><select class="form-select" name="' + esc(name) + '" ' + (o.required ? 'required' : '') + '>' + (o.placeholder !== false ? '<option value="">Select</option>' : '') + (o.options || []).map(x => '<option value="' + esc(x.value ?? x.id ?? x.sno) + '" ' + (String(x.value ?? x.id ?? x.sno) === String(value ?? '') ? 'selected' : '') + '>' + esc(x.label ?? x.name ?? x.category_name ?? x.company_name) + '</option>').join('') + '</select></div>';
        if (type === 'textarea') return '<div class="col-md-' + (o.col || 12) + '"><label class="form-label">' + esc(label) + '</label><textarea class="form-control" name="' + esc(name) + '" rows="' + (o.rows || 4) + '" placeholder="' + esc(o.placeholder || '') + '">' + esc(value || '') + '</textarea></div>';
        if (type === 'checkbox') return '<div class="col-md-' + (o.col || 6) + '"><div class="form-check mt-4"><input class="form-check-input" type="checkbox" name="' + esc(name) + '" value="1" ' + (value ? 'checked' : '') + '><label class="form-check-label">' + esc(label) + '</label></div></div>';
        return '<div class="col-md-' + (o.col || 6) + '"><label class="form-label">' + esc(label) + (o.required ? ' <span class="text-danger">*</span>' : '') + '</label><input class="form-control" type="' + esc(type || 'text') + '" name="' + esc(name) + '" value="' + esc(value ?? '') + '" placeholder="' + esc(o.placeholder || '') + '" ' + (o.required ? 'required' : '') + ' ' + (o.step ? 'step="'+esc(o.step)+'"' : '') + '></div>';
    }

    function multiUserField(name, label, values, col) {
        const selected = Array.isArray(values) ? values.map(String) : [];
        return '<div class="col-md-' + (col || 12) + '"><label class="form-label">' + esc(label) + '</label><select class="form-select" multiple size="5" name="' + esc(name) + '[]" data-egpk-user-select data-selected="' + esc(JSON.stringify(selected)) + '"></select><div class="form-text">Ctrl/Cmd + click to select multiple users.</div></div>';
    }

    function section(title, html) { return '<div class="egpk-form-section"><div class="egpk-form-section-title">' + esc(title) + '</div><div class="row g-3">' + html + '</div></div>'; }

    function hydrateUserSelects() {
        const selects = $('#egpkForm [data-egpk-user-select]');
        if (!selects.length || !routes.users) return;
        ajax('GET', routes.users + '?limit=200').done(function (res) {
            const users = Array.isArray(res.data) ? res.data : [];
            selects.each(function () {
                let selected = [];
                try { selected = JSON.parse($(this).attr('data-selected') || '[]'); } catch (e) {}
                $(this).html(users.map(u => {
                    const id = String(u.user_id || u.sno || '');
                    const name = u.staff_name || u.name || u.email || id;
                    return '<option value="' + esc(id) + '" ' + (selected.includes(id) ? 'selected' : '') + '>' + esc(name) + '</option>';
                }).join(''));
            });
        });
    }

    function submitForm(endpoint, method, formEl, onDone) {
        const button = $('#egpkFormSubmit');
        button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Saving…');
        const data = {};
        $.each(formEl.serializeArray(), function () {
            const key = this.name.endsWith('[]') ? this.name.slice(0, -2) : this.name;
            if (Object.prototype.hasOwnProperty.call(data, key)) {
                data[key] = Array.isArray(data[key]) ? data[key].concat([this.value]) : [data[key], this.value];
            } else if (this.name.endsWith('[]')) {
                data[key] = [this.value];
            } else {
                data[key] = this.value;
            }
        });
        ajax(method, endpoint, data).done(function(res){ formModal().hide(); notify(res.message || 'Saved successfully.'); if (onDone) onDone(res); else loadModule(); }).fail(function(err){ notify(err.message || 'Validation failed.', 'error'); }).always(function(){ button.prop('disabled', false).html('<i class="mdi mdi-content-save-outline"></i> Save'); });
    }

    /* ---------------- Dashboard ---------------- */
    function loadDashboard() {
        setFilterSlot(''); setViewSwitcher([]); $search.prop('disabled', true);
        loading();
        ajax('GET', routes.dashboard + '?' + query({company_id:state.company === 'all' ? '' : state.company})).done(function(res){
            const d = res.data || {}; const k = d.kpis || {};
            $stats.html([
                statCard('Contacts',k.contacts||0,'Active repository','mdi-contacts-outline'),
                statCard('Boards',k.boards||0,'Personal + shared','mdi-bookmark-outline'),
                statCard('Bookmarks',k.bookmarks||0,'Tracked links','mdi-link-variant'),
                statCard('Vault',k.vault_entries||0,'Credential entries','mdi-wallet-lock-outline'),
                statCard('Knowledge',k.knowledge_posts||0,'Posts','mdi-school-outline'),
                statCard('Apps',k.apps||0,'Registered apps','mdi-application-braces-outline')
            ].join(''));
            const attention = Array.isArray(d.attention) ? d.attention : [];
            const adoption = Array.isArray(d.adoption) ? d.adoption : [];
            $ws.html('<div class="row g-3"><div class="col-lg-7"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Attention</div><span class="badge bg-light text-dark">Role: '+esc(d.role||'-')+'</span></div><div class="egpk-card-body">'+(attention.length ? attention.map(x=>'<div class="d-flex justify-content-between align-items-center py-2 border-bottom"><div><div class="fw-bold small">'+esc(x.title||x.sub||'-')+'</div><div class="text-muted" style="font-size:9px">'+esc(x.sub||x.mod||'')+'</div></div><button class="btn btn-outline-secondary btn-sm" data-egpk-action="attention" data-id="'+esc(x.id||'')+'">Review</button></div>').join('') : empty('mdi-check-circle-outline','No attention items'))+'</div></div></div><div class="col-lg-5"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Module Activity</div></div><div class="egpk-card-body">'+(adoption.length ? adoption.slice(-8).map(x=>'<div class="d-flex justify-content-between py-2 border-bottom"><span class="small fw-bold">'+esc(x.mod||x.module||'-')+'</span><span class="badge bg-light text-dark">'+esc(x.value||x.count||0)+'</span></div>').join('') : empty('mdi-chart-line','No activity data'))+'</div></div></div></div>');
        }).fail(function(err){ $ws.html(errorBox(err.message || 'Dashboard could not be loaded.')); });
    }

    /* ---------------- ContactBook ---------------- */
    function loadContactCategories() { return ajax('GET', routes.contacts.categories + '?' + query({company_id:state.company === 'all' ? '' : state.company})); }
    function contactForm(item) {
        return loadContactCategories().then(function(res){
            const cats = (res.data || []).map(x=>({value:x.sno,label:x.category_name}));
            return section('Contact details',
                field('salutation','Salutation',item?.salutation,'text',{col:2})+
                field('person_name','Person Name',item?.person_name,'text',{required:true,col:5})+
                field('designation','Designation',item?.designation,'text',{col:5})+
                field('organisation','Company / College',item?.organisation,'text',{col:5})+
                field('department','Department',item?.department,'text',{col:3})+
                field('category_id','Category',item?.category_id,'select',{required:true,col:4,options:cats})+
                field('phone_primary','Primary Phone',item?.phone_primary,'text',{col:4})+
                field('phone_alternate','Alternate Phone',item?.phone_alternate,'text',{col:4})+
                field('email_primary','Email',item?.email_primary,'email',{col:4})+
                field('email_secondary','Secondary Email',item?.email_secondary,'email',{col:4})+
                field('city','City',item?.city,'text',{col:4})+
                field('website','Website',item?.website,'url',{col:6})+
                field('visibility','Visibility',item?.visibility || 'Private','select',{col:6,options:[{value:'Private',label:'Private'},{value:'Team',label:'Team'},{value:'Company',label:'Company'}]})+
                field('address','Address',item?.address,'textarea',{col:12,rows:2})+
                field('notes','Notes',item?.notes,'textarea',{col:12,rows:3})+
                field('is_starred','Favourite',item?.is_starred,'checkbox',{col:3})
            );
        });
    }
    function loadContacts() {
        $search.prop('disabled', false); setViewSwitcher([['table','Table','mdi-table'],['cards','Cards','mdi-view-grid-outline']]);
        setFilterSlot('<select id="egpkContactFilter" class="form-select form-select-sm"><option value="">All Visibility</option><option>Private</option><option>Company</option><option>Group</option></select>');
        loading();
        ajax('GET', routes.contacts.data + '?' + query(commonParams({visibility: $('#egpkContactFilter').val()}))).done(function(res){
            const p = res.data?.pagination || res.pagination || {}; const rows = res.data?.rows || res.data?.data || [];
            $stats.html(statCard('Visible Contacts',p.total||rows.length,'Current scope','mdi-contacts-outline')+statCard('Page',p.current_page||1,'Pagination','mdi-book-open-page-variant-outline')+statCard('Starred',rows.filter(x=>x.is_starred).length,'On this page','mdi-star-outline'));
            if(state.view === 'cards') renderContactCards(rows); else renderContactTable(rows,p);
        }).fail(err=> $ws.html(errorBox(err.message || 'ContactBook failed to load.')));
    }
    function renderContactTable(rows,p){
        const body = rows.length ? rows.map(x=>'<tr><td class="check-cell"><input class="form-check-input egpk-row-check" type="checkbox" value="'+esc(x.sno)+'"></td><td><div class="primary">'+esc(x.person_name)+'</div><span class="secondary">'+esc(x.designation||'')+' · '+esc(x.organisation||'')+'</span></td><td>'+esc(x.phone_primary||'-')+'</td><td>'+esc(x.email_primary||'-')+'</td><td>'+esc(x.category?.category_name||x.category_name||'-')+'</td><td>'+badge(x.visibility)+'</td><td>'+((x.is_starred)?'<i class="mdi mdi-star text-warning"></i>':'')+'</td><td class="text-end"><div class="btn-group btn-group-sm"><button class="btn btn-light" data-egpk-action="view-contact" data-id="'+x.sno+'"><i class="mdi mdi-eye-outline"></i></button><button class="btn btn-light" data-egpk-action="edit-contact" data-id="'+x.sno+'"><i class="mdi mdi-pencil-outline"></i></button><button class="btn btn-light" data-egpk-action="share" data-type="contact" data-id="'+x.sno+'"><i class="mdi mdi-share-variant-outline"></i></button><button class="btn btn-light" data-egpk-action="star-contact" data-id="'+x.sno+'"><i class="mdi '+(x.is_starred?'mdi-star':'mdi-star-outline')+'"></i></button><button class="btn btn-light text-danger" data-egpk-action="delete-contact" data-id="'+x.sno+'"><i class="mdi mdi-delete-outline"></i></button></div></td></tr>').join('') : '<tr><td colspan="8">'+empty('mdi-account-off-outline','No contacts found','<button class="btn btn-primary btn-sm" data-egpk-action="new-contact">Add contact</button>')+'</td></tr>';
        $ws.html('<div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Contact Register</div><div class="d-flex gap-1"><button class="btn btn-outline-secondary btn-sm" data-egpk-action="import-contacts"><i class="mdi mdi-upload-outline"></i> Import</button><a class="btn btn-outline-secondary btn-sm" href="' + esc(routes.contacts.googleConnect) + '"><i class="mdi mdi-google"></i> Gmail</a><button class="btn btn-outline-secondary btn-sm" data-egpk-action="merge-contacts"><i class="mdi mdi-account-switch-outline"></i> Merge</button><button class="btn btn-outline-secondary btn-sm" data-egpk-action="export-contacts"><i class="mdi mdi-export"></i> Export</button></div></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th></th><th>Contact</th><th>Phone</th><th>Email</th><th>Category</th><th>Visibility</th><th>Fav</th><th>Action</th></tr></thead><tbody>'+body+'</tbody></table></div></div></div><div>'+pagination(p.current_page||state.page,p.last_page||1,p.total||rows.length)+'</div>');
    }
    function renderContactCards(rows){
        $ws.html('<div class="row g-3">'+(rows.length?rows.map(x=>'<div class="col-md-6 col-xl-4"><div class="egpk-card h-100"><div class="egpk-card-body"><div class="d-flex justify-content-between"><div><div class="fw-bold">'+esc(x.person_name)+'</div><div class="small text-muted">'+esc(x.designation||'-')+'</div></div>'+badge(x.visibility)+'</div><div class="mt-3 small"><div><i class="mdi mdi-office-building-outline me-1"></i>'+esc(x.organisation||'-')+'</div><div><i class="mdi mdi-phone-outline me-1"></i>'+esc(x.phone_primary||'-')+'</div><div><i class="mdi mdi-email-outline me-1"></i>'+esc(x.email_primary||'-')+'</div></div><div class="mt-3 d-flex gap-1"><button class="btn btn-light btn-sm" data-egpk-action="view-contact" data-id="'+x.sno+'">View</button><button class="btn btn-light btn-sm" data-egpk-action="edit-contact" data-id="'+x.sno+'">Edit</button><button class="btn btn-light btn-sm" data-egpk-action="share" data-type="contact" data-id="'+x.sno+'">Share</button></div></div></div></div>').join(''): '<div class="col-12">'+empty('mdi-account-off-outline','No contacts found')+'</div>')+'</div>');
    }
    function newContact(){ contactForm().done(function(body){ openForm('Add Contact','Create a new governed ContactBook record',body,function(f){submitForm(routes.contacts.store,'POST',f);}); }); }
    function editContact(id){ ajax('GET',url(routes.contacts.show,id)).done(function(res){ contactForm(res.data?.contact || res.data).done(function(body){ openForm('Edit Contact','Update contact details',body,function(f){submitForm(url(routes.contacts.update,id),'PUT',f);}); }); }).fail(err=>notify(err.message||'Unable to load contact','error')); }
    function viewContact(id){ ajax('GET',url(routes.contacts.show,id)).done(function(res){ const d=res.data?.contact||{}; const activity=res.data?.activity||[]; const posts=res.data?.knowledge_posts||[]; $('#egpkViewTitle').text(d.person_name||'Contact'); $('#egpkViewSubtitle').text((d.organisation||'')+' · '+(d.email_primary||'')); $('#egpkViewBody').html('<div class="egpk-detail-grid">'+[['Designation',d.designation],['Organisation',d.organisation],['Department',d.department],['Phone',d.phone_primary],['Alternate Phone',d.phone_alternate],['Email',d.email_primary],['City',d.city],['Visibility',d.visibility],['Category',d.category?.category_name]].map(a=>'<div class="egpk-detail"><label>'+esc(a[0])+'</label><strong>'+esc(a[1]||'-')+'</strong></div>').join('')+'</div><div class="row g-3 mt-1"><div class="col-lg-7"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Activity</div></div><div class="egpk-card-body">'+(activity.length?activity.map(a=>'<div class="border-bottom py-2"><div class="small fw-bold">'+esc(a.action||'-')+'</div><div class="text-muted" style="font-size:8px">'+esc(a.actor_name||'')+' · '+esc(a.created_at||'')+'</div></div>').join(''):empty('mdi-history','No activity'))+'</div></div></div><div class="col-lg-5"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Linked Knowledge</div></div><div class="egpk-card-body">'+(posts.length?posts.map(p=>'<div class="border-bottom py-2 small fw-bold">'+esc(p.title||'-')+'</div>').join(''):empty('mdi-school-outline','No linked posts'))+'</div></div></div></div>'); viewModal().show(); }).fail(err=>notify(err.message||'Unable to load contact','error')); }
    function importContacts(){ openForm('Import Contacts','Excel/CSV/vCard supported. The server validates and reports imported/merged/skipped records.',section('Import',field('file','File','', 'file',{required:true,col:12})) ,function(f){ const fd=new FormData(f[0]); ajax('POST',routes.contacts.import,fd).done(function(r){formModal().hide();notify(r.message||'Import completed.');loadContacts();}).fail(e=>notify(e.message||'Import failed.','error'));}); }

    /* ---------------- BookMarks ---------------- */
    function loadBookmarks(){
        $search.prop('disabled',false);
        setViewSwitcher([['board','Boards','mdi-view-dashboard-outline'],['table','Table','mdi-table']]);
        setFilterSlot('<select id="egpkBookmarkHealth" class="form-select form-select-sm"><option value="">All Health</option><option value="healthy">Healthy</option><option value="checking">Checking</option><option value="broken">Broken</option><option value="unknown">Unknown</option></select>');
        loading();

        if(state.view==='board'){
            ajax('GET',routes.bookmarks.boards+'?'+query({company_id:state.company==='all'?'':state.company}))
                .done(function(res){
                    const boards=Array.isArray(res.data)?res.data:[];
                    $stats.html(statCard('Boards',boards.length,'Readable active boards','mdi-view-dashboard-outline'));
                    renderBoards(boards);
                })
                .fail(function(e){$ws.html(errorBox(e.message||'Bookmarks failed to load.'));});
            return;
        }

        ajax('GET',routes.bookmarks.data+'?'+query(commonParams({health_status:$('#egpkBookmarkHealth').val()})))
            .done(function(res){
                const p=res.data?.rows||{};
                const rows=p.data||[];
                $stats.html(
                    statCard('Bookmarks',p.total||rows.length,'Active permitted links','mdi-bookmark-outline')+
                    statCard('Healthy',rows.filter(function(x){return x.health_status==='healthy';}).length,'Current page','mdi-check-circle-outline')+
                    statCard('Clicks',rows.reduce(function(a,x){return a+Number(x.click_count||0);},0),'Current page','mdi-chart-click-outline')
                );
                renderBookmarkTable(rows,p);
            })
            .fail(function(e){$ws.html(errorBox(e.message||'Bookmarks failed to load.'));});
    }

    function bookmarkIconUrl(bookmark){
        const stored=String(bookmark?.favicon_url||'');
        if(stored && !/google\.com\/s2\/favicons/i.test(stored)) return stored;
        if(bookmark?.url) return routes.bookmarks.faviconImage+'?url='+encodeURIComponent(bookmark.url);
        return '';
    }

    function bookmarkIconMarkup(bookmark,size){
        const px=size||30;
        const src=bookmarkIconUrl(bookmark);
        const fallback=bookmark?.manual_icon||'mdi-bookmark-outline';
        return '<div class="egpk-favicon-wrap" style="width:'+px+'px;height:'+px+'px"><div class="egpk-favicon-fallback"><i class="mdi '+esc(fallback)+'"></i></div>'+(src?'<img class="egpk-favicon-img" loading="lazy" referrerpolicy="no-referrer" src="'+esc(src)+'" alt="" onerror="this.style.display=\'none\'">':'')+'</div>';
    }

    function renderBookmarkTags(tags){
        const list=Array.isArray(tags)?tags:(typeof tags==='string'?tags.split(','):[]);
        return list.filter(Boolean).slice(0,5).map(function(tag){return '<span class="badge bg-light text-dark me-1 mb-1">'+esc(String(tag))+'</span>';}).join('');
    }

    function renderBoards(boards){
        if(!boards.length){
            $ws.html(empty('mdi-bookmark-off-outline','No active boards found','<button class="btn btn-primary btn-sm" data-egpk-action="new-board">Create board</button>'));
            return;
        }

        $ws.html('<div class="egpk-board-grid">'+boards.map(function(b){
            return '<div class="egpk-board">'+
                '<div class="egpk-board-head">'+
                    '<strong title="'+esc(b.board_name||'')+'"><i class="mdi '+esc(b.icon||'mdi-view-dashboard-outline')+' me-1"></i>'+esc(b.board_name||'-')+'</strong>'+badge(b.visibility||'Private')+
                '</div>'+ 
                '<div class="p-2 small text-muted egpk-bookmark-board-description">'+esc(b.description||'No description')+'</div>'+ 
                '<div class="px-2 pb-2">'+
                    '<span class="badge '+(b.is_locked?'bg-warning text-dark':'bg-light text-dark')+' me-1"><i class="mdi '+(b.is_locked?'mdi-lock-outline':'mdi-lock-open-outline')+'"></i> '+(b.is_locked?'Locked':'Editable')+'</span>'+ 
                    (b.is_archived?'<span class="badge bg-secondary">Archived</span>':'')+
                '</div>'+ 
                '<div class="d-flex flex-wrap gap-1 px-2 pb-2">'+
                    '<button class="btn btn-primary btn-sm" data-egpk-action="open-board" data-id="'+b.sno+'"><i class="mdi mdi-open-in-new"></i> Open</button>'+ 
                    '<button class="btn btn-light btn-sm" data-egpk-action="edit-board" data-id="'+b.sno+'"><i class="mdi mdi-pencil-outline"></i></button>'+ 
                    '<button class="btn btn-light btn-sm" data-egpk-action="share" data-type="board" data-id="'+b.sno+'"><i class="mdi mdi-share-variant-outline"></i></button>'+ 
                    '<button class="btn btn-outline-danger btn-sm" data-egpk-action="delete-board" data-id="'+b.sno+'"><i class="mdi mdi-archive-outline"></i></button>'+ 
                '</div>'+ 
            '</div>';
        }).join('')+'</div>');
    }

    function renderBookmarkTable(rows,p){
        const body=rows.length?rows.map(function(x){
            const actions=
                '<button class="btn btn-light btn-sm egpk-action-btn" title="Open" data-egpk-action="open-bookmark" data-id="'+x.sno+'"><i class="mdi mdi-open-in-new"></i></button>'+ 
                '<button class="btn btn-light btn-sm egpk-action-btn" title="Edit" data-egpk-action="edit-bookmark" data-id="'+x.sno+'"><i class="mdi mdi-pencil-outline"></i></button>'+ 
                '<button class="btn btn-light btn-sm egpk-action-btn" title="Check health" data-egpk-action="bookmark-health" data-id="'+x.sno+'"><i class="mdi mdi-heart-pulse"></i></button>'+ 
                '<button class="btn btn-light btn-sm egpk-action-btn" title="Move / copy" data-egpk-action="bookmark-move-copy" data-id="'+x.sno+'"><i class="mdi mdi-content-copy"></i></button>'+ 
                '<button class="btn btn-light btn-sm egpk-action-btn" title="Share" data-egpk-action="share" data-type="bookmark" data-id="'+x.sno+'"><i class="mdi mdi-share-variant-outline"></i></button>'+ 
                '<button class="btn btn-outline-danger btn-sm egpk-action-btn" title="Remove" data-egpk-action="delete-bookmark" data-id="'+x.sno+'"><i class="mdi mdi-delete-outline"></i></button>';
            return '<tr>'+ 
                '<td><div class="d-flex align-items-center gap-2">'+bookmarkIconMarkup(x,32)+'<div class="min-w-0"><div class="primary text-truncate" style="max-width:320px">'+esc(x.bookmark_name||'-')+'</div><span class="secondary text-truncate" style="max-width:360px" title="'+esc(x.url||'')+'">'+esc(x.url||'-')+'</span><div class="mt-1">'+renderBookmarkTags(x.tags_json)+'</div></div></div></td>'+ 
                '<td>'+esc(x.board?.board_name||'-')+'</td>'+ 
                '<td>'+esc(x.category?.category_name||'-')+'</td>'+ 
                '<td>'+esc(x.click_count||0)+'</td>'+ 
                '<td>'+badge(x.health_status||'unknown')+(x.last_checked_at?'<div class="secondary">'+esc(x.last_checked_at)+'</div>':'')+'</td>'+ 
                '<td class="text-end text-nowrap">'+actions+'</td>'+ 
            '</tr>';
        }).join(''):'<tr><td colspan="6">'+empty('mdi-bookmark-off-outline','No bookmarks found','<button class="btn btn-primary btn-sm" data-egpk-action="new-bookmark">Add bookmark</button>')+'</td></tr>';

        $ws.html('<div class="egpk-card"><div class="egpk-card-head"><div><div class="egpk-card-title">Global Bookmark Register</div><small class="text-muted">Official favicons are resolved from each website and cached inside ERP.</small></div><div class="text-nowrap"><button class="btn btn-outline-secondary btn-sm" data-egpk-action="quick-bookmark"><i class="mdi mdi-link-plus"></i> Quick Add</button><button class="btn btn-outline-secondary btn-sm ms-1" data-egpk-action="bookmark-import-html"><i class="mdi mdi-file-import-outline"></i> Import</button><button class="btn btn-primary btn-sm ms-1" data-egpk-action="new-bookmark"><i class="mdi mdi-bookmark-plus-outline"></i> Add</button></div></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Bookmark</th><th>Board</th><th>Category</th><th>Clicks</th><th>Health</th><th>Action</th></tr></thead><tbody>'+body+'</tbody></table></div></div></div>'+pagination(p.current_page||p.current||state.page,p.last_page||p.last||1,p.total||rows.length));
    }

    function openBoard(id){
        ajax('GET',url(routes.bookmarks.board,id)).done(function(res){
            const d=res.data||{};
            state.currentBoard=d.board||null;
            const cats=Array.isArray(d.categories)?d.categories:[];
            const grouped=d.bookmarks||{};
            const total=Object.values(grouped).reduce(function(a,v){return a+(Array.isArray(v)?v.length:0);},0);
            $stats.html(statCard('Categories',cats.length,'In board','mdi-shape-outline')+statCard('Bookmarks',total,'In board','mdi-bookmark-outline')+statCard('Visibility',d.board?.visibility||'-','Access scope','mdi-eye-outline'));

            const headerButtons='<button class="btn btn-light btn-sm" data-egpk-action="new-category" data-id="'+id+'"><i class="mdi mdi-shape-plus-outline"></i> Category</button><button class="btn btn-outline-secondary btn-sm ms-1" data-egpk-action="bookmark-import-html" data-board="'+id+'"><i class="mdi mdi-file-import-outline"></i> Import</button><button class="btn btn-primary btn-sm ms-1" data-egpk-action="new-bookmark" data-board="'+id+'"><i class="mdi mdi-bookmark-plus-outline"></i> Bookmark</button>';

            $ws.html('<div class="egpk-card"><div class="egpk-card-head"><div><div class="egpk-card-title"><i class="mdi '+esc(d.board?.icon||'mdi-view-dashboard-outline')+' me-1"></i>'+esc(d.board?.board_name||'Board')+'</div><small class="text-muted">'+esc(d.board?.description||'No description')+'</small></div><div class="text-nowrap">'+headerButtons+'</div></div><div class="egpk-card-body"><div class="egpk-board-grid">'+
                (cats.length?cats.map(function(c){
                    const bookmarkList=Array.isArray(grouped[c.sno])?grouped[c.sno]:[];
                    return '<div class="egpk-board">'+
                        '<div class="egpk-board-head" style="border-left-color:'+esc(c.color||'#4A3E8E')+'"><strong title="'+esc(c.category_name||'')+'">'+esc(c.category_name||'Category')+'</strong><div class="d-flex gap-1"><button class="btn btn-sm btn-light" title="Edit category" data-egpk-action="edit-category" data-id="'+c.sno+'"><i class="mdi mdi-pencil-outline"></i></button><button class="btn btn-sm btn-outline-danger" title="Delete category" data-egpk-action="delete-category" data-id="'+c.sno+'"><i class="mdi mdi-delete-outline"></i></button></div></div>'+ 
                        '<div class="egpk-board-list">'+
                            (bookmarkList.length?bookmarkList.map(function(b){
                                return '<div class="egpk-bookmark-item"><button type="button" class="btn btn-link p-0 text-start text-decoration-none flex-grow-1 min-w-0" data-egpk-action="open-bookmark" data-id="'+b.sno+'"><div class="d-flex align-items-center gap-2">'+bookmarkIconMarkup(b,28)+'<div class="min-w-0"><div class="egpk-bookmark-title" title="'+esc(b.bookmark_name||'')+'">'+esc(b.bookmark_name||'-')+'</div><div class="egpk-bookmark-domain" title="'+esc(b.url||'')+'">'+esc(b.url||'-')+'</div></div></div></button><div class="dropdown"><button class="btn btn-sm btn-light" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-vertical"></i></button><ul class="dropdown-menu dropdown-menu-end"><li><button class="dropdown-item" data-egpk-action="open-bookmark" data-id="'+b.sno+'"><i class="mdi mdi-open-in-new me-2"></i>Open</button></li><li><button class="dropdown-item" data-egpk-action="edit-bookmark" data-id="'+b.sno+'"><i class="mdi mdi-pencil-outline me-2"></i>Edit</button></li><li><button class="dropdown-item" data-egpk-action="bookmark-health" data-id="'+b.sno+'"><i class="mdi mdi-heart-pulse me-2"></i>Check health</button></li><li><button class="dropdown-item" data-egpk-action="bookmark-move-copy" data-id="'+b.sno+'"><i class="mdi mdi-content-copy me-2"></i>Move / copy</button></li><li><hr class="dropdown-divider"></li><li><button class="dropdown-item text-danger" data-egpk-action="delete-bookmark" data-id="'+b.sno+'"><i class="mdi mdi-delete-outline me-2"></i>Remove</button></li></ul></div></div>';
                            }).join(''):'<div class="p-3 text-muted text-center" style="font-size:9px">No bookmarks in this category</div>')+
                        '</div></div>';
                }).join(''):'<div class="col-12">'+empty('mdi-shape-outline','No categories in this board','<button class="btn btn-primary btn-sm" data-egpk-action="new-category" data-id="'+id+'">Create category</button>')+'</div>')+
            '</div></div></div>');
        }).fail(function(e){notify(e.message||'Unable to open board','error');});
    }

    function loadBookmarkBoards(selectedBoard, done){
        ajax('GET',routes.bookmarks.boards+'?'+query({company_id:state.company==='all'?'':state.company})).done(function(res){
            const boards=(Array.isArray(res.data)?res.data:[]).filter(function(b){return b.can_manage!==false;}).map(function(b){return {value:b.sno,label:b.board_name};});
            if(done) done(boards);
        }).fail(function(e){notify(e.message||'Unable to load boards','error');});
    }

    function loadBookmarkCategories(boardId, selectedCategory, done){
        if(!boardId){ if(done) done([]); return; }
        ajax('GET',url(routes.bookmarks.board,boardId)).done(function(res){
            const rows=Array.isArray(res.data?.categories)?res.data.categories:[];
            if(done) done(rows.map(function(c){return {value:c.sno,label:c.category_name};}));
        }).fail(function(e){notify(e.message||'Unable to load categories','error');});
    }

    function bookmarkPreviewMarkup(item){
        const src=bookmarkIconUrl(item||{});
        return '<div class="egpk-favicon-preview"><div class="egpk-favicon-preview-icon"><i class="mdi mdi-bookmark-outline"></i><img id="egpkBookmarkFaviconPreview" src="'+esc(src||'')+'" alt="Official favicon" '+(src?'':'style="display:none"')+' onerror="this.style.display=\'none\';$(this).prev().show();"><span class="d-none" id="egpkBookmarkFaviconPreviewStatus">No official favicon resolved yet.</span></div><div class="flex-grow-1"><div class="fw-bold small">Official website favicon</div><div id="egpkBookmarkFaviconStatus" class="text-muted" style="font-size:9px">'+(src?'Using the ERP-cached official favicon.':'Enter a URL and resolve the official site favicon.')+'</div></div><button type="button" class="btn btn-outline-secondary btn-sm" id="egpkResolveBookmarkFavicon"><i class="mdi mdi-refresh"></i> Resolve</button></div>';
    }

    function openBookmarkForm(item, defaults, submitEndpoint, submitMethod, title, subtitle){
        const selectedBoard=String(item?.board_id||defaults?.boardId||state.currentBoard?.sno||'');
        const selectedCategory=String(item?.category_id||defaults?.categoryId||'');
        loadBookmarkBoards(selectedBoard,function(boardOptions){
            if(!boardOptions.length){notify('Create an active board before adding a bookmark.','warning');return;}
            const boardValue=boardOptions.some(function(x){return String(x.value)===selectedBoard})?selectedBoard:String(boardOptions[0].value);
            loadBookmarkCategories(boardValue,selectedCategory,function(categoryOptions){
                const categoryValue=categoryOptions.some(function(x){return String(x.value)===selectedCategory})?selectedCategory:(categoryOptions[0]?.value||'');
                const isEdit=!!item;
                const body=section('Bookmark details',
                    field('board_id','Board',boardValue,'select',{required:true,col:4,options:boardOptions})+
                    field('category_id','Category',categoryValue,'select',{required:true,col:4,options:categoryOptions})+
                    field('bookmark_name','Name',item?.bookmark_name||'','text',{required:true,col:4,placeholder:'e.g. Company Portal'})+
                    field('url','URL',item?.url||'','url',{required:true,col:12,placeholder:'https://example.com'})+
                    '<div class="col-12">'+bookmarkPreviewMarkup(item||{})+'</div>'+
                    field('tags','Tags',Array.isArray(item?.tags_json)?item.tags_json.join(', '):'','text',{col:6,placeholder:'erp, finance, reference'})+
                    field('description','Description',item?.description||'','textarea',{col:6,rows:3,placeholder:'Optional notes'})+
                    '<div class="col-12"><div class="alert alert-light border mb-0" style="font-size:9px"><i class="mdi mdi-shield-check-outline me-1"></i>Only public HTTP/HTTPS URLs are accepted. The favicon is fetched from the website itself and cached by ERP; third-party favicon proxy URLs are not used.</div></div>'
                );

                openForm(title|| (isEdit?'Edit Bookmark':'Add Bookmark'),subtitle||'Manage a governed bookmark with official favicon resolution.',body,function(f){
                    const tags=f.find('[name="tags"]').val()||'';
                    const oldName=f.find('[name="bookmark_name"]').val()||'';
                    f.find('[name="bookmark_name"]').val(oldName.trim());
                    f.data('bookmark-tags',tags);
                    submitBookmarkForm(submitEndpoint,submitMethod||'POST',f);
                });

                bindBookmarkFormInteractions();
            });
        });
    }

    function bindBookmarkFormInteractions(){
        const $form=$('#egpkForm');
        if(!$form.length)return;
        $form.off('change.bookmarks','[name="board_id"]').on('change.bookmarks','[name="board_id"]',function(){
            const boardId=$(this).val();
            const $category=$form.find('[name="category_id"]');
            $category.prop('disabled',true).html('<option value="">Loading…</option>');
            loadBookmarkCategories(boardId,'',function(options){
                $category.html('<option value="">Select</option>'+options.map(function(x){return '<option value="'+esc(x.value)+'">'+esc(x.label)+'</option>';}).join('')).prop('disabled',false).trigger('change');
            });
        });
        $form.off('click.bookmarks','#egpkResolveBookmarkFavicon').on('click.bookmarks','#egpkResolveBookmarkFavicon',function(){resolveBookmarkFavicon();});
        $form.off('blur.bookmarks','[name="url"]').on('blur.bookmarks','[name="url"]',function(){if($(this).val())resolveBookmarkFavicon(false);});
    }

    function resolveBookmarkFavicon(showError){
        const $form=$('#egpkForm');
        const urlValue=String($form.find('[name="url"]').val()||'').trim();
        const $status=$form.find('#egpkBookmarkFaviconStatus');
        const $img=$form.find('#egpkBookmarkFaviconPreview');
        const $fallback=$img.prev();
        if(!urlValue){$status.text('Enter a URL and resolve the official site favicon.');$img.hide();$fallback.show();return;}
        $status.html('<span class="spinner-border spinner-border-sm me-1"></span> Resolving official favicon…');
        ajax('GET',routes.bookmarks.favicon+'?url='+encodeURIComponent(urlValue)).done(function(res){
            const d=res.data||{};
            if(d.favicon_url){$img.attr('src',d.favicon_url).show();$fallback.hide();$status.text('Official favicon resolved and cached by ERP.');}
            else{$img.hide();$fallback.show();$status.text('This site did not expose a usable favicon. The bookmark will still be saved.');}
        }).fail(function(e){
            $img.hide();$fallback.show();$status.text(e.message||'Unable to resolve the official favicon.');
            if(showError!==false)notify(e.message||'Unable to resolve the official favicon.','error');
        });
    }

    function submitBookmarkForm(endpoint,method,formEl){
        const $button=$('#egpkFormSubmit');
        $button.prop('disabled',true).html('<span class="spinner-border spinner-border-sm me-1"></span>Saving…');
        const data={};
        $.each(formEl.serializeArray(),function(){
            if(this.name==='tags')return;
            data[this.name]=this.value;
        });
        const tags=String(formEl.data('bookmark-tags')||formEl.find('[name="tags"]').val()||'');
        data.tags=tags.split(',').map(function(x){return x.trim();}).filter(Boolean);
        ajax(method,endpoint,data).done(function(res){
            formModal().hide();
            notify(res.message||'Bookmark saved successfully.');
            loadBookmarks();
        }).fail(function(err){notify(err.message||'Bookmark could not be saved.','error');}).always(function(){$button.prop('disabled',false).html('<i class="mdi mdi-content-save-outline"></i> Save');});
    }

    function boardForm(item){
        return section('Board',
            field('board_name','Board Name',item?.board_name||'','text',{required:true,col:6,placeholder:'e.g. Work Resources'})+
            field('icon','MDI Icon',item?.icon||'mdi-view-dashboard-outline','text',{col:6,placeholder:'mdi-view-dashboard-outline'})+
            field('visibility','Visibility',item?.visibility||'Private','select',{required:true,col:4,options:[{value:'Private',label:'Private'},{value:'Company',label:'Company'},{value:'Group',label:'Group'}]})+
            field('is_locked','Lock Board',item?.is_locked,'checkbox',{col:3})+
            field('description','Description',item?.description||'','textarea',{col:12,rows:3,placeholder:'Explain what belongs in this board.'})+
            '<div class="col-12"><div class="alert alert-light border mb-0" style="font-size:9px"><i class="mdi mdi-shield-lock-outline me-1"></i>Company scope is enforced server-side. Locked boards remain readable according to visibility but cannot be modified unless the current user has manage access.</div></div>'
        );
    }

    function categoryForm(item){
        return section('Category',
            field('category_name','Category Name',item?.category_name||'','text',{required:true,col:7,placeholder:'e.g. Finance'})+
            field('color','Colour',item?.color||'#C0392B','color',{required:true,col:2})+
            field('sort_order','Order',item?.sort_order||0,'number',{col:3,step:'1'})+
            field('is_collapsed','Collapsed by default',item?.is_collapsed,'checkbox',{col:6})
        );
    }

    function quickBookmarkForm(){
        return openBookmarkForm(null,{boardId:state.currentBoard?.sno||'',categoryId:''},routes.bookmarks.quick,'POST','Quick Add Bookmark','Paste a public URL; title, board and category remain fully governed.');
    }

    function editBookmark(id){
        ajax('GET',url(routes.bookmarks.show,id)).done(function(res){
            const item=res.data||null;
            openBookmarkForm(item,{boardId:item?.board_id,categoryId:item?.category_id},url(routes.bookmarks.update,id),'PUT','Edit Bookmark','Update the bookmark and refresh its official favicon when the URL changes.');
        }).fail(function(e){notify(e.message||'Unable to load bookmark.','error');});
    }

    function moveCopyBookmark(id){
        ajax('GET',url(routes.bookmarks.show,id)).done(function(res){
            const item=res.data||{};
            loadBookmarkBoards('',function(boards){
                if(!boards.length){notify('No target boards are available.','warning');return;}
                const currentBoard=String(item.board_id||'');
                const body='<div class="row g-3">'+
                    field('mode','Action','move','select',{required:true,col:4,options:[{value:'move',label:'Move'},{value:'copy',label:'Copy'}]})+
                    field('target_board_id','Target Board',boards.some(function(x){return String(x.value)===currentBoard})?currentBoard:boards[0].value,'select',{required:true,col:8,options:boards})+
                    '<div class="col-12"><label class="form-label">Target Category <span class="text-danger">*</span></label><select class="form-select" name="target_category_id" required><option value="">Loading…</option></select></div>'+ 
                    '<div class="col-12"><div class="alert alert-light border mb-0" style="font-size:9px"><i class="mdi mdi-information-outline me-1"></i>Move changes the existing bookmark location. Copy creates a new bookmark and resets its click counter.</div></div>'+ 
                '</div>';
                openForm('Move / Copy Bookmark','Choose a target board and category.',body,function(f){
                    const button=$('#egpkFormSubmit');
                    button.prop('disabled',true).html('<span class="spinner-border spinner-border-sm me-1"></span>Saving…');
                    ajax('POST',url(routes.bookmarks.moveCopy,id,'move-copy'),f.serialize()).done(function(r){formModal().hide();notify(r.message||'Bookmark moved/copied.');loadBookmarks();}).fail(function(e){notify(e.message||'Move/copy failed.','error');}).always(function(){button.prop('disabled',false).html('<i class="mdi mdi-content-save-outline"></i> Save');});
                });
                function refreshCategories(boardId){
                    const $cat=$('#egpkForm [name="target_category_id"]');
                    $cat.prop('disabled',true).html('<option value="">Loading…</option>');
                    loadBookmarkCategories(boardId,'',function(options){$cat.html('<option value="">Select</option>'+options.map(function(x){return '<option value="'+esc(x.value)+'">'+esc(x.label)+'</option>';}).join('')).prop('disabled',false);});
                }
                refreshCategories($('#egpkForm [name="target_board_id"]').val());
                $('#egpkForm').off('change.bookmarkMove','[name="target_board_id"]').on('change.bookmarkMove','[name="target_board_id"]',function(){refreshCategories($(this).val());});
            });
        }).fail(function(e){notify(e.message||'Unable to load bookmark.','error');});
    }

    function importBookmarks(boardId){
        loadBookmarkBoards(boardId||'',function(boards){
            if(!boards.length){notify('Create an active board before importing bookmarks.','warning');return;}
            const selected=String(boardId||state.currentBoard?.sno||boards[0].value);
            const body=section('Import',
                field('board_id','Destination Board',boards.some(function(x){return String(x.value)===selected})?selected:boards[0].value,'select',{required:true,col:6,options:boards})+
                field('file','HTML Bookmark File','','file',{required:true,col:6})+
                '<div class="col-12"><div class="alert alert-light border mb-0" style="font-size:9px"><i class="mdi mdi-file-import-outline me-1"></i>Up to 10 MB and 500 valid public links are imported. Duplicate URLs on the target board are skipped.</div></div>'
            );
            openForm('Import HTML Bookmarks','Import browser-exported bookmarks into a governed board.',body,function(f){
                const button=$('#egpkFormSubmit');
                button.prop('disabled',true).html('<span class="spinner-border spinner-border-sm me-1"></span>Importing…');
                ajax('POST',routes.bookmarks.importHtml,new FormData(f[0])).done(function(r){formModal().hide();const d=r.data||{};notify((r.message||'Import completed.')+' Imported: '+(d.imported||0)+' · Duplicates: '+(d.duplicates||0)+' · Official favicons: '+(d.favicon_resolved||0));loadBookmarks();}).fail(function(e){notify(e.message||'Import failed.','error');}).always(function(){button.prop('disabled',false).html('<i class="mdi mdi-content-save-outline"></i> Save');});
            });
        });
    }

/* ---------------- PassWallet ---------------- */
    function loadPasswallet(){ $search.prop('disabled',false); setViewSwitcher([['table','Vault','mdi-table'],['shared','Shared','mdi-share-variant-outline']]); setFilterSlot('<select id="egpkVaultType" class="form-select form-select-sm"><option value="">All Types</option><option>Website</option><option>System</option><option>Application</option><option>Mobile App</option></select>'); loading(); ajax('GET',routes.passwallet.data+'?'+query(commonParams({entry_type:$('#egpkVaultType').val()}))).done(function(res){const p=res.data?.rows||{};const rows=p.data||[];$stats.html(statCard('Entries',p.total||rows.length,'Protected vault','mdi-wallet-lock-outline'));$ws.html('<div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">PassWallet Vault</div><button class="btn btn-primary btn-sm" data-egpk-action="new-vault"><i class="mdi mdi-plus"></i> New Entry</button></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Entry</th><th>Type</th><th>Username</th><th>Password</th><th>Rotation</th><th>Action</th></tr></thead><tbody>'+(rows.length?rows.map(x=>'<tr><td><div class="primary">'+esc(x.entry_name)+'</div><span class="secondary">'+esc(x.url||'')+'</span></td><td>'+badge(x.entry_type)+'</td><td>'+esc(x.username||'-')+'</td><td><span class="font-monospace">••••••••</span> <button class="btn btn-light btn-sm" data-egpk-action="reveal-vault" data-id="'+x.sno+'"><i class="mdi mdi-eye-outline"></i></button></td><td>'+badge(x.next_rotation_at ? (new Date(x.next_rotation_at)<new Date()?'Overdue':'Due') : 'Not set')+'</td><td><button class="btn btn-light btn-sm" data-egpk-action="edit-vault" data-id="'+x.sno+'">Edit</button> <button class="btn btn-light btn-sm" data-egpk-action="share" data-type="vault" data-id="'+x.sno+'">Share</button> <button class="btn btn-light btn-sm text-danger" data-egpk-action="delete-vault" data-id="'+x.sno+'">Delete</button></td></tr>').join(''):'<tr><td colspan="6">'+empty('mdi-lock-outline','No vault entries found')+'</td></tr>')+'</tbody></table></div></div></div>'+pagination(p.current_page||p.current||state.page,p.last_page||p.last||1,p.total||rows.length));}).fail(e=>$ws.html(errorBox(e.message||'PassWallet failed.'))); }
    function vaultForm(item){return section('Credential',field('entry_type','Type',item?.entry_type||'Website','select',{required:true,col:4,options:[{value:'Website',label:'Website'},{value:'System',label:'System'},{value:'Application',label:'Application'},{value:'Mobile App',label:'Mobile App'}]})+field('entry_name','Entry Name',item?.entry_name,'text',{required:true,col:8})+field('url','URL',item?.url,'url',{col:6})+field('username','Username',item?.username,'text',{col:6})+field('password','Password','','password',{col:6})+field('email','Registered Email',item?.email,'email',{col:6})+field('mobile','Registered Mobile',item?.mobile,'text',{col:6})+field('rotation_days','Rotation Days',item?.rotation_days||90,'number',{col:3})+field('visibility','Visibility',item?.visibility||'Private','select',{col:3,options:[{value:'Private',label:'Private'},{value:'Company',label:'Company'},{value:'Group',label:'Group'}]})+field('category_id','Category ID',item?.category_id,'number',{required:true,col:3})+field('notes','Notes',item?.notes,'textarea',{col:12,rows:3}));}

    /* ---------------- Knowledge ---------------- */
    function loadKnowledge(){ $search.prop('disabled',false); setViewSwitcher([['feed','Feed','mdi-view-stream-outline'],['library','Library','mdi-bookmark-multiple-outline']]); setFilterSlot('<select id="egpkKnowledgeSort" class="form-select form-select-sm"><option value="newest">Newest</option><option value="most-liked">Most liked</option><option value="relevance">Relevance</option></select>'); loading(); ajax('GET',routes.knowledge.data+'?'+query(commonParams({sort:$('#egpkKnowledgeSort').val(),feed:state.view}))).done(function(res){const p=res.data?.rows||res.data||{};const rows=Array.isArray(p)?p:(p.data||[]);$stats.html(statCard('Posts',p.total||rows.length,'Permitted knowledge','mdi-school-outline'));$ws.html('<div class="egpk-feed-grid"><div>'+ (rows.length?rows.map(renderPost).join(''):'<div class="egpk-card">'+empty('mdi-school-outline','No knowledge posts','<button class="btn btn-primary btn-sm" data-egpk-action="new-knowledge">Create Post</button>')+'</div>')+'</div><div><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Knowledge Tools</div></div><div class="egpk-card-body"><button class="btn btn-primary btn-sm w-100 mb-2" data-egpk-action="new-knowledge">New Post</button><button class="btn btn-light btn-sm w-100 mb-2" data-egpk-action="knowledge-categories">Categories</button><button class="btn btn-light btn-sm w-100" data-egpk-action="knowledge-reports">Moderation</button></div></div></div></div>');}).fail(e=>$ws.html(errorBox(e.message||'Knowledge failed.'))); }
    function renderPost(p){return '<div class="egpk-card mb-3"><div class="egpk-post"><div class="d-flex justify-content-between gap-2"><div><div class="egpk-post-title">'+esc(p.title)+'</div><div class="egpk-post-meta">'+esc(p.author_name||'')+' · '+esc(p.category_name||'')+' · '+esc(p.published_at||p.created_at||'')+'</div></div>'+badge(p.status)+'</div><div class="egpk-post-body">'+(p.body_html||esc(p.body||'')).substring(0,900)+'</div><div class="egpk-post-actions"><button class="egpk-chip-btn" data-egpk-action="view-knowledge" data-id="'+p.sno+'"><i class="mdi mdi-eye-outline"></i> View</button><button class="egpk-chip-btn" data-egpk-action="like-knowledge" data-id="'+p.sno+'"><i class="mdi mdi-heart-outline"></i> '+esc(p.likes||0)+'</button><button class="egpk-chip-btn" data-egpk-action="save-knowledge" data-id="'+p.sno+'"><i class="mdi mdi-bookmark-outline"></i> Save</button><button class="egpk-chip-btn" data-egpk-action="share" data-type="knowledge" data-id="'+p.sno+'"><i class="mdi mdi-share-variant-outline"></i> Share</button></div></div></div>';}
    function knowledgeForm(item){return section('Post',field('title','Title',item?.title,'text',{required:true,col:8})+field('category_id','Category ID',item?.category_id,'number',{required:true,col:4})+field('subcategory_id','Sub-category ID',item?.subcategory_id,'number',{col:4})+field('audience_scope','Audience',item?.audience_scope||'Group','select',{col:4,options:[{value:'Group',label:'Group-wide'},{value:'Company',label:'Company'}]})+field('tags','Tags',Array.isArray(item?.tags_json)?item.tags_json.join(', '):'','text',{col:4})+field('body_html','Content',item?.body_html,'textarea',{col:12,rows:12}));}

    /* ---------------- Portals ---------------- */
    function loadPortals(){ $search.prop('disabled',false);setViewSwitcher([['table','Register','mdi-table'],['launch','Launchpad','mdi-apps']]);setFilterSlot('<select id="egpkPortalStatus" class="form-select form-select-sm"><option value="">All Status</option><option>Live</option><option>Under Maintenance</option><option>Deprecated</option></select>');loading();ajax('GET',routes.portals.data+'?'+query(commonParams({status:$('#egpkPortalStatus').val()}))).done(function(res){const p=res.data?.rows||{};const rows=p.data||[];$stats.html(statCard('Apps',p.total||rows.length,'Registered','mdi-application-braces-outline')+statCard('Live',rows.filter(x=>x.status==='Live').length,'Current page','mdi-check-circle-outline'));$ws.html('<div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Portals & Apps</div><div><button class="btn btn-outline-secondary btn-sm" data-egpk-action="export-portals">Export</button> <button class="btn btn-primary btn-sm" data-egpk-action="new-portal">Add</button></div></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Name</th><th>Platform</th><th>Environment</th><th>Status</th><th>Version</th><th>Action</th></tr></thead><tbody>'+(rows.length?rows.map(x=>'<tr><td><div class="primary">'+esc(x.app_name)+'</div><span class="secondary">'+esc(x.purpose||'')+'</span></td><td>'+esc(x.platform)+'</td><td>'+badge(x.environment)+'</td><td>'+badge(x.status)+'</td><td>'+esc(x.current_version||'-')+'</td><td><button class="btn btn-light btn-sm" data-egpk-action="view-portal" data-id="'+x.sno+'">View</button> <button class="btn btn-light btn-sm" data-egpk-action="edit-portal" data-id="'+x.sno+'">Edit</button> <button class="btn btn-light btn-sm" data-egpk-action="portal-version" data-id="'+x.sno+'">Version</button> <button class="btn btn-light btn-sm" data-egpk-action="share" data-type="portal" data-id="'+x.sno+'">Share</button> <button class="btn btn-light btn-sm" data-egpk-action="launch-portal" data-id="'+x.sno+'">Open</button></td></tr>').join(''):'<tr><td colspan="6">'+empty('mdi-application-off-outline','No applications found')+'</td></tr>')+'</tbody></table></div></div></div>'+pagination(p.current_page||p.current||state.page,p.last_page||p.last||1,p.total||rows.length));}).fail(e=>$ws.html(errorBox(e.message||'Portals failed.'))); }
    function portalForm(item){return section('Registry',field('app_name','App / Portal Name',item?.app_name,'text',{required:true,col:6})+field('app_url','Link',item?.app_url,'url',{required:true,col:6})+field('company_id','Company ID',item?.company_id||state.company,'number',{col:4})+field('purpose','Purpose',item?.purpose,'textarea',{col:8,rows:2})+field('platform','Platform',item?.platform||'Web Portal','select',{required:true,col:4,options:[{value:'Web Portal',label:'Web Portal'},{value:'Mobile App',label:'Mobile App'},{value:'Desktop',label:'Desktop'}]})+field('environment','Environment',item?.environment||'Production','select',{required:true,col:4,options:[{value:'Production',label:'Production'},{value:'Staging',label:'Staging'}]})+field('status','Status',item?.status||'Live','select',{required:true,col:4,options:[{value:'Live',label:'Live'},{value:'Under Maintenance',label:'Under Maintenance'},{value:'Deprecated',label:'Deprecated'}]})+field('technical_owner_user_id','Technical Owner',item?.technical_owner_user_id,'number',{col:4})+field('passwallet_entry_id','PassWallet Entry',item?.passwallet_entry_id,'number',{col:4})+field('icon_path','Icon',item?.icon_path,'text',{col:4}));}

    /* ---------------- Meetings / Events shared calendar ---------------- */
    function localDateKey(date) {
        const d = date instanceof Date ? date : new Date(date);
        if (Number.isNaN(d.getTime())) return '';
        return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    }
    function calendarRange(monthDate){
        const y=monthDate.getFullYear(),m=monthDate.getMonth();
        return {start:localDateKey(new Date(y,m,1)),end:localDateKey(new Date(y,m+1,0))};
    }
    function loadMeetings(){ $search.prop('disabled',false);setViewSwitcher([['table','List','mdi-view-list-outline'],['calendar','Calendar','mdi-calendar-month-outline']]);setFilterSlot('<select id="egpkMeetingScope" class="form-select form-select-sm"><option value="my">My Calendar</option><option value="team">Team</option><option value="company">Company</option></select>');state.view=state.view||'calendar';if(state.view==='calendar') loadMeetingCalendar(); else {loading();ajax('GET',routes.meetings.data+'?'+query(commonParams())).done(res=>{const p=res.data?.rows||{};const rows=p.data||[];$stats.html(statCard('Meetings',p.total||rows.length,'Scheduled','mdi-calendar-account-outline'));$ws.html('<div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Meeting Register</div><button class="btn btn-primary btn-sm" data-egpk-action="new-meeting">New Meeting</button></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Meeting</th><th>Start</th><th>End</th><th>Venue</th><th>Status</th><th>Action</th></tr></thead><tbody>'+(rows.length?rows.map(x=>'<tr><td><div class="primary">'+esc(x.title)+'</div><span class="secondary">'+esc(x.category||'')+'</span></td><td>'+esc(x.start_at)+'</td><td>'+esc(x.end_at)+'</td><td>'+esc(x.venue||'Online')+'</td><td>'+badge(x.status)+'</td><td><button class="btn btn-light btn-sm" data-egpk-action="view-meeting" data-id="'+x.sno+'">View</button> <button class="btn btn-light btn-sm" data-egpk-action="edit-meeting" data-id="'+x.sno+'">Edit</button> <button class="btn btn-light btn-sm" data-egpk-action="reschedule-meeting" data-id="'+x.sno+'">Reschedule</button> <button class="btn btn-light btn-sm" data-egpk-action="share" data-type="meeting" data-id="'+x.sno+'">Share</button></td></tr>').join(''):'<tr><td colspan="6">'+empty('mdi-calendar-remove-outline','No meetings')+'</td></tr>')+'</tbody></table></div></div></div>');}).fail(e=>$ws.html(errorBox(e.message||'Meetings failed.')));}}
    function loadMeetingCalendar(){const r=calendarRange(state.calendarDate);loading();ajax('GET',routes.meetings.calendar+'?'+query(r)).done(res=>{$stats.html(statCard('Calendar',state.calendarDate.toLocaleString('en',{month:'long',year:'numeric'}),'Meeting schedule','mdi-calendar-month-outline'));renderCalendar(res.data||[], 'meetings');}).fail(e=>$ws.html(errorBox(e.message||'Calendar failed.')));}
    function renderCalendar(items,type){const y=state.calendarDate.getFullYear(),m=state.calendarDate.getMonth();const first=new Date(y,m,1);const start=new Date(y,m,1-first.getDay());const days=[];for(let i=0;i<42;i++){const d=new Date(start);d.setDate(start.getDate()+i);days.push(d);}const byDate={};(items||[]).forEach(x=>{const raw=x.start_at||x.event_date;const k=raw?localDateKey(raw):'';(byDate[k] ||= []).push(x);});$ws.html('<div class="egpk-card"><div class="egpk-calendar-toolbar"><div class="d-flex align-items-center gap-2"><button class="btn btn-light btn-sm" data-egpk-action="cal-prev">‹</button><div class="egpk-calendar-title">'+esc(state.calendarDate.toLocaleString('en',{month:'long',year:'numeric'}))+'</div><button class="btn btn-light btn-sm" data-egpk-action="cal-next">›</button><button class="btn btn-outline-secondary btn-sm" data-egpk-action="cal-today">Today</button></div><button class="btn btn-primary btn-sm" data-egpk-action="new-'+type.slice(0,-1)+'">Add</button></div><div class="egpk-calendar-wrap"><div class="egpk-calendar-grid">'+['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(x=>'<div class="egpk-day-head">'+x+'</div>').join('')+days.map(d=>{const k=localDateKey(d);return '<div class="egpk-day-cell '+(d.getMonth()!==m?'muted':'')+'"><div class="egpk-day-no">'+d.getDate()+'</div>'+((byDate[k]||[]).slice(0,4).map(x=>'<div class="egpk-event-pill '+(type==='meetings'?'purple':'gold')+'" data-egpk-action="view-'+type.slice(0,-1)+'" data-id="'+x.sno+'">'+esc(x.title||x.event_name||'-')+'</div>').join(''))+(((byDate[k]||[]).length>4)?'<div class="text-muted" style="font-size:7px">+'+((byDate[k]||[]).length-4)+' more</div>':'')+'</div>';}).join('')+'</div></div></div>');}
    function meetingForm(item){return section('Meeting',field('title','Title',item?.title,'text',{required:true,col:8})+field('category','Category',item?.category||'General','text',{required:true,col:4})+field('start_at','Start',item?.start_at,'datetime-local',{required:true,col:6})+field('end_at','End',item?.end_at,'datetime-local',{required:true,col:6})+field('venue','Venue',item?.venue,'text',{col:6})+field('meeting_url','Online Link',item?.meeting_url,'url',{col:6})+field('reminder_minutes','Reminder Minutes',item?.reminder_minutes||15,'number',{col:4})+field('visibility','Visibility',item?.visibility||'Private','select',{col:4,options:[{value:'Private',label:'Private'},{value:'Company',label:'Company'},{value:'Group',label:'Group'}]})+field('status','Status',item?.status||'Scheduled','select',{col:4,options:['Scheduled','In Progress','Completed','Cancelled','Postponed'].map(x=>({value:x,label:x}))})+multiUserField('participant_ids','Participants',item?.participant_ids||[],12)+field('agenda','Agenda',item?.agenda,'textarea',{col:12,rows:4}));}
    function eventForm(item){return section('Event',field('event_name','Event Name',item?.event_name,'text',{required:true,col:7})+field('organisation','Organiser',item?.organisation,'text',{col:5})+field('event_type','Type',item?.event_type,'text',{col:4})+field('event_date','Date',item?.event_date,'date',{required:true,col:4})+field('event_time','Time',item?.event_time,'time',{col:4})+field('venue','Venue',item?.venue,'text',{col:6})+field('online_link','Online Link',item?.online_link,'url',{col:6})+field('payment_amount','Amount',item?.payment_amount||0,'number',{step:'0.01',col:4})+field('status','Status',item?.status||'Upcoming','select',{col:4,options:['Upcoming','Registered','Attending','Attended','Missed','Cancelled'].map(x=>({value:x,label:x}))})+field('description','Description',item?.description,'textarea',{col:12,rows:4}));}
    function loadEvents(){ $search.prop('disabled',false);setViewSwitcher([['table','List','mdi-view-list-outline'],['calendar','Calendar','mdi-calendar-month-outline']]);setFilterSlot('<select id="egpkEventStatus" class="form-select form-select-sm"><option value="">All Status</option><option>Upcoming</option><option>Registered</option><option>Attending</option><option>Attended</option><option>Missed</option><option>Cancelled</option></select>');if(state.view==='calendar'){const r=calendarRange(state.calendarDate);loading();ajax('GET',routes.events.calendar+'?'+query(r)).done(res=>renderCalendar(res.data||[],'events')).fail(e=>$ws.html(errorBox(e.message||'Event calendar failed.')));}else{loading();ajax('GET',routes.events.data+'?'+query(commonParams({status:$('#egpkEventStatus').val()}))).done(res=>{const p=res.data?.rows||{};const rows=p.data||[];$stats.html(statCard('Events',p.total||rows.length,'Schedule','mdi-calendar-star'));$ws.html('<div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Event Register</div><button class="btn btn-primary btn-sm" data-egpk-action="new-event">Add Event</button></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Event</th><th>Date</th><th>Organiser</th><th>Venue</th><th>Status</th><th>Action</th></tr></thead><tbody>'+(rows.length?rows.map(x=>'<tr><td><div class="primary">'+esc(x.event_name)+'</div><span class="secondary">'+esc(x.event_type||'')+'</span></td><td>'+esc(x.event_date)+' '+esc(x.event_time||'')+'</td><td>'+esc(x.organisation||'-')+'</td><td>'+esc(x.venue||'Online')+'</td><td>'+badge(x.status)+'</td><td><button class="btn btn-light btn-sm" data-egpk-action="view-event" data-id="'+x.sno+'">View</button> <button class="btn btn-light btn-sm" data-egpk-action="edit-event" data-id="'+x.sno+'">Edit</button> <button class="btn btn-light btn-sm" data-egpk-action="share" data-type="event" data-id="'+x.sno+'">Share</button></td></tr>').join(''):'<tr><td colspan="6">'+empty('mdi-calendar-remove-outline','No events')+'</td></tr>')+'</tbody></table></div></div></div>');}).fail(e=>$ws.html(errorBox(e.message||'Events failed.')));}}

    /* ---------------- Tasks ---------------- */
    function loadTasks(){ $search.prop('disabled',false);setViewSwitcher([['kanban','Kanban','mdi-view-column-outline'],['table','Table','mdi-table']]);setFilterSlot('<select id="egpkTaskPriority" class="form-select form-select-sm"><option value="">All Priority</option><option>Urgent</option><option>High</option><option>Medium</option><option>Low</option></select>');loading();ajax('GET',routes.tasks.data+'?'+query(commonParams({priority:$('#egpkTaskPriority').val()}))).done(function(res){const p=res.data?.rows||{};const rows=p.data||[];$stats.html(statCard('Tasks',p.total||rows.length,'Work items','mdi-format-list-checks')+statCard('Urgent',rows.filter(x=>x.priority==='Urgent').length,'Current page','mdi-alert-outline'));state.view==='kanban'?renderTaskKanban(rows):renderTaskTable(rows,p);}).fail(e=>$ws.html(errorBox(e.message||'Tasks failed.'))); }
    function renderTaskKanban(rows){const stages=['To Do','In Progress','On Hold','Pending Verification','Completed'];$ws.html('<div class="egpk-kanban">'+stages.map(s=>'<div class="egpk-kanban-col"><div class="egpk-kanban-head">'+esc(s)+' <span class="badge bg-light text-dark float-end">'+rows.filter(x=>x.status===s).length+'</span></div>'+rows.filter(x=>x.status===s).map(x=>'<div class="egpk-task"><div class="d-flex justify-content-between"><div class="egpk-task-title">'+esc(x.title)+'</div>'+badge(x.priority)+'</div><div class="egpk-task-meta">'+esc(x.due_at||'No deadline')+'</div><div class="mt-2"><button class="btn btn-light btn-sm" data-egpk-action="view-task" data-id="'+x.sno+'">View</button></div></div>').join('')+'</div>').join('')+'</div>'); }
    function renderTaskTable(rows,p){$ws.html('<div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Task Register</div><button class="btn btn-primary btn-sm" data-egpk-action="new-task">New Task</button></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Task</th><th>Priority</th><th>Due</th><th>Status</th><th>Supervisor</th><th>Action</th></tr></thead><tbody>'+(rows.length?rows.map(x=>'<tr><td><div class="primary">'+esc(x.title)+'</div><span class="secondary">'+esc(x.category||'')+'</span></td><td>'+badge(x.priority)+'</td><td>'+esc(x.due_at||'-')+'</td><td>'+badge(x.status)+'</td><td>'+esc(x.supervisor_user_id||'-')+'</td><td><button class="btn btn-light btn-sm" data-egpk-action="view-task" data-id="'+x.sno+'">View</button> <button class="btn btn-light btn-sm" data-egpk-action="edit-task" data-id="'+x.sno+'">Edit</button> <button class="btn btn-light btn-sm" data-egpk-action="share" data-type="task" data-id="'+x.sno+'">Share</button></td></tr>').join(''):'<tr><td colspan="6">'+empty('mdi-format-list-checks','No tasks')+'</td></tr>')+'</tbody></table></div></div></div>'+pagination(p.current_page||p.current||state.page,p.last_page||p.last||1,p.total||rows.length));}
    function taskForm(item){return section('Task',field('title','Title',item?.title,'text',{required:true,col:8})+field('category','Category',item?.category,'text',{col:4})+field('due_at','Deadline',item?.due_at,'datetime-local',{col:6})+field('priority','Priority',item?.priority||'Medium','select',{col:6,options:['Urgent','High','Medium','Low'].map(x=>({value:x,label:x}))})+field('supervisor_user_id','Supervisor',item?.supervisor_user_id,'number',{col:4})+field('verification_required','Verification Required',item?.verification_required,'checkbox',{col:4})+field('visibility','Visibility',item?.visibility||'Private','select',{col:4,options:[{value:'Private',label:'Private'},{value:'Company',label:'Company'},{value:'Group',label:'Group'}]})+multiUserField('assignee_ids','Assignees',item?.assignee_ids||[],12)+field('description','Description',item?.description,'textarea',{col:12,rows:5}));}

    /* ---------------- Notes ---------------- */
    function loadNotes(){ $search.prop('disabled',false);setViewSwitcher([['grid','Notes','mdi-view-grid-outline'],['table','Table','mdi-table']]);setFilterSlot('<select id="egpkNoteScope" class="form-select form-select-sm"><option value="">All</option><option value="active">Active</option><option value="archive">Archived</option><option value="trash">Trash</option></select>');loading();ajax('GET',routes.notes.data+'?'+query(commonParams({scope:$('#egpkNoteScope').val()}))).done(function(res){const p=res.data?.rows||{};const rows=p.data||[];$stats.html(statCard('Notes',p.total||rows.length,'Personal workspace','mdi-note-multiple-outline'));state.view==='grid'?renderNotes(rows):renderNoteTable(rows,p);}).fail(e=>$ws.html(errorBox(e.message||'Notes failed.'))); }
    function renderNotes(rows){$ws.html('<div class="egpk-note-grid">'+(rows.length?rows.map(x=>'<div class="egpk-note" style="background:'+esc(x.color||'#fff8c7')+'"><div class="d-flex justify-content-between"><h6>'+esc(x.title||'Untitled')+'</h6>'+badge(x.visibility)+'</div><p>'+esc(x.body||'')+'</p><div class="small text-muted">'+esc(x.reminder_at||'')+'</div><div class="mt-2 d-flex gap-1"><button class="btn btn-light btn-sm" data-egpk-action="edit-note" data-id="'+x.sno+'">Edit</button><button class="btn btn-light btn-sm" data-egpk-action="note-pin" data-id="'+x.sno+'">Pin</button><button class="btn btn-light btn-sm" data-egpk-action="share" data-type="note" data-id="'+x.sno+'">Share</button></div></div>').join(''):'<div>'+empty('mdi-note-off-outline','No notes','<button class="btn btn-primary btn-sm" data-egpk-action="new-note">Take a note</button>')+'</div>')+'</div>'); }
    function renderNoteTable(rows,p){$ws.html('<div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Sticky Notes</div><button class="btn btn-primary btn-sm" data-egpk-action="new-note">New Note</button></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Title</th><th>Visibility</th><th>Reminder</th><th>Pinned</th><th>Action</th></tr></thead><tbody>'+(rows.length?rows.map(x=>'<tr><td>'+esc(x.title)+'</td><td>'+badge(x.visibility)+'</td><td>'+esc(x.reminder_at||'-')+'</td><td>'+badge(x.is_pinned?'Pinned':'Normal')+'</td><td><button class="btn btn-light btn-sm" data-egpk-action="edit-note" data-id="'+x.sno+'">Edit</button></td></tr>').join(''):'<tr><td colspan="5">'+empty('mdi-note-off-outline','No notes')+'</td></tr>')+'</tbody></table></div></div></div>'+pagination(p.current_page||p.current||state.page,p.last_page||p.last||1,p.total||rows.length));}
    function noteForm(item){return section('Note',field('title','Title',item?.title,'text',{required:true,col:8})+field('color','Colour',item?.color||'#fff8c7','color',{col:4})+field('visibility','Visibility',item?.visibility||'Private','select',{col:4,options:[{value:'Private',label:'Private'},{value:'Company',label:'Company'},{value:'Group',label:'Group'}]})+field('label','Label',item?.label,'text',{col:4})+field('priority','Priority',item?.priority||'normal','select',{col:4,options:[{value:'normal',label:'Normal'},{value:'high',label:'High'}]})+field('reminder_at','Reminder',item?.reminder_at,'datetime-local',{col:6})+field('body','Note',item?.body,'textarea',{col:12,rows:8}));}

    /* ---------------- Money ---------------- */
    function loadMoney(){ $search.prop('disabled',false);setViewSwitcher([]);setFilterSlot('');loading();ajax('GET',routes.money.data+'?'+query({company_id:state.company==='all'?'':state.company})).done(function(res){const d=res.data||{};const s=d.summary||{};$stats.html(statCard('Income','₹'+Number(s.income||0).toLocaleString('en-IN'),'Tracked','mdi-arrow-bottom-left-thick')+statCard('Expense','₹'+Number(s.expense||0).toLocaleString('en-IN'),'Tracked','mdi-arrow-top-right-thick')+statCard('Balance','₹'+Number(s.balance||0).toLocaleString('en-IN'),'Personal','mdi-wallet-outline'));const tx=d.transactions||[];$ws.html('<div class="row g-3"><div class="col-lg-7"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Transactions</div><button class="btn btn-light btn-sm" data-egpk-action="new-money-account">Account</button><button class="btn btn-light btn-sm" data-egpk-action="new-money-budget">Budget</button><button class="btn btn-primary btn-sm" data-egpk-action="new-money-transaction">Quick Entry</button></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Date</th><th>Category</th><th>Mode</th><th>Type</th><th>Amount</th></tr></thead><tbody>'+(tx.length?tx.map(x=>'<tr><td>'+esc(x.transaction_date)+'</td><td>'+esc(x.category)+'</td><td>'+esc(x.mode||'-')+'</td><td>'+badge(x.transaction_type)+'</td><td class="text-end">₹'+Number(x.amount||0).toLocaleString('en-IN')+'</td></tr>').join(''):'<tr><td colspan="5">'+empty('mdi-cash-off','No transactions')+'</td></tr>')+'</tbody></table></div></div></div></div><div class="col-lg-5"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Commitments</div><button class="btn btn-light btn-sm" data-egpk-action="new-commitment">Add</button></div><div class="egpk-card-body">'+((d.commitments||[]).length?(d.commitments||[]).slice(0,8).map(x=>'<div class="d-flex justify-content-between border-bottom py-2"><div><div class="small fw-bold">'+esc(x.commitment_name)+'</div><div class="small text-muted">'+esc(x.due_date)+'</div></div><strong>₹'+Number(x.amount||0).toLocaleString('en-IN')+'</strong></div>').join(''):empty('mdi-calendar-remove-outline','No commitments'))+'</div></div></div></div>');}).fail(e=>$ws.html(errorBox(e.message||'Money failed.'))); }

    /* ---------------- Documents ---------------- */
    function loadDocuments(){ $search.prop('disabled',false);setViewSwitcher([['table','Files','mdi-table'],['grid','Grid','mdi-view-grid-outline']]);setFilterSlot('<select id="egpkDocumentScope" class="form-select form-select-sm"><option value="">All Scope</option><option>Personal</option><option>Official</option></select>');loading();ajax('GET',routes.documents.data+'?'+query(commonParams({scope:$('#egpkDocumentScope').val()}))).done(function(res){const p=res.data?.rows||{};const rows=p.data||[];$stats.html(statCard('Documents',p.total||rows.length,'Accessible files','mdi-file-document-multiple-outline'));$ws.html('<div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Document Register</div><button class="btn btn-primary btn-sm" data-egpk-action="upload-document"><i class="mdi mdi-upload-outline"></i> Upload</button></div><div class="egpk-card-body p-0"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr><th>Document</th><th>Scope</th><th>Category</th><th>Version</th><th>Expiry</th><th>Action</th></tr></thead><tbody>'+(rows.length?rows.map(x=>'<tr><td><div class="primary">'+esc(x.document_name)+'</div><span class="secondary">'+esc(x.mime_type||'')+' · '+esc(x.file_size||0)+' bytes</span></td><td>'+badge(x.scope||x.visibility)+'</td><td>'+esc(x.category||'-')+'</td><td>v'+esc(x.version_no||1)+'</td><td>'+esc(x.expiry_date||'-')+'</td><td><button class="btn btn-light btn-sm" data-egpk-action="open-document" data-id="'+x.sno+'">Open</button><button class="btn btn-light btn-sm" data-egpk-action="pin-document" data-id="'+x.sno+'">Pin</button><button class="btn btn-light btn-sm" data-egpk-action="share" data-type="document" data-id="'+x.sno+'">Share</button></td></tr>').join(''):'<tr><td colspan="6">'+empty('mdi-file-hidden','No documents')+'</td></tr>')+'</tbody></table></div></div></div>');}).fail(e=>$ws.html(errorBox(e.message||'Documents failed.'))); }
    function documentUpload(){openForm('Upload Document','Files are validated and stored using the configured ERP storage disk.',section('Document',field('document_name','Document Name','','text',{col:6})+field('company_id','Company ID',state.company,'number',{col:3})+field('visibility','Visibility','Private','select',{col:3,options:[{value:'Private',label:'Private'},{value:'Company',label:'Company'},{value:'Group',label:'Group'}]})+field('scope','Scope','Personal','select',{col:3,options:[{value:'Personal',label:'Personal'},{value:'Official',label:'Official'}]})+field('category','Category','','text',{col:5})+field('expiry_date','','','date',{col:4})+field('document','File','','file',{required:true,col:12})),function(f){const fd=new FormData(f[0]);ajax('POST',routes.documents.upload,fd).done(r=>{formModal().hide();notify(r.message||'Document uploaded.');loadDocuments();}).fail(e=>notify(e.message||'Upload failed.','error'));});}

    /* ---------------- Admin / Reports ---------------- */
    function loadReports(){ $search.prop('disabled',false);setViewSwitcher([]);setFilterSlot('<select id="egpkReportType" class="form-select form-select-sm"><option value="contacts">Contact Master</option><option value="imports">Import Audit</option><option value="bookmarks">Board Health</option><option value="vault">Credential Compliance</option><option value="knowledge">Knowledge Engagement</option><option value="apps">Application Inventory</option><option value="audit">Audit Extract</option></select>');loading();ajax('GET',routes.reports.data+'?'+query({report:$('#egpkReportType').val(),company_id:state.company==='all'?'':state.company})).done(function(res){const payload=res.data||{};const rows=Array.isArray(payload)?payload:(Array.isArray(payload.data)?payload.data:(payload.rows||[]));$stats.html(statCard('Rows',rows.length,'Selected report','mdi-chart-box-outline'));$ws.html('<div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Report Preview</div><div><button class="btn btn-outline-secondary btn-sm" data-egpk-action="report-csv">CSV</button><button class="btn btn-primary btn-sm" data-egpk-action="report-xlsx">XLSX</button></div></div><div class="egpk-card-body"><div class="egpk-table-wrap"><table class="egpk-table"><thead><tr>'+((rows[0]?Object.keys(rows[0]):['Result']).slice(0,8).map(k=>'<th>'+esc(k.replace(/_/g,' '))+'</th>').join(''))+'</tr></thead><tbody>'+ (rows.length?rows.map(x=>'<tr>'+Object.keys(rows[0]).slice(0,8).map(k=>'<td>'+esc(typeof x[k]==='object'?JSON.stringify(x[k]):x[k])+'</td>').join('')+'</tr>').join(''):'<tr><td>'+empty('mdi-chart-box-outline','No report data')+'</td></tr>')+'</tbody></table></div></div></div>');}).fail(e=>$ws.html(errorBox(e.message||'Report failed.')));}
    function loadAdmin(){ $search.prop('disabled',false);setViewSwitcher([]);setFilterSlot('');loading();ajax('GET',routes.admin.data).done(function(res){const d=res.data||{};$stats.html(statCard('Shares',(d.shares||[]).length,'Recent grants','mdi-share-variant-outline')+statCard('Audit',(d.audits||[]).length,'Recent events','mdi-history'));$ws.html('<div class="row g-3"><div class="col-lg-7"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Share Governance</div></div><div class="egpk-card-body">'+tableSimple(d.shares||[],['resource_type','resource_id','grantee_type','permission','status','expires_at'])+'</div></div></div><div class="col-lg-5"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Recent Audit</div></div><div class="egpk-card-body">'+tableSimple(d.audits||[],['module_name','action','actor_user_id','created_at'])+'</div></div></div></div><div class="row g-3 mt-0"><div class="col-12"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Create Category</div></div><div class="egpk-card-body"><button class="btn btn-primary btn-sm" data-egpk-action="new-admin-category">Add Master Category</button></div></div></div></div>');}).fail(e=>$ws.html(errorBox(e.message||'Admin failed.'))); }
    function tableSimple(rows,keys){return rows.length?'<div class="egpk-table-wrap"><table class="egpk-table"><thead><tr>'+keys.map(k=>'<th>'+esc(k.replace(/_/g,' '))+'</th>').join('')+'</tr></thead><tbody>'+rows.slice(0,100).map(r=>'<tr>'+keys.map(k=>'<td>'+esc(r[k])+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>':empty('mdi-database-off-outline','No records');}

    /* ---------------- Generic dispatch ---------------- */
    function loadModule(){
        $search.val(state.search);
        switch(moduleName){
            case 'dashboard': return loadDashboard();
            case 'contacts': return loadContacts();
            case 'bookmarks': return loadBookmarks();
            case 'passwallet': return loadPasswallet();
            case 'knowledge': return loadKnowledge();
            case 'portals': return loadPortals();
            case 'meetings': return loadMeetings();
            case 'tasks': return loadTasks();
            case 'notes': return loadNotes();
            case 'money': return loadMoney();
            case 'events': return loadEvents();
            case 'documents': return loadDocuments();
            case 'reports': return loadReports();
            case 'admin': return loadAdmin();
            default: return loadDashboard();
        }
    }

    function operationButton(action, label, icon, id) {
        return '<button type="button" class="btn btn-light btn-sm w-100 text-start mb-2" data-egpk-action="'+esc(action)+'"'+(id!=null?' data-id="'+esc(id)+'"':'')+'><i class="mdi '+esc(icon||'mdi-chevron-right')+' me-2"></i>'+esc(label)+'</button>';
    }

    function openAdvancedOperations() {
        const sets = {
            contacts: [
                ['contact-search-history','Search history','mdi-history'],['contact-save-search','Save current search','mdi-content-save-search-outline'],
                ['contact-bulk','Bulk update','mdi-playlist-edit'],['contact-merge','Merge contacts','mdi-account-switch-outline'],['import-contacts','Import contacts','mdi-database-import-outline'],['export-contacts','Export contacts','mdi-file-export-outline'],
                ['contacts-google-connect','Google Contacts','mdi-google'],
            ],
            bookmarks: [
                ['quick-bookmark','Quick add','mdi-bookmark-plus-outline'],['bookmark-import-html','Import HTML bookmarks','mdi-file-import-outline'],['bookmark-move-copy','Move / copy bookmark','mdi-content-copy'],
            ],
            passwallet: [
                ['password-generator','Password generator','mdi-form-textbox-password'],['vault-history','Entry history','mdi-history'],['vault-shares','Entry shares','mdi-share-variant-outline'],['vault-attachments','Attachments','mdi-paperclip'],
                ['vault-add-attachment','Add attachment','mdi-paperclip-plus'],['vault-copy-audit','Copy audit access','mdi-content-copy'],['vault-lockdown','User lockdown','mdi-lock-alert-outline'],
            ],
            knowledge: [
                ['knowledge-categories','Categories','mdi-shape-outline'],['knowledge-follow','Follow category/post','mdi-bell-plus-outline'],['knowledge-media','Upload media','mdi-file-image-plus-outline'],['knowledge-moderate','Moderation','mdi-shield-check-outline'],
            ],
            portals: [
                ['portal-version','Record version','mdi-source-branch-plus'],['portal-subscribe','Subscribe / unsubscribe','mdi-bell-outline'],['export-portals','Export XLSX','mdi-file-excel-outline'],
            ],
            meetings: [
                ['meeting-rsvp','RSVP','mdi-calendar-check-outline'],['meeting-reschedule','Reschedule','mdi-calendar-clock-outline'],['delete-meeting','Delete meeting','mdi-delete-outline'],
            ],
            tasks: [
                ['task-status','Change status','mdi-progress-check'],['task-comment','Comment','mdi-comment-plus-outline'],['task-verify','Verify','mdi-check-decagram-outline'],['delete-task','Delete task','mdi-delete-outline'],
            ],
            notes: [
                ['note-action-pin','Pin / unpin','mdi-pin-outline'],['note-action-archive','Archive','mdi-archive-outline'],['note-action-trash','Trash','mdi-trash-can-outline'],['note-action-restore','Restore','mdi-restore'],
            ],
            money: [
                ['new-money-account','Account','mdi-bank-outline'],['new-money-budget','Budget','mdi-chart-box-outline'],['new-commitment','Commitment','mdi-calendar-alert-outline'],
            ],
            events: [['event-calendar','Calendar','mdi-calendar-month-outline'],['delete-event','Delete event','mdi-delete-outline']],
            documents: [['document-version','New version','mdi-file-replace-outline'],['document-versions','Version history','mdi-source-branch'],['open-document','Open document','mdi-open-in-new'],['pin-document','Pin / unpin','mdi-pin-outline'],['delete-document','Delete document','mdi-delete-outline']],
            reports: [['report-csv','CSV export','mdi-file-delimited-outline'],['report-xlsx','XLSX export','mdi-file-excel-outline']],
            admin: [['new-admin-category','Create master category','mdi-shape-plus-outline']],
        };
        const entries = (sets[moduleName] || []).map(x => operationButton(x[0],x[1],x[2])).join('');
        const body = '<div class="row g-3"><div class="col-lg-7"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Additional module operations</div></div><div class="egpk-card-body">'+(entries || empty('mdi-tune-variant','No additional operations for this module'))+'</div></div></div><div class="col-lg-5"><div class="egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Sharing</div></div><div class="egpk-card-body">'+operationButton('share-resource','Open resource sharing','mdi-share-variant-outline')+operationButton('share-approval','Pending share approvals','mdi-check-decagram-outline')+'</div></div></div></div>';
        $('#egpkViewTitle').text('More actions');$('#egpkViewSubtitle').text('All secondary operations remain AJAX based and respect server-side permissions.');$('#egpkViewBody').html(body);viewModal().show();
    }

    function promptForId(title, submit) {
        return openForm(title,'Enter the record ID from the current register.',field('record_id','Record ID','','number',{required:true,col:12}),function(f){const id=f.find('[name="record_id"]').val();submit(id);});
    }

    function openContactExport(){
        return openForm('Export Contacts','Choose a server-generated export format.',field('format','Format','xlsx','select',{required:true,col:12,options:[{value:'csv',label:'CSV'},{value:'xlsx',label:'Excel XLSX'},{value:'vcard',label:'vCard'}]}),function(f){
            const format=f.find('[name="format"]').val(); const map={csv:routes.contacts.exportCsv,xlsx:routes.contacts.exportXlsx,vcard:routes.contacts.vcard}; download('GET',map[format],commonParams(), 'contacts.'+(format==='vcard'?'vcf':format)); formModal().hide();
        });
    }

    function showRows(title, rows, fields) {
        const html = Array.isArray(rows)&&rows.length ? tableSimple(rows,fields||Object.keys(rows[0]||{})) : empty('mdi-information-outline','No records found');
        $('#egpkViewTitle').text(title);$('#egpkViewSubtitle').text('Loaded from the secured AJAX endpoint.');$('#egpkViewBody').html('<div class="egpk-card"><div class="egpk-card-body">'+html+'</div></div>');viewModal().show();
    }

    function dispatchAction(action,id,type,extra){
        if(action==='new-contact') return newContact();
        if(action==='edit-contact') return editContact(id);
        if(action==='view-contact') return viewContact(id);
        if(action==='import-contacts') return importContacts();
        if(action==='star-contact') return ajax('POST',url(routes.contacts.star,id)).done(()=>{notify('Favourite updated.');loadContacts();}).fail(e=>notify(e.message||'Unable to update.','error'));
        if(action==='delete-contact') return confirmAction('Deactivate contact','This contact will be deactivated.','Deactivate',()=>ajax('DELETE',url(routes.contacts.delete,id)).done(()=>{notify('Contact deactivated.');loadContacts();}));
        if(action==='export-contacts') return openContactExport();
        if(action==='merge-contacts') return notify('Select two contacts in the register for merge.', 'warning');
        if(action==='new-board') return openForm('Create Board','Personal or shared collaborative board',boardForm(),f=>submitForm(routes.bookmarks.boardStore,'POST',f));
        if(action==='edit-board') return ajax('GET',url(routes.bookmarks.board,id)).done(res=>{const b=res.data?.board||res.data;openForm('Edit Board','Update board',boardForm(b),f=>submitForm(url(routes.bookmarks.boardUpdate,id),'PUT',f));}).fail(e=>notify(e.message||'Unable to load board','error'));
        if(action==='delete-board') return confirmAction('Archive board','The board and its bookmarks will leave active views. Existing records remain auditable.','Archive',function(){ajax('DELETE',url(routes.bookmarks.boardDelete,id)).done(function(){notify('Board archived successfully.');state.currentBoard=null;loadBookmarks();}).fail(function(e){notify(e.message||'Unable to archive board.','error');});});
        if(action==='open-board') return openBoard(id);
        if(action==='new-category') return openForm('Add Category','Visual category inside the selected board',categoryForm(),f=>submitForm(url(routes.bookmarks.categoryStore,id),'POST',f,function(){openBoard(id);}));
        if(action==='edit-category') return ajax('GET',url(routes.bookmarks.board,state.currentBoard?.sno||0)).done(function(res){const cat=(res.data?.categories||[]).find(function(x){return String(x.sno)===String(id);});if(!cat){notify('Category could not be loaded.','error');return;}openForm('Edit Category','Change colour, order or collapse state.',categoryForm(cat),f=>submitForm(url(routes.bookmarks.categoryUpdate,id),'PUT',f,function(){if(state.currentBoard)openBoard(state.currentBoard.sno);}));}).fail(e=>notify(e.message||'Unable to load category','error'));
        if(action==='delete-category') return confirmAction('Delete category','Only empty categories can be deleted.','Delete',function(){ajax('DELETE',url(routes.bookmarks.categoryDelete,id)).done(function(){notify('Category deleted successfully.');if(state.currentBoard)openBoard(state.currentBoard.sno);else loadBookmarks();}).fail(function(e){notify(e.message||'Unable to delete category.','error');});});
        if(action==='quick-bookmark') return quickBookmarkForm();
        if(action==='new-bookmark') return openBookmarkForm(null,{boardId:extra?.board||state.currentBoard?.sno||'',categoryId:''},routes.bookmarks.store,'POST','Add Bookmark','Add a governed bookmark with official favicon resolution.');
        if(action==='edit-bookmark') return editBookmark(id);
        if(action==='delete-bookmark') return confirmAction('Remove bookmark','The bookmark will be archived and removed from active registers.','Remove',function(){ajax('DELETE',url(routes.bookmarks.delete,id)).done(function(){notify('Bookmark removed successfully.');if(state.currentBoard)openBoard(state.currentBoard.sno);else loadBookmarks();}).fail(function(e){notify(e.message||'Unable to remove bookmark.','error');});});
        if(action==='open-bookmark') return ajax('POST',url(routes.bookmarks.open,id)).done(res=>{if(res.data?.url)window.open(res.data.url,'_blank','noopener');}).fail(e=>notify(e.message||'Unable to open bookmark','error'));
        if(action==='bookmark-health') return ajax('POST',url(routes.bookmarks.health,id)).done(r=>{const d=r.data||{};notify((d.health_status||'')==='healthy'?'Link is healthy.':'Link reported broken.','warning');if(state.currentBoard)openBoard(state.currentBoard.sno);else loadBookmarks();}).fail(e=>notify(e.message||'Health check failed','error'));
        if(action==='bookmark-move-copy') return moveCopyBookmark(id);
        if(action==='bookmark-import-html') return importBookmarks(extra?.board||state.currentBoard?.sno||'');
        if(action==='new-vault') return openForm('New PassWallet Entry','Secrets are encrypted server-side; sensitive actions use step-up verification.',vaultForm(),f=>submitForm(routes.passwallet.store,'POST',f));
        if(action==='edit-vault') return ajax('GET',url(routes.passwallet.show,id)).done(res=>{const d=res.data?.entry||res.data;openForm('Edit PassWallet Entry','Credentials remain masked',vaultForm(d),f=>submitForm(url(routes.passwallet.update,id),'PUT',f));}).fail(e=>notify(e.message||'Unable to load vault entry','error'));
        if(action==='reveal-vault') return requestStepUp(()=>ajax('POST',url(routes.passwallet.reveal,id)).done(r=>{const d=r.data||{};$('#egpkViewTitle').text(d.entry_name||'Credential');$('#egpkViewBody').html('<div class="egpk-detail-grid"><div class="egpk-detail"><label>Username</label><strong>'+esc(d.username||'-')+'</strong></div><div class="egpk-detail"><label>Password</label><strong class="font-monospace">'+esc(d.password||'••••••••')+'</strong></div></div>');viewModal().show();}).fail(e=>notify(e.message||'Reveal denied','error')));
        if(action==='delete-vault') return confirmAction('Delete credential','This removes the vault entry from active records.','Delete',()=>ajax('DELETE',url(routes.passwallet.delete,id)).done(()=>{notify('Vault entry deleted.');loadPasswallet();}));
        if(action==='new-knowledge') return openForm('Create Knowledge Post','Use rich text and add media after creation.',knowledgeForm(),f=>submitForm(routes.knowledge.store,'POST',f));
        if(action==='view-knowledge') return ajax('GET',url(routes.knowledge.show,id)).done(res=>{const d=res.data?.post||res.data;$('#egpkViewTitle').text(d.title||'Knowledge');$('#egpkViewSubtitle').text(d.author_name||'');$('#egpkViewBody').html('<article class="egpk-post"><div class="egpk-post-body">'+(d.body_html||esc(d.body||''))+'</div><div class="egpk-post-actions"><button class="egpk-chip-btn" data-egpk-action="reply-knowledge" data-id="'+id+'">Reply</button><button class="egpk-chip-btn" data-egpk-action="report-knowledge" data-id="'+id+'">Report</button></div></article>');viewModal().show();}).fail(e=>notify(e.message||'Unable to open post','error'));
        if(action==='like-knowledge') return ajax('POST',url(routes.knowledge.like,id)).done(()=>{notify('Reaction updated.');loadKnowledge();}).fail(e=>notify(e.message||'Reaction failed','error'));
        if(action==='save-knowledge') return ajax('POST',url(routes.knowledge.save,id)).done(()=>notify('Saved to your library.')).fail(e=>notify(e.message||'Save failed','error'));
        if(action==='reply-knowledge') return openForm('Reply','Add a threaded reply',field('body_html','Reply','','textarea',{required:true,col:12,rows:6}),f=>submitForm(url(routes.knowledge.reply,id),'POST',f,()=>notify('Reply added.')));
        if(action==='report-knowledge') return openForm('Report Post','Report content for moderation',field('reason','Reason','','textarea',{required:true,col:12,rows:4}),f=>submitForm(url(routes.knowledge.report,id),'POST',f));
        if(action==='new-portal') return openForm('Add Portal / App','Register an internal application or portal',portalForm(),f=>submitForm(routes.portals.store,'POST',f));
        if(action==='edit-portal') return ajax('GET',url(routes.portals.show,id)).done(res=>{const d=res.data?.app||res.data;openForm('Edit Portal / App','Update registry details',portalForm(d),f=>submitForm(url(routes.portals.update,id),'PUT',f));}).fail(e=>notify(e.message||'Unable to load app','error'));
        if(action==='view-portal') return ajax('GET',url(routes.portals.show,id)).done(res=>{const d=res.data||{};$('#egpkViewTitle').text(d.app?.app_name||'Portal / App');$('#egpkViewSubtitle').text(d.app?.purpose||'');$('#egpkViewBody').html('<div class="egpk-detail-grid">'+[['Name',d.app?.app_name],['URL',d.app?.app_url],['Platform',d.app?.platform],['Environment',d.app?.environment],['Status',d.app?.status],['Current Version',d.app?.current_version]].map(a=>'<div class="egpk-detail"><label>'+esc(a[0])+'</label><strong>'+esc(a[1]||'-')+'</strong></div>').join('')+'</div><div class="mt-3 egpk-card"><div class="egpk-card-head"><div class="egpk-card-title">Version History</div></div><div class="egpk-card-body">'+tableSimple(d.versions||[],['version_no','update_date','updated_by','update_details','bug_fix_details'])+'</div></div>');viewModal().show();});
        if(action==='portal-version') return openForm('Record Version Update','Version history is retained chronologically.',section('Version',field('version_no','Version','','text',{required:true,col:4})+field('update_date','Update Date','','date',{required:true,col:4})+field('update_details','Update Details','','textarea',{col:12,rows:4})+field('bug_fix_details','Bug Fixes','','textarea',{col:12,rows:4})),f=>submitForm(url(routes.portals.version,id),'POST',f));
        if(action==='launch-portal') return ajax('POST',url(routes.portals.launch,id)).done(r=>{if(r.url)window.open(r.url,'_blank','noopener');else if(r.data?.url)window.open(r.data.url,'_blank','noopener');}).fail(e=>notify(e.message||'Launch failed','error'));
        if(action==='new-meeting') return openForm('Schedule Meeting','Create a personal, team or company meeting',meetingForm(),f=>submitForm(routes.meetings.store,'POST',f));
        if(action==='view-meeting') return ajax('GET',url(routes.meetings.show,id)).done(res=>{const d=res.data||{};$('#egpkViewTitle').text(d.meeting?.title||'Meeting');$('#egpkViewSubtitle').text(d.meeting?.start_at||'');$('#egpkViewBody').html('<div class="egpk-detail-grid">'+[['Start',d.meeting?.start_at],['End',d.meeting?.end_at],['Venue',d.meeting?.venue],['Online',d.meeting?.meeting_url],['Status',d.meeting?.status],['Agenda',d.meeting?.agenda]].map(a=>'<div class="egpk-detail"><label>'+esc(a[0])+'</label><strong>'+esc(a[1]||'-')+'</strong></div>').join('')+'</div><div class="mt-3"><div class="egpk-section-title">Participants</div>'+tableSimple(d.participants||[],['user_id','rsvp','display_name','email'])+'</div><div class="mt-3"><div class="egpk-section-title">Reschedule History</div>'+tableSimple(d.reschedules||[],['old_start_at','new_start_at','reason','changed_by'])+'</div>');viewModal().show();}).fail(e=>notify(e.message||'Unable to open meeting','error'));
        if(action==='edit-meeting') return ajax('GET',url(routes.meetings.show,id)).done(res=>{const d=res.data?.meeting||res.data;openForm('Edit Meeting','Update meeting details',meetingForm(d),f=>submitForm(url(routes.meetings.update,id),'PUT',f));});
        if(action==='reschedule-meeting') return openForm('Reschedule Meeting','A reschedule record will be retained.',section('New Time',field('start_at','Start','','datetime-local',{required:true,col:6})+field('end_at','End','','datetime-local',{required:true,col:6})+field('reason','Reason','','textarea',{col:12,rows:4})),f=>submitForm(url(routes.meetings.reschedule,id),'POST',f));
        if(action==='new-task') return openForm('Create Task','Assign later if needed',taskForm(),f=>submitForm(routes.tasks.store,'POST',f));
        if(action==='view-task') return ajax('GET',url(routes.tasks.show,id)).done(res=>{const d=res.data||{};$('#egpkViewTitle').text(d.task?.title||'Task');$('#egpkViewSubtitle').text(d.task?.status||'');$('#egpkViewBody').html('<div class="egpk-detail-grid">'+[['Priority',d.task?.priority],['Status',d.task?.status],['Due',d.task?.due_at],['Supervisor',d.task?.supervisor_user_id],['Verification',d.task?.verification_required?'Required':'No'],['Description',d.task?.description]].map(a=>'<div class="egpk-detail"><label>'+esc(a[0])+'</label><strong>'+esc(a[1]||'-')+'</strong></div>').join('')+'</div><div class="mt-3"><div class="egpk-section-title">Comments</div>'+tableSimple(d.comments||[],['user_id','comment_text','created_at'])+'</div>');viewModal().show();}).fail(e=>notify(e.message||'Unable to open task','error'));
        if(action==='edit-task') return ajax('GET',url(routes.tasks.show,id)).done(res=>{openForm('Edit Task','Update task details',taskForm(res.data?.task||res.data),f=>submitForm(url(routes.tasks.update,id),'PUT',f));});
        if(action==='new-note') return openForm('Take a Note','Capture a personal or shared note',noteForm(),f=>submitForm(routes.notes.store,'POST',f));
        if(action==='edit-note') return ajax('GET',url(routes.notes.show,id)).done(res=>{const d=res.data?.note||res.data;openForm('Edit Note','Update note',noteForm(d),f=>submitForm(url(routes.notes.update,id),'PUT',f));}).fail(e=>notify(e.message||'Unable to load note','error'));
        if(action==='note-pin') return ajax('POST',url(routes.notes.action,id),{action:'pin'}).done(()=>{notify('Pin updated.');loadNotes();}).fail(e=>notify(e.message||'Note action failed','error'));
        if(action==='new-money-account') return openForm('Add Money Account','Personal account / wallet / bank balance',section('Account',field('account_name','Account Name','','text',{required:true,col:6})+field('account_type','Type','Bank','select',{required:true,col:6,options:['Bank','Cash','UPI Wallet','Card','Investment'].map(x=>({value:x,label:x}))})+field('opening_balance','Opening Balance','0','number',{step:'0.01',col:6})),f=>submitForm(routes.money.account,'POST',f));
        if(action==='new-money-budget') return openForm('Monthly Budget','Track spending against a category',section('Budget',field('budget_month', 'Month', new Date().toISOString().slice(0,7)+'-01','date',{required:true,col:4})+field('category','Category','','text',{required:true,col:4})+field('budget_amount','Budget Amount','','number',{required:true,step:'0.01',col:4})),f=>submitForm(routes.money.budget,'POST',f));
        if(action==='new-money-transaction') return openForm('Quick Money Entry','Personal only',section('Transaction',field('account_id','Account ID','','number',{required:true,col:4})+field('transaction_date','Date',new Date().toISOString().slice(0,10),'date',{required:true,col:4})+field('category','Category','','text',{required:true,col:4})+field('amount','Amount','','number',{required:true,step:'0.01',col:4})+field('transaction_type','Type','expense','select',{required:true,col:4,options:[{value:'income',label:'Income'},{value:'expense',label:'Expense'}]})+field('mode','Mode','UPI','select',{col:4,options:['UPI','Cash','Card','Bank'].map(x=>({value:x,label:x}))})+field('note','Note','','textarea',{col:12,rows:3})),f=>submitForm(routes.money.transaction,'POST',f));
        if(action==='new-commitment') return openForm('Recurring Commitment','Track personal commitments',section('Commitment',field('commitment_name','Name','','text',{required:true,col:6})+field('due_date','Due Date','','date',{required:true,col:3})+field('amount','Amount','','number',{required:true,step:'0.01',col:3})+field('recurrence','Recurrence','','text',{col:6})+field('status','Status','pending','select',{col:6,options:['pending','paid','cancelled'].map(x=>({value:x,label:x}))})),f=>submitForm(routes.money.commitment,'POST',f));
        if(action==='new-event') return openForm('Create Event','Add an internal or external event',eventForm(),f=>submitForm(routes.events.store,'POST',f));
        if(action==='view-event') return ajax('GET',url(routes.events.show,id)).done(res=>{const d=res.data||{};$('#egpkViewTitle').text(d.event_name||'Event');$('#egpkViewSubtitle').text(d.event_date||'');$('#egpkViewBody').html('<div class="egpk-detail-grid">'+[['Organiser',d.organisation],['Type',d.event_type],['Date',d.event_date],['Time',d.event_time],['Venue',d.venue],['Status',d.status]].map(a=>'<div class="egpk-detail"><label>'+esc(a[0])+'</label><strong>'+esc(a[1]||'-')+'</strong></div>').join('')+'</div><div class="mt-3">'+esc(d.description||'')+'</div>');viewModal().show();});
        if(action==='edit-event') return ajax('GET',url(routes.events.show,id)).done(res=>openForm('Edit Event','Update event',eventForm(res.data),f=>submitForm(url(routes.events.update,id),'PUT',f)));
        if(action==='upload-document') return documentUpload();
        if(action==='open-document') return ajax('GET',url(routes.documents.url,id)).done(r=>window.open(r.data?.url||r.url,'_blank','noopener')).fail(e=>notify(e.message||'Unable to open document','error'));
        if(action==='pin-document') return ajax('POST',url(routes.documents.pin,id)).done(()=>{notify('Pin updated.');loadDocuments();});
        if(action==='report-csv') return download('GET',routes.reports.csv,{report:$('#egpkReportType').val(),company_id:state.company==='all'?'':state.company},'report.csv');
        if(action==='report-xlsx') return download('GET',routes.reports.xlsx,{report:$('#egpkReportType').val(),company_id:state.company==='all'?'':state.company},'report.xlsx');
        if(action==='export-portals') return download('GET',routes.portals.exportXlsx,null,'portals.xlsx');
        if(action==='new-admin-category') return openForm('Create Master Category','For ContactBook, PassWallet or Knowledge Panel',section('Master',field('type','Type','contact','select',{required:true,col:4,options:[{value:'contact',label:'ContactBook'},{value:'vault',label:'PassWallet'},{value:'knowledge',label:'Knowledge'}]})+field('name','Category Name','','text',{required:true,col:6})+field('color','Colour','#C0392B','color',{col:2})),f=>submitForm(routes.admin.category,'POST',f));
        if(action==='share') return openShare(type,id);
        if(action==='cal-prev'){state.calendarDate.setMonth(state.calendarDate.getMonth()-1);return loadModule();}
        if(action==='cal-next'){state.calendarDate.setMonth(state.calendarDate.getMonth()+1);return loadModule();}
        if(action==='cal-today'){state.calendarDate=new Date();return loadModule();}
    }

    function confirmAction(title,body,button,fn){
        $('#egpkConfirmTitle').text(title);
        $('#egpkConfirmBody').text(body);
        $('#egpkConfirmYes').text(button||'Confirm').off('click.egpk').on('click.egpk',function(){
            const b=$(this);
            b.prop('disabled',true);
            let result;
            try { result=fn&&fn(); } catch(e) { notify(e.message||'Action failed.','error'); }
            const finish=function(){b.prop('disabled',false);confirmModal().hide();};
            if(result && typeof result.always==='function') result.always(finish);
            else if(result && typeof result.finally==='function') result.finally(finish);
            else finish();
        });
        confirmModal().show();
    }
    function requestStepUp(next){ state.pending=next; $('#egpkStepupPassword').val('');stepupModal().show(); }

    function openShare(type,id){state.currentType=type;state.currentId=id;$('#egpkShareType').val(type);$('#egpkShareId').val(id);$('#egpkShareGranteeType').val('user').trigger('change');$('#egpkSharePermission').val('View');ajax('GET',routes.users+'?limit=100').done(function(res){const users=Array.isArray(res.data)?res.data:[];$('#egpkShareGranteeId').html(users.map(u=>'<option value="'+esc(u.user_id||u.sno)+'">'+esc(u.staff_name||u.name||u.email||u.user_id)+'</option>').join(''));});loadShares(type,id);shareModal().show();}
    function loadShares(type,id){ajax('GET',routes.shares.data+'?'+query({resource_type:type,resource_id:id})).done(function(res){const rows=Array.isArray(res.data)?res.data:[];$('#egpkShareList').html(rows.length?rows.map(x=>'<div class="d-flex justify-content-between align-items-center border-bottom py-2"><div><div class="small fw-bold">'+esc(x.grantee_type)+' · '+esc(x.grantee_id)+'</div><div class="text-muted" style="font-size:8px">'+esc(x.permission)+' · '+esc(x.status)+' · '+esc(x.expires_at||'No expiry')+'</div></div><button class="btn btn-light btn-sm text-danger" data-egpk-action="revoke-share" data-id="'+x.sno+'">Revoke</button></div>').join(''):empty('mdi-share-off-outline','No active shares'));}).fail(e=>$('#egpkShareList').html(errorBox(e.message||'Unable to load shares.')));}

    function refreshModalActionButtons(){/* intentionally centralized for future permission UI */}

    $('#egpkPrimaryAction').on('click.egpk', function(){ const map={contacts:'new-contact',bookmarks:'new-board',passwallet:'new-vault',knowledge:'new-knowledge',portals:'new-portal',meetings:'new-meeting',tasks:'new-task',notes:'new-note',money:'new-money-transaction',events:'new-event',documents:'upload-document',admin:'new-admin-category'};dispatchAction(map[moduleName]); });
    $('#egpkRefresh').on('click.egpk', function(){state.page=1;loadModule();});
    $('#egpkSearch').on('input.egpk', $.debounce ? $.debounce(function(){state.search=this.value.trim();state.page=1;loadModule();},350) : function(){clearTimeout(window.__egpkSearchTimer);const v=this.value;window.__egpkSearchTimer=setTimeout(()=>{state.search=v.trim();state.page=1;loadModule();},350);});
    $('#egpkSearchClear').on('click.egpk',function(){$('#egpkSearch').val('');state.search='';state.page=1;loadModule();});
    $('#egpkCompany').on('change.egpk',function(){state.company=this.value;state.page=1;loadModule();});
    $('#egpkViewSwitcher').on('click.egpk','[data-egpk-view]',function(){state.view=$(this).data('egpk-view');state.page=1;loadModule();});
    $('#egpkWorkspace').on('change.egpk','#egpkContactFilter,#egpkBookmarkHealth,#egpkVaultType,#egpkKnowledgeSort,#egpkPortalStatus,#egpkMeetingScope,#egpkTaskPriority,#egpkNoteScope,#egpkEventStatus,#egpkDocumentScope,#egpkReportType',function(){state.page=1;loadModule();});
    $('#egpkToolLauncher').on('click.egpk',()=>$('#egpkToolLauncherPanel').toggleClass('d-none'));
    $('#egpkToolLauncherClose').on('click.egpk',()=>$('#egpkToolLauncherPanel').addClass('d-none'));
    $('#egpkNotificationBtn').on('click.egpk',()=>$('#egpkNotificationPanel').toggleClass('d-none'));
    $('#egpkNotificationsRead').on('click.egpk',()=>ajax('POST',routes.notificationsRead).done(()=>{notify('Notifications marked as read.');loadNotifications();}));
    $('#egpkGlobalSearchBtn').on('click.egpk',()=>$('#egpkGlobalSearchPanel').toggleClass('d-none'));
    $('#egpkGlobalSearchClose').on('click.egpk',()=>$('#egpkGlobalSearchPanel').addClass('d-none'));
    $('#egpkGlobalSearchInput').on('input.egpk',function(){globalSearch(this.value.trim());});
    $('#egpkFormModal').on('shown.bs.modal',function(){const el=document.querySelector('#egpkFormModal input[type="datetime-local"]');if(el)el.focus();});
    $('#egpkStepupConfirm').on('click.egpk',function(){const pass=$('#egpkStepupPassword').val();if(!pass){notify('Password is required.','error');return;}const b=$(this);b.prop('disabled',true);ajax('POST',routes.passwallet.stepup,{password:pass}).done(()=>{stepupModal().hide();if(typeof state.pending==='function')state.pending();state.pending=null;}).fail(e=>notify(e.message||'Verification failed.','error')).always(()=>b.prop('disabled',false));});
    $('#egpkShareSave').on('click.egpk',function(){const d={resource_type:$('#egpkShareType').val(),resource_id:$('#egpkShareId').val(),grantee_type:$('#egpkShareGranteeType').val(),grantee_id:$('#egpkShareGranteeId').val(),permission:$('#egpkSharePermission').val(),expires_at:$('#egpkShareExpiry').val()};ajax('POST',routes.shares.store,d).done(r=>{notify(r.message||'Share created.');loadShares(d.resource_type,d.resource_id);}).fail(e=>notify(e.message||'Share failed.','error'));});
    $('#egpkShareModal').on('change','[id="egpkShareGranteeType"]',function(){const t=this.value;if(t==='group'){ $('#egpkShareGranteeId').html('<option value="0">Whole Group</option>');return;}if(t==='company'){ ajax('GET',routes.companies).done(res=>$('#egpkShareGranteeId').html((res.data||[]).map(c=>'<option value="'+esc(c.sno)+'">'+esc(c.company_name)+'</option>').join('')));return;}if(t==='role'){ $('#egpkShareGranteeId').html(['Super Admin','Group Admin','Company Admin','Module Manager','Staff','Auditor'].map(r=>'<option>'+esc(r)+'</option>').join(''));return;}ajax('GET',routes.users+'?limit=100').done(res=>$('#egpkShareGranteeId').html((Array.isArray(res.data)?res.data:[]).map(u=>'<option value="'+esc(u.user_id||u.sno)+'">'+esc(u.staff_name||u.name||u.user_id)+'</option>').join('')));});
    $('#egpkWorkspace').on('click.egpk','[data-egpk-action="revoke-share"]',function(){const id=$(this).data('id');ajax('POST',url(routes.shares.revoke,id)).done(()=>{notify('Share revoked.');loadShares(state.currentType,state.currentId);}).fail(e=>notify(e.message||'Unable to revoke share','error'));});

    bindDelegates();renderTools();loadCompanies().always(function(){loadNotifications();loadModule();});
})(jQuery, window, document);

</script>
@endsection
