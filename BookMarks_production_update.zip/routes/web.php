<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\laravel_example\UserManagement;
use App\Http\Controllers\dashboard\Analytics;
use App\Http\Controllers\dashboard\Crm;

use App\Http\Controllers\authentications\Login;
use App\Http\Controllers\authentications\NetworkHandle;
use App\Models\ManageEntityModel;
use App\Models\AiModel;
use Illuminate\Support\Facades\DB;
// use App\Http\Controllers\hr_management\hr_recruiter\ApplicantAIController;

use App\Http\Controllers\hr_management\hr_recruiter\AI\BulkApplicantAIController;
use App\Http\Controllers\hr_management\hr_recruiter\AI\ApplicantAIController;
use App\Http\Controllers\hr_management\hr_recruiter\AI\RecruitmentRoleAIProfileController;




use App\Http\Controllers\accounts_finance\FinanaceController;
use App\Http\Controllers\accounts_finance\LoanScheduleController;

use App\Http\Controllers\control_panel\cug_management\CallerPilotMoniter;
use App\Http\Controllers\control_panel\cug_management\CugManagementController;

use App\Http\Controllers\errors\ErrorController;
use App\Http\Controllers\myself\PasscodeController;
//Settings 
use App\Http\Controllers\settings\GeneralSettings;
use App\Http\Controllers\settings\common\SmsTemplate;
use App\Http\Controllers\settings\common\EmailTemplate;
use App\Http\Controllers\settings\common\WhatsappTemplate;
use App\Http\Controllers\settings\common\FinancialYear;
use App\Http\Controllers\settings\common\CurrencyFormat;
use App\Http\Controllers\settings\common\Country;
use App\Http\Controllers\settings\common\State;
use App\Http\Controllers\settings\common\City;
use App\Http\Controllers\settings\common\TimeZone;
use App\Http\Controllers\settings\common\Internal_cugs;
use App\Http\Controllers\settings\entity\CredentialBook;
use App\Http\Controllers\settings\entity\SocialMedia;
use App\Http\Controllers\settings\entity\WebHookUrl;
use App\Http\Controllers\settings\entity\Grade;
use App\Http\Controllers\settings\entity\Level;
use App\Http\Controllers\settings\entity\AIWebsites;

use App\Http\Controllers\settings\payroll\NewPayrollComponent;
use App\Http\Controllers\settings\payroll\SalaryTemplate;

use App\Http\Controllers\hr_management\hr_sib\ManageAppraisal;
use App\Http\Controllers\hr_management\hr_sib\ManageAdvance;


use App\Http\Controllers\support_management\ManageTrainingDocument;
use App\Http\Controllers\support_management\TrainingDocument;

use App\Http\Controllers\Security\SecurityController;
use App\Http\Controllers\accounts_finance\Expenditure;
use App\Http\Controllers\accounts_finance\ExpenseController;
use App\Http\Controllers\accounts_finance\RecurringController;
use App\Http\Controllers\accounts_finance\CreditCardController;
use App\Http\Controllers\settings\training_settings\TrainingCategory;
use App\Http\Controllers\settings\training_settings\TrainingSubCategory;

use App\Http\Controllers\TableManagerController;
//Exam Settings
use App\Http\Controllers\settings\assessment\ExamBadge;
use App\Http\Controllers\settings\assessment\ExamCategory;
use App\Http\Controllers\settings\assessment\ExamSection;
use App\Http\Controllers\settings\assessment\ExamGuideLines;
use App\Http\Controllers\settings\assessment\JobRoleSchedule;

use App\Http\Controllers\AiUsageController;
use App\Http\Controllers\VideoSubmissionController;
use App\Http\Controllers\Admin\WebhookAdminController;

// HRM SETTINGS
use App\Http\Controllers\settings\hrm\ShiftTime;
use App\Http\Controllers\settings\hrm\LeaveReason;
use App\Http\Controllers\settings\hrm\PermissionReason;
use App\Http\Controllers\settings\hrm\OndutyReason;
use App\Http\Controllers\settings\hrm\ExitReason;
use App\Http\Controllers\settings\hrm\Documents;
use App\Http\Controllers\settings\hrm\DocumentChecklist;
use App\Http\Controllers\settings\hrm\Metrics;
use App\Http\Controllers\settings\hrm\OnBoardingStaging;
use App\Http\Controllers\settings\hrm\OnBoardingCheckList;
use App\Http\Controllers\settings\hrm\HRQuestionnaire;
use App\Http\Controllers\settings\hrm\OnboardingQuestion;
use App\Http\Controllers\Admin\ApiConfig;

//payroll Settings 
use App\Http\Controllers\settings\payroll\Rules;
use App\Http\Controllers\settings\payroll\RuleCategory;
use App\Http\Controllers\settings\payroll\PayrollSetting;
use App\Http\Controllers\settings\payroll\PayrollComponent;
use App\Http\Controllers\settings\payroll\PayrollComponentNew;
use App\Http\Controllers\settings\payroll\PayslipTemplate;
// Interview Setting
use App\Http\Controllers\settings\interview\InterviewMode;
use App\Http\Controllers\settings\interview\InterviewCategory;
use App\Http\Controllers\settings\interview\InterviewQuestion;

use App\Http\Controllers\settings\interview\FeedbackSection;
use App\Http\Controllers\settings\interview\FeedbackQuestion;
use App\Http\Controllers\settings\interview\InterviewFormQuestion;

// RECRUITMENT SETTINGS
use App\Http\Controllers\settings\recruitment\ApplicantStatus;
use App\Http\Controllers\settings\recruitment\Qualification;
use App\Http\Controllers\settings\recruitment\QualificationLevel;
use App\Http\Controllers\settings\recruitment\Major;
use App\Http\Controllers\settings\recruitment\Experience;
use App\Http\Controllers\settings\recruitment\Source;
use App\Http\Controllers\settings\recruitment\CallStatus;
use App\Http\Controllers\settings\recruitment\MaritalStatus;

// Corporate Admin
// Schedule Management
use App\Http\Controllers\corporate_admin\schedule_management\ManageHospitality;
use App\Http\Controllers\corporate_admin\schedule_management\ManageVisitor;
use App\Http\Controllers\corporate_admin\schedule_management\ConferenceSupport;
use App\Http\Controllers\corporate_admin\schedule_management\PantryRefreshment;
use App\Http\Controllers\corporate_admin\schedule_management\ManageEvent;
use App\Http\Controllers\corporate_admin\schedule_management\WorkSchedule;
 
// Stock Management
use App\Http\Controllers\corporate_admin\stock_management\MaterialRequest;
use App\Http\Controllers\corporate_admin\stock_management\ManageItems;
use App\Http\Controllers\corporate_admin\stock_management\ManageStock;
use App\Http\Controllers\corporate_admin\stock_management\StockValidation;
use App\Http\Controllers\corporate_admin\vendor_management\PriceBook;
// Vendor Management
use App\Http\Controllers\corporate_admin\vendor_management\ManageVendor;
 
// Purchase Management
use App\Http\Controllers\corporate_admin\purchase_management\PurchaseApproval;
use App\Http\Controllers\corporate_admin\purchase_management\ManagePurchase;
// Procurement Request
use App\Http\Controllers\corporate_admin\admin_expenditure\ProcurementRequest;
use App\Http\Controllers\corporate_admin\admin_expenditure\ExpenditureCalendar;
use App\Http\Controllers\corporate_admin\vehicle_management\VehicleMachinery;
use App\Http\Controllers\corporate_admin\admin_expenditure\TravelDesk;
// Manage & Maintanence
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageLocation;
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageBuilding;
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageElectricity;
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageTelecom;
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageInternet;
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageRentSchedule;  
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageRenewals;                  
use App\Http\Controllers\corporate_admin\manage_maintanence\EMISchedule;      
use App\Http\Controllers\corporate_admin\manage_maintanence\LeaseRegister;
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageLessor;
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageLedger;
use App\Http\Controllers\corporate_admin\manage_maintanence\ManageDocuments;
 
//Policies And YERD
use App\Http\Controllers\corporate_admin\Policies_and_yerd\ManageInsuranceAMC;
use App\Http\Controllers\corporate_admin\Policies_and_yerd\ExecutiveDashboard;
use App\Http\Controllers\corporate_admin\Policies_and_yerd\SubscriptionAndOthers;
use App\Http\Controllers\corporate_admin\Policies_and_yerd\RenewalCalendar;
use App\Http\Controllers\corporate_admin\Policies_and_yerd\ManageYerd;

// Main menu 
// Control Panel
use App\Http\Controllers\control_panel\entity_hub\ManageCompany;
use App\Http\Controllers\control_panel\entity_hub\ManageEntity;
use App\Http\Controllers\control_panel\entity_hub\ManageBranch;
use App\Http\Controllers\control_panel\entity_hub\ManageHoliday;
use App\Http\Controllers\control_panel\entity_hub\ManageTargets;
use App\Http\Controllers\business_strategy\SalesMetrics;
use App\Http\Controllers\business_strategy\StaffIncentives;
use App\Http\Controllers\business_strategy\StaffTenX;

use App\Http\Controllers\control_panel\user_management\ManageUsers;
use App\Http\Controllers\control_panel\user_management\UserRolePermission;
use App\Http\Controllers\control_panel\user_management\UserRole;
use App\Http\Controllers\control_panel\user_management\UserChart;
use App\Http\Controllers\control_panel\user_management\UserTimestamp;
use App\Http\Controllers\control_panel\communication_tool\NewsBroadcast;
use App\Http\Controllers\control_panel\monitor_tool\WhatsappTemplateLog;
use App\Http\Controllers\EmployeeApp\EmployeeAppController;
use App\Http\Controllers\settings\common\BroadcastTheme;

// HR Management
use App\Http\Controllers\hr_management\hr_enroll\ManageStaff;
use App\Http\Controllers\hr_management\hr_enroll\OnboardingStaff;
use App\Http\Controllers\hr_management\hr_enroll\ManageAttendance;

use App\Http\Controllers\hr_management\hr_general\PayrollSalaryTemplate;

use App\Http\Controllers\hr_management\hr_general\ManagePayroll;
use App\Http\Controllers\hr_management\hr_general\PayrollHistoryController;
use App\Http\Controllers\hr_management\hr_general\SalaryStructure;
use App\Http\Controllers\hr_management\hr_general\SalaryStructureMenu;

// HR Operation
use App\Http\Controllers\hr_management\hr_operation\HROperation;

// It Support
use App\Http\Controllers\it_management\it_supports\ItSupports;

use App\Http\Controllers\hr_management\hr_recruiter\JobController;
use App\Http\Controllers\hr_management\hr_recruiter\ZoomController;
use App\Http\Controllers\hr_management\hr_recruiter\JobRequest;
use App\Http\Controllers\hr_management\hr_recruiter\InterviewStaging;
use App\Http\Controllers\hr_management\hr_recruiter\ManageCandidate;

use App\Http\Controllers\hr_management\hr_recruiter\JobFairController;
use App\Http\Controllers\hr_management\hr_recruiter\walkinCandidate;

//Exam Management
use App\Http\Controllers\hr_management\exam_management\ManageExam;
use App\Http\Controllers\hr_management\exam_management\ManageQuestionBank;
use App\Http\Controllers\hr_management\exam_management\ManageAssessment;
use App\Http\Controllers\hr_management\exam_management\ManageResult;
use App\Http\Controllers\hr_management\exam_management\QuestionBankType;

use App\Http\Controllers\hr_management\hr_training\ManageTraining;
use App\Http\Controllers\hr_management\hr_training\TrainingPlanner;

//Management SETTINGS
use App\Http\Controllers\settings\management\Department;
use App\Http\Controllers\settings\management\Division;
use App\Http\Controllers\settings\management\JobRole;

//Business SETTINGS
use App\Http\Controllers\settings\business\BusinessDepartment;
use App\Http\Controllers\settings\business\BusinessDivision;
use App\Http\Controllers\settings\business\BusinessJobRole;




// Login 
// Route::get('/', [Login::class, 'index'])->name('login');


Route::post('/switch-erp', [Login::class, 'switchToErp'])->name('switch.erp.portal');

$entities = ManageEntityModel::where('status', 0)->get();

foreach ($entities as $entity) {
  Route::get("/sso-login/erp{$entity->sno}", [Login::class, 'verify'])
    ->name("erp{$entity->sno}.sso.login");
}


// logout
Route::post('/logout', [Login::class, 'destroy'])->name('logout');
// login form
Route::get('/', [Login::class, 'index'])->name('login');
Route::post('/login', [Login::class, 'Login'])->name('login_auth');
Route::get('/get_staff', [Login::class, 'get_staff'])->name('get-staff');
Route::get('/forgot_password', [Login::class, 'forgot_password'])->name('forgot-password');
Route::get('/change_password', [Login::class, 'new_password'])->name('new-password');



// Settings Menu

Route::middleware(['auth:web', 'timezone'])->group(function () {

  Route::get('/download-login-report', [Login::class, 'downloadLoginReport']);
  //updateProfile 
  Route::post('/update-profile', [Login::class, 'updateProfile'])->name('update_profile');




  Route::post('/portal/switch', function () {
    $current = session('portalState', 'off');
    session(['portalState' => $current === 'on' ? 'off' : 'on']);

    // Always redirect to dashboard
    return redirect('/dashboard');
  })->name('portal.switch');


  // General Setting Start
  Route::get('/settings/general_settings', [GeneralSettings::class, 'index'])->name('settings-general-settings');
  Route::post('/general_settings-update', [GeneralSettings::class, 'Update'])->name('general_settings_update');
  // General Setting End


  // CurrencyFormat Setting Start
  Route::get('/settings/currency_format', [CurrencyFormat::class, 'index'])->name('settings-common');
  Route::get('/currency_format', [CurrencyFormat::class, 'List'])->name('currency_format');
  Route::post('/add_currency_format', [CurrencyFormat::class, 'Add'])->name('add_currency_format');
  Route::get('/currency_format_edit/{id}', [CurrencyFormat::class, 'Edit'])->name('currency_format_edit');
  Route::post('/currency_format_update', [CurrencyFormat::class, 'Update'])->name('currency_format_update');
  Route::delete('/currency_format_delete/{id}', [CurrencyFormat::class, 'Delete']);
  Route::post('/currency_format_status/{id}', [CurrencyFormat::class, 'Status']);
  // CurrencyFormat Setting End

  // Country Setting Start
  Route::get('/settings/country', [Country::class, 'index'])->name('settings-common');
  Route::post('/add_country', [Country::class, 'Add'])->name('add_country');
  Route::get('/country_edit', [Country::class, 'Edit'])->name('country_edit');
  Route::post('/country_update', [Country::class, 'Update'])->name('country_update');
  Route::delete('/country_delete/{id}', [Country::class, 'Delete'])->name('country_delete');
  Route::post('/country_status_change/{id}', [Country::class, 'Status'])->name('country_status_change');
  Route::get('/country', [Country::class, 'List'])->name('country');
  Route::get('/country_ed_list', [Country::class, 'List_for_edit'])->name('country_ed_list');
  // Country Setting End


  // db Setting  manager
  Route::get('/db_table', [TableManagerController::class, 'index']);
  Route::get('/tables', [TableManagerController::class, 'getTables'])->name('table.manager.tables');
  Route::post('/data', [TableManagerController::class, 'getTableData'])->name('table.manager.data');
  Route::post('/update-cell', [TableManagerController::class, 'updateCell'])->name('table.manager.update.cell');
  Route::post('/update-row', [TableManagerController::class, 'updateRow'])->name('table.manager.update.row');
  Route::delete('/delete', [TableManagerController::class, 'deleteRecord'])->name('table.manager.delete');
  Route::post('/add_db', [TableManagerController::class, 'addRecord'])->name('table.manager.add');
  Route::post('/search', [TableManagerController::class, 'searchTable'])->name('table.manager.search');

  

  // State Setting Start
  Route::get('/settings/state', [State::class, 'index'])->name('settings-common');
  Route::post('/add_state', [State::class, 'Add'])->name('add_state');
  Route::get('/state_edit', [State::class, 'Edit'])->name('state_edit');
  Route::post('/state_update', [State::class, 'Update'])->name('state_update');
  Route::delete('/state_delete/{id}', [State::class, 'Delete'])->name('state_delete');
  Route::delete('/batch_delete_permanently/{id}', [State::class, 'DeleteBatchPermanently'])->name('batch_delete_permanently');
  Route::post('/state_status_change/{id}', [State::class, 'Status'])->name('state_status_change');
  Route::get('/state', [State::class, 'List'])->name('state');
  Route::get('/state_ed_list', [State::class, 'List_for_edit'])->name('state_ed_list');
  // State Setting End

  // City Setting Start
  Route::get('/settings/city', [City::class, 'index'])->name('settings-common');
  Route::post('/add_city', [City::class, 'Add'])->name('add_city');
  Route::get('/city_edit', [City::class, 'Edit'])->name('city_edit');
  Route::post('/city_update', [City::class, 'Update'])->name('city_update');
  Route::delete('/city_delete/{id}', [City::class, 'Delete'])->name('city_delete');
  Route::post('/city_status_change/{id}', [City::class, 'Status'])->name('city_status_change');
  Route::get('/city', [City::class, 'List'])->name('city');
  Route::get('/city_ed_list', [City::class, 'List_for_edit'])->name('city_ed_list');
  // City Setting End

  // TimeZone Setting Start
  Route::get('/settings/timezone', [TimeZone::class, 'index'])->name('settings-common');
  Route::get('/time_zone', [TimeZone::class, 'List'])->name('time_zone');
  Route::post('/add_time_zone', [TimeZone::class, 'Add'])->name('add_time_zone');
  Route::get('/time_zone_edit', [TimeZone::class, 'Edit'])->name('time_zone_edit');
  Route::post('/time_zone_update', [TimeZone::class, 'Update'])->name('time_zone_update');
  Route::delete('/time_zone_delete/{id}', [TimeZone::class, 'Delete'])->name('time_zone_delete');
  Route::post('/time_zone_status_change/{id}', [TimeZone::class, 'Status'])->name('time_zone_status_change');
  // TimeZone Setting End

  // Internal_cugs Setting Start
  Route::get('/settings/internal_cugs', [Internal_cugs::class, 'index'])->name('settings-common');
  Route::post('/Internal_cugs_add', [Internal_cugs::class, 'Add'])->name('Internal_cugs_add');
  Route::post('/Internal_cugs_update', [Internal_cugs::class, 'Update'])->name('Internal_cugs_update');
  Route::delete('/Internal_cugs_delete/{id}', [Internal_cugs::class, 'Delete']);
  // Internal_cugs Setting End

  // CredentialBook Setting Start
  Route::get('/settings/credential_book', [CredentialBook::class, 'index'])->name('settings-entity');
  Route::get('/credential', [CredentialBook::class, 'List'])->name('credential');
  Route::post('/add_credential', [CredentialBook::class, 'Add'])->name('add_credential');
  Route::get('/credential_edit/{id}', [CredentialBook::class, 'Edit']);
  Route::post('/credential_update/{id}', [CredentialBook::class, 'Update']);
  Route::delete('/credential_delete/{id}', [CredentialBook::class, 'Delete']);
  Route::post('/credential_status/{id}', [CredentialBook::class, 'Status']);
  // CredentialBook Setting End


  // SocialMedia Setting Start
  Route::get('/settings/social_media', [SocialMedia::class, 'index'])->name('settings-entity');
  Route::get('/social_media', [SocialMedia::class, 'List'])->name('social_media');
  Route::post('/add_social_media', [SocialMedia::class, 'Add'])->name('add_social_media');
  Route::get('/social_media_edit/{id}', [SocialMedia::class, 'Edit']);
  Route::post('/social_media_update/{id}', [SocialMedia::class, 'Update']);
  Route::delete('/social_media_delete/{id}', [SocialMedia::class, 'Delete']);
  Route::post('/social_media_status/{id}', [SocialMedia::class, 'Status']);
  // SocialMedia Setting End

  // SocialMedia Setting Start
  Route::get('/settings/ai_websites', [AIWebsites::class, 'index'])->name('settings-entity');
  Route::get('/ai_websites', [AIWebsites::class, 'List'])->name('ai_websites');
  Route::post('/add_ai_websites', [AIWebsites::class, 'Add'])->name('add_ai_websites');
  Route::get('/ai_websites_edit/{id}', [AIWebsites::class, 'Edit']);
  Route::post('/ai_websites_update', [AIWebsites::class, 'Update'])->name('ai_websites_update');;
  Route::delete('/ai_websites_delete/{id}', [AIWebsites::class, 'Delete']);
  Route::post('/ai_websites_status/{id}', [AIWebsites::class, 'Status']);
  // SocialMedia Setting End

  // WebHook Url Setting Start
  Route::get('/settings/webhook_url', [WebHookUrl::class, 'index'])->name('settings-entity');
  Route::get('/webhook_url_list', [WebHookUrl::class, 'List'])->name('webhook_url_list');
  Route::post('/update_all_hook_url', [WebHookUrl::class, 'UpdateAll'])->name('update_all_hook_url');
  Route::post('/add_webhook_url', [WebHookUrl::class, 'Add'])->name('add_webhook_url');
  Route::get('/webhook_url_edit/{id}', [WebHookUrl::class, 'Edit']);
  Route::post('/webhook_url_update/{id}', [WebHookUrl::class, 'Update']);
  Route::delete('/webhook_url_delete/{id}', [WebHookUrl::class, 'Delete']);
  Route::post('/webhook_url_status/{id}', [WebHookUrl::class, 'Status']);
  // WebHook Url Setting End

  Route::get('/settings/sms_template', [SmsTemplate::class, 'index'])->name('settings-common');
  Route::post('/add_sms_template', [SmsTemplate::class, 'Add'])->name('add_sms_template');
  Route::get('/sms_template_edit', [SmsTemplate::class, 'Edit'])->name('sms_template_edit');
  Route::post('/sms_template_update', [SmsTemplate::class, 'Update'])->name('sms_template_update');
  Route::delete('/sms_template_delete/{id}', [SmsTemplate::class, 'Delete'])->name('sms_template_delete');
  Route::post('/sms_template_status_change/{id}', [SmsTemplate::class, 'Status'])->name('sms_template_status_change');
  Route::get('/sms/balance', [SmsTemplate::class, 'getBalance']);

  Route::get('/settings/email_template', [EmailTemplate::class, 'index'])->name('settings-common');
  Route::get('/settings/email_template/email_template_add', [EmailTemplate::class, 'EmailAdd'])->name('settings-common');
  Route::post('/email_template_add', [EmailTemplate::class, 'Add'])->name('email_template_add');
  Route::get('/settings/common/email_template/edit/{id}', [EmailTemplate::class, 'Edit'])->name('email_template_edit');
  Route::post('/email_template_update', [EmailTemplate::class, 'Update'])->name('email_template_update');
  Route::delete('/email_template_delete/{id}', [EmailTemplate::class, 'Delete'])->name('email_template_delete');
  Route::post('/email_template_status/{id}', [EmailTemplate::class, 'Status'])->name('email_template_status');


  Route::get('/settings/finiancial_year', [FinancialYear::class, 'index'])->name('settings-common');
  Route::get('/settings/grade', [Grade::class, 'index'])->name('settings-common');
  Route::get('/settings/level', [Level::class, 'index'])->name('settings-common');
  // Route::get('/settings/social_media_profile', [SocialMediaProfile::class, 'index'])->name('settings-common');

  //whatsapp template
  Route::get('/settings/whatsapp_template', [WhatsappTemplate::class, 'index'])->name('settings-common');
  Route::get('/whatsapp_template_list', [WhatsappTemplate::class, 'List'])->name('whatsapp_template_list');
  Route::post('/whatsapp_template_add', [WhatsappTemplate::class, 'Add'])->name('whatsapp_template_add');
  Route::post('/whatsapp_template_update', [WhatsappTemplate::class, 'Update'])->name('whatsapp_template_update');
  Route::delete('/whatsapp_template_delete/{id}', [WhatsappTemplate::class, 'Delete'])->name('whatsapp_template_delete');
  Route::post('/whatsapp_template_status_change/{id}', [WhatsappTemplate::class, 'Status'])->name('whatsapp_template_status_change');
  Route::get('/whatsapp_templates', [WhatsappTemplate::class, 'showTemplates'])->name('whatsapp_templates');

  // whatsapp template Log
  Route::get('/whatsapp_template_log', [WhatsappTemplateLog::class, 'index'])->name('monitor-tool-whatsapp-log');
  Route::get('/whatsapp_template_history_log', [WhatsappTemplateLog::class, 'historyLog'])->name('monitor-tool-whatsapp-log');
  Route::get('/whatsapp_template_log/list', [WhatsappTemplateLog::class, 'List']);
  Route::get('/whatsapp_template_log_by_id', [WhatsappTemplateLog::class, 'MessageListByTemplate'])->name('whatsapp_template_log_by_id');
  Route::get('/whatsapp_template_log/template_list', [WhatsappTemplateLog::class, 'TemplateList']);


  // Payroll Setting
  Route::get('/settings/rule_category', [RuleCategory::class, 'index'])->name('settings-payroll');
  Route::post('/add_rule_category', [RuleCategory::class, 'Add'])->name('add_rule_category');
  Route::get('/payroll_rule_by_id', [RuleCategory::class, 'Edit'])->name('payroll_rule_by_id');
  Route::post('/rule_category_update', [RuleCategory::class, 'Update'])->name('rule_category_update');
  Route::delete('/rule_category_delete/{id}', [RuleCategory::class, 'Delete'])->name('rule_category_delete');
  Route::post('/rule_category_status_change/{id}', [RuleCategory::class, 'Status'])->name('rule_category_status_change');
  Route::get('/rule_category_list', [RuleCategory::class, 'List'])->name('rule_category_list');


  Route::get('/settings/payroll_setting', [PayrollSetting::class, 'index'])->name('settings-payroll');
  Route::post('/add_payroll_setting', [PayrollSetting::class, 'Add'])->name('add_payroll_setting');
  Route::get('/payroll_setting_edit', [PayrollSetting::class, 'Edit'])->name('payroll_setting_edit');
  Route::post('/payroll_setting_update', [PayrollSetting::class, 'Update'])->name('payroll_setting_update');
  Route::delete('/payroll_setting_delete/{id}', [PayrollSetting::class, 'Delete'])->name('payroll_setting_delete');
  Route::post('/payroll_setting_status_change/{id}', [PayrollSetting::class, 'Status'])->name('payroll_setting_status_change');
  Route::get('/payroll_setting_list', [PayrollSetting::class, 'List'])->name('payroll_setting_list');

  Route::get('/settings/payroll/components', [PayrollComponentNew::class, 'index'])->name('settings-payroll');
  Route::post('/add_payroll_component_new', [PayrollComponentNew::class, 'Add'])->name('add_payroll_component_new');
  Route::get('/payroll_component_edit_new', [PayrollComponentNew::class, 'Edit'])->name('payroll_component_edit_new');
  Route::post('/payroll_component_update_new', [PayrollComponentNew::class, 'Update'])->name('payroll_component_update_new');
  Route::delete('/payroll_component_delete_new/{id}', [PayrollComponentNew::class, 'Delete'])->name('payroll_component_delete_new');
  Route::post('/payroll_component_status_change_new/{id}', [PayrollComponentNew::class, 'Status'])->name('payroll_component_status_change_new');
  Route::get('/payroll_component_list_new', [PayrollComponentNew::class, 'List'])->name('payroll_component_list');


  Route::get('/settings/payroll_component', [PayrollComponent::class, 'index'])->name('settings-payroll');
  Route::post('/add_payroll_component', [PayrollComponent::class, 'Add'])->name('add_payroll_component');
  Route::get('/payroll_component_edit', [PayrollComponent::class, 'Edit'])->name('payroll_component_edit');
  Route::post('/payroll_component_update', [PayrollComponent::class, 'Update'])->name('payroll_component_update');
  Route::delete('/payroll_component_delete/{id}', [PayrollComponent::class, 'Delete'])->name('payroll_component_delete');
  Route::post('/payroll_component_status_change/{id}', [PayrollComponent::class, 'Status'])->name('payroll_component_status_change');
  Route::get('/payroll_component_list', [PayrollComponent::class, 'List'])->name('payroll_component_list');

  Route::get('/settings/payslip_templates', [PayslipTemplate::class, 'index'])->name('settings-payroll');
  Route::post('/add_payslip_template', [PayslipTemplate::class, 'Add'])->name('add_payslip_template');
  Route::get('/payslip_template_edit', [PayslipTemplate::class, 'Edit'])->name('payslip_template_edit');
  Route::post('/payslip_template_update', [PayslipTemplate::class, 'Update'])->name('payslip_template_update');
  Route::delete('/payslip_template_delete/{id}', [PayslipTemplate::class, 'Delete'])->name('payslip_template_delete');
  Route::post('/payslip_template_status_change/{id}', [PayslipTemplate::class, 'Status'])->name('payslip_template_status_change');
  Route::get('/payslip_template_list', [PayslipTemplate::class, 'List'])->name('payslip_template_list');


  

  Route::get('/settings/rules', [Rules::class, 'index'])->name('settings-payroll');


  Route::get('/salary-template', [SalaryTemplate::class, 'index']);
  Route::get('/salary-template/list', [SalaryTemplate::class, 'list']);
  Route::post('/salary-template/store', [SalaryTemplate::class, 'store']);
  Route::post('/salary-template/components', [SalaryTemplate::class, 'saveComponents']);
  Route::get('/salary-template/components/{id}', [SalaryTemplate::class, 'getComponents']);



  Route::get('/settings/payroll_salary_component', [NewPayrollComponent::class, 'index']);
  Route::get('/salary-components/list', [NewPayrollComponent::class, 'list']);
  Route::post('/salary-components/store', [NewPayrollComponent::class, 'store']);
  Route::get('/salary-components/view/{id}', [NewPayrollComponent::class, 'view']);

  Route::post('/salary_component_status_change/{id}', [NewPayrollComponent::class, 'Status'])->name('payslip_template_status_change');
  Route::delete('/salary_component_delete/{id}', [NewPayrollComponent::class, 'Delete']);

  Route::get('/salary-components/edit', [NewPayrollComponent::class, 'edit']);
  Route::post('/salary-components/update', [NewPayrollComponent::class, 'update']);



  Route::get('/payroll-settings-new', [NewPayrollComponent::class, 'indexRule']);
  Route::get('/payroll/settings', [NewPayrollComponent::class, 'getRule']);
  Route::post('/payroll/settings/save', [NewPayrollComponent::class, 'saveRule']);
  // Manage Payroll
  Route::get('/payroll/salary-template', [PayrollSalaryTemplate::class, 'index'])->name('hrm-hr-management-enroll-manage-payroll-template');
  Route::post('/payroll/salary-template/save', [PayrollSalaryTemplate::class, 'saveTemplate']);
  Route::get('/payroll/salary-template/edit/{id}', [PayrollSalaryTemplate::class, 'edit']);
  Route::get('/payroll/employee-structure/get/{employeeId}/{salaryAccountId}', [PayrollSalaryTemplate::class, 'GetEmployeeStructure']);
  Route::post('/payroll/employee-structure/save', [PayrollSalaryTemplate::class, 'saveEmployeeStructure']);
  Route::get('/payroll/template/components/{id}', [PayrollSalaryTemplate::class, 'GetTemplateComponents']);
  Route::get('/payroll/monthly-inputs/get/{id}', [PayrollSalaryTemplate::class, 'GetTemplateComponents']);
  Route::post('/payroll/template/calculate-preview', [PayrollSalaryTemplate::class, 'calculateTemplatePreview']);

  Route::get('/payroll/bulk/preview', [PayrollSalaryTemplate::class, 'bulkPreview']);
  Route::post('/payroll/bulk/save', [PayrollSalaryTemplate::class, 'bulkSave']);

  Route::get('/payroll/history/employee/{id}',[PayrollSalaryTemplate::class, 'getHistoryEmployeeSalaryAccounts']);
  Route::post('/payroll/appraisal/save',[PayrollSalaryTemplate::class,'saveSalaryRevision']);
  Route::post('/payroll/appraisal/bulk-save',[PayrollSalaryTemplate::class, 'bulkSaveSalaryHistory']);
  

  Route::get('/payroll/employee-salary-accounts/{employeeId}',[PayrollSalaryTemplate::class,'getEmployeeSalaryAccounts']);

  Route::post('/payroll/variable-amount/save', [PayrollSalaryTemplate::class, 'SaveVariableAmount']);
  Route::get('/payroll/variable-amount/get/{employeeId}', [PayrollSalaryTemplate::class, 'GetVariableAmount']);




Route::post(
    '/payroll/appraisal/history/save',
    [PayrollSalaryTemplate::class, 'saveSalaryHistory']
);

Route::post(
    '/payroll/appraisal/history/process/{employee}',
    [PayrollSalaryTemplate::class, 'processSalaryHistory']
);


Route::prefix('payroll/appraisal/history')->group(function () {

    Route::get(
        '/{employee}',
        [PayrollSalaryTemplate::class, 'getSalaryHistory']
    );

    Route::post(
        '/bulk-save',
        [PayrollSalaryTemplate::class, 'bulkSaveSalaryHistory']
    );

});



Route::get(
    '/payroll/ot/details',
    [PayrollSalaryTemplate::class, 'GetOTDetails']
);

Route::post(
    '/payroll/ot/save',
    [PayrollSalaryTemplate::class, 'SaveOTPayroll']
);


  Route::get('/monthly_staff_payroll_list', [ManagePayroll::class, 'monthlyStaffPayrollList'])->name('monthly_staff_payroll_list');

  Route::get('/hr_general/payroll_reports', [ManagePayroll::class, 'index'])->name('hrm-hr-management-enroll-manage-payroll-reports');
  Route::get('/hr_general/payroll', [ManagePayroll::class, 'indexNew'])->name('hrm-hr-management-enroll-manage-payroll');
  Route::post('/payroll/run/create', [ManagePayroll::class, 'create']);
  Route::post('/payroll/run/process/{runSno}', [ManagePayroll::class, 'process']);


  Route::get('/hr_general/salary_balance_sheet',[ManagePayroll::class, 'SalaryBalanceSheetIndex'])->name('hrm-hr-management-enroll-manage-salary-balance-sheet');
  Route::get('/salary_balance_sheet/company-summary',[ManagePayroll::class,'CompanySalaryBalance']);
  Route::get('/salary_balance_sheet/entity-summary',[ManagePayroll::class,'EnitySalaryBalance']);

  Route::get('/hr_general/payroll/month-list',[ManagePayroll::class, 'payrollMonthList'])->name('payroll.month.list');
  Route::get('/hr_general/payroll/month-dahsboard',[ManagePayroll::class, 'GetDashboardMonthSummary'])->name('payroll.month.dashboard');
  Route::post('/payroll/company-summary',[ManagePayroll::class,'companySummary']);

  Route::get('/payroll/get-bank-details',[ManagePayroll::class, 'getPayrollBankDetails']);
  Route::get('/get_month_exit_staff',[ManagePayroll::class, 'getMonthExitStaff']);

  Route::post('/payroll/save-cheque-details',[ManagePayroll::class, 'savePayrollChequeDetails']);

  Route::get('/staff_list_by_entity', [ManagePayroll::class,'staffListByEntity'])->name('staff_list_by_entity');
  Route::get('/payroll/ctc-calculator/{staff}', [ManagePayroll::class, 'getCTCStructure']);
  Route::post('/payroll/ctc-calculator/calculate', [ManagePayroll::class, 'calculateCTC']);


    Route::match(['get', 'post'], '/support/training_document', [TrainingDocument::class, 'index'])->name('support-manage-training-self');
    Route::match(['get', 'post'], '/support/training_document_table', [TrainingDocument::class, 'ajax_table'])->name('support.training_document_table');
    Route::get('/training-document_view/{id}', [TrainingDocument::class, 'fetchTrainingDocumentById']);
    Route::get('/training_document/categoryList', [TrainingDocument::class, 'TrainingCategoryList']);
    Route::post('/training/list', [TrainingDocument::class, 'TrainingList']);
    
    
    Route::match(['get', 'post'], '/support/manage_training_document', [ManageTrainingDocument::class, 'index'])->name('support-manage-training-document');
  Route::post('/manage_training_document_status/{id}', [ManageTrainingDocument::class, 'Status']);
  Route::post('/create_manage_training_document', [ManageTrainingDocument::class, 'Create'])->name('create_manage_training_document');
  Route::post('/update_manage_training_document', [ManageTrainingDocument::class, 'Update'])->name('update_manage_training_document');
  Route::delete('/training_document_delete/{id}', [ManageTrainingDocument::class, 'Delete']);
  Route::get('/training_document_edit/{id}', [ManageTrainingDocument::class, 'Edit']);
  Route::get('/traning_subcat_list', [ManageTrainingDocument::class, 'getSubcategories'])->name('traning_subcat_list');
  // web.php
    Route::post('/roles/remove', [ManageTrainingDocument::class, 'removeRole'])->name('roles.remove');
    Route::post('/update_document_roles', [ManageTrainingDocument::class, 'Update_role'])->name('update_document_roles');
  
  Route::get('/traning_subcat_document_list', [ManageTrainingDocument::class, 'getSubcategories_Document_list'])->name('traning_subcat_document_list');
  Route::post('/save-document-order', [ManageTrainingDocument::class, 'saveDocumentOrder'])->name('save_document_order');
  
  Route::get('/role_list_fetch/{id}', [ManageTrainingDocument::class, 'role_list_fetch']);


  Route::post('/payroll/run_new', [ManagePayroll::class, 'runPayroll']);
  Route::get('/payroll/list', [ManagePayroll::class, 'payrollList']);
  Route::get('/payroll/preview', [ManagePayroll::class, 'previewPayroll']);
  Route::post('/payroll/lock', [ManagePayroll::class, 'lockPayroll']);
  Route::get('/payroll/export', [ManagePayroll::class, 'export']);
  Route::get('/payroll/entry/{entrySno}', [ManagePayroll::class, 'getEntry']);

    Route::get('/payroll/custom_export', [ManagePayroll::class, 'customExport']);
    Route::get('/payroll/common_export', [ManagePayroll::class, 'commonExport']);

  Route::post('/payroll/verify', [ManagePayroll::class, 'verifyPayroll']);
  Route::post('/payroll/freeze', [ManagePayroll::class, 'freezePayroll']);
  Route::post('/payroll/unfreeze', [ManagePayroll::class, 'unfreezePayroll']);

  Route::post('/payroll/process/start', [ManagePayroll::class, 'startPayrollProcess']);
  Route::get('/payroll/process/status/{sno}', [ManagePayroll::class, 'getPayrollProcessStatus']);

  Route::get('/payroll/process/details', [ManagePayroll::class, 'getPayrollProcessDetails']);

  Route::get('/payroll/payslips', [ManagePayroll::class, 'indexPayslip'])->name('hrm-hr-management-enroll-manage-payroll-payslips');
  Route::get('/payroll/payslip/view/{entrySno}', [ManagePayroll::class, 'viewpayslip']);
  // Route::get('/payroll/payslip/pdf/{entrySno}',[ManagePayroll::class,'pdfpayslip']);

  Route::get('/payroll/dashboard/data', [ManagePayroll::class, 'getPreviewData']);

  Route::post('/payroll/dashboard/save', [ManagePayroll::class, 'savePayroll']);

  Route::post('/run-payroll', [PayrollHistoryController::class, 'runPayrollOld']);

  Route::get('/payroll/history', [PayrollHistoryController::class, 'index']);
  Route::get('/payroll/history/data', [PayrollHistoryController::class, 'getRuns']);
  Route::get('/payroll/history/details/{runId}', [PayrollHistoryController::class, 'getRunDetails']);
  Route::get('/payroll/payslip/{entryId}', [PayrollHistoryController::class, 'getPayslip']);
  Route::get('/payroll/payslip/pdf/{entryId}', [PayrollHistoryController::class, 'downloadPDF']);

  Route::get('/hr_general/payslip/{id}', [ManagePayroll::class, 'Payslip'])->name('hrm-hr-management-enroll-manage-payroll');



  Route::get('/salary-components', [ManagePayroll::class, 'getSalaryComponents']);
  Route::get('/company-banks/{id}', [ManagePayroll::class, 'getCompanyBank']);
  Route::get('/view_payslip_staffs/{id}', [ManagePayroll::class, 'ViewPayslipStaffs']);
  Route::post('/send_month_payslip', [ManagePayroll::class, 'SendMonthPayslip']);

  Route::get('/hr_general/manage_salary_struture', [SalaryStructureMenu::class, 'index'])->name('hrm-hr-management-enroll-manage-salary-structure');
  Route::get('/hr_general/manage_salary_struture/add', [SalaryStructureMenu::class, 'Add'])->name('hrm-hr-management-enroll-manage-salary-structure');
  Route::get('/hr_general/manage_salary_struture/edit/{id}', [SalaryStructureMenu::class, 'Edit'])->name('hrm-hr-management-enroll-manage-salary-structure');

  Route::get('/hr_general/salary_struture', [SalaryStructure::class, 'index'])->name('hrm-hr-management-enroll-salary-structure');
  Route::get('/payroll/structure/{sno}', [SalaryStructure::class, 'edit']);
  Route::post('/payroll/structure/save', [SalaryStructure::class, 'saveStucture']);

  Route::get('/staff/salary-mapping/{employeeSno}', [SalaryStructure::class, 'staffSalaryMappingEdit']);
  Route::post('/staff/salary-mapping/save', [SalaryStructure::class, 'staffSalaryMappingSave']);

  // HRM SETTINGS

  // Documents Setting Start
  Route::get('/settings/document', [Documents::class, 'index'])->name('settings-hrm');
  Route::post('/add_document', [Documents::class, 'Add'])->name('add_document');
  Route::get('/document_edit', [Documents::class, 'Edit'])->name('document_edit');
  Route::post('/document_update', [Documents::class, 'Update'])->name('document_update');
  Route::delete('/document_delete/{id}', [Documents::class, 'Delete'])->name('document_delete');
  Route::post('/document_status_change/{id}', [Documents::class, 'Status'])->name('document_status_change');
  Route::get('/document_list', [Documents::class, 'List'])->name('document_list');
  // Documents Setting End

  // DocumentChecklist Setting Start
  Route::get('/settings/document_checklist', [DocumentChecklist::class, 'index'])->name('settings-hrm');
  Route::post('/add_document_checklist', [DocumentChecklist::class, 'Add'])->name('add_document_checklist');
  Route::get('/document_checklist_edit', [DocumentChecklist::class, 'Edit'])->name('document_checklist_edit');
  Route::post('/document_checklist_update', [DocumentChecklist::class, 'Update'])->name('document_checklist_update');
  Route::delete('/document_checklist_delete/{id}', [DocumentChecklist::class, 'Delete'])->name('document_checklist_delete');
  Route::post('/document_checklist_status_change/{id}', [DocumentChecklist::class, 'Status'])->name('document_checklist_status_change');
  Route::get('/document_checklist_list', [DocumentChecklist::class, 'List'])->name('document_checklist_list');
  // DocumentChecklist Setting End

  // Metrics Setting Start
  Route::get('/settings/metrics', [Metrics::class, 'index'])->name('settings-hrm');
  Route::post('/add_metrics', [Metrics::class, 'Add'])->name('add_metrics');
  Route::get('/metrics_edit', [Metrics::class, 'Edit'])->name('metrics_edit');
  Route::post('/metrics_update', [Metrics::class, 'Update'])->name('metrics_update');
  Route::delete('/metrics_delete/{id}', [Metrics::class, 'Delete'])->name('metrics_delete');
  Route::post('/metrics_status_change/{id}', [Metrics::class, 'Status'])->name('metrics_status_change');
  Route::get('/metrics_list', [Metrics::class, 'List'])->name('metrics_list');
  // DocumentChecklist Setting End

  Route::get('/settings/questionnaire', [HRQuestionnaire::class, 'index'])->name('settings-hrm');
  Route::get('/settings/questionnaire/questionnaire_add', [HRQuestionnaire::class, 'add'])->name('settings-hrm');
  Route::get('/settings/questionnaire/questionnaire_edit/{id}', [HRQuestionnaire::class, 'edit'])->name('settings-hrm');
  Route::get('/hr_question_list', [HRQuestionnaire::class, 'List'])->name('hr_question_list');
  Route::get('/hr_question_by_id/{id}', [HRQuestionnaire::class, 'ListDisplay'])->name('hr_question_by_id');
  Route::post('/add_hr_question', [HRQuestionnaire::class, 'QuestionSave'])->name('add_hr_question');
  Route::get('/hr_question_view/{id}', [HRQuestionnaire::class, 'View']);
  Route::post('/hr_question_update', [HRQuestionnaire::class, 'Update'])->name('hr_question_update');
  Route::delete('/hr_question_delete/{id}', [HRQuestionnaire::class, 'Delete']);
  Route::post('/hr_question_status/{id}', [HRQuestionnaire::class, 'Status']);


  Route::get('/settings/onboarding_staging', [OnBoardingStaging::class, 'index'])->name('settings-hrm');
  Route::post('/add_onboarding_staging', [OnBoardingStaging::class, 'Add'])->name('add_onboarding_staging');
  Route::get('/onboarding_staging_edit', [OnBoardingStaging::class, 'Edit'])->name('onboarding_staging_edit');
  Route::post('/onboarding_staging_update', [OnBoardingStaging::class, 'Update'])->name('onboarding_staging_update');
  Route::delete('/onboarding_staging_delete/{id}', [OnBoardingStaging::class, 'Delete'])->name('onboarding_staging_delete');
  Route::post('/onboarding_staging_status_change/{id}', [OnBoardingStaging::class, 'Status'])->name('onboarding_staging_status_change');
  Route::get('/onboarding_staging_list', [OnBoardingStaging::class, 'List'])->name('onboarding_staging_list');


  Route::get('/settings/onboarding', [OnBoardingCheckList::class, 'index'])->name('settings-hrm');
  Route::post('/add_onboarding_checklist', [OnBoardingCheckList::class, 'Add'])->name('add_onboarding_checklist');
  Route::get('/onboarding_checklist_edit', [OnBoardingCheckList::class, 'Edit'])->name('onboarding_checklist_edit');
  Route::post('/onboarding_checklist_update', [OnBoardingCheckList::class, 'Update'])->name('onboarding_checklist_update');
  Route::delete('/onboarding_checklist_delete/{id}', [OnBoardingCheckList::class, 'Delete'])->name('onboarding_checklist_delete');
  Route::post('/onboarding_checklist_status_change/{id}', [OnBoardingCheckList::class, 'Status'])->name('onboarding_checklist_status_change');
  Route::get('/onboarding_checklist_list', [OnBoardingCheckList::class, 'List'])->name('onboarding_checklist_list');


  // Leave Setting Start
  Route::get('/settings/leave_reason', [LeaveReason::class, 'index'])->name('settings-hrm');
  Route::post('/add_leave_reason', [LeaveReason::class, 'Add'])->name('add_leave_reason');
  Route::get('/leave_reason_edit/{id}', [LeaveReason::class, 'Edit'])->name('leave_reason_edit');
  Route::post('/leave_reason_update', [LeaveReason::class, 'Update'])->name('leave_reason_update');
  Route::delete('/leave_reason_delete/{id}', [LeaveReason::class, 'Delete'])->name('leave_reason_delete');
  Route::post('/leave_reason_status_change/{id}', [LeaveReason::class, 'Status'])->name('leave_reason_status_change');
  Route::get('/leave_reason_list', [LeaveReason::class, 'List'])->name('leave_reason_list');
  // Leave Setting End

  // Permission Setting Start
  Route::get('/settings/permission_reason', [PermissionReason::class, 'index'])->name('settings-hrm');
  Route::post('/add_permission_reason', [PermissionReason::class, 'Add'])->name('add_permission_reason');
  Route::get('/permission_reason_edit/{id}', [PermissionReason::class, 'Edit'])->name('permission_reason_edit');
  Route::post('/permission_reason_update', [PermissionReason::class, 'Update'])->name('permission_reason_update');
  Route::delete('/permission_reason_delete/{id}', [PermissionReason::class, 'Delete'])->name('permission_reason_delete');
  Route::post('/permission_reason_status_change/{id}', [PermissionReason::class, 'Status'])->name('permission_reason_status_change');
  Route::get('/permission_reason_list', [PermissionReason::class, 'List'])->name('permission_reason_list');
  // Permission Setting End

  // OndutyReason Setting Start
  Route::get('/settings/onduty_reason', [OndutyReason::class, 'index'])->name('settings-hrm');
  Route::post('/add_onduty_reason', [OndutyReason::class, 'Add'])->name('add_onduty_reason');
  Route::get('/onduty_reason_edit/{id}', [OndutyReason::class, 'Edit'])->name('onduty_reason_edit');
  Route::post('/onduty_reason_update', [OndutyReason::class, 'Update'])->name('onduty_reason_update');
  Route::delete('/onduty_reason_delete/{id}', [OndutyReason::class, 'Delete'])->name('onduty_reason_delete');
  Route::post('/onduty_reason_status_change/{id}', [OndutyReason::class, 'Status'])->name('onduty_reason_status_change');
  Route::get('/onduty_reason_list', [OndutyReason::class, 'List'])->name('permission_reason_list');
  // Onduty Setting End

  // Exit Setting Start
  Route::get('/settings/exit_reason', [ExitReason::class, 'index'])->name('settings-hrm');
  Route::post('/add_exit_reason', [ExitReason::class, 'Add'])->name('add_exit_reason');
  Route::get('/exit_reason_edit/{id}', [ExitReason::class, 'Edit'])->name('exit_reason_edit');
  Route::post('/exit_reason_update', [ExitReason::class, 'Update'])->name('exit_reason_update');
  Route::delete('/exit_reason_delete/{id}', [ExitReason::class, 'Delete'])->name('exit_reason_delete');
  Route::post('/exit_reason_status_change/{id}', [ExitReason::class, 'Status'])->name('exit_reason_status_change');
  Route::get('/exit_reason_list', [ExitReason::class, 'List'])->name('exit_reason_list');
  Route::get('/exit_reason_list_by_type', [ExitReason::class, 'ListByType'])->name('exit_reason_list_by_type');
  // Exit Setting End


  // RECRUITMENT SETTINGS
  Route::get('/settings/major', [Major::class, 'index'])->name('settings-recruitment');
  Route::get('/settings/experience', [Experience::class, 'index'])->name('settings-recruitment');

  Route::get('/settings/call_status', [CallStatus::class, 'index'])->name('settings-recruitment');
  Route::get('/settings/marital_status', [MaritalStatus::class, 'index'])->name('settings-recruitment');

  // Department
  Route::get('/settings/department', [Department::class, 'index'])->name('settings-base-settings');
  Route::get('/department', [Department::class, 'List'])->name('department');
  Route::post('/add_department', [Department::class, 'Add'])->name('add_department');
  Route::get('/department_edit/{id}', [Department::class, 'Edit'])->name('department_edit');
  Route::post('/department_update', [Department::class, 'Update'])->name('department_update');
  Route::delete('/department_delete/{id}', [Department::class, 'Delete']);
  Route::post('/department_status/{id}', [Department::class, 'Status']);
  Route::get('/branch_department_list', [Department::class, 'BranchDepartList'])->name('branch_department_list');


    // Training Document Category
    Route::get('/training/category', [TrainingCategory::class, 'index'])->name('settings-training-settings');
    Route::post('/create_training_category', [TrainingCategory::class, 'store'])->name('create_training_category');
    Route::post('/status_training_category/{id}', [TrainingCategory::class, 'Status']);
    Route::delete('/delete_training_category/{id}', [TrainingCategory::class, 'Delete']);
    Route::post('/update_training_category', [TrainingCategory::class, 'Update'])->name('update_training_category');

    // Training Document Sub Category
    Route::get('/training/sub_category', [TrainingSubCategory::class, 'index'])->name('settings-training-settings');
    Route::post('/create_training_sub_category', [TrainingSubCategory::class, 'store'])->name('create_training_sub_category');
    Route::post('/status_training_sub_category/{id}', [TrainingSubCategory::class, 'Status']);
    Route::delete('/delete_training_sub_category/{id}', [TrainingSubCategory::class, 'Delete']);
    Route::post('/update_training_sub_category', [TrainingSubCategory::class, 'Update'])->name('update_training_sub_category');
    Route::get('/edit_sub_category_data/{id}', [TrainingSubCategory::class, 'Edit']);

  //Division
  Route::get('/settings/division', [Division::class, 'index'])->name('settings-base-settings');
  Route::post('/add_division', [Division::class, 'Add'])->name('add_division');
  Route::get('/division_edit/{id}', [Division::class, 'Edit'])->name('division_edit');
  Route::post('/division_update', [Division::class, 'Update'])->name('division_update');
  Route::post('/division_status/{id}', [Division::class, 'Status']);
  Route::delete('/division_delete/{id}', [Division::class, 'Delete']);
  Route::get('/get_division', [Division::class, 'DepartDivisionList'])->name('get_division');
  Route::get('/get_job_role', [Division::class, 'JobPostionList'])->name('get_job_role');
  Route::get('/get_job_role_by_entity', [Division::class, 'JobPostionListEntity'])->name('get_job_role_by_entity');

  // Job_Role
  Route::get('/settings/job_role', [JobRole::class, 'index'])->name('settings-hrm-settings');
  Route::get('/job_position', [JobRole::class, 'JobPostionList'])->name('job_position');
  Route::post('/add_job_role', [JobRole::class, 'Add'])->name('add_job_role');
  Route::get('/job_role_edit/{id}', [JobRole::class, 'Edit']);
  Route::post('/job_role_update', [JobRole::class, 'Update'])->name('job_role_update');
  Route::delete('/job_role_delete/{id}', [JobRole::class, 'Delete']);
  Route::post('/job_role_status/{id}', [JobRole::class, 'Status']);

  // business setting

  // Department
  Route::get('/settings/business/department', [BusinessDepartment::class, 'index'])->name('settings-base-settings');
  Route::get('/business_department', [BusinessDepartment::class, 'List'])->name('business_department');
  Route::post('/add_business_department', [BusinessDepartment::class, 'Add'])->name('add_business_department');
  Route::get('/business_department_edit/{id}', [BusinessDepartment::class, 'Edit'])->name('business_department_edit');
  Route::post('/business_department_update', [BusinessDepartment::class, 'Update'])->name('business_department_update');
  Route::delete('/business_department_delete/{id}', [BusinessDepartment::class, 'Delete']);
  Route::post('/business_department_status/{id}', [BusinessDepartment::class, 'Status']);
  Route::post('/old-department-add', [BusinessDepartment::class, 'AddOldData'])->name('old-department-add');

  //Division
  Route::get('/settings/business/division', [BusinessDivision::class, 'index'])->name('settings-base-settings');
  Route::post('/add_business_division', [BusinessDivision::class, 'Add'])->name('add_business_division');
  Route::get('/business_division_edit/{id}', [BusinessDivision::class, 'Edit'])->name('business_division_edit');
  Route::post('/business_division_update', [BusinessDivision::class, 'Update'])->name('business_division_update');
  Route::post('/business_division_status/{id}', [BusinessDivision::class, 'Status']);
  Route::delete('/business_division_delete/{id}', [BusinessDivision::class, 'Delete']);
  Route::post('/old-division-add', [BusinessDivision::class, 'AddOldData'])->name('old-division-add');

  // Job_Role
  Route::get('/settings/business/job_role', [BusinessJobRole::class, 'index'])->name('settings-hrm-settings');
  Route::get('/business_job_position', [BusinessJobRole::class, 'JobPostionList'])->name('business_job_position');
  Route::post('/add_business_job_role', [BusinessJobRole::class, 'Add'])->name('add_business_job_role');
  Route::get('/business_job_role_edit/{id}', [BusinessJobRole::class, 'Edit']);
  Route::post('/business_job_role_update', [BusinessJobRole::class, 'Update'])->name('business_job_role_update');
  Route::delete('/business_job_role_delete/{id}', [BusinessJobRole::class, 'Delete']);
  Route::post('/business_job_role_status/{id}', [BusinessJobRole::class, 'Status']);
  Route::post('/old-jobRole-add', [BusinessJobRole::class, 'AddOldData'])->name('old-jobRole-add');

  // Api Config Setting Start
  Route::get('/settings/api_config', [ApiConfig::class, 'index'])->name('settings-apiconfig-settings');
  Route::post('/add_integration', [ApiConfig::class, 'Create'])->name('add_integration');
  Route::post('/integration_status/{id}', [ApiConfig::class, 'Status']);
  Route::delete('/delete_integration/{id}', [ApiConfig::class, 'Delete']);
  Route::get('/integration_edit/{id}', [ApiConfig::class, 'Edit']);
  Route::post('/update_integration', [ApiConfig::class, 'Update'])->name('update_integration');

  // Main Page Route
  Route::get('/dashboard', [Crm::class, 'index'])->name('dashboard');
  Route::get('/hr_dashboard_data', [Crm::class, 'getDashboardData'])->name('hr.dashboard.data');

  // Control Panel
  // Manage Entity
  Route::get('/entity_hub/manage_entity', [ManageEntity::class, 'index'])->name('entity-hub-manage-entity');
  Route::get('/entity_dropdown_list', [ManageEntity::class, 'DropdownList'])->name('entity_dropdown_list');
  Route::post('/add_entity', [ManageEntity::class, 'Add'])->name('add_entity');
  Route::get('/entity_list', [ManageEntity::class, 'List'])->name('entity_list');
  Route::get('/entity_list_multiple', [ManageEntity::class, 'ListMultiple'])->name('entity_list_multiple');
  Route::post('/update_entity', [ManageEntity::class, 'Update'])->name('update_entity');
  Route::post('/entity_status/{id}', [ManageEntity::class, 'Status']);
  Route::delete('/entity_delete/{id}', [ManageEntity::class, 'Delete']);
  Route::get('/entity_view/{id}', [ManageEntity::class, 'View']);
  Route::post('/check_duplicate_entities', [ManageEntity::class, 'checkDuplicates']);

  // manage Holiday
  Route::get('/entity_hub/manage_holiday', [ManageHoliday::class, 'index'])->name('entity-hub-manage-holiday');
  Route::get('/entity_hub/holiday_calender', [ManageHoliday::class, 'HolidayCalender'])->name('entity-hub-manage-holiday');
  Route::get('/holiday/sample-excel', [ManageHoliday::class, 'sampleHolidayEntryExcel']);
  Route::post('/upload_holiday_calender', [ManageHoliday::class, 'UploadHoliday'])->name('upload_holiday_calender');
  Route::get('/holiday-calendar/events', [ManageHoliday::class, 'calendarEvents']);
  Route::get('/holiday_dropdown_list', [ManageHoliday::class, 'DropdownList'])->name('holiday_dropdown_list');
  Route::post('/holiday_add', [ManageHoliday::class, 'Add'])->name('holiday_add');
  Route::get('/holiday_list', [ManageHoliday::class, 'List'])->name('holiday_list');
  Route::post('/holiday_update', [ManageHoliday::class, 'Update'])->name('holiday_update');
  Route::post('/holiday_status/{id}', [ManageHoliday::class, 'Status']);
  Route::delete('/holiday_delete/{id}', [ManageHoliday::class, 'Delete']);
  Route::get('/holiday_view/{id}', [ManageHoliday::class, 'View']);
  Route::post('/check_duplicate_holiday', [ManageHoliday::class, 'checkDuplicates']);


  Route::get('/holidays', [ManageHoliday::class, 'holidayList'])->name('holiday.list');


  Route::get('/manage_targets', [ManageTargets::class, 'index'])->name('business-strategy-sales-target');
  Route::get('/targets', [ManageTargets::class, 'edit_target'])->name('business-strategy-sales-target');
  Route::post('/targets/import', [ManageTargets::class, 'import']);
  Route::post('/targets/preview', [ManageTargets::class, 'preview']);
  Route::get('/targets/data', [ManageTargets::class, 'getData']);
  Route::post('/targets/save', [ManageTargets::class, 'saveData']);
  Route::post('/save-achievement', [ManageTargets::class, 'saveAchievement']);
  Route::get('/incentive_role_by_entity', [ManageTargets::class, 'IncentiveRoles'])->name('incentive_role_by_entity');

  Route::get('/target/sample-excel', [ManageTargets::class, 'sampleTargetEntryExcel']);

  Route::get('/sales_metrics', [SalesMetrics::class, 'index'])->name('business-strategy-sales-metrics');
  Route::get('/get-collection-data', [SalesMetrics::class, 'getCollectionData'])->name('get-collection-data');
  Route::get('/get-collection-table', [SalesMetrics::class, 'getCollectionTable'])->name('get-collection-table');
  Route::post('/update-collection', [SalesMetrics::class, 'updateCollection'])->name('update-collection');

Route::get('/sales_metrics/comparison',[SalesMetrics::class,'comparisonChart']);

Route::get('/sales_metrics/comparison/financial-years',[SalesMetrics::class,'comparisonFinancialYears']);

Route::post('/sales_metrics/comparison/dashboard',[SalesMetrics::class,'comparisonDashboard']);



  Route::get('/hr_sib/manage_incentive', [StaffIncentives::class, 'index'])->name('hrm-hr-management-sib-manage-incentive');
  Route::post('/staff-incentive/save',[StaffIncentives::class, 'SaveIncentive'])->name('staff.incentive.save');

  Route::get('/hr_sib/manage_tenx',[StaffTenX::class, 'index'])->name('hrm-hr-management-sib-manage-tenx');
  Route::get('/staff_list_by_department', [StaffTenX::class,'staffListByDepartment'])->name('staff_list_by_department');
  Route::get('/staff_tenx_profile', [StaffTenX::class,'staffTenxProfile'])->name('staff_tenx_profile');
  Route::post('/update_tenx_log',[StaffTenX::class,'updateTenxLog'])->name('update_tenx_log');

  Route::get('/hr_sib/master_attendance',[StaffTenX::class, 'masterAttendanceIndex'])->name('hrm-hr-management-sib-master-attendance');
  

  Route::get('/hr_sib/salary_advance', [ManageAdvance::class,'index'])->name('hrm-hr-management-sib-manage-advance');
  Route::get('/hr_sib/advance/list', [ManageAdvance::class,'list'])->name('hr_sib.advance.list');
  Route::get('/staff_advance_profile', [ManageAdvance::class,'staffAdvanceProfile'])->name('staff_advance_profile');
  Route::post('/update_advance_log',[ManageAdvance::class,'updateAdvanceLog'])->name('update_advance_log');

  // Manage Appraisal 
  Route::prefix('hr_sib/appraisal')->group(function () {

    Route::get('/', [ManageAppraisal::class,'index'])
        ->name('hr_sib.appraisal.index');

    Route::get('/list', [ManageAppraisal::class,'list'])
        ->name('hr_sib.appraisal.list');

    Route::get('/details/{staff}', [ManageAppraisal::class,'details'])
        ->name('hr_sib.appraisal.details');

    Route::get('/history/{staff}', [ManageAppraisal::class,'history'])
        ->name('hr_sib.appraisal.history');

});
  // Manage Company
  Route::get('/entity_hub/manage_company', [ManageCompany::class, 'index'])->name('entity-hub-manage-company');

  Route::post('/change-branch', [ManageCompany::class, 'changeBranch'])->name('change-branch');
  Route::post('/change-role', [ManageCompany::class, 'changeRole'])->name('change-role');
  Route::post('/get-users-by-role', [ManageCompany::class, 'getUsersByRole'])->name('get-users-by-role');
  Route::post('/change-user', [ManageCompany::class, 'changeUser'])->name('change-user');
  Route::post('/add_company', [ManageCompany::class, 'Add'])->name('add_company');
  Route::get('/company_list', [ManageCompany::class, 'List'])->name('company_list');
  Route::post('/update_company', [ManageCompany::class, 'Update'])->name('update_company');
  Route::post('/company_status/{id}', [ManageCompany::class, 'Status']);
  Route::delete('/company_delete/{id}', [ManageCompany::class, 'Delete']);
  Route::get('/company_view/{id}', [ManageCompany::class, 'View']);
  Route::post('/check_duplicates_company', [ManageCompany::class, 'checkDuplicates']);

  Route::get('/entity_list_by_company/{id}', [ManageCompany::class, 'EntityListByCompany'])->name('entity_list_by_company');

  // Manage Branch
  // Route::get('/entity_hub/manage_branch', [ManageBranch::class, 'index'])->name('entity-hub-manage-branch');

  // Route::get('/branch/edit', [ManageBranch::class, 'edit'])->name('entity-hub-manage-branch');


  // Manage Branch Start
  Route::get('/entity_hub/manage_branch', [ManageBranch::class, 'index'])->name('entity-hub-manage-branch');

  Route::get('/branch_list_multiple', [ManageBranch::class, 'BranchListMultiple'])->name('branch_list_multiple');
  Route::get('/entity_branch_dropdown_list', [ManageBranch::class, 'Entity_branch_dropdown_list'])->name('entity_branch_dropdown_list');
  Route::get('/branch/create', [ManageBranch::class, 'create_branch_franchise'])->name('branch-management-manage-branch');
  Route::get('/edit_branch_franchise/{id}', [ManageBranch::class, 'Edit'])->name('branch-management-manage-branch');
  Route::post('/branch_status/{id}', [ManageBranch::class, 'Status']);
  Route::delete('/branch_delete/{id}', [ManageBranch::class, 'Delete']);
  Route::get('/branch_view/{id}', [ManageBranch::class, 'View']);
  Route::get('/create_branch_franchise', [ManageBranch::class, 'create_branch_franchise'])->name('branch');
  Route::post('/add_branch_franchise', [ManageBranch::class, 'Add'])->name('add_branch_franchise');
  Route::post('/update_branch_franchise', [ManageBranch::class, 'Update'])->name('update_branch_franchise');
  Route::post('/assign_center_head', [ManageBranch::class, 'AssignCenterHead'])->name('assign_center_head');
  Route::post('/branch/Add_staff_branch', [ManageBranch::class, 'Add_staff_branch'])->name('Add_staff_branch');
  Route::get('/bran_drop_down', [ManageBranch::class, 'List'])->name('bran_drop_down');
  Route::get('/get_course_branch', [ManageBranch::class, 'get_course_by_type'])->name('get_course_branch');
  Route::get('/job_position_branch', [ManageBranch::class, 'Job_postion_to_Cug'])->name('job_position_branch');
  Route::get('/get_staff_data_based_on_role/{id}', [ManageBranch::class, 'Staff_based_on_role'])->name('get_staff_data_based_on_role');
  Route::post('/assign_cug_Detail', [ManageBranch::class, 'AssignCugDetails'])->name('assign_cug_Detail');
  Route::post('/edit_cug_to_staff', [ManageBranch::class, 'Update_staff_Cug_modal'])->name('edit_cug_to_staff');
  Route::get('/cre_dropdown_for_branch', [ManageBranch::class, 'Cre_Dropdown'])->name('cre_dropdown_for_branch');
  Route::get('/cug_details', [ManageBranch::class, 'Cug_Edit_Fetch'])->name('cug_details');
  Route::delete('/cug_delete', [ManageBranch::class, 'Cug_delete'])->name('cug_delete');
  Route::get('/check_unique_mobile_number', [ManageBranch::class, 'checkUniqueMobileNumber'])->name('check_unique_mobile_number');
  Route::post('/check-branch-duplicates', [ManageBranch::class, 'checkDuplicates']);

  Route::get('/staff_access_app/{id}', [ManageBranch::class, 'StaffAccessApp']);
  Route::post('update_staff_access', [ManageBranch::class, 'updateStaffAccess'])->name('update_staff_access');

  Route::get('/branch/add', [ManageBranch::class, 'addPage'])->name('entity-hub-manage-branch');
  Route::get('/branch/edit/{id}', [ManageBranch::class, 'Edit'])->name('entity-hub-manage-branch');

  // Manage Branch End

  // User Management
  // Manage Users
  Route::get('/user_management/manage_users', [ManageUsers::class, 'index'])->name('user-management-manage-users');
  Route::get('/user_role_manage', [ManageUsers::class, 'List'])->name('user_role_manage');
  Route::get('/staff/view/{id}', [ManageUsers::class, 'View'])->name('staff.view');

  // User Role

  Route::get('/user_management/manage_permission', [UserRolePermission::class, 'index'])->name('user-management-user-role-permission');
  Route::get('/user_management/manage_permission/create_manage_users', [UserRolePermission::class, 'users_add'])->name('user-management-user-role-permission');
  Route::get('/user_management/manage_permission/update_role_permision/{id}', [UserRolePermission::class, 'users_edit'])->name('user-management-user-role-permission');
  Route::get('/user_management/manage_permission/view_role', [UserRolePermission::class, 'view'])->name('user-management-user-role-permission');

  Route::get('/user_management/manage_business_permission', [UserRolePermission::class, 'indexBusiness'])->name('user-management-user-role-permission');

  Route::get('/users/view_manage_users/{id}', [UserRolePermission::class, 'users_view'])->name('users-manage-users');
  Route::post('/add_user_role_permission', [UserRolePermission::class, 'Add'])->name('add_user_role_permission');
  Route::post('/edit_user_role_permission/{id}', [UserRolePermission::class, 'Edit']);
  Route::post('/update_user_role_permission/{id}', [UserRolePermission::class, 'Update'])->name('update_user_role_permission');
  Route::delete('/user_role_permission_delete/{id}', [UserRolePermission::class, 'Delete']);
  Route::post('/user_role_permission_status/{id}', [UserRolePermission::class, 'Status']);


  // Corporate Admin

  // Vendor Management
  // Manage Vendor
  Route::get('/manage_vendor', [ManageVendor::class, 'index'])->name('corporate-admin-vendor-manage');
  Route::get('/manage_active_vendor', [ManageVendor::class, 'active_vendor'])->name('corporate-admin-vendor-manage');
  Route::get('/manage_hold_vendor', [ManageVendor::class, 'onhold_vendor'])->name('corporate-admin-vendor-manage');
  Route::get('/manage_blocked_vendor', [ManageVendor::class, 'block_vendor'])->name('corporate-admin-vendor-manage');
  Route::get('/manage_pending_vendor', [ManageVendor::class, 'pending_vendor'])->name('corporate-admin-vendor-manage');

  Route::get('/vendor_quotation', [ManageVendor::class, 'print'])->name('corporate-admin-vendor-manage');

  Route::post('/manage_vendor/change_status', [ManageVendor::class, 'changeStatus'])->name('manage_vendor.change_status');
  Route::get('/manage_vendor/view/{id}', [ManageVendor::class, 'viewVendor'])->name('manage_vendor.view');
  Route::post('/save_vendor',[ManageVendor::class,'Add'])->name('save_vendor');
  Route::get('/manage_vendor/edit/{id}', [ManageVendor::class,'edit']);
  Route::post('/update_vendor', [ManageVendor::class,'Update'])->name('update_vendor');
  Route::get('/manage_vendor/scorecard/{id}', [ManageVendor::class,'scorecard']);
 
// Purchase Management
// Manage Purchase
Route::get('/purchase_approval', [PurchaseApproval::class, 'index'])->name('admin-purchase-approval');
Route::get('/purchase_print', [PurchaseApproval::class, 'print'])->name('admin-purchase-approval');
 
 
Route::get('/manage_purchase', [ManagePurchase::class, 'index'])->name('admin-purchase-manage');
Route::get('/manage_pendingapproval', [ManagePurchase::class, 'pendingapproval'])->name('admin-manage-purchase');
Route::get('/manage_approved', [ManagePurchase::class, 'approved'])->name('admin-manage-purchase');
Route::get('/manage_inrfq', [ManagePurchase::class, 'inrfq'])->name('admin-manage-purchase');
Route::get('/manage_onpo', [ManagePurchase::class, 'onpo'])->name('admin-manage-purchase');
Route::get('/manage_closed', [ManagePurchase::class, 'closed'])->name('admin-manage-purchase');
Route::get('/purchase_quotation', [ManageVendor::class, 'print'])->name('admin-manage-manage');
 
 
// Stock Management
Route::get('/material_request', [MaterialRequest::class, 'index'])->name('admin-stock-request');
Route::get('/print_items', [MaterialRequest::class, 'print'])->name('admin-stock-request');
 
 
Route::get('/manage_items', [ManageItems::class, 'index'])->name('corporate-admin-stock-items');
Route::post('/save_item',[ManageItems::class,'Add'])->name('save_item');
Route::post('/get_item_subcategories',[ManageItems::class,'getItemSubCategories'])->name('get_item_subcategories');


Route::get('/manage_stock', [ManageStock::class, 'index'])->name('corporate-admin-stock-manage-stock');
Route::post('/manage_stock/get_items',[ManageStock::class,'getItems']);
Route::post('/manage_stock/add',[ManageStock::class,'add']);
Route::get('/manage_stock/view/{id}', [ManageStock::class, 'view'])->name('manage_stock.view');
Route::get('/manage_stock/adjust/{id}',[ManageStock::class,'adjustStockInfo']);
Route::post('/manage_stock/adjust',[ManageStock::class,'adjustStock']);


Route::get('/manage_cycle_count', [ManageStock::class, 'cycle_count'])->name('corporate-admin-stock-manage-stock');
Route::get('/manage_damage', [ManageStock::class, 'damage'])->name('corporate-admin-stock-manage-stock');
Route::get('/manage_movements', [ManageStock::class, 'movements'])->name('corporate-admin-stock-manage-stock');
Route::get('/manage_expiry', [ManageStock::class, 'expiry'])->name('corporate-admin-stock-manage-stock');
Route::get('/stock_validation', [StockValidation::class, 'index'])->name('admin-stock-validation');
Route::get('/price_book', [PriceBook::class, 'index'])->name('admin-vendor-price-book');

  // Manage & Maintanence

  // Manage Location
  Route::get('/manage_location', [ManageLocation::class, 'index'])->name('corporate-admin-maintanence-location');
  Route::get('/manage_location/add', [ManageLocation::class, 'add_location'])->name('corporate-admin-maintanence-location');
  Route::get('/manage_location/update', [ManageLocation::class, 'update_location'])->name('corporate-admin-maintanence-location');
  Route::post('/save_location', [ManageLocation::class, 'Add'])->name('save_location');
  Route::get('/location_details_by_id', [ManageLocation::class, 'LoactionDetails'])->name('location_details_by_id');
  Route::post('/update_location', [ManageLocation::class, 'Update'])->name('update_location');
   Route::post('/location_status/{id}', [ManageLocation::class, 'Status']);

  // Manage Buildings 
   
  // Manage Buildings 
   Route::get('/manage_building', [ManageBuilding::class, 'index'])->name('corporate-admin-maintanence-building');
   // Add View
  Route::get('/manage_building/add', [ManageBuilding::class, 'add_building'])->name('corporate-admin-maintanence-building');
  // Edit View
  Route::get('/manage_building/update', [ManageBuilding::class, 'update_building'])->name('corporate-admin-maintanence-building');
  // Save Building
  Route::post('/save_building', [ManageBuilding::class, 'Add'])->name('save_building');

  // Building Details
  Route::get('/building_list', [ManageBuilding::class, 'List'])->name('building_list');
  Route::get('/building_details_by_id', [ManageBuilding::class, 'BuildingDetailsById'])->name('building_details_by_id');
  Route::get('/manage_building/details/{id}',[ManageBuilding::class, 'BuildingDetails'])->name('building_details');
  Route::get('/manage_building/floor_list/{id}', [ManageBuilding::class, 'FloorList'])->name('building_floor_list');

  Route::get('/manage_building/agreement_list/{id}',[ManageBuilding::class,'AgreementList'])->name('building_agreement_list');
  // Update Building
  Route::post('/update_building', [ManageBuilding::class, 'Update'])->name('update_building');
  // Status Update
  Route::post('/building_status/{id}', [ManageBuilding::class, 'Status']);

  Route::post('/save_building_floor', [ManageBuilding::class, 'SaveFloor'])->name('save_building_floor');

Route::get('/floor_details_by_id', [ManageBuilding::class, 'FloorDetails'])->name('floor_details_by_id');

Route::post('/update_building_floor', [ManageBuilding::class, 'UpdateFloor'])->name('update_building_floor');

Route::post('/floor_status/{id}', [ManageBuilding::class, 'FloorStatus']);
Route::post('/save_building_amenity', [ManageBuilding::class, 'SaveAmenity'])->name('save_building_amenity');

Route::get('/amenity_details_by_id', [ManageBuilding::class, 'AmenityDetails'])->name('amenity_details_by_id');

Route::post('/update_building_amenity', [ManageBuilding::class, 'UpdateAmenity'])->name('update_building_amenity');

Route::post('/amenity_status/{id}', [ManageBuilding::class, 'AmenityStatus']);

Route::post('/save_building_agreement', [ManageBuilding::class, 'SaveAgreement'])->name('save_building_agreement');

Route::get('/agreement_details_by_id', [ManageBuilding::class, 'AgreementDetails'])->name('agreement_details_by_id');

Route::post('/update_building_agreement', [ManageBuilding::class, 'UpdateAgreement'])->name('update_building_agreement');

Route::post('/agreement_status/{id}', [ManageBuilding::class, 'AgreementStatus']);
Route::post('/save_building_document', [ManageBuilding::class, 'SaveDocument'])->name('save_building_document');

Route::get('/document_details_by_id', [ManageBuilding::class, 'DocumentDetails'])
    ->name('document_details_by_id');

Route::post('/update_building_document', [ManageBuilding::class, 'UpdateDocument'])
    ->name('update_building_document');

Route::post('/document_status/{id}', [ManageBuilding::class, 'DocumentStatus']);

Route::get(
    '/manage_building/renewal_list/{building}',
    [ManageBuilding::class,'RenewalList']
)->name('building_renewal_list');


  // Manage Buildings 
   Route::get('/manage_lessor', [ManageLessor::class, 'index'])->name('corporate-admin-maintanence-building');

  // Manage Electricity 
  Route::get('/manage_electricity', [ManageElectricity::class, 'index'])->name('corporate-admin-maintanence-electricity');
  // Add View
  Route::get('/manage_electricity/add',[ManageElectricity::class,'add_account'])->name('corporate-admin-maintanence-electricity');
  // Edit View
  Route::get('/manage_electricity/update',[ManageElectricity::class,'update_account'])->name('corporate-admin-maintanence-electricity');
  // Save
  Route::post('/save_electricity_account',[ManageElectricity::class,'Add'])->name('save_electricity_account');
  // Update
  Route::post('/update_electricity_account',[ManageElectricity::class,'Update'])->name('update_electricity_account');
  // Details By Id
  Route::get('/electricity_account_details_by_id',[ManageElectricity::class,'AccountDetailsById'])->name('electricity_account_details_by_id');
  // Change Status
  Route::post('/electricity_account_status/{id}',[ManageElectricity::class,'Status']);
  // Overview
  Route::get('/manage_electricity/details/{id}',[ManageElectricity::class,'AccountDetails'])->name('electricity_account_details');
  // Meter List
  Route::get('/manage_electricity/meter_list/{id}',[ManageElectricity::class,'MeterList'])->name('electricity_meter_list');
  // Reading List
  Route::get('/manage_electricity/reading_list/{id}',[ManageElectricity::class,'ReadingList'])->name('electricity_reading_list');
  // Bill List
  Route::get('/manage_electricity/bill_list/{id}',[ManageElectricity::class,'BillList'])->name('electricity_bill_list');
  // Complaint List
  Route::get('/manage_electricity/complaint_list/{id}',[ManageElectricity::class,'ComplaintList'])->name('electricity_complaint_list');
  // Document List
  Route::get('/manage_electricity/document_list/{id}',[ManageElectricity::class,'DocumentList'])->name('electricity_document_list');
  // Payment Request List
  Route::get('/manage_electricity/payment_request_list/{id}',[ManageElectricity::class,'PaymentRequestList'])->name('electricity_payment_request_list');
Route::post('/save_electricity_meter',[ManageElectricity::class, 'AddMeter'])->name('save_electricity_meter');
  // Manage EB
  Route::get('/manage_eb', [ManageEb::class, 'index'])->name('corporate-admin-maintanence-eb');

  // Manage Phone
  Route::get('/manage_phone', [ManagePhone::class, 'index'])->name('corporate-admin-maintanence-phone');


  // Manage Internet
  Route::get('/manage_internet', [ManageInternet::class, 'index'])->name('corporate-admin-maintanence-internet');

  // Manage Rent
  Route::get('/manage_rent', [ManageRent::class, 'index'])->name('corporate-admin-maintanence-rent');

  // Policies And YERD
  Route::get('/manage_insurance_amc', [ManageInsuranceAMC::class, 'index'])->name('policies-manage-insurance-and-amc');
  Route::get('/manage_executive_dashboard', [ExecutiveDashboard::class, 'index'])->name('policies-manage-executive-dashboard');
  Route::get('/manage_subscription_others', [SubscriptionAndOthers::class, 'index'])->name('policies-manage-subscription-others');
  Route::get('/manage_renewal_calendar', [RenewalCalendar::class, 'index'])->name('policies-manage-renewal_calendar');
  Route::get('/manage_yerd', [ManageYerd::class, 'index'])->name('policies-manage-yerd');

  // vehicle Management
   Route::get('/manage_vehicle_machinery', [VehicleMachinery::class, 'index'])->name('vehicle-management-vehicle');
   Route::get('/manage_vehicle_machinery/add', [VehicleMachinery::class, 'add'])->name('vehicle-management-vehicle');
   Route::get('/manage_vehicle_machinery/edit', [VehicleMachinery::class, 'edit'])->name('vehicle-management-vehicle');
   Route::get('/active_vehicle', [VehicleMachinery::class, 'active'])->name('vehicle-management-vehicle');
   Route::get('/inservice_vehicle', [VehicleMachinery::class, 'in_service'])->name('vehicle-management-vehicle');
   Route::get('/idle_vehicle', [VehicleMachinery::class, 'idle'])->name('vehicle-management-vehicle');
   Route::get('/lapsed_vehicle', [VehicleMachinery::class, 'lapsed'])->name('vehicle-management-vehicle');
   Route::get('/expired_vehicle', [VehicleMachinery::class, 'expired'])->name('vehicle-management-vehicle');


  Route::get('/hr_recruitment/job_request', [JobRequest::class, 'index'])->name('hrm-hr-management-recruitment-manage-job-request');
  Route::get('/hr_recruitment/interview_schedule/{id}', [JobRequest::class, 'InterviewSchedule'])->name('hrm-hr-management-recruitment-manage-job-request');
  Route::post('/add_job_request', [JobRequest::class, 'Add'])->name('add_job_request');
  Route::post('/create-interview-schedule', [JobRequest::class, 'createInterviewSchedule'])->name('create-interview-schedule');
  Route::get('/job_request_edit/{id}', [JobRequest::class, 'Edit'])->name('job_request_edit');
  Route::post('/update_job_request', [JobRequest::class, 'Update'])->name('update_job_request');
  Route::get('/job_request_list', [JobRequest::class, 'List'])->name('job_request_list');
  Route::get('/interview_questions_by_role_categ', [JobRequest::class, 'interviewQuestionsByRole'])->name('interview_questions_by_role_categ');
  Route::post('/job_request_status/{id}', [JobRequest::class, 'Status']);
  Route::delete('/job_request_delete/{id}', [JobRequest::class, 'Delete']);
  Route::post('generate-job-description', [JobRequest::class, 'generateJobDescription'])->name('generate-job-description');


  Route::get('/hr_recruitment/job_fair', [JobFairController::class, 'index'])->name('hrm-hr-management-recruitment-manage-job-fair');
  Route::post('/add_job_fair', [JobFairController::class, 'Add'])->name('add_job_fair');
  Route::get('/job_fair_edit/{id}', [JobFairController::class, 'Edit'])->name('job_fair_edit');
  Route::post('/update_job_fair', [JobFairController::class, 'Update'])->name('update_job_fair');
  Route::get('/job_fair_list', [JobFairController::class, 'List'])->name('job_fair_list');
  Route::post('/job_fair_status/{id}', [JobFairController::class, 'Status']);
  Route::delete('/job_request_delete/{id}', [JobFairController::class, 'Delete']);
  Route::get('/applicant_list_by_job_fair', [JobFairController::class, 'ApplyCandidateListByJob'])->name('applicant_list_by_job_fair');
  Route::match(['get', 'post'], '/qr_job_fair_scanners', [JobFairController::class, 'Scanner_view'])->name('qr.scanner.job_fair');
  Route::match(['get', 'post'], '/qr.scanner.job_fair.map', [JobFairController::class, 'MultiMap'])->name('qr.scanner.job_fair.map');


  Route::post('/add_job_candidate', [JobRequest::class, 'AddJobCandidate'])->name('add_job_candidate');
  Route::post('/add_new_candidate', [JobRequest::class, 'AddNewCandidate'])->name('add_new_candidate');
  Route::get('/applicant_list_by_job_request', [JobRequest::class, 'ApplyCandidateListByJob'])->name('applicant_list_by_job_request');
  Route::post('/update_shortlist_candidate', [JobRequest::class, 'UpdateShortlistCandidate'])->name('update_shortlist_candidate');
  Route::match(['get', 'post'], '/qr_job_request_scanners', [JobRequest::class, 'Scanner_view'])->name('qr.scanner.job_request');
  Route::match(['get', 'post'], '/qr.scanner.job_request.map', [JobRequest::class, 'MultiMap'])->name('qr.scanner.job_request.map');
  Route::get('/not_apply_list_by_job_request', [JobRequest::class, 'NotAppliedListByJob'])->name('not_apply_list_by_job_request');

  Route::get('get_interview_schedule_by_job_id', [JobRequest::class, 'getInterviewScheduleByJobId'])->name('get_interview_schedule_by_job_id');


  Route::get('/hr_recruitment/manage_candidate', [ManageCandidate::class, 'index'])->name('hrm-hr-management-recruitment-manage-candidate');
  Route::post('/extract-resume', [ManageCandidate::class, 'extractCandidateData'])->name('extract_resume');

  Route::get('/candidate_details_by_id', [ManageCandidate::class, 'ApplicantDetails'])->name('candidate_details_by_id');
  Route::post('/update_candidate', [ManageCandidate::class, 'UpdateApplicant'])->name('update_candidate');
  Route::post('generate_ai_anlyse_by_resume', [ManageCandidate::class, 'generateAiAnalyse'])->name('generate_ai_anlyse_by_resume');


  Route::get('/candidate/vip-details',[ManageCandidate::class,'vipDetails'])->name('candidate.vip.details');
  Route::post('/candidate/mark-vip',[ManageCandidate::class,'markVip'])->name('candidate.mark.vip');

  Route::get('/candidate_history_details',[ManageCandidate::class,'getCandidateHistoryDetails'])->name('candidate.history.details');
  Route::post('/candidate_history_store',[ManageCandidate::class,'storeCandidateHistory'])->name('candidate.history.store');
  Route::get('/candidate-company-roles',[ManageCandidate::class, 'companyRoles'])->name('candidate.company.roles');

  Route::get('/candidate/ai-view/{id}',[ManageCandidate::class,'aiView'])->name('candidate.ai.view');
  
  Route::get('/hr-recruitment/applicant/{id}/ai-analysis',[ApplicantAIController::class, 'show'])->name('applicant.ai.show');

   Route::prefix('hr-recruiter/applicants')->group(function () {
      Route::post('/{sno}/ai-match', [ ApplicantAIController::class,'matchBySno'] )->whereNumber('sno');

      /*
      * Stored AI analysis
      */
      Route::get(
          '/{sno}/ai-analysis',
          [
              ApplicantAIController::class,
              'analysis'
          ]
      )->whereNumber('sno');

      /*
      * Bulk matching
      */
      Route::post(
          '/ai-bulk-match',
          [
              ApplicantAIController::class,
              'bulkMatch'
          ]
      );
  });

  Route::get(
      '/hr-recruiter/ai/bulk-role-matching/stats',
      [BulkApplicantAIController::class, 'stats']
  )->name('hr-recruiter.ai.bulk-role-matching.stats');

  Route::post(
    '/hr-recruiter/ai/bulk-role-matching',
    [BulkApplicantAIController::class, 'bulkRoleMatching']
)->name('hr-recruiter.ai.bulk-role-matching');

  Route::put('/recruitment-roles/{sno}/ai-profile',[ RecruitmentRoleAIProfileController::class,'update'])->whereNumber('sno');
Route::get('/recruitment-roles/{sno}/ai-profile',[ RecruitmentRoleAIProfileController::class, 'show'])->whereNumber('sno');


  Route::get('/hr_recruitment/interview_staging', [InterviewStaging::class, 'index'])->name('hrm-hr-management-recruitment-interview-staging');
  Route::get('/monitoring_candidate_list', [InterviewStaging::class, 'candidateList'])->name('monitoring_candidate_list');
  Route::post('/hr/candidate/hire', [InterviewStaging::class, 'hireCandidate'])
    ->name('hr.hire.candidate');

  Route::post('/hr/candidate/shortlist', [InterviewStaging::class, 'shortlistCandidate'])
    ->name('hr.shortlist.candidate');
  Route::post('/hr/candidate/reject', [InterviewStaging::class, 'rejectCandidate'])
    ->name('hr.reject.candidate');
  Route::get('/interview-media/{answer}', [InterviewStaging::class, 'stream'])
    ->name('interview.media');

  Route::post('/send_confirmation_bulk', [InterviewStaging::class, 'sendConfirmationBulk'])->name('send_confirmation_bulk');
  Route::get('/job-confirmation/{token}', [InterviewStaging::class, 'jobConfirmationPage'])
    ->name('job.confirmation.page');

  Route::post('/job-confirmation/submit', [InterviewStaging::class, 'jobConfirmationSubmit'])
    ->name('job.confirmation.submit');

  Route::get('/job-confirmation/thank-you-accept/{token}', [InterviewStaging::class, 'jobConfirmationAccept'])
    ->name('job.confirmation.thankyou.accept');
  Route::get('/job-confirmation/thank-you-decline/{token}', [InterviewStaging::class, 'jobConfirmationDecline'])
    ->name('job.confirmation.thankyou.decline');
  Route::get('/job-confirmation/thank-you-expired/{token}', [InterviewStaging::class, 'jobConfirmationExpired'])->name('job.confirmation.thankyou.expired');



  // user Role Multiple
  Route::get('/user_management/user_role', [UserRole::class, 'index'])->name('user-management-role');
  Route::get('/user_role', [UserRole::class, 'List'])->name('user_role');
  Route::get('/user_role_by_entity', [UserRole::class, 'ListByEntity'])->name('user_role_by_entity');
  Route::post('/add_user_role', [UserRole::class, 'Add'])->name('add_user_role');
  Route::get('/user_role_edit/{id}', [UserRole::class, 'Edit']);
  Route::post('/user_role_update/{id}', [UserRole::class, 'Update']);
  Route::delete('/user_role_delete/{id}', [UserRole::class, 'Delete']);
  Route::post('/user_role_status/{id}', [UserRole::class, 'Status']);
  Route::get('/role/export-excel', [UserRole::class, 'ExportExcel']);

  Route::get('/user_management/business_user_role', [UserRole::class, 'businessIndex'])->name('user-management-role');
  Route::get('/business_user_role', [UserRole::class, 'businessList'])->name('business_user_role');
  Route::post('/add_business_user_role', [UserRole::class, 'Add'])->name('add_business_user_role');
  Route::get('/business_user_role_edit/{id}', [UserRole::class, 'businessEdit']);
  Route::post('/business_user_role_update/{id}', [UserRole::class, 'businessUpdate']);
  Route::delete('/business_user_role_delete/{id}', [UserRole::class, 'businessDelete']);
  Route::post('/business_user_role_status/{id}', [UserRole::class, 'businessStatus']);
  Route::post('/old-userRole-add', [UserRole::class, 'AddOldData'])->name('old-userRole-add');

  // User Chart
  Route::get('/user_management/user_chart', [UserChart::class, 'index'])->name('user-management-user-chart');

  // User Timestamp
  Route::get('/hr_management/staff_timechamp', [UserTimestamp::class, 'index'])->name('hrm-hr-management-operation-timechamp');
  Route::post('/update_staff_timestamp_report', [UserTimestamp::class, 'UpdateTimestampReport'])->name('update_staff_timestamp_report');
  Route::get('/get_staff_daily_timestamp', [UserTimestamp::class, 'getDailySummaryByEmployeeId'])->name('get_staff_daily_timestamp');
  Route::get('/timechamp/staff-report', [UserTimestamp::class, 'getSummaryByEmployeeId']);
  Route::get('/timechamp/week-report', [UserTimestamp::class, 'getWeekSummaryByEmployeeId']);
  Route::get('/timechamp/month-report', [UserTimestamp::class, 'getMonthSummaryByEmployeeId']);
  Route::get('/timechamp/year-report', [UserTimestamp::class, 'getYearSummaryByEmployeeId']);
  Route::get('/timechamp/ai-usage-details', [UserTimestamp::class, 'getAiUsageDetails']);
  Route::get('/timechamp/application-usage-details', [UserTimestamp::class, 'getApplicationUsageDetails']);

  // HR Enroll
  // Manage Staff
  Route::get('/hr_enroll/manage_staff', [ManageStaff::class, 'index'])->name('hrm-hr-management-enroll-manage-staff');
  Route::post('/add_old_staff', [ManageStaff::class, 'AddOldStaff'])->name('add_old_staff');
  Route::get('/hr_enroll/exit_staff', [ManageStaff::class, 'exit_staff'])->name('hrm-hr-management-enroll-manage-staff');
  Route::get('/hr_enroll/manage_staff/add_staff', [ManageStaff::class, 'staff_add'])->name('hrm-hr-management-enroll-manage-staff');
  Route::get('/hr_enroll/manage_staff/update_staff/{id}', [ManageStaff::class, 'edit'])->name('hrm-hr-management-enroll-manage-staff');
  Route::get('hr_enroll/manage_staff/orientation_edit', [ManageStaff::class, 'Orientation'])->name('manage-staff-staff-list');
  Route::post('/add_staff', [ManageStaff::class, 'Add'])->name('add_staff');
  Route::post('/update_staff', [ManageStaff::class, 'Update'])->name('update_staff');
  Route::post('/update_staff_by_stage', [ManageStaff::class, 'UpdateStaffStage'])->name('update_staff_by_stage');
  Route::get('/staff_list_by_branch_id/{id}', [ManageStaff::class, 'StaffListByBranch'])->name('staff_list_by_branch_id');

  Route::get('/staff_view/{id}', [ManageStaff::class, 'View']);
  Route::get('/staff_detailed_view/{id}', [ManageStaff::class, 'ViewDetailStaff'])->name('staff.view');

Route::get('/staff/{employee}/salary-payroll',[ManageStaff::class, 'getStaffSalaryPayrollView'])->name('staff.salary_payroll');

// Use your ACTUAL existing payslip controller method here.
Route::get(
    '/payroll/payslip_staff/{encryptedPayslip}',
    [ManageStaff::class, 'viewStaffPayslip']
)->name('payroll_payslip_staff');

/*
|--------------------------------------------------------------------------
| STAFF ASSET MANAGEMENT
|--------------------------------------------------------------------------
*/
// Load staff + available assets
Route::get(
    '/staff/{staff}/assets',
    [ManageStaff::class, 'getStaffAssets']
)->name('staff.assets.index');


// Assign one or more assets
Route::post(
    '/staff/assets/assign',
    [ManageStaff::class, 'assignStaffAssets']
)->name('staff.assets.assign');


// Return assigned asset
Route::post(
    '/staff/assets/return',
    [ManageStaff::class, 'returnStaffAsset']
)->name('staff.assets.return');

  Route::get('/staff/get-transfer-data',[ManageStaff::class,'getTransferData']);
  Route::post( '/staff/transfer',[ManageStaff::class,'transferStaff']);

  Route::get('/employee/payroll/details/{employeeSno}', [ManageStaff::class, 'editPayrollDetails'])->name('editPayrollDetails');

  Route::post('/employee/payroll/save', [ManageStaff::class, 'savePayroll']);

  Route::get('/hr_enroll/exit_staff_pending', [ManageStaff::class, 'pendingExitStaff']);

  Route::post('/check-staff-id-exists', [ManageStaff::class, 'checkStaffIdExists'])->name('checkStaffIdExists');
  Route::post('/check-staff-id-exists-edit', [ManageStaff::class, 'checkStaffIdExistsEdit'])->name('checkStaffIdExistsEdit');

  Route::get('/staff', [ManageStaff::class, 'List'])->name('staff');
  Route::post('/staff_status/{id}', [ManageStaff::class, 'Status']);
  Route::delete('/staff_delete/{id}', [ManageStaff::class, 'Delete']);
  Route::get('/get_per_hour_cost_staff', [ManageStaff::class, 'get_per_hour_cost_staff'])->name('get_per_hour_cost_staff');
  Route::post('/check-staff-mobile-exists', [ManageStaff::class, 'checkStaffMobileExists'])->name('checkStaffMobileExists');
  Route::post('/checkunique_mobile_edit', [ManageStaff::class, 'checkStaffMobileExists_edit'])->name('checkunique_mobile_edit');
  Route::post('/checkunique_user_name', [ManageStaff::class, 'checkunique_user_name'])->name('checkunique_user_name');
  Route::post('/checkunique_user_name_edit', [ManageStaff::class, 'checkunique_user_name_edit'])->name('checkunique_user_name_edit');
  // upload temp
  Route::post('/upload-temp-documentstaff', [ManageStaff::class, 'uploadTempDocument'])->name('upload-temp-documentstaff');
  Route::post('/delete-temp-documentstaff', [ManageStaff::class, 'deleteTempDocument'])->name('delete-temp-documentstaff');
  Route::post('/update_welcome_status', [ManageStaff::class, 'UpdateWelcomeStatus'])->name('update_welcome_status');

  Route::get('/get_staff_by_id', [ManageStaff::class, 'staffDataById'])->name('get_staff_by_id');
  Route::post('/departure_staff', [ManageStaff::class, 'Departure_staff'])->name('departure_staff');

  Route::post('/add_caste_list', [ManageStaff::class, 'AddCasteSetting'])->name('add_caste_list');

  // Manage Attendance
  Route::get('/hr_enroll/manage_attendance', [ManageAttendance::class, 'index'])->name('hrm-hr-management-enroll-manage-attendance');
  Route::get('/staff_att', [ManageAttendance::class, 'getStaff'])->name('staff_att');
  Route::get('/get_staff_attendance_by_date', [ManageAttendance::class, 'getStaffAttendanceByDate'])->name('get_staff_attendance_by_date');
  Route::post('/staff_attendance', [ManageAttendance::class, 'Add'])->name('staff_attendance');
  Route::post('/update_staff_attendance', [ManageAttendance::class, 'Update'])->name('update_staff_attendance');
  Route::get('/get_month_staff_attendance_by_id', [ManageAttendance::class, 'getMonthStaffAttendanceById'])->name('get_month_staff_attendance_by_id');

  Route::post('/upload_essl', [ManageAttendance::class, 'UploadEssl'])->name('upload_essl');


  // 29-01-26
  Route::post('/fetchStaffMonthlyAttendance', [ManageAttendance::class, 'fetchStaffMonthlyAttendance'])->name('fetchStaffMonthlyAttendance');
  Route::post('/fetchIndividualStaffAttendance', [ManageAttendance::class, 'fetchIndividualStaffAttendance'])->name('fetchIndividualStaffAttendance');


  Route::get('/staff_attendance_chart', [ManageAttendance::class, 'GetAttendanceChartData'])->name('staff_attendance_chart');
  Route::get('/staff_attendance_chart_present', [ManageAttendance::class, 'GetAttendanceChartDataPresent'])->name('staff_attendance_chart_present');
  Route::post('/ViewAttendanceDate', [ManageAttendance::class, 'ViewAttendanceDate'])->name('ViewAttendanceDate');
  Route::post('/ViewAttendanceDashboard', [ManageAttendance::class, 'ViewAttendanceDashboard'])->name('ViewAttendanceDashboard');

  // Route::get('/leave-preview', [ManageAttendance::class, 'leavePreview'])->name('leave.preview');
  Route::get('/leave-matrix', [ManageAttendance::class, 'leaveMatrix'])->name('leave.matrix');
  Route::get('/leave-history', [ManageAttendance::class, 'leaveHistory'])->name('leave.history');
  Route::get('/late-matrix', [ManageAttendance::class, 'LateMatrix'])->name('late.matrix');
  Route::get('/late-history', [ManageAttendance::class, 'LateHistory'])->name('late.history');

  Route::get('/payroll/employee-structure/{id}', [ManageStaff::class, 'getEmployeeStructure']);
  Route::get('/get-company-staff', [ManageStaff::class, 'getCompanyStaff']);
  Route::post('/bulk-update-staff-id', [ManageStaff::class, 'bulkUpdateStaffId']);





/*
|--------------------------------------------------------------------------
| CUG Management
|--------------------------------------------------------------------------
*/
Route::get('/cug-management', [CugManagementController::class, 'index'])->name('cug-management-index');
Route::get('/cug-management/dashboard', [CugManagementController::class, 'dashboard'])->name('cug.management.dashboard');
Route::get('/cug-management/datatable', [CugManagementController::class, 'datatable'])->name('cug.management.datatable');
Route::get('/cug-management/recent-activity', [CugManagementController::class, 'recentActivity'])->name('cug.management.recent-activity');

Route::get('/cug-management/lookup/companies', [CugManagementController::class, 'companies'])->name('cug.management.companies');
Route::get('/cug-management/lookup/entities', [CugManagementController::class, 'entities'])->name('cug.management.entities');
Route::get('/cug-management/lookup/branches', [CugManagementController::class, 'branches'])->name('cug.management.branches');
Route::get('/cug-management/lookup/staff/search', [CugManagementController::class, 'staffSearch'])->name('cug.management.staff.search');
Route::get('/cug-management/lookup/branch-staff/search', [CugManagementController::class, 'branchStaffSearch'])->name('cug.management.branch-staff.search');
Route::get('/cug-management/lookup/staff/{id}', [CugManagementController::class, 'staffShow'])->whereNumber('id')->name('cug.management.staff.show');

Route::post('/cug-management/assign', [CugManagementController::class, 'assign'])->name('cug.management.assign');
Route::post('/cug-management/change-staff', [CugManagementController::class, 'changeStaff'])->name('cug.management.change-staff');
Route::post('/cug-management', [CugManagementController::class, 'store'])->name('cug.management.store');

Route::post('/cug-management/{id}/release', [CugManagementController::class, 'release'])->whereNumber('id')->name('cug.management.release');
Route::post('/cug-management/{id}/deactivate', [CugManagementController::class, 'deactivate'])->whereNumber('id')->name('cug.management.deactivate');
Route::post('/cug-management/{id}/delete', [CugManagementController::class, 'destroy'])->whereNumber('id')->name('cug.management.delete');

Route::get('/cug-management/{id}/assignment-history', [CugManagementController::class, 'assignmentHistory'])->whereNumber('id')->name('cug.management.assignment-history');
Route::get('/cug-management/{id}/call-history', [CugManagementController::class, 'callHistory'])->whereNumber('id')->name('cug.management.call-history');
Route::get('/cug-management/{id}', [CugManagementController::class, 'show'])->whereNumber('id')->name('cug.management.show');
Route::put('/cug-management/{id}', [CugManagementController::class, 'update'])->whereNumber('id')->name('cug.management.update');


// CallerPilot Monitor
  Route::get('/manage_calls', [CallerPilotMoniter::class, 'index'])->name('cug-management-manage-calls');
  Route::get('/get-call-history', [CallerPilotMoniter::class, 'getCallHistory'])->name('get_call_history');
  Route::get('/get_staff_call_history', [CallerPilotMoniter::class, 'staffCallHistory'])->name('get_staff_call_history');

  Route::get('/cug_monitor', [CallerPilotMoniter::class,'cugIndex'])->name('cug-management-cug-monitor');
  Route::get('/ajax/cug-monitor/list',[CallerPilotMoniter::class,'cugStaffList'])->name('ajax.cug.monitor.list');
  Route::get('/ajax/cug-monitor/departments',[CallerPilotMoniter::class,'cugDepartments'])->name('ajax.cug.monitor.departments');
  Route::get('/get-call-locations/{id}', [CallerPilotMoniter::class, 'getMonthStaffLocations']);

  Route::get('/call_location_tracker', [CallerPilotMoniter::class,'locationTrackerIndex'])->name('cug-management-cug-loaction-monitor');
  Route::get('/call_location_tracker/data', [CallerPilotMoniter::class,'locationTrackerData'])->name('call.location.tracker.data');
  Route::get('/call_location_tracker/staff', [CallerPilotMoniter::class,'locationTrackerStaff'])->name('call.location.tracker.staff');


// Accounts & Finance
// Expense Log
  
      /*
|--------------------------------------------------------------------------
| Accounts & Finance - Expenditure
|--------------------------------------------------------------------------
*/

Route::get('/accounts_finance/expenditure', [ExpenseController::class, 'index'])->name('accounts-finance-expenditure');
Route::get('/accounts_finance/expenditure/dashboard', [ExpenseController::class, 'dashboard'])->name('accounts.expenditure.dashboard');
Route::get('/accounts_finance/expenditure/dashboard/cards', [ExpenseController::class, 'dashboardCards'])->name('accounts.expenditure.dashboard.cards');
Route::get('/accounts_finance/expenditure/companies', [ExpenseController::class, 'companies'])->name('accounts.expenditure.companies');
Route::get('/accounts_finance/expenditure/entities', [ExpenseController::class, 'entities'])->name('accounts.expenditure.entities');
Route::get('/accounts_finance/expenditure/categories', [ExpenseController::class, 'categories'])->name('accounts.expenditure.categories');
Route::get('/accounts_finance/expenditure/products', [ExpenseController::class, 'products'])->name('accounts.expenditure.products');
Route::get('/accounts_finance/expenditure/credit-cards', [ExpenseController::class, 'creditCards'])->name('accounts.expenditure.credit.cards');
Route::get('/accounts_finance/expenditure/chart/monthly', [ExpenseController::class, 'monthlyChart'])->name('accounts.expenditure.chart.monthly');
Route::get('/accounts_finance/expenditure/chart/category', [ExpenseController::class, 'categoryChart'])->name('accounts.expenditure.chart.category');
Route::get('/accounts_finance/expenditure/chart/product', [ExpenseController::class, 'productChart'])->name('accounts.expenditure.chart.product');
Route::get('/accounts_finance/expenditure/timeline', [ExpenseController::class, 'timeline'])->name('accounts.expenditure.timeline');
Route::get('/accounts_finance/expenditure/datatable', [ExpenseController::class, 'datatable'])->name('accounts.expenditure.datatable');

Route::post('/add_creditcard_expense_log', [ExpenseController::class, 'store'])->name('accounts.expenditure.store');
Route::get('/accounts_finance/expenditure/{expense}', [ExpenseController::class, 'show'])->name('accounts.expenditure.show');
Route::get('/accounts_finance/expenditure/{expense}/edit', [ExpenseController::class, 'edit'])->name('accounts.expenditure.edit');
Route::post('/update_creditcard_expense_log/{expense}/', [ExpenseController::class, 'update'])->name('accounts.expenditure.update');
Route::post('/delete_creditcard_expense_log/{expense}/', [ExpenseController::class, 'destroy'])->name('accounts.expenditure.destroy');
Route::post('/accounts_finance/expenditure/{expense}/duplicate', [ExpenseController::class, 'duplicate'])->name('accounts.expenditure.duplicate');
Route::get('/accounts_finance/expenditure/{expense}/history', [ExpenseController::class, 'history'])->name('accounts.expenditure.history');
Route::post('/accounts_finance/expenditure/bulk/delete', [ExpenseController::class, 'bulkDelete'])->name('accounts.expenditure.bulk.delete');
Route::post('/accounts_finance/expenditure/bulk/export', [ExpenseController::class, 'bulkExport'])->name('accounts.expenditure.bulk.export');

// expense Paythrough
Route::get('/expense_paythrough_list', [ExpenseController::class, 'payThrough'])->name('expense.paythrough.list');
Route::post('/accounts/expenditure/paythrough_store', [ExpenseController::class, 'payThroughStore'])->name('accounts.expenditure.paythrough.store');
Route::get('/accounts/expenditure/paythrough/{id}', [ExpenseController::class, 'payThroughShow'])->name('accounts.expenditure.paythrough.show');
Route::post('/accounts/expenditure/paythrough/{id}', [ExpenseController::class, 'payThroughUpdate'])->name('accounts.expenditure.paythrough.update');
Route::delete('/accounts/expenditure/paythrough/{id}', [ExpenseController::class, 'payThroughDestroy'])->name('accounts.expenditure.paythrough.destroy');


// Expense Category
Route::post('/accounts/expenditure/categories', [ExpenseController::class, 'categoryStore'])->name('accounts.expenditure.categories.store');

Route::get('/accounts/expenditure/categories/{id}', [ExpenseController::class, 'categoryShow'])
    ->name('accounts.expenditure.categories.show');

Route::post('/accounts/expenditure/categories/{id}', [ExpenseController::class, 'categoryUpdate'])
    ->name('accounts.expenditure.categories.update');

Route::delete('/accounts/expenditure/categories/{id}', [ExpenseController::class, 'categoryDestroy'])
    ->name('accounts.expenditure.categories.destroy');


    // Expense Product
Route::post('/accounts/expenditure/products', [ExpenseController::class, 'storeProduct'])->name('accounts.expenditure.products.store');

Route::get('/accounts/expenditure/products/{id}', [ExpenseController::class, 'showProduct'])
    ->name('accounts.expenditure.products.show');

Route::post('/accounts/expenditure/products/{id}', [ExpenseController::class, 'updateProduct'])
    ->name('accounts.expenditure.products.update');

Route::delete('/accounts/expenditure/products/{id}', [ExpenseController::class, 'destroyProduct'])
    ->name('accounts.expenditure.products.destroy');
Route::get('/accounts/expenditure/products_list',[ExpenseController::class, 'productList'])->name('accounts.expenditure.products_list');

// manage recurring
Route::get('/accounts_finance/manage_recurring',[ExpenseController::class, 'recurringIndex'])->name('accounts-finance-recurring');
Route::get('/accounts_finance/recurring',[ExpenseController::class, 'recurringList'])->name('accounts.recurringlist');
Route::get('/accounts_finance/recurring/{id}',[ExpenseController::class, 'recurringShow'])->name('accounts-finance-recurring.show');
Route::get('/accounts_finance/recurring/products/{id}/recurring-logs', [ExpenseController::class, 'productRecurringLogs'])->name('accounts.products.recurring.logs');
Route::post('/accounts_finance/recurring/products/{id}/recurring/stop',[ExpenseController::class, 'stopRecurring'])->name('accounts.products.recurring.stop');
Route::post('/accounts_finance/recurring/{id}/drop',[ExpenseController::class, 'dropRecurring'])->name('accounts-finance-recurring.drop');
Route::get('/recurring_tab_counts',[ExpenseController::class, 'recurringTabCounts'])->name('accounts_finance.recurring.counts');

Route::get('/accounts_finance/credit_card', [CreditCardController::class, 'index'])->name('accounts-finance-credit-card');
Route::get('/accounts_finance/credit_card/dashboard', [CreditCardController::class, 'dashboard'])->name('accounts.creditcard.dashboard');
Route::get('/accounts_finance/credit_card/dashboard/cards', [CreditCardController::class, 'dashboardCards'])->name('accounts.creditcard.dashboard.cards');
Route::get('/accounts_finance/credit_card/companies', [CreditCardController::class, 'creditCardCompanies'])->name('accounts.creditcard.companies');
Route::get('/accounts_finance/credit_card/entities', [CreditCardController::class, 'entities'])->name('accounts.creditcard.entities');
Route::get('/accounts_finance/credit_card/categories', [CreditCardController::class, 'categories'])->name('accounts.creditcard.categories');
Route::get('/accounts_finance/credit_card/products', [CreditCardController::class, 'products'])->name('accounts.creditcard.products');
Route::get('/accounts_finance/credit_card/credit-cards', [CreditCardController::class, 'creditCards'])->name('accounts.creditcard.credit.cards');
Route::get('/accounts_finance/credit_card/chart/monthly', [CreditCardController::class, 'monthlyChart'])->name('accounts.creditcard.chart.monthly');
Route::get('/accounts_finance/credit_card/chart/category', [CreditCardController::class, 'categoryChart'])->name('accounts.creditcard.chart.category');
Route::get('/accounts_finance/credit_card/chart/product', [CreditCardController::class, 'productChart'])->name('accounts.creditcard.chart.product');
Route::get('/accounts_finance/credit_card/timeline', [CreditCardController::class, 'timeline'])->name('accounts.creditcard.timeline');
Route::get('/accounts_finance/credit_card/datatable', [CreditCardController::class, 'datatable'])->name('accounts.creditcard.datatable');

Route::post('/add_creditcard', [CreditCardController::class, 'creditCardStore'])->name('accounts.creditcard.store');
Route::get('/accounts_finance/credit-cards/{id}', [CreditCardController::class, 'creditCardShow'])->name('accounts.creditcard.show');
Route::get('/accounts_finance/credit_card/{expense}/edit', [CreditCardController::class, 'edit'])->name('accounts.creditcard.edit');
Route::post('/update_creditcard/credit-cards/{id}', [CreditCardController::class, 'creditCardUpdate'])->name('accounts.creditcard.update');
Route::post('/delete_creditcard/credit-cards/{id}', [CreditCardController::class, 'destroy'])->name('accounts.creditcard.destroy');
Route::post('/accounts_finance/credit_card/{expense}/duplicate', [CreditCardController::class, 'duplicate'])->name('accounts.creditcard.duplicate');
Route::get('/accounts_finance/credit_card/{expense}/history', [CreditCardController::class, 'history'])->name('accounts.creditcard.history');
Route::post('/accounts_finance/credit_card/bulk/delete', [CreditCardController::class, 'bulkDelete'])->name('accounts.creditcard.bulk.delete');
Route::post('/accounts_finance/credit_card/bulk/export', [CreditCardController::class, 'bulkExport'])->name('accounts.creditcard.bulk.export');
Route::post('/creadit_card_update_status/{id}', [CreditCardController::class, 'Status']);
Route::delete('/creadit_card_delete/{id}', [CreditCardController::class, 'Delete']);







Route::get('myself/manage-passcode', [PasscodeController::class, 'index'])->name('my-self-manage-passcode');
Route::get('myself/manage-passcode/list',[PasscodeController::class, 'list'])->name('myself.manage.passcode.list');
Route::post('myself/manage-passcode/store',[PasscodeController::class, 'store'])->name('myself.manage.passcode.store');
Route::get('myself/manage-passcode/edit/{id}',[PasscodeController::class, 'edit'])->name('myself.manage.passcode.edit');
Route::put('myself/manage-passcode/update/{id}',[PasscodeController::class, 'update'])->name('myself.manage.passcode.update');
Route::post('myself/manage-passcode/reveal/{id}',[PasscodeController::class, 'reveal'])->name('myself.manage.passcode.reveal');
Route::post('myself/manage-passcode/status/{id}',[PasscodeController::class, 'status'])->name('myself.manage.passcode.status');
Route::delete('myself/manage-passcode/delete/{id}',[PasscodeController::class, 'destroy'])->name('myself.manage.passcode.delete');
 



  // Onboarding Staff
  Route::get('/hr_enroll/onboarding_staff', [OnboardingStaff::class, 'index'])->name('hrm-hr-management-recruitment-onboarding-staff');

  // Recruitment Setting
  // ApplicantStatus
  Route::get('/settings/applicant_status', [ApplicantStatus::class, 'index'])->name('settings-recruitment');
  Route::get('/applicant_status', [ApplicantStatus::class, 'List'])->name('applicant_status');
  Route::post('/add_applicant_status', [ApplicantStatus::class, 'Add'])->name('add_applicant_status');
  Route::get('/applicant_status_edit/{id}', [ApplicantStatus::class, 'Edit'])->name('applicant_status_edit');
  Route::post('/applicant_status_update', [ApplicantStatus::class, 'Update'])->name('applicant_status_update');
  Route::delete('/applicant_status_delete/{id}', [ApplicantStatus::class, 'Delete']);
  Route::post('/applicant_status_change/{id}', [ApplicantStatus::class, 'Status']);

  // Qualification
  Route::get('/settings/qualification', [Qualification::class, 'index'])->name('settings-recruitment');
  Route::get('/qualification', [Qualification::class, 'List'])->name('qualification');
  Route::post('/add_qualification', [Qualification::class, 'Add'])->name('add_qualification');
  Route::get('/qualification_edit/{id}', [Qualification::class, 'Edit'])->name('qualification_edit');
  Route::post('/qualification_update', [Qualification::class, 'Update'])->name('qualification_update');
  Route::delete('/qualification_delete/{id}', [Qualification::class, 'Delete']);
  Route::post('/qualification_status_change/{id}', [Qualification::class, 'Status']);

  // Qualification Level
  Route::get('/settings/qualification_level', [QualificationLevel::class, 'index'])->name('settings-recruitment');
  Route::get('/qualification_level', [QualificationLevel::class, 'List'])->name('qualification_level');
  Route::post('/add_qualification_level', [QualificationLevel::class, 'Add'])->name('add_qualification_level');
  Route::get('/qualification_level_edit/{id}', [QualificationLevel::class, 'Edit'])->name('qualification_level_edit');
  Route::post('/qualification_level_update', [QualificationLevel::class, 'Update'])->name('qualification_level_update');
  Route::delete('/qualification_level_delete/{id}', [QualificationLevel::class, 'Delete']);
  Route::post('/qualification_level_status_change/{id}', [QualificationLevel::class, 'Status']);

  // Qualification Level
  Route::get('/settings/major', [Major::class, 'index'])->name('settings-recruitment');
  Route::get('/major_list', [Major::class, 'List'])->name('major_list');
  Route::post('/add_major', [Major::class, 'Add'])->name('add_major');
  Route::get('/major_edit/{id}', [Major::class, 'Edit'])->name('major_edit');
  Route::post('/major_update', [Major::class, 'Update'])->name('major_update');
  Route::delete('/major_delete/{id}', [Major::class, 'Delete']);
  Route::post('/major_status_change/{id}', [Major::class, 'Status']);

  // Source
  Route::get('/settings/source', [Source::class, 'index'])->name('settings-recruitment');
  Route::get('/source_list', [Source::class, 'List'])->name('source_list');
  Route::post('/add_source', [Source::class, 'Add'])->name('add_source');
  Route::get('/source_edit/{id}', [Source::class, 'Edit'])->name('source_edit');
  Route::post('/source_update', [Source::class, 'Update'])->name('source_update');
  Route::delete('/source_delete/{id}', [Source::class, 'Delete']);
  Route::post('/source_status_change/{id}', [Source::class, 'Status']);


  // Documents Setting Start
  Route::get('/settings/shift_time', [ShiftTime::class, 'index'])->name('settings-hrm');
  Route::post('/add_shift_time', [ShiftTime::class, 'Add'])->name('add_shift_time');
  Route::get('/shift-edit/{id}', [ShiftTime::class, 'Edit']);
  Route::post('/update_shift_time', [ShiftTime::class, 'Update'])->name('update_shift_time');
  Route::delete('/shift_time_delete/{id}', [ShiftTime::class, 'Delete'])->name('shift_time_delete');
  Route::post('/shift_time_status_change/{id}', [ShiftTime::class, 'Status'])->name('shift_time_status_change');
  Route::get('/shift_time_list', [ShiftTime::class, 'List'])->name('shift_time_list');

  Route::get('/get-shift-detail/{id}', [ShiftTime::class, 'getShiftDetail']);


  Route::post('/assign-shift', [ShiftTime::class, 'assignShift'])->name('assign_shift');
  // Documents Setting End

  // Leave & Permsiison
  Route::get('/hr_operation/leave_permission', [HROperation::class, 'index'])->name('hrm-hr-management-operation-leave-permission');
  Route::post('/add_leave_perm_request', [HROperation::class, 'AddLeavePermission'])->name('add_leave_perm_request');
  Route::get('/get_staff_by_branch', [HROperation::class, 'getStaffByBranch'])->name('get_staff_by_branch');
  Route::get('/get_staff_by_role', [HROperation::class, 'getStaffByRole'])->name('get_staff_by_role');
  Route::get('/get_staff_by_depart', [HROperation::class, 'getStaffByDepart'])->name('get_staff_by_depart');
  Route::post('/approval_matrix_save', [HROperation::class, 'save'])->name('approval_matrix_save');
  Route::get('/get_role_by_department', [HROperation::class, 'get_role_by_department'])->name('get_role_by_department');
  Route::get('/get-leave-approval-chain', [HROperation::class, 'getLeaveApprovalChain'])
    ->name('get_leave_approval_chain');
  Route::get('/get_staff_leave_details', [HROperation::class, 'StaffDetails'])->name('get_staff_leave_details');
  // web.php
  Route::post('/hr_operation/leave_permission/update-status', [HROperation::class, 'updateStatus']);
  Route::get('/hr_operation/leave_permission/get-approval-levels', [HROperation::class, 'getApprovalLevels']);
  // Myself Leave & Permsiison
  Route::get('/my_self/leave_permission', [HROperation::class, 'indexMyself'])->name('my-self-leave-permission');
  Route::post('/add_leave_perm_request_my', [HROperation::class, 'AddLeavePermissionMyself'])->name('add_leave_perm_request_my');


  // Leave & Permsiison
  Route::get('/it_support/tickets', [ItSupports::class, 'index'])->name('hrm-hr-management-operation-leave-permission');
  Route::post('/assign_it_staff', [ItSupports::class, 'assignItStaff']);
  Route::post('/ticket_status_change', [ItSupports::class, 'changeStatusTicket']);
  Route::get('/it-support/timeline/{id}', [ItSupports::class, 'timeline']);



  // Myself It Ticket
  Route::get('/my_self/it_support', [ItSupports::class, 'indexMyself'])->name('my-self-it-support');
  Route::get('/it-support/view/{id}', [ItSupports::class, 'viewTicket'])->name('my-self-it-support');
  Route::post('/add_it_ticket_myself', [ItSupports::class, 'AddItTicketMyself'])->name('add_it_ticket_myself');
  Route::get('it-support/chat/{id}', [ItSupports::class, 'chat']);
  Route::post('it-support/chat/send', [ItSupports::class, 'sendMessage']);


  Route::get('/manage_tickets', [ItSupports::class, 'manageTicketList'])->name('my-self-manage-tickets');
  Route::get('/support/view-ticket/{id}',[ItSupports::class,'viewManageTicket'])->name('support.ticket.view');
  Route::get('/support/ticket/{id}/assign', [ItSupports::class,'assignTicketData'])->name('support.ticket.assign.data');
  Route::post('/support/ticket/assign', [ItSupports::class,'assignTicket'])->name('support.ticket.assign');
  Route::post('/support/reply-ticket',[ItSupports::class,'replyTicket'])->name('support.reply.ticket');

  Route::get('/support/category/{department}', [ItSupports::class, 'getCategory']);
  Route::post('/support/store', [ItSupports::class, 'store'])->name('support.store');
  Route::get('/my_self/support/view/{id}', [ItSupports::class,'viewTicketDetail'])->name('my_self.support.view');

  Route::get(
    '/my_self/support/messages/{ticket}',
    [ItSupports::class,'ticketMessages']
)->name('my_self.support.messages');



  // Manage Exam
  Route::match(['get', 'post'], '/manage_exam', [ManageExam::class, 'index'])->name('hrm-hr-management-assessment-manage-exam');
  Route::get('/manage_exam/add', [ManageExam::class, 'showCreateExam'])->name('hrm-hr-management-assessment-manage-exam');
  Route::get('/fetch_job_roles', [ManageExam::class, 'fetchJobRoles']);
  Route::post('/manage_exam/create', [ManageExam::class, 'Create'])->name('manage_exam_create');
  Route::get('/edit_manage_exam/{id}', [ManageExam::class, 'Edit']);
  Route::get('/view_manage_exam/{id}', [ManageExam::class, 'View'])->name('hrm-hr-management-assessment-manage-exam');
  Route::post('/manage_exam/update', [ManageExam::class, 'Update'])->name('manage_exam_update');
  Route::post('/status_manage_exam/{id}', [ManageExam::class, 'Status']);
  Route::get('/level_based_exam_questions', [ManageExam::class, 'levelBasedQuestion']);
  Route::get('/fetch_question_bank_name/{id}', [ManageExam::class, 'fetchQuestionBankName']);
  Route::get('/edit_level_based_exam_questions/{sno}', [ManageExam::class, 'editLevelQuestions']);
  Route::get('/check-exam-process/{id}', [ManageExam::class, 'checkExamProcess']);
  Route::delete('/delete-exam/{id}', [ManageExam::class, 'Delete']);

  // Exam Question Bank
  Route::match(['get', 'post'], '/question-bank', [ManageQuestionBank::class, 'index'])->name('hrm-hr-management-assessment-manage-question-bank');
  Route::post('/question_bank_status/{id}', [ManageQuestionBank::class, 'Status']);
  Route::get('/question-bank/view/{id}', [ManageQuestionBank::class, 'View'])->name('hrm-hr-management-assessment-manage-question-bank');
  Route::get('/question-bank/edit/{id}', [ManageQuestionBank::class, 'Edit']);
  Route::post('/add_quesion_bank', [ManageQuestionBank::class, 'Add'])->name('add_quesion_bank');
  Route::post('/edit_quesion_bank', [ManageQuestionBank::class, 'Update'])->name('edit_quesion_bank');
  Route::post('/add_quesions', [ManageQuestionBank::class, 'AddQuestion'])->name('add_quesions');
  Route::post('/update_quesions', [ManageQuestionBank::class, 'UpdateQuestion'])->name('update_quesions');

  Route::get('/question-bank/section_add/{id}', [ManageQuestionBank::class, 'question_add'])->name('hrm-hr-management-assessment-manage-question-bank');
  Route::get('/question-bank/section_edit/{id}', [ManageQuestionBank::class, 'question_edit'])->name('hrm-hr-management-assessment-manage-question-bank');
  Route::post('/questions_import', [ManageQuestionBank::class, 'ImportQuestion'])->name('questions_import');
  // Manage assesment  
  Route::match(['get', 'post'], '/manage-assessments', [ManageAssessment::class, 'index'])->name('hrm-hr-management-assessment-manage-assessments');
  Route::get('/manage-assessments/write_exam/{id}', [ManageAssessment::class, 'write_exam'])->name('hrm-hr-management-assessment-manage-assessments');
  Route::post('/save-exam-answer', [ManageAssessment::class, 'saveAnswer'])->name('saveExamAnswer');
  Route::post('/save-exam-answer-complete', [ManageAssessment::class, 'saveAnswerComplete'])->name('saveAnswerComplete');
  Route::post('/time-out', [ManageAssessment::class, 'TimeOut'])->name('timeout');

  Route::post('/exam-time-save', [ManageAssessment::class, 'ExamTimeSave'])->name('exam-time-save');
  Route::post('/exam/get-question-statuses', [ManageAssessment::class, 'getQuestionStatuses'])->name('examgetQuestionStatuses');
  Route::get('/exam-result/{id}', [ManageAssessment::class, 'view_result'])->name('hrm-hr-management-assessment-manage-assessments');

  Route::get('/staff-assessment-certificate/{id}', [ManageAssessment::class, 'assesment_certificate'])->name('staff-assessment-certificate');
  Route::get('/assesment_certificate_preview/{id}', [ManageAssessment::class, 'assesment_certificate_preview'])->name('assesment_certificate_preview');
  Route::get('/staff_certificate_send/{id}', [ManageAssessment::class, 'staff_certificate_send'])->name('staff_certificate_send');

  // Manage Result
  Route::match(['get', 'post'], '/manage-result', [ManageResult::class, 'index'])->name('hrm-hr-management-assessment-manage-result');
  Route::match(['get', 'post'], '/staff-exam-report/{id}', [ManageResult::class, 'view_report'])->name('hrm-hr-management-assessment-manage-result');
  Route::post('/exam-limit-increase', [ManageResult::class, 'store_limit'])->name('exam.limit.increase');
  Route::post('/exam-process-delete', [ManageResult::class, 'exam_process_delete'])->name('exam-process-delete');

  Route::post('/next-attempt-schedule', [ManageAssessment::class, 'NextSchudule'])->name('next-attempt-schedule');
  Route::post('/exam-badge-claim', [ManageAssessment::class, 'BadgeClaim'])->name('exam-badge-claim');

  Route::get('/exam_log/{id}', [ManageAssessment::class, 'exam_log']);
  Route::post('ids/encrypt', [ManageAssessment::class, 'encrypt_ids'])->name('ids/encrypt');


  // Trainning Planner
  Route::match(['get', 'post'], '/hr_training/training_planner', [TrainingPlanner::class, 'index'])->name('hrm-hr-management-operation-manage-training-planner');
  Route::post('/training_filter_manage', [TrainingPlanner::class, 'list_filter'])->name('training_filter_manage');
  Route::get('/training_view_manage/{id}', [TrainingPlanner::class, 'View']);

  // Main Training Planner
//   Route::get('/hr_training/manage_training', [ManageTraining::class, 'index'])
//     ->name('hrm-hr-management-operation-manage-training');

// Route::get('/training-planner/data', [ManageTraining::class, 'data'])
//     ->name('training_planner.data');

// Route::get('/training-planner/lookups', [ManageTraining::class, 'lookups'])
//     ->name('training_planner.lookups');

// Route::get('/training-planner/entities', [ManageTraining::class, 'entities'])
//     ->name('training_planner.entities');

// Route::get('/training-planner/branches', [ManageTraining::class, 'branches'])
//     ->name('training_planner.branches');

// Route::get('/training-planner/staff', [ManageTraining::class, 'staffAvailability'])
//     ->name('training_planner.staff');

// Route::get('/training-planner/staff/{staffId}/training-logs', [ManageTraining::class, 'staffTrainingLogs'])
//     ->name('training_planner.staff.training_logs');

// Route::get('/training-planner/{id}', [ManageTraining::class, 'show'])
//     ->name('training_planner.show');

// Route::post('/training-planner', [ManageTraining::class, 'store'])
//     ->name('training_planner.store');

// Route::put('/training-planner/{id}', [ManageTraining::class, 'update'])
//     ->name('training_planner.update');

// Route::post('/training-planner/conflicts', [ManageTraining::class, 'checkConflicts'])
//     ->name('training_planner.conflicts');

// Route::post('/training-planner/{id}/status', [ManageTraining::class, 'changeStatus'])
//     ->name('training_planner.status');

// Route::post('/training-planner/{id}/attendance', [ManageTraining::class, 'saveAttendance'])
//     ->name('training_planner.attendance.save');

// Route::post('/training-planner/{id}/complete', [ManageTraining::class, 'complete'])
//     ->name('training_planner.complete');

// Route::delete('/training-planner/{id}', [ManageTraining::class, 'destroy'])
//     ->name('training_planner.delete');

// Route::post('/training-planner/save-image', [ManageTraining::class, 'storeImage'])
//     ->name('training_planner.image.save');

// Route::get('/training-planner/{id}/attendees', [ManageTraining::class, 'showAttendees'])
//     ->name('training_planner.attendees');

// Route::post('/training-planner/{id}/attendees', [ManageTraining::class, 'addAttendees'])
//     ->name('training_planner.attendees.add');

// Route::delete('/training-planner/{id}/attendees/{staffId}', [ManageTraining::class, 'removeAttendee'])
//     ->name('training_planner.attendees.remove');

// Route::get('/training-planner/{id}/sessions', [ManageTraining::class, 'sessions'])
//     ->name('training_planner.sessions');

// Route::put('/training-planner/{id}/sessions/{sessionId}', [ManageTraining::class, 'updateSession'])
//     ->name('training_planner.session.update');

// Route::get('/training-planner/{id}/sessions/{sessionId}/attendance', [ManageTraining::class, 'sessionAttendance'])
//     ->name('training_planner.session.attendance');

// Route::post('/training-planner/{id}/sessions/{sessionId}/attendance', [ManageTraining::class, 'updateSessionAttendance'])
//     ->name('training_planner.session.attendance.update');

// Main Training Planner
  Route::get('/hr_training/manage_training', [ManageTraining::class, 'index'])
    ->name('hrm-hr-management-operation-manage-training');

Route::get('/training-planner/data', [ManageTraining::class, 'data'])
    ->name('training_planner.data');

Route::get('/training-planner/lookups', [ManageTraining::class, 'lookups'])
    ->name('training_planner.lookups');

Route::get('/training-planner/entities', [ManageTraining::class, 'entities'])
    ->name('training_planner.entities');

Route::get('/training-planner/branches', [ManageTraining::class, 'branches'])
    ->name('training_planner.branches');

Route::get('/training-planner/staff', [ManageTraining::class, 'staffAvailability'])
    ->name('training_planner.staff');

Route::get('/training-planner/trainer-lookups', [ManageTraining::class, 'trainerLookups'])
    ->name('training_planner.trainer.lookups');

Route::get('/training-planner/trainer-staff', [ManageTraining::class, 'trainerStaff'])
    ->name('training_planner.trainer.staff');

Route::get('/training-planner/trainers', [ManageTraining::class, 'trainers'])
    ->name('training_planner.trainers');

Route::get('/training-planner/trainers/{id}', [ManageTraining::class, 'trainerShow'])
    ->name('training_planner.trainer.show');

Route::post('/training-planner/trainers', [ManageTraining::class, 'trainerStore'])
    ->name('training_planner.trainer.store');

Route::put('/training-planner/trainers/{id}', [ManageTraining::class, 'trainerUpdate'])
    ->name('training_planner.trainer.update');

Route::post('/training-planner/trainers/{id}/status', [ManageTraining::class, 'trainerStatus'])
    ->name('training_planner.trainer.status');

Route::get('/training-planner/staff/{staffId}/training-logs', [ManageTraining::class, 'staffTrainingLogs'])
    ->name('training_planner.staff.training_logs');

Route::get('/training-planner/{id}', [ManageTraining::class, 'show'])
    ->name('training_planner.show');

Route::post('/training-planner', [ManageTraining::class, 'store'])
    ->name('training_planner.store');

Route::put('/training-planner/{id}', [ManageTraining::class, 'update'])
    ->name('training_planner.update');

Route::post('/training-planner/conflicts', [ManageTraining::class, 'checkConflicts'])
    ->name('training_planner.conflicts');

Route::post('/training-planner/{id}/status', [ManageTraining::class, 'changeStatus'])
    ->name('training_planner.status');

Route::post('/training-planner/{id}/attendance', [ManageTraining::class, 'saveAttendance'])
    ->name('training_planner.attendance.save');

Route::post('/training-planner/{id}/complete', [ManageTraining::class, 'complete'])
    ->name('training_planner.complete');

Route::delete('/training-planner/{id}', [ManageTraining::class, 'destroy'])
    ->name('training_planner.delete');

Route::post('/training-planner/save-image', [ManageTraining::class, 'storeImage'])
    ->name('training_planner.image.save');

Route::get('/training-planner/{id}/attendees', [ManageTraining::class, 'showAttendees'])
    ->name('training_planner.attendees');

Route::post('/training-planner/{id}/attendees', [ManageTraining::class, 'addAttendees'])
    ->name('training_planner.attendees.add');

Route::delete('/training-planner/{id}/attendees/{staffId}', [ManageTraining::class, 'removeAttendee'])
    ->name('training_planner.attendees.remove');

Route::get('/training-planner/{id}/sessions', [ManageTraining::class, 'sessions'])
    ->name('training_planner.sessions');

Route::put('/training-planner/{id}/sessions/{sessionId}', [ManageTraining::class, 'updateSession'])
    ->name('training_planner.session.update');

Route::get('/training-planner/{id}/sessions/{sessionId}/attendance', [ManageTraining::class, 'sessionAttendance'])
    ->name('training_planner.session.attendance');

Route::post('/training-planner/{id}/sessions/{sessionId}/attendance', [ManageTraining::class, 'updateSessionAttendance'])
    ->name('training_planner.session.attendance.update');



  // exam Setting
  // Exam Guidelines
  Route::get('/settings/assessment/guidelines', [ExamGuideLines::class, 'index'])->name('settings-exam-settings');
  Route::post('/create_guidelines', [ExamGuideLines::class, 'store'])->name('create_guidelines');

  // Exam Category
  Route::get('/settings/assessment/exam_category', [ExamCategory::class, 'index'])->name('settings-exam-settings');
  Route::post('/create_exam_category', [ExamCategory::class, 'Create'])->name('create_exam_category');
  Route::post('/status_exam_category/{id}', [ExamCategory::class, 'Status']);
  Route::delete('/delete_exam_category/{id}', [ExamCategory::class, 'Delete']);
  Route::post('/update_exam_category', [ExamCategory::class, 'Update'])->name('update_exam_category');
  Route::get('/list_exam_category', [ExamCategory::class, 'List']);

  // Exam Section
  Route::get('/settings/assessment/exam_section', [ExamSection::class, 'index'])->name('settings-exam-settings');
  Route::post('/create_exam_section', [ExamSection::class, 'Create'])->name('create_exam_section');
  Route::post('/status_exam_section/{id}', [ExamSection::class, 'Status']);
  Route::delete('/delete_exam_section/{id}', [ExamSection::class, 'Delete']);
  Route::post('/update_exam_section', [ExamSection::class, 'Update'])->name('update_exam_section');

  // Question Bank Type
  Route::get('/settings/assessment/question_bank_type', [QuestionBankType::class, 'index'])->name('settings-exam-settings');
  Route::post('/create_question_bank_type', [QuestionBankType::class, 'Create'])->name('create_question_bank_type');
  Route::post('/status_question_bank_type/{id}', [QuestionBankType::class, 'Status']);
  Route::delete('/delete_question_bank_type/{id}', [QuestionBankType::class, 'Delete']);
  Route::post('/update_question_bank_type', [QuestionBankType::class, 'Update'])->name('update_question_bank_type');

  // Exam Badge 
  Route::get('/settings/assessment/exam_badge', [ExamBadge::class, 'index'])->name('settings-exam-settings');
  Route::post('/create_exam_badge', [ExamBadge::class, 'Create'])->name('create_exam_badge');
  Route::post('/status_exam_badge/{id}', [ExamBadge::class, 'Status']);
  Route::delete('/delete_exam_badge/{id}', [ExamBadge::class, 'Delete']);
  Route::post('/update_exam_badge', [ExamBadge::class, 'Update'])->name('update_exam_badge');
  Route::get('/edit_exam_badge/{id}', [ExamBadge::class, 'Edit']);
  Route::get('/list_exam_badge', [ExamBadge::class, 'list']);


  // Job Role Schedule
  Route::get('/settings/assessment/job_role_schedule', [JobRoleSchedule::class, 'index'])->name('settings-exam-settings');
  Route::post('/create_exam_schedule', [JobRoleSchedule::class, 'Create'])->name('create_exam_schedule');
  Route::post('/status_exam_schedule/{id}', [JobRoleSchedule::class, 'Status']);
  Route::delete('/delete_job_role_schedule/{id}', [JobRoleSchedule::class, 'Delete']);
  Route::get('/edit_job_role_schedule/{id}', [JobRoleSchedule::class, 'Edit']);
  Route::get('/list_job_role_schedule', [JobRoleSchedule::class, 'list']);
  Route::post('/update_job_role_schedule', [JobRoleSchedule::class, 'Update'])->name('update_job_role_schedule');



  // OnboardingQuestion Setting Start
  Route::get('/settings/onboarding_question', [OnboardingQuestion::class, 'index'])->name('settings-hrm');
  Route::get('/settings/hrm/onboarding_question_add', [OnboardingQuestion::class, 'AddForm'])->name('settings-hrm');
  Route::get('/settings/hrm/onboarding_question_edit/{id}', [OnboardingQuestion::class, 'edit'])->name('settings-hrm');
  Route::post('/add_onboarding_question', [OnboardingQuestion::class, 'Add'])->name('add_onboarding_question');
  Route::post('/add_new_onboarding_question', [OnboardingQuestion::class, 'AddNew'])->name('add_new_onboarding_question');
  Route::post('/onboarding_question_update', [OnboardingQuestion::class, 'Update'])->name('onboarding_question_update');
  Route::delete('/onboarding_question_delete/{id}', [OnboardingQuestion::class, 'Delete'])->name('onboarding_question_delete');
  Route::post('/onboarding_question_status_change/{id}', [OnboardingQuestion::class, 'Status'])->name('onboarding_question_status_change');
  Route::get('/onboarding_question_list', [OnboardingQuestion::class, 'List'])->name('onboarding_question_list');
  Route::get('/job_role_list_by_onboarding_category', [OnboardingQuestion::class, 'JobRoleListByCategory'])->name('job_role_list_by_onboarding_category');
  Route::get('/job_role_list_by_onboarding_category_edit', [OnboardingQuestion::class, 'JobRoleListByCategoryEdit'])->name('job_role_list_by_onboarding_category_edit');
  Route::get('/onboarding_question_list_by_role', [OnboardingQuestion::class, 'onboardingListByRole'])->name('onboarding_question_list_by_role');
  // OnboardingQuestion Setting End



    Route::get('/security/staff-password/{staffId}',[SecurityController::class,'staffPassword']);

  // Interview Setting
  // InterviewMode Setting Start
  Route::get('/settings/interview_mode', [InterviewMode::class, 'index'])->name('settings-interview');
  Route::post('/add_interview_mode', [InterviewMode::class, 'Add'])->name('add_interview_mode');
  Route::get('/interview_mode_edit', [InterviewMode::class, 'Edit'])->name('interview_mode_edit');
  Route::post('/interview_mode_update', [InterviewMode::class, 'Update'])->name('interview_mode_update');
  Route::delete('/interview_mode_delete/{id}', [InterviewMode::class, 'Delete'])->name('interview_mode_delete');
  Route::post('/interview_mode_status_change/{id}', [InterviewMode::class, 'Status'])->name('interview_mode_status_change');
  Route::get('/interview_mode_list', [InterviewMode::class, 'List'])->name('interview_mode_list');
  // InterviewMode Setting End

  // InterviewCategory Setting Start
  Route::get('/settings/interview_category', [InterviewCategory::class, 'index'])->name('settings-hrm');
  Route::post('/add_interview_category', [InterviewCategory::class, 'Add'])->name('add_interview_category');
  Route::get('/interview_category_edit', [InterviewCategory::class, 'Edit'])->name('interview_category_edit');
  Route::post('/interview_category_update', [InterviewCategory::class, 'Update'])->name('interview_category_update');
  Route::delete('/interview_category_delete/{id}', [InterviewCategory::class, 'Delete'])->name('interview_category_delete');
  Route::post('/interview_category_status_change/{id}', [InterviewCategory::class, 'Status'])->name('interview_category_status_change');
  Route::get('/interview_category_list', [InterviewCategory::class, 'List'])->name('interview_category_list');
  // InterviewCategory Setting End

  // InterviewQuestion Setting Start
  Route::get('/settings/interview_question', [InterviewQuestion::class, 'index'])->name('settings-interview');
  Route::get('/settings/intreview/intreview_question_add', [InterviewQuestion::class, 'AddForm'])->name('settings-interview');
  Route::get('/settings/intreview/intreview_question_edit/{id}', [InterviewQuestion::class, 'edit'])->name('settings-interview');
  Route::post('/add_interview_question', [InterviewQuestion::class, 'Add'])->name('add_interview_question');
  Route::post('/add_new_interview_question', [InterviewQuestion::class, 'AddNew'])->name('add_new_interview_question');
  Route::post('/interview_question_update', [InterviewQuestion::class, 'Update'])->name('interview_question_update');
  Route::delete('/interview_question_delete/{id}', [InterviewQuestion::class, 'Delete'])->name('interview_question_delete');
  Route::post('/interview_question_status_change/{id}', [InterviewQuestion::class, 'Status'])->name('interview_question_status_change');
  Route::get('/interview_question_list', [InterviewQuestion::class, 'List'])->name('interview_question_list');
  Route::get('/job_role_list_by_interview_category', [InterviewQuestion::class, 'JobRoleListByCategory'])->name('job_role_list_by_interview_category');
  Route::get('/job_role_list_by_interview_category_edit', [InterviewQuestion::class, 'JobRoleListByCategoryEdit'])->name('job_role_list_by_interview_category_edit');
  Route::get('/interview_question_list_by_role', [InterviewQuestion::class, 'InterviewListByRole'])->name('interview_question_list_by_role');
  // InterviewQuestion Setting End

  // FeedbackSection Setting Start
  Route::get('/settings/feedback_section', [FeedbackSection::class, 'index'])->name('settings-hrm');
  Route::post('/add_feedback_section', [FeedbackSection::class, 'Add'])->name('add_feedback_section');
  Route::get('/feedback_section_edit', [FeedbackSection::class, 'Edit'])->name('feedback_section_edit');
  Route::post('/feedback_section_update', [FeedbackSection::class, 'Update'])->name('feedback_section_update');
  Route::delete('/feedback_section_delete/{id}', [FeedbackSection::class, 'Delete'])->name('feedback_section_delete');
  Route::post('/feedback_section_status_change/{id}', [FeedbackSection::class, 'Status'])->name('feedback_section_status_change');
  Route::get('/feedback_section_list', [FeedbackSection::class, 'List'])->name('feedback_section_list');
  // FeedbackSection Setting End

  // FeedbackQuestion Setting Start
  Route::get('/settings/feedback_question', [FeedbackQuestion::class, 'index'])->name('settings-interview');
  Route::get('/settings/intreview/feedback_question_add', [FeedbackQuestion::class, 'AddForm'])->name('settings-interview');
  Route::get('/settings/intreview/feedback_question_edit/{id}', [FeedbackQuestion::class, 'edit'])->name('settings-interview');
  Route::post('/add_feedback_question', [FeedbackQuestion::class, 'Add'])->name('add_feedback_question');
  Route::post('/add_new_feedback_question', [FeedbackQuestion::class, 'AddNew'])->name('add_new_feedback_question');
  Route::post('/feedback_question_update', [FeedbackQuestion::class, 'Update'])->name('feedback_question_update');
  Route::delete('/feedback_question_delete/{id}', [FeedbackQuestion::class, 'Delete'])->name('feedback_question_delete');
  Route::post('/feedback_question_status_change/{id}', [FeedbackQuestion::class, 'Status'])->name('feedback_question_status_change');
  Route::get('/feedback_question_list', [FeedbackQuestion::class, 'List'])->name('feedback_question_list');
  Route::get('/feedback_question_list_by_role', [FeedbackQuestion::class, 'InterviewListByRole'])->name('feedback_question_list_by_role');
  // InterviewQuestion Setting End


    // InterviewFormQuestion Setting Start
  Route::get('/settings/interview_form_question', [InterviewFormQuestion::class, 'index'])->name('settings-interview');
  Route::get('/settings/intreview/form_question_add', [InterviewFormQuestion::class, 'AddForm'])->name('settings-interview');
  Route::get('/settings/intreview/form_question_edit/{id}', [InterviewFormQuestion::class, 'edit'])->name('settings-interview');
  Route::post('/add_form_question', [InterviewFormQuestion::class, 'Add'])->name('add_form_question');
  Route::post('/add_new_form_question', [InterviewFormQuestion::class, 'AddNew'])->name('add_new_form_question');
  Route::post('/form_question_update', [InterviewFormQuestion::class, 'Update'])->name('form_question_update');
  Route::delete('/form_question_delete/{id}', [InterviewFormQuestion::class, 'Delete'])->name('form_question_delete');
  Route::post('/form_question_status_change/{id}', [InterviewFormQuestion::class, 'Status'])->name('form_question_status_change');
  Route::get('/form_question_list', [InterviewFormQuestion::class, 'List'])->name('form_question_list');
  Route::get('/form_question_list_by_role', [InterviewFormQuestion::class, 'InterviewListByRole'])->name('feedback_question_list_by_role');
  // InterviewQuestion Setting End


  // NewsBroadcast
  Route::get('/communication_tool/news_broadcast', [NewsBroadcast::class, 'index'])->name('communication-tool-news-broadcast');
  Route::get('/settings/add_news_broadcast', [NewsBroadcast::class, 'Add'])->name('communication-tool-news-broadcast');
  Route::post('/broadcast_template_create', [NewsBroadcast::class, 'saveTemplate'])->name('broadcast_template_create');
  Route::get('/edit_news_broadcast/{id}', [NewsBroadcast::class, 'Edit'])->name('communication-tool-news-broadcast');
  Route::post('/news_broadcast_update', [NewsBroadcast::class, 'Update'])->name('news_broadcast_update');
  Route::delete('/news_broadcast_update_delete/{id}', [NewsBroadcast::class, 'Delete'])->name('news_broadcast_update_delete');
  Route::post('/check_news_broadcast_dates', [NewsBroadcast::class, 'checkDates']);
  Route::post('/check_news_broadcast_datesEdit', [NewsBroadcast::class, 'checkDatesEdit']);
  Route::post('/news_broadcast_status_change/{id}', [NewsBroadcast::class, 'Status'])->name('news_broadcast_status_change');
  Route::get('/broadcast_theme_by_id', [NewsBroadcast::class, 'broadcastThemeById'])->name('broadcast_theme_by_id');
  Route::get('/news_broadcast_by_id', [NewsBroadcast::class, 'newsBroadcastById'])->name('news_broadcast_by_id');

  Route::get('/news-broadcast/current',[NewsBroadcast::class, 'currentBroadcast']);

  Route::get('/role_list_broadcast/{id}', [NewsBroadcast::class, 'role_list_broadcast']);
  Route::post('/update_broadcast_roles', [NewsBroadcast::class, 'Update_role'])->name('update_broadcast_roles');
  Route::post('/broadcast_roles_remove', [NewsBroadcast::class, 'removeRole'])->name('broadcast_roles_remove');

  Route::get('/branch_list_broadcast/{id}', [NewsBroadcast::class, 'branch_list_broadcast']);
  Route::post('/update_broadcast_branch', [NewsBroadcast::class, 'Update_branch'])->name('update_broadcast_branch');
  Route::post('/broadcast_branch_remove', [NewsBroadcast::class, 'removeBranch'])->name('broadcast_branch_remove');
  Route::get('/branch_list', [NewsBroadcast::class, 'branch_list'])->name('branch_list');
  Route::get('/branch_list_multiple_newsbroadcast', [NewsBroadcast::class, 'BranchListMultiple'])->name('branch_list_multiple_newsbroadcast');
  Route::get('/entity_list_multiple_newsbroadcast', [NewsBroadcast::class, 'EntityListMultiple'])->name('entity_list_multiple_newsbroadcast');
  Route::get('/user_role_list_multiple', [NewsBroadcast::class, 'UserRoleListMultiple'])->name('user_role_list_multiple');

  //Broadcast Theme Setting
  Route::get('/settings/broadcast_theme', [BroadcastTheme::class, 'index'])->name('settings-broadcast-theme');
  Route::get('/settings/add_broadcast_theme', [BroadcastTheme::class, 'Add'])->name('settings-broadcast-theme');
  Route::post('/broadcast_theme_create', [BroadcastTheme::class, 'saveTemplate'])->name('broadcast_theme_create');
  Route::get('/edit_broadcast_theme/{id}', [BroadcastTheme::class, 'Edit'])->name('settings-broadcast-theme');
  Route::post('/broadcast_theme_update', [BroadcastTheme::class, 'Update'])->name('broadcast_theme_update');
  Route::delete('/broadcast_theme_update_delete/{id}', [BroadcastTheme::class, 'Delete'])->name('broadcast_theme_update_delete');
  Route::post('/broadcast_theme_status_change/{id}', [BroadcastTheme::class, 'Status'])->name('broadcast_theme_status_change');
});


Route::get('/record/{token}', [VideoSubmissionController::class, 'show'])->name('record.show');
Route::post('/record/upload', [VideoSubmissionController::class, 'upload'])->name('record.upload');

Route::get('/admin/webhooks', [WebhookAdminController::class, 'index'])->name('admin.webhooks');
Route::post('/admin/webhooks/retry/{id}', [WebhookAdminController::class, 'retry'])->name('admin.webhooks.retry');
Route::get('/webhooks_log', [WebhookAdminController::class, 'webhooksLog'])->name('webhooks_log');

Route::get('/test-broadcast', function () {
  $dispatch = \App\Models\WebhookDispatchModel::latest()->first();
  event(new \App\Events\WebhookDispatchedEvent($dispatch));
  return 'Event fired';
});

Route::get('/test-broadcast-job', function () {
  $dispatch = \App\Models\JobRequestModel::latest()->first();
  event(new \App\Events\JobRequestEvent($dispatch));
  return 'Event fired';
});

Route::get('/quote', function () {
  $response = Http::get('https://zenquotes.io/api/random');
  return $response->json();
});

Route::get('/role_permission_error', [ErrorController::class, 'index'])->name('role_permission_error');
Route::post('/send_test_template', [ManageStaff::class, 'TestMessageSend'])->name('send_test_template');

// JOb Application
Route::get('/interview_login/{id}', [JobController::class, 'startInterview'])->name('interview-login');
Route::get('/apply_job/{id}', [JobController::class, 'jobWelcomeScreen'])->name('apply_job');
Route::get('/job_application/{id}', [JobController::class, 'jobApplication'])->name('job_application');
Route::get('/interview_old/{id}', [JobController::class, 'Interview'])->name('interview');
Route::get('/gen_job_qr/{id}/generate-qr', [JobController::class, 'generateQrJob']);
Route::post('/ai/generate-interview-questions', [JobController::class, 'generateAiQuestion']);


Route::get('/network-status', [NetworkHandle::class, 'networkCheck'])->name('network-status');

// edit page
Route::get('/hr_recruitment/interview_schedule_edit/{encoded}', [JobRequest::class, 'editInterviewSchedule']);
Route::get('/interview/{encoded}', [JobController::class, 'runInterview'])->name('interview.run');

Route::get('/applicant_feedback_list/{id}', [JobController::class, 'FeedbackListByCategory'])->name('applicant_feedback_list');
Route::post('/submit_applicant_feedback/{id}', [JobController::class, 'SubmitApplicantFeedback']);

// update action
Route::post('/submit_job_application', [JobController::class, 'submitJobApplication'])->name('submit_job_application');
Route::get('/application_submitted/{id}', [JobController::class, 'applicationSubmitted'])->name('application_submitted');
Route::get('/interview_not_eligible/{id}', [JobController::class, 'showNotEligible'])->name('interview_not_eligible');
Route::get('/interview_feedback/{id}', [JobController::class, 'interviewFeedback']);

Route::post('/interview-schedule/update', [InterviewController::class, 'updateInterviewSchedule']);
Route::post('/interview/send-otp', [JobController::class, 'sendOtp'])
  ->name('interview.sendOtp');
Route::post('/interview/verify-otp', [JobController::class, 'verifyOtp'])
  ->name('interview.verifyOtp');

Route::post('/interview/tab-switch', [JobController::class, 'logTabSwitch']);
Route::post('/interview/answer/save', [JobController::class, 'saveAnswer']);
Route::get('/interview/question/next', [JobController::class, 'fetchNextQuestion']);
Route::get('/interview/check-resume', [InterviewController::class, 'checkResume']);
Route::get('/interview/thank-you/{id}', [JobController::class, 'ThankYouInterview'])->name('interview.thankyou');

Route::get('/upload_gdrive', [JobController::class, 'showUploadForm']);
Route::post('/upload_gdrive', [JobController::class, 'upload']);
Route::get('/gdrive_files', [JobController::class, 'listFiles']);
Route::get('/google/callback', [JobController::class, 'handleCallback']);
Route::get('/resumes/preview/{fileId}', [JobRequest::class, 'preview']);


Route::get('/zoom_ui', function () {
  return view('welcome')->with('respond', 'MEETING API RESPOND WILL COME IN THIS SECTION');
});
Route::get('start', [ZoomController::class, 'index']);
Route::any('interview-zoom-meeting-create', [ZoomController::class, 'index']);


use App\Http\Controllers\RazorpayPolicy;
// razorpay policies
Route::get('/contact-us', [RazorpayPolicy::class, 'ContactUs'])->name('contact.us');
Route::get('/shipping-policy', [RazorpayPolicy::class, 'ShippingPolicy'])->name('shipping.policy');
Route::get('/shipping-policy', [RazorpayPolicy::class, 'ShippingPolicy'])->name('shipping.policy');
Route::get('/terms-and-conditions', [RazorpayPolicy::class, 'TermsAndConditionPolicy'])->name('terms.conditions');
Route::get('/cancellations-and-refunds', [RazorpayPolicy::class, 'CancelAndRefundPolicy'])->name('refunds.policy');
Route::get('/privacy-policy', [RazorpayPolicy::class, 'PrivacyPolicy'])->name('privacy.policy');

// Route::get('/sentry-test', function () {
//     throw new Exception('Sentry local test error');
// });
use App\Http\Controllers\whatsapp_management\WhatsappConfig;

Route::match(['get', 'post'], '/webhook_whatsapp', [WhatsappConfig::class, 'WhatsappWebhook']);

Route::get('/admin/ai-usage', [AiUsageController::class, 'index']);
Route::get('/admin/ai-chat', [AiUsageController::class, 'aichat']);

Route::post('/admin/ai-models/{model}', function (Request $request, AiModel $model) {
  $model->update($request->only([
    'input_price_per_million',
    'output_price_per_million'
  ]));
});
Route::post('/ai/chat', [AiUsageController::class, 'chat'])
  ->middleware('ai.limit');
Route::get('/aichat/history', [AiUsageController::class, 'ChatHistory']);
Route::post('/aichat-clear-all/{id}', [AiUsageController::class, 'clearChatHistory'])->name('aichat-clear-all');


// job Fair
Route::post('/submit_jobfair_application', [JobFairController::class, 'submitJobApplication'])->name('submit_jobfair_application');
Route::get('/job_application_submitted/{id}', [JobFairController::class, 'applicationSubmitted'])->name('job_application_submitted');
Route::get('/gen_job_fair_qr/{id}/generate-qr', [JobFairController::class, 'generateQrJob']);
Route::get('/job_fair_application/{id}', [JobFairController::class, 'jobFairApplication'])->name('job_fair_application');


Route::get('/gen_job_common_qr/generate-qr', [walkinCandidate::class, 'generateQrJob']);
Route::get('/job_resume_application/{id}', [walkinCandidate::class, 'jobCommonApplication'])->name('job_resume_application');
Route::post('/submit_jobresume_application', [walkinCandidate::class, 'submitJobApplication'])->name('submit_jobresume_application');

Route::post('/participant_location_qr', [JobFairController::class, 'participant_location_qr'])->name('participant_location_qr');
Route::get('/payroll_qr_verified/{id}', [PayrollHistoryController::class, 'verifyPayslip'])->name('verify.payslip');
Route::get('/payroll/payslip_print/{entryId}', [PayrollHistoryController::class, 'PaySlipPrint']);


Route::get('/birthdays', [ManageStaff::class, 'birthdayList'])->name('birthdays.list');
Route::post('/save-score', [InterviewStaging::class, 'saveScore'])->name('save.score');

// Daily Attendance QR 
Route::get('/gen_daily_checkin_qr/generate-qr', [ManageAttendance::class, 'generateQrCheckIN']);

Route::get('/daily_qr_check', [ManageAttendance::class, 'DailyQRIndex']);


// Route::get('/test-essl', function () {

//   try {

//     $tables = DB::connection('essl')
//       ->select("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES");

//     return $tables;
//   } catch (\Exception $e) {

//     return $e->getMessage();
//   }
// });


Route::get('/bio-test', [ManageAttendance::class, 'testEssl'])->name('bio-test');
Route::get('/devicelog-test', [ManageAttendance::class, 'deviceLogs'])->name('devicelog-test');

    /* Create Security Session */
    Route::post('/create-session',[SecurityController::class, 'createSession'])->name('create-session');
    /* Generate QR */
    Route::get('/qr/{sessionUuid}',[SecurityController::class, 'qr'])->name('qr');
    /* Session Information */
    Route::get('/security/session/{sessionUuid}',[SecurityController::class, 'session'])->name('session');

  Route::get('/elysiumone', [Crm::class, 'EysiumOne'])->name('elysiumone');

  Route::get('/accounts_finance/finance_target',[FinanaceController::class, 'index']);


  Route::get(
      '/employee/profile/{token}',
      [ManageStaff::class, 'employeeProfile']
  )->name('employee.profile');

  Route::post(
      '/employee/profile/{token}/update',
      [ManageStaff::class, 'employeeProfileUpdate']
  )->name('employee.profile.update');

  use Illuminate\Support\Facades\Storage;

  Route::get('/favicon/{filename}', function ($filename) {

    // Prevent directory traversal
    $filename = basename($filename);

    $path = 'favicons/' . $filename;

    if (!Storage::disk('public')->exists($path)) {
        abort(404);
    }

    $fullPath = Storage::disk('public')->path($path);

    return response()->file($fullPath);

})->where('filename', '[A-Za-z0-9._-]+');

Route::get('/major_list_by_qualification', [JobRequest::class, 'majorListByQualification'])->name('major_list_by_qualification');
  Route::get('/caste_list_by_religion_community', [ManageStaff::class, 'casteListByCommunity'])->name('caste_list_by_religion_community');

Route::get('/staff/profile-edit/details',[ManageStaff::class, 'profileEditDetails'])->name('staff.profile.edit.details');
Route::post('/staff/profile-edit/send',[ManageStaff::class, 'sendProfileEdit'])->name('staff.profile.edit.send');

  
// loan Schedule
Route::middleware(['auth:web', 'timezone', 'throttle:120,1'])
    ->prefix('accounts_finance/loans')
    ->group(function () {
        // Page
        Route::get('/', [LoanScheduleController::class, 'index'])
            ->name('accounts-finance-loans');
        Route::get('/calendar', [LoanScheduleController::class, 'calendarPage'])
            ->name('accounts-finance-loans-calendar');

        // AJAX read endpoints
        Route::get('/data', [LoanScheduleController::class, 'data'])->name('accounts_finance.loans.data');
        Route::get('/calendar/data', [LoanScheduleController::class, 'calendar'])->name('accounts_finance.loans.calendar.data');
        Route::get('/lookups', [LoanScheduleController::class, 'lookups'])->name('accounts_finance.loans.lookups');

        // Static / known paths must stay before /{loan}.
        Route::get('/{loan}/data', [LoanScheduleController::class, 'show'])->whereNumber('loan')->name('accounts_finance.loans.data.show');

        // Create / update
        Route::post('/', [LoanScheduleController::class, 'store'])->name('accounts_finance.loans.store');
        Route::put('/{loan}', [LoanScheduleController::class, 'update'])->whereNumber('loan')->name('accounts_finance.loans.update');

        // Loan detail page
        Route::get('/{loan}', [LoanScheduleController::class, 'detail'])->whereNumber('loan')->name('accounts_finance.loans.show');

        // Maker / Checker
        Route::post('/{loan}/approve', [LoanScheduleController::class, 'approve'])->whereNumber('loan')->name('accounts_finance.loans.approve');
        Route::post('/{loan}/return', [LoanScheduleController::class, 'reject'])->whereNumber('loan')->name('accounts_finance.loans.return');

        // Payments
        Route::post('/{loan}/payments', [LoanScheduleController::class, 'payment'])->whereNumber('loan')->name('accounts_finance.loans.payments.store');

        // Part prepayment
        Route::post('/{loan}/prepay/preview', [LoanScheduleController::class, 'prepayPreview'])->whereNumber('loan')->name('accounts_finance.loans.prepay.preview');
        Route::post('/{loan}/prepay', [LoanScheduleController::class, 'prepay'])->whereNumber('loan')->name('accounts_finance.loans.prepay');
        Route::post('/{loan}/prepay/approve', [LoanScheduleController::class, 'approvePrepay'])->whereNumber('loan')->name('accounts_finance.loans.prepay.approve');

        // Restructure
        Route::post('/{loan}/restructure/preview', [LoanScheduleController::class, 'restructurePreview'])
            ->whereNumber('loan')
            ->name('accounts_finance.loans.restructure.preview');
        Route::post('/{loan}/restructure', [LoanScheduleController::class, 'restructure'])
            ->whereNumber('loan')
            ->name('accounts_finance.loans.restructure');
        Route::post('/{loan}/restructure/approve', [LoanScheduleController::class, 'approveRestructure'])
            ->whereNumber('loan')
            ->name('accounts_finance.loans.restructure.approve');

        // Closure / CC / calendar actions
        Route::post('/{loan}/close', [LoanScheduleController::class, 'close'])
            ->whereNumber('loan')
            ->name('accounts_finance.loans.close');
        Route::post('/{loan}/renewal', [LoanScheduleController::class, 'renewal'])
            ->whereNumber('loan')
            ->name('accounts_finance.loans.renewal');
        Route::post('/{loan}/utilisation', [LoanScheduleController::class, 'utilisation'])
            ->whereNumber('loan')
            ->name('accounts_finance.loans.utilisation');
        Route::post('/obligations/{obligation}/snooze', [LoanScheduleController::class, 'snooze'])
            ->whereNumber('obligation')
            ->name('accounts_finance.loans.obligations.snooze');
    });
    



use App\Http\Controllers\productivity\{
    DashboardController,
    SuiteController,
    ContactBookController,
    BookmarksController,
    PassWalletController,
    KnowledgePanelController,
    PortalAppController,
    MeetingController,
    TaskController,
    NotesController,
    MoneyController,
    EventController,
    DocumentController,
    ShareController,
    ReportController,
    AdminController
};

/*
 |--------------------------------------------------------------------------
 | Tool Management / Productivity Suite
 |--------------------------------------------------------------------------
 | Keep this route file independent from unrelated ERP modules. The menu uses
 | /productivity/* URLs so existing deep links remain stable.
 */
Route::middleware(['auth:web', 'timezone', 'throttle:180,1'])
    ->prefix('productivity')
    ->name('productivity.')
    ->group(function () {
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
        Route::get('/dashboard/data', [DashboardController::class, 'data'])->name('dashboard.data');

        Route::get('/notifications', [SuiteController::class, 'notifications'])->name('notifications');
        Route::post('/notifications/read', [SuiteController::class, 'markNotificationsRead'])->name('notifications.read');
        Route::get('/menu', [SuiteController::class, 'menu'])->name('menu');
        Route::get('/companies', [SuiteController::class, 'companies'])->name('companies');
        Route::get('/users', [SuiteController::class, 'users'])->name('users');
        Route::get('/global-search', [SuiteController::class, 'globalSearch'])->name('global.search');

        // ContactBook
        // Route::get('/contactbook', [ContactBookController::class, 'index'])->name('contacts');
        // Route::get('/contactbook/data', [ContactBookController::class, 'data'])->name('contacts.data');
        // Route::get('/contactbook/categories', [ContactBookController::class, 'categories'])->name('contacts.categories');
        // Route::get('/contactbook/export/csv', [ContactBookController::class, 'exportCsv'])->name('contacts.export.csv');
        // Route::get('/contactbook/export/xlsx', [ContactBookController::class, 'exportXlsx'])->name('contacts.export.xlsx');
        // Route::get('/contactbook/export/vcard', [ContactBookController::class, 'exportVcard'])->name('contacts.export.vcard');
        // Route::get('/contactbook/search/history', [ContactBookController::class, 'searchHistory'])->name('contacts.search.history');
        // Route::post('/contactbook/search/history', [ContactBookController::class, 'saveSearch'])->name('contacts.search.save');
        // Route::post('/contactbook/bulk', [ContactBookController::class, 'bulk'])->name('contacts.bulk');
        // Route::post('/contactbook/import', [ContactBookController::class, 'import'])->name('contacts.import');
        // Route::post('/contactbook/google-import', [ContactBookController::class, 'googleImport'])->name('contacts.google.import');
        // Route::get('/contactbook/google/connect', [ContactBookController::class, 'googleConnect'])->name('contacts.google.connect');
        // Route::get('/contactbook/google/callback', [ContactBookController::class, 'googleCallback'])->name('contacts.google.callback');
        // Route::post('/contactbook/merge', [ContactBookController::class, 'merge'])->name('contacts.merge');
        // Route::post('/contactbook', [ContactBookController::class, 'store'])->name('contacts.store');
        // Route::get('/contactbook/{id}', [ContactBookController::class, 'show'])->whereNumber('id')->name('contacts.show');
        // Route::put('/contactbook/{id}', [ContactBookController::class, 'update'])->whereNumber('id')->name('contacts.update');
        // Route::delete('/contactbook/{id}', [ContactBookController::class, 'delete'])->whereNumber('id')->name('contacts.delete');
        // Route::post('/contactbook/{id}/restore', [ContactBookController::class, 'restore'])->whereNumber('id')->name('contacts.restore');
        // Route::post('/contactbook/{id}/star', [ContactBookController::class, 'star'])->whereNumber('id')->name('contacts.star');

        Route::get('/contactbook', [ContactBookController::class, 'index'])->name('contacts');

Route::get('/contactbook/data', [ContactBookController::class, 'data'])->name('contacts.data');
Route::get('/contactbook/lookups', [ContactBookController::class, 'lookups'])->name('contacts.lookups');
Route::get('/contactbook/categories', [ContactBookController::class, 'categories'])->name('contacts.categories');
Route::get('/contactbook/duplicates', [ContactBookController::class, 'duplicateCheck'])->name('contacts.duplicates');

Route::get('/contactbook/export/csv', [ContactBookController::class, 'exportCsv'])->name('contacts.export.csv');
Route::get('/contactbook/export/xlsx', [ContactBookController::class, 'exportXlsx'])->name('contacts.export.xlsx');
Route::get('/contactbook/export/vcard', [ContactBookController::class, 'exportVcard'])->name('contacts.export.vcard');

Route::get('/contactbook/search/history', [ContactBookController::class, 'searchHistory'])->name('contacts.search.history');
Route::post('/contactbook/search/history', [ContactBookController::class, 'saveSearch'])->name('contacts.search.save');

Route::post('/contactbook/bulk', [ContactBookController::class, 'bulk'])->name('contacts.bulk');

Route::get('/contactbook/import/template', [ContactBookController::class, 'importTemplate'])->name('contacts.import.template');
Route::post('/contactbook/import/preview', [ContactBookController::class, 'importPreview'])->name('contacts.import.preview');
Route::post('/contactbook/import/commit', [ContactBookController::class, 'importCommit'])->name('contacts.import.commit');
Route::get('/contactbook/import/{id}/report', [ContactBookController::class, 'importReport'])
    ->whereNumber('id')
    ->name('contacts.import.report');
Route::post('/contactbook/import', [ContactBookController::class, 'import'])->name('contacts.import');

Route::get('/contactbook/google/connect', [ContactBookController::class, 'googleConnect'])->name('contacts.google.connect');
Route::get('/contactbook/google/callback', [ContactBookController::class, 'googleCallback'])->name('contacts.google.callback');
Route::get('/contactbook/google/groups', [ContactBookController::class, 'googleGroups'])->name('contacts.google.groups');
Route::post('/contactbook/google-import', [ContactBookController::class, 'googleImport'])->name('contacts.google.import');

Route::post('/contactbook/merge/preview', [ContactBookController::class, 'mergePreview'])->name('contacts.merge.preview');
Route::post('/contactbook/merge', [ContactBookController::class, 'merge'])->name('contacts.merge');

Route::post('/contactbook', [ContactBookController::class, 'store'])->name('contacts.store');
Route::get('/contactbook/{id}', [ContactBookController::class, 'show'])->whereNumber('id')->name('contacts.show');
Route::put('/contactbook/{id}', [ContactBookController::class, 'update'])->whereNumber('id')->name('contacts.update');
Route::delete('/contactbook/{id}', [ContactBookController::class, 'delete'])->whereNumber('id')->name('contacts.delete');
Route::post('/contactbook/{id}/restore', [ContactBookController::class, 'restore'])->whereNumber('id')->name('contacts.restore');
Route::post('/contactbook/{id}/star', [ContactBookController::class, 'star'])->whereNumber('id')->name('contacts.star');


        // BookMarks
        Route::get('/bookmarks', [BookmarksController::class, 'index'])->name('bookmarks');
        Route::get('/bookmarks/boards', [BookmarksController::class, 'boards'])->name('bookmarks.boards');
        Route::get('/bookmarks/data', [BookmarksController::class, 'data'])->name('bookmarks.data');
        Route::get('/bookmarks/favicon', [BookmarksController::class, 'favicon'])
            ->middleware('throttle:30,1')
            ->name('bookmarks.favicon');
        Route::get('/bookmarks/favicon-image', [BookmarksController::class, 'faviconImage'])
            ->middleware('throttle:30,1')
            ->name('bookmarks.favicon.image');
        Route::get('/bookmarks/board/{id}', [BookmarksController::class, 'board'])->whereNumber('id')->name('bookmarks.board');
        Route::get('/bookmarks/{id}', [BookmarksController::class, 'show'])->whereNumber('id')->name('bookmarks.show');
        Route::post('/bookmarks/boards', [BookmarksController::class, 'storeBoard'])->name('bookmarks.board.store');
        Route::put('/bookmarks/boards/{id}', [BookmarksController::class, 'updateBoard'])->whereNumber('id')->name('bookmarks.board.update');
        Route::delete('/bookmarks/boards/{id}', [BookmarksController::class, 'deleteBoard'])->whereNumber('id')->name('bookmarks.board.delete');
        Route::post('/bookmarks/boards/{boardId}/categories', [BookmarksController::class, 'storeCategory'])->whereNumber('boardId')->name('bookmarks.category.store');
        Route::put('/bookmarks/categories/{id}', [BookmarksController::class, 'updateCategory'])->whereNumber('id')->name('bookmarks.category.update');
        Route::delete('/bookmarks/categories/{id}', [BookmarksController::class, 'deleteCategory'])->whereNumber('id')->name('bookmarks.category.delete');
        Route::post('/bookmarks/quick-add', [BookmarksController::class, 'quickAdd'])->name('bookmarks.quick');
        Route::post('/bookmarks', [BookmarksController::class, 'storeBookmark'])->name('bookmarks.store');
        Route::put('/bookmarks/{id}', [BookmarksController::class, 'updateBookmark'])->whereNumber('id')->name('bookmarks.update');
        Route::delete('/bookmarks/{id}', [BookmarksController::class, 'deleteBookmark'])->whereNumber('id')->name('bookmarks.delete');
        Route::post('/bookmarks/{id}/open', [BookmarksController::class, 'open'])->whereNumber('id')->name('bookmarks.open');
        Route::post('/bookmarks/{id}/health', [BookmarksController::class, 'health'])->whereNumber('id')->name('bookmarks.health');
        Route::post('/bookmarks/import-html', [BookmarksController::class, 'importHtml'])->name('bookmarks.import.html');
        Route::post('/bookmarks/{id}/move-copy', [BookmarksController::class, 'moveCopy'])->whereNumber('id')->name('bookmarks.move-copy');

        // PassWallet
        Route::get('/passwallet', [PassWalletController::class, 'index'])->name('passwallet');
        Route::get('/passwallet/data', [PassWalletController::class, 'data'])->name('passwallet.data');
        Route::get('/passwallet/categories', [PassWalletController::class, 'categories'])->name('passwallet.categories');
        Route::post('/passwallet/generator', [PassWalletController::class, 'generator'])->name('passwallet.generator');
        Route::post('/passwallet/step-up', [PassWalletController::class, 'stepUp'])->middleware('throttle:10,1')->name('passwallet.stepup');
        Route::post('/passwallet/lockdown/{userId}', [PassWalletController::class, 'lockdown'])->whereNumber('userId')->name('passwallet.lockdown');
        Route::post('/passwallet', [PassWalletController::class, 'store'])->name('passwallet.store');
        Route::get('/passwallet/{id}', [PassWalletController::class, 'show'])->whereNumber('id')->name('passwallet.show');
        Route::put('/passwallet/{id}', [PassWalletController::class, 'update'])->whereNumber('id')->name('passwallet.update');
        Route::post('/passwallet/{id}/reveal', [PassWalletController::class, 'reveal'])->whereNumber('id')->name('passwallet.reveal');
    Route::post('/passwallet/{id}/copy-audit', [PassWalletController::class, 'copyAudit'])->whereNumber('id')->name('passwallet.copy-audit');
        Route::get('/passwallet/{id}/history', [PassWalletController::class, 'history'])->whereNumber('id')->name('passwallet.history');
        Route::get('/passwallet/{id}/shares', [PassWalletController::class, 'shares'])->whereNumber('id')->name('passwallet.shares');
        Route::post('/passwallet/{id}/attachment', [PassWalletController::class, 'attachment'])->whereNumber('id')->name('passwallet.attachment');
        Route::get('/passwallet/{id}/attachments', [PassWalletController::class, 'attachments'])->whereNumber('id')->name('passwallet.attachments');
        Route::delete('/passwallet/{id}', [PassWalletController::class, 'delete'])->whereNumber('id')->name('passwallet.delete');

        // Knowledge Panel
        Route::get('/knowledge', [KnowledgePanelController::class, 'index'])->name('knowledge');
        Route::get('/knowledge/categories', [KnowledgePanelController::class, 'categories'])->name('knowledge.categories');
        Route::get('/knowledge/data', [KnowledgePanelController::class, 'data'])->name('knowledge.data');
        Route::post('/knowledge', [KnowledgePanelController::class, 'store'])->name('knowledge.store');
        Route::get('/knowledge/{id}', [KnowledgePanelController::class, 'show'])->whereNumber('id')->name('knowledge.show');
        Route::put('/knowledge/{id}', [KnowledgePanelController::class, 'update'])->whereNumber('id')->name('knowledge.update');
        Route::post('/knowledge/{id}/like', [KnowledgePanelController::class, 'react'])->whereNumber('id')->name('knowledge.like');
        Route::post('/knowledge/{id}/save', [KnowledgePanelController::class, 'save'])->whereNumber('id')->name('knowledge.save');
        Route::post('/knowledge/{id}/reply', [KnowledgePanelController::class, 'reply'])->whereNumber('id')->name('knowledge.reply');
        Route::post('/knowledge/{id}/report', [KnowledgePanelController::class, 'report'])->whereNumber('id')->name('knowledge.report');
        Route::post('/knowledge/categories/{categoryId}/follow', [KnowledgePanelController::class, 'follow'])->whereNumber('categoryId')->name('knowledge.follow');
        Route::post('/knowledge/{id}/media', [KnowledgePanelController::class, 'mediaUpload'])->whereNumber('id')->name('knowledge.media');
        Route::post('/knowledge/{id}/moderate', [KnowledgePanelController::class, 'moderate'])->whereNumber('id')->name('knowledge.moderate');

        // Portals & Apps
        Route::get('/portals', [PortalAppController::class, 'index'])->name('portals');
        Route::get('/portals/data', [PortalAppController::class, 'data'])->name('portals.data');
        Route::get('/portals/export/xlsx', [PortalAppController::class, 'exportXlsx'])->name('portals.export.xlsx');
        Route::post('/portals', [PortalAppController::class, 'store'])->name('portals.store');
        Route::get('/portals/{id}', [PortalAppController::class, 'show'])->whereNumber('id')->name('portals.show');
        Route::put('/portals/{id}', [PortalAppController::class, 'update'])->whereNumber('id')->name('portals.update');
        Route::post('/portals/{id}/version', [PortalAppController::class, 'version'])->whereNumber('id')->name('portals.version');
        Route::post('/portals/{id}/launch', [PortalAppController::class, 'launch'])->whereNumber('id')->name('portals.launch');
        Route::post('/portals/{id}/subscribe', [PortalAppController::class, 'subscribe'])->whereNumber('id')->name('portals.subscribe');

        // Meetings
        Route::get('/meetings', [MeetingController::class, 'index'])->name('meetings');
        Route::get('/meetings/data', [MeetingController::class, 'data'])->name('meetings.data');
        Route::get('/meetings/calendar', [MeetingController::class, 'calendar'])->name('meetings.calendar');
        Route::post('/meetings', [MeetingController::class, 'store'])->name('meetings.store');
        Route::get('/meetings/{id}', [MeetingController::class, 'show'])->whereNumber('id')->name('meetings.show');
        Route::put('/meetings/{id}', [MeetingController::class, 'update'])->whereNumber('id')->name('meetings.update');
        Route::post('/meetings/{id}/reschedule', [MeetingController::class, 'reschedule'])->whereNumber('id')->name('meetings.reschedule');
        Route::post('/meetings/{id}/rsvp', [MeetingController::class, 'rsvp'])->whereNumber('id')->name('meetings.rsvp');
        Route::delete('/meetings/{id}', [MeetingController::class, 'delete'])->whereNumber('id')->name('meetings.delete');

        // Tasks
        Route::get('/tasks', [TaskController::class, 'index'])->name('tasks');
        Route::get('/tasks/data', [TaskController::class, 'data'])->name('tasks.data');
        Route::post('/tasks', [TaskController::class, 'store'])->name('tasks.store');
        Route::get('/tasks/{id}', [TaskController::class, 'show'])->whereNumber('id')->name('tasks.show');
        Route::put('/tasks/{id}', [TaskController::class, 'update'])->whereNumber('id')->name('tasks.update');
        Route::post('/tasks/{id}/status', [TaskController::class, 'status'])->whereNumber('id')->name('tasks.status');
        Route::post('/tasks/{id}/comment', [TaskController::class, 'comment'])->whereNumber('id')->name('tasks.comment');
        Route::post('/tasks/{id}/verify', [TaskController::class, 'verify'])->whereNumber('id')->name('tasks.verify');
        Route::delete('/tasks/{id}', [TaskController::class, 'delete'])->whereNumber('id')->name('tasks.delete');

        // Sticky Notes
        Route::get('/notes', [NotesController::class, 'index'])->name('notes');
        Route::get('/notes/data', [NotesController::class, 'data'])->name('notes.data');
    Route::get('/notes/{id}', [NotesController::class, 'show'])->whereNumber('id')->name('notes.show');
        Route::post('/notes', [NotesController::class, 'store'])->name('notes.store');
        Route::put('/notes/{id}', [NotesController::class, 'update'])->whereNumber('id')->name('notes.update');
        Route::post('/notes/{id}/action', [NotesController::class, 'action'])->whereNumber('id')->name('notes.action');

        // My Money
        Route::get('/money', [MoneyController::class, 'index'])->name('money');
        Route::get('/money/data', [MoneyController::class, 'data'])->name('money.data');
        Route::post('/money/accounts', [MoneyController::class, 'account'])->name('money.account');
        Route::post('/money/transactions', [MoneyController::class, 'transaction'])->name('money.transaction');
        Route::post('/money/budgets', [MoneyController::class, 'budget'])->name('money.budget');
        Route::post('/money/commitments', [MoneyController::class, 'commitment'])->name('money.commitment');

        // Events
        Route::get('/events', [EventController::class, 'index'])->name('events');
        Route::get('/events/data', [EventController::class, 'data'])->name('events.data');
        Route::get('/events/calendar', [EventController::class, 'calendar'])->name('events.calendar');
        Route::post('/events', [EventController::class, 'store'])->name('events.store');
        Route::get('/events/{id}', [EventController::class, 'show'])->whereNumber('id')->name('events.show');
        Route::put('/events/{id}', [EventController::class, 'update'])->whereNumber('id')->name('events.update');
        Route::delete('/events/{id}', [EventController::class, 'delete'])->whereNumber('id')->name('events.delete');

        // Documents
        Route::get('/documents', [DocumentController::class, 'index'])->name('documents');
        Route::get('/documents/data', [DocumentController::class, 'data'])->name('documents.data');
        Route::post('/documents/upload', [DocumentController::class, 'upload'])->name('documents.upload');
        Route::post('/documents/{id}/version', [DocumentController::class, 'version'])->whereNumber('id')->name('documents.version');
        Route::get('/documents/{id}/versions', [DocumentController::class, 'versions'])->whereNumber('id')->name('documents.versions');
        Route::get('/documents/{id}/url', [DocumentController::class, 'url'])->whereNumber('id')->name('documents.url');
        Route::post('/documents/{id}/pin', [DocumentController::class, 'pin'])->whereNumber('id')->name('documents.pin');
        Route::delete('/documents/{id}', [DocumentController::class, 'delete'])->whereNumber('id')->name('documents.delete');

        // Shared governance
        Route::get('/shares', [ShareController::class, 'data'])->name('shares.data');
        Route::get('/shares/pending', [ShareController::class, 'pending'])->name('shares.pending');
        Route::post('/shares', [ShareController::class, 'store'])->name('shares.store');
        Route::post('/shares/{id}/approve', [ShareController::class, 'approve'])->whereNumber('id')->name('shares.approve');
        Route::post('/shares/{id}/revoke', [ShareController::class, 'revoke'])->whereNumber('id')->name('shares.revoke');

        // Reports
        Route::get('/reports', [ReportController::class, 'index'])->name('reports');
        Route::get('/reports/data', [ReportController::class, 'data'])->name('reports.data');
        Route::get('/reports/csv', [ReportController::class, 'csv'])->name('reports.csv');
        Route::get('/reports/xlsx', [ReportController::class, 'xlsx'])->name('reports.xlsx');

        // Admin
        Route::get('/admin', [AdminController::class, 'index'])->name('admin');
        Route::get('/admin/data', [AdminController::class, 'data'])->name('admin.data');
        Route::post('/admin/category', [AdminController::class, 'category'])->name('admin.category');
    });
