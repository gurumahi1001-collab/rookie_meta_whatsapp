<?php

namespace App\Http\Controllers\productivity;

use App\Models\Productivity\Board;
use App\Models\Productivity\BoardCategory;
use App\Models\Productivity\Bookmark;
use App\Services\FavIcon\BookmarkFaviconService;
use App\Services\Productivity\ProductivityAccessService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class BookmarksController extends ProductivityBaseController
{
    public function __construct(
        ProductivityAccessService $access,
        protected BookmarkFaviconService $faviconService,
    ) {
        parent::__construct($access);
    }

    public function index()
    {
        return view('content.productivity.bookmarks.index');
    }

    public function boards(Request $request): JsonResponse
    {
        $query = Board::query()
            ->where('status', 0)
            ->where('is_archived', 0);

        $this->applyReadableScope($query, $request, 'board');

        $query->orderBy('sort_order')->orderBy('board_name');
        $boards = $query->get();
        $boards->each(function (Board $board) {
            $board->setAttribute(
                'can_manage',
                $this->access->canManageResource('board', $board->sno, $board->owner_user_id)
            );
        });

        return $this->ok($boards);
    }

    public function board(Request $request, int $id): JsonResponse
    {
        $board = Board::query()
            ->where('status', 0)
            ->where('is_archived', 0)
            ->findOrFail($id);

        abort_unless(
            $this->access->canReadResource(
                'board',
                $board->sno,
                $board->owner_user_id,
                $board->company_id,
                $board->visibility
            ),
            403
        );

        $categories = BoardCategory::query()
            ->where('board_id', $board->sno)
            ->orderBy('sort_order')
            ->orderBy('category_name')
            ->get();

        $bookmarks = Bookmark::query()
            ->where('board_id', $board->sno)
            ->where('status', 0)
            ->orderBy('sort_order')
            ->orderBy('bookmark_name')
            ->get()
            ->groupBy('category_id');

        return $this->ok([
            'board' => $board,
            'categories' => $categories,
            'bookmarks' => $bookmarks,
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()
            ->where('status', 0)
            ->with(['board', 'category'])
            ->findOrFail($id);

        $board = $bookmark->board;

        abort_unless(
            $board
                && $board->status === 0
                && !$board->is_archived
                && $this->access->canReadResource(
                    'board',
                    $board->sno,
                    $board->owner_user_id,
                    $board->company_id,
                    $board->visibility
                ),
            403
        );

        return $this->ok($bookmark);
    }

    public function data(Request $request): JsonResponse
    {
        $query = Bookmark::query()
            ->where('status', 0)
            ->with(['board', 'category'])
            ->whereHas('board', function ($boardQuery) use ($request) {
                $boardQuery
                    ->where('status', 0)
                    ->where('is_archived', 0);

                $this->applyReadableScope($boardQuery, $request, 'board');
            });

        if ($request->filled('board_id')) {
            $query->where('board_id', (int) $request->input('board_id'));
        }

        if ($request->filled('category_id')) {
            $query->where('category_id', (int) $request->input('category_id'));
        }

        if ($request->filled('health_status')) {
            $query->where('health_status', trim((string) $request->input('health_status')));
        }

        $search = trim((string) $request->input('search', ''));
        if ($search !== '') {
            $escaped = addcslashes($search, '%_\\');
            $query->where(function ($row) use ($escaped) {
                $row->where('bookmark_name', 'like', '%' . $escaped . '%')
                    ->orWhere('url', 'like', '%' . $escaped . '%')
                    ->orWhere('description', 'like', '%' . $escaped . '%');
            });
        }

        $perPage = min(max((int) $request->input('per_page', 25), 10), 100);

        return $this->ok([
            'rows' => $query
                ->orderByDesc('click_count')
                ->orderBy('sort_order')
                ->orderBy('bookmark_name')
                ->paginate($perPage),
        ]);
    }

    public function favicon(Request $request): JsonResponse
    {
        $data = $request->validate([
            'url' => ['required', 'url', 'max:2000'],
        ]);

        $url = $this->normalizeUrl($data['url']);
        if (!$url || !$this->faviconService->isSafePublicUrl($url)) {
            return $this->fail('Only public HTTP/HTTPS URLs can be resolved.', 422);
        }

        $faviconUrl = $this->faviconService->getFavicon($url);

        return $this->ok([
            'favicon_url' => $faviconUrl,
            'resolved' => (bool) $faviconUrl,
        ]);
    }

    public function faviconImage(Request $request)
    {
        $url = trim((string) $request->query('url', ''));

        if (!$url || !$this->faviconService->isSafePublicUrl($url)) {
            return response()->noContent(204);
        }

        $faviconUrl = $this->faviconService->getFavicon($url);

        if (!$faviconUrl) {
            return response()->noContent(204);
        }

        return redirect()->to($faviconUrl);
    }

    public function storeBoard(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $data = $request->validate([
            'company_id' => ['nullable', 'integer'],
            'board_name' => ['required', 'string', 'max:160'],
            'icon' => ['nullable', 'string', 'max:100'],
            'description' => ['nullable', 'string', 'max:5000'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'is_locked' => ['nullable', 'boolean'],
        ]);

        // Company selection is privileged; normal users can only create in
        // their current company scope.
        if (!$this->access->isGroupAdmin()) {
            $data['company_id'] = $this->cid();
        } else {
            $data['company_id'] = $data['company_id'] ?? $this->cid();
        }

        $data['owner_user_id'] = $this->uid();
        $data['created_by'] = $this->uid();
        $data['updated_by'] = $this->uid();
        $data['sort_order'] = (int) Board::query()
            ->where('company_id', $data['company_id'])
            ->max('sort_order') + 1;
        $data['icon'] = trim((string) ($data['icon'] ?? '')) ?: 'mdi-view-dashboard-outline';
        $data['is_locked'] = (bool) ($data['is_locked'] ?? false);

        $board = Board::create($data);

        $this->audit(
            $request,
            'BookMarks',
            'board_created',
            'board',
            $board->sno,
            null,
            $board->toArray()
        );

        return $this->ok($board, 'Board created successfully.');
    }

    public function updateBoard(Request $request, int $id): JsonResponse
    {
        $board = Board::findOrFail($id);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $board->owner_user_id),
            403
        );

        $data = $request->validate([
            'board_name' => ['required', 'string', 'max:160'],
            'icon' => ['nullable', 'string', 'max:100'],
            'description' => ['nullable', 'string', 'max:5000'],
            'visibility' => ['required', 'in:Private,Company,Group'],
            'is_locked' => ['nullable', 'boolean'],
            'is_archived' => ['nullable', 'boolean'],
        ]);

        $before = $board->toArray();
        $data['updated_by'] = $this->uid();
        $data['is_locked'] = (bool) ($data['is_locked'] ?? false);
        $data['is_archived'] = (bool) ($data['is_archived'] ?? false);

        $board->update($data);

        $this->audit(
            $request,
            'BookMarks',
            'board_updated',
            'board',
            $board->sno,
            $before,
            $board->fresh()->toArray()
        );

        return $this->ok($board->fresh(), 'Board updated successfully.');
    }

    public function deleteBoard(Request $request, int $id): JsonResponse
    {
        $board = Board::findOrFail($id);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $board->owner_user_id),
            403
        );

        $before = $board->toArray();
        $board->update([
            'status' => 2,
            'is_archived' => 1,
            'deleted_at' => now(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'board_archived',
            'board',
            $board->sno,
            $before,
            $board->fresh()->toArray()
        );

        return $this->ok(null, 'Board archived successfully.');
    }

    public function storeCategory(Request $request, int $boardId): JsonResponse
    {
        $board = $this->activeBoard($boardId);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $board->owner_user_id),
            403
        );

        $data = $request->validate([
            'category_name' => ['required', 'string', 'max:160'],
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'is_collapsed' => ['nullable', 'boolean'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ]);

        $data['board_id'] = $board->sno;
        $data['created_by'] = $this->uid();
        $data['updated_by'] = $this->uid();
        $data['sort_order'] = array_key_exists('sort_order', $data)
            ? (int) $data['sort_order']
            : ((int) BoardCategory::query()->where('board_id', $board->sno)->max('sort_order') + 1);
        $data['is_collapsed'] = (bool) ($data['is_collapsed'] ?? false);

        $category = BoardCategory::create($data);

        $this->audit(
            $request,
            'BookMarks',
            'category_created',
            'bookmark_category',
            $category->sno,
            null,
            $category->toArray()
        );

        return $this->ok($category, 'Category created successfully.');
    }

    public function updateCategory(Request $request, int $id): JsonResponse
    {
        $category = BoardCategory::findOrFail($id);
        $board = $this->activeBoard($category->board_id);

        abort_unless(
            $this->access->canManageResource('board', $board->sno, $board->owner_user_id),
            403
        );

        $data = $request->validate([
            'category_name' => ['required', 'string', 'max:160'],
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'is_collapsed' => ['nullable', 'boolean'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ]);

        $before = $category->toArray();
        $category->update(array_merge($data, [
            'updated_by' => $this->uid(),
            'is_collapsed' => (bool) ($data['is_collapsed'] ?? false),
        ]));

        $this->audit(
            $request,
            'BookMarks',
            'category_updated',
            'bookmark_category',
            $category->sno,
            $before,
            $category->fresh()->toArray()
        );

        return $this->ok($category->fresh(), 'Category updated successfully.');
    }

    public function deleteCategory(Request $request, int $id): JsonResponse
    {
        $category = BoardCategory::findOrFail($id);
        $board = $this->activeBoard($category->board_id);

        abort_unless(
            $this->access->canManageResource('board', $board->sno, $board->owner_user_id),
            403
        );

        if (Bookmark::query()->where('category_id', $category->sno)->where('status', 0)->exists()) {
            return $this->fail('Move or remove the active bookmarks in this category before deleting it.', 422);
        }

        $before = $category->toArray();
        $category->delete();

        $this->audit(
            $request,
            'BookMarks',
            'category_deleted',
            'bookmark_category',
            $id,
            $before,
            null
        );

        return $this->ok(null, 'Category deleted successfully.');
    }

    public function storeBookmark(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $data = $this->validateBookmarkPayload($request);
        [$board, $category] = $this->validateBookmarkPlacement(
            (int) $data['board_id'],
            (int) $data['category_id']
        );

        abort_unless(
            $this->access->canManageResource('board', $board->sno, $board->owner_user_id),
            403
        );

        $url = $this->normalizeUrl($data['url']);
        if (!$url || !$this->faviconService->isSafePublicUrl($url)) {
            return $this->fail('Only public HTTP/HTTPS URLs are allowed.', 422);
        }

        $duplicate = $this->findDuplicate($board->sno, $url);
        if ($duplicate) {
            return $this->fail(
                'This URL already exists on the selected board.',
                409,
                ['duplicate' => $duplicate]
            );
        }

        $faviconUrl = $this->faviconService->getFavicon($url);
        $bookmark = Bookmark::create([
            'board_id' => $board->sno,
            'category_id' => $category->sno,
            'owner_user_id' => $this->uid(),
            'bookmark_name' => trim($data['bookmark_name']),
            'url' => $url,
            'description' => $this->nullableString($data['description'] ?? null),
            'favicon_url' => $faviconUrl,
            // Manual third-party icon URLs are intentionally not persisted.
            'manual_icon' => null,
            'tags_json' => $this->normalizeTags($data['tags'] ?? []),
            'created_by' => $this->uid(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_created',
            'bookmark',
            $bookmark->sno,
            null,
            $bookmark->toArray(),
            ['favicon_resolved' => (bool) $faviconUrl]
        );

        return $this->ok(
            $bookmark->load(['board', 'category']),
            'Bookmark added successfully.'
        );
    }

    public function quickAdd(Request $request): JsonResponse
    {
        $name = trim((string) $request->input('bookmark_name', ''));
        $url = trim((string) $request->input('url', ''));

        if ($name === '' && filter_var($url, FILTER_VALIDATE_URL)) {
            $name = (string) (parse_url($url, PHP_URL_HOST) ?: 'Bookmark');
        }

        $request->merge(['bookmark_name' => $name]);

        return $this->storeBookmark($request);
    }

    public function updateBookmark(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);

        abort_unless(
            $this->access->canManageResource('bookmark', $bookmark->sno, $bookmark->owner_user_id),
            403
        );

        $data = $this->validateBookmarkPayload($request);
        [$board, $category] = $this->validateBookmarkPlacement(
            (int) $data['board_id'],
            (int) $data['category_id']
        );

        abort_unless(
            $this->access->canManageResource('board', $board->sno, $board->owner_user_id),
            403
        );

        $url = $this->normalizeUrl($data['url']);
        if (!$url || !$this->faviconService->isSafePublicUrl($url)) {
            return $this->fail('Only public HTTP/HTTPS URLs are allowed.', 422);
        }

        $duplicate = $this->findDuplicate($board->sno, $url, $bookmark->sno);
        if ($duplicate) {
            return $this->fail(
                'This URL already exists on the selected board.',
                409,
                ['duplicate' => $duplicate]
            );
        }

        $before = $bookmark->toArray();
        $urlChanged = $bookmark->url !== $url;
        $legacyProxyFavicon = is_string($bookmark->favicon_url)
            && stripos($bookmark->favicon_url, 'google.com/s2/favicons') !== false;
        $faviconUrl = ($urlChanged || $legacyProxyFavicon)
            ? $this->faviconService->getFavicon($url)
            : $bookmark->favicon_url;

        $bookmark->update([
            'board_id' => $board->sno,
            'category_id' => $category->sno,
            'bookmark_name' => trim($data['bookmark_name']),
            'url' => $url,
            'description' => $this->nullableString($data['description'] ?? null),
            'favicon_url' => $faviconUrl,
            'manual_icon' => null,
            'tags_json' => $this->normalizeTags($data['tags'] ?? []),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_updated',
            'bookmark',
            $bookmark->sno,
            $before,
            $bookmark->fresh()->toArray(),
            ['favicon_refreshed' => $urlChanged]
        );

        return $this->ok(
            $bookmark->fresh()->load(['board', 'category']),
            'Bookmark updated successfully.'
        );
    }

    public function deleteBookmark(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);

        abort_unless(
            $this->access->canManageResource('bookmark', $bookmark->sno, $bookmark->owner_user_id),
            403
        );

        $before = $bookmark->toArray();
        $bookmark->update([
            'status' => 2,
            'deleted_at' => now(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_archived',
            'bookmark',
            $bookmark->sno,
            $before,
            $bookmark->fresh()->toArray()
        );

        return $this->ok(null, 'Bookmark removed successfully.');
    }

    public function open(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);
        $board = $bookmark->board;

        abort_unless(
            $board
                && $board->status === 0
                && !$board->is_archived
                && $this->access->canReadResource(
                    'board',
                    $board->sno,
                    $board->owner_user_id,
                    $board->company_id,
                    $board->visibility
                ),
            403
        );

        $bookmark->increment('click_count');

        DB::table('egc_tool_bookmark_clicks')->insert([
            'bookmark_id' => $bookmark->sno,
            'user_id' => $this->uid(),
            'clicked_at' => now(),
            'ip_address' => $request->ip(),
            'user_agent' => substr((string) $request->userAgent(), 0, 1000),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_opened',
            'bookmark',
            $bookmark->sno,
            null,
            null,
            ['url' => $bookmark->url]
        );

        return $this->ok(['url' => $bookmark->url]);
    }

    public function health(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);

        abort_unless(
            $this->access->canManageResource('bookmark', $bookmark->sno, $bookmark->owner_user_id),
            403
        );

        if (!$this->faviconService->isSafePublicUrl($bookmark->url)) {
            return $this->fail('The bookmark URL is not eligible for server-side health checks.', 422);
        }

        $bookmark->update([
            'health_status' => 'checking',
            'last_checked_at' => now(),
            'updated_by' => $this->uid(),
        ]);

        $status = null;
        $health = 'broken';

        try {
            $response = Http::timeout(8)
                ->connectTimeout(4)
                ->retry(1, 150)
                ->withOptions(['allow_redirects' => false])
                ->head($bookmark->url);

            $status = $response->status();

            // Some sites reject HEAD; retry with a small GET in that case.
            if (in_array($status, [405, 501], true)) {
                $response = Http::timeout(8)
                    ->connectTimeout(4)
                    ->retry(1, 150)
                    ->withOptions(['allow_redirects' => false])
                    ->get($bookmark->url);
                $status = $response->status();
            }

            if ($response->successful() || in_array($status, [301, 302, 303, 307, 308, 401, 403, 429], true)) {
                $health = 'healthy';
            }
        } catch (\Throwable $exception) {
            report($exception);
        }

        $bookmark->update([
            'health_status' => $health,
            'last_checked_at' => now(),
            'updated_by' => $this->uid(),
        ]);

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_health_checked',
            'bookmark',
            $bookmark->sno,
            null,
            ['health_status' => $health, 'http_status' => $status]
        );

        return $this->ok([
            'health_status' => $health,
            'http_status' => $status,
        ]);
    }

    public function moveCopy(Request $request, int $id): JsonResponse
    {
        $bookmark = Bookmark::query()->where('status', 0)->findOrFail($id);

        abort_unless(
            $this->access->canManageResource('bookmark', $bookmark->sno, $bookmark->owner_user_id),
            403
        );

        $data = $request->validate([
            'target_board_id' => ['required', 'integer', 'exists:egc_tool_boards,sno'],
            'target_category_id' => ['required', 'integer', 'exists:egc_tool_board_categories,sno'],
            'mode' => ['required', 'in:move,copy'],
        ]);

        $targetBoard = $this->activeBoard((int) $data['target_board_id']);
        abort_unless(
            $this->access->canManageResource('board', $targetBoard->sno, $targetBoard->owner_user_id),
            403
        );

        $targetCategory = BoardCategory::query()
            ->where('sno', (int) $data['target_category_id'])
            ->where('board_id', $targetBoard->sno)
            ->first();

        if (!$targetCategory) {
            return $this->fail('The selected category does not belong to the selected board.', 422);
        }

        $duplicate = $this->findDuplicate(
            $targetBoard->sno,
            $bookmark->url,
            $data['mode'] === 'move' ? $bookmark->sno : null
        );

        if ($duplicate) {
            return $this->fail(
                'The bookmark URL already exists on the target board.',
                409,
                ['duplicate' => $duplicate]
            );
        }

        $before = $bookmark->toArray();

        if ($data['mode'] === 'move') {
            $bookmark->update([
                'board_id' => $targetBoard->sno,
                'category_id' => $targetCategory->sno,
                'updated_by' => $this->uid(),
            ]);
            $result = $bookmark->fresh();
        } else {
            $result = $bookmark->replicate();
            $result->board_id = $targetBoard->sno;
            $result->category_id = $targetCategory->sno;
            $result->owner_user_id = $this->uid();
            $result->created_by = $this->uid();
            $result->updated_by = $this->uid();
            $result->click_count = 0;
            $result->status = 0;
            $result->deleted_at = null;
            $result->save();
        }

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_' . $data['mode'] . 'd',
            'bookmark',
            $result->sno,
            $before,
            $result->fresh()->toArray(),
            ['target_board_id' => $targetBoard->sno, 'target_category_id' => $targetCategory->sno]
        );

        return $this->ok($result->fresh()->load(['board', 'category']), 'Bookmark ' . $data['mode'] . 'd successfully.');
    }

    public function importHtml(Request $request): JsonResponse
    {
        abort_unless($this->access->canWrite(), 403);

        $data = $request->validate([
            'board_id' => ['required', 'integer', 'exists:egc_tool_boards,sno'],
            'file' => ['required', 'file', 'max:10240', 'mimes:html,htm'],
        ]);

        $board = $this->activeBoard((int) $data['board_id']);
        abort_unless(
            $this->access->canManageResource('board', $board->sno, $board->owner_user_id),
            403
        );

        $html = file_get_contents($request->file('file')->getRealPath()) ?: '';
        if (!class_exists(\DOMDocument::class)) {
            return $this->fail('The PHP DOM extension is required for HTML bookmark import.', 500);
        }
        $dom = new \DOMDocument();
        @$dom->loadHTML($html);

        $links = [];
        foreach ($dom->getElementsByTagName('a') as $anchor) {
            if (count($links) >= 500) {
                break;
            }

            $url = trim((string) $anchor->getAttribute('href'));
            $name = trim((string) $anchor->textContent);

            if (!$url || !filter_var($url, FILTER_VALIDATE_URL)) {
                continue;
            }

            $url = $this->normalizeUrl($url);
            if (!$url || !$this->faviconService->isSafePublicUrl($url)) {
                continue;
            }

            $links[] = [
                'name' => mb_substr($name ?: (string) (parse_url($url, PHP_URL_HOST) ?: 'Bookmark'), 0, 180),
                'url' => $url,
            ];
        }

        $category = BoardCategory::query()
            ->where('board_id', $board->sno)
            ->orderBy('sort_order')
            ->orderBy('category_name')
            ->first();

        if (!$category) {
            $category = BoardCategory::create([
                'board_id' => $board->sno,
                'category_name' => 'Imported',
                'color' => '#1F618D',
                'sort_order' => 0,
                'created_by' => $this->uid(),
                'updated_by' => $this->uid(),
            ]);
        }

        $imported = 0;
        $duplicates = 0;
        $faviconResolved = 0;

        foreach ($links as $link) {
            if ($this->findDuplicate($board->sno, $link['url'])) {
                $duplicates++;
                continue;
            }

            $faviconUrl = $this->faviconService->getFavicon($link['url']);
            if ($faviconUrl) {
                $faviconResolved++;
            }

            Bookmark::create([
                'board_id' => $board->sno,
                'category_id' => $category->sno,
                'owner_user_id' => $this->uid(),
                'bookmark_name' => $link['name'],
                'url' => $link['url'],
                'favicon_url' => $faviconUrl,
                'manual_icon' => null,
                'tags_json' => [],
                'created_by' => $this->uid(),
                'updated_by' => $this->uid(),
            ]);

            $imported++;
        }

        $this->audit(
            $request,
            'BookMarks',
            'bookmark_import_html',
            'board',
            $board->sno,
            null,
            ['imported' => $imported, 'duplicates' => $duplicates, 'total' => count($links)],
            ['favicon_resolved' => $faviconResolved]
        );

        return $this->ok([
            'imported' => $imported,
            'duplicates' => $duplicates,
            'total' => count($links),
            'favicon_resolved' => $faviconResolved,
        ], 'Browser bookmark import completed.');
    }

    private function validateBookmarkPayload(Request $request): array
    {
        return $request->validate([
            'board_id' => ['required', 'integer', 'exists:egc_tool_boards,sno'],
            'category_id' => ['required', 'integer', 'exists:egc_tool_board_categories,sno'],
            'bookmark_name' => ['required', 'string', 'max:180'],
            'url' => ['required', 'url', 'max:2000'],
            'description' => ['nullable', 'string', 'max:5000'],
            'favicon_url' => ['nullable', 'url', 'max:1000'],
            'manual_icon' => ['nullable', 'string', 'max:500'],
            'tags' => ['nullable'],
        ]);
    }

    private function validateBookmarkPlacement(int $boardId, int $categoryId): array
    {
        $board = $this->activeBoard($boardId);
        $category = BoardCategory::query()
            ->where('sno', $categoryId)
            ->where('board_id', $boardId)
            ->first();

        if (!$category) {
            abort(422, 'The selected category does not belong to the selected board.');
        }

        return [$board, $category];
    }

    private function activeBoard(int $id): Board
    {
        return Board::query()
            ->where('status', 0)
            ->where('is_archived', 0)
            ->findOrFail($id);
    }

    private function findDuplicate(int $boardId, string $url, ?int $exceptId = null): ?Bookmark
    {
        $query = Bookmark::query()
            ->where('board_id', $boardId)
            ->where('status', 0)
            ->where('url', $url);

        if ($exceptId) {
            $query->where('sno', '<>', $exceptId);
        }

        return $query->first();
    }

    private function normalizeUrl(string $url): ?string
    {
        $url = trim($url);
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return null;
        }

        $parts = parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = $parts['host'] ?? '';

        if (!in_array($scheme, ['http', 'https'], true) || !$host) {
            return null;
        }

        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        $path = $parts['path'] ?? '/';
        $query = isset($parts['query']) ? '?' . $parts['query'] : '';

        return $scheme . '://' . $host . $port . $path . $query;
    }

    private function normalizeTags($tags): array
    {
        if (is_string($tags)) {
            $tags = preg_split('/[,\n]+/', $tags) ?: [];
        }

        if (!is_array($tags)) {
            return [];
        }

        $normalized = [];
        foreach ($tags as $tag) {
            $tag = trim((string) $tag);
            if ($tag !== '') {
                $normalized[] = mb_substr($tag, 0, 50);
            }
        }

        return array_values(array_unique(array_slice($normalized, 0, 30)));
    }

    private function nullableString($value): ?string
    {
        $value = trim((string) $value);
        return $value === '' ? null : $value;
    }
}
