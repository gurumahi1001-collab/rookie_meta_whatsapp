<?php

namespace App\Services\FavIcon;

use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;

/**
 * BookMarks-specific favicon resolver.
 *
 * It resolves the official icon advertised by the target site, follows only
 * safe public redirects, and caches the image locally so the browser never
 * depends on a third-party favicon proxy.
 */
class BookmarkFaviconService
{
    private const MAX_REDIRECTS = 3;
    private const MAX_BYTES = 524288; // 512 KB

    public function getFavicon(string $websiteUrl): ?string
    {
        $websiteUrl = $this->normalizeUrl($websiteUrl);

        if (!$websiteUrl || !$this->isSafePublicUrl($websiteUrl)) {
            return null;
        }

        $host = strtolower((string) parse_url($websiteUrl, PHP_URL_HOST));
        $port = (string) (parse_url($websiteUrl, PHP_URL_PORT) ?: '');
        $cacheKey = 'favicons/bookmark_' . sha1($host . ':' . $port) . '.ico';

        if (Storage::disk('public')->exists($cacheKey)) {
            return url('/favicon/' . basename($cacheKey));
        }

        $response = $this->requestFollowingSafeRedirects($websiteUrl, false);

        if (!$response || !$response->successful()) {
            return $this->downloadDefault($websiteUrl, $cacheKey);
        }

        $faviconUrl = $this->extractFaviconUrl($response->body());
        if ($faviconUrl) {
            $faviconUrl = $this->makeAbsoluteUrl($faviconUrl, $websiteUrl);
            if ($faviconUrl && $this->isSafePublicUrl($faviconUrl)) {
                $cached = $this->downloadAndCache($faviconUrl, $cacheKey);
                if ($cached) {
                    return $cached;
                }
            }
        }

        return $this->downloadDefault($websiteUrl, $cacheKey);
    }

    public function isSafePublicUrl(string $url): bool
    {
        $url = trim($url);
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $parts = parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = strtolower((string) ($parts['host'] ?? ''));

        if (!in_array($scheme, ['http', 'https'], true) || $host === '') {
            return false;
        }

        if ($this->isBlockedHostname($host)) {
            return false;
        }

        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return $this->isPublicIp($host);
        }

        $records = @dns_get_record($host, DNS_A | DNS_AAAA);
        if (!$records) {
            // Fail closed for server-side requests.
            return false;
        }

        foreach ($records as $record) {
            $ip = $record['ip'] ?? ($record['ipv6'] ?? null);
            if ($ip && !$this->isPublicIp($ip)) {
                return false;
            }
        }

        return true;
    }

    private function normalizeUrl(string $url): ?string
    {
        $url = trim($url);
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return null;
        }

        $parts = parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = $parts['host'] ?? null;

        if (!in_array($scheme, ['http', 'https'], true) || !$host) {
            return null;
        }

        // Credentials and fragments are intentionally omitted.
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        $path = $parts['path'] ?? '/';
        $query = isset($parts['query']) ? '?' . $parts['query'] : '';

        return $scheme . '://' . $host . $port . $path . $query;
    }

    private function isBlockedHostname(string $host): bool
    {
        return $host === 'localhost'
            || str_ends_with($host, '.localhost')
            || str_ends_with($host, '.local')
            || str_ends_with($host, '.internal')
            || $host === 'metadata.google.internal'
            || $host === 'host.docker.internal';
    }

    private function isPublicIp(string $ip): bool
    {
        return (bool) filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        );
    }

    private function extractFaviconUrl(string $html): ?string
    {
        if ($html === '') {
            return null;
        }

        libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        if (!@$dom->loadHTML($html)) {
            libxml_clear_errors();
            return null;
        }

        foreach ($dom->getElementsByTagName('link') as $link) {
            $rel = strtolower(trim($link->getAttribute('rel')));
            $href = trim($link->getAttribute('href'));

            if ($href === '' || $this->isUnsafeIconHref($href)) {
                continue;
            }

            if (preg_match('/(^|\s)(icon|shortcut\s*icon|apple-touch-icon)(\s|$)/i', $rel)) {
                libxml_clear_errors();
                return $href;
            }
        }

        libxml_clear_errors();
        return null;
    }

    private function isUnsafeIconHref(string $href): bool
    {
        $lower = strtolower(trim($href));
        return str_starts_with($lower, 'data:')
            || str_starts_with($lower, 'javascript:')
            || str_starts_with($lower, 'mailto:')
            || str_starts_with($lower, 'tel:');
    }

    private function makeAbsoluteUrl(string $faviconUrl, string $websiteUrl): ?string
    {
        $faviconUrl = trim($faviconUrl);
        if ($faviconUrl === '') {
            return null;
        }

        if (filter_var($faviconUrl, FILTER_VALIDATE_URL)) {
            return $this->normalizeUrl($faviconUrl);
        }

        $parts = parse_url($websiteUrl);
        if (!$parts || empty($parts['host'])) {
            return null;
        }

        $scheme = $parts['scheme'] ?? 'https';
        $host = $parts['host'];
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        $base = $scheme . '://' . $host . $port;

        if (str_starts_with($faviconUrl, '//')) {
            return $this->normalizeUrl($scheme . ':' . $faviconUrl);
        }

        if (str_starts_with($faviconUrl, '/')) {
            return $this->normalizeUrl($base . $faviconUrl);
        }

        $path = $parts['path'] ?? '/';
        $directory = rtrim(str_replace('\\', '/', dirname($path)), '/');
        if ($directory === '.' || $directory === '\\') {
            $directory = '';
        }

        return $this->normalizeUrl($base . $directory . '/' . ltrim($faviconUrl, '/'));
    }

    private function downloadDefault(string $websiteUrl, string $cacheKey): ?string
    {
        $parts = parse_url($websiteUrl);
        if (!$parts || empty($parts['host'])) {
            return null;
        }

        $scheme = $parts['scheme'] ?? 'https';
        $host = $parts['host'];
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        $url = $scheme . '://' . $host . $port . '/favicon.ico';

        if (!$this->isSafePublicUrl($url)) {
            return null;
        }

        return $this->downloadAndCache($url, $cacheKey);
    }

    private function downloadAndCache(string $faviconUrl, string $cacheKey): ?string
    {
        $response = $this->requestFollowingSafeRedirects($faviconUrl, true);
        if (!$response || !$response->successful()) {
            return null;
        }

        $contentType = strtolower((string) $response->header('Content-Type', ''));
        if (!str_contains($contentType, 'image/') && !str_contains($contentType, 'icon')) {
            return null;
        }

        $body = $response->body();
        if ($body === '' || strlen($body) > self::MAX_BYTES) {
            return null;
        }

        if (class_exists(\finfo::class)) {
            $mime = (new \finfo(FILEINFO_MIME_TYPE))->buffer($body);
            if ($mime && !str_starts_with($mime, 'image/') && $mime !== 'image/x-icon') {
                return null;
            }
        }

        Storage::disk('public')->put($cacheKey, $body);
        return url('/favicon/' . basename($cacheKey));
    }

    private function requestFollowingSafeRedirects(string $url, bool $image): ?Response
    {
        $current = $this->normalizeUrl($url);
        if (!$current || !$this->isSafePublicUrl($current)) {
            return null;
        }

        for ($attempt = 0; $attempt <= self::MAX_REDIRECTS; $attempt++) {
            $response = $this->httpClient($image)->send('GET', $current, [
                'allow_redirects' => false,
            ]);

            if ($response->successful()) {
                return $response;
            }

            $status = $response->status();
            if (!in_array($status, [301, 302, 303, 307, 308], true)) {
                return $response;
            }

            $location = trim((string) $response->header('Location'));
            if ($location === '') {
                return $response;
            }

            $next = $this->makeAbsoluteUrl($location, $current);
            if (!$next || !$this->isSafePublicUrl($next)) {
                return null;
            }

            $current = $next;
        }

        return null;
    }

    private function httpClient(bool $image): PendingRequest
    {
        return Http::timeout(8)
            ->connectTimeout(4)
            ->retry(1, 150)
            ->withHeaders([
                'User-Agent' => 'Mozilla/5.0 (compatible; EGC-BookMarks/1.0)',
                'Accept' => $image
                    ? 'image/avif,image/webp,image/png,image/jpeg,image/x-icon,*/*'
                    : 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.1',
            ]);
    }
}
