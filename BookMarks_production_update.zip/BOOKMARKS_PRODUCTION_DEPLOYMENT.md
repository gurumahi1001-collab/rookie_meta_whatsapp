# BookMarks production update

This patch updates only the BookMarks module and its supporting route/service files.

## Updated files

- `app/Http/Controllers/productivity/BookmarksController.php`
- `app/Services/FavIcon/BookmarkFaviconService.php`
- `resources/views/content/productivity/bookmarks/index.blade.php`
- `routes/web.php`

## Production behavior

- Bookmark icons are resolved from the target website itself (`rel=icon`, `shortcut icon`, `apple-touch-icon`, then `/favicon.ico`).
- No Google S2 favicon proxy is used for new BookMarks records.
- Existing Google S2 favicon values are refreshed when a bookmark is edited; the UI also uses the ERP favicon proxy for legacy rows until refreshed.
- Favicons are cached locally in the configured public storage under `favicons/bookmark_<hash>.ico`.
- Server-side favicon resolution accepts only HTTP/HTTPS public hosts and validates DNS/IP and redirects to reduce SSRF risk.
- Favicon endpoints are throttled at 30 requests/minute in addition to the existing productivity route throttle.
- Bookmark add/edit screens use board/category selectors loaded through AJAX rather than asking users for numeric IDs.
- Add, edit, remove, open, health check, move/copy, and HTML import flows are wired in the existing AJAX UI.
- Board/category management actions are wired; category deletion is blocked while active bookmarks still reference the category.
- Bookmark and board write paths validate target relationships and permissions server-side.
- HTML import is limited to a 10 MB upload and up to 500 valid public links per import; duplicate URLs are skipped.
- Audit records are written for create/update/archive/open/health/move/copy/import actions.
- The existing shared `FaviconService.php` was intentionally left unchanged so unrelated ERP modules using it are not affected.

## Deployment

Replace the four updated files in the corresponding project paths. No new database table or migration is required by this patch.

After deployment, clear the normal Laravel caches for the environment, then verify the BookMarks menu with:

1. Create a board and category.
2. Add a public URL and confirm the official favicon appears.
3. Edit the URL and confirm the favicon refreshes.
4. Test move/copy, health check, archive/remove, and HTML import.
5. Verify the application can write to the public storage disk used for cached favicons.
