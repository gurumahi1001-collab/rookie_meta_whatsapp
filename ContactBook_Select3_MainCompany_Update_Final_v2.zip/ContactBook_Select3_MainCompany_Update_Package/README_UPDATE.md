# ContactBook – Select3 + Main Company Update

Source: current `190926mvc.zip`.

Updated only:
- `app/Http/Controllers/productivity/ContactBookController.php`
- `resources/views/content/productivity/contactbook/index.blade.php`

Changes:
1. All ContactBook `<select>` controls now use the ERP `select3` class.
2. Dynamically rendered merge/import selects are also initialized as `select3`.
3. ContactBook company lookup includes the ERP main organisation as `id/value = 0`.
4. The main organisation display name is loaded from `egc_general_settings.title` through `GeneralSettingsModel`.
5. Main `0` is supported for create/edit, Company visibility, import defaults, lookup display, exports, and company name decoration.
6. Restricted users retain company-level visibility restrictions; the main option is exposed to Group Admin/Auditor and users whose own company context is `0`.
7. Select2 UI refreshes use `change.select2` so AJAX population does not trigger unrelated change handlers.
8. No ContactBook SQL/table changes were made.
9. No other productivity module files were changed.

Validation performed:
- PHP syntax check: passed for both modified Blade/PHP files.
- JavaScript syntax check: passed for the inline ContactBook JavaScript extracted from the Blade.
- Static diff confirmed the changes are isolated to the two ContactBook files above.

The application/database itself was not live-tested from this environment.
