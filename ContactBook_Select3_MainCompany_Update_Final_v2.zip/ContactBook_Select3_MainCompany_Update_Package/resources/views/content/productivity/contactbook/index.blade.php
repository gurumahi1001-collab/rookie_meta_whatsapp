@extends('layouts/layoutMaster')

@section('title', 'ContactBook')

@section('vendor-style')
@vite([
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
])
@endsection

@section('vendor-script')
@vite([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('content')
<style>
    .cb-page{
    --cb-primary:#8F1D1D;
    --cb-primary-2:#B52B25;
    --cb-gold:#F5A623;
    --cb-navy:#1F3864;
    --cb-ink:#202431;
    --cb-muted:#70798B;
    --cb-border:#E4E7EE;
    --cb-bg:#F6F7FA;
    --cb-green:#2E7D32;
    --cb-purple:#4A3E8E;
    --cb-blue:#1F618D;
    font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
    color:var(--cb-ink);
    background:var(--cb-bg);
    min-height:calc(100vh - 80px);
    padding-bottom:28px;
}

.cb-breadcrumb{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    padding:12px 18px 10px;
    color:#697284;
    font-size:12px;
}
.cb-breadcrumb-left{
    display:flex;
    align-items:center;
    gap:7px;
    min-width:0;
}
.cb-breadcrumb-left strong{color:var(--cb-primary)}
.cb-breadcrumb-icon{
    width:26px;
    height:26px;
    border-radius:8px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    background:#fff;
    border:1px solid var(--cb-border);
    color:var(--cb-primary);
}
.cb-top-actions{display:flex;gap:7px}

.cb-hero{
    margin:0 18px 16px;
    background:linear-gradient(115deg,#731414 0%,#8F1D1D 52%,#A62923 100%);
    border-radius:15px;
    padding:20px 22px;
    color:#fff;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:20px;
    box-shadow:0 12px 32px rgba(72,19,19,.14);
}
.cb-hero-main{display:flex;align-items:flex-start;gap:15px;min-width:0}
.cb-hero-icon{
    width:52px;height:52px;border-radius:14px;flex:0 0 52px;
    display:flex;align-items:center;justify-content:center;
    background:rgba(245,166,35,.18);
    border:1px solid rgba(245,166,35,.38);
    color:#F7C75F;font-size:26px;
}
.cb-kicker{
    font-size:10px;font-weight:800;letter-spacing:1.1px;opacity:.72;
    text-transform:uppercase;margin-bottom:4px;
}
.cb-hero h1{
    margin:0;font-size:25px;line-height:1.1;font-weight:800;letter-spacing:-.3px;
}
.cb-hero p{
    margin:7px 0 8px;font-size:12.5px;color:rgba(255,255,255,.77);
    max-width:780px;
}
.cb-hero-meta{display:flex;align-items:center;gap:8px;font-size:11px;color:rgba(255,255,255,.86)}
.cb-dot{width:4px;height:4px;border-radius:50%;background:#F5A623}
.cb-hero-actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.cb-btn-gold{
    background:var(--cb-gold);border-color:var(--cb-gold);color:#2C2110;font-weight:800;
}
.cb-btn-gold:hover,.cb-btn-gold:focus{background:#E99A13;border-color:#E99A13;color:#2C2110}
.cb-btn-outline-light{
    color:#fff!important;border:1px solid rgba(255,255,255,.34)!important;
    background:rgba(255,255,255,.07)!important;font-weight:700;
}
.cb-btn-outline-light:hover{background:rgba(255,255,255,.14)!important}

.cb-stat-grid{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:12px;
    margin:0 18px 16px;
}
.cb-stat-card{
    background:#fff;border:1px solid var(--cb-border);border-radius:13px;
    padding:14px 15px;display:flex;align-items:center;gap:12px;
    box-shadow:0 3px 12px rgba(31,56,100,.035);
}
.cb-stat-card.cb-stat-primary{border-top:3px solid var(--cb-primary)}
.cb-stat-icon{
    width:42px;height:42px;border-radius:11px;display:flex;align-items:center;justify-content:center;
    background:rgba(143,29,29,.08);color:var(--cb-primary);font-size:20px;flex:0 0 42px;
}
.cb-icon-gold{background:rgba(245,166,35,.13);color:#A56C00}
.cb-icon-blue{background:rgba(31,97,141,.10);color:var(--cb-blue)}
.cb-icon-purple{background:rgba(74,62,142,.10);color:var(--cb-purple)}
.cb-stat-card div:last-child{display:flex;flex-direction:column;min-width:0}
.cb-stat-card span{font-size:10.5px;color:var(--cb-muted);font-weight:700;text-transform:uppercase;letter-spacing:.45px}
.cb-stat-card strong{font-size:22px;line-height:1.05;margin:3px 0;color:#242936}
.cb-stat-card small{font-size:10px;color:#9298A7}

.cb-panel{
    margin:0 18px;
    background:#fff;border:1px solid var(--cb-border);border-radius:14px;
    box-shadow:0 7px 26px rgba(31,56,100,.045);overflow:hidden;
}
.cb-panel-head{
    padding:16px 17px 13px;display:flex;align-items:center;justify-content:space-between;gap:15px;
    border-bottom:1px solid #EEF0F4;
}
.cb-section-title{font-size:16px;font-weight:800;color:#202531}
.cb-section-subtitle{font-size:11px;color:#818899;margin-top:3px}
.cb-view-switch{
    display:flex;gap:3px;padding:3px;border:1px solid var(--cb-border);border-radius:9px;background:#F7F8FA;
}
.cb-view-switch button{
    border:0;background:transparent;color:#6F7789;padding:6px 10px;border-radius:7px;
    font-size:11px;font-weight:700;
}
.cb-view-switch button.active{background:#fff;color:var(--cb-primary);box-shadow:0 2px 7px rgba(31,56,100,.08)}

.cb-filter-bar{
    display:flex;gap:8px;align-items:center;padding:12px 15px;border-bottom:1px solid #EEF0F4;
    flex-wrap:wrap;
}
.cb-search-wrap{
    position:relative;display:flex;align-items:center;flex:1 1 280px;min-width:220px;
}
.cb-search-wrap>i{position:absolute;left:11px;color:#8B92A1;font-size:18px;z-index:2}
.cb-search-wrap .form-control{
    padding-left:37px;padding-right:35px;border-color:#DDE1E9;height:38px;border-radius:9px;font-size:12px;
}
.cb-search-clear{
    position:absolute;right:6px;border:0;background:transparent;color:#9299A8;font-size:18px;
}
.cb-filter-select{
    width:auto;min-width:145px;height:38px;border-color:#DDE1E9;border-radius:9px;
    font-size:11.5px;color:#4D5567;font-weight:600;
}
.cb-filter-more,.cb-btn-outline{
    border:1px solid #D8DCE5;background:#fff;color:#596174;font-size:11.5px;font-weight:700;height:38px;border-radius:9px;
}
.cb-filter-more:hover,.cb-btn-outline:hover,.cb-btn-soft:hover{border-color:#BFC5D2;background:#F8F9FB;color:#343B4B}
/* .cb-btn-primary{
    background:var(--cb-primary);border-color:var(--cb-primary);color:#fff;font-weight:800;border-radius:9px;
} */
/* .cb-btn-primary:hover,.cb-btn-primary:focus{background:var(--cb-primary-2);border-color:var(--cb-primary-2);color:#fff} */
.cb-btn-soft{
    border:1px solid #DCE0E8;background:#F8F9FB;color:#4E5668;font-weight:700;border-radius:9px;
}
.cb-filter-bar .btn{white-space:nowrap}

.cb-active-filters{
    display:flex;align-items:center;gap:6px;flex-wrap:wrap;padding:8px 15px;background:#FBFBFC;border-bottom:1px solid #EEF0F4
}
.cb-filter-chip{
    display:inline-flex;align-items:center;gap:4px;background:#F1F3F7;border:1px solid #E3E6ED;
    border-radius:30px;padding:4px 7px 4px 9px;color:#5F6675;font-size:10.5px;
}
.cb-filter-chip strong{color:#3D4556}
.cb-filter-chip button{border:0;background:none;padding:0;color:#8C93A2;line-height:1}
.cb-clear-all-filters{border:0;background:none;color:var(--cb-primary);font-size:10.5px;font-weight:800}
.cb-advanced-panel{padding:12px 15px;background:#FBFCFE;border-bottom:1px solid #EEF0F4}
.cb-advanced-grid{display:grid;grid-template-columns:1fr 1fr 1.5fr auto;gap:10px;align-items:end}
.cb-advanced-grid .form-label,.cb-import-config-card .form-label,.cb-modal .form-label{font-size:11px;font-weight:800;color:#444C5C;margin-bottom:5px}
.cb-advanced-grid .form-control,.cb-advanced-grid .form-select{height:37px;font-size:12px;border-radius:8px}
.cb-advanced-hint{font-size:10.5px;color:#7C8494;padding:8px 10px;background:#fff;border:1px dashed #DCE1E9;border-radius:8px}
.cb-advanced-hint i{color:var(--cb-primary)}
.cb-advanced-actions{display:flex;gap:6px}

.cb-bulk-bar{
    background:#FFF8E8;border-bottom:1px solid #F0DFB1;padding:9px 14px;
    display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;
}
.cb-bulk-count{font-size:11px;color:#6A531E;font-weight:800}
.cb-bulk-actions{display:flex;gap:5px;flex-wrap:wrap}
.cb-bulk-actions .btn{
    background:#fff;border:1px solid #E6D6AA;color:#66572E;border-radius:7px;font-size:10.5px;font-weight:700;padding:6px 8px;
}
.cb-bulk-actions .btn:hover{background:#FFFDF7}
.cb-bulk-clear{width:29px}

.cb-loading{
    padding:12px 15px;font-size:11px;color:#71798A;border-bottom:1px solid #EEF0F4;
    display:flex;align-items:center;gap:7px;
}
.cb-request-active .cb-btn-primary{cursor:wait}

.cb-table-wrap{width:100%;overflow:auto}
.cb-table{min-width:1180px}
.cb-table thead th{
    padding:10px 9px;background:#8F1D1D;color:#fff;border:0;
    font-size:10px;letter-spacing:.45px;font-weight:800;white-space:nowrap;
}
.cb-table thead th:first-child{border-top-left-radius:0}
.cb-table tbody td{
    padding:10px 9px;border-color:#EDF0F4;vertical-align:middle;font-size:11.5px;color:#323847;
}
.cb-table tbody tr{transition:background .12s}
.cb-table tbody tr:hover{background:#FCFCFE}
.cb-check-col{width:38px;text-align:center}
.cb-contact-cell{display:flex;align-items:center;gap:10px;min-width:205px}
.cb-table-avatar{
    width:38px;height:38px;border-radius:11px;overflow:hidden;background:#F1E7E6;border:1px solid #E7D1CE;
    display:flex;align-items:center;justify-content:center;color:var(--cb-primary);font-size:11px;font-weight:900;flex:0 0 38px;
}
.cb-table-avatar img{width:100%;height:100%;object-fit:cover}
.cb-contact-name{
    border:0;background:transparent;padding:0;color:#202633;font-weight:800;font-size:12px;cursor:pointer;
}
.cb-contact-name:hover{color:var(--cb-primary);text-decoration:underline}
.cb-contact-sub{font-size:10px;color:#7B8291;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:250px}
.cb-mini-tags{display:flex;gap:3px;margin-top:4px;flex-wrap:wrap}
.cb-mini-tags span{background:#F3F4F7;border:1px solid #E4E7EC;padding:2px 5px;border-radius:4px;font-size:9px;color:#71798A}
.cb-org-cell{display:flex;flex-direction:column;min-width:135px;max-width:220px}
.cb-org-cell strong{font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cb-org-cell small{font-size:9.5px;color:#8A91A0;margin-top:2px}
.cb-cell-line{display:flex;align-items:center;gap:3px;max-width:180px}
.cb-cell-line a{color:#4E576B;font-size:10.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cb-cell-line a:hover{color:var(--cb-primary)}
.cb-icon-copy{
    border:0;background:none;padding:1px 2px;color:#B1B6C1;cursor:pointer;line-height:1;
}
.cb-icon-copy:hover{color:var(--cb-primary)}
.cb-category-badge{
    display:inline-flex;align-items:center;gap:5px;border:1px solid #E2E5EC;border-radius:999px;
    padding:4px 7px;color:#566071;font-size:10px;background:#fff;white-space:nowrap;
}
.cb-cat-dot{width:6px;height:6px;border-radius:50%;background:var(--cb-cat,#C0392B)}
.cb-visibility{
    display:inline-flex;align-items:center;gap:4px;border-radius:999px;padding:4px 7px;font-size:9.5px;font-weight:800;
    white-space:nowrap;
}
.cb-vis-private{background:#F3F4F6;color:#636A78}
.cb-vis-company{background:#EEF5FB;color:#1F618D}
.cb-vis-group{background:#F2EDFB;color:#5C478F}
.cb-star-btn{
    border:0;background:transparent;color:#C2C6CF;padding:3px 4px;font-size:18px;line-height:1;cursor:pointer
}
.cb-star-btn:hover{color:#B88718}
.cb-star-btn.active{color:#F5A623}
.cb-row-more{border:0;background:transparent;color:#70798B;font-size:20px;padding:1px 4px}
.cb-row-menu{min-width:190px;padding:5px;border:1px solid #E0E4EB;box-shadow:0 10px 28px rgba(27,42,71,.12);border-radius:10px}
.cb-row-menu .dropdown-item{font-size:11px;border-radius:7px;padding:7px 9px}
.cb-row-menu .dropdown-item i{width:20px;color:#7A8292}
.cb-card-view{padding:13px}
.cb-contact-card{
    border:1px solid #E3E6EC;border-radius:12px;background:#fff;padding:14px;
    box-shadow:0 3px 11px rgba(31,56,100,.035);transition:.16s;display:flex;flex-direction:column;gap:10px
}
.cb-contact-card:hover{transform:translateY(-1px);box-shadow:0 8px 22px rgba(31,56,100,.08)}
.cb-card-view{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.cb-card-top{display:flex;align-items:center;justify-content:space-between;gap:9px}
.cb-card-person{display:flex;align-items:center;gap:9px;min-width:0}
.cb-card-avatar{
    width:42px;height:42px;border-radius:12px;background:#F2E8E6;color:var(--cb-primary);display:flex;align-items:center;justify-content:center;
    font-size:12px;font-weight:900;overflow:hidden;flex:0 0 42px
}
.cb-card-avatar img{width:100%;height:100%;object-fit:cover}
.cb-card-name{border:0;background:none;padding:0;color:#242A36;font-size:12px;font-weight:800;text-align:left}
.cb-card-role{font-size:9.5px;color:#808798;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:185px}
.cb-card-org{display:flex;align-items:center;gap:5px;font-size:10.5px;color:#5B6373}
.cb-card-org i{color:var(--cb-primary)}
.cb-card-info{display:grid;grid-template-columns:1fr;gap:5px}
.cb-card-info a,.cb-card-info span{font-size:10px;color:#636B79;display:flex;gap:6px;align-items:center}
.cb-card-info a:hover{color:var(--cb-primary)}
.cb-card-bottom{display:flex;flex-wrap:wrap;gap:5px}
.cb-card-actions{display:flex;gap:6px;margin-top:auto}
.cb-card-actions .btn{font-size:10px;height:32px;padding:5px 9px}
.cb-empty,.cb-error{padding:55px 20px;text-align:center}
.cb-empty-icon{
    width:58px;height:58px;border-radius:17px;background:#F5ECEB;color:var(--cb-primary);display:flex;align-items:center;justify-content:center;
    margin:0 auto 11px;font-size:27px
}
.cb-empty-error{background:#FEF0EE;color:#B02418}
.cb-empty h3,.cb-error h3{font-size:16px;margin:0 0 5px}
.cb-empty p,.cb-error p{font-size:11px;color:#858C99;margin:0 auto 14px;max-width:520px}
.cb-panel-foot{
    border-top:1px solid #EEF0F4;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;gap:12px;
}
.cb-result-summary{font-size:10.5px;color:#7D8492}
.cb-pagination{display:flex;align-items:center;gap:3px}
.cb-page-btn{
    min-width:29px;height:29px;padding:0 7px;border:1px solid #DFE3EA;background:#fff;color:#687082;border-radius:7px;font-size:10px;font-weight:800
}
.cb-page-btn:hover:not(:disabled){background:#F6F7F9;color:var(--cb-primary)}
.cb-page-btn.active{background:var(--cb-primary);border-color:var(--cb-primary);color:#fff}
.cb-page-btn:disabled{opacity:.45;cursor:not-allowed}
.cb-page-dots{font-size:10px;color:#A1A6B1;padding:0 3px}
.cb-empty-mini{font-size:10.5px;color:#858C99;padding:12px 0}
.cb-modal .modal-content{
    border:1px solid #E0E4EA;border-radius:14px;overflow:hidden;box-shadow:0 22px 60px rgba(31,56,100,.18)
}
.cb-modal .modal-header{
    background:#fff;border-bottom:1px solid #ECEEF3;padding:14px 17px
}
.cb-modal .modal-footer{border-top:1px solid #ECEEF3;padding:10px 15px;background:#FCFCFD}
.cb-modal-kicker{font-size:9.5px;letter-spacing:1.1px;font-weight:900;color:var(--cb-primary);margin-bottom:3px}
.cb-modal .modal-title{font-size:17px;font-weight:800;color:#252A36}
.cb-modal-subtitle{font-size:10.5px;color:#8A91A0;margin-top:3px}
.cb-modal-body{background:#F8F9FB;padding:15px}
.cb-form-section{
    background:#fff;border:1px solid #E4E7ED;border-radius:11px;padding:14px;margin-bottom:11px
}
.cb-form-section-head{display:flex;align-items:flex-start;gap:9px;margin-bottom:12px}
.cb-form-section-icon{
    width:31px;height:31px;border-radius:9px;background:#F7EDEE;color:var(--cb-primary);display:flex;align-items:center;justify-content:center;font-size:16px;flex:0 0 31px
}
.cb-fsi-gold{background:#FFF6E3;color:#B47B10}
.cb-fsi-purple{background:#F0ECFA;color:#5A4A91}
.cb-fsi-blue{background:#EAF3FA;color:#1F618D}
.cb-fsi-slate{background:#EEF1F3;color:#53626F}
.cb-form-section-head h6{margin:1px 0 2px;font-size:12px;font-weight:800}
.cb-form-section-head p{margin:0;font-size:9.5px;color:#89909D}
.cb-modal .form-control,.cb-modal .form-select{
    border-color:#DCE1E9;border-radius:8px;min-height:38px;font-size:11.5px;color:#343B49
}
.cb-modal textarea.form-control{min-height:78px;resize:vertical}
.cb-modal .form-control:focus,.cb-modal .form-select:focus{
    border-color:#B76460;box-shadow:0 0 0 3px rgba(143,29,29,.08)
}
.cb-modal .form-label span:first-child{color:#B02418}
.cb-optional{font-size:9px!important;color:#8B92A0!important;font-weight:600;margin-left:2px}
.cb-modal .form-text{font-size:9px;color:#9298A4}
.cb-input-action{border-color:#DCE1E9;background:#F8F9FA;color:#717989}
.cb-favourite-toggle{padding:9px 10px;background:#FFF9EC;border:1px solid #F1E2B8;border-radius:8px}
.cb-favourite-toggle .form-check-label{font-size:10.5px;font-weight:700;color:#6F5B27}
.cb-modal .modal-header .btn-close{margin-left:12px}
.cb-view-head-actions{display:flex;align-items:center;gap:5px}
.cb-view-body{padding:15px;background:#F7F8FA}
.cb-profile-banner{
    display:flex;align-items:center;gap:14px;padding:16px;background:linear-gradient(110deg,#8F1D1D,#A72A24);
    border-radius:12px;color:#fff
}
.cb-profile-avatar{width:58px;height:58px;border-radius:16px;background:rgba(245,166,35,.19);border:1px solid rgba(245,166,35,.35);display:flex;align-items:center;justify-content:center;font-size:17px;font-weight:900;overflow:hidden;flex:0 0 58px}
.cb-profile-avatar img{width:100%;height:100%;object-fit:cover}
.cb-profile-name{font-size:18px;font-weight:900}
.cb-profile-role{font-size:10.5px;color:rgba(255,255,255,.74);margin-top:2px}
.cb-profile-org{font-size:11px;color:#fff;font-weight:700;margin-top:3px}
.cb-profile-chips{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}
.cb-profile-chips .cb-category-badge,.cb-profile-chips .cb-visibility{
    background:rgba(255,255,255,.13);border-color:rgba(255,255,255,.22);color:#fff
}
.cb-profile-quick{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;margin-left:auto}
.cb-quick-btn{border:1px solid rgba(255,255,255,.28);color:#fff!important;background:rgba(255,255,255,.08);font-size:10px;border-radius:8px}
.cb-quick-btn:hover{background:rgba(255,255,255,.15)}
.cb-view-card{background:#fff;border:1px solid #E4E7ED;border-radius:11px;padding:12px;margin-bottom:12px}
.cb-view-card-head{display:flex;align-items:center;gap:7px;font-size:10.5px;font-weight:800;color:#353C4A;padding-bottom:9px;border-bottom:1px solid #EEF0F4}
.cb-view-card-head i{color:var(--cb-primary);font-size:17px}
.cb-detail-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0}
.cb-detail-item{padding:9px 7px;border-bottom:1px solid #F0F2F5;min-width:0}
.cb-detail-item span{display:block;color:#9097A5;font-size:9px;margin-bottom:3px}
.cb-detail-item strong{font-size:10.5px;color:#383F4E;word-break:break-word}
.cb-detail-item a{color:var(--cb-primary)}
.cb-view-tags{display:flex;gap:4px;flex-wrap:wrap;padding:10px 0 6px}
.cb-note-tag{padding:4px 6px;background:#F4F5F7;border:1px solid #E5E7EC;border-radius:6px;color:#6C7483;font-size:9px}
.cb-view-notes{font-size:10px;color:#626A79;line-height:1.6}
.cb-note-content{padding:8px 0 2px;white-space:normal}
.cb-timeline{padding-top:8px}
.cb-timeline-item{display:flex;gap:9px;padding:8px 2px;border-bottom:1px solid #F0F2F5}
.cb-timeline-dot{width:7px;height:7px;border-radius:50%;background:var(--cb-primary);margin-top:5px;box-shadow:0 0 0 3px #F5E9E8;flex:0 0 7px}
.cb-timeline-item strong{display:block;font-size:10px;color:#414857;text-transform:capitalize}
.cb-timeline-item span{display:block;font-size:9px;color:#969CA8;margin-top:2px}
.cb-knowledge-item{
    width:100%;border:0;background:#fff;text-align:left;padding:9px 2px;display:flex;align-items:center;gap:7px;
    border-bottom:1px solid #F0F2F5
}
.cb-knowledge-item i{font-size:16px;color:var(--cb-primary)}
.cb-knowledge-item strong{display:block;font-size:10px;color:#3F4654}
.cb-knowledge-item small{display:block;font-size:8.5px;color:#9298A4;margin-top:2px}
.cb-modal-loader{padding:18px;text-align:center;color:#848B99;font-size:10.5px}
.cb-duplicate-alert{display:flex;gap:10px;padding:11px 12px;background:#FFF8E8;border:1px solid #EDD79B;border-radius:10px;margin-bottom:11px;color:#6B5729}
.cb-duplicate-icon{width:32px;height:32px;border-radius:9px;background:#FCECC5;display:flex;align-items:center;justify-content:center;font-size:17px;color:#B47B10;flex:0 0 32px}
.cb-duplicate-alert strong{font-size:11px}
.cb-duplicate-matches{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;margin-top:7px}
.cb-duplicate-item{display:flex;align-items:center;gap:7px;background:#fff;border:1px solid #F0E5C6;border-radius:8px;padding:6px}
.cb-duplicate-avatar{width:25px;height:25px;border-radius:7px;background:#F5ECEB;color:var(--cb-primary);display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:900}
.cb-duplicate-item strong{display:block;font-size:9.5px;color:#4C5360}
.cb-duplicate-item span{display:block;font-size:8px;color:#9298A3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:210px}
.cb-duplicate-actions{display:flex;gap:5px;margin-top:8px}
.cb-btn-danger-outline{border:1px solid #D9A5A1;background:#fff;color:#A32A24;border-radius:7px;font-weight:700}
.cb-form-error{padding:9px 10px;background:#FEF0EE;border:1px solid #F2C6C2;border-radius:8px;color:#A52E27;font-size:10px}
.cb-export-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.cb-export-card{border:1px solid #E0E4EB;background:#fff;border-radius:11px;padding:14px 9px;text-align:center;display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer}
.cb-export-card:hover{border-color:#C9A6A3;background:#FFF8F7}
.cb-export-card i{font-size:25px;color:var(--cb-primary)}
.cb-export-card strong{font-size:10.5px;color:#3D4553}
.cb-export-card span{font-size:8.5px;color:#9097A3}
.cb-export-note{margin-top:11px;padding:8px 9px;background:#F7F8FA;border-radius:8px;font-size:9px;color:#808896;display:flex;gap:6px}
.cb-export-note i{color:var(--cb-green)}
.cb-import-stepper{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:13px}
.cb-import-stepper>div{display:flex;align-items:center;gap:7px;padding:8px 10px;border:1px solid #E0E4EB;border-radius:8px;background:#fff;color:#9298A5;font-size:9px}
.cb-import-stepper>div span{width:21px;height:21px;border-radius:50%;background:#EEF0F4;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:800}
.cb-import-stepper>div.active{border-color:#D8B0AC;background:#FFF8F7;color:var(--cb-primary)}
.cb-import-stepper>div.active span,.cb-import-stepper>div.done span{background:var(--cb-primary);color:#fff}
.cb-import-stepper>div.done{border-color:#DCE9DF;color:#2E7D32;background:#F7FBF8}
.cb-import-option{background:#fff;border:1px solid #E3E7ED;border-radius:11px;padding:15px;min-height:190px;display:flex;flex-direction:column}
.cb-import-option-icon{width:39px;height:39px;border-radius:10px;background:#F6EDEC;color:#A52A24;display:flex;align-items:center;justify-content:center;font-size:21px;margin-bottom:8px}
.cb-import-option-icon.gold{background:#FFF5E0;color:#AA7512}
.cb-import-option-icon.blue{background:#EAF2F9;color:#1F618D}
.cb-import-option h6{font-size:12px;font-weight:800;margin:0}
.cb-import-option p{font-size:9.5px;color:#8B92A0;line-height:1.5;margin:5px 0 12px;flex:1}
.cb-import-template{margin-top:12px;padding:10px 11px;background:#fff;border:1px dashed #D8DDE6;border-radius:9px;display:flex;align-items:center;justify-content:space-between;gap:10px}
.cb-import-template>div{display:flex;align-items:center;gap:8px}
.cb-import-template i{font-size:20px;color:var(--cb-primary)}
.cb-import-template strong{display:block;font-size:10.5px}
.cb-import-template span{display:block;font-size:8.8px;color:#9298A4;margin-top:2px}
.cb-import-file-summary{display:flex;align-items:center;gap:9px;padding:10px;background:#fff;border:1px solid #E1E5EB;border-radius:9px;margin-bottom:10px}
.cb-file-summary-icon{width:34px;height:34px;border-radius:8px;background:#EAF4EC;color:#2E7D32;display:flex;align-items:center;justify-content:center;font-size:18px}
.cb-import-file-summary strong{display:block;font-size:10.5px}
.cb-import-file-summary span{display:block;font-size:8.8px;color:#9097A4;margin-top:2px}
.cb-import-config-card,.cb-import-map-card{background:#fff;border:1px solid #E3E7ED;border-radius:10px;padding:11px;margin-bottom:10px}
.cb-import-map{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;margin-top:10px}
.cb-import-map-row{display:grid;grid-template-columns:1fr 1.2fr;gap:8px;align-items:center;padding:7px;border:1px solid #EEF0F3;border-radius:7px;background:#FBFCFD}
.cb-import-map-row strong{display:block;font-size:9.5px;color:#4B5361}
.cb-import-map-row span{display:block;font-size:8px;color:#9A9FAA;margin-top:1px}
.cb-import-map-row .form-select{height:31px;font-size:9.5px;padding-top:4px;padding-bottom:4px}
.cb-import-preview-wrap{overflow:auto;margin-top:9px}
.cb-import-preview-table{min-width:700px}
.cb-import-preview-table th{font-size:8.5px;background:#F5F7FA;color:#6A7282;white-space:nowrap}
.cb-import-preview-table td{font-size:8.8px;color:#505867;max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cb-import-complete{text-align:center;padding:22px 10px}
.cb-import-complete-icon{width:55px;height:55px;border-radius:18px;background:#EAF5ED;color:#2E7D32;display:flex;align-items:center;justify-content:center;margin:0 auto 9px;font-size:28px}
.cb-import-complete h4{font-size:17px;font-weight:800;margin:0}
.cb-import-complete p{font-size:10px;color:#8C93A0;margin:4px 0 0}
.cb-import-result-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
.cb-import-result-grid>div{background:#fff;border:1px solid #E2E6EC;border-radius:9px;padding:13px;text-align:center}
.cb-import-result-grid strong{display:block;font-size:21px;color:#29303D}
.cb-import-result-grid span{font-size:8.5px;color:#8A91A0;text-transform:uppercase;letter-spacing:.45px}
.cb-import-error{padding:9px;background:#FEF0EE;border:1px solid #F2C6C2;border-radius:8px;color:#A72A25;font-size:9.5px}
.cb-danger-box{display:flex;gap:9px;padding:11px;border-radius:9px;background:#FFF5F4;border:1px solid #F0C9C6;color:#9F302A}
.cb-danger-box i{font-size:19px}
.cb-danger-box strong{display:block;font-size:10.5px}
.cb-danger-box span{display:block;font-size:9px;margin-top:2px;color:#9C7571}
.cb-merge-contacts{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}
.cb-merge-person{display:flex;align-items:center;gap:7px;border:1px solid #E2E6EC;background:#fff;border-radius:9px;padding:7px 9px;cursor:pointer;min-width:200px}
.cb-merge-person.selected{border-color:#C99D99;background:#FFF7F6}
.cb-merge-person input{margin-right:1px}
.cb-merge-avatar{width:28px;height:28px;border-radius:8px;background:#F4EAE8;color:var(--cb-primary);display:flex;align-items:center;justify-content:center;font-size:8px;font-weight:900}
.cb-merge-person strong{display:block;font-size:9.5px}
.cb-merge-person small{display:block;font-size:8px;color:#9298A4;max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cb-merge-grid-wrap{overflow:auto;border:1px solid #E3E7ED;border-radius:9px}
.cb-merge-table{min-width:800px}
.cb-merge-table th{background:#F6F7F9;font-size:9px;color:#687082}
.cb-merge-table td{font-size:9.5px;vertical-align:middle;border-color:#EEF0F4}
.cb-merge-field{height:32px;font-size:9px}
.cb-share-card{background:#fff;border:1px solid #E3E7ED;border-radius:10px;padding:11px}
.cb-share-existing{background:#fff;border:1px solid #E3E7ED;border-radius:10px;padding:11px}
.cb-existing-share{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 2px;border-bottom:1px solid #EEF0F3}
.cb-existing-share:last-child{border-bottom:0}
.cb-existing-share strong{font-size:9.5px;text-transform:capitalize}
.cb-existing-share span{display:block;font-size:8.5px;color:#8A92A0;margin-top:1px}
.cb-share-permission{padding:3px 6px;border-radius:999px;background:#EFF4FB;color:#1F618D;font-size:8px;font-weight:800}
.cb-google-groups{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}
.cb-google-all,.cb-google-group{
    display:flex;align-items:center;gap:8px;padding:9px;background:#fff;border:1px solid #E2E6EC;border-radius:8px;cursor:pointer
}
.cb-google-all{grid-column:1/-1;background:#FFF9EB;border-color:#E9D69C}
.cb-google-group:hover{background:#FBFCFE}
.cb-google-all span,.cb-google-group span{min-width:0}
.cb-google-all strong,.cb-google-group strong{display:block;font-size:9.8px}
.cb-google-all small,.cb-google-group small{display:block;font-size:8.3px;color:#9097A4;margin-top:2px}
.cb-saved-search-list{display:flex;flex-direction:column;gap:5px}
.cb-saved-search{
    width:100%;display:flex;align-items:center;gap:8px;border:1px solid #E3E7ED;background:#fff;border-radius:9px;padding:9px;text-align:left
}
.cb-saved-search:hover{background:#FBFCFD;border-color:#D4D9E2}
.cb-saved-search>i:first-child{font-size:17px;color:var(--cb-primary)}
.cb-saved-search span{flex:1;min-width:0}
.cb-saved-search strong{display:block;font-size:10px;color:#3B4250;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cb-saved-search small{display:block;font-size:8px;color:#9399A6;margin-top:2px}
.cb-saved-search>i:last-child{color:#A4AAB5}

.cb-toast-stack{
    position:fixed;right:18px;bottom:18px;z-index:2000;display:flex;flex-direction:column;gap:7px;width:min(360px,calc(100vw - 36px))
}
.cb-toast{
    display:flex;align-items:center;gap:8px;padding:9px 10px;background:#fff;border:1px solid #E0E4EA;border-radius:10px;
    box-shadow:0 12px 28px rgba(31,56,100,.16);font-size:10.5px;color:#46505F;animation:cb-toast-in .18s ease
}
.cb-toast>i{font-size:17px}
.cb-toast-message{flex:1}
.cb-toast-close{border:0;background:none;color:#A0A6B1;padding:0;line-height:1}
.cb-toast-success>i{color:#2E7D32}
.cb-toast-error>i{color:#B02418}
.cb-toast-warning>i{color:#B8860B}
@keyframes cb-toast-in{from{transform:translateY(8px);opacity:0}to{transform:none;opacity:1}}

@media (max-width:1199.98px){
    .cb-stat-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
    .cb-card-view{grid-template-columns:repeat(2,minmax(0,1fr))}
    .cb-advanced-grid{grid-template-columns:1fr 1fr}
}
@media (max-width:767.98px){
    .cb-page{min-height:calc(100vh - 60px)}
    .cb-breadcrumb,.cb-hero,.cb-panel,.cb-stat-grid{margin-left:10px;margin-right:10px}
    .cb-breadcrumb{padding-left:0;padding-right:0}
    .cb-top-actions{display:none}
    .cb-hero{padding:15px;flex-direction:column;align-items:flex-start}
    .cb-hero-actions{width:100%;justify-content:flex-start}
    .cb-hero h1{font-size:21px}
    .cb-stat-grid{grid-template-columns:1fr 1fr;gap:8px}
    .cb-stat-card{padding:11px}
    .cb-stat-icon{width:37px;height:37px;flex-basis:37px;font-size:18px}
    .cb-stat-card strong{font-size:18px}
    .cb-stat-card small{display:none}
    .cb-panel-head{align-items:flex-start;flex-direction:column}
    .cb-view-switch{width:100%}
    .cb-view-switch button{flex:1}
    .cb-filter-select{flex:1 1 130px;min-width:0}
    .cb-search-wrap{flex-basis:100%}
    .cb-advanced-grid{grid-template-columns:1fr}
    .cb-advanced-actions{justify-content:flex-end}
    .cb-card-view{grid-template-columns:1fr}
    .cb-panel-foot{align-items:flex-start;flex-direction:column}
    .cb-pagination{width:100%;justify-content:flex-end}
    .cb-profile-banner{align-items:flex-start;flex-wrap:wrap}
    .cb-profile-quick{margin-left:0;width:100%}
    .cb-detail-grid{grid-template-columns:1fr}
    .cb-duplicate-matches,.cb-import-map,.cb-google-groups{grid-template-columns:1fr}
    .cb-google-all{grid-column:auto}
    .cb-import-stepper strong{display:none}
    .cb-import-stepper>div{justify-content:center}
    .cb-import-result-grid{grid-template-columns:1fr 1fr}
}


.cb-import-validation-list{display:flex;flex-direction:column;gap:4px;margin-top:9px;margin-bottom:9px;max-height:220px;overflow:auto}
.cb-validation-row{display:grid;grid-template-columns:150px 50px minmax(120px,1fr) minmax(180px,1.5fr);gap:7px;align-items:center;padding:6px 7px;background:#FBFCFD;border:1px solid #EDF0F3;border-radius:7px}
.cb-validation-status{display:inline-flex;align-items:center;gap:4px;width:max-content;padding:3px 6px;border-radius:999px;font-size:8px;font-weight:800}
.cb-validation-ready{background:#EAF5ED;color:#2E7D32}
.cb-validation-duplicate{background:#FFF5DC;color:#A86D00}
.cb-validation-invalid{background:#FEF0EE;color:#A72A25}
.cb-validation-row>strong{font-size:8.5px;color:#707887}
.cb-validation-name{font-size:9.2px;color:#3E4653;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cb-validation-row>small{font-size:8.2px;color:#9198A4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
@media (max-width:767.98px){
    .cb-validation-row{grid-template-columns:1fr 1fr}
    .cb-validation-status{grid-column:1}
    .cb-validation-row>strong{grid-column:2}
    .cb-validation-name,.cb-validation-row>small{grid-column:1/-1}
}

</style>
<div
    id="cbContactBook"
    class="cb-page"
    data-list-url="{{ route('productivity.contacts.data') }}"
    data-lookups-url="{{ route('productivity.contacts.lookups') }}"
    data-show-url="{{ url('/productivity/contactbook/__ID__') }}"
    data-store-url="{{ route('productivity.contacts.store') }}"
    data-update-url="{{ url('/productivity/contactbook/__ID__') }}"
    data-delete-url="{{ url('/productivity/contactbook/__ID__') }}"
    data-star-url="{{ url('/productivity/contactbook/__ID__/star') }}"
    data-restore-url="{{ url('/productivity/contactbook/__ID__/restore') }}"
    data-duplicate-url="{{ route('productivity.contacts.duplicates') }}"
    data-merge-preview-url="{{ route('productivity.contacts.merge.preview') }}"
    data-merge-url="{{ route('productivity.contacts.merge') }}"
    data-bulk-url="{{ route('productivity.contacts.bulk') }}"
    data-search-history-url="{{ route('productivity.contacts.search.history') }}"
    data-search-save-url="{{ route('productivity.contacts.search.save') }}"
    data-import-template-url="{{ route('productivity.contacts.import.template') }}"
    data-import-preview-url="{{ route('productivity.contacts.import.preview') }}"
    data-import-commit-url="{{ route('productivity.contacts.import.commit') }}"
    data-import-report-url="{{ url('/productivity/contactbook/import/__ID__/report') }}"
    data-google-connect-url="{{ route('productivity.contacts.google.connect') }}"
    data-google-groups-url="{{ route('productivity.contacts.google.groups') }}"
    data-google-import-url="{{ route('productivity.contacts.google.import') }}"
    data-share-data-url="{{ route('productivity.shares.data') }}"
    data-share-store-url="{{ route('productivity.shares.store') }}"
    data-share-revoke-url="{{ url('/productivity/shares/__ID__/revoke') }}"
    data-export-csv-url="{{ route('productivity.contacts.export.csv') }}"
    data-export-xlsx-url="{{ route('productivity.contacts.export.xlsx') }}"
    data-export-vcard-url="{{ route('productivity.contacts.export.vcard') }}"
    data-csrf="{{ csrf_token() }}"
>
    <div class="cb-breadcrumb">
        <div class="cb-breadcrumb-left">
            <span class="cb-breadcrumb-icon"><i class="mdi mdi-home-outline"></i></span>
            <span>Home</span>
            <i class="mdi mdi-chevron-right"></i>
            <span>Tool Management</span>
            <i class="mdi mdi-chevron-right"></i>
            <strong>ContactBook</strong>
        </div>
        <div class="cb-top-actions">
            <button type="button" class="btn cb-btn-soft" id="cbRefreshBtn" title="Refresh">
                <i class="mdi mdi-refresh"></i>
                <span class="d-none d-sm-inline">Refresh</span>
            </button>
            <button type="button" class="btn cb-btn-soft" id="cbSavedSearchBtn">
                <i class="mdi mdi-history"></i>
                <span class="d-none d-sm-inline">Saved searches</span>
            </button>
        </div>
    </div>

    <div class="cb-hero">
        <div class="cb-hero-main">
            <div class="cb-hero-icon"><i class="mdi mdi-account-box-multiple-outline"></i></div>
            <div>
                <!-- <div class="cb-kicker">TOOL MANAGEMENT</div> -->
                <h1 class="text-white">ContactBook</h1>
                <p id="cbHeroSubtitle">People, companies, colleges, vendors and partners in one governed contact workspace.</p>
                <div class="cb-hero-meta">
                    <span id="cbHeroCount">0 contacts</span>
                    <span class="cb-dot"></span>
                    <span id="cbHeroScope">Current company</span>
                </div>
            </div>
        </div>

        <div class="cb-hero-actions">
            <button type="button" class="btn cb-btn-outline-light" id="cbExportBtn">
                <i class="mdi mdi-download-outline"></i> Export
            </button>
            <button type="button" class="btn cb-btn-outline-light" id="cbImportBtn">
                <i class="mdi mdi-upload-outline"></i> Import
            </button>
            <button type="button" class="btn cb-btn-gold" id="cbAddBtn">
                <i class="mdi mdi-plus"></i> Add contact
            </button>
        </div>
    </div>

    <div class="cb-stat-grid" id="cbStats">
        <div class="cb-stat-card cb-stat-primary">
            <div class="cb-stat-icon"><i class="mdi mdi-account-group-outline"></i></div>
            <div><span>Total contacts</span><strong id="cbStatTotal">0</strong><small>Visible in your current scope</small></div>
        </div>
        <div class="cb-stat-card">
            <div class="cb-stat-icon cb-icon-gold"><i class="mdi mdi-star-outline"></i></div>
            <div><span>Favourites</span><strong id="cbStatStarred">0</strong><small>Starred contacts</small></div>
        </div>
        <div class="cb-stat-card">
            <div class="cb-stat-icon cb-icon-blue"><i class="mdi mdi-office-building-outline"></i></div>
            <div><span>Company shared</span><strong id="cbStatCompany">0</strong><small>Visible to a company</small></div>
        </div>
        <div class="cb-stat-card">
            <div class="cb-stat-icon cb-icon-purple"><i class="mdi mdi-account-multiple-outline"></i></div>
            <div><span>Group shared</span><strong id="cbStatGroup">0</strong><small>Group-wide or selected users</small></div>
        </div>
    </div>

    <div class="cb-panel">
        <div class="cb-panel-head">
            <div>
                <div class="cb-section-title">Contacts</div>
                <div class="cb-section-subtitle">Search, filter, share and manage your contact directory without leaving the page.</div>
            </div>
            <div class="cb-view-switch" role="group" aria-label="Contact view">
                <button type="button" class="active" data-cb-view="table"><i class="mdi mdi-table-large"></i> Table</button>
                <button type="button" data-cb-view="cards"><i class="mdi mdi-view-grid-outline"></i> Cards</button>
            </div>
        </div>

        <div class="cb-filter-bar">
            <div class="cb-search-wrap">
                <i class="mdi mdi-magnify"></i>
                <input type="search" id="cbSearch" class="form-control" autocomplete="off"
                       placeholder="Search name, organisation, phone, email, city or tag…">
                <button type="button" class="cb-search-clear d-none" id="cbSearchClear"><i class="mdi mdi-close-circle"></i></button>
            </div>

            <select id="cbFilterCategory" class="form-select select3 cb-filter-select">
                <option value="">All categories</option>
            </select>

            <select id="cbFilterVisibility" class="form-select select3 cb-filter-select">
                <option value="">All visibility</option>
                <option value="Private">Private</option>
                <option value="Company">Company</option>
                <option value="Group">Group</option>
            </select>

            <select id="cbFilterCompany" class="form-select select3 cb-filter-select d-none d-xl-block">
                <option value="">All companies</option>
            </select>

            <button type="button" class="btn cb-filter-more" id="cbAdvancedFilterBtn">
                <i class="mdi mdi-tune-variant"></i>
                <span>Filters</span>
            </button>

            <button type="button" class="btn cb-btn-outline" id="cbSaveSearchBtn" title="Save current search">
                <i class="mdi mdi-bookmark-plus-outline"></i>
            </button>
        </div>

        <div class="cb-active-filters d-none" id="cbActiveFilters"></div>

        <div class="cb-bulk-bar d-none" id="cbBulkBar">
            <div class="cb-bulk-count"><span id="cbSelectedCount">0</span> selected</div>
            <div class="cb-bulk-actions">
                <button type="button" class="btn" data-cb-bulk="category"><i class="mdi mdi-shape-outline"></i> Re-categorise</button>
                <button type="button" class="btn" data-cb-bulk="visibility"><i class="mdi mdi-eye-outline"></i> Change visibility</button>
                <button type="button" class="btn" data-cb-bulk="tag"><i class="mdi mdi-tag-plus-outline"></i> Add tags</button>
                <button type="button" class="btn text-danger" data-cb-bulk="deactivate"><i class="mdi mdi-account-off-outline"></i> Deactivate</button>
                <button type="button" class="btn cb-bulk-clear" id="cbClearSelection"><i class="mdi mdi-close"></i></button>
            </div>
        </div>

        <div id="cbAdvancedFilterPanel" class="cb-advanced-panel d-none">
            <div class="cb-advanced-grid">
                <div>
                    <label class="form-label">City</label>
                    <input type="text" id="cbFilterCity" class="form-control" placeholder="e.g. Madurai">
                </div>
                <div>
                    <label class="form-label">Company scope</label>
                    <select id="cbFilterCompanyAdvanced" class="form-select select3">
                        <option value="">All companies</option>
                    </select>
                </div>
                <div class="cb-advanced-hint">
                    <i class="mdi mdi-information-outline"></i>
                    Company and Group visibility are still controlled by server-side access rules.
                </div>
                <div class="cb-advanced-actions">
                    <button type="button" class="btn cb-btn-soft" id="cbClearFilters">Clear</button>
                    <button type="button" class="btn cb-btn-primary btn-primary" id="cbApplyFilters">Apply filters</button>
                </div>
            </div>
        </div>

        <div class="cb-loading d-none" id="cbLoading">
            <div class="spinner-border spinner-border-sm"></div>
            <span>Loading contacts…</span>
        </div>

        <div class="cb-table-wrap" id="cbTableView">
            <table class="table cb-table align-middle mb-0">
                <thead>
                    <tr>
                        <th class="cb-check-col">
                            <input class="form-check-input" type="checkbox" id="cbSelectAll" aria-label="Select all">
                        </th>
                        <th>CONTACT</th>
                        <th>COMPANY / COLLEGE</th>
                        <th>PHONE</th>
                        <th>EMAIL</th>
                        <th>CATEGORY</th>
                        <th>VISIBILITY</th>
                        <th class="text-center">FAV</th>
                        <th class="text-end">ACTION</th>
                    </tr>
                </thead>
                <tbody id="cbTableBody"></tbody>
            </table>
        </div>

        <div class="cb-card-view d-none" id="cbCardView"></div>

        <div class="cb-empty d-none" id="cbEmptyState">
            <div class="cb-empty-icon"><i class="mdi mdi-account-search-outline"></i></div>
            <h3>No contacts found</h3>
            <p>Try changing your search or filters, or add the first contact to this scope.</p>
            <button type="button" class="btn cb-btn-primary btn-primary" id="cbEmptyAddBtn"><i class="mdi mdi-plus"></i> Add contact</button>
        </div>

        <div class="cb-error d-none" id="cbErrorState">
            <div class="cb-empty-icon cb-empty-error"><i class="mdi mdi-cloud-alert-outline"></i></div>
            <h3>Couldn't load ContactBook</h3>
            <p id="cbErrorMessage">The server didn't respond. Your existing data is safe.</p>
            <button type="button" class="btn cb-btn-primary btn-primary" id="cbRetryBtn"><i class="mdi mdi-refresh"></i> Retry</button>
        </div>

        <div class="cb-panel-foot">
            <div class="cb-result-summary" id="cbResultSummary">Showing 0 contacts</div>
            <div class="cb-pagination" id="cbPagination"></div>
        </div>
    </div>
</div>

{{-- Advanced Filter / Contact Modal --}}
<div class="modal fade cb-modal" id="cbContactModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="cb-modal-kicker" id="cbContactKicker">CONTACTBOOK</div>
                    <h5 class="modal-title" id="cbContactTitle">Add contact</h5>
                    <div class="cb-modal-subtitle">Keep the profile complete today, or start with the essentials and enrich it later.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form id="cbContactForm" novalidate>
                <input type="hidden" name="force_duplicate" id="cbForceDuplicate" value="0">
                <input type="hidden" name="owner_user_id" id="cbOwnerUserId" value="">

                <div class="modal-body cb-modal-body">
                    <div id="cbDuplicateAlert" class="cb-duplicate-alert d-none">
                        <div class="cb-duplicate-icon"><i class="mdi mdi-alert-outline"></i></div>
                        <div class="flex-grow-1">
                            <strong>Possible duplicate contact</strong>
                            <div id="cbDuplicateText" class="small mt-1"></div>
                            <div id="cbDuplicateMatches" class="cb-duplicate-matches"></div>
                            <div class="cb-duplicate-actions">
                                <button type="button" class="btn btn-sm cb-btn-soft" id="cbOpenDuplicateBtn">
                                    <i class="mdi mdi-account-search-outline"></i> Open existing
                                </button>
                                <button type="button" class="btn btn-sm cb-btn-danger-outline" id="cbKeepDuplicateBtn">
                                    Keep both
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="cb-form-section">
                        <div class="cb-form-section-head">
                            <div class="cb-form-section-icon"><i class="mdi mdi-account-outline"></i></div>
                            <div><h6>Contact identity</h6><p>Name and professional identity</p></div>
                        </div>

                        <div class="row g-3">
                            <div class="col-12 col-md-2">
                                <label class="form-label">Salutation</label>
                                <select name="salutation" id="cbSalutation" class="form-select select3" data-placeholder="Salutation">
                                    <option value="">None</option>
                                    <option>Mr.</option>
                                    <option>Mrs.</option>
                                    <option>Ms.</option>
                                    <option>Dr.</option>
                                    <option>Prof.</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-5">
                                <label class="form-label">Full name <span>*</span></label>
                                <input type="text" name="person_name" id="cbPersonName" class="form-control" maxlength="180"
                                       placeholder="e.g. Dr. R. Karthik" required>
                                <div class="invalid-feedback">Full name is required.</div>
                            </div>
                            <div class="col-12 col-md-5">
                                <label class="form-label">Position / Designation</label>
                                <input type="text" name="designation" id="cbDesignation" class="form-control" maxlength="150"
                                       placeholder="Principal, HR Lead, IT Manager…">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Company / College / Organisation</label>
                                <input type="text" name="organisation" id="cbOrganisation" class="form-control" maxlength="180"
                                       placeholder="SVN College">
                            </div>
                            <div class="col-12 col-md-3">
                                <label class="form-label">Department</label>
                                <input type="text" name="department" id="cbDepartment" class="form-control" maxlength="150"
                                       placeholder="Administration">
                            </div>
                            <div class="col-12 col-md-3">
                                <label class="form-label">City / Location</label>
                                <input type="text" name="city" id="cbCity" class="form-control" maxlength="100" placeholder="Madurai">
                            </div>
                        </div>
                    </div>

                    <div class="cb-form-section">
                        <div class="cb-form-section-head">
                            <div class="cb-form-section-icon cb-fsi-gold"><i class="mdi mdi-phone-outline"></i></div>
                            <div><h6>Communication</h6><p>Primary and alternate ways to reach this contact</p></div>
                        </div>

                        <div class="row g-3">
                            <div class="col-12 col-md-6">
                                <label class="form-label">Primary phone</label>
                                <div class="input-group">
                                    <input type="text" name="phone_primary" id="cbPhonePrimary" class="form-control"
                                           maxlength="40" placeholder="+91 98430 55621">
                                    <button type="button" class="btn cb-input-action" id="cbCallPreview" title="Call"><i class="mdi mdi-phone-outline"></i></button>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Alternate phone</label>
                                <input type="text" name="phone_alternate" id="cbPhoneAlternate" class="form-control" maxlength="40"
                                       placeholder="Secondary number">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Primary email</label>
                                <div class="input-group">
                                    <input type="email" name="email_primary" id="cbEmailPrimary" class="form-control" maxlength="180"
                                           placeholder="name@organisation.in">
                                    <button type="button" class="btn cb-input-action" id="cbMailPreview" title="Email"><i class="mdi mdi-email-outline"></i></button>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Secondary email</label>
                                <input type="email" name="email_secondary" id="cbEmailSecondary" class="form-control" maxlength="180"
                                       placeholder="Alternate email">
                            </div>
                            <div class="col-12 col-md-8">
                                <label class="form-label">Website</label>
                                <input type="url" name="website" id="cbWebsite" class="form-control" maxlength="255"
                                       placeholder="https://example.com">
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label">Profile photo URL <span class="cb-optional">Optional</span></label>
                                <input type="url" name="profile_photo" id="cbProfilePhoto" class="form-control" maxlength="500"
                                       placeholder="https://…/photo.jpg">
                            </div>
                        </div>
                    </div>

                    <div class="cb-form-section">
                        <div class="cb-form-section-head">
                            <div class="cb-form-section-icon cb-fsi-purple"><i class="mdi mdi-tag-multiple-outline"></i></div>
                            <div><h6>Classification & relationship</h6><p>Optional relationship details, category and search tags</p></div>
                        </div>

                        <div class="row g-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label">Category <span>*</span></label>
                                <select name="category_id" id="cbCategoryId" class="form-select select3" data-placeholder="Select category" required>
                                    <option value="">Select category</option>
                                </select>
                                <div class="invalid-feedback">Select a category.</div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label">Relationship <span class="cb-optional">Optional</span></label>
                                <select name="relationship_id" id="cbRelationshipId" class="form-select select3" data-placeholder="No relationship">
                                    <option value="">No relationship</option>
                                </select>
                                <div class="form-text">For family/personal contacts such as Father, Mother, Brother, etc.</div>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label">Tags</label>
                                <input type="text" name="tags" id="cbTags" class="form-control" maxlength="1000"
                                       placeholder="MoU, Hiring, AMC">
                                <div class="form-text">Separate tags with comma or semicolon.</div>
                            </div>
                        </div>
                    </div>

                    <div class="cb-form-section">
                        <div class="cb-form-section-head">
                            <div class="cb-form-section-icon cb-fsi-blue"><i class="mdi mdi-shield-account-outline"></i></div>
                            <div><h6>Ownership & visibility</h6><p>Choose exactly who should be able to discover this record</p></div>
                        </div>

                        <div class="row g-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label">Owning company</label>
                                <select name="company_id" id="cbCompanyId" class="form-select select3">
                                    <option value="">Current / no specific company</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label">Visibility <span>*</span></label>
                                <select name="visibility" id="cbVisibility" class="form-select select3">
                                    <option value="Private">Private — only you</option>
                                    <option value="Company">Company — selected company</option>
                                    <option value="Group">Group — selected users / everyone</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-4 d-none" id="cbVisibilityCompanyWrap">
                                <label class="form-label">Visible to company</label>
                                <select name="visibility_company_id" id="cbVisibilityCompanyId" class="form-select select3">
                                    <option value="">Select company</option>
                                </select>
                                <div class="form-text">Company visibility can be different from the owning company.</div>
                            </div>

                            <div class="col-12 d-none" id="cbVisibilityUsersWrap">
                                <label class="form-label">Visible group members <span class="cb-optional">Optional</span></label>
                                <select name="visibility_user_ids[]" id="cbVisibilityUserIds" class="form-select select3" multiple size="7"></select>
                                <div class="form-text">Leave empty to make the contact visible to all permitted group users. Select people to restrict it.</div>
                            </div>

                            <div class="col-12 d-none" id="cbOwnerWrap">
                                <label class="form-label">Record owner</label>
                                <select id="cbOwnerSelect" class="form-select select3"></select>
                                <div class="form-text">Admin users can assign the contact to another staff member.</div>
                            </div>
                        </div>
                    </div>

                    <div class="cb-form-section mb-0">
                        <div class="cb-form-section-head">
                            <div class="cb-form-section-icon cb-fsi-slate"><i class="mdi mdi-note-text-outline"></i></div>
                            <div><h6>Notes & profile</h6><p>Context that helps the next person understand this relationship</p></div>
                        </div>

                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Address</label>
                                <textarea name="address" id="cbAddress" class="form-control" rows="2" maxlength="5000" placeholder="Full address"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" id="cbNotes" class="form-control" rows="3" maxlength="10000"
                                          placeholder="Important context, preferences, reminders…"></textarea>
                            </div>
                            <div class="col-12">
                                <div class="cb-favourite-toggle">
                                    <label class="form-check form-switch mb-0">
                                        <input class="form-check-input" type="checkbox" name="is_starred" value="1" id="cbIsStarred">
                                        <span class="form-check-label">Add to favourites</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="cb-form-error d-none" id="cbFormServerError"></div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn cb-btn-soft" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn cb-btn-primary btn-primary" id="cbContactSubmit">
                        <i class="mdi mdi-content-save-outline"></i>
                        <span>Save contact</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

{{-- View --}}
<div class="modal fade cb-modal" id="cbViewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="cb-modal-kicker">CONTACT PROFILE</div>
                    <h5 class="modal-title" id="cbViewTitle">Contact</h5>
                    <div class="cb-modal-subtitle" id="cbViewSubtitle"></div>
                </div>
                <div class="cb-view-head-actions">
                    <button type="button" class="btn cb-btn-soft btn-sm" id="cbViewEditBtn"><i class="mdi mdi-pencil-outline"></i> Edit</button>
                    <button type="button" class="btn cb-btn-soft btn-sm" id="cbViewShareBtn"><i class="mdi mdi-share-variant-outline"></i> Share</button>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            </div>
            <div class="modal-body cb-view-body">
                <div class="cb-profile-banner">
                    <div class="cb-profile-avatar" id="cbViewAvatar">AK</div>
                    <div class="flex-grow-1">
                        <div class="cb-profile-name" id="cbViewName">—</div>
                        <div class="cb-profile-role" id="cbViewRole">—</div>
                        <div class="cb-profile-org" id="cbViewOrg">—</div>
                        <div class="cb-profile-chips" id="cbViewChips"></div>
                    </div>
                    <div class="cb-profile-quick">
                        <a href="#" class="btn cb-quick-btn" id="cbViewCall"><i class="mdi mdi-phone"></i><span>Call</span></a>
                        <a href="#" class="btn cb-quick-btn" id="cbViewEmail"><i class="mdi mdi-email-outline"></i><span>Email</span></a>
                        <a href="#" target="_blank" rel="noopener noreferrer" class="btn cb-quick-btn d-none" id="cbViewWebsite"><i class="mdi mdi-web"></i><span>Website</span></a>
                    </div>
                </div>

                <div class="row g-3 mt-1">
                    <div class="col-12 col-lg-7">
                        <div class="cb-view-card">
                            <div class="cb-view-card-head"><i class="mdi mdi-card-account-details-outline"></i><span>Contact details</span></div>
                            <div class="cb-detail-grid" id="cbViewFields"></div>
                        </div>

                        <div class="cb-view-card">
                            <div class="cb-view-card-head"><i class="mdi mdi-tag-multiple-outline"></i><span>Tags & notes</span></div>
                            <div id="cbViewTags" class="cb-view-tags"></div>
                            <div id="cbViewNotes" class="cb-view-notes"></div>
                        </div>

                        <div class="cb-view-card d-none" id="cbViewSharesCard">
                            <div class="cb-view-card-head"><i class="mdi mdi-account-multiple-check-outline"></i><span>Active sharing</span></div>
                            <div id="cbViewShares"></div>
                        </div>
                    </div>

                    <div class="col-12 col-lg-5">
                        <div class="cb-view-card">
                            <div class="cb-view-card-head"><i class="mdi mdi-history"></i><span>Activity trail</span></div>
                            <div class="cb-timeline" id="cbViewActivity"></div>
                        </div>

                        <div class="cb-view-card">
                            <div class="cb-view-card-head"><i class="mdi mdi-book-open-page-variant-outline"></i><span>Linked knowledge</span></div>
                            <div id="cbViewKnowledge"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Export --}}
<div class="modal fade cb-modal" id="cbExportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="cb-modal-kicker">CONTACTBOOK</div>
                    <h5 class="modal-title">Export contacts</h5>
                    <div class="cb-modal-subtitle">Exports follow your current search and filter scope.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="cb-export-grid">
                    <button type="button" class="cb-export-card" data-cb-export="xlsx">
                        <i class="mdi mdi-file-excel-outline"></i>
                        <strong>Excel</strong><span>XLSX register</span>
                    </button>
                    <button type="button" class="cb-export-card" data-cb-export="csv">
                        <i class="mdi mdi-file-delimited-outline"></i>
                        <strong>CSV</strong><span>Portable tabular data</span>
                    </button>
                    <button type="button" class="cb-export-card" data-cb-export="vcard">
                        <i class="mdi mdi-card-account-details-outline"></i>
                        <strong>vCard</strong><span>Phone/contact import</span>
                    </button>
                </div>
                <div class="cb-export-note"><i class="mdi mdi-shield-check-outline"></i> Export permission is role controlled and the export is audited.</div>
            </div>
        </div>
    </div>
</div>

{{-- Import wizard --}}
<div class="modal fade cb-modal" id="cbImportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="cb-modal-kicker">CONTACTBOOK IMPORT</div>
                    <h5 class="modal-title">Import contacts</h5>
                    <div class="cb-modal-subtitle">Preview first. Nothing is written until you confirm the final import.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body cb-import-body">
                <div class="cb-import-stepper" id="cbImportStepper">
                    <div class="active"><span>1</span><strong>Source</strong></div>
                    <div><span>2</span><strong>Map & review</strong></div>
                    <div><span>3</span><strong>Complete</strong></div>
                </div>

                <section id="cbImportStep1">
                    <div class="row g-3">
                        <div class="col-12 col-md-4">
                            <div class="cb-import-option">
                                <div class="cb-import-option-icon"><i class="mdi mdi-file-excel-outline"></i></div>
                                <h6>Excel / CSV</h6>
                                <p>Upload XLSX, XLS or CSV and map the columns before importing.</p>
                                <button type="button" class="btn cb-btn-primary btn-primary w-100" id="cbChooseFileBtn"><i class="mdi mdi-upload"></i> Choose file</button>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="cb-import-option">
                                <div class="cb-import-option-icon gold"><i class="mdi mdi-google"></i></div>
                                <h6>Gmail contacts</h6>
                                <p>Connect with Google OAuth, choose a contact group, then review the snapshot import.</p>
                                <button type="button" class="btn cb-btn-primary btn-primary w-100" id="cbGoogleBtn"><i class="mdi mdi-google"></i> Continue with Google</button>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="cb-import-option">
                                <div class="cb-import-option-icon blue"><i class="mdi mdi-card-account-details-outline"></i></div>
                                <h6>Phone vCard</h6>
                                <p>Upload a .vcf exported from your phone. Multi-contact files are supported.</p>
                                <button type="button" class="btn cb-btn-primary btn-primary w-100" id="cbChooseVcardBtn"><i class="mdi mdi-cellphone-arrow-down"></i> Choose vCard</button>
                            </div>
                        </div>
                    </div>

                    <div class="cb-import-template">
                        <div><i class="mdi mdi-file-download-outline"></i><div><strong>Start from the template</strong><span>Predefined columns make mapping faster.</span></div></div>
                        <button type="button" class="btn cb-btn-soft" id="cbTemplateBtn">Download template</button>
                    </div>

                    <input type="file" id="cbImportFile" class="d-none" accept=".xlsx,.xls,.csv,.txt">
                    <input type="file" id="cbImportVcard" class="d-none" accept=".vcf,text/vcard">
                </section>

                <section id="cbImportStep2" class="d-none">
                    <div class="cb-import-file-summary" id="cbImportFileSummary"></div>

                    <div class="cb-import-config-card">
                        <div class="row g-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label">Default category <span>*</span></label>
                                <select id="cbImportCategory" class="form-select select3"></select>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label">Visibility</label>
                                <select id="cbImportVisibility" class="form-select select3">
                                    <option value="Private">Private</option>
                                    <option value="Company">Company</option>
                                    <option value="Group">Group</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-4">
                                <label class="form-label">Duplicate handling</label>
                                <select id="cbImportDuplicateMode" class="form-select select3">
                                    <option value="skip">Skip duplicates</option>
                                    <option value="keep">Keep both</option>
                                    <option value="merge">Merge into existing</option>
                                </select>
                            </div>
                        </div>
                        <div class="row g-3 mt-1 d-none" id="cbImportVisibilityCompanyWrap">
                            <div class="col-12 col-md-6">
                                <label class="form-label">Visible to company</label>
                                <select id="cbImportVisibilityCompany" class="form-select select3"></select>
                            </div>
                        </div>
                        <div class="row g-3 mt-1 d-none" id="cbImportVisibilityUsersWrap">
                            <div class="col-12">
                                <label class="form-label">Visible group members <span class="cb-optional">Optional</span></label>
                                <select id="cbImportVisibilityUsers" class="form-select select3" multiple size="6"></select>
                            </div>
                        </div>
                    </div>

                    <div class="cb-import-map-card">
                        <div class="cb-view-card-head"><i class="mdi mdi-table-key"></i><span>File column mapping</span></div>
                        <div class="cb-import-map" id="cbImportMapping"></div>
                    </div>

                    <div class="cb-import-map-card">
                        <div class="cb-view-card-head"><i class="mdi mdi-table-search"></i><span>Validation preview</span></div>
                        <div class="cb-import-validation-list" id="cbImportValidationList"></div>
                        <div class="cb-import-preview-wrap">
                            <table class="table table-sm cb-import-preview-table mb-0">
                                <thead id="cbImportPreviewHead"></thead>
                                <tbody id="cbImportPreviewBody"></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="cb-import-error d-none" id="cbImportError"></div>
                </section>

                <section id="cbImportStep3" class="d-none">
                    <div class="cb-import-complete">
                        <div class="cb-import-complete-icon"><i class="mdi mdi-check-circle-outline"></i></div>
                        <h4>Import complete</h4>
                        <p id="cbImportCompleteText">The batch has been processed.</p>
                    </div>
                    <div class="cb-import-result-grid">
                        <div><strong id="cbImportImported">0</strong><span>Imported</span></div>
                        <div><strong id="cbImportMerged">0</strong><span>Merged</span></div>
                        <div><strong id="cbImportSkipped">0</strong><span>Skipped</span></div>
                        <div><strong id="cbImportInvalid">0</strong><span>Invalid</span></div>
                    </div>
                    <div class="text-end mt-3">
                        <button type="button" class="btn cb-btn-soft" id="cbDownloadImportReport"><i class="mdi mdi-file-download-outline"></i> Download import log</button>
                    </div>
                </section>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn cb-btn-soft d-none" id="cbImportBackBtn">Back</button>
                <button type="button" class="btn cb-btn-soft" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn cb-btn-primary btn-primary d-none" id="cbImportNextBtn"><i class="mdi mdi-check"></i> Import contacts</button>
            </div>
        </div>
    </div>
</div>

{{-- Bulk --}}
<div class="modal fade cb-modal" id="cbBulkModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="cb-modal-kicker">BULK ACTION</div>
                    <h5 class="modal-title" id="cbBulkTitle">Update selected contacts</h5>
                    <div class="cb-modal-subtitle" id="cbBulkSubtitle">0 records selected</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="cbBulkCategoryWrap" class="d-none">
                    <label class="form-label">New category</label>
                    <select id="cbBulkCategory" class="form-select select3"></select>
                </div>
                <div id="cbBulkVisibilityWrap" class="d-none">
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label">Visibility</label><select id="cbBulkVisibility" class="form-select select3"><option value="Private">Private</option><option value="Company">Company</option><option value="Group">Group</option></select></div>
                        <div class="col-md-6 d-none" id="cbBulkVisibilityCompanyWrap"><label class="form-label">Company</label><select id="cbBulkVisibilityCompany" class="form-select select3"></select></div>
                        <div class="col-12 d-none" id="cbBulkVisibilityUsersWrap"><label class="form-label">Group members</label><select id="cbBulkVisibilityUsers" class="form-select select3" multiple size="6"></select></div>
                    </div>
                </div>
                <div id="cbBulkTagWrap" class="d-none">
                    <label class="form-label">Tags to add</label>
                    <input type="text" id="cbBulkTags" class="form-control" placeholder="Important, Client, Follow-up">
                </div>
                <div id="cbBulkDeactivateWrap" class="d-none">
                    <div class="cb-danger-box"><i class="mdi mdi-alert-circle-outline"></i><div><strong>Deactivate selected contacts?</strong><span>They will be removed from the active ContactBook and retained as inactive records.</span></div></div>
                </div>
                <div class="cb-form-error d-none mt-3" id="cbBulkError"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn cb-btn-soft" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn cb-btn-primary btn-primary" id="cbBulkSubmit"><i class="mdi mdi-check"></i> Apply action</button>
            </div>
        </div>
    </div>
</div>

{{-- Merge --}}
<div class="modal fade cb-modal" id="cbMergeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="cb-modal-kicker">DUPLICATE MERGE</div>
                    <h5 class="modal-title">Merge contacts</h5>
                    <div class="cb-modal-subtitle">Choose which record should survive and pick the source value for each field.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="cbMergeContacts" class="cb-merge-contacts"></div>
                <div class="cb-merge-grid-wrap">
                    <table class="table cb-merge-table mb-0">
                        <thead><tr><th>Field</th><th>Source value</th></tr></thead>
                        <tbody id="cbMergeBody"></tbody>
                    </table>
                </div>
                <div class="cb-form-error d-none mt-3" id="cbMergeError"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn cb-btn-soft" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn cb-btn-primary btn-primary" id="cbMergeSubmit"><i class="mdi mdi-content-merge"></i> Merge contacts</button>
            </div>
        </div>
    </div>
</div>

{{-- Share --}}
<div class="modal fade cb-modal" id="cbShareModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="cb-modal-kicker">SHARING</div>
                    <h5 class="modal-title">Share contact</h5>
                    <div class="cb-modal-subtitle" id="cbShareSubtitle">Choose users, roles, companies or the entire group.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="cbShareResourceId">
                <div class="cb-share-card">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Audience type</label>
                            <select id="cbShareType" class="form-select select3">
                                <option value="user">User</option>
                                <option value="role">Role</option>
                                <option value="company">Company</option>
                                <option value="group">Group</option>
                            </select>
                        </div>
                        <div class="col-md-8" id="cbShareTargetWrap">
                            <label class="form-label">Audience</label>
                            <select id="cbShareTarget" class="form-select select3"></select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Permission</label>
                            <select id="cbSharePermission" class="form-select select3">
                                <option value="View">View</option>
                                <option value="Manage">Manage</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Expiry <span class="cb-optional">Optional</span></label>
                            <input type="date" id="cbShareExpiry" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="cb-share-existing mt-3">
                    <div class="cb-view-card-head"><i class="mdi mdi-account-multiple-outline"></i><span>Current grants</span></div>
                    <div id="cbShareExistingList" class="pt-2"></div>
                </div>
                <div class="cb-form-error d-none mt-3" id="cbShareError"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn cb-btn-soft" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn cb-btn-primary btn-primary" id="cbShareSubmit"><i class="mdi mdi-share-variant-outline"></i> Share contact</button>
            </div>
        </div>
    </div>
</div>

{{-- Google groups --}}
<div class="modal fade cb-modal" id="cbGoogleGroupsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div class="cb-modal-kicker">GOOGLE CONTACTS</div>
                    <h5 class="modal-title">Choose a Google contact group</h5>
                    <div class="cb-modal-subtitle">Leave groups unselected to import the complete Google Contacts snapshot.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="cbGoogleGroupsList" class="cb-google-groups"></div>
                <div class="cb-import-config-card mt-3">
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label">ContactBook category</label><select id="cbGoogleCategory" class="form-select select3"></select></div>
                        <div class="col-md-6"><label class="form-label">Duplicate handling</label><select id="cbGoogleDuplicateMode" class="form-select select3"><option value="skip">Skip duplicates</option><option value="keep">Keep both</option><option value="merge">Merge into existing</option></select></div>
                    </div>
                </div>
                <div class="cb-form-error d-none mt-3" id="cbGoogleError"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn cb-btn-soft" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn cb-btn-primary btn-primary" id="cbGoogleImportSubmit"><i class="mdi mdi-import"></i> Import selected group</button>
            </div>
        </div>
    </div>
</div>

{{-- Saved searches --}}
<div class="modal fade cb-modal" id="cbSavedSearchModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <div><div class="cb-modal-kicker">CONTACTBOOK</div><h5 class="modal-title">Recent saved searches</h5></div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body"><div id="cbSavedSearchList" class="cb-saved-search-list"></div></div>
        </div>
    </div>
</div>

{{-- Confirmation --}}
<div class="modal fade cb-modal" id="cbConfirmModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cbConfirmTitle">Please confirm</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body"><p id="cbConfirmText" class="mb-0 text-muted"></p></div>
            <div class="modal-footer">
                <button type="button" class="btn cb-btn-soft" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn cb-btn-primary btn-primary" id="cbConfirmProceed">Confirm</button>
            </div>
        </div>
    </div>
</div>

<div class="cb-toast-stack" id="cbToastStack" aria-live="polite" aria-atomic="true"></div>
<script>
    (function ($) {
    'use strict';

    $(function () {
        const root = document.getElementById('cbContactBook');

        if (!root || typeof bootstrap === 'undefined' || typeof $ === 'undefined') {
            return;
        }

        const url = (template, id) => String(template || '').replace('__ID__', encodeURIComponent(id));
        const csrf = root.dataset.csrf;

        const state = {
            page: 1,
            perPage: 25,
            view: 'table',
            rows: [],
            selected: new Set(),
            currentContact: null,
            editId: null,
            duplicateMatches: [],
            duplicateOpenId: null,
            bulkAction: null,
            mergeIds: [],
            mergeFields: null,
            import: {
                token: null,
                source: null,
                fileName: null,
                totalRows: 0,
                headers: [],
                rows: [],
                validationPreview: [],
                fields: {},
                mapping: {},
                reportId: null
            },
            googleGroups: [],
            googleConnected: false,
            lookups: {
                categories: [],
                companies: [],
                staff: [],
                relationships: [],
                roles: []
            },
            confirm: null
        };

        const modals = {
            contact: new bootstrap.Modal(document.getElementById('cbContactModal')),
            view: new bootstrap.Modal(document.getElementById('cbViewModal')),
            export: new bootstrap.Modal(document.getElementById('cbExportModal')),
            import: new bootstrap.Modal(document.getElementById('cbImportModal')),
            bulk: new bootstrap.Modal(document.getElementById('cbBulkModal')),
            merge: new bootstrap.Modal(document.getElementById('cbMergeModal')),
            share: new bootstrap.Modal(document.getElementById('cbShareModal')),
            google: new bootstrap.Modal(document.getElementById('cbGoogleGroupsModal')),
            saved: new bootstrap.Modal(document.getElementById('cbSavedSearchModal')),
            confirm: new bootstrap.Modal(document.getElementById('cbConfirmModal'))
        };

        const U = {
            list: root.dataset.listUrl,
            lookups: root.dataset.lookupsUrl,
            show: root.dataset.showUrl,
            store: root.dataset.storeUrl,
            update: root.dataset.updateUrl,
            remove: root.dataset.deleteUrl,
            star: root.dataset.starUrl,
            restore: root.dataset.restoreUrl,
            duplicate: root.dataset.duplicateUrl,
            mergePreview: root.dataset.mergePreviewUrl,
            merge: root.dataset.mergeUrl,
            bulk: root.dataset.bulkUrl,
            history: root.dataset.searchHistoryUrl,
            saveSearch: root.dataset.searchSaveUrl,
            importTemplate: root.dataset.importTemplateUrl,
            importPreview: root.dataset.importPreviewUrl,
            importCommit: root.dataset.importCommitUrl,
            importReport: root.dataset.importReportUrl,
            googleConnect: root.dataset.googleConnectUrl,
            googleGroups: root.dataset.googleGroupsUrl,
            googleImport: root.dataset.googleImportUrl,
            shareData: root.dataset.shareDataUrl,
            shareStore: root.dataset.shareStoreUrl,
            shareRevoke: root.dataset.shareRevokeUrl,
            exportCsv: root.dataset.exportCsvUrl,
            exportXlsx: root.dataset.exportXlsxUrl,
            exportVcard: root.dataset.exportVcardUrl
        };

        function escapeHtml(value) {
            return $('<div>').text(value == null ? '' : String(value)).html();
        }

        function normalizeText(value) {
            return String(value == null ? '' : value).trim().toLowerCase();
        }

        function initials(value) {
            const parts = String(value || '').trim().split(/\s+/).filter(Boolean);

            if (!parts.length) {
                return '?';
            }

            const first = parts[0].charAt(0);
            const last = parts.length > 1 ? parts[parts.length - 1].charAt(0) : '';

            return (first + last).toUpperCase();
        }

        function phoneHref(value) {
            const digits = String(value || '').replace(/[^\d+]/g, '');
            return digits ? 'tel:' + digits : '#';
        }

        function mailHref(value) {
            return value ? 'mailto:' + encodeURIComponent(value) : '#';
        }

        function isExternal(urlValue) {
            return /^https?:\/\//i.test(String(urlValue || ''));
        }

        function formatDate(value) {
            if (!value) {
                return '—';
            }

            const date = new Date(String(value).replace(' ', 'T'));

            if (Number.isNaN(date.getTime())) {
                return String(value);
            }

            return date.toLocaleDateString('en-IN', {
                day: '2-digit',
                month: 'short',
                year: 'numeric'
            });
        }

        function formatDateTime(value) {
            if (!value) {
                return '—';
            }

            const date = new Date(String(value).replace(' ', 'T'));

            if (Number.isNaN(date.getTime())) {
                return String(value);
            }

            return date.toLocaleString('en-IN', {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        function toast(message, type) {
            const typeClass = type === 'error'
                ? 'cb-toast-error'
                : type === 'warning'
                    ? 'cb-toast-warning'
                    : 'cb-toast-success';

            const icon = type === 'error'
                ? 'alert-circle-outline'
                : type === 'warning'
                    ? 'alert-outline'
                    : 'check-circle-outline';

            const el = $(
                '<div class="cb-toast ' + typeClass + '">' +
                '<i class="mdi mdi-' + icon + '"></i>' +
                '<div class="cb-toast-message"></div>' +
                '<button type="button" class="cb-toast-close">' +
                '<i class="mdi mdi-close"></i>' +
                '</button>' +
                '</div>'
            );

            el.find('.cb-toast-message').text(message || 'Done.');
            $('#cbToastStack').append(el);

            const close = () => el.remove();

            el.on('click', '.cb-toast-close', close);

            setTimeout(close, 4200);
        }

        function showErrorBox(selector, message) {
            $(selector)
                .removeClass('d-none')
                .text(message || 'Something went wrong.');
        }

        function hideErrorBox(selector) {
            $(selector)
                .addClass('d-none')
                .text('');
        }

        function getErrorMessage(xhr) {
            if (!xhr) {
                return 'Unexpected error.';
            }

            if (xhr.responseJSON) {
                if (xhr.responseJSON.message) {
                    return xhr.responseJSON.message;
                }

                if (xhr.responseJSON.errors) {
                    const firstKey = Object.keys(xhr.responseJSON.errors)[0];

                    if (
                        firstKey &&
                        xhr.responseJSON.errors[firstKey] &&
                        xhr.responseJSON.errors[firstKey][0]
                    ) {
                        return xhr.responseJSON.errors[firstKey][0];
                    }
                }
            }

            return xhr.statusText || 'Request failed.';
        }

        function ajax(options) {
            const settings = $.extend(true, {
                headers: {
                    'X-CSRF-TOKEN': csrf,
                    'Accept': 'application/json'
                },

                beforeSend: function () {
                    root.classList.add('cb-request-active');
                },

                complete: function () {
                    root.classList.remove('cb-request-active');
                }
            }, options);

            return $.ajax(settings);
        }

        function initContactBookSelect3(scope) {
            if (typeof $.fn.select2 !== 'function') {
                return;
            }

            const $scope = scope
                ? $(scope)
                : $('#cbContactBook');

            $scope
                .find('select.select3')
                .addBack('select.select3')
                .each(function () {
                    const $select = $(this);

                    if (!$select.length || $select.hasClass('select2-hidden-accessible')) {
                        return;
                    }

                    const $modal = $select.closest('.modal');
                    const placeholder = $select.data('placeholder')
                        || $select.find('option:first').text()
                        || 'Select';

                    $select.select2({
                        width: '100%',
                        dropdownParent: $modal.length ? $modal : $(document.body),
                        placeholder: placeholder,
                        allowClear: true,
                        minimumResultsForSearch: 8,
                        language: {
                            noResults: function () {
                                return 'No options found';
                            }
                        }
                    });
                });
        }

        function populateSelect(
            selector,
            items,
            placeholder,
            valueKey,
            textKey
        ) {
            const $select = $(selector);

            if (!$select.length) {
                return;
            }

            const currentValue = $select.val();

            $select.empty();

            if (placeholder !== false) {
                $select.append(
                    $('<option>')
                        .val('')
                        .text(placeholder || 'Select')
                );
            }

            (items || []).forEach((item) => {
                $select.append(
                    $('<option>')
                        .val(item[valueKey || 'id'])
                        .text(item[textKey || 'name'])
                );
            });

            if (
                currentValue !== null &&
                currentValue !== undefined &&
                currentValue !== ''
            ) {
                $select.val(String(currentValue));
            }

            if ($select.hasClass('select2-hidden-accessible')) {
                $select.trigger('change.select2');
            }
        }

        function populateMultiSelect(selector, items) {
            const $select = $(selector);

            if (!$select.length) {
                return;
            }

            $select.empty();

            (items || []).forEach((item) => {
                $select.append(
                    $('<option>')
                        .val(item.id)
                        .text(
                            item.name +
                            (item.company_name
                                ? ' · ' + item.company_name
                                : '')
                        )
                );
            });

            if ($select.hasClass('select2-hidden-accessible')) {
                $select.trigger('change.select2');
            }
        }

        function fillLookupsIntoUI() {
            populateSelect(
                '#cbFilterCategory',
                state.lookups.categories,
                'All categories'
            );

            populateSelect(
                '#cbCategoryId',
                state.lookups.categories,
                'Select category'
            );

            populateSelect(
                '#cbBulkCategory',
                state.lookups.categories,
                'Select category'
            );

            populateSelect(
                '#cbCompanyId',
                state.lookups.companies,
                'Current / no specific company'
            );

            populateSelect(
                '#cbVisibilityCompanyId',
                state.lookups.companies,
                'Select company'
            );

            populateSelect(
                '#cbFilterCompany',
                state.lookups.companies,
                'All companies'
            );

            populateSelect(
                '#cbFilterCompanyAdvanced',
                state.lookups.companies,
                'All companies'
            );

            populateSelect(
                '#cbImportVisibilityCompany',
                state.lookups.companies,
                'Select company'
            );

            populateSelect(
                '#cbBulkVisibilityCompany',
                state.lookups.companies,
                'Select company'
            );

            populateSelect(
                '#cbRelationshipId',
                state.lookups.relationships,
                'No relationship'
            );

            populateMultiSelect(
                '#cbVisibilityUserIds',
                state.lookups.staff
            );

            populateMultiSelect(
                '#cbImportVisibilityUsers',
                state.lookups.staff
            );

            populateMultiSelect(
                '#cbBulkVisibilityUsers',
                state.lookups.staff
            );

            const ownerItems = (state.lookups.staff || []).map(item => ({
                id: item.id,
                name: item.name,
                company_name: (
                    state.lookups.companies.find(
                        c => Number(c.id) === Number(item.company_id)
                    ) || {}
                ).short_name || ''
            }));

            populateSelect(
                '#cbOwnerSelect',
                ownerItems,
                'Select owner'
            );

            initContactBookSelect3('#cbContactBook');
        }

        function loadLookups() {
            return ajax({
                url: U.lookups,
                method: 'GET',
                data: {
                    company_id: $('#cbFilterCompanyAdvanced').val() || ''
                }
            }).done(function (res) {
                state.lookups = $.extend(
                    true,
                    state.lookups,
                    res.data || {}
                );

                fillLookupsIntoUI();

                const currentUser = state.lookups.current_user || {};

                if (currentUser.company_id !== null && currentUser.company_id !== undefined && currentUser.company_id !== '') {
                    if (!$('#cbCompanyId').val()) {
                        $('#cbCompanyId').val(
                            String(currentUser.company_id)
                        );
                    }

                    if (!$('#cbVisibilityCompanyId').val()) {
                        $('#cbVisibilityCompanyId').val(
                            String(currentUser.company_id)
                        );
                    }
                }

                const adminRole = [
                    'Super Admin',
                    'Group Admin'
                ].includes(currentUser.role);

                $('#cbOwnerWrap').toggleClass(
                    'd-none',
                    !adminRole
                );

                if (adminRole) {
                    $('#cbOwnerSelect').val(
                        String(currentUser.id)
                    );

                    $('#cbOwnerUserId').val(
                        String(currentUser.id)
                    );
                }

                toggleVisibilityTargets('#cbVisibility');
                toggleVisibilityTargets('#cbImportVisibility');
                toggleVisibilityTargets('#cbBulkVisibility');
            }).fail(function (xhr) {
                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            });
        }

        function buildQuery() {
            return {
                page: state.page,
                per_page: state.perPage,
                search: $('#cbSearch').val().trim(),
                category_id: $('#cbFilterCategory').val() || '',
                visibility: $('#cbFilterVisibility').val() || '',
                company_id: (
                    $('#cbFilterCompany').val() ||
                    $('#cbFilterCompanyAdvanced').val() ||
                    ''
                ),
                city: $('#cbFilterCity').val().trim()
            };
        }

        function renderStats(stats) {
            stats = stats || {};

            $('#cbStatTotal').text(
                Number(stats.total || 0)
                    .toLocaleString('en-IN')
            );

            $('#cbStatStarred').text(
                Number(stats.starred || 0)
                    .toLocaleString('en-IN')
            );

            $('#cbStatCompany').text(
                Number(stats.company || 0)
                    .toLocaleString('en-IN')
            );

            $('#cbStatGroup').text(
                Number(stats.group || 0)
                    .toLocaleString('en-IN')
            );

            $('#cbHeroCount').text(
                Number(stats.total || 0)
                    .toLocaleString('en-IN') +
                ' contacts'
            );
        }

        function visibilityBadge(contact) {
            const type = contact.visibility || 'Private';

            const icon = type === 'Group'
                ? 'account-multiple-outline'
                : type === 'Company'
                    ? 'office-building-outline'
                    : 'lock-outline';

            let label = type;

            if (
                type === 'Company' &&
                contact.visibility_company_name
            ) {
                label = contact.visibility_company_name;
            } else if (
                type === 'Group' &&
                (contact.visibility_user_ids || []).length
            ) {
                label = 'Selected group';
            }

            return (
                '<span class="cb-visibility cb-vis-' +
                type.toLowerCase() +
                '">' +
                '<i class="mdi mdi-' +
                icon +
                '"></i>' +
                escapeHtml(label) +
                '</span>'
            );
        }

        function categoryBadge(contact) {
            const color =
                contact.category_color || '#C0392B';

            return (
                '<span class="cb-category-badge" ' +
                'style="--cb-cat:' +
                escapeHtml(color) +
                '">' +
                '<span class="cb-cat-dot"></span>' +
                escapeHtml(
                    contact.category_name ||
                    'Uncategorised'
                ) +
                '</span>'
            );
        }

        function renderTableRows(rows) {
            if (!rows.length) {
                return '';
            }

            return rows.map(function (contact) {
                const selected = state.selected.has(
                    Number(contact.sno)
                );

                const avatar = contact.profile_photo
                    ? '<img src="' +
                      escapeHtml(contact.profile_photo) +
                      '" alt="">'
                    : escapeHtml(
                        contact.initials ||
                        initials(contact.person_name)
                    );

                const secondary = [
                    contact.designation,
                    contact.organisation
                ]
                    .filter(Boolean)
                    .join(' · ');

                const phone = contact.phone_primary
                    ? '<div class="cb-cell-line">' +
                      '<a href="' +
                      escapeHtml(
                          phoneHref(
                              contact.phone_primary
                          )
                      ) +
                      '">' +
                      escapeHtml(
                          contact.phone_primary
                      ) +
                      '</a>' +
                      '<button type="button" ' +
                      'class="cb-icon-copy" ' +
                      'data-copy="' +
                      escapeHtml(
                          contact.phone_primary
                      ) +
                      '" title="Copy">' +
                      '<i class="mdi mdi-content-copy"></i>' +
                      '</button>' +
                      '</div>'
                    : '<span class="text-muted">—</span>';

                const email = contact.email_primary
                    ? '<div class="cb-cell-line">' +
                      '<a href="' +
                      escapeHtml(
                          mailHref(
                              contact.email_primary
                          )
                      ) +
                      '">' +
                      escapeHtml(
                          contact.email_primary
                      ) +
                      '</a>' +
                      '<button type="button" ' +
                      'class="cb-icon-copy" ' +
                      'data-copy="' +
                      escapeHtml(
                          contact.email_primary
                      ) +
                      '" title="Copy">' +
                      '<i class="mdi mdi-content-copy"></i>' +
                      '</button>' +
                      '</div>'
                    : '<span class="text-muted">—</span>';

                return (
                    '<tr data-id="' +
                    contact.sno +
                    '">' +

                    '<td class="cb-check-col">' +
                    '<input ' +
                    'class="form-check-input cb-row-check" ' +
                    'type="checkbox" ' +
                    'data-id="' +
                    contact.sno +
                    '"' +
                    (
                        selected
                            ? ' checked'
                            : ''
                    ) +
                    '>' +
                    '</td>' +

                    '<td>' +
                    '<div class="cb-contact-cell">' +

                    '<div class="cb-table-avatar">' +
                    avatar +
                    '</div>' +

                    '<div class="min-w-0">' +

                    '<button type="button" ' +
                    'class="cb-contact-name text-start" ' +
                    'data-action="view" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +
                    escapeHtml(
                        contact.person_name
                    ) +
                    '</button>' +

                    (
                        secondary
                            ? '<div class="cb-contact-sub">' +
                              escapeHtml(secondary) +
                              '</div>'
                            : ''
                    ) +

                    (
                        contact.tags &&
                        contact.tags.length
                            ? '<div class="cb-mini-tags">' +
                              contact.tags
                                  .slice(0, 2)
                                  .map(
                                      t =>
                                          '<span>' +
                                          escapeHtml(t) +
                                          '</span>'
                                  )
                                  .join('') +
                              (
                                  contact.tags.length > 2
                                      ? '<span>+' +
                                        (
                                            contact.tags.length -
                                            2
                                        ) +
                                        '</span>'
                                      : ''
                              ) +
                              '</div>'
                            : ''
                    ) +

                    '</div>' +
                    '</div>' +
                    '</td>' +

                    '<td>' +
                    '<div class="cb-org-cell">' +
                    '<strong>' +
                    escapeHtml(
                        contact.organisation ||
                        '—'
                    ) +
                    '</strong>' +
                    (
                        contact.city
                            ? '<small>' +
                              escapeHtml(
                                  contact.city
                              ) +
                              '</small>'
                            : ''
                    ) +
                    '</div>' +
                    '</td>' +

                    '<td>' +
                    phone +
                    '</td>' +

                    '<td>' +
                    email +
                    '</td>' +

                    '<td>' +
                    categoryBadge(contact) +
                    '</td>' +

                    '<td>' +
                    visibilityBadge(contact) +
                    '</td>' +

                    '<td class="text-center">' +

                    '<button type="button" ' +
                    'class="cb-star-btn ' +
                    (
                        contact.is_starred
                            ? 'active'
                            : ''
                    ) +
                    '" ' +
                    'data-action="star" ' +
                    'data-id="' +
                    contact.sno +
                    '" ' +
                    'title="' +
                    (
                        contact.is_starred
                            ? 'Remove favourite'
                            : 'Add favourite'
                    ) +
                    '">' +

                    '<i class="mdi ' +
                    (
                        contact.is_starred
                            ? 'mdi-star'
                            : 'mdi-star-outline'
                    ) +
                    '"></i>' +

                    '</button>' +

                    '</td>' +

                    '<td class="text-end">' +

                    '<div class="dropdown">' +

                    '<button ' +
                    'class="btn cb-row-more" ' +
                    'type="button" ' +
                    'data-bs-toggle="dropdown" ' +
                    'aria-expanded="false">' +
                    '<i class="mdi mdi-dots-vertical"></i>' +
                    '</button>' +

                    '<ul class="dropdown-menu dropdown-menu-end cb-row-menu">' +

                    '<li>' +
                    '<button class="dropdown-item" ' +
                    'type="button" ' +
                    'data-action="view" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +
                    '<i class="mdi mdi-eye-outline"></i>' +
                    'View profile' +
                    '</button>' +
                    '</li>' +

                    '<li>' +
                    '<button class="dropdown-item" ' +
                    'type="button" ' +
                    'data-action="edit" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +
                    '<i class="mdi mdi-pencil-outline"></i>' +
                    'Edit contact' +
                    '</button>' +
                    '</li>' +

                    '<li>' +
                    '<button class="dropdown-item" ' +
                    'type="button" ' +
                    'data-action="share" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +
                    '<i class="mdi mdi-share-variant-outline"></i>' +
                    'Share' +
                    '</button>' +
                    '</li>' +

                    '<li>' +
                    '<hr class="dropdown-divider">' +
                    '</li>' +

                    (
                        contact.phone_primary
                            ? '<li>' +
                              '<a class="dropdown-item" ' +
                              'href="' +
                              escapeHtml(
                                  phoneHref(
                                      contact.phone_primary
                                  )
                              ) +
                              '">' +
                              '<i class="mdi mdi-phone-outline"></i>' +
                              'Call' +
                              '</a>' +
                              '</li>'
                            : ''
                    ) +

                    (
                        contact.email_primary
                            ? '<li>' +
                              '<a class="dropdown-item" ' +
                              'href="' +
                              escapeHtml(
                                  mailHref(
                                      contact.email_primary
                                  )
                              ) +
                              '">' +
                              '<i class="mdi mdi-email-outline"></i>' +
                              'Email' +
                              '</a>' +
                              '</li>'
                            : ''
                    ) +

                    '<li>' +
                    '<button class="dropdown-item text-danger" ' +
                    'type="button" ' +
                    'data-action="delete" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +
                    '<i class="mdi mdi-account-off-outline"></i>' +
                    'Deactivate' +
                    '</button>' +
                    '</li>' +

                    '</ul>' +

                    '</div>' +

                    '</td>' +

                    '</tr>'
                );
            }).join('');
        }

        function renderCards(rows) {
            if (!rows.length) {
                return '';
            }

            return rows.map(function (contact) {
                const avatar = contact.profile_photo
                    ? '<img src="' +
                      escapeHtml(contact.profile_photo) +
                      '" alt="">'
                    : escapeHtml(
                        contact.initials ||
                        initials(contact.person_name)
                    );

                return (
                    '<article class="cb-contact-card">' +

                    '<div class="cb-card-top">' +

                    '<div class="cb-card-person" ' +
                    'data-action="view" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +

                    '<div class="cb-card-avatar">' +
                    avatar +
                    '</div>' +

                    '<div>' +

                    '<button type="button" ' +
                    'class="cb-card-name" ' +
                    'data-action="view" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +
                    escapeHtml(
                        contact.person_name
                    ) +
                    '</button>' +

                    '<div class="cb-card-role">' +
                    escapeHtml(
                        contact.designation ||
                        'Contact'
                    ) +
                    '</div>' +

                    '</div>' +

                    '</div>' +

                    '<button type="button" ' +
                    'class="cb-star-btn ' +
                    (
                        contact.is_starred
                            ? 'active'
                            : ''
                    ) +
                    '" ' +
                    'data-action="star" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +
                    '<i class="mdi ' +
                    (
                        contact.is_starred
                            ? 'mdi-star'
                            : 'mdi-star-outline'
                    ) +
                    '"></i>' +
                    '</button>' +

                    '</div>' +

                    '<div class="cb-card-org">' +
                    '<i class="mdi mdi-office-building-outline"></i>' +
                    '<span>' +
                    escapeHtml(
                        contact.organisation ||
                        'No organisation'
                    ) +
                    '</span>' +
                    '</div>' +

                    '<div class="cb-card-info">' +

                    (
                        contact.phone_primary
                            ? '<a href="' +
                              escapeHtml(
                                  phoneHref(
                                      contact.phone_primary
                                  )
                              ) +
                              '">' +
                              '<i class="mdi mdi-phone-outline"></i>' +
                              escapeHtml(
                                  contact.phone_primary
                              ) +
                              '</a>'
                            : '<span>' +
                              '<i class="mdi mdi-phone-off-outline"></i>' +
                              'No phone' +
                              '</span>'
                    ) +

                    (
                        contact.email_primary
                            ? '<a href="' +
                              escapeHtml(
                                  mailHref(
                                      contact.email_primary
                                  )
                              ) +
                              '">' +
                              '<i class="mdi mdi-email-outline"></i>' +
                              escapeHtml(
                                  contact.email_primary
                              ) +
                              '</a>'
                            : '<span>' +
                              '<i class="mdi mdi-email-off-outline"></i>' +
                              'No email' +
                              '</span>'
                    ) +

                    '</div>' +

                    '<div class="cb-card-bottom">' +
                    categoryBadge(contact) +
                    visibilityBadge(contact) +
                    '</div>' +

                    '<div class="cb-card-actions">' +

                    '<button type="button" ' +
                    'class="btn cb-btn-soft" ' +
                    'data-action="view" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +
                    '<i class="mdi mdi-eye-outline"></i>' +
                    'View' +
                    '</button>' +

                    '<button type="button" ' +
                    'class="btn cb-btn-primary btn-primary" ' +
                    'data-action="edit" ' +
                    'data-id="' +
                    contact.sno +
                    '">' +
                    '<i class="mdi mdi-pencil-outline"></i>' +
                    'Edit' +
                    '</button>' +

                    '</div>' +

                    '</article>'
                );
            }).join('');
        }

        function renderPagination(meta) {
            const $pagination = $('#cbPagination');

            $pagination.empty();

            const current = Number(meta.current || 1);
            const last = Number(meta.last || 1);
            const total = Number(meta.total || 0);

            if (last <= 1) {
                return;
            }

            const addButton = (
                page,
                label,
                disabled,
                active
            ) => {
                const $button = $(
                    '<button type="button" class="cb-page-btn"></button>'
                )
                    .text(label)
                    .prop('disabled', disabled)
                    .toggleClass('active', active)
                    .on('click', function () {
                        if (
                            !disabled &&
                            page !== state.page
                        ) {
                            loadContacts(page);
                        }
                    });

                $pagination.append($button);
            };

            addButton(
                Math.max(1, current - 1),
                '‹',
                current <= 1,
                false
            );

            const start = Math.max(
                1,
                current - 2
            );

            const end = Math.min(
                last,
                current + 2
            );

            if (start > 1) {
                addButton(
                    1,
                    '1',
                    false,
                    current === 1
                );

                if (start > 2) {
                    $pagination.append(
                        '<span class="cb-page-dots">…</span>'
                    );
                }
            }

            for (
                let page = start;
                page <= end;
                page++
            ) {
                addButton(
                    page,
                    String(page),
                    false,
                    page === current
                );
            }

            if (end < last) {
                if (end < last - 1) {
                    $pagination.append(
                        '<span class="cb-page-dots">…</span>'
                    );
                }

                addButton(
                    last,
                    String(last),
                    false,
                    current === last
                );
            }

            addButton(
                Math.min(last, current + 1),
                '›',
                current >= last,
                false
            );
        }
                function renderActiveFilters() {
            const values = [];

            const search = $('#cbSearch')
                .val()
                .trim();

            const category = $(
                '#cbFilterCategory option:selected'
            ).text();

            const visibility =
                $('#cbFilterVisibility').val();

            const company =
                $('#cbFilterCompany').val() ||
                $('#cbFilterCompanyAdvanced').val();

            const companyText = company
                ? (
                    $('#cbFilterCompany option:selected')
                        .text() ||
                    $('#cbFilterCompanyAdvanced option:selected')
                        .text()
                )
                : '';

            const city = $('#cbFilterCity')
                .val()
                .trim();

            if (search) {
                values.push({
                    label: 'Search',
                    value: search,
                    key: 'search'
                });
            }

            if ($('#cbFilterCategory').val()) {
                values.push({
                    label: 'Category',
                    value: category,
                    key: 'category'
                });
            }

            if (visibility) {
                values.push({
                    label: 'Visibility',
                    value: visibility,
                    key: 'visibility'
                });
            }

            if (company) {
                values.push({
                    label: 'Company',
                    value: companyText,
                    key: 'company'
                });
            }

            if (city) {
                values.push({
                    label: 'City',
                    value: city,
                    key: 'city'
                });
            }

            const $wrap = $('#cbActiveFilters');

            if (!values.length) {
                $wrap
                    .addClass('d-none')
                    .empty();

                return;
            }

            $wrap
                .removeClass('d-none')
                .html(
                    values.map(
                        item =>
                            '<span class="cb-filter-chip">' +
                            '<strong>' +
                            escapeHtml(
                                item.label
                            ) +
                            '</strong> ' +
                            escapeHtml(
                                item.value
                            ) +
                            '<button type="button" ' +
                            'data-filter-key="' +
                            item.key +
                            '">' +
                            '<i class="mdi mdi-close"></i>' +
                            '</button>' +
                            '</span>'
                    ).join('') +
                    '<button type="button" ' +
                    'class="cb-clear-all-filters">' +
                    'Clear all' +
                    '</button>'
                );
        }

        function loadContacts(page) {
            state.page = Number(
                page ||
                state.page ||
                1
            );

            renderActiveFilters();

            $('#cbLoading')
                .removeClass('d-none');

            $('#cbEmptyState, #cbErrorState')
                .addClass('d-none');

            return ajax({
                url: U.list,
                method: 'GET',
                data: buildQuery()
            }).done(function (res) {
                const data = res.data || {};

                state.rows = Array.isArray(data.rows)
                    ? data.rows
                    : [];

                renderStats(
                    data.stats || {}
                );

                $('#cbTableBody').html(
                    renderTableRows(
                        state.rows
                    )
                );

                $('#cbCardView').html(
                    renderCards(
                        state.rows
                    )
                );

                renderPagination(
                    data.pagination || {}
                );

                const total = Number(
                    (
                        data.pagination ||
                        {}
                    ).total || 0
                );

                const from = Number(
                    (
                        data.pagination ||
                        {}
                    ).from || 0
                );

                const to = Number(
                    (
                        data.pagination ||
                        {}
                    ).to || 0
                );

                $('#cbResultSummary').text(
                    total
                        ? 'Showing ' +
                          from.toLocaleString('en-IN') +
                          '–' +
                          to.toLocaleString('en-IN') +
                          ' of ' +
                          total.toLocaleString('en-IN') +
                          ' contacts'
                        : 'Showing 0 contacts'
                );

                $('#cbHeroScope').text(
                    $('#cbFilterCompany').val() ||
                    $('#cbFilterCompanyAdvanced').val()
                        ? (
                            $('#cbFilterCompany option:selected')
                                .text() ||
                            $('#cbFilterCompanyAdvanced option:selected')
                                .text()
                        )
                        : 'Current company & shared contacts'
                );

                if (!state.rows.length) {
                    $('#cbEmptyState')
                        .removeClass('d-none');

                    $('#cbTableView, #cbCardView')
                        .addClass('d-none');
                } else {
                    if (state.view === 'table') {
                        $('#cbTableView')
                            .removeClass('d-none');

                        $('#cbCardView')
                            .addClass('d-none');
                    } else {
                        $('#cbCardView')
                            .removeClass('d-none');

                        $('#cbTableView')
                            .addClass('d-none');
                    }
                }

                syncSelectionUI();
            }).fail(function (xhr) {
                $('#cbTableBody').empty();
                $('#cbCardView').empty();

                $('#cbTableView, #cbCardView, #cbEmptyState')
                    .addClass('d-none');

                $('#cbErrorState')
                    .removeClass('d-none');

                $('#cbErrorMessage').text(
                    getErrorMessage(xhr)
                );

                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            }).always(function () {
                $('#cbLoading')
                    .addClass('d-none');
            });
        }

        function syncSelectionUI() {
            const visibleIds =
                state.rows.map(
                    row => Number(row.sno)
                );

            const visibleSelected =
                visibleIds.filter(
                    id => state.selected.has(id)
                ).length;

            $('#cbSelectedCount').text(
                state.selected.size
            );

            $('#cbBulkBar').toggleClass(
                'd-none',
                state.selected.size === 0
            );

            const $selectAll =
                $('#cbSelectAll');

            $selectAll.prop(
                'checked',
                visibleIds.length > 0 &&
                visibleSelected === visibleIds.length
            );

            $selectAll.prop(
                'indeterminate',
                visibleSelected > 0 &&
                visibleSelected < visibleIds.length
            );

            $('#cbTableBody .cb-row-check')
                .each(function () {
                    $(this).prop(
                        'checked',
                        state.selected.has(
                            Number(
                                $(this).data('id')
                            )
                        )
                    );
                });
        }

        function resetContactForm(contact) {
            const form =
                document.getElementById(
                    'cbContactForm'
                );

            form.reset();

            form.classList.remove(
                'was-validated'
            );

            hideErrorBox(
                '#cbFormServerError'
            );

            $('#cbDuplicateAlert')
                .addClass('d-none');

            $('#cbForceDuplicate')
                .val('0');

            $('#cbOwnerUserId')
                .val('');

            populateSelect(
                '#cbCategoryId',
                state.lookups.categories,
                'Select category'
            );

            populateSelect(
                '#cbRelationshipId',
                state.lookups.relationships,
                'No relationship'
            );

            populateSelect(
                '#cbCompanyId',
                state.lookups.companies,
                'Current / no specific company'
            );

            populateSelect(
                '#cbVisibilityCompanyId',
                state.lookups.companies,
                'Select company'
            );

            populateMultiSelect(
                '#cbVisibilityUserIds',
                state.lookups.staff
            );

            $('#cbVisibility')
                .val('Private')
                .trigger('change.select2');

            $('#cbIsStarred')
                .prop('checked', false);

            const currentUser =
                state.lookups.current_user ||
                {};

            if (currentUser.company_id !== null && currentUser.company_id !== undefined && currentUser.company_id !== '') {
                $('#cbCompanyId').val(
                    String(
                        currentUser.company_id
                    )
                ).trigger('change.select2');

                $('#cbVisibilityCompanyId')
                    .val(
                        String(
                            currentUser.company_id
                        )
                    )
                    .trigger('change.select2');
            }

            if (!contact) {
                $('#cbContactTitle').text(
                    'Add contact'
                );

                $('#cbContactKicker').text(
                    'CONTACTBOOK · NEW RECORD'
                );

                $('#cbContactForm')
                    .data('mode', 'create')
                    .data('id', '');

                $('#cbOwnerSelect').val(
                    String(
                        currentUser.id || ''
                    )
                ).trigger('change.select2');

                $('#cbOwnerUserId').val(
                    String(
                        currentUser.id || ''
                    )
                );

                toggleVisibilityTargets(
                    '#cbVisibility'
                );

                return;
            }

            $('#cbContactTitle').text(
                'Edit contact'
            );

            $('#cbContactKicker').text(
                'CONTACTBOOK · EDIT RECORD'
            );

            $('#cbContactForm')
                .data('mode', 'edit')
                .data('id', contact.sno);

            Object.entries({
                cbSalutation:
                    contact.salutation || '',

                cbPersonName:
                    contact.person_name || '',

                cbDesignation:
                    contact.designation || '',

                cbOrganisation:
                    contact.organisation || '',

                cbDepartment:
                    contact.department || '',

                cbCity:
                    contact.city || '',

                cbPhonePrimary:
                    contact.phone_primary || '',

                cbPhoneAlternate:
                    contact.phone_alternate || '',

                cbEmailPrimary:
                    contact.email_primary || '',

                cbEmailSecondary:
                    contact.email_secondary || '',

                cbWebsite:
                    contact.website || '',

                cbProfilePhoto:
                    contact.profile_photo || '',

                cbAddress:
                    contact.address || '',

                cbNotes:
                    contact.notes || ''
            }).forEach(
                ([id, value]) =>
                    $('#' + id).val(value)
            );

            $('#cbCategoryId').val(
                String(
                    contact.category_id ?? ''
                )
            ).trigger('change.select2');

            $('#cbRelationshipId').val(
                String(
                    contact.relationship_id ?? ''
                )
            ).trigger('change.select2');

            const contactCompanyId =
                contact.company_id !== null &&
                contact.company_id !== undefined
                    ? contact.company_id
                    : currentUser.company_id;

            $('#cbCompanyId').val(
                contactCompanyId !== null &&
                contactCompanyId !== undefined
                    ? String(contactCompanyId)
                    : ''
            ).trigger('change.select2');

            $('#cbVisibility').val(
                contact.visibility ||
                'Private'
            ).trigger('change.select2');

            const visibilityCompanyId =
                contact.visibility_company_id !== null &&
                contact.visibility_company_id !== undefined
                    ? contact.visibility_company_id
                    : (contact.company_id !== null &&
                       contact.company_id !== undefined
                        ? contact.company_id
                        : currentUser.company_id);

            $('#cbVisibilityCompanyId').val(
                visibilityCompanyId !== null &&
                visibilityCompanyId !== undefined
                    ? String(visibilityCompanyId)
                    : ''
            ).trigger('change.select2');

            $('#cbTags').val(
                (contact.tags || []).join(', ')
            );

            $('#cbIsStarred')
                .prop(
                    'checked',
                    !!contact.is_starred
                );

            $('#cbOwnerSelect').val(
                String(
                    contact.owner_user_id ??
                    currentUser.id ??
                    ''
                )
            ).trigger('change.select2');

            $('#cbOwnerUserId').val(
                String(
                    contact.owner_user_id ||
                    currentUser.id ||
                    ''
                )
            );

            const groupIds =
                (contact.visibility_user_ids || [])
                    .map(String);

            $('#cbVisibilityUserIds').val(
                groupIds
            ).trigger('change.select2');

            toggleVisibilityTargets(
                '#cbVisibility'
            );
        }

        function toggleVisibilityTargets(selector) {
            const value =
                $(selector).val();

            if (selector === '#cbVisibility') {
                $('#cbVisibilityCompanyWrap')
                    .toggleClass(
                        'd-none',
                        value !== 'Company'
                    );

                $('#cbVisibilityUsersWrap')
                    .toggleClass(
                        'd-none',
                        value !== 'Group'
                    );
            }

            if (selector === '#cbImportVisibility') {
                $('#cbImportVisibilityCompanyWrap')
                    .toggleClass(
                        'd-none',
                        value !== 'Company'
                    );

                $('#cbImportVisibilityUsersWrap')
                    .toggleClass(
                        'd-none',
                        value !== 'Group'
                    );
            }

            if (selector === '#cbBulkVisibility') {
                $('#cbBulkVisibilityCompanyWrap')
                    .toggleClass(
                        'd-none',
                        value !== 'Company'
                    );

                $('#cbBulkVisibilityUsersWrap')
                    .toggleClass(
                        'd-none',
                        value !== 'Group'
                    );
            }
        }
            function collectContactForm() {
            const data = {
                company_id:
                    $('#cbCompanyId').val() || '',

                owner_user_id:
                    $('#cbOwnerSelect').val() ||
                    $('#cbOwnerUserId').val() ||
                    '',

                visibility:
                    $('#cbVisibility').val(),

                visibility_company_id:
                    $('#cbVisibilityCompanyId').val() ||
                    '',

                salutation:
                    $('#cbSalutation').val(),

                person_name:
                    $('#cbPersonName').val().trim(),

                designation:
                    $('#cbDesignation').val().trim(),

                organisation:
                    $('#cbOrganisation').val().trim(),

                department:
                    $('#cbDepartment').val().trim(),

                phone_primary:
                    $('#cbPhonePrimary').val().trim(),

                phone_alternate:
                    $('#cbPhoneAlternate').val().trim(),

                email_primary:
                    $('#cbEmailPrimary').val().trim(),

                email_secondary:
                    $('#cbEmailSecondary').val().trim(),

                city:
                    $('#cbCity').val().trim(),

                address:
                    $('#cbAddress').val().trim(),

                website:
                    $('#cbWebsite').val().trim(),

                profile_photo:
                    $('#cbProfilePhoto').val().trim(),

                category_id:
                    $('#cbCategoryId').val(),

                relationship_id:
                    $('#cbRelationshipId').val() ||
                    '',

                tags:
                    $('#cbTags').val().trim(),

                notes:
                    $('#cbNotes').val().trim(),

                is_starred:
                    $('#cbIsStarred').is(':checked')
                        ? 1
                        : 0,

                force_duplicate:
                    $('#cbForceDuplicate').val() === '1'
                        ? 1
                        : 0
            };

            data.visibility_user_ids =
                $('#cbVisibilityUserIds').val() ||
                [];

            if (data.visibility !== 'Company') {
                data.visibility_company_id = '';
            }

            if (data.visibility !== 'Group') {
                data.visibility_user_ids = [];
            }

            return data;
        }

        function renderDuplicateAlert(matches) {
            state.duplicateMatches =
                matches || [];

            state.duplicateOpenId =
                state.duplicateMatches.length
                    ? Number(
                        state.duplicateMatches[0].sno
                    )
                    : null;

            if (!state.duplicateMatches.length) {
                $('#cbDuplicateAlert')
                    .addClass('d-none');

                return;
            }

            const first =
                state.duplicateMatches[0];

            $('#cbDuplicateText').text(
                'This phone number, email or name looks similar to an existing contact. Review before creating another record.'
            );

            $('#cbDuplicateMatches').html(
                state.duplicateMatches
                    .slice(0, 5)
                    .map(item =>
                        '<div class="cb-duplicate-item">' +

                        '<div class="cb-duplicate-avatar">' +
                        escapeHtml(
                            item.initials ||
                            initials(
                                item.person_name
                            )
                        ) +
                        '</div>' +

                        '<div class="min-w-0">' +

                        '<strong>' +
                        escapeHtml(
                            item.person_name
                        ) +
                        '</strong>' +

                        '<span>' +
                        escapeHtml(
                            [
                                item.organisation,
                                item.phone_primary,
                                item.email_primary
                            ]
                                .filter(Boolean)
                                .join(' · ') ||
                            'Existing contact'
                        ) +
                        '</span>' +

                        '</div>' +

                        '</div>'
                    )
                    .join('')
            );

            $('#cbDuplicateAlert')
                .removeClass('d-none');

            if (first) {
                state.duplicateOpenId =
                    Number(first.sno);
            }
        }

        function openContactModal(id) {
            if (id) {
                const contact =
                    state.rows.find(
                        row =>
                            Number(row.sno) ===
                            Number(id)
                    );

                resetContactForm(
                    contact || null
                );
            } else {
                resetContactForm(null);
            }

            modals.contact.show();
        }

        function submitContact() {
            const form =
                document.getElementById(
                    'cbContactForm'
                );

            if (!form.checkValidity()) {
                form.classList.add(
                    'was-validated'
                );

                return;
            }

            const mode =
                form.dataset.mode ||
                'create';

            const id =
                form.dataset.id;

            const payload =
                collectContactForm();

            $('#cbContactSubmit')
                .prop('disabled', true);

            hideErrorBox(
                '#cbFormServerError'
            );

            ajax({
                url:
                    mode === 'edit'
                        ? url(U.update, id)
                        : U.store,

                method:
                    mode === 'edit'
                        ? 'PUT'
                        : 'POST',

                data: payload
            }).done(function (res) {
                toast(
                    res.message ||
                    'Contact saved.'
                );

                modals.contact.hide();

                state.selected.delete(
                    Number(id)
                );

                loadContacts(
                    state.page
                );
            }).fail(function (xhr) {
                if (
                    xhr.status === 409 &&
                    xhr.responseJSON &&
                    Array.isArray(
                        xhr.responseJSON.duplicates
                    )
                ) {
                    renderDuplicateAlert(
                        xhr.responseJSON.duplicates
                    );

                    $('#cbForceDuplicate')
                        .val('0');

                    return;
                }

                if (
                    xhr.status === 422 &&
                    xhr.responseJSON &&
                    xhr.responseJSON.errors
                ) {
                    const errors =
                        xhr.responseJSON.errors;

                    const firstKey =
                        Object.keys(errors)[0];

                    if (firstKey) {
                        const selector =
                            $('[name="' +
                                firstKey +
                                '"]')
                                .first();

                        if (selector.length) {
                            selector
                                .addClass(
                                    'is-invalid'
                                )
                                .trigger(
                                    'focus'
                                );
                        }
                    }
                }

                showErrorBox(
                    '#cbFormServerError',
                    getErrorMessage(xhr)
                );

                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            }).always(function () {
                $('#cbContactSubmit')
                    .prop('disabled', false);
            });
        }

        function checkDuplicateLive() {
            const name =
                $('#cbPersonName')
                    .val()
                    .trim();

            const phone =
                $('#cbPhonePrimary')
                    .val()
                    .trim();

            const email =
                $('#cbEmailPrimary')
                    .val()
                    .trim();

            if (!name && !phone && !email) {
                $('#cbDuplicateAlert')
                    .addClass('d-none');

                return;
            }

            ajax({
                url: U.duplicate,
                method: 'GET',
                data: {
                    person_name: name,
                    phone_primary: phone,
                    email_primary: email,

                    organisation:
                        $('#cbOrganisation')
                            .val()
                            .trim(),

                    exclude_id:
                        $('#cbContactForm').data(
                            'mode'
                        ) === 'edit'
                            ? $('#cbContactForm').data(
                                'id'
                            )
                            : ''
                }
            }).done(function (res) {
                const matches =
                    Array.isArray(res.data)
                        ? res.data
                        : [];

                if (matches.length) {
                    renderDuplicateAlert(
                        matches
                    );
                } else if (
                    $('#cbForceDuplicate').val() !== '1'
                ) {
                    $('#cbDuplicateAlert')
                        .addClass('d-none');
                }
            });
        }

        function openViewModal(id) {
            $('#cbViewActivity').html(
                '<div class="cb-modal-loader">' +
                '<span class="spinner-border spinner-border-sm"></span> ' +
                'Loading profile…' +
                '</div>'
            );

            $('#cbViewKnowledge').html(
                '<div class="cb-modal-loader">' +
                'Loading…' +
                '</div>'
            );

            $('#cbViewSharesCard')
                .addClass('d-none');

            modals.view.show();

            ajax({
                url: url(U.show, id),
                method: 'GET'
            }).done(function (res) {
                const data =
                    res.data || {};

                state.currentContact =
                    data.contact || null;

                if (!state.currentContact) {
                    toast(
                        'Contact not found.',
                        'error'
                    );

                    modals.view.hide();

                    return;
                }

                renderViewProfile(
                    state.currentContact,
                    data
                );

                $('#cbViewEditBtn').toggle(
                    !!(
                        data.permissions &&
                        data.permissions.manage
                    )
                );

                $('#cbViewShareBtn').toggle(
                    !!(
                        data.permissions &&
                        data.permissions.share
                    )
                );
            }).fail(function (xhr) {
                modals.view.hide();

                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            });
        }

        function renderViewProfile(
            contact,
            data
        ) {
            const avatar =
                contact.profile_photo
                    ? '<img src="' +
                      escapeHtml(
                          contact.profile_photo
                      ) +
                      '" alt="">'
                    : escapeHtml(
                        contact.initials ||
                        initials(
                            contact.person_name
                        )
                    );

            $('#cbViewTitle').text(
                contact.person_name ||
                'Contact'
            );

            $('#cbViewSubtitle').text(
                [
                    contact.designation,
                    contact.organisation,
                    contact.city
                ]
                    .filter(Boolean)
                    .join(' · ')
            );

            $('#cbViewAvatar')
                .html(avatar);

            $('#cbViewName').text(
                contact.person_name ||
                '—'
            );

            $('#cbViewRole').text(
                contact.designation ||
                'Contact'
            );

            $('#cbViewOrg').text(
                contact.organisation ||
                '—'
            );

            $('#cbViewChips').html(
                categoryBadge(contact) +
                visibilityBadge(contact)
            );

            $('#cbViewCall')
                .attr(
                    'href',
                    contact.phone_primary
                        ? phoneHref(
                            contact.phone_primary
                        )
                        : '#'
                )
                .toggleClass(
                    'disabled',
                    !contact.phone_primary
                );

            $('#cbViewEmail')
                .attr(
                    'href',
                    contact.email_primary
                        ? mailHref(
                            contact.email_primary
                        )
                        : '#'
                )
                .toggleClass(
                    'disabled',
                    !contact.email_primary
                );

            if (
                contact.website &&
                isExternal(contact.website)
            ) {
                $('#cbViewWebsite')
                    .removeClass('d-none')
                    .attr(
                        'href',
                        contact.website
                    );
            } else {
                $('#cbViewWebsite')
                    .addClass('d-none');
            }

            const details = [
                [
                    'Primary phone',
                    contact.phone_primary,
                    contact.phone_primary
                        ? '<a href="' +
                          escapeHtml(
                              phoneHref(
                                  contact.phone_primary
                              )
                          ) +
                          '">' +
                          escapeHtml(
                              contact.phone_primary
                          ) +
                          '</a>'
                        : '—'
                ],

                [
                    'Alternate phone',
                    contact.phone_alternate,
                    contact.phone_alternate
                        ? '<a href="' +
                          escapeHtml(
                              phoneHref(
                                  contact.phone_alternate
                              )
                          ) +
                          '">' +
                          escapeHtml(
                              contact.phone_alternate
                          ) +
                          '</a>'
                        : '—'
                ],

                [
                    'Primary email',
                    contact.email_primary,
                    contact.email_primary
                        ? '<a href="' +
                          escapeHtml(
                              mailHref(
                                  contact.email_primary
                              )
                          ) +
                          '">' +
                          escapeHtml(
                              contact.email_primary
                          ) +
                          '</a>'
                        : '—'
                ],

                [
                    'Secondary email',
                    contact.email_secondary,
                    contact.email_secondary
                        ? '<a href="' +
                          escapeHtml(
                              mailHref(
                                  contact.email_secondary
                              )
                          ) +
                          '">' +
                          escapeHtml(
                              contact.email_secondary
                          ) +
                          '</a>'
                        : '—'
                ],

                [
                    'Department',
                    contact.department,
                    escapeHtml(
                        contact.department ||
                        '—'
                    )
                ],

                [
                    'City',
                    contact.city,
                    escapeHtml(
                        contact.city ||
                        '—'
                    )
                ],

                [
                    'Relationship',
                    contact.relationship_name,
                    escapeHtml(
                        contact.relationship_name ||
                        '—'
                    )
                ],

                [
                    'Owner',
                    contact.owner_user_id
                        ? 'User #' +
                          contact.owner_user_id
                        : '—',

                    contact.owner_user_id
                        ? 'User #' +
                          contact.owner_user_id
                        : '—'
                ],

                [
                    'Address',
                    contact.address,
                    escapeHtml(
                        contact.address ||
                        '—'
                    )
                ],

                [
                    'Website',
                    contact.website,

                    contact.website &&
                    isExternal(
                        contact.website
                    )
                        ? '<a target="_blank" ' +
                          'rel="noopener" ' +
                          'href="' +
                          escapeHtml(
                              contact.website
                          ) +
                          '">' +
                          escapeHtml(
                              contact.website
                          ) +
                          '</a>'
                        : '—'
                ]
            ];

            $('#cbViewFields').html(
                details.map(
                    item =>
                        '<div class="cb-detail-item">' +
                        '<span>' +
                        escapeHtml(
                            item[0]
                        ) +
                        '</span>' +
                        '<strong>' +
                        item[2] +
                        '</strong>' +
                        '</div>'
                ).join('')
            );

            $('#cbViewTags').html(
                (contact.tags || []).length
                    ? contact.tags
                          .map(
                              tag =>
                                  '<span class="cb-note-tag">' +
                                  escapeHtml(tag) +
                                  '</span>'
                          )
                          .join('')
                    : '<span class="text-muted">' +
                      'No tags' +
                      '</span>'
            );

            $('#cbViewNotes').html(
                contact.notes
                    ? '<div class="cb-note-content">' +
                      escapeHtml(
                          contact.notes
                      ).replace(
                          /\n/g,
                          '<br>'
                      ) +
                      '</div>'
                    : '<span class="text-muted">' +
                      'No notes added.' +
                      '</span>'
            );

            const activity =
                Array.isArray(
                    data.activity
                )
                    ? data.activity
                    : [];

            $('#cbViewActivity').html(
                activity.length
                    ? activity.map(
                        item =>
                            '<div class="cb-timeline-item">' +
                            '<div class="cb-timeline-dot"></div>' +
                            '<div>' +
                            '<strong>' +
                            escapeHtml(
                                String(
                                    item.action ||
                                    ''
                                ).replace(
                                    /_/g,
                                    ' '
                                )
                            ) +
                            '</strong>' +
                            '<span>' +
                            escapeHtml(
                                item.actor_name ||
                                'System'
                            ) +
                            ' · ' +
                            escapeHtml(
                                formatDateTime(
                                    item.created_at
                                )
                            ) +
                            '</span>' +
                            '</div>' +
                            '</div>'
                    ).join('')
                    : '<div class="cb-empty-mini">' +
                      'No activity recorded yet.' +
                      '</div>'
            );

            const posts =
                Array.isArray(
                    data.knowledge_posts
                )
                    ? data.knowledge_posts
                    : [];

            $('#cbViewKnowledge').html(
                posts.length
                    ? posts.map(
                        post =>
                            '<button type="button" ' +
                            'class="cb-knowledge-item">' +
                            '<i class="mdi mdi-file-document-outline"></i>' +
                            '<span>' +
                            '<strong>' +
                            escapeHtml(
                                post.title
                            ) +
                            '</strong>' +
                            '<small>' +
                            escapeHtml(
                                formatDate(
                                    post.published_at
                                )
                            ) +
                            '</small>' +
                            '</span>' +
                            '</button>'
                    ).join('')
                    : '<div class="cb-empty-mini">' +
                      'No linked knowledge posts found.' +
                      '</div>'
            );

            const shares =
                Array.isArray(
                    data.shares
                )
                    ? data.shares
                    : [];

            if (shares.length) {
                $('#cbViewSharesCard')
                    .removeClass('d-none');

                $('#cbViewShares').html(
                    shares.map(
                        share =>
                            '<div class="cb-share-row">' +
                            '<span>' +
                            '<strong>' +
                            escapeHtml(
                                share.grantee_type
                            ) +
                            '</strong> · ' +
                            escapeHtml(
                                share.grantee_id
                            ) +
                            '</span>' +
                            '<span class="cb-share-permission">' +
                            escapeHtml(
                                share.permission
                            ) +
                            '</span>' +
                            '</div>'
                    ).join('')
                );
            }
        }

        function openShareModal(id) {
            $('#cbShareResourceId')
                .val(id);

            $('#cbShareError')
                .addClass('d-none')
                .text('');

            $('#cbShareTarget')
                .empty();

            $('#cbShareExpiry')
                .val('');

            $('#cbSharePermission')
                .val('View')
                .trigger('change.select2');

            $('#cbShareType')
                .val('user')
                .trigger('change.select2');

            populateShareTargets(
                'user'
            );

            modals.share.show();

            loadShareRows(id);
        }

        function populateShareTargets(type) {
            const $target =
                $('#cbShareTarget');

            $target.empty();

            let items = [];

            if (type === 'user') {
                items =
                    state.lookups.staff.map(
                        item => ({
                            id: item.id,
                            text: item.name
                        })
                    );
            } else if (type === 'company') {
                items =
                    state.lookups.companies.map(
                        item => ({
                            id: item.id,
                            text: item.name
                        })
                    );
            } else if (type === 'role') {
                items =
                    state.lookups.roles.map(
                        item => ({
                            id: item.id,
                            text: item.name
                        })
                    );
            }

            if (type === 'group') {
                $('#cbShareTargetWrap')
                    .addClass('d-none');

                return;
            }

            $('#cbShareTargetWrap')
                .removeClass('d-none');

            $target.append(
                '<option value="">' +
                'Select ' +
                type +
                '</option>'
            );

            items.forEach(item => {
                $target.append(
                    $('<option>')
                        .val(item.id)
                        .text(item.text)
                );
            });

            if ($target.hasClass('select2-hidden-accessible')) {
                $target.trigger('change.select2');
            }
        }

        function loadShareRows(id) {
            ajax({
                url: U.shareData,
                method: 'GET',
                data: {
                    resource_type:
                        'contact',

                    resource_id:
                        id
                }
            }).done(function (res) {
                const rows =
                    Array.isArray(
                        res.data
                    )
                        ? res.data
                        : [];

                $('#cbShareExistingList').html(
                    rows.length
                        ? rows.map(
                            row =>
                                '<div class="cb-existing-share">' +

                                '<div>' +

                                '<strong>' +
                                escapeHtml(
                                    row.grantee_type
                                ) +
                                '</strong>' +

                                '<span>' +
                                escapeHtml(
                                    row.grantee_id
                                ) +
                                '</span>' +

                                '</div>' +

                                '<div class="d-flex align-items-center gap-2">' +

                                '<span class="cb-share-permission">' +
                                escapeHtml(
                                    row.permission
                                ) +
                                '</span>' +

                                (
                                    [
                                        'active',
                                        'pending'
                                    ].includes(
                                        row.status
                                    )
                                        ? '<button type="button" ' +
                                          'class="btn btn-sm btn-link ' +
                                          'text-danger p-0" ' +
                                          'data-share-revoke="' +
                                          row.sno +
                                          '">' +
                                          'Revoke' +
                                          '</button>'
                                        : ''
                                ) +

                                '</div>' +

                                '</div>'
                        ).join('')

                        : '<div class="cb-empty-mini">' +
                          'No explicit sharing grants.' +
                          '</div>'
                );
            }).fail(function (xhr) {
                $('#cbShareExistingList').html(
                    '<div class="cb-empty-mini text-danger">' +
                    escapeHtml(
                        getErrorMessage(xhr)
                    ) +
                    '</div>'
                );
            });
        }

        function shareContact() {
            const id =
                Number(
                    $('#cbShareResourceId')
                        .val()
                );

            const type =
                $('#cbShareType')
                    .val();

            const target =
                type === 'group'
                    ? '0'
                    : $('#cbShareTarget')
                        .val();

            const permission =
                $('#cbSharePermission')
                    .val();

            const expires =
                $('#cbShareExpiry')
                    .val() || '';

            if (
                !target &&
                type !== 'group'
            ) {
                showErrorBox(
                    '#cbShareError',
                    'Select an audience.'
                );

                return;
            }

            $('#cbShareSubmit')
                .prop(
                    'disabled',
                    true
                );

            hideErrorBox(
                '#cbShareError'
            );

            ajax({
                url: U.shareStore,
                method: 'POST',
                data: {
                    resource_type:
                        'contact',

                    resource_id:
                        id,

                    grantee_type:
                        type,

                    grantee_id:
                        target,

                    permission:
                        permission,

                    expires_at:
                        expires
                }
            }).done(function (res) {
                toast(
                    res.message ||
                    'Contact shared successfully.'
                );

                loadShareRows(id);
            }).fail(function (xhr) {
                showErrorBox(
                    '#cbShareError',
                    getErrorMessage(xhr)
                );

                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            }).always(function () {
                $('#cbShareSubmit')
                    .prop(
                        'disabled',
                        false
                    );
            });
        }

        function revokeShare(id) {
            askConfirm(
                'Revoke sharing?',
                'This will remove the selected access grant. The contact itself will remain unchanged.',
                function () {
                    ajax({
                        url:
                            url(
                                U.shareRevoke,
                                id
                            ),

                        method:
                            'POST'
                    }).done(function (res) {
                        toast(
                            res.message ||
                            'Share revoked.'
                        );

                        loadShareRows(
                            Number(
                                $('#cbShareResourceId')
                                    .val()
                            )
                        );
                    }).fail(function (xhr) {
                        toast(
                            getErrorMessage(xhr),
                            'error'
                        );
                    });
                }
            );
        }

        function openBulkModal(action) {
            state.bulkAction = action;

            $(
                '#cbBulkCategoryWrap, ' +
                '#cbBulkVisibilityWrap, ' +
                '#cbBulkTagWrap, ' +
                '#cbBulkDeactivateWrap'
            ).addClass('d-none');

            hideErrorBox(
                '#cbBulkError'
            );

            const count =
                state.selected.size;

            $('#cbBulkSubtitle').text(
                count +
                ' contact' +
                (
                    count === 1
                        ? ''
                        : 's'
                ) +
                ' selected'
            );

            if (action === 'category') {
                $('#cbBulkCategoryWrap')
                    .removeClass('d-none');

                $('#cbBulkTitle').text(
                    'Re-categorise contacts'
                );
            } else if (
                action === 'visibility'
            ) {
                $('#cbBulkVisibilityWrap')
                    .removeClass('d-none');

                $('#cbBulkTitle').text(
                    'Change contact visibility'
                );

                toggleVisibilityTargets(
                    '#cbBulkVisibility'
                );
            } else if (action === 'tag') {
                $('#cbBulkTagWrap')
                    .removeClass('d-none');

                $('#cbBulkTitle').text(
                    'Add tags to contacts'
                );
            } else {
                $('#cbBulkDeactivateWrap')
                    .removeClass('d-none');

                $('#cbBulkTitle').text(
                    'Deactivate contacts'
                );
            }

            modals.bulk.show();
        }

        function submitBulk() {
            const action =
                state.bulkAction;

            const data = {
                ids:
                    Array.from(
                        state.selected
                    ),

                action:
                    action
            };

            if (action === 'category') {
                data.category_id =
                    $('#cbBulkCategory')
                        .val();
            } else if (
                action === 'visibility'
            ) {
                data.visibility =
                    $('#cbBulkVisibility')
                        .val();

                data.visibility_company_id =
                    $('#cbBulkVisibilityCompany')
                        .val() || '';

                data.visibility_user_ids =
                    $('#cbBulkVisibilityUsers')
                        .val() || [];
            } else if (action === 'tag') {
                data.tags =
                    $('#cbBulkTags')
                        .val()
                        .trim();
            }

            $('#cbBulkSubmit')
                .prop(
                    'disabled',
                    true
                );

            hideErrorBox(
                '#cbBulkError'
            );

            ajax({
                url: U.bulk,
                method: 'POST',
                data
            }).done(function (res) {
                toast(
                    res.message ||
                    'Bulk action completed.'
                );

                state.selected.clear();

                modals.bulk.hide();

                loadContacts(
                    state.page
                );
            }).fail(function (xhr) {
                showErrorBox(
                    '#cbBulkError',
                    getErrorMessage(xhr)
                );

                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            }).always(function () {
                $('#cbBulkSubmit')
                    .prop(
                        'disabled',
                        false
                    );
            });
        }

        function openMergeModal(ids) {
            ids =
                (
                    ids ||
                    Array.from(
                        state.selected
                    )
                )
                    .map(Number)
                    .filter(Boolean);

            if (ids.length < 2) {
                toast(
                    'Select at least two contacts to merge.',
                    'warning'
                );

                return;
            }

            if (ids.length > 5) {
                toast(
                    'Select no more than five contacts for one merge.',
                    'warning'
                );

                return;
            }

            state.mergeIds = ids;

            $('#cbMergeBody').html(
                '<tr>' +
                '<td colspan="2">' +
                '<div class="cb-modal-loader">' +
                '<span class="spinner-border spinner-border-sm"></span> ' +
                'Preparing merge…' +
                '</div>' +
                '</td>' +
                '</tr>'
            );

            $('#cbMergeContacts')
                .empty();

            hideErrorBox(
                '#cbMergeError'
            );

            modals.merge.show();

            ajax({
                url:
                    U.mergePreview,

                method:
                    'POST',

                data: {
                    ids
                }
            }).done(function (res) {
                const data =
                    res.data || {};

                state.mergeFields =
                    data.fields || {};

                $('#cbMergeContacts').html(
                    (
                        data.contacts ||
                        []
                    ).map(
                        (contact, index) =>
                            '<label class="cb-merge-person ' +
                            (
                                Number(contact.sno) ===
                                Number(
                                    data.default_survivor_id
                                )
                                    ? 'selected'
                                    : ''
                            ) +
                            '">' +

                            '<input type="radio" ' +
                            'name="cbSurvivor" ' +
                            'value="' +
                            contact.sno +
                            '"' +
                            (
                                Number(contact.sno) ===
                                Number(
                                    data.default_survivor_id
                                )
                                    ? ' checked'
                                    : ''
                            ) +
                            '>' +

                            '<span class="cb-merge-avatar">' +
                            escapeHtml(
                                contact.initials ||
                                initials(
                                    contact.person_name
                                )
                            ) +
                            '</span>' +

                            '<span>' +

                            '<strong>' +
                            escapeHtml(
                                contact.person_name
                            ) +
                            '</strong>' +

                            '<small>' +
                            escapeHtml(
                                [
                                    contact.organisation,
                                    contact.email_primary
                                ]
                                    .filter(Boolean)
                                    .join(
                                        ' · '
                                    ) ||
                                'Contact'
                            ) +
                            '</small>' +

                            '</span>' +

                            '</label>'
                    ).join('')
                );

                const labels = {
                    salutation: 'Salutation',
                    person_name: 'Full name',
                    designation: 'Position',
                    organisation: 'Organisation',
                    department: 'Department',
                    phone_primary: 'Primary phone',
                    phone_alternate: 'Alternate phone',
                    email_primary: 'Email',
                    email_secondary: 'Secondary email',
                    city: 'City',
                    address: 'Address',
                    website: 'Website',
                    category_id: 'Category',
                    relationship_id: 'Relationship',
                    tags: 'Tags',
                    notes: 'Notes',
                    profile_photo: 'Profile photo'
                };

                $('#cbMergeBody').html(
                    Object.entries(labels)
                        .map(
                            ([field, label]) => {
                                const options =
                                    Array.isArray(
                                        state.mergeFields[
                                            field
                                        ]
                                    )
                                        ? state.mergeFields[
                                            field
                                        ]
                                        : [];

                                return (
                                    '<tr>' +

                                    '<td>' +
                                    '<strong>' +
                                    label +
                                    '</strong>' +
                                    '</td>' +

                                    '<td>' +

                                    '<select class="form-select form-select-sm select3 cb-merge-field" ' +
                                    'data-field="' +
                                    field +
                                    '">' +

                                    options
                                        .map(
                                            opt =>
                                                '<option value="' +
                                                opt.contact_id +
                                                '">' +
                                                escapeHtml(
                                                    String(
                                                        opt.value ||
                                                        '—'
                                                    )
                                                ) +
                                                ' · Contact #' +
                                                opt.contact_id +
                                                '</option>'
                                        )
                                        .join('') +

                                    '</select>' +

                                    '</td>' +

                                    '</tr>'
                                );
                            }
                        )
                        .join('')
                );

                initContactBookSelect3('#cbMergeBody');
            }).fail(function (xhr) {
                showErrorBox(
                    '#cbMergeError',
                    getErrorMessage(xhr)
                );
            });
        }

        function submitMerge() {
            const survivorId =
                Number(
                    $(
                        'input[name="cbSurvivor"]:checked'
                    ).val()
                );

            if (!survivorId) {
                showErrorBox(
                    '#cbMergeError',
                    'Choose the contact that should survive.'
                );

                return;
            }

            const decisions = {};

            $('.cb-merge-field')
                .each(function () {
                    decisions[
                        $(this).data(
                            'field'
                        )
                    ] = Number(
                        $(this).val()
                    );
                });

            $('#cbMergeSubmit')
                .prop(
                    'disabled',
                    true
                );

            hideErrorBox(
                '#cbMergeError'
            );

            ajax({
                url: U.merge,
                method: 'POST',
                data: {
                    ids:
                        state.mergeIds,

                    survivor_id:
                        survivorId,

                    field_decisions:
                        decisions
                }
            }).done(function (res) {
                toast(
                    res.message ||
                    'Contacts merged successfully.'
                );

                modals.merge.hide();

                state.selected.clear();

                loadContacts(1);
            }).fail(function (xhr) {
                showErrorBox(
                    '#cbMergeError',
                    getErrorMessage(xhr)
                );

                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            }).always(function () {
                $('#cbMergeSubmit')
                    .prop(
                        'disabled',
                        false
                    );
            });
        }
            function askConfirm(
            title,
            text,
            callback
        ) {
            state.confirm = callback;

            $('#cbConfirmTitle')
                .text(title);

            $('#cbConfirmText')
                .text(text);

            modals.confirm.show();
        }

        function performDelete(id) {
            ajax({
                url:
                    url(
                        U.remove,
                        id
                    ),

                method:
                    'DELETE'
            }).done(function (res) {
                toast(
                    res.message ||
                    'Contact deactivated.'
                );

                state.selected.delete(
                    Number(id)
                );

                loadContacts(
                    state.page
                );
            }).fail(function (xhr) {
                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            });
        }

        function performStar(id) {
            ajax({
                url:
                    url(
                        U.star,
                        id
                    ),

                method:
                    'POST'
            }).done(function (res) {
                toast(
                    res.message ||
                    'Favourite updated.'
                );

                const row =
                    state.rows.find(
                        item =>
                            Number(item.sno) ===
                            Number(id)
                    );

                if (row) {
                    row.is_starred =
                        !!(
                            res.data &&
                            res.data.starred
                        );
                }

                loadContacts(
                    state.page
                );
            }).fail(function (xhr) {
                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            });
        }

        function exportContacts(format) {
            const endpoints = {
                csv:
                    U.exportCsv,

                xlsx:
                    U.exportXlsx,

                vcard:
                    U.exportVcard
            };

            const exportUrl =
                endpoints[format];

            if (!exportUrl) {
                return;
            }

            const query =
                buildQuery();

            const params =
                $.param(query);

            const iframe =
                $(
                    '<iframe style="display:none" aria-hidden="true"></iframe>'
                );

            iframe.attr(
                'src',
                exportUrl +
                (
                    params
                        ? '?' +
                          params
                        : ''
                )
            );

            $('body').append(
                iframe
            );

            setTimeout(
                () => iframe.remove(),
                60000
            );

            modals.export.hide();

            toast(
                'Your ' +
                format.toUpperCase() +
                ' export is being prepared.'
            );
        }

        function resetImportWizard() {
            state.import = {
                token: null,
                source: null,
                fileName: null,
                totalRows: 0,
                headers: [],
                rows: [],
                validationPreview: [],
                fields: {},
                mapping: {},
                reportId: null
            };

            $('#cbImportStep1')
                .removeClass('d-none');

            $(
                '#cbImportStep2, ' +
                '#cbImportStep3, ' +
                '#cbImportBackBtn, ' +
                '#cbImportNextBtn'
            ).addClass('d-none');

            $('#cbImportStepper > div')
                .removeClass('active done')
                .first()
                .addClass('active');

            $('#cbImportFile, #cbImportVcard')
                .val('');

            $(
                '#cbImportMapping, ' +
                '#cbImportPreviewHead, ' +
                '#cbImportPreviewBody, ' +
                '#cbImportFileSummary'
            ).empty();

            $('#cbImportError')
                .addClass('d-none')
                .text('');

            $('#cbDownloadImportReport')
                .data('id', '');
        }

        function setImportStep(step) {
            $(
                '#cbImportStep1, ' +
                '#cbImportStep2, ' +
                '#cbImportStep3'
            ).addClass('d-none');

            $('#cbImportStep' + step)
                .removeClass('d-none');

            $('#cbImportStepper > div')
                .each(function (index) {
                    const current =
                        index + 1;

                    $(this)
                        .toggleClass(
                            'active',
                            current === step
                        )
                        .toggleClass(
                            'done',
                            current < step
                        );
                });

            $('#cbImportBackBtn')
                .toggleClass(
                    'd-none',
                    step !== 2
                );

            $('#cbImportNextBtn')
                .toggleClass(
                    'd-none',
                    step !== 2
                );
        }

        function openImportModal() {
            resetImportWizard();

            fillLookupsIntoUI();

            modals.import.show();
        }

        function previewImportFile(file) {
            if (!file) {
                return;
            }

            const form =
                new FormData();

            form.append(
                'file',
                file
            );

            $('#cbImportError')
                .addClass('d-none')
                .text('');

            $('#cbImportStep1 .cb-import-option')
                .addClass(
                    'cb-import-loading'
                );

            $('#cbImportStep1').append(
                '<div id="cbImportUploading" ' +
                'class="cb-modal-loader mt-3">' +
                '<span class="spinner-border spinner-border-sm"></span> ' +
                'Reading and validating file…' +
                '</div>'
            );

            ajax({
                url:
                    U.importPreview,

                method:
                    'POST',

                data:
                    form,

                processData:
                    false,

                contentType:
                    false
            }).done(function (res) {
                const data =
                    res.data || {};

                state.import.token =
                    data.token;

                state.import.source =
                    data.source;

                state.import.fileName =
                    data.file_name;

                state.import.totalRows =
                    Number(
                        data.total_rows ||
                        0
                    );

                state.import.headers =
                    Array.isArray(
                        data.headers
                    )
                        ? data.headers
                        : [];

                state.import.rows =
                    Array.isArray(
                        data.rows
                    )
                        ? data.rows
                        : [];

                state.import.validationPreview =
                    Array.isArray(
                        data.validation_preview
                    )
                        ? data.validation_preview
                        : [];

                state.import.fields =
                    data.fields || {};

                state.import.mapping =
                    data.suggested_mapping ||
                    {};

                $('#cbImportFileSummary').html(
                    '<div class="cb-file-summary-icon">' +
                    '<i class="mdi mdi-file-table-outline"></i>' +
                    '</div>' +

                    '<div>' +

                    '<strong>' +
                    escapeHtml(
                        state.import.fileName ||
                        'Import file'
                    ) +
                    '</strong>' +

                    '<span>' +
                    state.import.totalRows
                        .toLocaleString(
                            'en-IN'
                        ) +
                    ' rows · ' +
                    escapeHtml(
                        state.import.source ||
                        ''
                    ) +
                    '</span>' +

                    '</div>'
                );

                $('#cbImportCategory')
                    .empty()
                    .append(
                        '<option value="">' +
                        'Select category' +
                        '</option>'
                    );

                state.lookups.categories
                    .forEach(
                        category => {
                            $('#cbImportCategory')
                                .append(
                                    $('<option>')
                                        .val(
                                            category.id
                                        )
                                        .text(
                                            category.name
                                        )
                                );
                        }
                    );

                if (
                    state.lookups.categories.length
                ) {
                    $('#cbImportCategory')
                        .val(
                            String(
                                state.lookups
                                    .categories[0]
                                    .id
                            )
                        );
                }

                renderImportMapping();

                renderImportPreviewTable();

                renderImportValidation();

                toggleVisibilityTargets(
                    '#cbImportVisibility'
                );

                setImportStep(2);
            }).fail(function (xhr) {
                showErrorBox(
                    '#cbImportError',
                    getErrorMessage(xhr)
                );
            }).always(function () {
                $('#cbImportStep1 .cb-import-option')
                    .removeClass(
                        'cb-import-loading'
                    );

                $('#cbImportUploading')
                    .remove();
            });
        }

        function renderImportMapping() {
            const fields =
                state.import.fields ||
                {};

            $('#cbImportMapping').html(
                Object.entries(fields)
                    .map(
                        ([field, label]) =>
                            '<div class="cb-import-map-row">' +

                            '<div>' +

                            '<strong>' +
                            escapeHtml(
                                label
                            ) +
                            '</strong>' +

                            '<span>' +
                            escapeHtml(
                                field
                            ) +
                            '</span>' +

                            '</div>' +

                            '<div>' +

                            '<select class="form-select form-select-sm select3 cb-import-map-select" ' +
                            'data-field="' +
                            field +
                            '">' +

                            '<option value="">' +
                            'Do not import' +
                            '</option>' +

                            state.import.headers
                                .map(
                                    header =>
                                        '<option value="' +
                                        escapeHtml(
                                            header
                                        ) +
                                        '"' +
                                        (
                                            state.import.mapping[
                                                field
                                            ] === header
                                                ? ' selected'
                                                : ''
                                        ) +
                                        '>' +
                                        escapeHtml(
                                            header
                                        ) +
                                        '</option>'
                                )
                                .join('') +

                            '</select>' +

                            '</div>' +

                            '</div>'
                    )
                    .join('')
            );

            initContactBookSelect3('#cbImportMapping');

        }

        function renderImportValidation() {
            const rows =
                state.import.validationPreview ||
                [];

            const statusMap = {
                ready: [
                    'Ready',
                    'cb-validation-ready',
                    'check-circle-outline'
                ],

                duplicate: [
                    'Possible duplicate',
                    'cb-validation-duplicate',
                    'alert-outline'
                ],

                invalid: [
                    'Invalid',
                    'cb-validation-invalid',
                    'alert-circle-outline'
                ]
            };

            $('#cbImportValidationList').html(
                rows.length
                    ? rows
                          .map(item => {
                              const meta =
                                  statusMap[
                                      item.status
                                  ] ||
                                  statusMap.invalid;

                              return (
                                  '<div class="cb-validation-row">' +

                                  '<span class="cb-validation-status ' +
                                  meta[1] +
                                  '">' +

                                  '<i class="mdi mdi-' +
                                  meta[2] +
                                  '"></i>' +

                                  meta[0] +

                                  '</span>' +

                                  '<strong>Row ' +
                                  Number(
                                      item.row ||
                                      0
                                  ) +
                                  '</strong>' +

                                  '<span class="cb-validation-name">' +
                                  escapeHtml(
                                      item.name ||
                                      'Unnamed'
                                  ) +
                                  '</span>' +

                                  '<small>' +
                                  escapeHtml(
                                      item.reason ||
                                      ''
                                  ) +
                                  '</small>' +

                                  '</div>'
                              );
                          })
                          .join('')

                    : '<div class="cb-empty-mini">' +
                      'No validation preview available.' +
                      '</div>'
            );
        }

        function renderImportPreviewTable() {
            const headers =
                state.import.headers
                    .slice(0, 6);

            $('#cbImportPreviewHead').html(
                '<tr>' +
                headers
                    .map(
                        h =>
                            '<th>' +
                            escapeHtml(h) +
                            '</th>'
                    )
                    .join('') +
                '</tr>'
            );

            $('#cbImportPreviewBody').html(
                state.import.rows
                    .slice(0, 10)
                    .map(
                        row =>
                            '<tr>' +
                            headers
                                .map(
                                    h =>
                                        '<td>' +
                                        escapeHtml(
                                            row[h] ??
                                            ''
                                        ) +
                                        '</td>'
                                )
                                .join('') +
                            '</tr>'
                    )
                    .join('')
            );
        }
            function commitImport() {
            $('.cb-import-map-select')
                .each(function () {
                    state.import.mapping[
                        $(this).data('field')
                    ] = $(this).val() || null;
                });

            const categoryId =
                $('#cbImportCategory')
                    .val();

            if (!categoryId) {
                showErrorBox(
                    '#cbImportError',
                    'Select a default category before importing.'
                );

                return;
            }

            const payload = {
                token:
                    state.import.token,

                mapping:
                    state.import.mapping,

                defaults: {
                    category_id:
                        Number(
                            categoryId
                        ),

                    visibility:
                        $('#cbImportVisibility')
                            .val(),

                    visibility_company_id:
                        $('#cbImportVisibilityCompany')
                            .val() ||
                        null,

                    visibility_user_ids:
                        $('#cbImportVisibilityUsers')
                            .val() ||
                        []
                },

                duplicate_mode:
                    $('#cbImportDuplicateMode')
                        .val()
            };

            $('#cbImportNextBtn')
                .prop(
                    'disabled',
                    true
                );

            hideErrorBox(
                '#cbImportError'
            );

            ajax({
                url:
                    U.importCommit,

                method:
                    'POST',

                contentType:
                    'application/json',

                data:
                    JSON.stringify(
                        payload
                    )
            }).done(function (res) {
                const data =
                    res.data || {};

                $('#cbImportImported').text(
                    Number(
                        data.imported ||
                        0
                    )
                        .toLocaleString(
                            'en-IN'
                        )
                );

                $('#cbImportMerged').text(
                    Number(
                        data.merged ||
                        0
                    )
                        .toLocaleString(
                            'en-IN'
                        )
                );

                $('#cbImportSkipped').text(
                    Number(
                        data.skipped ||
                        0
                    )
                        .toLocaleString(
                            'en-IN'
                        )
                );

                $('#cbImportInvalid').text(
                    Number(
                        data.invalid ||
                        0
                    )
                        .toLocaleString(
                            'en-IN'
                        )
                );

                $('#cbImportCompleteText').text(
                    (
                        data.file_name ||
                        'The imported file'
                    ) +
                    ' has been processed.'
                );

                state.import.reportId =
                    data.import_id;

                $('#cbDownloadImportReport')
                    .data(
                        'id',
                        data.import_id
                    );

                setImportStep(3);

                loadContacts(1);

                toast(
                    res.message ||
                    'Contacts imported successfully.'
                );
            }).fail(function (xhr) {
                showErrorBox(
                    '#cbImportError',
                    getErrorMessage(xhr)
                );

                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            }).always(function () {
                $('#cbImportNextBtn')
                    .prop(
                        'disabled',
                        false
                    );
            });
        }

        function loadSavedSearches() {
            $('#cbSavedSearchList').html(
                '<div class="cb-modal-loader">' +
                '<span class="spinner-border spinner-border-sm"></span> ' +
                'Loading…' +
                '</div>'
            );

            modals.saved.show();

            ajax({
                url:
                    U.history,

                method:
                    'GET'
            }).done(function (res) {
                const rows =
                    Array.isArray(
                        res.data
                    )
                        ? res.data
                        : [];

                $('#cbSavedSearchList').html(
                    rows.length
                        ? rows
                              .map(
                                  row =>
                                      '<button type="button" ' +
                                      'class="cb-saved-search" ' +
                                      'data-search="' +
                                      escapeHtml(
                                          row.search_text
                                      ) +
                                      '">' +

                                      '<i class="mdi mdi-history"></i>' +

                                      '<span>' +

                                      '<strong>' +
                                      escapeHtml(
                                          row.search_text
                                      ) +
                                      '</strong>' +

                                      '<small>' +
                                      escapeHtml(
                                          formatDateTime(
                                              row.created_at
                                          )
                                      ) +
                                      '</small>' +

                                      '</span>' +

                                      '<i class="mdi mdi-arrow-top-right"></i>' +

                                      '</button>'
                              )
                              .join('')

                        : '<div class="cb-empty-mini">' +
                          'No saved searches yet.' +
                          '</div>'
                );
            }).fail(function (xhr) {
                $('#cbSavedSearchList').html(
                    '<div class="cb-empty-mini text-danger">' +
                    escapeHtml(
                        getErrorMessage(xhr)
                    ) +
                    '</div>'
                );
            });
        }

        function saveCurrentSearch() {
            const text =
                $('#cbSearch')
                    .val()
                    .trim();

            if (!text) {
                toast(
                    'Enter a search phrase before saving.',
                    'warning'
                );

                return;
            }

            ajax({
                url:
                    U.saveSearch,

                method:
                    'POST',

                data: {
                    search_text:
                        text
                }
            }).done(function (res) {
                toast(
                    res.message ||
                    'Search saved.'
                );
            }).fail(function (xhr) {
                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            });
        }

        function startGoogleConnect() {
            const popup =
                window.open(
                    U.googleConnect,
                    'egpkGoogleContactImport',
                    'width=620,height=720,menubar=no,toolbar=no,location=yes,resizable=yes,scrollbars=yes'
                );

            if (!popup) {
                toast(
                    'Allow popups to connect Google Contacts.',
                    'warning'
                );
            }
        }

        function loadGoogleGroups() {
            $('#cbGoogleError')
                .addClass('d-none')
                .text('');

            $('#cbGoogleGroupsList').html(
                '<div class="cb-modal-loader">' +
                '<span class="spinner-border spinner-border-sm"></span> ' +
                'Loading Google contact groups…' +
                '</div>'
            );

            ajax({
                url:
                    U.googleGroups,

                method:
                    'GET'
            }).done(function (res) {
                state.googleGroups =
                    (
                        res.data &&
                        res.data.groups
                    ) || [];

                $('#cbGoogleGroupsList').html(
                    '<label class="cb-google-all">' +

                    '<input type="checkbox" ' +
                    'class="form-check-input" ' +
                    'id="cbGoogleAllGroups" checked>' +

                    '<span>' +

                    '<strong>' +
                    'All Google Contacts' +
                    '</strong>' +

                    '<small>' +
                    'Import contacts from every available group' +
                    '</small>' +

                    '</span>' +

                    '</label>' +

                    (
                        state.googleGroups.length
                            ? state.googleGroups
                                  .map(
                                      group =>
                                          '<label class="cb-google-group">' +

                                          '<input type="checkbox" ' +
                                          'class="form-check-input cb-google-group-check" ' +
                                          'value="' +
                                          escapeHtml(
                                              group.id
                                          ) +
                                          '">' +

                                          '<span>' +

                                          '<strong>' +
                                          escapeHtml(
                                              group.name
                                          ) +
                                          '</strong>' +

                                          '<small>' +
                                          Number(
                                              group.member_count ||
                                              0
                                          ) +
                                          ' members' +
                                          '</small>' +

                                          '</span>' +

                                          '</label>'
                                  )
                                  .join('')

                            : '<div class="cb-empty-mini">' +
                              'Google returned no named contact groups. You can import all contacts.' +
                              '</div>'
                    )
                );

                if (
                    state.lookups.categories.length
                ) {
                    populateSelect(
                        '#cbGoogleCategory',
                        state.lookups.categories,
                        'Select category'
                    );

                    $('#cbGoogleCategory')
                        .val(
                            String(
                                state.lookups
                                    .categories[0]
                                    .id
                            )
                        );
                }

                modals.google.show();
            }).fail(function (xhr) {
                showErrorBox(
                    '#cbGoogleError',
                    getErrorMessage(xhr)
                );

                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            });
        }

        function googleImport() {
            const groupIds =
                $('#cbGoogleAllGroups')
                    .is(':checked')
                    ? []
                    : $(
                        '.cb-google-group-check:checked'
                    )
                        .map(
                            function () {
                                return $(this)
                                    .val();
                            }
                        )
                        .get();

            const categoryId =
                $('#cbGoogleCategory')
                    .val();

            if (!categoryId) {
                showErrorBox(
                    '#cbGoogleError',
                    'Select a ContactBook category.'
                );

                return;
            }

            $('#cbGoogleImportSubmit')
                .prop(
                    'disabled',
                    true
                );

            hideErrorBox(
                '#cbGoogleError'
            );

            ajax({
                url:
                    U.googleImport,

                method:
                    'POST',

                data: {
                    group_ids:
                        groupIds,

                    category_id:
                        categoryId,

                    visibility:
                        'Private',

                    duplicate_mode:
                        $('#cbGoogleDuplicateMode')
                            .val()
                }
            }).done(function (res) {
                toast(
                    res.message ||
                    'Google contacts imported.'
                );

                modals.google.hide();

                modals.import.hide();

                loadContacts(1);
            }).fail(function (xhr) {
                showErrorBox(
                    '#cbGoogleError',
                    getErrorMessage(xhr)
                );

                toast(
                    getErrorMessage(xhr),
                    'error'
                );
            }).always(function () {
                $('#cbGoogleImportSubmit')
                    .prop(
                        'disabled',
                        false
                    );
            });
        }

        function bindEvents() {
            $('#cbAddBtn, #cbEmptyAddBtn')
                .on(
                    'click',
                    function () {
                        openContactModal();
                    }
                );

            $('#cbRefreshBtn, #cbRetryBtn')
                .on(
                    'click',
                    function () {
                        loadLookups()
                            .always(
                                () =>
                                    loadContacts(
                                        state.page
                                    )
                            );
                    }
                );

            $('#cbSavedSearchBtn')
                .on(
                    'click',
                    loadSavedSearches
                );

            $('#cbSaveSearchBtn')
                .on(
                    'click',
                    saveCurrentSearch
                );

            $('#cbSearch')
                .on(
                    'input',
                    debounce(
                        function () {
                            $('#cbSearchClear')
                                .toggleClass(
                                    'd-none',
                                    !$(this).val()
                                );

                            state.page = 1;

                            loadContacts(1);
                        },
                        330
                    )
                );

            $('#cbSearchClear')
                .on(
                    'click',
                    function () {
                        $('#cbSearch')
                            .val('')
                            .trigger('input')
                            .trigger('focus');
                    }
                );

            $(
                '#cbFilterCategory, ' +
                '#cbFilterVisibility, ' +
                '#cbFilterCompany'
            ).on(
                'change',
                function () {
                    state.page = 1;
                    loadContacts(1);
                }
            );

            $('#cbFilterCity')
                .on(
                    'input',
                    debounce(
                        function () {
                            state.page = 1;
                            loadContacts(1);
                        },
                        330
                    )
                );

            $('#cbAdvancedFilterBtn')
                .on(
                    'click',
                    function () {
                        $('#cbAdvancedFilterPanel')
                            .toggleClass(
                                'd-none'
                            );
                    }
                );

            $('#cbApplyFilters')
                .on(
                    'click',
                    function () {
                        if (
                            $('#cbFilterCompanyAdvanced')
                                .val()
                        ) {
                            $('#cbFilterCompany').val(
                                $('#cbFilterCompanyAdvanced')
                                    .val()
                            );
                        }

                        state.page = 1;

                        loadContacts(1);

                        $('#cbAdvancedFilterPanel')
                            .addClass(
                                'd-none'
                            );
                    }
                );

            $('#cbClearFilters')
                .on(
                    'click',
                    function () {
                        $('#cbSearch, #cbFilterCity')
                            .val('');

                        $(
                            '#cbFilterCategory, ' +
                            '#cbFilterVisibility, ' +
                            '#cbFilterCompany, ' +
                            '#cbFilterCompanyAdvanced'
                        ).val('');

                        $('#cbSearchClear')
                            .addClass(
                                'd-none'
                            );

                        state.page = 1;

                        loadContacts(1);
                    }
                );

            $('#cbActiveFilters')
                .on(
                    'click',
                    '[data-filter-key], .cb-clear-all-filters',
                    function () {
                        const key =
                            $(this)
                                .data(
                                    'filter-key'
                                );

                        if (!key) {
                            $('#cbClearFilters')
                                .trigger(
                                    'click'
                                );

                            return;
                        }

                        if (key === 'search') {
                            $('#cbSearch')
                                .val('');
                        }

                        if (key === 'category') {
                            $('#cbFilterCategory')
                                .val('');
                        }

                        if (key === 'visibility') {
                            $('#cbFilterVisibility')
                                .val('');
                        }

                        if (key === 'company') {
                            $(
                                '#cbFilterCompany, ' +
                                '#cbFilterCompanyAdvanced'
                            ).val('');
                        }

                        if (key === 'city') {
                            $('#cbFilterCity')
                                .val('');
                        }

                        $('#cbSearchClear')
                            .toggleClass(
                                'd-none',
                                !$('#cbSearch').val()
                            );

                        loadContacts(1);
                    }
                );

            $('[data-cb-view]')
                .on(
                    'click',
                    function () {
                        state.view =
                            $(this)
                                .data(
                                    'cb-view'
                                );

                        $('[data-cb-view]')
                            .removeClass(
                                'active'
                            );

                        $(this)
                            .addClass(
                                'active'
                            );

                        if (state.rows.length) {
                            $('#cbTableView')
                                .toggleClass(
                                    'd-none',
                                    state.view !==
                                    'table'
                                );

                            $('#cbCardView')
                                .toggleClass(
                                    'd-none',
                                    state.view !==
                                    'cards'
                                );
                        }
                    }
                );
                        $('#cbSelectAll')
                .on(
                    'change',
                    function () {
                        const checked =
                            $(this).is(':checked');

                        state.rows.forEach(
                            contact => {
                                const id =
                                    Number(
                                        contact.sno
                                    );

                                if (checked) {
                                    state.selected.add(
                                        id
                                    );
                                } else {
                                    state.selected.delete(
                                        id
                                    );
                                }
                            }
                        );

                        syncSelectionUI();
                    }
                );

            $('#cbTableBody')
                .on(
                    'change',
                    '.cb-row-check',
                    function () {
                        const id =
                            Number(
                                $(this)
                                    .data('id')
                            );

                        if (
                            $(this).is(':checked')
                        ) {
                            state.selected.add(
                                id
                            );
                        } else {
                            state.selected.delete(
                                id
                            );
                        }

                        syncSelectionUI();
                    }
                );

            $('#cbTableBody, #cbCardView')
                .on(
                    'click',
                    '[data-action]',
                    function (event) {
                        const action =
                            $(this).data(
                                'action'
                            );

                        const id =
                            Number(
                                $(this).data(
                                    'id'
                                )
                            );

                        if (action === 'view') {
                            openViewModal(id);
                        }

                        if (action === 'edit') {
                            openContactModal(id);
                        }

                        if (action === 'share') {
                            openShareModal(id);
                        }

                        if (action === 'star') {
                            performStar(id);
                        }

                        if (action === 'delete') {
                            askConfirm(
                                'Deactivate contact?',
                                'This removes the contact from the active directory but keeps the record as inactive.',
                                () =>
                                    performDelete(
                                        id
                                    )
                            );
                        }
                    }
                );

            $('#cbTableBody, #cbCardView')
                .on(
                    'click',
                    '.cb-icon-copy',
                    function (event) {
                        event.preventDefault();

                        event.stopPropagation();

                        const value =
                            $(this)
                                .data(
                                    'copy'
                                );

                        if (!navigator.clipboard) {
                            toast(
                                'Clipboard access is unavailable in this browser.',
                                'warning'
                            );

                            return;
                        }

                        navigator.clipboard
                            .writeText(
                                String(
                                    value ||
                                    ''
                                )
                            )
                            .then(
                                () =>
                                    toast(
                                        'Copied to clipboard.'
                                    ),
                                () =>
                                    toast(
                                        'Unable to copy.',
                                        'error'
                                    )
                            );
                    }
                );

            $('#cbContactForm')
                .on(
                    'submit',
                    function (event) {
                        event.preventDefault();

                        submitContact();
                    }
                );

            $('#cbVisibility')
                .on(
                    'change',
                    function () {
                        toggleVisibilityTargets(
                            '#cbVisibility'
                        );

                        if (
                            $(this).val() ===
                                'Company' &&
                            !$('#cbVisibilityCompanyId')
                                .val()
                        ) {
                            $('#cbVisibilityCompanyId')
                                .val(
                                    $('#cbCompanyId')
                                        .val() ||
                                    ''
                                );
                        }
                    }
                );

            $(
                '#cbImportVisibility, ' +
                '#cbBulkVisibility'
            ).on(
                'change',
                function () {
                    toggleVisibilityTargets(
                        '#' +
                        this.id
                    );
                }
            );

            $('#cbCompanyId')
                .on(
                    'change',
                    function () {
                        if (
                            $('#cbVisibility')
                                .val() ===
                                'Company' &&
                            !$('#cbVisibilityCompanyId')
                                .val()
                        ) {
                            $('#cbVisibilityCompanyId')
                                .val(
                                    $(this)
                                        .val()
                                );
                        }
                    }
                );

            $('#cbOwnerSelect')
                .on(
                    'change',
                    function () {
                        $('#cbOwnerUserId')
                            .val(
                                $(this)
                                    .val() ||
                                ''
                            );
                    }
                );

            $(
                '#cbPersonName, ' +
                '#cbPhonePrimary, ' +
                '#cbEmailPrimary'
            ).on(
                'blur',
                debounce(
                    checkDuplicateLive,
                    150
                )
            );

            $('#cbKeepDuplicateBtn')
                .on(
                    'click',
                    function () {
                        $('#cbForceDuplicate')
                            .val('1');

                        $('#cbDuplicateAlert')
                            .addClass(
                                'd-none'
                            );

                        toast(
                            'Duplicate protection bypassed for this save.',
                            'warning'
                        );
                    }
                );

            $('#cbOpenDuplicateBtn')
                .on(
                    'click',
                    function () {
                        if (
                            state.duplicateOpenId
                        ) {
                            modals.contact.hide();

                            openViewModal(
                                state.duplicateOpenId
                            );
                        }
                    }
                );

            $('#cbViewEditBtn')
                .on(
                    'click',
                    function () {
                        if (
                            !state.currentContact
                        ) {
                            return;
                        }

                        modals.view.hide();

                        openContactModal(
                            state.currentContact.sno
                        );
                    }
                );

            $('#cbViewShareBtn')
                .on(
                    'click',
                    function () {
                        if (
                            !state.currentContact
                        ) {
                            return;
                        }

                        openShareModal(
                            state.currentContact.sno
                        );
                    }
                );

            $('#cbCallPreview')
                .on(
                    'click',
                    function () {
                        const value =
                            $('#cbPhonePrimary')
                                .val()
                                .trim();

                        if (value) {
                            window.location.href =
                                phoneHref(
                                    value
                                );
                        }
                    }
                );

            $('#cbMailPreview')
                .on(
                    'click',
                    function () {
                        const value =
                            $('#cbEmailPrimary')
                                .val()
                                .trim();

                        if (value) {
                            window.location.href =
                                mailHref(
                                    value
                                );
                        }
                    }
                );

            $('#cbExportBtn')
                .on(
                    'click',
                    function () {
                        modals.export.show();
                    }
                );

            $('[data-cb-export]')
                .on(
                    'click',
                    function () {
                        exportContacts(
                            $(this)
                                .data(
                                    'cb-export'
                                )
                        );
                    }
                );

            $('#cbImportBtn')
                .on(
                    'click',
                    openImportModal
                );

            $('#cbChooseFileBtn')
                .on(
                    'click',
                    function () {
                        $('#cbImportFile')
                            .trigger(
                                'click'
                            );
                    }
                );

            $('#cbChooseVcardBtn')
                .on(
                    'click',
                    function () {
                        $('#cbImportVcard')
                            .trigger(
                                'click'
                            );
                    }
                );

            $('#cbImportFile')
                .on(
                    'change',
                    function () {
                        previewImportFile(
                            this.files[0]
                        );
                    }
                );

            $('#cbImportVcard')
                .on(
                    'change',
                    function () {
                        previewImportFile(
                            this.files[0]
                        );
                    }
                );

            $('#cbTemplateBtn')
                .on(
                    'click',
                    function () {
                        const iframe =
                            $(
                                '<iframe style="display:none" aria-hidden="true"></iframe>'
                            );

                        iframe.attr(
                            'src',
                            U.importTemplate
                        );

                        $('body')
                            .append(
                                iframe
                            );

                        setTimeout(
                            () =>
                                iframe.remove(),
                            30000
                        );
                    }
                );

            $('#cbImportNextBtn')
                .on(
                    'click',
                    commitImport
                );

            $('#cbImportBackBtn')
                .on(
                    'click',
                    function () {
                        setImportStep(1);
                    }
                );

            $('#cbDownloadImportReport')
                .on(
                    'click',
                    function () {
                        const id =
                            $(this)
                                .data(
                                    'id'
                                );

                        if (!id) {
                            return;
                        }

                        const iframe =
                            $(
                                '<iframe style="display:none" aria-hidden="true"></iframe>'
                            );

                        iframe.attr(
                            'src',
                            url(
                                U.importReport,
                                id
                            )
                        );

                        $('body')
                            .append(
                                iframe
                            );

                        setTimeout(
                            () =>
                                iframe.remove(),
                            30000
                        );
                    }
                );

            $('#cbGoogleBtn')
                .on(
                    'click',
                    startGoogleConnect
                );

            $('#cbGoogleImportSubmit')
                .on(
                    'click',
                    googleImport
                );

            $('#cbGoogleGroupsList')
                .on(
                    'change',
                    '#cbGoogleAllGroups',
                    function () {
                        $(
                            '.cb-google-group-check'
                        ).prop(
                            'checked',
                            false
                        );
                    }
                );

            $('#cbGoogleGroupsList')
                .on(
                    'change',
                    '.cb-google-group-check',
                    function () {
                        if (
                            $(this)
                                .is(':checked')
                        ) {
                            $('#cbGoogleAllGroups')
                                .prop(
                                    'checked',
                                    false
                                );
                        }

                        if (
                            !$('.cb-google-group-check:checked')
                                .length
                        ) {
                            $('#cbGoogleAllGroups')
                                .prop(
                                    'checked',
                                    true
                                );
                        }
                    }
                );

            $('[data-cb-bulk]')
                .on(
                    'click',
                    function () {
                        const action =
                            $(this)
                                .data(
                                    'cb-bulk'
                                );

                        if (
                            action ===
                                'category' ||
                            action ===
                                'visibility' ||
                            action ===
                                'tag' ||
                            action ===
                                'deactivate'
                        ) {
                            openBulkModal(
                                action
                            );
                        }
                    }
                );

            $('#cbClearSelection')
                .on(
                    'click',
                    function () {
                        state.selected.clear();

                        syncSelectionUI();
                    }
                );

            $('#cbBulkSubmit')
                .on(
                    'click',
                    submitBulk
                );

            $('#cbMergeSubmit')
                .on(
                    'click',
                    submitMerge
                );

            $('#cbShareType')
                .on(
                    'change',
                    function () {
                        populateShareTargets(
                            $(this)
                                .val()
                        );
                    }
                );

            $('#cbShareSubmit')
                .on(
                    'click',
                    shareContact
                );

            $('#cbShareExistingList')
                .on(
                    'click',
                    '[data-share-revoke]',
                    function () {
                        revokeShare(
                            Number(
                                $(this)
                                    .data(
                                        'share-revoke'
                                    )
                            )
                        );
                    }
                );

            $('#cbConfirmProceed')
                .on(
                    'click',
                    function () {
                        const callback =
                            state.confirm;

                        state.confirm = null;

                        modals.confirm.hide();

                        if (
                            typeof callback ===
                            'function'
                        ) {
                            callback();
                        }
                    }
                );

            $('#cbSavedSearchList')
                .on(
                    'click',
                    '.cb-saved-search',
                    function () {
                        const value =
                            $(this)
                                .data(
                                    'search'
                                ) ||
                            '';

                        $('#cbSearch')
                            .val(value)
                            .trigger(
                                'input'
                            );

                        modals.saved.hide();
                    }
                );

            $(document)
                .on(
                    'click',
                    '.cb-quick-copy',
                    function () {
                        const value =
                            $(this)
                                .data(
                                    'copy'
                                );

                        if (
                            navigator.clipboard
                        ) {
                            navigator.clipboard
                                .writeText(
                                    String(
                                        value ||
                                        ''
                                    )
                                )
                                .then(
                                    () =>
                                        toast(
                                            'Copied to clipboard.'
                                        ),
                                    () =>
                                        toast(
                                            'Unable to copy.',
                                            'error'
                                        )
                                );
                        }
                    }
                );

            window.addEventListener(
                'message',
                function (event) {
                    if (
                        event.origin !==
                        window.location.origin
                    ) {
                        return;
                    }

                    const data =
                        event.data ||
                        {};

                    if (
                        data.source !==
                        'egpk-contactbook-google'
                    ) {
                        return;
                    }

                    if (!data.success) {
                        toast(
                            data.message ||
                            'Google connection failed.',
                            'error'
                        );

                        return;
                    }

                    state.googleConnected =
                        true;

                    toast(
                        data.message ||
                        'Google connected.'
                    );

                    loadGoogleGroups();
                }
            );

            $('#cbImportVisibility')
                .on(
                    'change',
                    function () {
                        toggleVisibilityTargets(
                            '#cbImportVisibility'
                        );
                    }
                );

            $('#cbBulkVisibility')
                .on(
                    'change',
                    function () {
                        toggleVisibilityTargets(
                            '#cbBulkVisibility'
                        );
                    }
                );

            $(document)
                .on(
                    'shown.bs.modal',
                    '.cb-modal',
                    function () {
                        const $modal =
                            $(this);

                        const $focus =
                            $modal
                                .find(
                                    'input:not([type="hidden"]), select, textarea'
                                )
                                .filter(
                                    ':visible'
                                )
                                .first();

                        if (
                            $focus.length &&
                            $modal.attr(
                                'id'
                            ) ===
                                'cbContactModal'
                        ) {
                            setTimeout(
                                () =>
                                    $focus.trigger(
                                        'focus'
                                    ),
                                120
                            );
                        }
                    }
                );

            $(window)
                .on(
                    'keydown',
                    function (event) {
                        if (
                            (
                                event.ctrlKey ||
                                event.metaKey
                            ) &&
                            event.key
                                .toLowerCase() ===
                                'k'
                        ) {
                            event.preventDefault();

                            $('#cbSearch')
                                .trigger(
                                    'focus'
                                );
                        }

                        if (
                            event.key ===
                                'Escape' &&
                            $(
                                '#cbAdvancedFilterPanel'
                            ).is(
                                ':visible'
                            )
                        ) {
                            $('#cbAdvancedFilterPanel')
                                .addClass(
                                    'd-none'
                                );
                        }
                    }
                );
        }

        function debounce(
            fn,
            wait
        ) {
            let timer;

            return function () {
                const context =
                    this;

                const args =
                    arguments;

                clearTimeout(
                    timer
                );

                timer =
                    setTimeout(
                        () =>
                            fn.apply(
                                context,
                                args
                            ),
                        wait
                    );
            };
        }

        bindEvents();

        loadLookups()
            .always(
                function () {
                    loadContacts(1);
                }
            );
    });
})(jQuery);
</script>
@endsection
