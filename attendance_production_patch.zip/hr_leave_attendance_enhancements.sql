-- HR Leave / Attendance enhancement migration
-- Target: MariaDB 10.4+ (database: ryans_infra)
-- Safe to run more than once. Select the target database before executing.
-- Take a full database backup before applying to production.

USE `ryans_infra`;

SET @hr_leave_mode_sql = IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'ryans_leave_requests'
       AND COLUMN_NAME = 'leave_mode') = 0,
    'ALTER TABLE `ryans_leave_requests` ADD COLUMN `leave_mode` VARCHAR(20) NOT NULL DEFAULT ''full'' AFTER `days`',
    'SELECT ''ryans_leave_requests.leave_mode already exists'' AS migration_status'
);
PREPARE hr_leave_mode_stmt FROM @hr_leave_mode_sql;
EXECUTE hr_leave_mode_stmt;
DEALLOCATE PREPARE hr_leave_mode_stmt;

SET @hr_attendance_mode_sql = IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = 'ryans_staff_attendance'
       AND COLUMN_NAME = 'leave_mode') = 0,
    'ALTER TABLE `ryans_staff_attendance` ADD COLUMN `leave_mode` VARCHAR(20) NULL DEFAULT NULL AFTER `time_end`',
    'SELECT ''ryans_staff_attendance.leave_mode already exists'' AS migration_status'
);
PREPARE hr_attendance_mode_stmt FROM @hr_attendance_mode_sql;
EXECUTE hr_attendance_mode_stmt;
DEALLOCATE PREPARE hr_attendance_mode_stmt;

-- Existing leave rows remain full-day by default; no historical rows are deleted.
-- PR and OD continue to store start/end in the existing time_start/time_end columns.
-- Shared carry-forward caps are saved by the application to both employment_type policies.
