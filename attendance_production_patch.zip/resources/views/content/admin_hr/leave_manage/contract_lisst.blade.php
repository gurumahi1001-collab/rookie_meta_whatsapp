@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('content')

{{-- ============================================================
    PERMANENT STAFF - LEAVE MANAGEMENT
============================================================= --}}



<div class="container-fluid px-0">

    {{-- ============================================================
        PAGE HEADER
    ============================================================= --}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-3 p-md-4">

            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3">

                <div>
                    <span class="text-uppercase fw-bold text-muted" style="font-size:10px; letter-spacing:1px;">
                        Contract Staff
                    </span>

                    <h4 class="mb-1 fw-bold" style="color:#0C3C62;">
                        Leave Management
                    </h4>

                    <p class="mb-0 text-muted small">
                        Manage leave applications, approvals and employee leave balances.
                    </p>
                </div>

                <button type="button" class="btn btn-primary btn-sm rounded-3 px-3" data-bs-toggle="modal"
                    data-bs-target="#applyLeaveModal">

                    <i class="mdi mdi-plus me-1"></i>
                    Apply Leave

                </button>

            </div>

        </div>
    </div>


    {{-- ============================================================
        LEAVE MANAGEMENT KPI CARDS
    ============================================================= --}}
    <div class="row g-3 mb-4">

        {{-- Total Personnel --}}
        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center gap-3">

                        <div class="leave-kpi-icon bg-primary-subtle text-primary">
                            <i class="mdi mdi-account-group-outline"></i>
                        </div>

                        <div class="min-w-0">

                            <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                Total Personnel
                            </span>

                            <span class="d-block fw-bold font-monospace leave-kpi-value" style="color:#0C3C62;">
                                Loading…
                            </span>

                            <span class="d-block text-muted leave-kpi-description">
                                Permanent employees
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- On Leave Today --}}
        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center gap-3">

                        <div class="leave-kpi-icon bg-warning-subtle text-warning">
                            <i class="mdi mdi-calendar-account-outline"></i>
                        </div>

                        <div class="min-w-0">

                            <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                On Leave Today
                            </span>

                            <span class="d-block fw-bold font-monospace leave-kpi-value text-warning">
                                Loading…
                            </span>

                            <span class="d-block text-muted leave-kpi-description">
                                Active leave records
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- Pending Requests --}}
        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center gap-3">

                        <div class="leave-kpi-icon bg-warning-subtle text-warning">
                            <i class="mdi mdi-alert-circle-outline"></i>
                        </div>

                        <div class="min-w-0">

                            <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                Pending Requests
                            </span>

                            <span class="d-block fw-bold font-monospace leave-kpi-value text-warning">
                                Loading…
                            </span>

                            <span class="d-block text-muted leave-kpi-description">
                                Awaiting HR review
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- Approved --}}
        <div class="col-12 col-sm-6 col-xl-3">

            <div class="card border-0 shadow-sm rounded-4 h-100">

                <div class="card-body p-3">

                    <div class="d-flex align-items-center gap-3">

                        <div class="leave-kpi-icon bg-success-subtle text-success">
                            <i class="mdi mdi-check-circle-outline"></i>
                        </div>

                        <div class="min-w-0">

                            <span class="d-block text-muted text-uppercase fw-bold leave-kpi-label">
                                Approved This Month
                            </span>

                            <span class="d-block fw-bold font-monospace leave-kpi-value text-success">
                                Loading…
                            </span>

                            <span class="d-block text-muted leave-kpi-description">
                                July 2026
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- ============================================================
        LEAVE MANAGEMENT NAVIGATION
    ============================================================= --}}
    <div class="card border-0 shadow-sm rounded-4 mb-4">

        <div class="card-body p-2">

            <div class="row g-2 align-items-center">

                <div class="col-12 col-lg">

                    <div class="d-flex flex-wrap gap-2">
                        {{-- Leave Applications Link --}}
                        <a href="{{ url('/admin-hr/leave_management/contract') }}"
                            class="btn btn-sm rounded-3 text-decoration-none
                        {{ !request()->is('/admin-hr/leave_management/contract') || request()->is('/admin-hr/leave_management/contract') ? 'btn-primary' : 'btn-light' }}">

                            <i class="mdi mdi-calendar-check-outline me-1"></i>
                            Leave Applications

                            <span
                                class="badge {{ !request()->is('/admin-hr/leave_management/contract') || request()->is('/admin-hr/leave_management/contract') ? 'bg-white text-primary' : 'bg-secondary text-white' }} ms-1">
                                
                            </span>
                        </a>

                        {{-- Leave Entitlement / Table View Link --}}
                        <a href="{{ url('/admin-hr/leave_management/contract/leave_entitle') }}"
                            class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center gap-1
                          {{ request()->is('/admin-hr/leave_management/contract/leave_entitle') ? 'btn-danger' : 'btn-light' }}">

                            <i class="mdi mdi-table me-1"></i>
                            Leave Entitlement

                            <span
                                class="badge {{ request()->is('/admin-hr/leave_management/contract/leave_entitle') ? 'bg-white text-primary' : 'bg-secondary text-white' }} ms-1">
                               
                            </span>
                        </a>
                    </div>

                </div>

                <div class="col-12 col-lg-auto">

                    <div class="d-flex flex-wrap align-items-center gap-2">

                        <button type="button" class="btn btn-outline-secondary btn-sm rounded-3" data-bs-toggle="modal"
                            data-bs-target="#leaveSettingsModal">

                            <i class="mdi mdi-cog-outline me-1"></i>
                            Configure Settings

                        </button>

                        <!-- <span class="small text-muted">

                            <span class="text-success me-1">●</span>

                            Annual Cycle:
                            <strong class="font-monospace text-dark">
                                2026–2027
                            </strong>

                        </span> -->

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{--   LEAVE APPLICATIONS  --}}
    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-3 p-md-4">
            {{-- SECTION HEADER --}}
            <div class="d-flex flex-column flex-md-row
                        justify-content-between
                        align-items-start
                        align-items-md-center
                        gap-3
                        border-bottom pb-3 mb-3">
                <div>

                    <h5 class="mb-1 fw-bold text-dark">

                        <i class="mdi mdi-calendar-text-outline text-primary me-1"></i>

                        Leave Applications & Calendar Logs

                    </h5>

                    <p class="mb-0 text-muted small">
                        Review and manage leave requests for permanent employees.
                    </p>

                </div>



            </div>


            {{--   FILTER AREA     --}}
            <div class="bg-light border rounded-4 p-3 mb-4">
                <form>
                    <div class="row g-2 align-items-end">
                        {{-- SEARCH --}}
                        <div class="col-12 col-md-6 col-lg-3">
                            <label class="form-label small fw-bold text-muted mb-1">
                                Employee
                            </label>

                            <input type="text" name="employee" value="{{ request('employee') }}"
                                class="form-control form-control-sm" placeholder="Search employee...">

                        </div>


                        {{-- LEAVE TYPE --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                Leave Type
                            </label>

                            <select name="leave_type" class="form-select form-select-sm">

                                <option value="ALL">
                                    All Types
                                </option>

                                <option value="Casual">
                                    Casual Leave
                                </option>

                                <option value="Privilege">
                                    Privilege Leave
                                </option>

                                <option value="Sick">
                                    Sick Leave
                                </option>

                            </select>

                        </div>


                        {{-- STATUS --}}
                        <div class="col-12 col-md-6 col-lg-2">
                            <label class="form-label small fw-bold text-muted mb-1">
                                Status
                            </label>
                            <select name="status" class="form-select form-select-sm">
                                <option value="ALL">
                                    All Status
                                </option>
                                <option value="Pending">
                                    Pending
                                </option>
                                <option value="Approved">
                                    Approved
                                </option>
                                <option value="Rejected">
                                    Rejected
                                </option>
                            </select>

                        </div>


                        {{-- FROM DATE --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                From Date
                            </label>

                            <input type="date" name="from_date" value="{{ request('from_date') }}"
                                class="form-control form-control-sm">

                        </div>


                        {{-- TO DATE --}}
                        <div class="col-12 col-md-6 col-lg-2">

                            <label class="form-label small fw-bold text-muted mb-1">
                                To Date
                            </label>

                            <input type="date" name="to_date" value="{{ request('to_date') }}"
                                class="form-control form-control-sm">

                        </div>


                        {{-- FILTER BUTTON --}}
                        <div class="col-12 col-lg-1">

                            <button type="submit" class="btn btn-primary btn-sm w-100">

                                <i class="mdi mdi-filter-outline"></i>

                            </button>

                        </div>

                    </div>

                </form>

            </div>


            {{-- LEAVE TABLE  --}}
            <div class="table-responsive border rounded-4">
                <table id="leave-requests-table" class="table table-hover mb-0">
                    <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                        <tr>
                            <th class="min-w-100px text-black">
                                Employee
                            </th>
                            <th class="min-w-100px text-black">
                                Leave Type
                            </th>
                            <th class="min-w-100px text-black">
                                Leave Date
                            </th>
                            <th class="min-w-100px text-black">
                                Duration
                            </th>
                            <th class="min-w-100px text-black">
                                Leave Mode
                            </th>
                            <th class="min-w-100px text-black">
                                Applied Date
                            </th>
                            <th class="min-w-100px text-black">
                                Reason
                            </th>
                            <th class="min-w-100px text-black">
                                Status / Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


{{-- APPLY LEAVE MODAL --}}
<div class="modal fade" id="applyLeaveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Apply Contract Staff Leave</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="contractLeaveApplyLeaveForm">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Employee</label>
                        <select name="employee_id" class="select3 form-select" required><option value="">Select Employee</option></select>
                    </div>
                    <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3 gap-2">
                        <div><h6 class="fw-bold mb-0">Leave entries</h6><small class="text-muted">Add one entry per date. Half-day entries deduct 0.5 day.</small></div>
                        <button type="button" class="btn btn-outline-primary btn-sm" id="contractLeaveAddLeaveEntryButton"><i class="mdi mdi-plus me-1"></i>Add date</button>
                    </div>
                    <div id="contractLeaveLeaveEntries" class="d-flex flex-column gap-3">
                        <div class="leave-entry-item border rounded-3 p-3" data-leave-entry>
                            <div class="d-flex justify-content-between align-items-center mb-3"><span class="fw-semibold small leave-entry-heading">Leave entry 1</span><button type="button" class="btn btn-sm btn-outline-danger remove-leave-entry d-none" aria-label="Remove leave entry"><i class="mdi mdi-delete-outline"></i></button></div>
                            <div class="row g-3">
                                <div class="col-12 col-md-4"><label class="form-label small fw-semibold">Date</label><input type="date" class="form-control form-control-sm leave-entry-date" required value="{{ now()->toDateString() }}"></div>
                                <div class="col-12 col-md-4"><label class="form-label small fw-semibold">Leave Type</label><select class="form-select form-select-sm leave-entry-type" required><option value="">Select type</option><option value="Casual Leave">Casual Leave</option><option value="Paid Leave">Paid Leave</option><option value="Sick Leave">Sick Leave</option></select></div>
                                <div class="col-12 col-md-4"><label class="form-label small fw-semibold">Leave Mode</label><select class="form-select form-select-sm leave-entry-mode" required><option value="full">Full day</option><option value="first_half">First half</option><option value="second_half">Second half</option></select></div>
                                <div class="col-12"><label class="form-label small fw-semibold">Reason</label><textarea class="form-control form-control-sm leave-entry-reason" rows="2" maxlength="2000" placeholder="Enter reason for this date" required></textarea></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary btn-sm"><i class="mdi mdi-check me-1"></i>Submit Leave</button></div>
            </form>
        </div>
    </div>
</div>

{{-- LEAVE SETTINGS MODAL--}}
<div class="modal fade" id="leaveSettingsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <div class="modal-header">
                <h5 class="modal-title fw-bold">
                    Permanent Staff Leave Policy
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-12 col-sm-4">
                        <label class="form-label small fw-bold">
                            Casual Leave
                        </label>
                        <input type="number" id="leavePolicyCasualDays" name="casual_days" class="form-control form-control-sm" min="0" max="366" step="0.5" value="7">
                        <small class="text-muted">
                            Days / Year
                        </small>
                    </div>
                    <div class="col-12 col-sm-4">
                        <label class="form-label small fw-bold">
                            Privilege Leave
                        </label>
                        <input type="number" id="leavePolicyPaidDays" name="paid_days" class="form-control form-control-sm" min="0" max="366" step="0.5" value="10">

                        <small class="text-muted">
                            Days / Year
                        </small>

                    </div>

                    <div class="col-12 col-sm-4">

                        <label class="form-label small fw-bold">
                            Sick Leave
                        </label>

                        <input type="number" id="leavePolicySickDays" name="sick_days" class="form-control form-control-sm" min="0" max="366" step="0.5" value="7">

                        <small class="text-muted">
                            Days / Year
                        </small>

                    </div>

                </div>

                <hr class="my-3">
                <div class="mb-2"><h6 class="fw-bold mb-1">Carry-forward limits</h6><small class="text-muted">These limits are common to permanent and contract staff.</small></div>
                <div class="row g-3">
                    <div class="col-12 col-sm-4"><label class="form-label small fw-bold" for="leavePolicyCasualCarry">Casual Leave carry forward</label><input type="number" id="leavePolicyCasualCarry" class="form-control form-control-sm" min="0" max="366" step="0.5" value="0"><small class="text-muted">Maximum days carried</small></div>
                    <div class="col-12 col-sm-4"><label class="form-label small fw-bold" for="leavePolicyPaidCarry">Paid Leave carry forward</label><input type="number" id="leavePolicyPaidCarry" class="form-control form-control-sm" min="0" max="366" step="0.5" value="30"><small class="text-muted">Maximum days carried</small></div>
                    <div class="col-12 col-sm-4"><label class="form-label small fw-bold" for="leavePolicySickCarry">Sick Leave carry forward</label><input type="number" id="leavePolicySickCarry" class="form-control form-control-sm" min="0" max="366" step="0.5" value="0"><small class="text-muted">Maximum days carried</small></div>
                </div>

            </div>

            <div class="modal-footer">

                <button type="button" class="btn btn-light btn-sm" data-bs-dismiss="modal">
                    Cancel
                </button>

                <button type="button" id="saveLeavePolicyButton" class="btn btn-primary btn-sm">
                    Save Settings
                </button>

            </div>

        </div>

    </div>

</div>


<style>
/* LEAVE MANAGEMENT */

.leave-kpi-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    font-size: 20px;
}

.leave-kpi-label {
    font-size: 9px;
    letter-spacing: .5px;
    line-height: 1.4;
}

.leave-kpi-value {
    font-size: 18px;
    line-height: 1.3;
    margin-top: 2px;
}

.leave-kpi-description {
    font-size: 9px;
    margin-top: 2px;
}

.leave-reason {
    max-width: 180px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}


/* RESPONSIVE */
@media (max-width: 767.98px) {
    .leave-kpi-value {
        font-size: 16px;
    }

    .leave-kpi-description {
        font-size: 8px;
    }

    .table {
        min-width: 900px;
    }
}
</style>

<script>
const contractLeaveType = 'contract';
const contractLeaveBase = `/admin-hr/api/leave/${contractLeaveType}`;
const contractLeaveCsrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
const contractLeaveState = {
    page: 1,
    perPage: 10,
    search: '',
    leaveType: 'ALL',
    status: 'ALL',
    fromDate: '',
    toDate: '',
    staff: []
};

function contractLeaveEscape(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[character]);
}

async function contractLeaveRequest(url, options = {}) {
    const headers = {
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        ...(contractLeaveCsrf ? { 'X-CSRF-TOKEN': contractLeaveCsrf } : {}),
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
        ...(options.headers || {})
    };

    const response = await fetch(url, {
        credentials: 'same-origin',
        ...options,
        headers
    });

    let payload = {};

    try {
        payload = await response.json();
    } catch (error) {
        // Leave the payload empty when the response has no valid JSON body.
    }

    if (!response.ok || payload.success === false) {
        throw new Error(
            payload.message ||
            Object.values(payload.errors || {}).flat()[0] ||
            `Request failed (${response.status}).`
        );
    }

    return payload;
}

function contractLeaveBuildParams() {
    const params = new URLSearchParams({
        page: String(contractLeaveState.page),
        per_page: String(contractLeaveState.perPage),
        employee: contractLeaveState.search,
        leave_type: contractLeaveState.leaveType,
        status: contractLeaveState.status
    });

    if (contractLeaveState.fromDate) {
        params.set('from_date', contractLeaveState.fromDate);
    }

    if (contractLeaveState.toDate) {
        params.set('to_date', contractLeaveState.toDate);
    }

    return params.toString();
}

function contractLeaveUpdateSummary(summary) {
    const cards = [...document.querySelectorAll('.leave-kpi-item')];
    const values = [
        `${Number(summary.staff_count || 0)} Staff`,
        `${Number(summary.on_leave_today || 0)} Personnel`,
        `${Number(summary.pending_count || 0)} Pending`,
        `${Number(summary.approved_this_month || 0)} Approved`
    ];

    cards.forEach((card, index) => {
        const value = card.querySelector('.leave-kpi-value');

        if (value && values[index] !== undefined) {
            value.textContent = values[index];
        }
    });

    const descriptions = cards.map(card => card.querySelector('.leave-kpi-description'));

    if (descriptions[1]) {
        descriptions[1].textContent = 'Approved leave including today';
    }

    if (descriptions[2]) {
        descriptions[2].textContent = 'Awaiting HR review';
    }

    if (descriptions[3]) {
        descriptions[3].textContent = new Date().toLocaleDateString(undefined, {
            month: 'long',
            year: 'numeric'
        });
    }
}

function contractLeaveStatusBadge(status) {
    const color = status === 'Approved'
        ? 'success'
        : status === 'Rejected'
            ? 'danger'
            : 'warning';

    return `<span class="badge bg-${color}-subtle text-${color}">${contractLeaveEscape(status)}</span>`;
}

function contractLeaveRenderRows(rows) {
    const table = document.getElementById('leave-requests-table');

    if (!table) {
        return;
    }

    const body = table.tBodies[0];

    if (!rows.length) {
        body.innerHTML = `
            <tr>
                <td colspan="8" class="text-center text-muted py-5">
                    No leave requests found for the selected filters.
                </td>
            </tr>
        `;
        return;
    }

    body.innerHTML = rows.map(row => `
        <tr data-leave-id="${contractLeaveEscape(row.id)}">
            <td>
                <div class="fw-bold text-dark small">${contractLeaveEscape(row.staff_name || '—')}</div>
                <div class="text-muted" style="font-size:10px">
                    ${contractLeaveEscape(row.designation || 'Staff')}
                    <span class="mx-1">•</span>
                    ${contractLeaveEscape(row.department_name || 'General')}
                </div>
                <small class="text-muted">${contractLeaveEscape(row.staff_code || '')}</small>
            </td>
            <td>
                <span class="badge rounded-2 bg-primary-subtle text-primary">
                    ${contractLeaveEscape(row.leave_type)}
                </span>
            </td>
            <td>
                <span class="small fw-semibold">
                    ${contractLeaveEscape(row.from_date)}
                    <span class="text-muted">to</span>
                    ${contractLeaveEscape(row.to_date)}
                </span>
            </td>
            <td>
                <span class="badge bg-light text-dark">
                    ${contractLeaveEscape(row.days ?? '—')}
                    ${Number(row.days) === 1 ? 'Day' : 'Days'}
                </span>
            </td>
            <td>
                <span class="badge bg-info-subtle text-info">
                    ${({'full': 'Full day', 'first_half': 'First half', 'second_half': 'Second half'})[String(row.leave_mode || 'full')] || 'Full day'}
                </span>
            </td>
            <td>
                <small class="text-muted">
                    ${contractLeaveEscape(String(row.created_at || '').slice(0, 10) || '—')}
                </small>
            </td>
            <td>
                <span class="small text-muted" title="${contractLeaveEscape(row.reason || '')}">
                    ${contractLeaveEscape(row.reason || '—')}
                </span>
            </td>
            <td>
                ${contractLeaveStatusBadge(row.approval_status)}
                ${row.approval_status === 'Pending' ? `
                    <div class="d-flex gap-1 mt-2">
                        <button type="button" class="btn btn-success btn-sm leave-review"
                            data-id="${contractLeaveEscape(row.id)}" data-status="Approved">Approve</button>
                        <button type="button" class="btn btn-outline-danger btn-sm leave-review"
                            data-id="${contractLeaveEscape(row.id)}" data-status="Rejected">Reject</button>
                    </div>
                ` : ''}
            </td>
        </tr>
    `).join('');
}

function contractLeaveRenderPager(meta = {}) {
    const table = document.getElementById('leave-requests-table');
    if (!table) return;

    let host = document.getElementById('leave-requests-pagination');
    if (!host) {
        host = document.createElement('div');
        host.id = 'leave-requests-pagination';
        host.className = 'd-flex flex-wrap align-items-center justify-content-between gap-2 p-3';
        table.closest('.card')?.appendChild(host);
    }
    if (!host) return;

    const currentPage = Number(meta.current_page || 1);
    const lastPage = Math.max(1, Number(meta.last_page || 1));
    const total = Number(meta.total || 0);
    const perPage = Number(meta.per_page || contractLeaveState.perPage);
    const start = total === 0 ? 0 : ((currentPage - 1) * perPage) + 1;
    const end = Math.min(currentPage * perPage, total);
    const firstPage = Math.max(1, currentPage - 2);
    const finalPage = Math.min(lastPage, currentPage + 2);
    const pageButtons = Array.from({ length: finalPage - firstPage + 1 }, (_, index) => {
        const page = firstPage + index;
        return `<li class="page-item ${page === currentPage ? 'active' : ''}"><button type="button" class="page-link" data-leave-page="${page}" ${page === currentPage ? 'aria-current="page"' : ''}>${page}</button></li>`;
    }).join('');

    host.innerHTML = `
        <div class="small text-muted">Showing ${start} to ${end} of ${total} results</div>
        <div class="d-flex flex-wrap align-items-center gap-2">
            <label for="leaveRequestsPageSize" class="small text-muted mb-0">Rows</label>
            <select id="leaveRequestsPageSize" class="form-select form-select-sm" style="width:82px">
                <option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option>
            </select>
            <nav aria-label="Contract leave requests table pagination"><ul class="pagination pagination-sm mb-0">
                <li class="page-item ${currentPage === 1 ? 'disabled' : ''}"><button type="button" class="page-link" data-leave-page="1" aria-label="First page" ${currentPage === 1 ? 'disabled' : ''}>«</button></li>
                <li class="page-item ${currentPage === 1 ? 'disabled' : ''}"><button type="button" class="page-link" data-leave-page="${Math.max(1, currentPage - 1)}" aria-label="Previous page" ${currentPage === 1 ? 'disabled' : ''}>‹</button></li>
                ${pageButtons}
                <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}"><button type="button" class="page-link" data-leave-page="${Math.min(lastPage, currentPage + 1)}" aria-label="Next page" ${currentPage === lastPage ? 'disabled' : ''}>›</button></li>
                <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}"><button type="button" class="page-link" data-leave-page="${lastPage}" aria-label="Last page" ${currentPage === lastPage ? 'disabled' : ''}>»</button></li>
            </ul></nav>
        </div>`;

    host.querySelector('#leaveRequestsPageSize').value = String(perPage);
    host.querySelector('#leaveRequestsPageSize').addEventListener('change', event => {
        contractLeaveState.perPage = Number(event.currentTarget.value);
        contractLeaveState.page = 1;
        contractLeaveLoadRequests();
    });
    host.querySelectorAll('[data-leave-page]').forEach(button => button.addEventListener('click', () => {
        if (button.disabled) return;
        contractLeaveState.page = Number(button.dataset.leavePage);
        contractLeaveLoadRequests();
    }));
}

async function contractLeaveLoadRequests() {
    const table = document.getElementById('leave-requests-table');

    if (!table) {
        return;
    }

    const body = table.tBodies[0];
    body.innerHTML = Array.from({ length: 5 }, () => `
        <tr class="skeleton-loader">
            ${Array.from({ length: 8 }, () => `
                <td class="skeleton-cell"><div class="skeleton-loader-view"></div></td>
            `).join('')}
        </tr>
    `).join('');

    try {
        const payload = await contractLeaveRequest(`${contractLeaveBase}?${contractLeaveBuildParams()}`);

        contractLeaveRenderRows(payload.data || []);
        contractLeaveRenderPager(payload.meta || {});
        contractLeaveUpdateSummary(payload.summary || {});

        const countBadge = document.querySelector(`a[href*="leave_management/${contractLeaveType}"] .badge`);

        if (countBadge) {
            countBadge.textContent = Number(payload.summary?.pending_count || 0);
        }
    } catch (error) {
        body.innerHTML = `
            <tr>
                <td colspan="8" class="text-danger text-center py-4">
                    ${contractLeaveEscape(error.message)}
                </td>
            </tr>
        `;

        document.querySelectorAll('.leave-kpi-value').forEach(value => {
            value.textContent = '—';
        });
    }
}

async function contractLeaveLoadStaffOptions() {
    const selects = [...document.querySelectorAll(
        '#applyLeaveModal select[name="employee_id"], #applyLeaveModal select[name="staff_id"]'
    )];

    if (!selects.length) {
        return;
    }

    try {
        const allStaff = [];
        let page = 1;
        let lastPage = 1;

        do {
            const payload = await contractLeaveRequest(
                `/admin-hr/api/staff/${contractLeaveType}?per_page=100&sort=name&direction=asc&page=${page}`
            );

            allStaff.push(...(payload.data || []));
            lastPage = Number(payload.meta?.last_page || 1);
            page += 1;
        } while (page <= lastPage && page <= 100);

        contractLeaveState.staff = allStaff;

        const options = allStaff.map(staff => `
            <option value="${contractLeaveEscape(staff.id)}">
                ${contractLeaveEscape(staff.name)} · ${contractLeaveEscape(staff.staff_id || '')}
            </option>
        `).join('');

        selects.forEach(select => {
            const previousValue = select.value;
            select.innerHTML = `<option value="">Select Employee</option>${options}`;
            select.value = previousValue;
        });
    } catch (error) {
        console.warn('Could not load staff selector:', error.message);
    }
}

async function contractLeaveReviewRequest(button) {
    const id = button.dataset.id;
    const status = button.dataset.status;

    if (!id || !status) {
        return;
    }

    if (status === 'Approved' && !confirm('Approve this leave request and mark working days as Leave in Attendance?')) {
        return;
    }

    if (status === 'Rejected' && !confirm('Reject this leave request?')) {
        return;
    }

    button.disabled = true;

    try {
        await contractLeaveRequest(`${contractLeaveBase}/${id}/review`, {
            method: 'PATCH',
            body: JSON.stringify({ approval_status: status })
        });

        await contractLeaveLoadRequests();
    } catch (error) {
        alert(error.message);
    } finally {
        button.disabled = false;
    }
}

async function contractLeaveLoadPolicy() {
    const modal = document.getElementById('leaveSettingsModal');

    if (!modal) {
        return;
    }

    try {
        const payload = await contractLeaveRequest(`${contractLeaveBase}/policies`);
        const policies = payload.data || [];
        const findPolicy = leaveType => policies.find(policy =>
            String(policy.leave_type).toLowerCase().replace(/[^a-z]/g, '') === leaveType
        );
        const casualLeave = findPolicy('casualleave');
        const paidLeave = findPolicy('paidleave') || findPolicy('privilegeleave');
        const sickLeave = findPolicy('sickleave');

        function contractLeaveSetPolicyInput(id, value) {
            const input = document.getElementById(id);

            if (input && value !== undefined) {
                input.value = value;
            }
        }

        contractLeaveSetPolicyInput('leavePolicyCasualDays', casualLeave?.annual_days ?? 7);
        contractLeaveSetPolicyInput('leavePolicyPaidDays', paidLeave?.annual_days ?? 10);
        contractLeaveSetPolicyInput('leavePolicySickDays', sickLeave?.annual_days ?? 7);
        contractLeaveSetPolicyInput('leavePolicyCasualCarry', casualLeave?.max_carry_forward_days ?? 0);
        contractLeaveSetPolicyInput('leavePolicyPaidCarry', paidLeave?.max_carry_forward_days ?? 30);
        contractLeaveSetPolicyInput('leavePolicySickCarry', sickLeave?.max_carry_forward_days ?? 0);
    } catch (error) {
        console.warn('Could not load leave policies:', error.message);
    }
}

async function contractLeaveSavePolicy(button) {
    const readPolicyInput = id => Number(document.getElementById(id)?.value || 0);
    const policies = [
        { leave_type: 'Casual Leave', annual_days: readPolicyInput('leavePolicyCasualDays'), carry_forward_enabled: readPolicyInput('leavePolicyCasualCarry') > 0 ? 1 : 0, max_carry_forward_days: readPolicyInput('leavePolicyCasualCarry'), accrual_method: 'annual' },
        { leave_type: 'Paid Leave', annual_days: readPolicyInput('leavePolicyPaidDays'), carry_forward_enabled: readPolicyInput('leavePolicyPaidCarry') > 0 ? 1 : 0, max_carry_forward_days: readPolicyInput('leavePolicyPaidCarry'), accrual_method: 'annual' },
        { leave_type: 'Sick Leave', annual_days: readPolicyInput('leavePolicySickDays'), carry_forward_enabled: readPolicyInput('leavePolicySickCarry') > 0 ? 1 : 0, max_carry_forward_days: readPolicyInput('leavePolicySickCarry'), accrual_method: 'annual' }
    ];
    if (policies.some(policy => !Number.isFinite(policy.annual_days) || policy.annual_days < 0 || policy.annual_days > 366 || policy.max_carry_forward_days < 0 || policy.max_carry_forward_days > 366)) {
        alert('Enter leave allocation and carry-forward values between 0 and 366 days.');
        return;
    }

    button.disabled = true;

    try {
        const payload = await contractLeaveRequest(`${contractLeaveBase}/policies`, {
            method: 'PUT',
            body: JSON.stringify({ policies })
        });

        alert(payload.message || 'Leave policy saved.');
        bootstrap.Modal.getInstance(document.getElementById('leaveSettingsModal'))?.hide();
    } catch (error) {
        alert(error.message);
    } finally {
        button.disabled = false;
    }
}

function contractLeaveBindFilters() {
    const form = document.querySelector(
        `form[action*="leave_management/${contractLeaveType}"][method="GET"]`
    ) || document.querySelector('.card form[method="GET"]');

    if (!form) {
        return;
    }

    const employeeInput = form.querySelector('[name="employee"]');
    const leaveTypeSelect = form.querySelector('[name="leave_type"]');
    const statusSelect = form.querySelector('[name="status"]');
    const fromDateInput = form.querySelector('[name="from_date"]');
    const toDateInput = form.querySelector('[name="to_date"]');

    if (employeeInput) {
        contractLeaveState.search = employeeInput.value || '';
        let searchTimer;

        employeeInput.addEventListener('input', function contractLeaveSearchInput() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(function contractLeaveApplySearch() {
                contractLeaveState.search = employeeInput.value.trim();
                contractLeaveState.page = 1;
                contractLeaveLoadRequests();
            }, 250);
        });
    }

    if (leaveTypeSelect) {
        contractLeaveState.leaveType = leaveTypeSelect.value || 'ALL';
        leaveTypeSelect.addEventListener('change', function contractLeaveChangeLeaveType() {
            contractLeaveState.leaveType = leaveTypeSelect.value || 'ALL';
            contractLeaveState.page = 1;
            contractLeaveLoadRequests();
        });
    }

    if (statusSelect) {
        contractLeaveState.status = statusSelect.value || 'ALL';
        statusSelect.addEventListener('change', function contractLeaveChangeStatus() {
            contractLeaveState.status = statusSelect.value || 'ALL';
            contractLeaveState.page = 1;
            contractLeaveLoadRequests();
        });
    }

    if (fromDateInput) {
        contractLeaveState.fromDate = fromDateInput.value || '';
        fromDateInput.addEventListener('change', function contractLeaveChangeFromDate() {
            contractLeaveState.fromDate = fromDateInput.value;
            contractLeaveState.page = 1;
            contractLeaveLoadRequests();
        });
    }

    if (toDateInput) {
        contractLeaveState.toDate = toDateInput.value || '';
        toDateInput.addEventListener('change', function contractLeaveChangeToDate() {
            contractLeaveState.toDate = toDateInput.value;
            contractLeaveState.page = 1;
            contractLeaveLoadRequests();
        });
    }

    form.addEventListener('submit', function contractLeaveSubmitFilters(event) {
        event.preventDefault();
        event.stopImmediatePropagation();
        contractLeaveState.search = employeeInput?.value?.trim() || '';
        contractLeaveState.leaveType = leaveTypeSelect?.value || 'ALL';
        contractLeaveState.status = statusSelect?.value || 'ALL';
        contractLeaveState.fromDate = fromDateInput?.value || '';
        contractLeaveState.toDate = toDateInput?.value || '';
        contractLeaveState.page = 1;
        contractLeaveLoadRequests();
    });
}

function contractLeaveHandleDocumentClick(event) {
    const reviewButton = event.target.closest('.leave-review');

    if (reviewButton) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        contractLeaveReviewRequest(reviewButton);
        return;
    }

    const saveButton = event.target.closest('#saveLeavePolicyButton');

    if (saveButton) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        contractLeaveSavePolicy(saveButton);
    }
}

document.addEventListener('click', contractLeaveHandleDocumentClick, true);

function contractLeaveHandleDocumentSubmit(event) {
    const form = event.target;
    if (!form?.matches('#contractLeaveApplyLeaveForm')) return;
    event.preventDefault(); event.stopPropagation(); event.stopImmediatePropagation();
    const staffId = Number(new FormData(form).get('employee_id'));
    const items = [...form.querySelectorAll('[data-leave-entry]')].map(entry => ({
        date: entry.querySelector('.leave-entry-date')?.value || '',
        leave_type: entry.querySelector('.leave-entry-type')?.value || '',
        leave_mode: entry.querySelector('.leave-entry-mode')?.value || 'full',
        reason: entry.querySelector('.leave-entry-reason')?.value?.trim() || ''
    }));
    const submitButton = form.querySelector('[type="submit"]');
    if (!staffId || items.some(item => !item.date || !item.leave_type || !item.leave_mode || !item.reason)) {
        alert('Choose an employee and complete the date, leave type, leave mode and reason for every entry.'); return;
    }
    const seen = new Set();
    for (const item of items) {
        const key = item.date;
        if (seen.has(key)) { alert(`Only one leave entry can be submitted for ${item.date}.`); return; }
        seen.add(key);
    }
    if (submitButton) submitButton.disabled = true;
    contractLeaveRequest(contractLeaveBase, { method: 'POST', body: JSON.stringify({ staff_id: staffId, items }) })
        .then(response => {
            alert(response.message || 'Leave request submitted.');
            bootstrap.Modal.getInstance(form.closest('.modal'))?.hide();
            form.reset();
            const entries = form.querySelector('#contractLeaveLeaveEntries');
            [...entries.querySelectorAll('[data-leave-entry]')].slice(1).forEach(entry => entry.remove());
            const first = entries.querySelector('[data-leave-entry]');
            if (first) {
                const today = new Date();
                first.querySelector('.leave-entry-date').value = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
                first.querySelector('.leave-entry-mode').value = 'full';
                first.querySelector('.remove-leave-entry')?.classList.add('d-none');
                first.querySelector('.leave-entry-heading').textContent = 'Leave entry 1';
            }
            contractLeaveState.page = 1;
            contractLeaveLoadRequests();
        })
        .catch(error => alert(error.message))
        .finally(() => { if (submitButton) submitButton.disabled = false; });
}
document.addEventListener('submit', contractLeaveHandleDocumentSubmit, true);

function contractLeaveBindLeaveEntryControls() {
    const container = document.getElementById('contractLeaveLeaveEntries');
    const addButton = document.getElementById('contractLeaveAddLeaveEntryButton');
    if (!container || !addButton || addButton.dataset.bound === '1') return;
    addButton.dataset.bound = '1';
    addButton.addEventListener('click', () => {
        const first = container.querySelector('[data-leave-entry]');
        if (!first) return;
        const entry = first.cloneNode(true);
        entry.querySelectorAll('input, select, textarea').forEach(input => {
            if (input.classList.contains('leave-entry-date')) input.value = '';
            else if (input.classList.contains('leave-entry-type')) input.value = '';
            else if (input.classList.contains('leave-entry-mode')) input.value = 'full';
            else input.value = '';
        });
        entry.querySelector('.remove-leave-entry')?.classList.remove('d-none');
        container.appendChild(entry);
        contractLeaveRefreshLeaveEntryLabels();
    });
    container.addEventListener('click', event => {
        const remove = event.target.closest('.remove-leave-entry');
        if (!remove || container.querySelectorAll('[data-leave-entry]').length <= 1) return;
        remove.closest('[data-leave-entry]')?.remove();
        contractLeaveRefreshLeaveEntryLabels();
    });
}
function contractLeaveRefreshLeaveEntryLabels() {
    const entries = [...document.querySelectorAll('#contractLeaveLeaveEntries [data-leave-entry]')];
    entries.forEach((entry, index) => {
        const heading = entry.querySelector('.leave-entry-heading');
        if (heading) heading.textContent = `Leave entry ${index + 1}`;
        entry.querySelector('.remove-leave-entry')?.classList.toggle('d-none', entries.length === 1);
    });
}
function contractLeaveInit() {
    contractLeaveBindLeaveEntryControls();
    contractLeaveBindFilters();
    contractLeaveLoadStaffOptions();
    contractLeaveLoadPolicy();
    contractLeaveLoadRequests();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', contractLeaveInit, { once: true });
} else {
    contractLeaveInit();
}
</script>

@endsection