# HR Leave & Attendance Enhancements — Deployment Notes

## Contents
- `hr_leave_attendance_production_patch.zip`: only the updated and newly added application files, with their original Laravel-relative paths, plus the SQL migration and this note.
- `updated_mvc_leave_attendance_enhancements.zip`: the complete `app/`, `resources/`, and `routes/` source trees available in the uploaded ZIP, updated with the changes, plus the SQL migration and this note.
- `hr_leave_attendance_enhancements.sql`: additive, rerunnable MariaDB migration for the two new `leave_mode` columns.

## Before deployment
1. Back up the production database and the existing files listed in the patch.
2. Deploy to staging first. The submitted source archive contained only `app/`, `resources/`, and `routes/`, not a complete Laravel root (`artisan`, `composer.json`, or `vendor/` were not included). Therefore these are overlay files for the existing full application, not a standalone Laravel install.
3. Open `hr_leave_attendance_enhancements.sql`. It selects database `ryans_infra`; change the `USE` statement to the production schema name if it differs. Run the migration only after selecting the intended database.
4. Extract the patch over the full application root, preserving the relative paths. Review your deployment diff before replacing files.
5. From the full Laravel project root, run `php artisan optimize:clear` (and your normal deployment/route-cache process, if used). This command could not be run here because the uploaded archive did not contain `artisan` or the Laravel runtime dependencies.

## Smoke test checklist
- In both permanent and contract Leave Management pages, change CL, Paid and Sick annual limits and their carry-forward caps. Confirm the annual limits remain category-specific while the three carry-forward caps are shared across permanent and contract policies.
- Apply leave with one entry, then several entries on different dates; try Full day, First half and Second half. Verify duplicate dates are rejected and half-day requests deduct 0.5 day after approval.
- Approve/reject requests and confirm leave mode appears in the leave list and is reflected in attendance.
- In both attendance list views, use Leave mode and Permission/On Duty actions. Verify Leave mode is shown and that Permission/On Duty requires a start time, end time, and reason.
- In the monthly attendance matrix, select Leave, Permission or On Duty and confirm the values persist after reloading the month.
- In both staff Add forms, verify the Workplace Leave Balance Configuration fields load from Configure Settings and the joining-date cycle preview updates when Date of Joining changes.
- Edit a staff profile, use Change photo, save, close/reopen the profile, and verify the new photo is loaded.

## Scope / validation
The SQL adds only `ryans_leave_requests.leave_mode` and `ryans_staff_attendance.leave_mode` when missing; existing rows default to Full day for leave requests. The application files were checked with PHP syntax linting, and the embedded JavaScript blocks in the eight modified Blade views were extracted and checked with Node syntax validation. The live Laravel routes, rendered Blade templates, database migration execution, and end-to-end behavior were not run because a complete application root and database connection were not supplied.

## Data safety
Do not import the uploaded full SQL dump to deploy these changes; use only the additive migration. The supplied dump contains personal access-token/login data, so keep it private and rotate tokens if it was shared outside trusted access.
