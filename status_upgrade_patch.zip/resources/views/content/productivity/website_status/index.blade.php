@extends('layouts/layoutMaster')

@section('title', 'Website Status')

@section('vendor-style')
    @vite([
        'resources/assets/vendor/libs/select2/select2.scss',
    ])
@endsection

@section('vendor-script')
    @vite([
        'resources/assets/vendor/libs/select2/select2.js',
    ])
@endsection

@section('content')
<style>
    #websiteStatusApp .wsm-card { 
        border:1px solid #e7eaf0; 
        border-radius:12px; 
        overflow:hidden; 
    }
    #websiteStatusApp .wsm-heading { 
        color:#202938; 
        font-weight:700; 
    }
    #websiteStatusApp .wsm-accent { 
        color:#b12a1f; 
    }
    #websiteStatusApp .wsm-btn-primary { 
        background:#b12a1f; 
        border-color:#b12a1f; 
        color:#fff; 
    }
    #websiteStatusApp .wsm-btn-primary:hover { 
        background:#972219; 
        border-color:#972219; 
        color:#fff; 
    }
    #websiteStatusApp .wsm-summary { 
        display:flex; 
        gap:10px; 
        flex-wrap:wrap; 
        /* padding:14px 18px 4px;  */
    }
    #websiteStatusApp .wsm-summary-item { 
        min-width:135px; 
        border:1px solid #e9edf3; 
        border-radius:9px; 
        padding:10px 13px; 
        background:#fff; 
    }
    #websiteStatusApp .wsm-summary-label { 
        color:#7d8796; 
        font-size:11px; 
        font-weight:600; 
    }
    #websiteStatusApp .wsm-summary-value { 
        color:#202938; 
        font-size:22px; 
        line-height:1.3; 
        font-weight:800; 
    }

    #websiteStatusApp .wsm-http-card {
        min-width:140px;
        flex:1 1 145px;
        border:1px solid #e9edf3;
        border-radius:10px;
        padding:10px 13px;
        background:#fff;
        position:relative;
        overflow:hidden;
    }
    #websiteStatusApp .wsm-http-card::before {
        content:'';
        position:absolute;
        inset:0 auto 0 0;
        width:3px;
        background:var(--wsm-tone, #64748b);
    }
    #websiteStatusApp .wsm-http-card .wsm-summary-label { font-size:10px; letter-spacing:.045em; }
    #websiteStatusApp .wsm-http-card .wsm-summary-value { font-size:21px; }
    #websiteStatusApp .wsm-http-card.wsm-2xx { --wsm-tone:#16a36a; }
    #websiteStatusApp .wsm-http-card.wsm-3xx { --wsm-tone:#d99b21; }
    #websiteStatusApp .wsm-http-card.wsm-4xx { --wsm-tone:#d45a4d; }
    #websiteStatusApp .wsm-http-card.wsm-5xx { --wsm-tone:#962f45; }
    #websiteStatusApp .wsm-history-dialog { max-width:1240px; }
    #websiteStatusApp .wsm-history-modal .modal-content { border:0; border-radius:16px; overflow:hidden; box-shadow:0 24px 70px rgba(20,32,50,.22); }
    #websiteStatusApp .wsm-history-modal .modal-header { color:#fff; background:linear-gradient(115deg,#202b3d,#34445f); padding:18px 22px; }
    #websiteStatusApp .wsm-history-modal .modal-header .btn-close { filter:invert(1); opacity:.8; }
    #websiteStatusApp .wsm-history-modal .modal-body { background:#f5f7fb; padding:20px; }
    #websiteStatusApp .wsm-history-kpi { height:100%; background:#fff; border:1px solid #e7ebf2; border-radius:11px; padding:12px 14px; }
    #websiteStatusApp .wsm-history-kpi-label { color:#8490a1; font-size:10px; font-weight:800; letter-spacing:.06em; text-transform:uppercase; }
    #websiteStatusApp .wsm-history-kpi-value { color:#202b3d; font-size:21px; font-weight:800; line-height:1.35; }
    #websiteStatusApp .wsm-history-chart-card { background:#fff; border:1px solid #e7ebf2; border-radius:12px; padding:14px; min-height:275px; }
    #websiteStatusApp .wsm-history-chart-title { font-size:12px; color:#334155; font-weight:800; margin-bottom:12px; }
    #websiteStatusApp .wsm-history-chart-wrap { position:relative; height:220px; }
    #websiteStatusApp .wsm-history-chart-wrap.wsm-chart-small { height:180px; }
    #websiteStatusApp .wsm-history-table-wrap { background:#fff; border:1px solid #e7ebf2; border-radius:12px; overflow:hidden; }
    #websiteStatusApp .wsm-history-table { margin:0; min-width:760px; }
    #websiteStatusApp .wsm-history-table thead th { background:#f0f3f8; color:#596579; font-size:10px; text-transform:uppercase; letter-spacing:.04em; border:0; white-space:nowrap; }
    #websiteStatusApp .wsm-history-table tbody td { font-size:11px; vertical-align:middle; border-color:#edf0f4; }
    #websiteStatusApp .wsm-history-transition { font-weight:800; white-space:nowrap; }
    #websiteStatusApp .wsm-history-error { max-width:300px; color:#bd3b40; white-space:normal; }
    #websiteStatusApp .wsm-history-pagination { display:flex; justify-content:space-between; align-items:center; gap:10px; padding:12px 14px; }
    #websiteStatusApp .wsm-history-empty { padding:28px 12px; text-align:center; color:#7c8798; font-size:12px; }
    #websiteStatusApp .wsm-history-loading { padding:30px; text-align:center; color:#7c8798; }
  
 
   
    #websiteStatusApp .wsm-table-wrap { 
        overflow-x:auto; 
    }
    #websiteStatusApp .wsm-table { 
        min-width:1080px; 
        margin-bottom:0; 
    }
    #websiteStatusApp .wsm-table thead th { 
        background:#b12a1f; 
        color:#fff; 
        font-weight:700; 
        font-size:11px; 
        white-space:nowrap; 
        padding:10px 8px; 
        border-bottom:0; 
    }
    #websiteStatusApp .wsm-table tbody td { 
        padding:9px 8px; 
        vertical-align:middle; 
        border-color:#edf0f4; 
        font-size:12px; 
    }
    #websiteStatusApp .wsm-website-name { 
        color:#263449; 
        font-size:12px; 
        font-weight:700; 
    }
    #websiteStatusApp .wsm-url { 
        display:inline-block; 
        max-width:230px; 
        overflow:hidden; 
        text-overflow:ellipsis; 
        white-space:nowrap; 
        color:#4266a5; 
        text-decoration:none; 
        vertical-align:middle; 
    }
    #websiteStatusApp .wsm-url:hover { 
        color:#b12a1f; 
        text-decoration:underline; 
    }
    #websiteStatusApp .wsm-muted { 
        color:#8792a2; 
        font-size:10px; 
    }
    #websiteStatusApp .wsm-code { 
        display:inline-block; 
        min-width:64px; 
        border-radius:5px; 
        background:#f2f4f7; 
        color:#526071; 
        padding:4px 6px; 
        text-align:center; 
        font-size:11px; 
        font-weight:700; 
    }
    #websiteStatusApp .wsm-actions { 
        display:flex; 
        align-items:center; 
        gap:5px; 
        white-space:nowrap; 
    }
    #websiteStatusApp .wsm-action-btn { 
        border:1px solid #e5e9ef; 
        background:#fff; 
        color:#596678; 
        border-radius:6px; 
        padding:4px 7px; 
        font-size:11px; 
    }
    #websiteStatusApp .wsm-action-btn:hover { 
        border-color:#b12a1f; 
        color:#b12a1f; 
    }
    #websiteStatusApp .wsm-action-btn:disabled { 
        opacity:.55; 
        cursor:not-allowed; 
    }
    #websiteStatusApp .wsm-pagination { 
        display:flex; 
        justify-content:space-between; 
        align-items:center; 
        gap:12px; 
        flex-wrap:wrap; 
        padding:13px 18px; 
    }
    #websiteStatusApp .wsm-pagination .pagination { 
        margin:0; 
    }
    #websiteStatusApp .wsm-pagination .page-link { 
        cursor:pointer; 
    }
    #websiteStatusApp .wsm-empty { 
        padding:38px 15px; 
        text-align:center; 
        color:#7c8798; 
    }
    #websiteStatusApp .wsm-empty i { 
        display:block; 
        font-size:32px; 
        margin-bottom:7px; 
        color:#b6bfcc; 
    }
    #websiteStatusApp .wsm-skeleton { 
        height:30px; 
        width:100%; 
        border-radius:4px; 
        background:linear-gradient(90deg,#e5e7eb 25%,#f3f4f6 50%,#e5e7eb 75%); 
        background-size:200% 100%; 
        animation:wsm-loading 1.2s infinite; 
    }

    #websiteStatusApp .wsm-skeleton-cell { 
        min-width:90px;
    }
    #websiteStatusApp .wsm-form-section { 
        border:1px solid #edf0f4; 
        border-radius:9px; 
        padding:14px; 
        margin-bottom:12px; 
    }
    #websiteStatusApp .wsm-form-section-title { 
        font-size:12px; 
        font-weight:800; 
        color:#121923; 
        margin-bottom:12px; 
    }
    #websiteStatusApp .form-label { 
        color:#40434a; 
        font-size:11px; 
        font-weight:700; 
    }
    #websiteStatusApp .form-control, #websiteStatusApp .form-select { 
        font-size:12px; 
        min-height:37px; 
    }
    /* #websiteStatusApp .select2-container--default .select2-selection--single { 
        min-height:37px; 
        border-color:#dfe4eb; 
        border-radius:7px; 
    }
    #websiteStatusApp .select2-container--default .select2-selection--single .select2-selection__rendered { 
        line-height:35px; 
        font-size:12px; 
        color:#455166; 
    } */

    /* #websiteStatusApp .select2-container--default .select2-selection--single .select2-selection__arrow { 
        height:35px;
    }
    #websiteStatusApp .select2-dropdown { 
        z-index:1200;
    } */
    #websiteStatusApp .wsm-poll-indicator { 
        font-size:10px; 
        color:#8792a2; 
        white-space:nowrap;
    }
    #websiteStatusApp .wsm-pulse { 
        display:inline-block; 
        width:7px; 
        height:7px; 
        border-radius:50%; 
        background:#37b36b; 
        margin-right:5px; 
        box-shadow:0 0 0 3px rgba(55,179,107,.12); 
    }
    #websiteStatusApp .wsm-favicon { 
        width:42px; 
        height:42px; 
        min-width:42px; 
        border-radius:8px; 
        background:#e2e2e3; 
        display:inline-flex; 
        align-items:center; 
        justify-content:center; 
        overflow:hidden; 
        border:1px solid #edf0f4; 
    }
    #websiteStatusApp .wsm-favicon img { 
        width:32px; 
        height:32px; 
        object-fit:contain; 
        display:block; 
    }
    #websiteStatusApp .wsm-favicon i { 
        font-size:17px; 
        color:#a4adba; 
    }
    @keyframes wsm-loading { 
        0% { 
            background-position:-200% 0;
        } 
        100% { 
            background-position:200% 0;
        } 
    }
    @media(max-width:767px) {
        #websiteStatusApp .wsm-summary-item { 
            flex:1 1 calc(50% - 10px); 
            min-width:120px; 
        }
       
      
        
    }
</style>

@php
    $perpage =25;
@endphp

<div id="websiteStatusApp" class="" >

    <div class="card card-action">
        <div class="card-header d-flex justify-content-between border-bottom pb-0 mb-0 ip-monitor-header">
            <div class="d-flex flex-column align-items-start">
                <h5 class="card-title mb-1 text-black" id="ip_menu_title">Website Status</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-tools"></i> Tool Management
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                            Website Status
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <span class="wsm-poll-indicator" id="wsmPollIndicator"><span class="wsm-pulse"></span>Live status sync · every 20 sec</span>
                <button type="button" class="btn btn-sm wsm-btn-primary fw-bold" id="wsmAddWebsite">
                    <i class="mdi mdi-plus me-1"></i> Add Website
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="wsm-summary mb-2">
                        <div class="wsm-summary-item"><div class="wsm-summary-label">TOTAL WEBSITES</div><div class="wsm-summary-value" id="wsmTotal">0</div></div>
                        <div class="wsm-summary-item"><div class="wsm-summary-label">LIVE</div><div class="wsm-summary-value text-success" id="wsmUp">0</div></div>
                        <div class="wsm-summary-item"><div class="wsm-summary-label">NOT LIVE</div><div class="wsm-summary-value text-danger" id="wsmDown">0</div></div>
                        <div class="wsm-summary-item"><div class="wsm-summary-label">NOT CHECKED</div><div class="wsm-summary-value text-secondary" id="wsmUnknown">0</div></div>
                    </div>
                    <div class="wsm-summary mb-3">
                        <div class="wsm-http-card wsm-2xx"><div class="wsm-summary-label">2xx · SUCCESS</div><div class="wsm-summary-value" id="wsm2xx">0</div></div>
                        <div class="wsm-http-card wsm-3xx"><div class="wsm-summary-label">3xx · REDIRECTION</div><div class="wsm-summary-value" id="wsm3xx">0</div></div>
                        <div class="wsm-http-card wsm-4xx"><div class="wsm-summary-label">4xx · CLIENT ERROR</div><div class="wsm-summary-value" id="wsm4xx">0</div></div>
                        <div class="wsm-http-card wsm-5xx"><div class="wsm-summary-label">5xx · SERVER ERROR</div><div class="wsm-summary-value" id="wsm5xx">0</div></div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between mb-2 ">
                        <div>
                            <span>Show</span>
                            <select id="wsmPerPage" class="form-select form-select-sm w-75px select3"
                                onchange="loadData(1)">
                                @php $options = [5,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end  gap-2">
                            <div class="fiters-div d-flex">
                                
                                <div id="" class="">
                                    <select id="wsmHealthFilter" class="form-select form-select-sm select3" aria-label="Filter by website status">
                                        <option value="">Status · All</option>
                                        <option value="Up">Live</option>
                                        <option value="Down">Not Live</option>
                                        <option value="Unknown">Not Checked</option>
                                    </select>
                                    <select id="wsmHttpFamilyFilter" class="form-select form-select-sm select3" aria-label="Filter by HTTP status code family">
                                        <option value="">HTTP · All codes</option>
                                        <option value="2xx">2xx · 200–299</option>
                                        <option value="3xx">3xx · 300–399</option>
                                        <option value="4xx">4xx · 400–499</option>
                                        <option value="5xx">5xx · 500–599</option>
                                        <option value="none">No response</option>
                                    </select>
                                </div>
                                <div id="" class="">
                                    <select id="wsmForFilter" class="form-select form-select-sm  select3" aria-label="Filter by website category">
                                        <option value="">Website · All</option>
                                        <option value="In-house">In-house</option>
                                        <option value="Client">Client</option>
                                    </select>
                                </div>
                                <div id="wsmCompanyFilterWrap" class="d-none">
                                    <select id="wsmCompanyFilter" class="form-select form-select-sm  select3" aria-label="Filter by company">
                                        <option value="">All companies</option>
                                    </select>
                                </div>
                            </div>
                            <div class="searchBar">
                                <input type="text" id="wsmSearch" class="searchQueryInput"
                                    placeholder="Search website, URL or company..."
                                    value="" autocomplete="off"/>

                                <div class="searchAction">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;" class="searchSubmit" id="wsmSearchButton" title="Search">
                                            <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                        </a>
                                        <a href="javascript:;" class="refreshBar" id="wsmClearSearch" title="Clear search">
                                            <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table  class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 ">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary attendance-header">
                                    <th>Website</th>
                                    <th>Live Status</th>
                                    <th >HTTP Code</th>
                                    <th >Response</th>
                                    <th >Last Checked</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7" id="wsmTableBody">
                                <tr class="skeleton-loader" id="skeleton-loader" style="border-left: 5px solid #e2e2e2;">
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center my-3 wsm-pagination border-top" id="wsmPagination">
                        <!-- Pagination buttons will appear here -->
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="modal fade" id="wsmFormModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title fw-bold" id="wsmFormTitle">Add Website</h5>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="wsmForm">
                    <div class="modal-body">
                        <div id="wsmFormError" class="alert alert-danger d-none py-2 small"></div>
                        <input type="hidden" id="wsmWebsiteId" value="">
                        <div class="wsm-form-section">
                            <div class="wsm-form-section-title"><i class="mdi mdi-web me-1 wsm-accent"></i> Website details</div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label" for="wsmWebsiteName">Website Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="wsmWebsiteName" name="website_name" maxlength="180" placeholder="e.g. Elysium Academy Website" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label" for="wsmWebsiteFor">Website For <span class="text-danger">*</span></label>
                                    <select class="form-select select3" id="wsmWebsiteFor" name="website_for" required>
                                        <option value="In-house">In-house</option>
                                        <option value="Client">Client</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label" for="wsmWebsiteUrl">Link URL <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="wsmWebsiteUrl" name="website_url" maxlength="2000" placeholder="https://www.example.com" required>
                                    
                                </div>
                                <div class="col-md-7">
                                    <label class="form-label" for="wsmCompany">Company </label>
                                    <select class="form-select select3" id="wsmCompany" name="company_id" >

                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label" for="wsmNotes">Notes </label>
                                    <textarea class="form-control" id="wsmNotes" name="notes" rows="2" maxlength="5000" placeholder="Purpose, environment or additional details"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn wsm-btn-primary" id="wsmSaveButton">
                            <span class="wsm-save-label"><i class="mdi mdi-content-save-outline me-1"></i>Save Website</span>
                            <span class="wsm-save-loading d-none"><span class="spinner-border spinner-border-sm me-1"></span>Saving…</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- Website delete confirmation modal (Bootstrap, matching Staff List pattern) --}}
    <div class="modal fade" id="wsmDeleteModal" tabindex="-1" aria-hidden="true"
         data-bs-keyboard="false" data-bs-backdrop="static">
        <div class="modal-dialog modal-sm modal-dialog-centered">
            <div class="modal-content rounded-3 text-center p-3">
                <div class="py-3">
                    <i class="mdi mdi-trash-can-outline text-danger fs-2" ></i>
                </div>
                <div class="mb-4 px-2">
                    <div class="fw-semibold text-dark mb-2">Delete Website?</div>
                    <div class="small text-muted" id="wsmDeleteMessage">
                        Are you sure you want to remove this website from monitoring?
                    </div>
                </div>
                <div class="d-flex justify-content-center gap-2 pb-2">
                    <button type="button" class="btn btn-danger" id="wsmConfirmDelete">
                        <span class="wsm-delete-label">Yes, delete</span>
                        <span class="wsm-delete-loading d-none">
                            <span class="spinner-border spinner-border-sm me-1"></span>Deleting…
                        </span>
                    </button>
                    <button type="button" class="btn btn-secondary text-black" data-bs-dismiss="modal"
                            id="wsmCancelDelete">No, cancel</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade wsm-history-modal" id="wsmHistoryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable wsm-history-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="d-flex align-items-center gap-3">
                        <span class="rounded-3 bg-white bg-opacity-10 d-inline-flex align-items-center justify-content-center" style="width:42px;height:42px;">
                            <i class="mdi mdi-chart-timeline-variant fs-3 text-white"></i>
                        </span>
                        <div>
                            <h5 class="modal-title fw-bold mb-1" id="wsmHistoryTitle">Website health history</h5>
                            <a href="javascript:void(0)" target="_blank" rel="noopener noreferrer" class="small text-white-50" id="wsmHistoryUrl">Loading website…</a>
                        </div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
                        <div class="small text-muted"><i class="mdi mdi-information-outline me-1"></i>Transition history is recorded whenever the HTTP code or health state changes.</div>
                        <div class="d-flex align-items-center gap-2">
                            <label for="wsmHistoryPeriod" class="small fw-bold text-muted">Period</label>
                            <select id="wsmHistoryPeriod" class="form-select form-select-sm" style="width:150px;">
                                <option value="24h">Last 24 hours</option>
                                <option value="7d">Last 7 days</option>
                                <option value="30d" selected>Last 30 days</option>
                                <option value="90d">Last 90 days</option>
                                <option value="all">All history</option>
                            </select>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="wsmHistoryRefresh"><i class="mdi mdi-refresh me-1"></i>Refresh</button>
                        </div>
                    </div>

                    <div id="wsmHistoryContent">
                        <div class="wsm-history-loading"><span class="spinner-border spinner-border-sm me-2"></span>Loading website health history…</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>




<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<script>
    (function () {
        'use strict';

        const root = document.getElementById('websiteStatusApp');
        if (!root) return;

        const R = @js([
            'lookups' => route('productivity.website-status.lookups'),
            'data' => route('productivity.website-status.data'),
            'store' => route('productivity.website-status.store'),
            'update' => url('/productivity/website-status'),
            'delete' => url('/productivity/website-status'),
            'check' => url('/productivity/website-status'),
            'statuses' => route('productivity.website-status.statuses'),
            'refresh' => route('productivity.website-status.statuses.refresh'),
            'history' => url('/productivity/website-status'),
            'favicon' => route('productivity.bookmarks.favicon'),
        ]);

        const state = {
            page: 1,
            perPage: 25,
            search: '',
            healthStatus: '',
            httpFamily: '',
            websiteFor: '',
            companyId: '',
            lastPage: 1,
            total: 0,
            rows: new Map(),
            lookups: null,
            autoRefresh: null,
            autoRefreshBusy: false,
            searchTimer: null,
            requestController: null,
            formBusy: false,
            historyWebsiteId: null,
            historyPeriod: '30d',
            historyPage: 1,
            historyNewestEventId: null,
            historyCharts: {}
        };

        const $ = (selector) => root.querySelector(selector);
        const formModalElement = $('#wsmFormModal');
        const formModal = () => bootstrap.Modal.getOrCreateInstance(formModalElement);
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

        function escapeHtml(value) {
            return String(value ?? '').replace(/[&<>"']/g, function (character) {
                return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[character];
            });
        }

        function buildQuery(values) {
            const params = new URLSearchParams();
            Object.keys(values).forEach(function (key) {
                const value = values[key];
                if (value !== '' && value !== null && value !== undefined) params.set(key, value);
            });
            return params.toString();
        }

        async function fetchJson(url, options = {}) {
            const headers = Object.assign({
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }, options.headers || {});
            if (options.method && options.method.toUpperCase() !== 'GET') headers['X-CSRF-TOKEN'] = csrfToken;

            const response = await fetch(url, Object.assign({
                credentials: 'same-origin',
                headers: headers
            }, options));

            let payload = {};
            try { payload = await response.json(); } catch (error) { payload = {}; }
            if (!response.ok) {
                const validationMessage = payload.errors ? Object.values(payload.errors).flat()[0] : '';
                throw new Error(payload.message || validationMessage || `Request failed (${response.status}).`);
            }
            return payload;
        }

        function notify(message, type = 'success') {
            const existing = document.getElementById('wsmNotice');
            if (existing) existing.remove();
            const element = document.createElement('div');
            element.id = 'wsmNotice';
            element.className = `alert alert-${type === 'error' ? 'danger' : type} shadow-sm position-fixed`;
            element.style.cssText = 'z-index:2000;right:20px;top:90px;max-width:380px;font-size:12px;';
            element.textContent = message;
            document.body.appendChild(element);
            window.setTimeout(() => element.remove(), 3800);
        }

        function showSkeleton() {
            const body = $('#wsmTableBody');
            body.innerHTML = '';
            for (let row = 0; row < 6; row++) {
                body.insertAdjacentHTML('beforeend', `<tr>${Array.from({ length: 6 }, () => '<td class="wsm-skeleton-cell"><div class="wsm-skeleton"></div></td>').join('')}</tr>`);
            }
        }

        function formatDateTime(value) {
            if (!value) return '<span class="text-muted">Not checked yet</span>';
            const parsed = new Date(String(value).replace(' ', 'T'));
            if (Number.isNaN(parsed.getTime())) return escapeHtml(value);
            return parsed.toLocaleString('en-IN', {
                day: '2-digit', month: 'short', year: 'numeric',
                hour: '2-digit', minute: '2-digit', hour12: true
            });
        }

        function statusMarkup(row) {
            if (Number(row.is_active) === 0) {
                return '<span class="badge bg-label-secondary" data-health-label>Monitoring Paused</span>';
            }
            if (row.health_status === 'Up') {
                return '<span class="badge bg-label-success" data-health-label><i class="mdi mdi-check-circle-outline me-1"></i>Live</span>';
            }
            if (row.health_status === 'Down') {
                const title = escapeHtml(row.last_error || 'Website is not responding normally.');
                return `<span class="badge bg-label-danger" title="${title}" data-health-label><i class="mdi mdi-alert-circle-outline me-1"></i>Not Live</span>`;
            }
            return '<span class="badge bg-label-secondary" data-health-label><i class="mdi mdi-progress-clock me-1"></i>Not Checked</span>';
        }

        // function codeMarkup(row) {
        //     if (!row.http_status_code) return '<span class="wsm-code" data-http-code>No response</span>';
        //     const tone = Number(row.http_status_code) >= 400 ? 'text-danger' : 'text-success';
        //     return `<span class="wsm-code ${tone}" data-http-code>HTTP ${escapeHtml(row.http_status_code)}</span>`;
        // }

        function codeMarkup(row) {
            const rawCode = row.http_status_code;

            if (rawCode === null || rawCode === undefined || String(rawCode).trim() === '') {
                return '<span class="wsm-code text-muted" data-http-code>No response</span>';
            }

            const code = Number(rawCode);

            if (!Number.isInteger(code) || code < 100 || code > 599) {
                return `<span class="wsm-code text-muted" data-http-code>${escapeHtml(rawCode)}</span>`;
            }

            let tone = 'text-secondary';
            let category = 'Unknown';

            if (code >= 200 && code <= 299) {
                tone = 'text-success';
                category = 'Success';
            } else if (code >= 300 && code <= 399) {
                tone = 'text-warning';
                category = 'Redirection';
            } else if (code >= 400 && code <= 499) {
                tone = 'text-danger';
                category = 'Client Error';
            } else if (code >= 500 && code <= 599) {
                tone = 'text-danger fw-bold';
                category = 'Server Error';
            }

            return `<span class="wsm-code ${tone}" data-http-code title="${category}">HTTP ${escapeHtml(code)}</span>`;
        }

        function responseMarkup(row) {
            return row.response_time_ms === null || row.response_time_ms === undefined
                ? '<span class="text-muted" data-response-time>—</span>'
                : `<span class="fw-semibold" data-response-time>${escapeHtml(row.response_time_ms)} ms</span>`;
        }

        function renderRow(row) {
            const id = Number(row.sno);
            state.rows.set(String(id), row);
            const url = String(row.website_url || '');
            const websiteForClass = row.website_for === 'Client' ? 'bg-label-info' : 'bg-label-primary';
            const activeText = 'Automatic monitoring';

            return `
                <tr data-website-row="${id}">
                    <td>
                        <div class="d-flex align-items-center gap-2">

                            <span class="wsm-favicon" data-wsm-favicon-for="${escapeHtml(url)}">
                                <i class="mdi mdi-web"></i>
                            </span>

                            <div class="d-flex flex-column">
                                <div class="d-flex gap-2">
                                    <a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer" class="" title="${escapeHtml(url)}" >
                                        <span class="fs-7 fw-bold text-black">${escapeHtml(row.website_name)}</span>
                                    </a>
                                    <div>
                                        <span class="badge ${websiteForClass}">${escapeHtml(row.website_for || 'In-house')}</span>
                                    </div>
                                </div>
                                <div class="fw-semibold text-dark fs-8">${escapeHtml(row.company_name || '-')}</div>
                            </div>

                        </div>
                    </td>
                
                    <td data-health-cell>${statusMarkup(row)}</td>
                    <td data-code-cell>${codeMarkup(row)}</td>
                    <td data-response-cell>${responseMarkup(row)}</td>
                    <td>
                        <div class="fw-semibold" data-last-checked>${formatDateTime(row.last_checked_at)}</div>
                        ${row.last_error ? `<div class="wsm-muted text-danger" title="${escapeHtml(row.last_error)}">${escapeHtml(String(row.last_error).slice(0, 45))}${String(row.last_error).length > 45 ? '…' : ''}</div>` : '<div class="wsm-muted"></div>'}
                    </td>
                    <td>
                        <div class="wsm-actions">
                            <button type="button" class="btn btn-icon btn-sm border-none" data-wsm-action="check" data-id="${id}" title="Check website now"><i class="mdi mdi-refresh fs-3 text-black"></i></button>
                            <button type="button" class="btn btn-sm btn-label-primary px-2" data-wsm-action="history" data-id="${id}" title="View HTTP status history"><i class="mdi mdi-chart-timeline-variant me-1"></i>History</button>
                            <button type="button" class="btn btn-icon btn-sm border-none" data-wsm-action="edit" data-id="${id}" title="Edit website"><i class="mdi mdi-pencil-outline fs-3 text-black"></i></button>
                            <button type="button" class="btn btn-icon btn-sm text-danger border-none" data-wsm-action="delete" data-id="${id}" title="Remove website"><i class="mdi mdi-delete-outline fs-3 text-black"></i></button>
                        </div>
                    </td>
                </tr>
            `;
        }

        function renderEmpty() {
            $('#wsmTableBody').innerHTML = `<tr><td colspan="6"><div class="wsm-empty"><i class="mdi mdi-web-off"></i><strong class="d-block text-dark">No websites found</strong><span>Change your filters or add a website to begin monitoring.</span></div></td></tr>`;
        }

        function updateSummary(summary = {}) {
            $('#wsmTotal').textContent = Number(summary.total || 0).toLocaleString('en-IN');
            $('#wsmUp').textContent = Number(summary.up || 0).toLocaleString('en-IN');
            $('#wsmDown').textContent = Number(summary.down || 0).toLocaleString('en-IN');
            $('#wsmUnknown').textContent = Number(summary.unknown || 0).toLocaleString('en-IN');
            $('#wsm2xx').textContent = Number(summary['2xx'] || 0).toLocaleString('en-IN');
            $('#wsm3xx').textContent = Number(summary['3xx'] || 0).toLocaleString('en-IN');
            $('#wsm4xx').textContent = Number(summary['4xx'] || 0).toLocaleString('en-IN');
            $('#wsm5xx').textContent = Number(summary['5xx'] || 0).toLocaleString('en-IN');
        }

        function updatePagination(currentPage, lastPage, total, perPage) {
            const container = $('#wsmPagination');
            container.innerHTML = '';
            container.style.display = 'flex';
            container.style.justifyContent = 'space-between';
            container.style.alignItems = 'center';

            const start = total === 0 ? 0 : ((currentPage - 1) * perPage) + 1;
            const end = Math.min(currentPage * perPage, total);
            container.insertAdjacentHTML('beforeend', `<div class="small text-muted">Showing ${start} to ${end} of ${total} results</div>`);

            const firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" title="First Page"><button class="page-link" data-page="1">«</button></li>`;
            const prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" title="Previous"><button class="page-link" data-page="${currentPage - 1}">‹</button></li>`;
            const nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" title="Next"><button class="page-link" data-page="${currentPage + 1}">›</button></li>`;
            const lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" title="Last Page"><button class="page-link" data-page="${lastPage}">»</button></li>`;

            let pageButtons = '';
            const range = 2;
            const startPage = Math.max(1, currentPage - range);
            const endPage = Math.min(lastPage, currentPage + range);
            for (let page = startPage; page <= endPage; page++) {
                pageButtons += `<li class="page-item ${page === currentPage ? 'active' : ''}"><button class="page-link" data-page="${page}">${page}</button></li>`;
            }

            container.insertAdjacentHTML('beforeend', `
                <nav aria-label="Website status pagination">
                    <ul class="pagination pagination-sm mb-0">
                        ${firstButton}${prevButton}${pageButtons}${nextButton}${lastButton}
                    </ul>
                </nav>
            `);
        }

        async function loadLookups() {
            const response = await fetchJson(R.lookups);

            state.lookups = response.data || {};

            const companies = Array.isArray(state.lookups.companies)
                ? state.lookups.companies
                : [];

            // Company is optional
            const companyOptions = `
                <option value="">Select company</option>
                ${companies.map(function (company) {
                    return `
                        <option value="${Number(company.sno)}">
                            ${escapeHtml(company.company_name)}
                        </option>
                    `;
                }).join('')}
            `;

            $('#wsmCompany').innerHTML = companyOptions;
            // Company assignment is optional. Always start the add form with
            // the placeholder selected; editForm will select the saved value.
            $('#wsmCompany').value = '';

            if (state.lookups.can_select_company) {
                $('#wsmCompanyFilterWrap').classList.remove('d-none');

                $('#wsmCompanyFilter').innerHTML = `
                    <option value="">All companies</option>
                    ${companies.map(function (company) {
                        return `
                            <option value="${Number(company.sno)}">
                                ${escapeHtml(company.company_name)}
                            </option>
                        `;
                    }).join('')}
                `;
            } else {
                $('#wsmCompanyFilterWrap').classList.add('d-none');
            }

            initSelect3(root.querySelectorAll('.select3'));
        }

        function initSelect3(elements) {
            if (!window.jQuery || !jQuery.fn || !jQuery.fn.select2) return;
            jQuery(elements).each(function () {
                const $select = jQuery(this);
                if ($select.hasClass('select2-hidden-accessible')) $select.select2('destroy');
                const inModal = $select.closest('.modal').length > 0;
                $select.select2({
                    width: '100%',
                    minimumResultsForSearch: 6,
                    dropdownParent: inModal ? jQuery($select.closest('.modal')) : $select.parent()
                });
            });
        }

        async function loadWebsiteData(page = 1) {
            state.page = page;
            state.perPage = Number($('#wsmPerPage').value || 10);
            state.search = $('#wsmSearch').value.trim();
            state.healthStatus = $('#wsmHealthFilter').value;
            state.httpFamily = $('#wsmHttpFamilyFilter').value;
            state.websiteFor = $('#wsmForFilter').value;
            state.companyId = $('#wsmCompanyFilterWrap').classList.contains('d-none') ? '' : $('#wsmCompanyFilter').value;

            if (state.requestController) state.requestController.abort();
            state.requestController = new AbortController();
            showSkeleton();

            const query = buildQuery({
                page: state.page,
                per_page: state.perPage,
                search: state.search,
                health_status: state.healthStatus,
                http_family: state.httpFamily,
                website_for: state.websiteFor,
                company_id: state.companyId
            });

            try {
                const response = await fetchJson(`${R.data}?${query}`, { signal: state.requestController.signal });
                const rows = Array.isArray(response.data) ? response.data : [];
                state.lastPage = Number(response.last_page || 1);
                state.total = Number(response.total || 0);
                state.rows.clear();

                if (rows.length) {
                    $('#wsmTableBody').innerHTML = rows.map(renderRow).join('');
                    resolveFavicons();
                } else {
                    renderEmpty();
                }

                updateSummary(response.summary || {});
                updatePagination(Number(response.current_page || 1), state.lastPage, state.total, Number(response.per_page || state.perPage));
                
            } catch (error) {
                if (error.name === 'AbortError') return;
                $('#wsmTableBody').innerHTML = `<tr><td colspan="6"><div class="wsm-empty"><i class="mdi mdi-alert-circle-outline"></i><strong class="d-block text-dark">Unable to load website records</strong><span>${escapeHtml(error.message || 'Please try again.')}</span><div class="mt-3"><button type="button" class="btn btn-sm wsm-btn-primary" id="wsmRetry">Retry</button></div></div></td></tr>`;
                $('#wsmPagination').innerHTML = '';
            }
        }

        function patchStatusRow(status) {
            const rowElement = root.querySelector(`[data-website-row="${Number(status.sno)}"]`);
            if (!rowElement) return;

            const rowData = state.rows.get(String(status.sno)) || {};
            Object.assign(rowData, status);
            state.rows.set(String(status.sno), rowData);

            const healthCell = rowElement.querySelector('[data-health-cell]');
            const codeCell = rowElement.querySelector('[data-code-cell]');
            const responseCell = rowElement.querySelector('[data-response-cell]');
            const checkedCell = rowElement.querySelector('[data-last-checked]');
            if (healthCell) healthCell.innerHTML = statusMarkup(rowData);
            if (codeCell) codeCell.innerHTML = codeMarkup(rowData);
            if (responseCell) responseCell.innerHTML = responseMarkup(rowData);
            if (checkedCell) checkedCell.innerHTML = formatDateTime(rowData.last_checked_at);

            const errorCell = checkedCell?.parentElement?.querySelector('.wsm-muted');
            if (errorCell) {
                errorCell.classList.toggle('text-danger', Boolean(rowData.last_error));
                errorCell.title = rowData.last_error || '';
                errorCell.textContent = rowData.last_error
                    ? `${String(rowData.last_error).slice(0, 45)}${String(rowData.last_error).length > 45 ? '…' : ''}`
                    : '';
            }
        }

        function applyFavicon(url, src) {
            root.querySelectorAll('[data-wsm-favicon-for]').forEach(function (element) {
                if (element.getAttribute('data-wsm-favicon-for') !== url) return;
                element.dataset.resolved = '1';
                if (src) {
                    element.innerHTML = `<img loading="lazy" decoding="async" referrerpolicy="no-referrer" src="${escapeHtml(src)}" alt="">`;
                }
            });
        }

        function resolveFavicons() {
            const urls = [];
            root.querySelectorAll('[data-wsm-favicon-for]').forEach(function (element) {
                if (element.dataset.resolved === '1') return;
                const url = element.getAttribute('data-wsm-favicon-for') || '';
                if (url && !urls.includes(url)) urls.push(url);
            });

            urls.forEach(function (url) {
                fetchJson(`${R.favicon}?url=${encodeURIComponent(url)}`)
                    .then(function (response) {
                        applyFavicon(url, String(response?.data?.favicon_url || ''));
                    })
                    .catch(function () {
                        root.querySelectorAll('[data-wsm-favicon-for]').forEach(function (element) {
                            if (element.getAttribute('data-wsm-favicon-for') === url) element.dataset.resolved = '1';
                        });
                    });
            });
        }

        function setPollIndicator(message) {
            const indicator = $('#wsmPollIndicator');
            if (!indicator) return;
            indicator.innerHTML = `<span class="wsm-pulse"></span>${escapeHtml(message)}`;
        }

        async function refreshStatuses() {
            if (state.autoRefreshBusy || document.hidden) return;
            state.autoRefreshBusy = true;
            setPollIndicator('Checking websites now...');

            try {
                // Submit only the visible page IDs. The backend checks up to three
                // due websites from this page, then returns all visible status data.
                const ids = Array.from(root.querySelectorAll('[data-website-row]'))
                    .map((row) => Number(row.dataset.websiteRow))
                    .filter(Boolean);

                const params = new URLSearchParams();
                ids.forEach((id) => params.append('ids[]', id));

                const response = await fetchJson(`${R.refresh}?${params.toString()}`, { method: 'POST' });
                (Array.isArray(response.data) ? response.data : []).forEach(patchStatusRow);
                updateSummary(response.summary || {});

                // Keep the open history modal in sync with status transitions
                // discovered by the same live monitoring cycle.
                if (state.historyWebsiteId && historyModalElement?.classList.contains('show')) {
                    await loadHistory(state.historyPage || 1, true);
                }

                const checked = Number(response.checks?.checked || 0);
                setPollIndicator(checked > 0
                    ? `Auto-check active · ${checked} website${checked === 1 ? '' : 's'} checked`
                    : 'Auto-check active · waiting for due websites');
                
            } catch (error) {
                // Keep the existing table intact. The next state.autoRefresh cycle retries.
                setPollIndicator('Auto-check reconnecting...');
            } finally {
                state.autoRefreshBusy = false;
            }
        }

        function startRefresh() {
            clearInterval(state.autoRefresh);
            const interval = document.hidden ? 60000 : 20000;
            state.autoRefresh = setInterval(() => {
                refreshStatuses();
            }, interval);

            // Check immediately when the page opens or the user returns to this tab.
            if (!document.hidden) refreshStatuses();
        }

        function openForm(row = null) {
            $('#wsmForm').reset();
            $('#wsmWebsiteId').value = row ? row.sno : '';
            $('#wsmFormTitle').textContent = row ? 'Edit Website' : 'Add Website';
            $('#wsmWebsiteName').value = row?.website_name || '';
            $('#wsmWebsiteUrl').value = row?.website_url || '';
            $('#wsmWebsiteFor').value = row?.website_for || 'In-house';
            // Add: leave company blank by default. Edit: preserve the saved
            // company_id, including 0 for the explicitly selected Main Company.
            const selectedCompanyId = row && row.company_id !== null && row.company_id !== undefined
                ? String(row.company_id)
                : '';
            $('#wsmCompany').value = selectedCompanyId;
            $('#wsmNotes').value = row?.notes || '';
            $('#wsmFormError').classList.add('d-none');
            initSelect3(root.querySelectorAll('#wsmForm .select3'));
            if (window.jQuery && jQuery.fn && jQuery.fn.select2) {
                jQuery('#wsmWebsiteFor').val(row?.website_for || 'In-house').trigger('change.select2');
                jQuery('#wsmCompany').val(selectedCompanyId).trigger('change.select2');
            }
            formModal().show();
        }

        async function saveWebsite(event) {
            event.preventDefault();
            if (state.formBusy) return;
            const form = $('#wsmForm');
            if (!form.reportValidity()) return;

            const id = $('#wsmWebsiteId').value;
            const formData = new FormData(form);
            // Send an explicit empty value when no company is selected. Laravel's
            // empty-string-to-null middleware and the controller then persist SQL NULL.
            if (!$('#wsmCompany').value) formData.set('company_id', '');
            formData.set('is_active', '1');
            formData.set('check_interval_minutes', '1');
            if (id) formData.set('_method', 'PUT');

            state.formBusy = true;
            $('#wsmSaveButton').disabled = true;
            $('#wsmSaveButton .wsm-save-label').classList.add('d-none');
            $('#wsmSaveButton .wsm-save-loading').classList.remove('d-none');
            $('#wsmFormError').classList.add('d-none');

            try {
                const endpoint = id ? `${R.update}/${encodeURIComponent(id)}` : R.store;
                const response = await fetchJson(endpoint, {
                    method: 'POST',
                    body: formData
                });
                formModal().hide();
                // notify(response.message || 'Website saved successfully.');
                toastr.success(response.message || 'Website saved successfully.');
                await loadWebsiteData(id ? state.page : 1);
            } catch (error) {
                $('#wsmFormError').textContent = error.message || 'Unable to save website details.';
                $('#wsmFormError').classList.remove('d-none');
            } finally {
                state.formBusy = false;
                $('#wsmSaveButton').disabled = false;
                $('#wsmSaveButton .wsm-save-label').classList.remove('d-none');
                $('#wsmSaveButton .wsm-save-loading').classList.add('d-none');
            }
        }

        async function checkWebsiteNow(id, button) {
            if (button) {
                button.disabled = true;
                button.innerHTML = '<span class="spinner-border spinner-border-sm "></span>';
            }
          
            try {
                const response = await fetchJson(`${R.check}/${encodeURIComponent(id)}/check`, { method: 'POST' });
                if (response.data) patchStatusRow(response.data);
                const currentRow = state.rows.get(String(id));
                if (currentRow) {
                    Object.assign(currentRow, response.data || {});
                    const rowElement = root.querySelector(`[data-website-row="${Number(id)}"]`);
                    if (rowElement) {
                        rowElement.outerHTML = renderRow(currentRow);
                        resolveFavicons();
                    }
                }
                if (response.data?.health_status === 'Up') toastr.success('Website is live.') ;
                else  toastr.warning('Website is not live. Check the HTTP code or connection details.');
                await refreshStatuses();
            } catch (error) {
                // notify(error.message || 'Unable to check this website.', 'error');
                toastr.error(error.message || 'Unable to check this website.');
            } finally {
                const refreshedButton = root.querySelector(`[data-wsm-action="check"][data-id="${Number(id)}"]`);
                if (refreshedButton) {
                    refreshedButton.disabled = false;
                    refreshedButton.innerHTML = '<i class="mdi mdi-refresh fs-3 text-black"></i>';
                }
            }
        }

        const deleteModalElement = $('#wsmDeleteModal');
        const deleteModal = () => bootstrap.Modal.getOrCreateInstance(deleteModalElement);
        let pendingDeleteId = null;
        let deleteBusy = false;

        function openDeleteConfirmation(id) {
            const row = state.rows.get(String(id));
            if (!row || !id) return;

            pendingDeleteId = String(id);
            $('#wsmDeleteMessage').textContent =
                `Are you sure you want to remove “${row.website_name || 'this website'}” from the Website Status monitor?`; 

            const confirmButton = $('#wsmConfirmDelete');
            confirmButton.disabled = false;
            $('#wsmCancelDelete').disabled = false;
            confirmButton.querySelector('.wsm-delete-label').classList.remove('d-none');
            confirmButton.querySelector('.wsm-delete-loading').classList.add('d-none');

            deleteModal().show();
        }

        async function deleteWebsite() {
            if (deleteBusy || !pendingDeleteId) return;

            const id = pendingDeleteId;
            const confirmButton = $('#wsmConfirmDelete');
            deleteBusy = true;
            confirmButton.disabled = true;
            $('#wsmCancelDelete').disabled = true;
            confirmButton.querySelector('.wsm-delete-label').classList.add('d-none');
            confirmButton.querySelector('.wsm-delete-loading').classList.remove('d-none');

            try {
                const response = await fetchJson(`${R.delete}/${encodeURIComponent(id)}`, { method: 'DELETE' });
                deleteModal().hide();
                pendingDeleteId = null;
                toastr.success(response.message || 'Website removed.');
                // notify(response.message || 'Website removed.');
                await loadWebsiteData(state.page);
            } catch (error) {
                // notify(error.message || 'Unable to remove website.', 'error');
                toastr.error(error.message || 'Unable to remove website.');
            } finally {
                deleteBusy = false;
                confirmButton.disabled = false;
                $('#wsmCancelDelete').disabled = false;
                confirmButton.querySelector('.wsm-delete-label').classList.remove('d-none');
                confirmButton.querySelector('.wsm-delete-loading').classList.add('d-none');
            }
        }

        const historyModalElement = $('#wsmHistoryModal');
        const historyModal = () => bootstrap.Modal.getOrCreateInstance(historyModalElement);

        function historyStatusBadge(code, healthStatus) {
            if (code === null || code === undefined || code === '') {
                return `<span class="badge bg-label-secondary">No HTTP response</span>`;
            }
            const numericCode = Number(code);
            let tone = 'bg-label-secondary';
            if (numericCode >= 200 && numericCode <= 299) tone = 'bg-label-success';
            else if (numericCode >= 300 && numericCode <= 399) tone = 'bg-label-warning';
            else if (numericCode >= 400 && numericCode <= 499) tone = 'bg-label-danger';
            else if (numericCode >= 500 && numericCode <= 599) tone = 'bg-label-dark';
            return `<span class="badge ${tone}">HTTP ${escapeHtml(numericCode)}</span>`;
        }

        function destroyHistoryCharts() {
            Object.keys(state.historyCharts).forEach(function (key) {
                if (state.historyCharts[key]) state.historyCharts[key].destroy();
                state.historyCharts[key] = null;
            });
        }

        function renderHistoryCharts(payload) {
            destroyHistoryCharts();
            const events = Array.isArray(payload.chart) ? payload.chart : [];
            state.historyNewestEventId = events.length ? Number(events[events.length - 1].sno) : null;

            if (typeof window.Chart === 'undefined') {
                $('#wsmHistoryStatusChart').parentElement.innerHTML = '<div class="wsm-history-empty">Charts could not be loaded. Check the Chart.js CDN connection.</div>';
                $('#wsmHistoryResponseChart').parentElement.innerHTML = '<div class="wsm-history-empty">Chart library unavailable.</div>';
                $('#wsmHistoryDistributionChart').parentElement.innerHTML = '<div class="wsm-history-empty">Chart library unavailable.</div>';
                return;
            }

            const labels = events.map((event) => formatHistoryChartDate(event.changed_at));
            const codeValues = events.map((event) => event.http_status_code === null ? null : Number(event.http_status_code));
            const responseValues = events.map((event) => event.response_time_ms === null ? null : Number(event.response_time_ms));
            const chartDefaults = {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: { display: false },
                    tooltip: { backgroundColor: '#1f2937', padding: 10, titleFont: { size: 11 }, bodyFont: { size: 11 } }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { color: '#8a94a6', maxTicksLimit: 8, maxRotation: 0, font: { size: 9 } } },
                    y: { grid: { color: 'rgba(148,163,184,.16)' }, ticks: { color: '#8a94a6', font: { size: 9 } } }
                }
            };

            state.historyCharts.status = new Chart($('#wsmHistoryStatusChart'), {
                type: 'line',
                data: {
                    labels,
                    datasets: [{
                        label: 'HTTP status code',
                        data: codeValues,
                        stepped: true,
                        borderWidth: 2.5,
                        pointRadius: 3,
                        pointHoverRadius: 5,
                        spanGaps: false,
                        tension: 0,
                        fill: false,
                        borderColor: '#4b66d1',
                        backgroundColor: 'rgba(75,102,209,.12)'
                    }]
                },
                options: Object.assign({}, chartDefaults, {
                    scales: Object.assign({}, chartDefaults.scales, {
                        y: Object.assign({}, chartDefaults.scales.y, {
                            min: 100,
                            max: 599,
                            ticks: Object.assign({}, chartDefaults.scales.y.ticks, {
                                stepSize: 100,
                                callback: (value) => [200, 300, 400, 500].includes(Number(value)) ? value : ''
                            })
                        })
                    }),
                    plugins: Object.assign({}, chartDefaults.plugins, {
                        tooltip: { callbacks: { label: (context) => context.raw === null ? 'No HTTP response' : `HTTP ${context.raw}` } }
                    })
                })
            });

            state.historyCharts.response = new Chart($('#wsmHistoryResponseChart'), {
                type: 'line',
                data: {
                    labels,
                    datasets: [{
                        label: 'Response time',
                        data: responseValues,
                        borderColor: '#16a36a',
                        backgroundColor: 'rgba(22,163,106,.12)',
                        borderWidth: 2.5,
                        pointRadius: 2.5,
                        pointHoverRadius: 4,
                        tension: .32,
                        fill: true
                    }]
                },
                options: Object.assign({}, chartDefaults, {
                    scales: Object.assign({}, chartDefaults.scales, {
                        y: Object.assign({}, chartDefaults.scales.y, {
                            beginAtZero: true,
                            title: { display: true, text: 'Milliseconds', color: '#8a94a6', font: { size: 9 } }
                        })
                    }),
                    plugins: Object.assign({}, chartDefaults.plugins, {
                        tooltip: { callbacks: { label: (context) => context.raw === null ? 'No response time' : `${context.raw} ms` } }
                    })
                })
            });

            const summary = payload.summary || {};
            state.historyCharts.distribution = new Chart($('#wsmHistoryDistributionChart'), {
                type: 'doughnut',
                data: {
                    labels: ['2xx Success', '3xx Redirect', '4xx Client error', '5xx Server error'],
                    datasets: [{
                        data: [Number(summary['2xx'] || 0), Number(summary['3xx'] || 0), Number(summary['4xx'] || 0), Number(summary['5xx'] || 0)],
                        backgroundColor: ['#16a36a', '#d99b21', '#d45a4d', '#962f45'],
                        borderWidth: 0,
                        hoverOffset: 5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '68%',
                    plugins: {
                        legend: { position: 'bottom', labels: { color: '#687386', usePointStyle: true, boxWidth: 7, padding: 12, font: { size: 9 } } },
                        tooltip: chartDefaults.plugins.tooltip
                    }
                }
            });
        }

        function formatHistoryChartDate(value) {
            if (!value) return '';
            const parsed = new Date(String(value).replace(' ', 'T'));
            if (Number.isNaN(parsed.getTime())) return String(value);
            return parsed.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
        }

        function renderHistoryTable(rows) {
            if (!rows.length) {
                return '<div class="wsm-history-empty"><i class="mdi mdi-history fs-2 d-block mb-2"></i>No status changes found for this period.</div>';
            }

            return `
                <div class="table-responsive wsm-history-table-wrap">
                    <table class="table wsm-history-table">
                        <thead><tr><th>Changed At</th><th>Transition</th><th>Health</th><th>Response</th><th>Event / Error</th></tr></thead>
                        <tbody>
                            ${rows.map(function (event) {
                                const beforeCode = event.previous_http_status_code === null ? '—' : `HTTP ${event.previous_http_status_code}`;
                                const afterCode = event.http_status_code === null ? 'No response' : `HTTP ${event.http_status_code}`;
                                const typeLabel = String(event.change_type || 'status_changed').replaceAll('_', ' ');
                                return `
                                    <tr>
                                        <td class="text-nowrap">${formatDateTime(event.changed_at)}</td>
                                        <td><div class="wsm-history-transition">${escapeHtml(beforeCode)} <i class="mdi mdi-arrow-right text-muted mx-1"></i> ${escapeHtml(afterCode)}</div></td>
                                        <td>${historyStatusBadge(event.http_status_code, event.health_status)}<div class="small text-muted mt-1">${escapeHtml(event.health_status || 'Unknown')}</div></td>
                                        <td class="text-nowrap">${event.response_time_ms === null ? '—' : `${escapeHtml(event.response_time_ms)} ms`}</td>
                                        <td><div class="text-capitalize text-muted small">${escapeHtml(typeLabel)}</div><div class="wsm-history-error">${escapeHtml(event.error_message || '—')}</div></td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        }

        function renderHistoryPagination(payload) {
            const currentPage = Number(payload.current_page || 1);
            const lastPage = Number(payload.last_page || 1);
            const total = Number(payload.total || 0);
            const perPage = Number(payload.per_page || 25);
            const start = total ? ((currentPage - 1) * perPage) + 1 : 0;
            const end = Math.min(currentPage * perPage, total);
            let buttons = '';
            for (let page = Math.max(1, currentPage - 2); page <= Math.min(lastPage, currentPage + 2); page++) {
                buttons += `<li class="page-item ${page === currentPage ? 'active' : ''}"><button type="button" class="page-link" data-history-page="${page}">${page}</button></li>`;
            }
            return `
                <div class="wsm-history-pagination">
                    <span class="small text-muted">Showing ${start}–${end} of ${total} transitions</span>
                    <nav><ul class="pagination pagination-sm mb-0">
                        <li class="page-item ${currentPage <= 1 ? 'disabled' : ''}"><button type="button" class="page-link" data-history-page="${currentPage - 1}">‹</button></li>
                        ${buttons}
                        <li class="page-item ${currentPage >= lastPage ? 'disabled' : ''}"><button type="button" class="page-link" data-history-page="${currentPage + 1}">›</button></li>
                    </ul></nav>
                </div>
            `;
        }

        function renderHistoryContent(payload) {
            const website = payload.website || {};
            const summary = payload.summary || {};
            $('#wsmHistoryTitle').textContent = website.website_name || 'Website health history';
            $('#wsmHistoryUrl').textContent = website.website_url || '';
            $('#wsmHistoryUrl').href = website.website_url || 'javascript:void(0)';
            const cards = `
                <div class="row g-2 mb-3">
                    <div class="col-6 col-md-2"><div class="wsm-history-kpi"><div class="wsm-history-kpi-label">Current status</div><div class="wsm-history-kpi-value">${historyStatusBadge(website.http_status_code, website.health_status)}</div></div></div>
                    <div class="col-6 col-md-2"><div class="wsm-history-kpi"><div class="wsm-history-kpi-label">Transitions</div><div class="wsm-history-kpi-value">${Number(summary.changes || 0).toLocaleString('en-IN')}</div></div></div>
                    <div class="col-6 col-md-2"><div class="wsm-history-kpi"><div class="wsm-history-kpi-label">4xx events</div><div class="wsm-history-kpi-value text-danger">${Number(summary['4xx'] || 0).toLocaleString('en-IN')}</div></div></div>
                    <div class="col-6 col-md-2"><div class="wsm-history-kpi"><div class="wsm-history-kpi-label">5xx events</div><div class="wsm-history-kpi-value" style="color:#962f45;">${Number(summary['5xx'] || 0).toLocaleString('en-IN')}</div></div></div>
                    <div class="col-6 col-md-2"><div class="wsm-history-kpi"><div class="wsm-history-kpi-label">Avg. transition response</div><div class="wsm-history-kpi-value">${summary.average_response_time_ms === null ? '—' : `${Number(summary.average_response_time_ms).toLocaleString('en-IN')}<small class="fs-6"> ms</small>`}</div></div></div>
                    <div class="col-6 col-md-2"><div class="wsm-history-kpi"><div class="wsm-history-kpi-label">Last checked</div><div class="wsm-history-kpi-value" style="font-size:12px;">${formatDateTime(website.last_checked_at)}</div></div></div>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-xl-6"><div class="wsm-history-chart-card"><div class="wsm-history-chart-title">HTTP status timeline <span class="text-muted fw-normal">· transition events</span></div><div class="wsm-history-chart-wrap"><canvas id="wsmHistoryStatusChart"></canvas></div></div></div>
                    <div class="col-xl-6"><div class="wsm-history-chart-card"><div class="wsm-history-chart-title">Response time at transitions <span class="text-muted fw-normal">· milliseconds</span></div><div class="wsm-history-chart-wrap"><canvas id="wsmHistoryResponseChart"></canvas></div></div></div>
                    <div class="col-xl-4"><div class="wsm-history-chart-card"><div class="wsm-history-chart-title">Transition code mix</div><div class="wsm-history-chart-wrap wsm-chart-small"><canvas id="wsmHistoryDistributionChart"></canvas></div></div></div>
                    <div class="col-xl-8"><div class="wsm-history-chart-card d-flex flex-column justify-content-center"><div class="wsm-history-chart-title">HTTP code guide</div><div class="row g-2 small"><div class="col-6"><span class="badge bg-label-success me-1">2xx</span> Successful response</div><div class="col-6"><span class="badge bg-label-warning me-1">3xx</span> Redirection</div><div class="col-6"><span class="badge bg-label-danger me-1">4xx</span> Client-side error</div><div class="col-6"><span class="badge bg-label-dark me-1">5xx</span> Server-side error</div></div><div class="small text-muted mt-3">The timeline plots recorded transitions, not every polling cycle. Stable repeated responses are intentionally not duplicated in the history log.</div></div></div>
                </div>
                <div class="d-flex align-items-center justify-content-between gap-2 flex-wrap mb-2"><div class="fw-bold text-dark">Status change history</div><span class="small text-muted">Latest transitions first</span></div>
                ${renderHistoryTable(Array.isArray(payload.data) ? payload.data : [])}
                ${renderHistoryPagination(payload)}
            `;
            $('#wsmHistoryContent').innerHTML = cards;
            renderHistoryCharts(payload);
        }

        async function loadHistory(page = 1, quiet = false) {
            const id = state.historyWebsiteId;
            if (!id) return;
            state.historyPeriod = $('#wsmHistoryPeriod').value || '30d';
            state.historyPage = page;
            if (!quiet) {
                $('#wsmHistoryContent').innerHTML = '<div class="wsm-history-loading"><span class="spinner-border spinner-border-sm me-2"></span>Loading website health history…</div>';
            }
            try {
                const query = buildQuery({ period: state.historyPeriod, page: page, per_page: 25 });
                const response = await fetchJson(`${R.history}/${encodeURIComponent(id)}/history?${query}`);
                const events = Array.isArray(response.chart) ? response.chart : [];
                const newestEventId = events.length ? Number(events[events.length - 1].sno) : null;
                if (quiet && newestEventId === state.historyNewestEventId) return;
                renderHistoryContent(response);
            } catch (error) {
                $('#wsmHistoryContent').innerHTML = `<div class="alert alert-danger mb-0"><i class="mdi mdi-alert-circle-outline me-1"></i>${escapeHtml(error.message || 'Unable to load the history. Run the website status history migration and try again.')}</div>`;
            }
        }

        function openHistory(id) {
            const row = state.rows.get(String(id));
            if (!row || !id) return;
            state.historyWebsiteId = String(id);
            state.historyPage = 1;
            state.historyNewestEventId = null;
            $('#wsmHistoryTitle').textContent = row.website_name || 'Website health history';
            $('#wsmHistoryUrl').textContent = row.website_url || '';
            $('#wsmHistoryUrl').href = row.website_url || 'javascript:void(0)';
            $('#wsmHistoryPeriod').value = '30d';
            destroyHistoryCharts();
            $('#wsmHistoryContent').innerHTML = '<div class="wsm-history-loading"><span class="spinner-border spinner-border-sm me-2"></span>Loading website health history…</div>';
            historyModal().show();
            loadHistory(1);
        }

        root.addEventListener('click', function (event) {
            const actionButton = event.target.closest('[data-wsm-action]');
            if (actionButton) {
                const id = actionButton.dataset.id;
                const action = actionButton.dataset.wsmAction;
                const row = state.rows.get(String(id));
                if (action === 'check') checkWebsiteNow(id, actionButton);
                if (action === 'history') openHistory(id);
                if (action === 'edit' && row) openForm(row);
                if (action === 'delete') openDeleteConfirmation(id);
                return;
            }

            const historyPageButton = event.target.closest('[data-history-page]');
            if (historyPageButton && !historyPageButton.closest('.disabled')) {
                loadHistory(Number(historyPageButton.dataset.historyPage));
                return;
            }

            const pageButton = event.target.closest('[data-page]');
            if (pageButton && !pageButton.closest('.disabled')) {
                loadWebsiteData(Number(pageButton.dataset.page));
                return;
            }

            if (event.target.closest('#wsmRetry')) loadWebsiteData(state.page);
        });

        $('#wsmAddWebsite').addEventListener('click', function () { openForm(); });
        $('#wsmForm').addEventListener('submit', saveWebsite);
        $('#wsmConfirmDelete').addEventListener('click', deleteWebsite);

        deleteModalElement.addEventListener('hidden.bs.modal', function () {
            if (!deleteBusy) pendingDeleteId = null;
        });
        $('#wsmPerPage').addEventListener('change', function () { loadWebsiteData(1); });
        $('#wsmHealthFilter').addEventListener('change', function () { loadWebsiteData(1); });
        $('#wsmHttpFamilyFilter').addEventListener('change', function () { loadWebsiteData(1); });
        $('#wsmForFilter').addEventListener('change', function () { loadWebsiteData(1); });
        $('#wsmCompanyFilter').addEventListener('change', function () { loadWebsiteData(1); });
        $('#wsmSearchButton').addEventListener('click', function () { loadWebsiteData(1); });
        $('#wsmSearch').addEventListener('keydown', function (event) {
            if (event.key === 'Enter') loadWebsiteData(1);
        });
        $('#wsmSearch').addEventListener('input', function () {
            $('#wsmClearSearch').classList.toggle('d-none', !this.value);
            window.clearTimeout(state.searchTimer);
            state.searchTimer = window.setTimeout(function () { loadWebsiteData(1); }, 450);
        });
        $('#wsmClearSearch').addEventListener('click', function () {
            $('#wsmSearch').value = '';
            this.classList.add('d-none');
            loadWebsiteData(1);
        });

        formModalElement.addEventListener('hidden.bs.modal', function () {
            $('#wsmFormError').classList.add('d-none');
        });

        $('#wsmHistoryPeriod').addEventListener('change', function () { loadHistory(1); });
        $('#wsmHistoryRefresh').addEventListener('click', function () { loadHistory(1); });
        historyModalElement.addEventListener('hidden.bs.modal', function () {
            destroyHistoryCharts();
            state.historyWebsiteId = null;
            state.historyNewestEventId = null;
        });

        async function initialise() {
            try {
                await loadLookups();
                await loadWebsiteData(1);
                startRefresh();
                document.addEventListener('visibilitychange', startRefresh);
            } catch (error) {
                $('#wsmTableBody').innerHTML = `<tr><td colspan="6"><div class="wsm-empty"><i class="mdi mdi-alert-circle-outline"></i><strong class="d-block text-dark">Website Status could not be initialised</strong><span>${escapeHtml(error.message || 'Please check the page permissions and try again.')}</span></div></td></tr>`;
            }
        }

        initialise();
    })();
</script>
@endsection
