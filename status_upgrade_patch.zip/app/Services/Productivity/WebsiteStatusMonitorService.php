<?php

namespace App\Services\Productivity;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Carbon;
use RuntimeException;
use Throwable;


class WebsiteStatusMonitorService
{
    private const TABLE = 'egc_tool_website_status';
    private const AUTO_REFRESH_CHECK_SECONDS = 20;

    public function checkNow(int $websiteId): array
    {
        $website = DB::table(self::TABLE)
            ->where('sno', $websiteId)
            ->whereNull('deleted_at')
            ->first();

        if (!$website) {
            throw new RuntimeException('Website record was not found.');
        }

        return $this->performCheck($website);
    }


    public function checkDue(int $limit = 25): array
    {
        return $this->checkDueForScope(null, $limit);
    }

   
    public function checkDueForScope(?int $companyId, int $limit = 3, array $websiteIds = []): array
    {
        $limit = min(max($limit, 1), 25);
        $websiteIds = array_values(array_unique(array_filter(
            array_map('intval', $websiteIds),
            static fn ($id) => $id > 0
        )));
        $now = now();

        $ids = DB::table(self::TABLE)
            ->where('is_active', 1)
            ->whereNull('deleted_at')
            ->when($companyId !== null, fn ($query) => $query->where('company_id', $companyId))
           
            ->when(!empty($websiteIds), fn ($query) => $query->whereIn('sno', $websiteIds))
            ->where(function ($query) use ($now) {
                $query->whereNull('next_check_at')
                    ->orWhere('next_check_at', '<=', $now);
            })
            ->orderByRaw('COALESCE(next_check_at, created_at) ASC')
            ->orderBy('sno')
            ->limit($limit)
            ->pluck('sno');

        $checked = 0;
        $skipped = 0;

        foreach ($ids as $id) {
            $claimedWebsite = DB::transaction(function () use ($id, $companyId) {
                $website = DB::table(self::TABLE)
                    ->where('sno', $id)
                    ->where('is_active', 1)
                    ->whereNull('deleted_at')
                    ->when($companyId !== null, fn ($query) => $query->where('company_id', $companyId))
                    ->lockForUpdate()
                    ->first();

                if (!$website) {
                    return null;
                }

                
                if (
                    $website->next_check_at &&
                    Carbon::parse($website->next_check_at)->isFuture()
                ) {
                    return null;
                }

                
                $nextCheck = now()->addSeconds(self::AUTO_REFRESH_CHECK_SECONDS);

                DB::table(self::TABLE)
                    ->where('sno', $website->sno)
                    ->whereNull('deleted_at')
                    ->update([
                        'next_check_at' => $nextCheck,
                        'updated_at' => now(),
                    ]);

                $website->next_check_at = $nextCheck;

                return $website;
            });

            if (!$claimedWebsite) {
                $skipped++;
                continue;
            }

            $this->performCheck($claimedWebsite);
            $checked++;
        }

        return [
            'checked' => $checked,
            'skipped' => $skipped,
            'found' => $ids->count(),
        ];
    }

    private function performCheck(object $website): array
    {
        $startedAt = hrtime(true);
        $httpCode = null;
        $healthStatus = 'Down';
        $errorMessage = null;

        try {
            $this->assertPublicHttpUrl((string) $website->website_url);

            $client = Http::connectTimeout(3)
                ->timeout(7)
                ->withOptions(['allow_redirects' => false])
                ->withHeaders([
                    'User-Agent' => 'Elysium-Website-Monitor/1.0',
                    'Accept' => 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
                ]);

            $response = $client->head((string) $website->website_url);

            // Some servers explicitly do not implement HEAD. A ranged GET is
            // used only for those responses to avoid downloading a full page.
            if (in_array($response->status(), [405, 501], true)) {
                $response = Http::connectTimeout(3)
                    ->timeout(7)
                    ->withOptions([
                        'allow_redirects' => false,
                        'stream' => true,
                    ])
                    ->withHeaders([
                        'User-Agent' => 'Elysium-Website-Monitor/1.0',
                        'Range' => 'bytes=0-0',
                    ])
                    ->get((string) $website->website_url);

                try {
                    $response->toPsrResponse()->getBody()->close();
                } catch (Throwable $ignored) {
                    // The response body may already be closed by the HTTP client.
                }
            }

            $httpCode = (int) $response->status();
            // Keep the existing availability policy: 2xx and 3xx mean the
            // origin responded; 4xx and 5xx are reported as not-live/error.
            $healthStatus = ($httpCode >= 200 && $httpCode < 400) ? 'Up' : 'Down';

            if ($healthStatus === 'Down') {
                $errorMessage = 'The website returned HTTP ' . $httpCode . '.';
            }
        } catch (RuntimeException $exception) {
            $errorMessage = mb_substr(trim($exception->getMessage()) ?: 'Website URL is not allowed.', 0, 1000);
        } catch (Throwable $exception) {
            $errorMessage = 'Website connection failed, DNS resolution failed, or the request timed out.';
        }

        $responseTime = max(0, (int) round((hrtime(true) - $startedAt) / 1_000_000));
        $checkedAt = now();

        DB::transaction(function () use ($website, $httpCode, $healthStatus, $errorMessage, $responseTime, $checkedAt) {
            // Lock the latest state before comparing it. This avoids duplicate
            // transition records when a manual check and the live poll overlap.
            $current = DB::table(self::TABLE)
                ->where('sno', $website->sno)
                ->whereNull('deleted_at')
                ->lockForUpdate()
                ->first();

            if (!$current) {
                return;
            }

            $previousCode = $current->http_status_code !== null
                ? (int) $current->http_status_code
                : null;
            $previousHealth = (string) ($current->health_status ?? 'Unknown');
            $previousError = trim((string) ($current->last_error ?? ''));
            $currentError = trim((string) ($errorMessage ?? ''));
            // Seed one baseline event for records that existed before the
            // history feature was deployed, even when their current code stays
            // unchanged on the first post-deployment check.
            $hasHistory = DB::table('egc_tool_website_status_history')
                ->where('website_id', $current->sno)
                ->exists();
            $isInitialCheck = empty($current->last_checked_at) || !$hasHistory;
            $codeChanged = $previousCode !== $httpCode;
            $healthChanged = $previousHealth !== $healthStatus;
            $errorChanged = $previousError !== $currentError;

            // Store an append-only event only when the observed state changes.
            // This keeps the history useful without writing a row on every poll.
            if ($isInitialCheck || $codeChanged || $healthChanged || $errorChanged) {
                $changeType = $isInitialCheck
                    ? 'initial'
                    : ($codeChanged ? 'status_changed' : ($healthChanged ? 'health_changed' : 'error_changed'));

                DB::table('egc_tool_website_status_history')->insert([
                    'website_id' => (int) $current->sno,
                    'company_id' => $current->company_id !== null ? (int) $current->company_id : null,
                    'website_name' => (string) $current->website_name,
                    'website_url' => (string) $current->website_url,
                    'previous_http_status_code' => $isInitialCheck ? null : $previousCode,
                    'http_status_code' => $httpCode,
                    'previous_health_status' => $isInitialCheck ? 'Unknown' : $previousHealth,
                    'health_status' => $healthStatus,
                    'response_time_ms' => $responseTime,
                    'error_message' => $errorMessage,
                    'change_type' => $changeType,
                    'changed_at' => $checkedAt,
                    'created_at' => $checkedAt,
                ]);
            }

            $update = [
                'health_status' => $healthStatus,
                'http_status_code' => $httpCode,
                'response_time_ms' => $responseTime,
                'last_checked_at' => $checkedAt,
                'last_error' => $errorMessage,
                'next_check_at' => $checkedAt->copy()->addSeconds(self::AUTO_REFRESH_CHECK_SECONDS),
                'updated_at' => $checkedAt,
            ];

            if ($healthStatus === 'Up') {
                $update['last_success_at'] = $checkedAt;
            }

            DB::table(self::TABLE)
                ->where('sno', $website->sno)
                ->whereNull('deleted_at')
                ->update($update);
        });

        $saved = DB::table(self::TABLE)
            ->where('sno', $website->sno)
            ->whereNull('deleted_at')
            ->first();

        return $saved ? (array) $saved : [];
    }

    private function assertPublicHttpUrl(string $url): void
    {
        $parts = parse_url($url);
        if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
            throw new RuntimeException('The URL is invalid.');
        }

        $scheme = strtolower((string) $parts['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            throw new RuntimeException('Only HTTP and HTTPS websites can be monitored.');
        }

        if (isset($parts['user']) || isset($parts['pass'])) {
            throw new RuntimeException('URLs containing embedded credentials are not supported.');
        }

        $host = strtolower(rtrim((string) $parts['host'], '.'));
        $allowedHosts = (array) config('website_status.allowed_internal_hosts', []);
        $allowedHosts = array_map(static fn ($value) => strtolower(rtrim((string) $value, '.')), $allowedHosts);
        $isAllowlistedHost = in_array($host, $allowedHosts, true);

       
        if ($host === 'localhost' || $host === '127.0.0.1' || $host === '::1' || str_ends_with($host, '.localhost')) {
            throw new RuntimeException('Localhost cannot be monitored from this tool.');
        }

        $port = isset($parts['port']) ? (int) $parts['port'] : null;
        if ($port !== null && !in_array($port, [80, 443], true)) {
            $allowedPorts = array_map('intval', (array) config('website_status.allowed_internal_ports', []));
            if (!$isAllowlistedHost || !in_array($port, $allowedPorts, true)) {
                throw new RuntimeException('This custom port is not approved for the selected website host.');
            }
        }

        if (filter_var($host, FILTER_VALIDATE_IP)) {
            if ($this->isPublicIp($host) || $isAllowlistedHost) {
                return;
            }
            throw new RuntimeException('This private or reserved IP is not on the Website Status internal-host allowlist.');
        }

        $records = @dns_get_record($host, DNS_A | DNS_AAAA);
        $addresses = [];
        foreach (($records ?: []) as $record) {
            if (!empty($record['ip'])) $addresses[] = $record['ip'];
            if (!empty($record['ipv6'])) $addresses[] = $record['ipv6'];
        }

        if (!$addresses) {
            $fallback = @gethostbynamel($host);
            if (is_array($fallback)) $addresses = array_merge($addresses, $fallback);
        }

        $addresses = array_values(array_unique($addresses));
        if (!$addresses) {
            throw new RuntimeException('The server is not responding...');
        }

        foreach ($addresses as $address) {
            if (!$this->isPublicIp($address) && !$isAllowlistedHost) {
                throw new RuntimeException('This private or reserved website host is not on the Website Status internal-host allowlist.');
            }
        }
    }

    private function isPublicIp(string $ip): bool
    {
        $flags = FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE;
        return (bool) filter_var($ip, FILTER_VALIDATE_IP, $flags);
    }
}
