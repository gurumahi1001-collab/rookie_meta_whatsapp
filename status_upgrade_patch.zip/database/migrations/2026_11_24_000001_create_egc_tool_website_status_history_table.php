<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('egc_tool_website_status_history')) {
            return;
        }

        Schema::create('egc_tool_website_status_history', function (Blueprint $table) {
            $table->bigIncrements('sno');
            $table->unsignedBigInteger('website_id');
            $table->unsignedBigInteger('company_id')->nullable();
            $table->string('website_name', 180);
            $table->text('website_url');
            $table->unsignedSmallInteger('previous_http_status_code')->nullable();
            $table->unsignedSmallInteger('http_status_code')->nullable();
            $table->string('previous_health_status', 20)->nullable();
            $table->string('health_status', 20);
            $table->unsignedInteger('response_time_ms')->nullable();
            $table->text('error_message')->nullable();
            $table->string('change_type', 30)->default('status_changed');
            $table->dateTime('changed_at');
            $table->timestamp('created_at')->nullable();

            $table->index(['website_id', 'changed_at'], 'egc_ws_history_website_time_idx');
            $table->index(['company_id', 'changed_at'], 'egc_ws_history_company_time_idx');
            $table->index(['http_status_code', 'changed_at'], 'egc_ws_history_code_time_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_tool_website_status_history');
    }
};
