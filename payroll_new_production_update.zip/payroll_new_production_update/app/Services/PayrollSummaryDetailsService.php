<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * Builds the detail view used by the new payroll summary modal.
 * Generated months read the saved payroll rows; ungenerated months use the
 * same live payroll calculator as the existing payroll detail screen.
 */
class PayrollSummaryDetailsService
{
    public function summary(int $month, int $year, string $type = 'all', $companyId = null): array
    {
        $period = Carbon::create($year, $month, 1);
        $process = DB::table('egc_payroll_processes')
            ->where('payroll_month', $month)
            ->where('payroll_year', $year)
            ->where('status', 0)
            ->first();

        if ($process) {
            return $this->generatedSummary($month, $year, $type, $companyId);
        }

        return $this->liveSummary($month, $year, $type, $companyId);
    }

    private function generatedSummary(int $month, int $year, string $type, $companyId): array
    {
        $query = DB::table('egc_payroll_employee_payrolls as ep')
            ->join('egc_staff as s', 's.sno', '=', 'ep.staff_id')
            ->where('ep.payroll_month', $month)
            ->where('ep.payroll_year', $year)
            ->where('ep.status', 0)
            ->whereNotExists(function ($sub) use ($month, $year) {
                $sub->select(DB::raw(1))
                    ->from('egc_payroll_staff_deactivations as pd')
                    ->whereColumn('pd.staff_id', 'ep.staff_id')
                    ->where('pd.payroll_month', $month)
                    ->where('pd.payroll_year', $year)
                    ->where('pd.is_deactivated', 1);
            });

        if ($companyId !== null && $companyId !== '' && $type === 'salary_company') {
            $query->join('egc_staff_salary_accounts as sa', 'sa.sno', '=', 'ep.salary_account_id')
                ->where('sa.salary_company_id', (int) $companyId);
        } elseif ($companyId !== null && $companyId !== '' && $type === 'company') {
            $query->where('s.company_id', (int) $companyId);
        }

        $rows = $query->select([
            'ep.sno',
            'ep.staff_id',
            'ep.fixed_salary',
            'ep.gross_earnings',
            'ep.gross_deductions',
            'ep.employer_contribution',
            'ep.net_payable',
        ])->get();

        $entryIds = $rows->pluck('sno')->all();
        $componentRows = empty($entryIds)
            ? collect()
            : DB::table('egc_payroll_employee_payroll_details')
                ->select('component_name', 'component_category', DB::raw('SUM(actual_amount) as total'))
                ->whereIn('payroll_employee_sno', $entryIds)
                ->where('status', 0)
                ->groupBy('component_name', 'component_category')
                ->orderBy('component_category')
                ->orderBy('component_name')
                ->get();

        [$earnings, $deductions, $contributions] = $this->formatComponents($componentRows);

        return [
            'month' => Carbon::create($year, $month, 1)->format('F Y'),
            'month_int' => $month,
            'year_int' => $year,
            'generated' => true,
            'source' => 'generated',
            'company_type' => $type,
            'company_id' => $companyId,
            'staff_count' => $rows->count(),
            'fixed_salary' => round((float) $rows->sum('fixed_salary'), 2),
            'gross' => round((float) $rows->sum('gross_earnings'), 2),
            'deduction' => round((float) $rows->sum('gross_deductions'), 2),
            'employer_contribution' => round((float) $rows->sum('employer_contribution'), 2),
            'net' => round((float) $rows->sum('net_payable'), 2),
            'earnings_summary' => $earnings,
            'deductions_summary' => $deductions,
            'contribution_summary' => $contributions,
        ];
    }

    private function liveSummary(int $month, int $year, string $type, $companyId): array
    {
        $period = Carbon::create($year, $month, 1);
        $endOfMonth = $period->copy()->endOfMonth()->toDateString();
        $payrollMonth = $period->format('Y-m');

        $query = DB::table('egc_staff_salary_accounts as sa')
            ->join('egc_staff as s', 's.sno', '=', 'sa.staff_id')
            ->where('s.status', '!=', 2)
            ->where('sa.status', 0)
            ->where(function ($status) use ($month, $year, $payrollMonth) {
                $status->whereIn('s.status', [0, 1])
                    ->orWhere(function ($notice) use ($month, $year) {
                        $notice->where('s.status', 4)
                            ->whereNotNull('s.notice_end_date')
                            ->whereMonth('s.notice_end_date', $month)
                            ->whereYear('s.notice_end_date', $year);
                    })
                    ->orWhere(function ($exit) use ($month, $year) {
                        $exit->whereIn('s.status', [5, 6, 7])
                            ->whereNotNull('s.staff_last_date')
                            ->whereMonth('s.staff_last_date', $month)
                            ->whereYear('s.staff_last_date', $year)
                            ->whereNotIn('s.sno', [211, 212, 94, 77])
                            ->whereRaw('DATEDIFF(s.staff_last_date, s.date_of_joining) > ?', [3]);
                    })
                    ->orWhere(function ($special) use ($payrollMonth) {
                        $special->whereIn('s.sno', [211, 212, 94, 77])
                            ->whereIn('s.status', [5, 6, 7])
                            ->whereNotNull('s.staff_last_date')
                            ->whereRaw(
                                "? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m') AND DATE_FORMAT(DATE_SUB(s.staff_last_date, INTERVAL 1 MONTH), '%Y-%m')",
                                [$payrollMonth]
                            )
                            ->whereRaw('DATEDIFF(s.staff_last_date, s.date_of_joining) > ?', [3]);
                    });
            })
            ->whereDate('s.date_of_joining', '<=', $endOfMonth)
            ->where('s.sno', '>', 0)
            ->whereNotExists(function ($sub) use ($month, $year) {
                $sub->select(DB::raw(1))
                    ->from('egc_payroll_staff_deactivations as pd')
                    ->whereColumn('pd.staff_id', 's.sno')
                    ->where('pd.payroll_month', $month)
                    ->where('pd.payroll_year', $year)
                    ->where('pd.is_deactivated', 1);
            })
            ->select([
                's.*',
                's.sno',
                'sa.sno as salary_account_id',
                'sa.gross_salary as basic_salary',
                'sa.per_day_salary',
            ]);

        if ($companyId !== null && $companyId !== '' && $type === 'salary_company') {
            $query->where('sa.salary_company_id', (int) $companyId);
        } elseif ($companyId !== null && $companyId !== '' && $type === 'company') {
            $query->where('s.company_id', (int) $companyId);
        }

        $staff = $query->orderBy('s.date_of_joining', 'asc')->get();
        $payrollService = app(PayrollPreviewService::class);
        $fixedSalary = 0.0;
        $gross = 0.0;
        $deduction = 0.0;
        $net = 0.0;
        $employerContribution = 0.0;
        $earningComponents = [];
        $deductionComponents = [];
        $contributionComponents = [];

        foreach ($staff as $employee) {
            $payroll = $payrollService->calculateLivePayroll($employee, $month, $year, 0);
            $fixedSalary += (float) ($payroll['basic_salary'] ?? 0);
            $gross += (float) ($payroll['gross_salary'] ?? 0);
            $deduction += (float) ($payroll['deductions'] ?? 0);
            $employerContribution += (float) ($payroll['employer_contribution'] ?? 0);
            $net += (float) ($payroll['net_salary'] ?? 0);

            foreach (($payroll['components'] ?? []) as $component) {
                $name = (string) ($component['component'] ?? 'Unknown');
                $amount = (float) ($component['amount'] ?? 0);
                $kind = strtolower((string) ($component['type'] ?? ''));
                if ($kind === 'earning') {
                    $earningComponents[$name] = ($earningComponents[$name] ?? 0) + $amount;
                } elseif ($kind === 'deduction') {
                    $deductionComponents[$name] = ($deductionComponents[$name] ?? 0) + $amount;
                } elseif ($kind === 'employer_contribution') {
                    $contributionComponents[$name] = ($contributionComponents[$name] ?? 0) + $amount;
                }
            }
        }

        $earnings = [];
        foreach ($earningComponents as $name => $amount) {
            $earnings[] = ['name' => $name, 'total' => round($amount, 2)];
        }
        $deductions = [];
        foreach ($deductionComponents as $name => $amount) {
            $deductions[] = ['name' => $name, 'total' => round($amount, 2)];
        }
        $contributions = [];
        foreach ($contributionComponents as $name => $amount) {
            $contributions[] = ['name' => $name, 'total' => round($amount, 2)];
        }

        return [
            'month' => $period->format('F Y'),
            'month_int' => $month,
            'year_int' => $year,
            'generated' => false,
            'source' => 'live',
            'company_type' => $type,
            'company_id' => $companyId,
            'staff_count' => $staff->count(),
            'fixed_salary' => round($fixedSalary, 2),
            'gross' => round($gross, 2),
            'deduction' => round($deduction, 2),
            'employer_contribution' => round($employerContribution, 2),
            'net' => round($net, 2),
            'earnings_summary' => $earnings,
            'deductions_summary' => $deductions,
            'contribution_summary' => $contributions,
        ];
    }

    private function formatComponents($rows): array
    {
        $earnings = [];
        $deductions = [];
        $contributions = [];
        foreach ($rows as $row) {
            $item = [
                'name' => (string) $row->component_name,
                'total' => round((float) $row->total, 2),
            ];
            if (strtolower((string) $row->component_category) === 'earning') {
                $earnings[] = $item;
            } elseif (strtolower((string) $row->component_category) === 'deduction') {
                $deductions[] = $item;
            } elseif (strtolower((string) $row->component_category) === 'employer_contribution') {
                $contributions[] = $item;
            }
        }
        return [$earnings, $deductions, $contributions];
    }
}
