<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class PayrollMonthSummaryService
{
    public function summary($month, $year, $onlyBank = 0)
    {
        $endOfMonth = Carbon::create($year, $month, 1)->endOfMonth();

        /*
        |--------------------------------------------------------------------------
        | Same Staff Query as indexNew()
        |--------------------------------------------------------------------------
        */

       $staffQuery =  DB::table('egc_staff_salary_accounts')
            ->join('egc_staff as s','s.sno','=','egc_staff_salary_accounts.staff_id')
            ->leftJoin('egc_company as salary_company', 'egc_staff_salary_accounts.salary_company_id', '=', 'salary_company.sno')
            ->leftJoin('egc_company', 's.company_id', '=', 'egc_company.sno')
            ->leftJoin('egc_entity', 's.entity_id', '=', 'egc_entity.sno')
            ->leftJoin('egc_department', 's.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_division', 's.division_id', '=', 'egc_division.sno')
            ->leftJoin('egc_job_role', 's.job_role_id', '=', 'egc_job_role.sno')
            ->where('s.status','!=', 2)
            ->where('egc_staff_salary_accounts.status',0)
            ->whereNotExists(function ($sub) use ($month, $year) {
                $sub->select(DB::raw(1))
                    ->from('egc_payroll_staff_deactivations as pd')
                    ->whereColumn('pd.staff_id', 's.sno')
                    ->where('pd.payroll_month', $month)
                    ->where('pd.payroll_year', $year)
                    ->where('pd.is_deactivated', 1);
            })
            ->where(function ($q) use ($month, $year) {
                /*
                |--------------------------------------------------------------------------
                | ACTIVE STAFF
                |--------------------------------------------------------------------------
                */
                $q->whereIn('s.status', [0, 1]);
                /*
                |--------------------------------------------------------------------------
                | NOTICE PERIOD STAFF
                |--------------------------------------------------------------------------
                */
                $q->orWhere(function ($notice) use ($month, $year) {
                    $notice->where('s.status', 4)
                        ->whereNotNull('s.notice_end_date')
                        ->whereMonth(
                            's.notice_end_date',
                            $month
                        )
                        ->whereYear(
                            's.notice_end_date',
                            $year
                        );
                });
                /*
                |--------------------------------------------------------------------------
                | EXITED STAFF
                |--------------------------------------------------------------------------
                */
                 $q->orWhere(function ($exit) use ($month, $year) {
                    $exit->whereIn('s.status', [5, 6, 7])
                        ->whereNotNull('s.staff_last_date')
                        ->whereMonth('s.staff_last_date', $month)
                        ->whereYear('s.staff_last_date', $year)
                        ->whereNotIn('s.sno', [211,212, 94,77]) // exclude special staff
                        ->whereRaw(
                            'DATEDIFF(s.staff_last_date, s.date_of_joining) > ?',
                            [3]
                        );
                })

                ->orWhere(function ($special) use ($month, $year) {

                    $payrollMonth = sprintf('%04d-%02d', $year, $month);

                    $special->whereIn('s.sno', [211,212,94,77])
                        ->whereIn('s.status', [5, 6, 7])
                        ->whereNotNull('s.staff_last_date')
                        ->whereRaw(
                            "? BETWEEN DATE_FORMAT(s.date_of_joining, '%Y-%m')
                            AND DATE_FORMAT(DATE_SUB(s.staff_last_date, INTERVAL 1 MONTH), '%Y-%m')",
                            [$payrollMonth]
                        )
                        ->whereRaw(
                            'DATEDIFF(s.staff_last_date, s.date_of_joining) > ?',
                            [3]
                        );
                });
            })
            ->whereDate('s.date_of_joining', '<=', $endOfMonth)
            ->where('s.sno', '>', 0)
            // ->where('s.sno', 200)
            ->select(
                's.*',
                's.sno',
                's.staff_name',
                's.staff_id as staff_code',
                'egc_staff_salary_accounts.sno as salary_account_id',
                'egc_staff_salary_accounts.gross_salary as basic_salary',
                'egc_staff_salary_accounts.per_day_salary',
                's.company_id',
                's.entity_id',
                's.nick_name',
                's.mobile_no',
                's.staff_image',
                's.company_type',
                's.gender',
                's.salary_type',
                's.salary_date',
                's.staff_last_date',
                's.notice_start_date',
                's.notice_end_date',
                's.date_of_joining',
                'egc_entity.entity_name',
                'egc_entity.entity_short_name',
                'salary_company.company_base_color as salary_company_base_color',
                'salary_company.company_name as salary_company_name',
                'egc_company.company_base_color',
                'egc_company.company_name',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name'
            );
        
        
        $staffs = $staffQuery
            ->orderBy('s.date_of_joining', 'desc')
            ->get();


        // $staffs = $staffQuery->get();

        $staffCount = $staffs->count();

        $gross = 0;
        $fixed_salary = 0;
        $deduction = 0;
        $net = 0;

        $earningComponents = [];
        $deductionComponents = [];

        /*
        |--------------------------------------------------------------------------
        | Existing Payroll Service
        |--------------------------------------------------------------------------
        */

        

        $payrollService = app(PayrollPreviewService::class);

        foreach ($staffs as $staff) {

            $payroll = $payrollService->calculateLivePayroll($staff,$month,$year,$onlyBank);

            $fixed_salary += $payroll['basic_salary'];
            $gross += $payroll['gross_salary'];
            $deduction += round($payroll['deductions']);
            $net += round($payroll['net_salary']);

            foreach ($payroll['components'] as $component) {

                $name = $component['component'] ?? 'Unknown';
                $amount = (float)($component['amount'] ?? 0);
                $type = $component['type'] ?? '';

                if ($type == 'earning') {

                    if (!isset($earningComponents[$name])) {
                        $earningComponents[$name] = 0;
                    }

                    $earningComponents[$name] += $amount;
                }

                if ($type == 'deduction') {

                    if (!isset($deductionComponents[$name])) {
                        $deductionComponents[$name] = 0;
                    }

                    $deductionComponents[$name] += $amount;
                }
            }

        }

        $earningsSummary = [];
        $deductionsSummary = [];

        foreach ($earningComponents as $name => $amount) {

            $earningsSummary[] = [
                'name'  => $name,
                'total' => round($amount)
            ];
        }

        foreach ($deductionComponents as $name => $amount) {

            $deductionsSummary[] = [
                'name'  => $name,
                'total' => round($amount)
            ];
        }

        return [

            'staff'=>$staffCount,
            'earnings_summary' => $earningsSummary,
            'deductions_summary' => $deductionsSummary,
            'fixed_salary'=>$fixed_salary,
            'gross'=>$gross,
            'deduction'=>$deduction,
            'net'=>$net

        ];

    }
}