-- Run this once before deploying the updated payroll controller/Blade files.
-- A separate table is used so existing generated payroll and payslip rows are not destructively changed.
CREATE TABLE IF NOT EXISTS `egc_payroll_staff_deactivations` (
    `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `staff_id` BIGINT UNSIGNED NOT NULL,
    `payroll_month` TINYINT UNSIGNED NOT NULL,
    `payroll_year` SMALLINT UNSIGNED NOT NULL,
    `is_deactivated` TINYINT(1) NOT NULL DEFAULT 1,
    `reason` TEXT NOT NULL,
    `deactivated_by` BIGINT UNSIGNED NULL,
    `deactivated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `created_at` DATETIME NULL DEFAULT NULL,
    `updated_at` DATETIME NULL DEFAULT NULL,
    PRIMARY KEY (`sno`),
    UNIQUE KEY `uq_payroll_staff_deactivation_period` (`staff_id`, `payroll_month`, `payroll_year`),
    KEY `idx_payroll_staff_deactivation_period` (`payroll_year`, `payroll_month`, `is_deactivated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
