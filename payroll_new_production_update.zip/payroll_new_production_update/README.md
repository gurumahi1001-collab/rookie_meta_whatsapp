# Payroll UI and monthly deactivation update

This package contains only the updated/new files for the existing Laravel payroll implementation. The existing Blade layout and payroll calculation service are retained.

## Included changes

- Color legend and detail-row statuses in `payroll_list_new.blade.php`:
  - notice-period staff: full row pale yellow
  - exited staff (status 5/6/7): full row light grey
  - active variable pay: staff name highlighted pink, with the 1st/2nd/3rd month of the three-month variable period shown beneath the variable amount
  - salary structure increased against the previous month: staff name highlighted green
  - month-specific payroll deactivation: full row pale red with the recorded reason available as a tooltip
- A reason-capture modal and two routes for monthly staff deactivation and component-wise payroll summary.
- Component summary for earnings, deductions, and employer contributions. Generated months use saved payroll rows; ungenerated months use the current payroll preview calculator.
- Deactivated staff are excluded from future generation and monthly/company summary aggregates. Existing generated payroll and payslip records are not deleted or rewritten, so they remain available for audit.

## Deployment steps

1. Back up the application and database.
2. Run `sql/20261029_create_payroll_staff_deactivations.sql` against the same database used by this Laravel application. **Run the SQL before deploying the PHP files**, because the updated queries refer to the new table.
3. Copy the included `app/`, `resources/`, and `routes/` files into the matching locations in the existing application, preserving the directory structure. These are replacements for the named files, not a new Laravel project.
4. From the application root, run `php artisan optimize:clear` if the deployment uses cached routes/views/configuration.
5. Test in staging with one ungenerated month and one generated, unfrozen month. Check the row colors, summary totals/components, reason persistence, and refresh behavior before using the change in production.

## Deactivation safeguards

- A reason of at least three characters is required and the actor/time are stored with the month and staff ID.
- Frozen payroll months are locked; the endpoint returns a validation error instead of changing a frozen period.
- The stored payroll and payslip records are intentionally retained. Deactivation affects monthly totals and future generation, while the staff remains visible as a red audit row in the details modal.

## Validation performed

PHP syntax checks passed for all updated PHP/Blade/route files. JavaScript syntax checks passed for the modified script blocks; one pre-existing Blade script containing `@json(...)` was not directly parsable by Node without rendering the Blade template first. The uploaded ZIP did not include a database dump or a running application database, so database integration and browser workflow tests could not be run in this environment. Please exercise the included staging checklist before production rollout.
