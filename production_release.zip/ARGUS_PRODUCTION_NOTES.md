# ARGUS — Updated Production Source Release

Prepared: 11 October 2026

## Included release changes

### Admin panel
- Added API-backed Fleet Management with **Fleet Manage**, **Fleet Requisition**, **Claim Bills**, and **Fleet Settings** (vehicle categories and claim types).
- Added create/edit/deactivate vehicle operations, fleet assignment to approved vendors, requisition creation/review, claim review/settlement, and private evidence download.
- Updated the Project BOQ approval list to reflect the revised UI source while keeping its existing backend API flow and draft-only edit/delete safety.
- Added an admin review flow for vendor-submitted tax/bank profile changes.

### Vendor panel
- Added **My Assigned Fleet**, fleet requisitions with pickup/return actions, and claim submission with optional evidence.
- Added **General Settings** before **Roles & Permission**, for each logged-in vendor to update their own company/contact/site details. Tax/bank changes remain pending until internal review.
- Preserved the existing API-backed quotation editor and its Add Item/BOQ flow rather than replacing it with prototype sample data.

### Backend
- Added MongoDB/Mongoose fleet vehicle, requisition, claim bill, and fleet settings models plus API routes/controllers/services.
- Added server-side vendor ownership/status validation, fleet requisition transition checks, private evidence storage/download, and audit events.
- Added the `fleet_management` permission catalog entry using the existing bootstrap seed versioning pattern.
- Fixed invoice installment selection parsing for repeated `installmentIndexes` form fields, removed the unsafe default-to-first-installment behavior, and kept invoice eligibility/totals server-validated.
- Made project task/scope mutation errors visible and refresh task state after server-side task status changes instead of leaving silent optimistic state behind.

## Validation performed

- Backend JavaScript syntax checks: **passed**.
- Edited frontend TSX/TS syntax parsing: **passed**.
- Relative local imports in admin/vendor source: **passed**.
- `npm test` in backend exits successfully but reports **0 tests**, so this is not functional test coverage.
- A fresh frontend build could not be completed in this workspace because `node_modules` are not installed (`vite`/React dependencies are unavailable here). No new `dist` output is included, so an old built bundle cannot accidentally be deployed over the source changes.
- The live URL returned only the JavaScript-required application shell in the available browser inspection; interactive, authenticated production flows were not end-to-end tested here.

## Deployment checklist

1. Back up the current source/deployment and MongoDB database before deployment.
2. Deploy the updated backend source and install dependencies using the committed lockfile (`npm ci`). Keep the existing production `.env`/environment variables out of source control and do not replace them with example settings.
3. Ensure the existing private local storage directory used by `storageService` is writable by the backend process; the release intentionally excludes stored uploads, logs, backups, and environment files.
4. Confirm the existing authorization bootstrap has applied the `fleet_management` permission. Review custom internal roles in **Roles & Permissions** and grant Fleet Management actions only to the appropriate users.
5. In each frontend directory, run `npm ci` and `npm run build`, then deploy the freshly generated `dist` artifact. These commands still need to be run in an environment with the project dependencies available.
6. Verify in staging using test accounts: admin fleet CRUD and vendor assignment; vendor-only assigned fleet visibility; requisition request/approve/pickup/return/complete; claim evidence upload/download/review/settlement; vendor profile update and tax/bank approval/rejection; quotation item add/save/submit; invoice generation for available installments; and project task/deliverable/scope actions.
7. Run an end-to-end check against the production-like MongoDB schema and confirm audit events and uploaded evidence can be retrieved before enabling the menus for all users.

## Scope note

Fleet Management was present in the supplied UI source but was not defined as a module in the supplied ARGUS PDD Phase 1 functional requirements. This release implements it as an additional requested module; record the scope addition in the project change-control/sign-off process. The PDD's existing server-side RBAC and invoice/project workflow constraints were otherwise used as guardrails.

## Packaging note

The release ZIPs contain updated source and build configuration. They intentionally exclude `.env`/`.env.production` files, `node_modules`, stale `dist` builds, logs, backups, and persisted private storage files. Do not deploy an old `dist` bundle; build a fresh one from the updated source.
