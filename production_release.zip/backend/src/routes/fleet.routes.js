import { Router } from "express";
import multer from "multer";
import * as controller from "../controllers/fleet/fleetController.js";
import { authenticate } from "../middleware/auth.js";
import { requireVendorTermsAcceptedMiddleware } from "../middleware/vendorTerms.js";
import authorize from "../middleware/rbac.js";

const router = Router();
router.use(authenticate);
const allowedEvidenceTypes = new Set([
  "application/pdf", "image/jpeg", "image/png", "image/webp", "image/gif",
  "text/plain", "text/csv", "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);
const fleetEvidenceUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, callback) => allowedEvidenceTypes.has(String(file.mimetype || "").toLowerCase())
    ? callback(null, true)
    : callback(Object.assign(new Error("Evidence must be a PDF, image, text file or Word document."), { statusCode: 422, code: "FLEET_EVIDENCE_TYPE_NOT_ALLOWED" })),
});
function uploadEvidence(req, res, next) {
  fleetEvidenceUpload.single("evidence")(req, res, (error) => {
    if (!error) return next();
    return res.status(error.statusCode || (error.code === "LIMIT_FILE_SIZE" ? 413 : 400)).json({ success: false, message: error.message || "Unable to upload fleet evidence.", code: error.code || "FLEET_EVIDENCE_UPLOAD_FAILED" });
  });
}

function internalOnly(req, res, next) {
  if (["admin", "internal"].includes(String(req.user?.userType || "").toLowerCase())) return next();
  return res.status(403).json({ success: false, message: "Only internal users can perform this fleet action.", code: "FLEET_ACTION_FORBIDDEN" });
}
function vendorOrInternal(req, res, next) {
  const type = String(req.user?.userType || "").toLowerCase();
  if (!["admin", "internal", "vendor"].includes(type)) return res.status(403).json({ success: false, message: "This account cannot access fleet management.", code: "FLEET_ACCESS_FORBIDDEN" });
  if (type !== "vendor") return next();
  return requireVendorTermsAcceptedMiddleware(req, res, next);
}
function internalPermission(action) {
  const permission = authorize({ module: "fleet_management", action, realms: ["admin", "internal"], userTypes: ["admin", "internal"], allowSuperAdmin: true });
  return (req, res, next) => String(req.user?.userType || "").toLowerCase() === "vendor" ? next() : permission(req, res, next);
}
function internalOnlyPermission(action) {
  return [internalOnly, internalPermission(action)];
}

router.use(vendorOrInternal);
router.get("/settings", internalPermission("view"), controller.getSettings);
// Vendor portal needs active claim-type/category configuration, but not write access.
router.put("/settings", ...internalOnlyPermission("edit"), controller.updateSettings);
router.get("/vehicles", internalPermission("view"), controller.listVehicles);
router.post("/vehicles", ...internalOnlyPermission("add"), controller.createVehicle);
router.patch("/vehicles/:id", ...internalOnlyPermission("edit"), controller.updateVehicle);
router.delete("/vehicles/:id", ...internalOnlyPermission("delete"), controller.deleteVehicle);
router.get("/requisitions", internalPermission("view"), controller.listRequisitions);
router.post("/requisitions", internalPermission("add"), controller.createRequisition);
router.patch("/requisitions/:id/action", internalPermission("edit"), controller.updateRequisitionAction);
router.get("/claims", internalPermission("view"), controller.listClaims);
router.post("/claims", internalPermission("add"), uploadEvidence, controller.createClaim);
router.get("/claims/:id/attachment", internalPermission("view"), controller.getClaimAttachment);
router.patch("/claims/:id/status", ...internalOnlyPermission("edit"), controller.updateClaimStatus);

export default router;
