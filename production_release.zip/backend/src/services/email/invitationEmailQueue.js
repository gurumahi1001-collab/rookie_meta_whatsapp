import crypto from "node:crypto";
import os from "node:os";
import mongoose, { Schema } from "mongoose";

import env from "../../config/env.js";
import { emailConfig } from "../../config/email.js";
import User from "../../models/User.js";
import { sendVendorInvitation } from "./emailService.js";
import userManagementService from "../user/userManagementService.js";

const QUEUE_NAME = "vendor_invitation";
const WORKER_ID = `${os.hostname()}:${process.pid}:${crypto.randomUUID()}`;

const emailJobSchema = new Schema(
    {
        type: {
            type: String,
            enum: [QUEUE_NAME],
            required: true,
            index: true,
        },
        status: {
            type: String,
            enum: ["queued", "processing", "succeeded", "failed"],
            default: "queued",
            index: true,
        },
        payload: {
            type: String,
            required: true,
        },
        attempts: {
            type: Number,
            default: 0,
            min: 0,
        },
        maxAttempts: {
            type: Number,
            required: true,
            min: 1,
        },
        nextAttemptAt: {
            type: Date,
            default: Date.now,
            index: true,
        },
        lockedAt: {
            type: Date,
            default: null,
        },
        lockedBy: {
            type: String,
            default: "",
            maxlength: 180,
        },
        lastError: {
            type: String,
            default: "",
            maxlength: 2000,
        },
        sentAt: {
            type: Date,
            default: null,
        },
        messageId: {
            type: String,
            default: null,
            maxlength: 500,
        },
    },
    {
        timestamps: true,
        versionKey: false,
        minimize: false,
    },
);

emailJobSchema.index({ status: 1, nextAttemptAt: 1, createdAt: 1 });
emailJobSchema.index({ status: 1, lockedAt: 1 });

const EmailJob =
    mongoose.models.EmailDeliveryJob ||
    mongoose.model("EmailDeliveryJob", emailJobSchema);

function encryptionKey() {
    const secret = env?.jwt?.refresh?.secret;
    if (!secret) {
        throw new Error("JWT refresh secret is required for email job encryption.");
    }

    return crypto
        .createHash("sha256")
        .update(`argus-email-job:${secret}`)
        .digest();
}

function encryptPayload(value) {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey(), iv);
    const plaintext = Buffer.from(JSON.stringify(value), "utf8");
    const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
    const authTag = cipher.getAuthTag();

    return [iv, authTag, ciphertext].map((part) => part.toString("base64url")).join(".");
}

function decryptPayload(value) {
    const [ivBase64, authTagBase64, ciphertextBase64] = String(value || "").split(".");
    if (!ivBase64 || !authTagBase64 || !ciphertextBase64) {
        throw new Error("Email queue payload is invalid.");
    }

    const decipher = crypto.createDecipheriv(
        "aes-256-gcm",
        encryptionKey(),
        Buffer.from(ivBase64, "base64url"),
    );
    decipher.setAuthTag(Buffer.from(authTagBase64, "base64url"));

    const plaintext = Buffer.concat([
        decipher.update(Buffer.from(ciphertextBase64, "base64url")),
        decipher.final(),
    ]);

    return JSON.parse(plaintext.toString("utf8"));
}

function safeError(error) {
    const message = error?.message || "Unable to send vendor invitation email.";
    return String(message).slice(0, 1900);
}

function retryDelayMs(attempt) {
    const base = Math.max(1000, Number(emailConfig.queueRetryBaseDelayMs || 15000));
    const exponent = Math.max(0, Math.min(Number(attempt || 1) - 1, 6));
    const jitter = Math.floor(Math.random() * Math.max(1000, Math.floor(base * 0.25)));
    return Math.min(15 * 60 * 1000, base * 2 ** exponent + jitter);
}

async function markInvitationState(userId, values) {
    if (!userId) return;

    await User.findByIdAndUpdate(
        userId,
        {
            $set: Object.fromEntries(
                Object.entries({
                    "vendorPortalOnboarding.invitationSentAt": values.sentAt,
                    "vendorPortalOnboarding.invitationSentTo": values.sentTo,
                    "vendorPortalOnboarding.invitationLastError": values.error || "",
                }).filter(([, value]) => value !== undefined),
            ),
        },
        { runValidators: true },
    );
}

export async function enqueueVendorInvitation({
    vendor,
    account,
    actorUserId = null,
    isResend = false,
    isTemporaryPassword = true,
    previousPasswordHash = null,
    previousPasswordChangedAt = null,
}) {
    const password = String(account?.password ?? account?.temporaryPassword ?? "").trim();

    if (!account?.userId || !account?.email || !password) {
        throw new Error("Vendor invitation queue payload is incomplete.");
    }

    const maxAttempts = Math.max(1, Number(emailConfig.maxRetries || 0) + 1);

    const payload = {
        vendorId: String(vendor?._id || ""),
        vendorName: vendor?.companyName || "Vendor",
        userId: String(account.userId),
        email: String(account.email).trim().toLowerCase(),
        displayName: account.displayName || "Vendor Admin",
        password,
        isTemporaryPassword,
        isResend,
        actorUserId: actorUserId ? String(actorUserId) : null,
        previousPasswordHash: previousPasswordHash || null,
        previousPasswordChangedAt: previousPasswordChangedAt
            ? new Date(previousPasswordChangedAt).toISOString()
            : null,
    };

    const job = await EmailJob.create({
        type: QUEUE_NAME,
        status: "queued",
        payload: encryptPayload(payload),
        attempts: 0,
        maxAttempts,
        nextAttemptAt: new Date(),
    });

    return {
        jobId: String(job._id),
        queuedAt: job.createdAt,
    };
}

async function claimJob() {
    const now = new Date();
    const staleBefore = new Date(now.getTime() - emailConfig.queueLeaseMs);

    return EmailJob.findOneAndUpdate(
        {
            type: QUEUE_NAME,
            $or: [
                {
                    status: "queued",
                    nextAttemptAt: { $lte: now },
                },
                {
                    status: "processing",
                    lockedAt: { $lte: staleBefore },
                },
            ],
        },
        {
            $set: {
                status: "processing",
                lockedAt: now,
                lockedBy: WORKER_ID,
                lastError: "",
            },
            $inc: {
                attempts: 1,
            },
        },
        {
            sort: { nextAttemptAt: 1, createdAt: 1 },
            new: true,
        },
    ).lean();
}

async function rollbackPassword(payload) {
    if (!payload.isResend || !payload.previousPasswordHash) {
        return;
    }

    await User.findByIdAndUpdate(
        payload.userId,
        {
            $set: {
                passwordHash: payload.previousPasswordHash,
                passwordChangedAt: payload.previousPasswordChangedAt
                    ? new Date(payload.previousPasswordChangedAt)
                    : null,
                ...(payload.actorUserId ? { updatedBy: payload.actorUserId } : {}),
            },
        },
        { runValidators: false },
    );
}

async function applyResendPassword(payload) {
    if (!payload.isResend) return;

    await userManagementService.resetPassword({
        userId: payload.userId,
        password: payload.password,
        updatedBy: payload.actorUserId || null,
    });
}

function isRetryableEmailError(error) {
    const code = String(error?.code || "").toUpperCase();
    return !new Set([
        "EMAIL_NOT_CONFIGURED",
        "EMAIL_RECIPIENT_REQUIRED",
        "EMAIL_PASSWORD_REQUIRED",
        "EAUTH",
        "EENVELOPE",
        "EINVALIDEMAIL",
    ]).has(code);
}

async function recordJobFailure(job, payload, error) {
    const errorMessage = safeError(error);
    const shouldRetry =
        isRetryableEmailError(error) &&
        Number(job.attempts || 0) < Number(job.maxAttempts || 1);
    const nextAttemptAt = shouldRetry
        ? new Date(Date.now() + retryDelayMs(job.attempts))
        : null;

    if (payload?.userId) {
        try {
            await markInvitationState(payload.userId, {
                sentAt: null,
                sentTo: payload.email,
                error: shouldRetry
                    ? `Email delivery attempt ${job.attempts}/${job.maxAttempts} failed. Retrying automatically.`
                    : errorMessage,
            });
        } catch (stateError) {
            console.error("[emailQueue] invitation state update failed", {
                jobId: String(job._id),
                message: stateError?.message,
                code: stateError?.code,
            });
        }
    }

    await EmailJob.updateOne(
        { _id: job._id, status: "processing", lockedBy: WORKER_ID },
        shouldRetry
            ? {
                  $set: {
                      status: "queued",
                      nextAttemptAt,
                      lastError: errorMessage,
                  },
                  $unset: {
                      lockedAt: 1,
                      lockedBy: 1,
                  },
              }
            : {
                  $set: {
                      status: "failed",
                      nextAttemptAt: null,
                      lastError: errorMessage,
                  },
                  $unset: {
                      lockedAt: 1,
                      lockedBy: 1,
                  },
              },
    );

    console.error("[emailQueue] vendor invitation delivery failed", {
        jobId: String(job._id),
        attempts: job.attempts,
        maxAttempts: job.maxAttempts,
        retrying: shouldRetry,
        message: errorMessage,
        code: error?.code,
    });
}

async function processJob(job) {
    let payload = null;
    let passwordApplied = false;
    let emailDelivered = false;

    try {
        payload = decryptPayload(job.payload);

        if (payload.isResend) {
            await applyResendPassword(payload);
            passwordApplied = true;
        }

        const result = await sendVendorInvitation({
            to: payload.email,
            vendorName: payload.vendorName,
            displayName: payload.displayName,
            email: payload.email,
            password: payload.password,
            isTemporaryPassword: payload.isTemporaryPassword,
            isResend: payload.isResend,
        });
        emailDelivered = true;

        try {
            await markInvitationState(payload.userId, {
                sentAt: new Date(),
                sentTo: payload.email,
                error: "",
            });
        } catch (stateError) {
            // Email delivery already succeeded; do not roll back the new password
            // or retry the email just because the reporting field could not update.
            console.error("[emailQueue] invitation success state update failed", {
                jobId: String(job._id),
                message: stateError?.message,
                code: stateError?.code,
            });
        }

        try {
            await EmailJob.updateOne(
                { _id: job._id, status: "processing", lockedBy: WORKER_ID },
                {
                    $set: {
                        status: "succeeded",
                        sentAt: new Date(),
                        messageId: result.messageId || null,
                        lastError: "",
                    },
                    $unset: {
                        lockedAt: 1,
                        lockedBy: 1,
                    },
                },
            );
        } catch (jobStateError) {
            // The message is already delivered. The lease will allow another
            // worker to reconcile the job later without breaking the request path.
            console.error("[emailQueue] failed to finalize delivered email job", {
                jobId: String(job._id),
                message: jobStateError?.message,
                code: jobStateError?.code,
            });
        }
    } catch (error) {
        if (passwordApplied && !emailDelivered && payload?.isResend) {
            try {
                await rollbackPassword(payload);
            } catch (rollbackError) {
                console.error("[emailQueue] password rollback failed", {
                    jobId: String(job._id),
                    message: rollbackError?.message,
                    code: rollbackError?.code,
                });
            }
        }

        try {
            await recordJobFailure(job, payload, error);
        } catch (jobStateError) {
            console.error("[emailQueue] failed to record email job failure", {
                jobId: String(job._id),
                message: jobStateError?.message,
                code: jobStateError?.code,
            });
        }
    }
}

let workerTimer = null;
let workerBusy = false;
let activeDrainPromise = null;

async function drainQueue() {
    if (workerBusy || !emailConfig.queueEnabled || !emailConfig.enabled) return;

    workerBusy = true;

    try {
        const jobs = [];

        for (let index = 0; index < emailConfig.queueConcurrency; index += 1) {
            const job = await claimJob();
            if (!job) break;
            jobs.push(job);
        }

        if (jobs.length) {
            await Promise.all(jobs.map((job) => processJob(job)));
        }
    } catch (error) {
        console.error("[emailQueue] worker cycle failed", {
            message: error?.message,
            code: error?.code,
        });
    } finally {
        workerBusy = false;
    }
}

function triggerDrain() {
    if (activeDrainPromise) return activeDrainPromise;

    activeDrainPromise = drainQueue().finally(() => {
        activeDrainPromise = null;
    });

    return activeDrainPromise;
}

export function startVendorInvitationEmailWorker() {
    if (!emailConfig.queueEnabled || !emailConfig.enabled || workerTimer) return;

    void triggerDrain();
    workerTimer = setInterval(() => {
        void triggerDrain();
    }, emailConfig.queuePollIntervalMs);
    workerTimer.unref?.();

    console.info("[emailQueue] vendor invitation worker started", {
        workerId: WORKER_ID,
        concurrency: emailConfig.queueConcurrency,
        pollIntervalMs: emailConfig.queuePollIntervalMs,
        maxAttempts: Math.max(1, Number(emailConfig.maxRetries || 0) + 1),
    });
}

export async function stopVendorInvitationEmailWorker() {
    if (workerTimer) {
        clearInterval(workerTimer);
        workerTimer = null;
    }

    if (activeDrainPromise) {
        await activeDrainPromise;
    }
}

export async function getVendorInvitationEmailJob(jobId) {
    if (!mongoose.Types.ObjectId.isValid(String(jobId))) return null;

    return EmailJob.findOne({
        _id: jobId,
        type: QUEUE_NAME,
    })
        .select("_id status attempts maxAttempts nextAttemptAt lastError sentAt messageId createdAt updatedAt")
        .lean();
}
