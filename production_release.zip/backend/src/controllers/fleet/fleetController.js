import * as service from "../../services/fleet/fleetService.js";

const actor = (req) => req?.user ? {
  userId: req.user.id || req.user._id,
  userType: req.user.userType,
  role: req.user.role || req.user.roleKey || req.user.roleName,
  roleId: req.user.roleId,
  vendorId: req.user.vendorId,
  actor: req.user,
} : {};
const request = (req) => ({ ipAddress: req?.ip, headers: req?.headers, get: req?.get?.bind(req) });
function sendError(res, error) {
  if (error instanceof service.FleetServiceError) return res.status(error.statusCode || 400).json({ success: false, message: error.message, code: error.code, ...(error.details ? { details: error.details } : {}) });
  if (error?.name === "ValidationError") return res.status(422).json({ success: false, message: "Fleet data is invalid.", code: "FLEET_VALIDATION_FAILED", fields: Object.fromEntries(Object.entries(error.errors || {}).map(([k, v]) => [k, v?.message || "Invalid value."])) });
  if (error?.code === 11000) return res.status(409).json({ success: false, message: "A fleet code, registration number or reference already exists.", code: "FLEET_DUPLICATE" });
  console.error("[fleetController]", error);
  return res.status(error?.statusCode || 500).json({ success: false, message: error?.message || "An unexpected fleet management error occurred.", code: error?.code || "INTERNAL_SERVER_ERROR" });
}
const wrap = (fn, status = 200) => async (req, res) => { try { return res.status(status).json({ success: true, data: await fn(req) }); } catch (error) { return sendError(res, error); } };
export const listVehicles = wrap((req) => service.listVehicles({ actor: actor(req), ...req.query }));
export const createVehicle = wrap((req) => service.createVehicle(req.body || {}, actor(req), request(req)), 201);
export const updateVehicle = wrap((req) => service.updateVehicle(req.params.id, req.body || {}, actor(req), request(req)));
export const deleteVehicle = wrap((req) => service.deleteVehicle(req.params.id, actor(req), request(req)));
export const listRequisitions = wrap((req) => service.listRequisitions({ actor: actor(req), ...req.query }));
export const createRequisition = wrap((req) => service.createRequisition(req.body || {}, actor(req), request(req)), 201);
export const updateRequisitionAction = wrap((req) => service.updateRequisitionAction(req.params.id, req.body || {}, actor(req), request(req)));
export const listClaims = wrap((req) => service.listClaims({ actor: actor(req), ...req.query }));
export const createClaim = wrap((req) => service.createClaim(req.body || {}, actor(req), request(req), req.file || null), 201);
export async function getClaimAttachment(req, res) {
  try {
    const result = await service.getClaimAttachment(req.params.id, actor(req));
    res.setHeader("Content-Type", result.attachment?.mimeType || "application/octet-stream");
    res.setHeader("Content-Length", String(result.stream.size));
    res.setHeader("Content-Disposition", `attachment; filename="${String(result.attachment?.originalName || "fleet-claim-evidence").replace(/[\"\r\n]/g, "")}"`);
    return result.stream.stream.pipe(res);
  } catch (error) { return sendError(res, error); }
}
export const updateClaimStatus = wrap((req) => service.updateClaimStatus(req.params.id, req.body || {}, actor(req), request(req)));
export const getSettings = wrap((req) => service.getFleetSettings(actor(req)));
export const updateSettings = wrap((req) => service.updateFleetSettings(req.body || {}, actor(req), request(req)));
export default { listVehicles, createVehicle, updateVehicle, deleteVehicle, listRequisitions, createRequisition, updateRequisitionAction, listClaims, createClaim, updateClaimStatus, getSettings, updateSettings };
