import nodemailer from "nodemailer";
import env from "./env.js";

const config = env?.email ?? {};
const smtp = config.smtp ?? {};

export const mailer =
    smtp.host && config.enabled !== false
        ? nodemailer.createTransport({
              host: smtp.host,
              port: smtp.port,
              secure: smtp.secure,
              auth: smtp.user
                  ? {
                        user: smtp.user,
                        pass: smtp.password,
                    }
                  : undefined,
              connectionTimeout: config.smtp?.connectionTimeoutMs,
              greetingTimeout: config.smtp?.greetingTimeoutMs,
              socketTimeout: config.smtp?.socketTimeoutMs,
              dnsTimeout: config.smtp?.dnsTimeoutMs,
          })
        : null;

export const emailConfig = Object.freeze({
    enabled: config.enabled === true,
    from: {
        name: config.from?.name || "ARGUS",
        email: config.from?.email || "",
    },
    queueEnabled: config.queueEnabled === true,
    maxRetries: Number(config.maxRetries || 0),
    queuePollIntervalMs: Number(config.queuePollIntervalMs || 2000),
    queueConcurrency: Number(config.queueConcurrency || 2),
    queueRetryBaseDelayMs: Number(config.queueRetryBaseDelayMs || 15000),
    queueLeaseMs: Number(config.queueLeaseMs || 120000),
});
