// src/scripts/backfillMasterRateReferences.js

import {
    connectDatabase,
    disconnectDatabase,
} from "../config/database.js";

import MarketRateItem from "../models/MarketRateItem.js";
import RateCategory from "../models/RateCategory.js";
import Unit from "../models/Unit.js";

/*
 * One-time production migration for the Master Rate reference model.
 *
 * Repairs legacy documents by:
 *   - copying subcategory -> module when module is empty
 *   - resolving category_id from categoryType + category
 *   - resolving unit_id from unit name
 *   - removing the legacy subcategory field
 *
 * Run once against the production database after deploying the new schema.
 */

function key(value) {
    return String(value ?? "").trim().toLowerCase();
}

async function run() {
    await connectDatabase();

    const [categories, units] = await Promise.all([
        RateCategory.find({})
            .select("_id categoryType category")
            .lean(),
        Unit.find({})
            .select("_id name")
            .lean(),
    ]);

    const categoryMap = new Map(
        categories.map((row) => [
            `${key(row.categoryType)}|${key(row.category)}`,
            row._id,
        ]),
    );

    const unitMap = new Map(
        units.map((row) => [key(row.name), row._id]),
    );

    const cursor = MarketRateItem.find({}).cursor();
    let scanned = 0;
    let updated = 0;
    let unresolved = 0;
    const operations = [];

    for await (const row of cursor) {
        scanned += 1;

        const moduleName =
            String(row.module || row.subcategory || "").trim();
        const categoryId =
            row.category_id ||
            categoryMap.get(
                `${key(row.categoryType)}|${key(row.category)}`,
            ) ||
            null;
        const unitId =
            row.unit_id ||
            unitMap.get(key(row.unit)) ||
            null;

        if (!moduleName || !categoryId || !unitId) {
            unresolved += 1;
            console.warn(
                `[MASTER-RATE-REF-BACKFILL] Unresolved ${row.code}: module=${Boolean(moduleName)} category_id=${Boolean(categoryId)} unit_id=${Boolean(unitId)}`,
            );
            continue;
        }

        operations.push({
            updateOne: {
                filter: { _id: row._id },
                update: {
                    $set: {
                        module: moduleName,
                        category_id: categoryId,
                        unit_id: unitId,
                    },
                    $unset: {
                        subcategory: "",
                    },
                },
            },
        });

        if (operations.length >= 500) {
            const result =
                await MarketRateItem.bulkWrite(operations, {
                    ordered: false,
                });
            updated += result.modifiedCount;
            operations.length = 0;
        }
    }

    if (operations.length) {
        const result =
            await MarketRateItem.bulkWrite(operations, {
                ordered: false,
            });
        updated += result.modifiedCount;
    }

    console.info(
        `[MASTER-RATE-REF-BACKFILL] Scanned=${scanned} Updated=${updated} Unresolved=${unresolved}`,
    );
}

try {
    await run();
    console.info(
        "[MASTER-RATE-REF-BACKFILL] Completed successfully.",
    );
} catch (error) {
    console.error(
        "[MASTER-RATE-REF-BACKFILL] Migration failed:",
        error,
    );
    process.exitCode = 1;
} finally {
    await disconnectDatabase().catch((error) => {
        console.error(
            "[MASTER-RATE-REF-BACKFILL] Database disconnect failed:",
            error,
        );
    });
}
