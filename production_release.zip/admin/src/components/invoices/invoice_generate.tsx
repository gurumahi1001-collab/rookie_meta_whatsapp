import {
    ArrowLeftIcon,
    CheckCircleIcon,
    CheckIcon,
    FileTextIcon,
    PencilSimpleIcon,
    XIcon,
} from "@phosphor-icons/react";
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import Select from "react-select";
import { createInvoice, getInvoiceCreationContext } from "../../api/invoiceApi";

// ============================================================
// TYPES
// ============================================================
interface ApprovedQuotation {
    id: string;
    quotationId?: string;
    projectId?: string;
    quotationNo: string;
    projectTitle: string;
    vendor: string;
    vendorId?: string;
    contractValue: number;
    currency: string;
    status: string;
    siteReference?: string;
    dueDate?: string;
}

interface InvoiceGenerateLocationState {
    quotation?: ApprovedQuotation;
}

type ModuleItem = {
    id: number;
    name: string;
    rate: number;
};

type VerificationTask = {
    id: number;
    name: string;
    description: string;
    estimatedHours: number;
    status: string;
    progress: number;
    priority: string;
};

type InstallmentData = {
    id: number;
    name: string;
    days: number;
    netTotalAmount: number;
    moduleItems: ModuleItem[];
    dueDate?: string | null;
    invoiced?: boolean;
    paid?: boolean;
    available?: boolean;
    status?: string;
};

// ============================================================
// STATIC DATA
// ============================================================
const currencyOptions = [
    { value: "USD", label: "USD" },
    { value: "JMD", label: "JMD" },
    
];

// ============================================================
// COMPONENT
// ============================================================
const InvoiceGenerate = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const state = location.state as InvoiceGenerateLocationState | null;
    const quotation = state?.quotation;

    // ----- Invoice Config State -----
    const [invoiceNumber, setInvoiceNumber] = useState("Auto-generated");
    const [currency, setCurrency] = useState(quotation?.currency || "USD");
    const [dueDate, setDueDate] = useState("");
    const [siteReference, setSiteReference] = useState(quotation?.siteReference || "");
    const [tax, setTax] = useState(15);
    const [invoiceDocument, setInvoiceDocument] = useState<File | null>(null);
    const [contextLoading, setContextLoading] = useState(false);
    const [dynamicInstallments, setDynamicInstallments] = useState<InstallmentData[]>([]);
    const [dynamicVerificationTasks, setDynamicVerificationTasks] = useState<VerificationTask[]>([]);

    // ----- Installment Selection State -----
    // Select only installments that are still available to invoice.
    const [selectedInstallments, setSelectedInstallments] = useState<number[]>([]);

    const [remarks, setRemarks] = useState("");
    const invoiceAmount = dynamicInstallments
        .filter((installment) => selectedInstallments.includes(installment.id))
        .reduce((total, installment) => total + installment.netTotalAmount, 0);

    const toDateInput = (value: unknown) => {
        if (!value) return "";
        const date = new Date(String(value));
        if (Number.isNaN(date.getTime())) return "";
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
    };

    useEffect(() => {
        let active = true;
        const quotationId = quotation?.quotationId || quotation?.id;
        if (!quotationId) return () => { active = false; };

        setContextLoading(true);
        getInvoiceCreationContext(quotationId)
            .then((context: any) => {
                if (!active) return;

                const sourceQuotation = context?.quotation ?? {};
                const project = context?.project ?? {};
                const schedule = Array.isArray(context?.paymentSchedule) ? context.paymentSchedule : [];
                const baseDate = new Date(sourceQuotation?.createdAt ?? sourceQuotation?.quotationDate ?? Date.now());

                const mappedSchedule: InstallmentData[] = schedule.map((item: any, index: number) => {
                    const due = item?.dueDate ? new Date(item.dueDate) : null;
                    const days = due && !Number.isNaN(due.getTime()) && !Number.isNaN(baseDate.getTime())
                        ? Math.max(0, Math.round((due.getTime() - baseDate.getTime()) / 86400000))
                        : 0;
                    const moduleRows = Array.isArray(context?.moduleItems) ? context.moduleItems : [];
                    return {
                        id: index + 1,
                        name: String(item?.name || `Installment ${index + 1}`),
                        days,
                        netTotalAmount: Number(item?.amount ?? 0),
                        dueDate: item?.dueDate ?? null,
                        invoiced: Boolean(item?.invoiced),
                        paid: Boolean(item?.paid),
                        available: item?.available !== false,
                        status: String(item?.status || "Pending"),
                        moduleItems: moduleRows.map((module: any, moduleIndex: number) => ({
                            id: (index + 1) * 100 + moduleIndex + 1,
                            name: String(module?.name || "Module Item"),
                            rate: Number(module?.rate ?? 0),
                        })),
                    };
                });

                setDynamicInstallments(mappedSchedule);
                setSelectedInstallments([]);
                setCurrency(String(sourceQuotation?.currency || project?.currency || quotation?.currency || "USD"));
                setSiteReference(String(project?.location || sourceQuotation?.projectSiteLocation || quotation?.siteReference || ""));

                const firstAvailable = mappedSchedule.find((item) => item.available && !item.invoiced && !item.paid);
                const fallbackDue = sourceQuotation?.dueDate || project?.endDate || quotation?.dueDate;
                setDueDate(toDateInput(firstAvailable?.dueDate || fallbackDue));

                const taskRows = Array.isArray(context?.tasks) ? context.tasks : [];
                setDynamicVerificationTasks(taskRows.map((task: any, index: number) => ({
                    id: index + 1,
                    name: String(task?.title || task?.name || `Task ${index + 1}`),
                    description: String(task?.description || "Project task verification."),
                    estimatedHours: Number(task?.estimatedHours || 0),
                    status: String(task?.status || "Pending"),
                    progress: Number(task?.progress || 0),
                    priority: String(task?.priority || "Medium"),
                })));
            })
            .catch((error: any) => {
                if (!active) return;
                window.alert(error?.response?.data?.message || "Unable to load invoice configuration.");
            })
            .finally(() => {
                if (active) setContextLoading(false);
            });

        return () => { active = false; };
    }, [quotation?.id, quotation?.quotationId, quotation?.currency, quotation?.siteReference]);

    // ============================================================
    // HELPERS
    // ============================================================
    const formatCurrency = (value: number) =>
        value.toLocaleString("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        });

    const handleDocumentUpload = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        const file = event.target.files?.[0];
        if (file) setInvoiceDocument(file);
    };

    const handleCancel = () => {
        navigate("/invoices", {
            state: { activeTab: "approvedQuotes" },
        });
    };

    // ----- Installment toggle -----
    const handleInstallmentChange = (installmentId: number) => {
        setSelectedInstallments((prev) => {
            if (prev.includes(installmentId)) {
                return prev.filter((id) => id !== installmentId);
            }

            return [...prev, installmentId];
        });
    };


    // ============================================================
    // SAVE / SUBMIT
    // ============================================================
    const buildInvoicePayload = (status: "Draft" | "Submitted") => ({
        quotationId: quotation?.quotationId || quotation?.id,
        projectId: quotation?.projectId,
        currency,
        status,
        dueDate,
        siteReference,
        milestoneName: dynamicInstallments.filter((item) => selectedInstallments.includes(item.id)).map((item) => item.name).join(", "),
        installmentIndexes: selectedInstallments.map((id) => id - 1),
        subtotal: invoiceAmount,
        taxRatePercent: tax,
        remarks,
    });

    const handleSaveDraft = async () => {
        if (!quotation) {
            navigate("/invoices");
            return;
        }

        if (selectedInstallments.length === 0) {
            window.alert("Select at least one pending installment before saving the invoice.");
            return;
        }

        try {
            const created = await createInvoice(buildInvoicePayload("Draft"), invoiceDocument);
            setInvoiceNumber(String(created?.invoiceNo || created?.id || "Auto-generated"));
            navigate("/invoices");
        } catch (error: any) {
            window.alert(error?.response?.data?.message || "Unable to save the invoice draft.");
        }
    };

    const handleSubmitInvoice = async () => {
        if (!quotation) {
            navigate("/invoices");
            return;
        }

        if (selectedInstallments.length === 0) {
            window.alert("Select at least one pending installment before generating the invoice.");
            return;
        }

        try {
            const created = await createInvoice(buildInvoicePayload("Submitted"), invoiceDocument);
            setInvoiceNumber(String(created?.invoiceNo || created?.id || "Auto-generated"));
            navigate("/invoices", { state: { invoiceSubmitted: true } });
        } catch (error: any) {
            window.alert(error?.response?.data?.message || "Unable to generate the invoice.");
        }
    };

    // ============================================================
    // EARLY RETURN: No Quotation
    // ============================================================
    if (!quotation) {
        return (
            <div className="flex min-h-[500px] items-center justify-center bg-slate-50">
                <div className="text-center">
                    <p className="text-sm font-semibold text-slate-700">
                        No quotation selected.
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                        Please select an approved quotation before generating an
                        invoice.
                    </p>
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="mb-3 mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 transition-colors hover:text-red-600"
                    >
                        <ArrowLeftIcon size={14} />
                        Back to Invoice List
                    </button>
                </div>
            </div>
        );
    }

    // ============================================================
    // RENDER
    // ============================================================
    return (
        <div className="min-h-screen bg-slate-50">
            <div className="mx-auto px-2 py-3">
                {/* ================= HEADER ================= */}
                <div className="mb-6">
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="mb-3 inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-red-600"
                    >
                        <ArrowLeftIcon size={14} />
                        Back to Invoice List
                    </button>

                    <h1 className="text-xl font-bold text-slate-900">
                        Invoice Configuration
                    </h1>

                    <p className="mt-1 text-xs text-slate-500">
                        Generating invoice for{" "}
                        <span className="font-semibold text-slate-700">
                            {quotation.projectTitle}
                        </span>{" "}
                        ({quotation.quotationNo})
                    </p>
                </div>

                {/* ================= INVOICE CONFIG ================= */}
                <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    {/* Header */}
                    <div className="border-b border-slate-100 px-6 py-4">
                        <h2 className="text-sm font-bold text-slate-800">
                            Invoice Configuration
                        </h2>
                    </div>

                    {/* Form */}
                    <div className="grid grid-cols-1 gap-x-5 gap-y-5 p-6 md:grid-cols-3">

                        {/* Invoice Number */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Invoice Number
                            </label>

                            <input
                                type="text"
                                value={invoiceNumber}
                                disabled
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-100 px-3 text-sm font-semibold text-slate-600 outline-none"
                            />
                        </div>

                        {/* Vendor */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Vendor
                            </label>

                            <input
                                type="text"
                                value={quotation.vendor}
                                disabled
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-100 px-3 text-sm font-semibold text-slate-600 outline-none"
                            />
                        </div>

                        {/* Currency */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Currency
                            </label>

                            <Select
                                value={
                                    currencyOptions.find(
                                        (option) => option.value === currency
                                    ) ?? null
                                }
                                onChange={(option) =>
                                    setCurrency(option?.value ?? "USD")
                                }
                                options={currencyOptions}
                                isSearchable={false}
                                className="text-sm"
                                classNamePrefix="currency-select"
                                styles={{
                                    control: (base, state) => ({
                                        ...base,
                                        minHeight: "42px",
                                        height: "42px",
                                        borderRadius: "8px",
                                        borderColor: state.isFocused
                                            ? "#fca5a5"
                                            : "#e2e8f0",
                                        backgroundColor: state.isFocused
                                            ? "#ffffff"
                                            : "#f8fafc",
                                        boxShadow: "none",
                                        "&:hover": {
                                            borderColor: "#fca5a5",
                                        },
                                    }),
                                    valueContainer: (base) => ({
                                        ...base,
                                        height: "42px",
                                        padding: "0 12px",
                                    }),
                                    indicatorsContainer: (base) => ({
                                        ...base,
                                        height: "42px",
                                    }),
                                    singleValue: (base) => ({
                                        ...base,
                                        fontSize: "13px",
                                        color: "#334155",
                                    }),
                                    placeholder: (base) => ({
                                        ...base,
                                        fontSize: "13px",
                                        color: "#94a3b8",
                                    }),
                                    option: (base, state) => ({
                                        ...base,
                                        fontSize: "13px",
                                        color: "#334155",
                                        backgroundColor: state.isSelected
                                            ? "#fee2e2"
                                            : state.isFocused
                                                ? "#fef2f2"
                                                : "#ffffff",
                                        cursor: "pointer",
                                    }),
                                    menu: (base) => ({
                                        ...base,
                                        zIndex: 50,
                                    }),
                                }}
                            />
                        </div>

                        {/* Due Date */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Due Date
                            </label>

                            <input
                                type="date"
                                value={dueDate}
                                onChange={(event) =>
                                    setDueDate(event.target.value)
                                }
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                            />
                        </div>

                        {/* Site Reference */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Site Reference
                            </label>

                            <input
                                type="text"
                                value={siteReference}
                                disabled
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-100 px-3 text-sm font-semibold text-slate-600 outline-none"
                            />
                        </div>


                        {/* Invoice Amount */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Invoice Amount
                            </label>

                            <div className="relative">
                                <span className="absolute left-3 top-1/2 z-10 -translate-y-1/2 text-xs font-semibold text-slate-400">
                                    {currency}
                                </span>

                                <input
                                    type="number"
                                    value={invoiceAmount}
                                    readOnly
                                    placeholder="Enter amount"
                                    className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-12 pr-3 text-sm font-semibold text-slate-700 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                                />
                            </div>
                        </div>

                        {/* Tax */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Tax (%)
                            </label>

                            <input
                                type="number"
                                min={0}
                                max={100}
                                value={tax}
                                onChange={(event) =>
                                    setTax(Number(event.target.value))
                                }
                                className="h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                            />
                        </div>

                        {/* Supporting Document */}
                        <div className="min-w-0">
                            <label className="mb-1.5 block text-xs font-semibold text-slate-700">
                                Supporting Document
                            </label>

                            <input
                                type="file"
                                onChange={handleDocumentUpload}
                                className="block h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600 file:mr-3 file:rounded-md file:border-0 file:bg-red-50 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-red-600"
                            />

                            {invoiceDocument && (
                                <p className="mt-2 text-[10px] font-medium text-emerald-600">
                                    Selected: {invoiceDocument.name}
                                </p>
                            )}
                        </div>

                        {/* Remarks */}
                        <div className="min-w-0">
                            <label
                                htmlFor="remarks"
                                className="mb-1.5 block text-xs font-semibold text-slate-700"
                            >
                                Remarks
                            </label>

                            <textarea
                                id="remarks"
                                rows={3}
                                value={remarks}
                                onChange={(e) => setRemarks(e.target.value)}
                                placeholder="Enter remarks..."
                                className="w-full resize-none rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 placeholder:text-slate-400 outline-none transition focus:border-primary focus:ring-1 focus:ring-primary"
                            />
                        </div>


                    </div>
                </section>


                {/* ================= MILESTONE ALLOCATION ================= */}
                <section className="mt-5 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="border-b border-slate-100 px-6 py-4">
                        <h2 className="text-sm font-bold text-slate-800">
                            Overall Milestone Allocation
                        </h2>
                        <p className="mt-1 text-xs text-slate-500">
                            Select the project phase, module, and percentage of
                            the approved contract value to invoice.
                        </p>
                    </div>



                    {/* ============================================================
                        INSTALLMENT ITEMS
                    ============================================================ */}
                    <div className="border-t border-slate-200">
                        <div className="border-b border-slate-100 px-6 py-4">
                            <h2 className="text-sm font-bold text-slate-800">
                                Installment Items
                            </h2>
                            <p className="mt-1 text-xs text-slate-500">
                                Select one or more available installments to include in this invoice. Paid or already invoiced installments are unavailable.
                            </p>
                        </div>

                        <div className="p-6">
                            {/* Installment List Table */}
                            <div className="overflow-hidden rounded-lg border border-slate-200">
                                {/* Header */}
                                <div className="grid grid-cols-[50px_1.5fr_1fr_1.5fr_1.5fr_2fr] items-center gap-4 bg-slate-50 px-4 py-3 text-xs font-bold uppercase tracking-wide text-slate-500">
                                    <div></div>
                                    <div>Installment Name</div>
                                    <div>Days</div>
                                    <div>Total Amount</div>
                                    <div>Action</div>
                                    <div>Module Items</div>
                                </div>

                                {/* Rows */}
                                {dynamicInstallments.map((installment, index) => {
                                    const isPaid = Boolean(installment.paid);
                                    const isInvoiced = Boolean(installment.invoiced);
                                    const isUnavailable = isInvoiced || isPaid || installment.available === false;
                                    const isChecked = selectedInstallments.includes(installment.id);

                                    return (
                                        <div
                                            key={installment.id}
                                            className={`grid grid-cols-[50px_1.5fr_1fr_1.5fr_1.5fr_2fr] items-center gap-4 border-t border-slate-100 px-4 py-4 transition-colors ${isChecked
                                                ? "bg-primary/5"
                                                : "bg-white hover:bg-slate-50"
                                                }`}
                                        >
                                            {/* Checkbox */}
                                            <div>
                                                <input
                                                    type="checkbox"
                                                    checked={isChecked}
                                                    disabled={isUnavailable}
                                                    onChange={() => {
                                                        if (!isUnavailable) {
                                                            handleInstallmentChange(
                                                                installment.id
                                                            );
                                                        }
                                                    }}
                                                    className={`h-4 w-4 rounded border-slate-300 text-primary focus:ring-primary ${isUnavailable
                                                        ? "cursor-not-allowed opacity-60"
                                                        : "cursor-pointer"
                                                        }`}
                                                />
                                            </div>

                                            {/* Name */}
                                            <div>
                                                <p className="text-sm font-semibold text-slate-800">
                                                    {installment.name}
                                                </p>

                                            </div>

                                            {/* Days */}
                                            <div className="text-sm text-slate-600">
                                                {installment.days} Days
                                            </div>

                                            {/* Net Total */}
                                            <div className="text-sm font-bold text-red-600">
                                                {currency}{" "}
                                                {formatCurrency(
                                                    installment.netTotalAmount
                                                )}
                                            </div>

                                            {/* Action */}
                                            <div>
                                                {isUnavailable ? (
                                                    <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${isPaid ? "bg-green-100 text-green-700" : "bg-slate-100 text-slate-500"}`}>
                                                        {isPaid ? "Paid" : isInvoiced ? "Already Invoiced" : "Unavailable"}
                                                    </span>
                                                ) : (
                                                    <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${isChecked ? "bg-primary/10 text-primary" : "bg-slate-100 text-slate-500"}`}>
                                                        {isChecked ? "Selected" : "Available"}
                                                    </span>
                                                )}
                                            </div>

                                            {/* Module Items */}
                                            <div className="flex flex-wrap gap-2">
                                                {installment.moduleItems.map(
                                                    (item) => (
                                                        <span
                                                            key={item.id}
                                                            className="rounded-md bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600"
                                                        >
                                                            {item.name}
                                                        </span>
                                                    )
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>

                            {/* ============================================================
                                SELECTED INSTALLMENTS (SEPARATE)
                            ============================================================ */}
                            {selectedInstallments.length > 0 && (
                                <div className="mt-6">
                                    <div className="mb-4">
                                        <h3 className="text-sm font-bold text-slate-800">
                                            Selected Installments
                                        </h3>
                                        <p className="mt-1 text-xs text-slate-500">
                                            Details of the selected installments
                                            are displayed separately below.
                                        </p>
                                    </div>

                                    <div className="space-y-4">
                                        {dynamicInstallments.filter((installment) =>
                                            selectedInstallments.includes(installment.id)
                                        ).map((installment) => (
                                            <div
                                                key={installment.id}
                                                className="overflow-hidden rounded-lg border border-slate-200 bg-white"
                                            >
                                                {/* Header */}
                                                <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-5 py-4">
                                                    <div>
                                                        <div className="flex items-center gap-2">
                                                            <h4 className="text-sm font-bold text-slate-800">
                                                                {
                                                                    installment.name
                                                                }
                                                            </h4>
                                                            <span className="rounded-full bg-primary/10 px-2.5 py-1 text-[10px] font-semibold text-primary">
                                                                Selected
                                                            </span>
                                                        </div>
                                                        <p className="mt-1 text-xs text-slate-500">
                                                            {installment.days}{" "}
                                                            Days
                                                        </p>
                                                    </div>

                                                    <div className="text-right">
                                                        <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                                                            Total
                                                        </p>
                                                        <p className="text-sm font-bold text-red-600">
                                                            {currency}{" "}
                                                            {formatCurrency(
                                                                installment.netTotalAmount
                                                            )}
                                                        </p>
                                                    </div>
                                                </div>

                                                {/* Module Items */}
                                                <div className="p-5">
                                                    <h5 className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-500">
                                                        Module Items
                                                    </h5>

                                                    <div className="overflow-hidden rounded-lg border border-slate-200">
                                                        {installment.moduleItems.map(
                                                            (item) => (
                                                                <div
                                                                    key={item.id}
                                                                    className="flex items-center justify-between border-b border-slate-100 px-4 py-3 last:border-b-0"
                                                                >
                                                                    <div>
                                                                        <p className="text-sm font-medium text-slate-700">
                                                                            {
                                                                                item.name
                                                                            }
                                                                        </p>
                                                                        <p className="mt-0.5 text-xs text-slate-400">
                                                                            Module
                                                                            Item
                                                                        </p>
                                                                    </div>
                                                                    <div className="text-sm font-bold text-slate-700">
                                                                        {currency}{" "}
                                                                        {formatCurrency(
                                                                            item.rate
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            )
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </section>

                {/* ================= TASKS VERIFICATION ================= */}
                <section className="mt-5 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5">
                        <div>
                            <h2 className="text-sm font-bold text-slate-800">
                                Tasks Verification
                            </h2>
                            <p className="mt-0.5 text-[11px] text-slate-500">
                                Review task progress and completion status.
                            </p>
                        </div>
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-1 text-[9px] font-bold text-emerald-700">
                            <CheckCircleIcon size={11} weight="fill" />
                            Verified
                        </span>
                    </div>

                    <div className="divide-y divide-slate-100">
                        {dynamicVerificationTasks.map((task) => {
                            const isCompleted = task.status === "Completed";

                            return (
                                <div
                                    key={task.id}
                                    className="flex items-center gap-3 px-5 py-3 transition hover:bg-slate-50"
                                >
                                    {/* Status Icon */}
                                    <div
                                        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${isCompleted
                                            ? "bg-emerald-500 text-white"
                                            : "border border-slate-300 bg-white"
                                            }`}
                                    >
                                        {isCompleted && (
                                            <CheckIcon size={12} weight="bold" />
                                        )}
                                    </div>

                                    {/* Info */}
                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-center gap-2">
                                            <h3
                                                className={`truncate text-xs font-semibold ${isCompleted
                                                    ? "text-slate-400 line-through"
                                                    : "text-slate-700"
                                                    }`}
                                            >
                                                {task.name}
                                            </h3>
                                            <span
                                                className={`shrink-0 rounded px-1.5 py-0.5 text-[8px] font-bold ${task.priority === "Urgent"
                                                    ? "bg-red-50 text-red-600"
                                                    : task.priority === "High"
                                                        ? "bg-orange-50 text-orange-600"
                                                        : task.priority ===
                                                            "Medium"
                                                            ? "bg-amber-50 text-amber-600"
                                                            : "bg-slate-100 text-slate-500"
                                                    }`}
                                            >
                                                {task.priority}
                                            </span>
                                        </div>

                                        {/* Progress Bar */}
                                        <div className="mt-1.5 flex items-center gap-2">
                                            <div className="h-1 flex-1 overflow-hidden rounded-full bg-slate-100">
                                                <div
                                                    className={`h-full rounded-full ${isCompleted
                                                        ? "bg-emerald-500"
                                                        : task.status ===
                                                            "In Progress"
                                                            ? "bg-blue-500"
                                                            : task.status ===
                                                                "On Hold"
                                                                ? "bg-amber-500"
                                                                : "bg-slate-300"
                                                        }`}
                                                    style={{
                                                        width: `${task.progress}%`,
                                                    }}
                                                />
                                            </div>
                                            <span className="w-7 text-right text-[9px] font-bold text-slate-500">
                                                {task.progress}%
                                            </span>
                                        </div>
                                    </div>

                                    {/* Status Badge */}
                                    <span
                                        className={`shrink-0 rounded-full px-2 py-0.5 text-[9px] font-semibold ${task.status === "Completed"
                                            ? "bg-emerald-50 text-emerald-700"
                                            : task.status === "In Progress"
                                                ? "bg-blue-50 text-blue-700"
                                                : task.status === "On Hold"
                                                    ? "bg-amber-50 text-amber-700"
                                                    : task.status === "Due Date"
                                                        ? "bg-red-50 text-red-700"
                                                        : "bg-slate-100 text-slate-600"
                                            }`}
                                    >
                                        {task.status}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </section>



                {/* ================= ACTIONS ================= */}
                <div className="mt-6 flex flex-col-reverse gap-3 border-t border-slate-200 pt-5 sm:flex-row sm:items-center sm:justify-end">
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="inline-flex h-10 items-center justify-center rounded-lg border border-slate-200 bg-white px-5 text-xs font-bold text-slate-600 transition-colors hover:bg-slate-50"
                    >
                        Cancel
                    </button>

                    <button
                        type="button"
                        onClick={handleSaveDraft}
                        disabled={contextLoading}
                        className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-5 text-xs font-bold text-slate-700 shadow-sm transition-colors hover:bg-slate-50"
                    >
                        <FileTextIcon size={15} weight="duotone" />
                        Save as Draft
                    </button>

                    <button
                        type="button"
                        onClick={handleSubmitInvoice}
                        disabled={contextLoading}
                        className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-red-600 px-5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-red-700"
                    >
                        <FileTextIcon size={15} weight="duotone" />
                        Generate Invoice
                    </button>
                </div>
            </div>
        </div>
    );
};

export default InvoiceGenerate;