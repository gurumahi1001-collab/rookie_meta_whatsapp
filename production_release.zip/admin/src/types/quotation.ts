export type QuotationViewMode = "grid" | "list";
export type WorkflowStage = "Draft" | "Submitted for Approval";

export type QuotationStatus =
    | "Form Issued"
    | "Form Submitted"
    | "Form Approved"
    | "Form Rejected"
    | "Issued"
    | "Draft"
    | "Not Responded"
    | "Submitted"
    | "Awarded"
    | "Rejected"
    | "Not Awarded";

export interface QuotationLineRecord {
    id?: string;
    boqLineId?: string | null;
    rateItemId?: string | null;
    module?: string;
    category?: string;
    description: string;
    unit: string;
    quantity: number;
    materialCost?: number;
    serviceCost?: number;
    quotedRate: number;
    masterRate?: number;
    taxRate?: number;
    lineSubtotal?: number;
    lineTax?: number;
    lineTotal?: number;
    sortOrder?: number;
}

export interface QuotationWorkflowHistoryEntry {
    status: QuotationStatus;
    statusCode?: string;
    comment: string;
    performedAt?: string;
    performedBy?: string | null;
}

export interface Quotation {
    id: string;
    quotationNo: string;
    vendor: string;
    vendorName: string;
    vendorEmail?: string;
    projectTitle: string;
    projectLocation?: string;
    date: string;
    grandTotal: number;
    currency: string;
    margin: number;
    status: QuotationStatus;
    statusCode?: string;
    category: string;
    items: number;
    progress: number;
    validUntil: string;
    createdDate: string;
    clientName: string;
    formTemplate: string;
    scopeSummary?: string;
    terms?: string;
    boqId?: string | null;
    boqReference?: string;
    surveyTemplateId?: string | null;
    surveyResponseId?: string | null;
    survey?: {
        id: string;
        status: string;
        statusLabel: string;
        issuedAt?: string | null;
        submittedAt?: string | null;
        approvedAt?: string | null;
        rejectionReason?: string;
        response: Record<string, unknown>;
        revision?: number;
        templateSnapshot?: Record<string, unknown> | null;
    } | null;
    formIssuedAt?: string | null;
    formSubmittedAt?: string | null;
    formApprovedAt?: string | null;
    rejectionStage?: string | null;
    rejectionReason?: string;
    masterRateComparison?: { checkedAt?: string; checkedBy?: string | null; variance?: number; withinTolerance?: boolean; notes?: string } | null;
    award?: { awardedAt?: string; awardedBy?: string | null; remarks?: string; } | null;
    lines?: QuotationLineRecord[];
    paymentSchedule?: { installments: Array<Record<string, unknown>> };
    subtotal?: number;
    taxTotal?: number;
    otherCharges?: number;
    workflowHistory?: QuotationWorkflowHistoryEntry[];
    submittedAt?: string | null;
    approvedAt?: string | null;
    rejectedAt?: string | null;
    awardedAt?: string | null;
    createdAt?: string;
    updatedAt?: string;
}

export interface QuotationPayload {
    reference?: string;
    vendorId: string;
    projectTitle: string;
    projectLocation?: string;
    clientName?: string;
    currency: string;
    quotationDate: string;
    validUntil: string;
    scopeSummary?: string;
    terms?: string;
    formTemplate?: string;
    category?: string;
    otherCharges?: number;
    lines: Array<{
        description: string;
        unit: string;
        quantity: number;
        materialCost?: number;
        serviceCost?: number;
        quotedRate: number;
        taxRate?: number;
        module?: string;
        category?: string;
        sortOrder?: number;
    }>;
    paymentSchedule?: { installments: Array<Record<string, unknown>> };
}

export interface QuotationStats {
    total: number;
    pending: number;
    approved: number;
    totalValue: number;
}

export interface QuotationFilterState {
    query: string;
    category: string;
    status: string;
    currency: string;
}
