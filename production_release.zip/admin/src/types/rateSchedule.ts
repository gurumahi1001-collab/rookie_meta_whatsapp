export type RateStatus = "active" | "inactive";

export interface RateHistory {
    rate: number;
    effectiveDate: string;
    updatedAt: string;
    updatedBy: string;
}

export interface RateItem {
    id: string;
    code: string;
    rate: number;
    categoryType: string;
    category: string;
    module: string;
    subcategory?: string;
    category_id?: string;
    unit_id?: string;
    description: string;
    unit: string;

    standardRate: number;
    effectiveDate: string;

    status: "active" | "inactive";

    history: RateHistory[];
}




export interface RateFormValues {
    code: string;
    category: string;
    categorytype: string;
    description: string;
    unit: string;
    standardRate: string;
    effectiveDate: string;
    status: RateStatus;
    module: string;
    category_id: string;
    unit_id: string;

}

export const emptyRateForm = (today: string): RateFormValues => ({
    code: "",
    category: "",
    categorytype: "",
    description: "",
    unit: "",
    standardRate: "",
    effectiveDate: today,
    status: "active",
    module: "",
    category_id: "",
    unit_id: ""
});
