export interface BOQRecord {
    id: string;
    reference: string;
    title: string;
    status: string;
    projectSiteLocation?: string;
    grandTotal: number;
    currency: string;
    itemCount: number;
    responseDueDate?: string | null;
    [key: string]: unknown;
}
