import {
    awardBOQ,
    getBOQ,
    getQuotation,
    getQuotationComparison,
    reviewQuotationSurvey,
} from "./quotationApi";

export interface BOQApprovalQuotationRow {
    quotationId: string;
    vendorId: string;
    vendorName: string;
    quotationNo: string;
    status: string;
    statusLabel: string;
    surveyStatus: string;
    masterRateTotal: number;
    vendorQuotedTotal: number;
    grandTotal: number;
    variance: number;
    variancePercentage: number;
    currency: string;
}

export interface BOQApproval {
    boq: {
        id?: string;
        status?: string;
        statusLabel?: string;
    };
    counts: {
        selectedVendors: number;
        surveyPending: number;
        quoteIssued: number;
        submitted: number;
        awarded: number;
    };
    quotations: BOQApprovalQuotationRow[];
    eligibleToAward: BOQApprovalQuotationRow[];
    canAward: boolean;
}

const unwrap = (value: any) => value?.data?.data ?? value?.data ?? value ?? null;

const statusLabel = (status: string) => {
    const labels: Record<string, string> = {
        "Form Issued": "Form Issued",
        "Form Submitted": "Form Submitted",
        "Form Approved": "Form Approved",
        "Form Rejected": "Form Rejected",
        Issued: "Issued",
        Draft: "Draft",
        Submitted: "Submitted",
        Awarded: "Awarded",
        "Not Awarded": "Not Awarded",
        Rejected: "Rejected",
    };
    return labels[status] || status;
};

const numberValue = (value: unknown) => {
    const number = Number(value);
    return Number.isFinite(number) ? number : 0;
};

const toRow = (quotation: any): BOQApprovalQuotationRow => {
    const lines = Array.isArray(quotation?.lines) ? quotation.lines : [];
    const masterRateTotal = lines.reduce(
        (sum: number, line: any) =>
            sum + numberValue(line?.masterRate ?? line?.rate) * numberValue(line?.quantity),
        0,
    );
    const vendorQuotedTotal = lines.reduce(
        (sum: number, line: any) =>
            sum + numberValue(line?.vendorRate ?? line?.quotedRate) * numberValue(line?.quantity),
        0,
    );
    const variance = vendorQuotedTotal - masterRateTotal;
    const variancePercentage = masterRateTotal > 0
        ? (variance / masterRateTotal) * 100
        : 0;

    return {
        quotationId: String(quotation?.id ?? quotation?._id ?? ""),
        vendorId: String(
            quotation?.vendorId ??
            quotation?.vendor?._id ??
            quotation?.vendor ??
            "",
        ),
        vendorName: String(quotation?.vendorName ?? quotation?.vendor?.name ?? "Vendor"),
        quotationNo: String(quotation?.quotationNo ?? ""),
        status: String(quotation?.status ?? "Draft"),
        statusLabel: statusLabel(String(quotation?.status ?? "Draft")),
        surveyStatus: String(quotation?.survey?.status ?? quotation?.surveyStatus ?? ""),
        masterRateTotal,
        vendorQuotedTotal,
        grandTotal: Number(quotation?.grandTotal ?? vendorQuotedTotal),
        variance,
        variancePercentage,
        currency: String(quotation?.currency ?? "USD"),
    };
};

export async function getBOQApproval(boqId: string): Promise<BOQApproval> {
    const response = await getBOQ(boqId);
    const payload = unwrap(response) ?? {};
    const quotations = Array.isArray(payload?.quotations) ? payload.quotations : [];

    const rows = quotations
        .map(toRow)
        .filter((row: BOQApprovalQuotationRow) => row.quotationId);

    const eligibleToAward = rows.filter((row: BOQApprovalQuotationRow) =>
        ["Submitted", "Form Approved", "Awarded"].includes(row.status),
    );

    return {
        boq: {
            id: String(payload?.id ?? payload?._id ?? boqId),
            status: String(payload?.status ?? ""),
            statusLabel: String(payload?.status ?? ""),
        },
        counts: {
            selectedVendors: Array.isArray(payload?.assignedVendors)
                ? payload.assignedVendors.length
                : rows.length,
            surveyPending: rows.filter((row: BOQApprovalQuotationRow) =>
                ["Form Issued", "Form Submitted"].includes(row.status),
            ).length,
            quoteIssued: rows.filter((row: BOQApprovalQuotationRow) => row.status === "Form Issued").length,
            submitted: rows.filter((row: BOQApprovalQuotationRow) =>
                ["Submitted", "Form Approved"].includes(row.status),
            ).length,
            awarded: rows.filter((row: BOQApprovalQuotationRow) => row.status === "Awarded").length,
        },
        quotations: rows,
        eligibleToAward,
        canAward: eligibleToAward.length > 0,
    };
}

export async function reviewSurvey(
    quotationId: string,
    approve: boolean,
    remarks = "",
) {
    return reviewQuotationSurvey(
        quotationId,
        approve ? "approve" : "reject",
        remarks,
    );
}

export async function checkMasterRate(quotationId: string) {
    return getQuotationComparison(quotationId);
}

export async function awardBOQVendor(
    boqId: string,
    quotationId: string,
    remarks: string,
) {
    const quotation = await getQuotation(quotationId);
    const vendorId = String(
        quotation?.vendorId ??
        quotation?.vendor?._id ??
        quotation?.vendor ??
        "",
    ).trim();

    if (!vendorId) {
        throw new Error("The selected quotation does not contain a vendor reference.");
    }

    return awardBOQ(boqId, vendorId, remarks);
}
