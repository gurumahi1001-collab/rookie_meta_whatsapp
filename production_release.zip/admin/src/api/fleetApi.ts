import api from './axios';

function unwrap(response: any) { return response?.data?.data ?? response?.data ?? null; }
function rows(response: any): any[] {
  const value = unwrap(response);
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.data)) return value.data;
  return [];
}
export async function listFleetVehicles(params: Record<string, any> = {}) { return rows(await api.get('/fleet/vehicles', { params })); }
export async function createFleetVehicle(payload: Record<string, any>) { return unwrap(await api.post('/fleet/vehicles', payload)); }
export async function updateFleetVehicle(id: string, payload: Record<string, any>) { return unwrap(await api.patch(`/fleet/vehicles/${encodeURIComponent(id)}`, payload)); }
export async function deleteFleetVehicle(id: string) { return unwrap(await api.delete(`/fleet/vehicles/${encodeURIComponent(id)}`)); }
export async function listFleetRequisitions(params: Record<string, any> = {}) { return rows(await api.get('/fleet/requisitions', { params })); }
export async function createFleetRequisition(payload: Record<string, any>) { return unwrap(await api.post('/fleet/requisitions', payload)); }
export async function updateFleetRequisitionAction(id: string, payload: Record<string, any>) { return unwrap(await api.patch(`/fleet/requisitions/${encodeURIComponent(id)}/action`, payload)); }
export async function listFleetClaims(params: Record<string, any> = {}) { return rows(await api.get('/fleet/claims', { params })); }
export async function createFleetClaim(payload: Record<string, any>, evidence?: File | null) {
  if (!evidence) return unwrap(await api.post('/fleet/claims', payload));
  const form = new FormData();
  Object.entries(payload).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') form.append(key, String(value));
  });
  form.append('evidence', evidence);
  return unwrap(await api.post('/fleet/claims', form, { headers: { 'Content-Type': 'multipart/form-data' } }));
}
export async function downloadFleetClaimAttachment(id: string, filename = 'fleet-claim-evidence') {
  const response = await api.get(`/fleet/claims/${encodeURIComponent(id)}/attachment`, { responseType: 'blob' });
  const blobUrl = window.URL.createObjectURL(response.data);
  const anchor = document.createElement('a');
  anchor.href = blobUrl;
  anchor.download = filename || 'fleet-claim-evidence';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => window.URL.revokeObjectURL(blobUrl), 1000);
}
export async function updateFleetClaimStatus(id: string, payload: Record<string, any>) { return unwrap(await api.patch(`/fleet/claims/${encodeURIComponent(id)}/status`, payload)); }
export async function getFleetSettings() { return unwrap(await api.get('/fleet/settings')); }
export async function updateFleetSettings(payload: Record<string, any>) { return unwrap(await api.put('/fleet/settings', payload)); }
