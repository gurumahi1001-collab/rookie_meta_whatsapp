import api from "./axios";

export type ApiQuotation = any;
export type ApiBOQ = any;

function unwrap(response: any) {
    return response?.data?.data ?? response?.data ?? null;
}

export async function listQuotations(params: Record<string, any> = {}) {
    const response = await api.get("/quotations", { params });
    return response.data as { success: boolean; data: ApiQuotation[]; pagination?: any };
}
export async function getQuotation(id: string) {
    return unwrap(await api.get(`/quotations/${id}`)) as ApiQuotation;
}
export async function deleteQuotation(id: string) {
    return unwrap(await api.delete(`/quotations/${id}`));
}
export async function getQuotationSurvey(id: string) {
    return unwrap(await api.get(`/quotations/${id}/survey`)) as { quotation: ApiQuotation; template: any; response: any };
}
export async function reviewQuotationSurvey(id: string, decision: "approve" | "reject", remarks = "") {
    return unwrap(await api.post(`/quotations/${id}/survey/review`, { decision, remarks })) as ApiQuotation;
}
export async function getQuotationComparison(id: string) {
    return unwrap(await api.get(`/quotations/${id}/comparison`)) as any[];
}
export async function listBOQs(params: Record<string, any> = {}) {
    const response = await api.get("/boqs", { params });
    return response.data as { success: boolean; data: ApiBOQ[]; pagination?: any };
}
export async function getBOQ(id: string) {
    return unwrap(await api.get(`/boqs/${id}`)) as ApiBOQ;
}
export async function saveBOQ(payload: Record<string, any>, submit = false) {
    const body = { ...payload, submit };
    const response = payload.id
        ? await api.patch(`/boqs/${payload.id}`, body)
        : await api.post("/boqs", body);
    return unwrap(response) as ApiBOQ;
}
export async function deleteBOQ(id: string) {
    return unwrap(await api.delete(`/boqs/${id}`));
}
export async function awardBOQ(id: string, vendorId: string, remarks: string) {
    return unwrap(await api.post(`/boqs/${id}/award`, { vendorId, remarks })) as ApiBOQ;
}
export async function listActiveMasterRates() {
    const response = await api.get("/master-rates/active", { params: { limit: 5000 } });
    return (response.data?.data ?? response.data ?? []) as any[];
}
export async function listApprovedVendors() {
    const response = await api.get("/vendors", { params: { status: "APPROVED", page: 1, limit: 500 } });
    return (response.data?.data ?? response.data ?? []) as any[];
}
export async function listCommonSetting(
    type: "validity_period" | "unit",
    params: Record<string, any> = {},
) {
    const response = await api.get("/settings/common", {
        params: { type, ...params },
    });
    return (response.data?.data ?? response.data ?? []) as any[];
}

export async function listActiveUnits() {
    return listCommonSetting("unit", {
        status: true,
        page: 1,
        limit: 100,
    });
}

export async function listMasterRateCategoryTypes() {
    const response = await api.get("/master-rates/categories/types");
    return (response.data?.data ?? response.data ?? []) as any[];
}

export async function listActiveMasterRateCategories(categoryType = "") {
    const response = await api.get("/master-rates/categories/active", {
        params: categoryType ? { categoryType } : undefined,
    });
    return (response.data?.data ?? response.data ?? []) as any[];
}

export async function listActiveSurveyTemplates() {
    const response = await api.get("/surveys/templates", { params: { status: "active", page: 1, limit: 500 } });
    return (response.data?.data ?? response.data ?? []) as any[];
}

const getQuotationLines = (row: any): any[] => [
    ...(Array.isArray(row?.lines) ? row.lines : []),
    ...(Array.isArray(row?.manualAdditions) ? row.manualAdditions : []),
];

const deriveQuotationEstimateTotal = (row: any): number => {
    const storedTotal = Number(row?.grandTotal);
    if (Number.isFinite(storedTotal) && storedTotal > 0) return storedTotal;

    const boqGrandTotal = Number(row?.boqGrandTotal);
    if (Number.isFinite(boqGrandTotal) && boqGrandTotal > 0) return boqGrandTotal;

    const lines = getQuotationLines(row);
    return lines.reduce((total, line) => {
        const quantity = Number(line?.quantity ?? 0);
        const vendorRate = Number(line?.vendorRate ?? line?.quotedRate);
        const lineTotal = Number(line?.lineTotal);
        const masterRate = Number(line?.masterRate ?? line?.rate);
        const unitRate = Number.isFinite(vendorRate) && vendorRate > 0
            ? vendorRate
            : Number.isFinite(lineTotal) && lineTotal > 0 && quantity > 0
                ? lineTotal / quantity
                : Number.isFinite(masterRate) && masterRate > 0
                    ? masterRate
                    : 0;
        return total + (Number.isFinite(quantity) && quantity > 0 ? quantity * unitRate : 0);
    }, 0);
};

export function toQuotationView(row: any): any {
    if (!row) return row;
    return {
        ...row,
        id: String(row.id ?? row._id),
        quotationNo: row.quotationNo ?? row.no ?? "",
        vendor: row.vendor ?? row.vendorId ?? "",
        vendorName: row.vendorName ?? row.vendor?.name ?? "Vendor",
        projectTitle: row.projectTitle ?? row.projectName ?? "",
        date: row.date ?? row.dueDate ?? row.quotationDate ?? "",
        dueDate: row.dueDate ?? row.date ?? "",
        grandTotal: deriveQuotationEstimateTotal(row),
        currency: row.currency ?? "USD",
        status: row.status ?? "Draft",
        category: row.category ?? "",
        items: Number(row.items ?? (getQuotationLines(row).length)),
        progress: Number(row.progress ?? 0),
        validUntil: row.validUntil ?? "",
        createdDate: row.createdDate ?? row.createdAt ?? "",
        clientName: row.clientName ?? "",
        formTemplate: row.formTemplate ?? row.formTemplateName ?? "",
    };
}

export function toBOQView(row: any): any {
    if (!row) return row;
    const vendorNames = (row.vendors ?? row.assignedVendors ?? []).map((v: any) => v?.name ?? v?.vendorName ?? String(v));
    return {
        ...row,
        id: String(row.id ?? row._id),
        quotationNo: row.quotationNo ?? row.boqNo ?? "",
        projectTitle: row.projectTitle ?? row.projectName ?? "",
        projectName: row.projectName ?? row.projectTitle ?? "",
        vendor: vendorNames,
        vendors: vendorNames,
        date: row.date ?? row.responseDueDate ?? row.dueDate ?? "",
        grandTotal: Number(row.grandTotal ?? 0),
        projectValue: Number(row.projectValue ?? 0),
        currency: row.currency ?? "USD",
        status: row.status ?? "Draft",
        category: row.category ?? row.formTemplate ?? "",
        items: Number(row.items ?? row.lines?.length ?? 0),
        validUntil: row.validUntil ?? row.responseDueDate ?? row.dueDate ?? "",
        createdDate: row.createdDate ?? row.createdAt ?? "",
        workflowStage: row.workflowStage ?? (row.status === "Pending Approval" ? "Financial Review" : row.status),
        vendorName: "",
        clientName: row.clientName ?? "",
        currencies: row.currency ?? "",
        awardedVendor: row.awardedVendorName ?? row.awardedVendor ?? "",
    };
}
