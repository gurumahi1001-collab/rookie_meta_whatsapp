import { useEffect, useMemo, useState } from "react";
import {
    CheckCircleIcon,
    FileMagnifyingGlassIcon,
    FileTextIcon,
    FloppyDiskIcon,
    SealCheckIcon,
    TrophyIcon,
    WarningCircleIcon,
    XCircleIcon,
} from "@phosphor-icons/react";
import type { BOQRecord } from "../../types/boq";
import type { BOQApproval } from "../../api/procurementWorkflowApi";
import {
    awardBOQVendor,
    checkMasterRate,
    getBOQApproval,
    reviewSurvey,
} from "../../api/procurementWorkflowApi";
import { getQuotation } from "../../api/quotationApi";
import type { Quotation } from "../../types/quotation";

interface Props {
    isOpen: boolean;
    boq: BOQRecord | null;
    onClose: () => void;
    onChanged?: () => void;
}

type ApprovalTab = "overview" | "survey" | "quotation" | "comparison" | "approval";

type SurveyField = {
    id?: string;
    label?: string;
    type?: string;
    required?: boolean;
    helpText?: string;
    unit?: string;
    options?: Array<{ id?: string; label?: string; value?: string }>;
};

type SurveyModule = {
    id?: string;
    name?: string;
    description?: string;
    sections?: Array<{
        id?: string;
        title?: string;
        fieldGroups?: Array<{
            id?: string;
            title?: string;
            fields?: SurveyField[];
        }>;
    }>;
};

const money = (value: number, currency: string) =>
    `${currency} ${Number(value || 0).toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    })}`;

const dateTime = (value?: string | null) => {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
    }).format(date);
};

const statusClass = (status: string) => {
    if (["approved", "awarded", "submitted"].includes(status)) {
        return "bg-emerald-50 text-emerald-700";
    }
    if (["form_submitted", "form_issued", "draft", "issued"].includes(status)) {
        return "bg-amber-50 text-amber-700";
    }
    if (["rejected", "not_awarded"].includes(status)) {
        return "bg-red-50 text-red-700";
    }
    return "bg-slate-100 text-slate-600";
};

const tabClass = (active: boolean) =>
    `whitespace-nowrap px-4 py-2.5 text-sm font-semibold transition ${
        active
            ? "border-b-2 border-red-600 text-red-600"
            : "text-slate-500 hover:text-slate-700"
    }`;

const asObject = (value: unknown): Record<string, any> =>
    value && typeof value === "object" && !Array.isArray(value)
        ? (value as Record<string, any>)
        : {};

const text = (value: unknown) => String(value ?? "").trim();

const surveyStatusLabel = (status?: string | null) =>
    ({
        issued: "Form Issued",
        draft: "Draft",
        submitted: "Submitted",
        reviewed: "Reviewed",
        approved: "Form Approved",
        rejected: "Rejected",
    } as Record<string, string>)[status || ""] || (status ? status : "-");

export default function BOQApprovalDrawer({
    isOpen,
    boq,
    onClose,
    onChanged,
}: Props) {
    const [data, setData] = useState<BOQApproval | null>(null);
    const [detail, setDetail] = useState<Quotation | null>(null);
    const [selectedQuotationId, setSelectedQuotationId] = useState("");
    const [activeTab, setActiveTab] = useState<ApprovalTab>("overview");
    const [loading, setLoading] = useState(false);
    const [detailLoading, setDetailLoading] = useState(false);
    const [busyId, setBusyId] = useState("");
    const [message, setMessage] = useState("");
    const [awardId, setAwardId] = useState("");
    const [awardRemarks, setAwardRemarks] = useState("");
    const [rejectTarget, setRejectTarget] = useState<string | null>(null);
    const [rejectReason, setRejectReason] = useState("");

    const load = async (preserveSelected = true) => {
        if (!boq) return;
        setLoading(true);
        setMessage("");
        try {
            const next = await getBOQApproval(boq.id);
            setData(next);
            const keep = preserveSelected && selectedQuotationId
                ? next.quotations.some((row) => row.quotationId === selectedQuotationId)
                : false;
            const fallback = next.quotations[0]?.quotationId || "";
            setSelectedQuotationId(keep ? selectedQuotationId : fallback);
            if (!awardId && next.eligibleToAward[0]) {
                setAwardId(next.eligibleToAward[0].quotationId);
            }
        } catch (error) {
            setMessage(error instanceof Error ? error.message : "Unable to load BOQ approval.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (isOpen && boq) {
            setActiveTab("overview");
            setData(null);
            setDetail(null);
            setSelectedQuotationId("");
            setAwardId("");
            setAwardRemarks("");
            setRejectTarget(null);
            setRejectReason("");
            void load(false);
        }
    }, [isOpen, boq?.id]);

    const selectedRow = useMemo(
        () => data?.quotations.find((row) => row.quotationId === selectedQuotationId) || null,
        [data, selectedQuotationId],
    );

    useEffect(() => {
        if (!isOpen || !selectedQuotationId) {
            setDetail(null);
            return;
        }
        let active = true;
        setDetailLoading(true);
        getQuotation(selectedQuotationId)
            .then((value) => {
                if (active) setDetail(value);
            })
            .catch((error) => {
                if (active) {
                    setMessage(error instanceof Error ? error.message : "Unable to load quotation details.");
                }
            })
            .finally(() => {
                if (active) setDetailLoading(false);
            });
        return () => {
            active = false;
        };
    }, [isOpen, selectedQuotationId]);

    const run = async (
        id: string,
        action: () => Promise<unknown>,
        success: string,
        nextTab?: ApprovalTab,
    ) => {
        setBusyId(id);
        setMessage("");
        try {
            await action();
            setMessage(success);
            await load(true);
            if (selectedQuotationId) {
                try {
                    setDetail(await getQuotation(selectedQuotationId));
                } catch {
                    // The list refresh already completed; keep the current detail if a secondary refresh fails.
                }
            }
            onChanged?.();
            if (nextTab) setActiveTab(nextTab);
        } catch (error) {
            setMessage(error instanceof Error ? error.message : "Action failed.");
        } finally {
            setBusyId("");
        }
    };

    const approveSurvey = async (quotationId: string) => {
        await run(
            quotationId,
            () => reviewSurvey(quotationId, true),
            "Survey approved. The vendor quotation is now open for pricing.",
            "quotation",
        );
    };

    const confirmRejectSurvey = async () => {
        if (!rejectTarget || !rejectReason.trim()) {
            setMessage("Survey rejection reason is required.");
            return;
        }
        const target = rejectTarget;
        await run(
            target,
            () => reviewSurvey(target, false, rejectReason.trim()),
            "Survey rejected and returned to the vendor.",
            "survey",
        );
        setRejectTarget(null);
        setRejectReason("");
    };

    const checkRate = async (quotationId: string) => {
        await run(
            quotationId,
            () => checkMasterRate(quotationId),
            "Master Rate comparison saved.",
            "comparison",
        );
    };

    const award = async () => {
        if (!boq || !awardId || !awardRemarks.trim()) {
            setMessage("Select a vendor and enter award remarks.");
            return;
        }
        await run(
            "award",
            () => awardBOQVendor(boq.id, awardId, awardRemarks.trim()),
            "Vendor awarded. The project was created from the approved commercial value.",
            "approval",
        );
    };

    const renderSurveyValue = (field: SurveyField, values: Record<string, any>) => {
        const raw = values[text(field.id)];
        if (Array.isArray(raw)) return raw.join(", ") || "-";
        if (raw === undefined || raw === null || raw === "") return "-";
        return String(raw);
    };

    const surveyModules = useMemo<SurveyModule[]>(() => {
        const snapshot = asObject(detail?.survey?.templateSnapshot);
        const schema = asObject(snapshot.schema);
        return Array.isArray(schema.modules) ? schema.modules.map((module) => asObject(module) as SurveyModule) : [];
    }, [detail]);

    const surveyValues = asObject(detail?.survey?.response);

    if (!isOpen || !boq) return null;

    const tabs = [
        { id: "overview" as const, label: "Overview" },
        { id: "survey" as const, label: "Survey & Form" },
        { id: "quotation" as const, label: "Quotation" },
        { id: "comparison" as const, label: "Master Rate Comparison" },
        { id: "approval" as const, label: "Approval & Award" },
    ];

    return (
        <div className="fixed inset-0 z-[9999] flex justify-end bg-slate-950/40 p-0 backdrop-blur-[2px]">
            <button
                type="button"
                className="absolute inset-0 cursor-default"
                aria-label="Close BOQ approval"
                onClick={onClose}
            />

            <aside className="relative z-10 flex h-full w-full max-w-6xl flex-col bg-white shadow-2xl">
                <div className="border-b border-slate-200 bg-white px-6 pt-5">
                    <div className="flex items-start justify-between gap-4">
                        <div>
                            <div className="flex flex-wrap items-center gap-2">
                                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-50 text-red-600">
                                    <FileTextIcon size={18} weight="duotone" />
                                </div>
                                <h2 className="text-base font-bold text-slate-900">
                                    {boq.reference} - BOQ Approval
                                </h2>
                                <span className="rounded-full bg-blue-50 px-2.5 py-1 text-[9px] font-bold text-blue-700">
                                    {data?.boq.statusLabel || boq.status}
                                </span>
                                {selectedRow?.statusLabel && (
                                    <span className={`rounded-full px-2.5 py-1 text-[9px] font-bold ${statusClass(selectedRow.status)}`}>
                                        Selected: {selectedRow.statusLabel}
                                    </span>
                                )}
                            </div>
                            <p className="mt-1 text-xs text-slate-500">
                                {boq.title} - vendor survey, quotation, commercial review and award workflow
                            </p>
                        </div>
                        <button
                            type="button"
                            onClick={onClose}
                            className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                            aria-label="Close"
                        >
                            <XCircleIcon size={19} />
                        </button>
                    </div>

                    <div className="mt-5 flex gap-1 overflow-x-auto border-b border-slate-200">
                        {tabs.map((tab) => (
                            <button
                                key={tab.id}
                                type="button"
                                className={tabClass(activeTab === tab.id)}
                                onClick={() => setActiveTab(tab.id)}
                            >
                                {tab.label}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto bg-slate-50 p-6">
                    {message && (
                        <div className="mb-5 flex items-start gap-2 rounded-xl border border-blue-100 bg-blue-50 px-4 py-3 text-xs font-semibold text-blue-700">
                            <WarningCircleIcon size={16} className="mt-0.5 shrink-0" />
                            <span>{message}</span>
                        </div>
                    )}

                    {loading ? (
                        <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-xs font-semibold text-slate-500 shadow-sm">
                            Loading approval workflow...
                        </div>
                    ) : data ? (
                        <>
                            {activeTab === "overview" && (
                                <div className="space-y-5">
                                    <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
                                        {[
                                            ["Selected Vendors", data.counts.selectedVendors],
                                            ["Survey Pending", data.counts.surveyPending],
                                            ["Quote Issued", data.counts.quoteIssued],
                                            ["Submitted", data.counts.submitted],
                                            ["Awarded", data.counts.awarded],
                                        ].map(([label, value]) => (
                                            <div key={String(label)} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                                                <p className="text-[8px] font-bold uppercase tracking-widest text-slate-400">{label}</p>
                                                <p className="mt-1 text-xl font-black text-slate-900">{value}</p>
                                            </div>
                                        ))}
                                    </div>

                                    <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                                        <div className="flex items-center justify-between border-b border-slate-200 bg-white px-5 py-4">
                                            <div>
                                                <h3 className="text-sm font-bold text-slate-900">Vendor Responses</h3>
                                                <p className="mt-1 text-[10px] text-slate-500">
                                                    Select a vendor to open the detailed tabs without changing the page layout.
                                                </p>
                                            </div>
                                            <SealCheckIcon size={20} className="text-red-500" />
                                        </div>
                                        <div className="overflow-x-auto">
                                            <table className="w-full min-w-[1050px] border-collapse">
                                                <thead>
                                                    <tr className="border-b border-slate-200 bg-slate-50">
                                                        {["Vendor", "Quotation", "Survey", "Master Rate", "Vendor Quote", "Variance", "Actions"].map((heading) => (
                                                            <th key={heading} className="px-4 py-3 text-left text-[8px] font-bold uppercase tracking-widest text-slate-400">
                                                                {heading}
                                                            </th>
                                                        ))}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {data.quotations.map((row) => (
                                                        <tr
                                                            key={row.quotationId}
                                                            className={`border-b border-slate-100 transition hover:bg-slate-50 ${selectedQuotationId === row.quotationId ? "bg-red-50/30" : ""}`}
                                                            onClick={() => setSelectedQuotationId(row.quotationId)}
                                                        >
                                                            <td className="px-4 py-3">
                                                                <p className="text-[11px] font-bold text-slate-800">{row.vendorName}</p>
                                                                <p className="mt-0.5 text-[9px] text-slate-400">{row.vendorId}</p>
                                                            </td>
                                                            <td className="px-4 py-3">
                                                                <p className="text-[10px] font-semibold text-slate-700">{row.quotationNo}</p>
                                                                <span className={`mt-1 inline-flex rounded-full px-2 py-1 text-[9px] font-bold ${statusClass(row.status)}`}>{row.statusLabel}</span>
                                                            </td>
                                                            <td className="px-4 py-3">
                                                                <span className="rounded-full bg-slate-100 px-2 py-1 text-[9px] font-semibold text-slate-600">{surveyStatusLabel(row.surveyStatus)}</span>
                                                            </td>
                                                            <td className="px-4 py-3 text-[10px] font-semibold text-slate-700">{money(row.masterRateTotal, row.currency)}</td>
                                                            <td className="px-4 py-3 text-[10px] font-semibold text-slate-700">{money(row.vendorQuotedTotal, row.currency)}</td>
                                                            <td className={`px-4 py-3 text-[10px] font-bold ${row.variance > 0 ? "text-red-600" : "text-emerald-600"}`}>
                                                                {money(row.variance, row.currency)}
                                                                <span className="ml-1 text-[8px] font-semibold">({row.variancePercentage.toFixed(2)}%)</span>
                                                            </td>
                                                            <td className="px-4 py-3">
                                                                <div className="flex flex-wrap gap-1">
                                                                    <button
                                                                        type="button"
                                                                        className="rounded-md border border-slate-200 bg-white px-2 py-1.5 text-[9px] font-bold text-slate-600 hover:bg-slate-50"
                                                                        onClick={(event) => {
                                                                            event.stopPropagation();
                                                                            setSelectedQuotationId(row.quotationId);
                                                                            setActiveTab("survey");
                                                                        }}
                                                                    >
                                                                        View
                                                                    </button>
                                                                    {row.surveyStatus === "submitted" && (
                                                                        <>
                                                                            <button
                                                                                type="button"
                                                                                disabled={busyId === row.quotationId}
                                                                                onClick={(event) => {
                                                                                    event.stopPropagation();
                                                                                    void approveSurvey(row.quotationId);
                                                                                }}
                                                                                className="inline-flex items-center gap-1 rounded-md bg-emerald-600 px-2 py-1.5 text-[9px] font-bold text-white disabled:opacity-50"
                                                                            >
                                                                                <CheckCircleIcon size={11} /> Approve
                                                                            </button>
                                                                            <button
                                                                                type="button"
                                                                                disabled={busyId === row.quotationId}
                                                                                onClick={(event) => {
                                                                                    event.stopPropagation();
                                                                                    setRejectTarget(row.quotationId);
                                                                                    setRejectReason("");
                                                                                }}
                                                                                className="inline-flex items-center gap-1 rounded-md border border-red-200 bg-red-50 px-2 py-1.5 text-[9px] font-bold text-red-700 disabled:opacity-50"
                                                                            >
                                                                                <XCircleIcon size={11} /> Reject
                                                                            </button>
                                                                        </>
                                                                    )}
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </section>

                                    <div className="grid gap-4 md:grid-cols-3">
                                        <div className="rounded-2xl border border-slate-200 bg-white p-5">
                                            <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">Project</p>
                                            <p className="mt-2 text-sm font-bold text-slate-900">{boq.title}</p>
                                            <p className="mt-1 text-[10px] text-slate-500">Site: {boq.projectSiteLocation || "-"}</p>
                                        </div>
                                        <div className="rounded-2xl border border-slate-200 bg-white p-5">
                                            <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">BOQ Total</p>
                                            <p className="mt-2 text-lg font-black text-slate-900">{money(boq.grandTotal, boq.currency)}</p>
                                            <p className="mt-1 text-[10px] text-slate-500">{boq.itemCount} line items</p>
                                        </div>
                                        <div className="rounded-2xl border border-slate-200 bg-white p-5">
                                            <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">Response Due</p>
                                            <p className="mt-2 text-sm font-bold text-slate-900">{dateTime(boq.responseDueDate)}</p>
                                            <p className="mt-1 text-[10px] text-slate-500">Only selected approved vendors are included.</p>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {activeTab === "survey" && (
                                <div className="space-y-5">
                                    {!selectedRow ? (
                                        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-xs text-slate-500">
                                            Select a vendor response from Overview.
                                        </div>
                                    ) : (
                                        <>
                                            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                                                <div className="flex flex-wrap items-center justify-between gap-3">
                                                    <div>
                                                        <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">Dynamic Survey</p>
                                                        <h3 className="mt-1 text-lg font-black text-slate-900">{selectedRow.vendorName}</h3>
                                                        <p className="mt-1 text-[10px] text-slate-500">{selectedRow.quotationNo}</p>
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        <span className={`rounded-full px-2.5 py-1 text-[9px] font-bold ${statusClass(selectedRow.surveyStatus || "")}`}>
                                                            {surveyStatusLabel(selectedRow.surveyStatus)}
                                                        </span>
                                                        {selectedRow.surveyStatus === "submitted" && (
                                                            <>
                                                                <button
                                                                    type="button"
                                                                    disabled={busyId === selectedRow.quotationId}
                                                                    onClick={() => void approveSurvey(selectedRow.quotationId)}
                                                                    className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-[10px] font-bold text-white disabled:opacity-50"
                                                                >
                                                                    <CheckCircleIcon size={13} /> Approve Form
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    disabled={busyId === selectedRow.quotationId}
                                                                    onClick={() => setRejectTarget(selectedRow.quotationId)}
                                                                    className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-[10px] font-bold text-red-700 disabled:opacity-50"
                                                                >
                                                                    <XCircleIcon size={13} /> Reject Form
                                                                </button>
                                                            </>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>

                                            {detailLoading ? (
                                                <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center text-xs text-slate-500">Loading submitted form...</div>
                                            ) : detail?.survey ? (
                                                <div className="space-y-5">
                                                    {surveyModules.map((module, moduleIndex) => (
                                                        <section key={module.id || moduleIndex} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                                                            <div>
                                                                <h4 className="text-sm font-black text-slate-900">{module.name || `Module ${moduleIndex + 1}`}</h4>
                                                                {module.description && <p className="mt-1 text-[10px] text-slate-500">{module.description}</p>}
                                                            </div>
                                                            <div className="mt-4 space-y-4">
                                                                {(module.sections || []).map((section, sectionIndex) => (
                                                                    <div key={section.id || sectionIndex}>
                                                                        <p className="mb-2 text-[9px] font-bold uppercase tracking-widest text-slate-400">{section.title || `Section ${sectionIndex + 1}`}</p>
                                                                        <div className="grid gap-3 md:grid-cols-2">
                                                                            {(section.fieldGroups || []).flatMap((group) => group.fields || []).map((field, fieldIndex) => (
                                                                                <div key={field.id || fieldIndex} className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                                                                                    <div className="flex items-start justify-between gap-2">
                                                                                        <p className="text-xs font-bold text-slate-700">{field.label || field.id}</p>
                                                                                        {field.required && <span className="text-[8px] font-bold text-red-500">Required</span>}
                                                                                    </div>
                                                                                    {field.helpText && <p className="mt-1 text-[9px] text-slate-400">{field.helpText}</p>}
                                                                                    <p className="mt-3 text-sm font-semibold text-slate-900">
                                                                                        {renderSurveyValue(field, surveyValues)}{field.unit ? ` ${field.unit}` : ""}
                                                                                    </p>
                                                                                </div>
                                                                            ))}
                                                                        </div>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </section>
                                                    ))}
                                                    {surveyModules.length === 0 && (
                                                        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-xs text-slate-500">
                                                            No dynamic fields were returned for this submitted form.
                                                        </div>
                                                    )}
                                                </div>
                                            ) : (
                                                <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-xs text-slate-500">Survey response is not available for this quotation.</div>
                                            )}
                                        </>
                                    )}
                                </div>
                            )}

                            {activeTab === "quotation" && (
                                <div className="space-y-5">
                                    {!selectedRow ? (
                                        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-xs text-slate-500">Select a vendor response from Overview.</div>
                                    ) : (
                                        <>
                                            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                                                {[
                                                    ["Vendor", selectedRow.vendorName],
                                                    ["Quotation", selectedRow.quotationNo],
                                                    ["Status", selectedRow.statusLabel],
                                                    ["Grand Total", money(selectedRow.grandTotal, selectedRow.currency)],
                                                ].map(([label, value]) => (
                                                    <div key={String(label)} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                                                        <p className="text-[8px] font-bold uppercase tracking-widest text-slate-400">{label}</p>
                                                        <p className="mt-1 text-sm font-bold text-slate-900">{value}</p>
                                                    </div>
                                                ))}
                                            </div>
                                            <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                                                <div className="border-b border-slate-200 bg-white px-5 py-4">
                                                    <h3 className="text-sm font-bold text-slate-900">Submitted Quotation Lines</h3>
                                                    <p className="mt-1 text-[10px] text-slate-500">Read-only commercial values from the vendor submission.</p>
                                                </div>
                                                {detailLoading ? (
                                                    <div className="p-10 text-center text-xs text-slate-500">Loading quotation...</div>
                                                ) : detail ? (
                                                    <div className="overflow-x-auto">
                                                        <table className="w-full min-w-[980px] border-collapse">
                                                            <thead>
                                                                <tr className="border-b border-slate-200 bg-slate-50">
                                                                    {["#", "Module", "Category", "Description", "Unit", "Qty", "Quoted Rate", "Tax", "Line Total"].map((heading) => (
                                                                        <th key={heading} className="px-4 py-3 text-left text-[8px] font-bold uppercase tracking-widest text-slate-400">{heading}</th>
                                                                    ))}
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                {(detail.lines || []).map((line, index) => (
                                                                    <tr key={line.id || index} className="border-b border-slate-100 last:border-0">
                                                                        <td className="px-4 py-3 text-[9px] text-slate-400">{index + 1}</td>
                                                                        <td className="px-4 py-3 text-[10px] font-semibold text-slate-700">{line.module || "-"}</td>
                                                                        <td className="px-4 py-3 text-[10px] text-slate-600">{line.category || "-"}</td>
                                                                        <td className="px-4 py-3 text-[10px] text-slate-700">{line.description}</td>
                                                                        <td className="px-4 py-3 text-[10px] text-slate-600">{line.unit}</td>
                                                                        <td className="px-4 py-3 text-[10px] font-semibold text-slate-700">{line.quantity}</td>
                                                                        <td className="px-4 py-3 text-[10px] font-bold text-slate-800">{money(line.quotedRate, detail.currency)}</td>
                                                                        <td className="px-4 py-3 text-[10px] text-slate-600">{line.taxRate || 0}%</td>
                                                                        <td className="px-4 py-3 text-[10px] font-bold text-slate-900">{money(line.lineTotal || 0, detail.currency)}</td>
                                                                    </tr>
                                                                ))}
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                ) : (
                                                    <div className="p-10 text-center text-xs text-slate-500">Quotation details are unavailable.</div>
                                                )}
                                            </section>
                                        </>
                                    )}
                                </div>
                            )}

                            {activeTab === "comparison" && (
                                <div className="space-y-5">
                                    {!selectedRow ? (
                                        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-xs text-slate-500">Select a vendor response from Overview.</div>
                                    ) : (
                                        <>
                                            <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
                                                {[
                                                    ["Master Rate Total", money(selectedRow.masterRateTotal, selectedRow.currency)],
                                                    ["Vendor Quotation", money(selectedRow.vendorQuotedTotal, selectedRow.currency)],
                                                    ["Variance", money(selectedRow.variance, selectedRow.currency)],
                                                    ["Variance %", `${selectedRow.variancePercentage.toFixed(2)}%`],
                                                ].map(([label, value], index) => (
                                                    <div key={String(label)} className={`rounded-xl border p-4 ${index === 2 && selectedRow.variance > 0 ? "border-red-200 bg-red-50" : "border-slate-200 bg-white"}`}>
                                                        <p className="text-[8px] font-bold uppercase tracking-widest text-slate-400">{label}</p>
                                                        <p className="mt-1 text-base font-black text-slate-900">{value}</p>
                                                    </div>
                                                ))}
                                            </div>
                                            <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                                                <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
                                                    <div>
                                                        <h3 className="text-sm font-bold text-slate-900">Benchmark Comparison</h3>
                                                        <p className="mt-1 text-[10px] text-slate-500">Item-wise difference using the stored Master Rate snapshot.</p>
                                                    </div>
                                                    {(["submitted", "approved", "awarded", "not_awarded"] as string[]).includes(selectedRow.status) && (
                                                        <button
                                                            type="button"
                                                            disabled={busyId === selectedRow.quotationId}
                                                            onClick={() => void checkRate(selectedRow.quotationId)}
                                                            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-2 text-[10px] font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-50"
                                                        >
                                                            <FileMagnifyingGlassIcon size={13} /> Check Rate
                                                        </button>
                                                    )}
                                                </div>
                                                {detailLoading ? (
                                                    <div className="p-10 text-center text-xs text-slate-500">Loading comparison...</div>
                                                ) : detail ? (
                                                    <div className="overflow-x-auto">
                                                        <table className="w-full min-w-[900px] border-collapse">
                                                            <thead>
                                                                <tr className="border-b border-slate-200 bg-slate-50">
                                                                    {["Item", "Qty", "Master Rate", "Vendor Rate", "Difference", "Variance %"].map((heading) => (
                                                                        <th key={heading} className="px-4 py-3 text-left text-[8px] font-bold uppercase tracking-widest text-slate-400">{heading}</th>
                                                                    ))}
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                {(detail.lines || []).map((line, index) => {
                                                                    const master = Number(line.masterRate || 0);
                                                                    const quoted = Number(line.quotedRate || 0);
                                                                    const difference = quoted - master;
                                                                    const variance = master > 0 ? (difference / master) * 100 : 0;
                                                                    return (
                                                                        <tr key={line.id || index} className="border-b border-slate-100 last:border-0">
                                                                            <td className="px-4 py-3"><p className="text-[10px] font-bold text-slate-800">{line.description}</p><p className="mt-0.5 text-[9px] text-slate-400">{line.module || "-"} / {line.category || "-"}</p></td>
                                                                            <td className="px-4 py-3 text-[10px] font-semibold text-slate-700">{line.quantity}</td>
                                                                            <td className="px-4 py-3 text-[10px] font-semibold text-slate-700">{money(master, detail.currency)}</td>
                                                                            <td className="px-4 py-3 text-[10px] font-semibold text-slate-700">{money(quoted, detail.currency)}</td>
                                                                            <td className={`px-4 py-3 text-[10px] font-bold ${difference > 0 ? "text-red-600" : "text-emerald-600"}`}>{money(difference, detail.currency)}</td>
                                                                            <td className={`px-4 py-3 text-[10px] font-bold ${variance > 0 ? "text-red-600" : "text-emerald-600"}`}>{variance.toFixed(2)}%</td>
                                                                        </tr>
                                                                    );
                                                                })}
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                ) : (
                                                    <div className="p-10 text-center text-xs text-slate-500">Comparison details are unavailable.</div>
                                                )}
                                            </section>
                                        </>
                                    )}
                                </div>
                            )}

                            {activeTab === "approval" && (
                                <div className="space-y-5">
                                    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                                        <div className="flex items-start gap-3">
                                            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
                                                <TrophyIcon size={19} />
                                            </div>
                                            <div>
                                                <h3 className="text-sm font-black text-slate-900">Management Approval & Award</h3>
                                                <p className="mt-1 text-[10px] text-slate-500">
                                                    The final award closes the RFQ, marks non-selected vendors Not Awarded and creates the project automatically.
                                                </p>
                                            </div>
                                        </div>

                                        <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
                                            <div className="grid gap-3 md:grid-cols-[1fr_1.4fr_auto] md:items-end">
                                                <label className="block">
                                                    <span className="mb-1 block text-[9px] font-bold uppercase tracking-widest text-slate-400">Award Vendor</span>
                                                    <select
                                                        value={awardId}
                                                        onChange={(event) => {
                                                            setAwardId(event.target.value);
                                                            setSelectedQuotationId(event.target.value);
                                                        }}
                                                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-xs font-semibold text-slate-700 outline-none focus:border-red-300"
                                                    >
                                                        <option value="">Select vendor...</option>
                                                        {data.eligibleToAward.map((row) => (
                                                            <option key={row.quotationId} value={row.quotationId}>
                                                                {row.vendorName} - {money(row.vendorQuotedTotal, row.currency)}
                                                            </option>
                                                        ))}
                                                    </select>
                                                </label>
                                                <label className="block">
                                                    <span className="mb-1 block text-[9px] font-bold uppercase tracking-widest text-slate-400">Award Remarks</span>
                                                    <input
                                                        value={awardRemarks}
                                                        onChange={(event) => setAwardRemarks(event.target.value)}
                                                        placeholder="Enter mandatory award remarks"
                                                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-xs text-slate-700 outline-none focus:border-red-300"
                                                    />
                                                </label>
                                                <button
                                                    type="button"
                                                    disabled={!data.canAward || !awardId || !awardRemarks.trim() || busyId === "award"}
                                                    onClick={() => void award()}
                                                    className="inline-flex h-[39px] items-center justify-center gap-2 rounded-lg bg-red-600 px-4 text-[10px] font-bold text-white hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
                                                >
                                                    <TrophyIcon size={13} /> Award Vendor
                                                </button>
                                            </div>
                                        </div>
                                    </section>

                                    <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
                                        <div className="border-b border-slate-200 px-5 py-4">
                                            <h3 className="text-sm font-bold text-slate-900">Eligible Vendors</h3>
                                            <p className="mt-1 text-[10px] text-slate-500">Only submitted or approved quotations are eligible for award.</p>
                                        </div>
                                        <div className="overflow-x-auto">
                                            <table className="w-full min-w-[780px] border-collapse">
                                                <thead>
                                                    <tr className="border-b border-slate-200 bg-slate-50">
                                                        {["Vendor", "Quotation", "Status", "Commercial Value", "Variance", "Select"].map((heading) => (
                                                            <th key={heading} className="px-4 py-3 text-left text-[8px] font-bold uppercase tracking-widest text-slate-400">{heading}</th>
                                                        ))}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {data.eligibleToAward.map((row) => (
                                                        <tr key={row.quotationId} className="border-b border-slate-100 last:border-0">
                                                            <td className="px-4 py-3 text-[10px] font-bold text-slate-800">{row.vendorName}</td>
                                                            <td className="px-4 py-3 text-[10px] text-slate-600">{row.quotationNo}</td>
                                                            <td className="px-4 py-3"><span className={`rounded-full px-2 py-1 text-[9px] font-bold ${statusClass(row.status)}`}>{row.status}</span></td>
                                                            <td className="px-4 py-3 text-[10px] font-bold text-slate-800">{money(row.vendorQuotedTotal, row.currency)}</td>
                                                            <td className={`px-4 py-3 text-[10px] font-bold ${row.variance > 0 ? "text-red-600" : "text-emerald-600"}`}>{row.variancePercentage.toFixed(2)}%</td>
                                                            <td className="px-4 py-3">
                                                                <button
                                                                    type="button"
                                                                    onClick={() => {
                                                                        setAwardId(row.quotationId);
                                                                        setSelectedQuotationId(row.quotationId);
                                                                    }}
                                                                    className={`rounded-lg px-3 py-1.5 text-[9px] font-bold ${awardId === row.quotationId ? "bg-red-600 text-white" : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`}
                                                                >
                                                                    {awardId === row.quotationId ? "Selected" : "Select"}
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </section>
                                </div>
                            )}
                        </>
                    ) : null}
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-white px-6 py-3">
                    <div className="flex items-center gap-2 text-[9px] text-slate-400">
                        <FloppyDiskIcon size={13} />
                        <span>Workflow actions are persisted server-side and every approval/award transition is auditable.</span>
                    </div>
                    <button
                        type="button"
                        onClick={() => void load(true)}
                        disabled={loading}
                        className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-[10px] font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50"
                    >
                        Refresh
                    </button>
                </div>
            </aside>

            {rejectTarget && (
                <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-[2px]">
                    <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-5 shadow-2xl">
                        <div className="flex items-start gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-50 text-red-600">
                                <XCircleIcon size={19} />
                            </div>
                            <div>
                                <h3 className="text-sm font-bold text-slate-900">Reject Survey Form</h3>
                                <p className="mt-1 text-[10px] leading-relaxed text-slate-500">Enter the reason that will be stored with the workflow decision and returned to the vendor.</p>
                            </div>
                        </div>
                        <textarea
                            value={rejectReason}
                            onChange={(event) => setRejectReason(event.target.value)}
                            rows={5}
                            placeholder="Enter rejection reason..."
                            className="mt-4 w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-3 py-3 text-xs text-slate-700 outline-none focus:border-red-300 focus:bg-white"
                        />
                        <div className="mt-4 flex justify-end gap-2">
                            <button
                                type="button"
                                onClick={() => {
                                    setRejectTarget(null);
                                    setRejectReason("");
                                }}
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-[10px] font-bold text-slate-600 hover:bg-slate-50"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                disabled={!rejectReason.trim() || Boolean(busyId)}
                                onClick={() => void confirmRejectSurvey()}
                                className="rounded-lg bg-red-600 px-4 py-2.5 text-[10px] font-bold text-white hover:bg-red-700 disabled:opacity-50"
                            >
                                Confirm Rejection
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
