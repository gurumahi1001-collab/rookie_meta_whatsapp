import React, { useEffect, useMemo, useState } from "react";
import {
    XIcon,
    DownloadSimpleIcon,
    PrinterIcon,
    PencilSimpleIcon,
    ClockIcon,
    CheckCircleIcon,
    WarningIcon,
    ArrowRightIcon,
    FileTextIcon,
} from "@phosphor-icons/react";
import Select from "react-select";
import { ProjectBOQQuotation } from "../../data/quotations";
import DataTable, {
    DataTableColumn,
} from "../../components/DataTable";
import { SelectOption } from "../../types/projectBOQ";
import { getSelectStyles } from "../../utils/selectStyles";
import { awardBOQ, getBOQ, getQuotationComparison } from "../../api/quotationApi";

interface ViewQuotationDrawerProps {
    isOpen: boolean;
    quotation: ProjectBOQQuotation | null;
    onClose: () => void;
    onEdit?: (quotation: ProjectBOQQuotation) => void;
    onExport?: (quotation: ProjectBOQQuotation) => void;
    onGenerateQuotation?: () => void;
    onAwarded?: () => void;
}

interface BOQItem {
    id: number;
    boqLineId?: string;
    masterRateItemId?: string;
    categoryType?: string;
    module: string;
    category: string;
    description: string;
    unit: string;
    quantity: number;
    rate: number;
    total: number;
}

interface MasterRateItem {
    id: number;
    boqLineId?: string;
    masterRateItemId?: string;
    module: string;
    category: string;
    description: string;
    unit: string;
    standardRate: number;
    lastUpdated: string;
    variance: number;
}

interface ManuallyCreatedItem {
    id: number;
    module: string;
    category: string;
    description: string;
    unit: string;
    quantity: number;
    rate: number;
    total: number;
    createdBy: string;
    createdAt: string;
    notes?: string;
}

type ManagerOption = {
    value: string;
    label: string;
};

interface VendorQuote {
    vendor: string;
    rate: number;
    variance: number;
}

interface VendorPayment {
    id: string;
    vendor: string;
    module: string;
    installmentName: string;
    netTotal: number;
    amountPaid: number;
    dueDate: string;
    paidDate?: string;
    status: "Paid" | "Partial" | "Pending" | "Past Due";
}

const managerOptions = [
    { value: "david miller", label: "David Miller" },
    { value: "jessica williams", label: "Jessica Williams" },
    { value: "michael chen", label: "Michael Chen" },
];

interface ComparisonItem extends BOQItem {
    masterRate: number;
    variance: number;
    lastUpdated: string;
    status: {
        color: string;
        bg: string;
        label: string;
        icon: React.ElementType;
    };
    vendors: VendorQuote[];
}

/* =========================================================
   HELPERS
========================================================= */

const formatCurrency = (value: number) => {
    return Number(value || 0).toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
};

/* =========================================================
   MAIN DRAWER
========================================================= */

const ViewQuotationDrawer = ({
    isOpen,
    quotation,
    onClose,
    onEdit,
    onExport,
    onGenerateQuotation,
    onAwarded,
}: ViewQuotationDrawerProps) => {
    const [activeTab, setActiveTab] = useState<
        "boq" | "comparison" | "manual" | "payment"
    >("boq");
    const [showConvertModal, setShowConvertModal] = useState(false);
    const [startDate, setStartDate] = useState("");
    const [endDate, setEndDate] = useState("");
    const [assignedManager, setAssignedManager] = useState<ManagerOption | null>(null);
    const [liveBoqData, setLiveBoqData] = useState<any | null>(null);

    useEffect(() => {
        if (!isOpen || !quotation?.id) {
            setLiveBoqData(null);
            return;
        }
        let active = true;
        setLiveBoqData(null);
        getBOQ(String(quotation.id))
            .then((data) => {
                if (active && data) setLiveBoqData(data);
            })
            .catch(() => {
                // The drawer can also be opened with a quotation record rather than a BOQ record.
                // In that case the prop remains the authoritative fallback.
            });
        return () => { active = false; };
    }, [isOpen, quotation?.id]);

    const sourceBoq = (liveBoqData ?? quotation ?? {}) as any;
    const rawQuotations: any[] = Array.isArray(sourceBoq.quotations)
        ? sourceBoq.quotations
        : quotation
            ? [quotation]
            : [];


    const getStatusClass = (status: string) => {
        switch (status) {
            case "Draft":
                return "bg-slate-100 text-slate-600";

            case "Pending Approval":
                return "bg-amber-50 text-amber-600";

            case "Awarded":
            return "bg-emerald-50 text-emerald-600";

           case "Generated Quotation":
                 return "bg-blue-50 text-blue-600";

            case "Converted to Project":
                return "bg-blue-50 text-blue-600";

            case "Rejected":
                return "bg-red-50 text-red-600";

            default:
                return "bg-slate-100 text-slate-600";
        }
    };

    const primaryQuotation = rawQuotations[0] || sourceBoq;

    const sourceBoqLines = Array.isArray(sourceBoq.lines) ? sourceBoq.lines : [];
    const sourceBoqManualLines = Array.isArray(sourceBoq.manualAdditions) ? sourceBoq.manualAdditions : [];
    const quotationLines = [
        ...(Array.isArray(primaryQuotation.lines) ? primaryQuotation.lines : []),
        ...(Array.isArray(primaryQuotation.manualAdditions) ? primaryQuotation.manualAdditions : []),
    ];
    const allSourceLines = sourceBoqLines.length || sourceBoqManualLines.length
        ? [...sourceBoqLines, ...sourceBoqManualLines]
        : quotationLines;

    const boqItems: BOQItem[] = allSourceLines.map((line: any, index: number) => ({
        id: index + 1,
        boqLineId: String(line.boqLineId ?? line.id ?? line._id ?? ""),
        masterRateItemId: String(line.masterRateItemId ?? line.marketRateItemId ?? ""),
        categoryType: String(line.categoryType ?? ""),
        module: String(line.module ?? "-"),
        category: String(line.category ?? "General"),
        description: String(line.description ?? "-"),
        unit: String(line.unit ?? "Unit"),
        quantity: Number(line.quantity ?? 0),
        rate: Number(line.rate ?? line.masterRate ?? 0),
        total: Number(line.lineTotal ?? 0),
    }));

    const manualItems: ManuallyCreatedItem[] = (Array.isArray(sourceBoq.manualAdditions) ? sourceBoq.manualAdditions : []).map((line: any, index: number) => ({
        id: index + 1,
        module: String(line.module ?? "-"),
        category: String(line.category ?? "General"),
        description: String(line.description ?? "-"),
        unit: String(line.unit ?? "Unit"),
        quantity: Number(line.quantity ?? 0),
        rate: Number(line.rate ?? line.masterRate ?? 0),
        total: Number(line.lineTotal ?? 0),
        createdBy: String(line.createdBy ?? "-"),
        createdAt: line.createdAt ? String(line.createdAt).slice(0, 10) : "-",
        notes: line.notes ? String(line.notes) : undefined,
    }));

    const subtotal = Number(sourceBoq.subtotal ?? primaryQuotation.subtotal ?? boqItems.reduce((sum, item) => sum + item.total, 0));
    const manualTotal = manualItems.reduce((sum, item) => sum + item.total, 0);
    const totalItems = subtotal + manualTotal;
    const contingency = Number(sourceBoq.contingency ?? subtotal * 0.1);
    const grandTotal = Number(sourceBoq.grandTotal ?? primaryQuotation.grandTotal ?? totalItems + contingency);

    const masterRates: MasterRateItem[] = boqItems.map((item, index) => {
        const sourceLine = quotationLines.find((line: any) =>
            String(line.boqLineId ?? line.id ?? line._id ?? "") === String(item.boqLineId ?? "")
            || String(line.masterRateItemId ?? line.marketRateItemId ?? "") === String(item.masterRateItemId ?? "")
        ) || {};
        return {
            id: index + 1,
            boqLineId: item.boqLineId,
            masterRateItemId: item.masterRateItemId,
            module: item.module,
            category: item.category,
            description: item.description,
            unit: item.unit,
            standardRate: Number(sourceLine.masterRate ?? item.rate ?? 0),
            lastUpdated: sourceLine.updatedAt ? String(sourceLine.updatedAt).slice(0, 10) : "",
            variance: 0,
        };
    });

    const vendorPaymentSchedules = rawQuotations.map((quote: any, vendorIndex: number) => {
        const rawSchedule = Array.isArray(quote?.paymentSchedule)
            ? quote.paymentSchedule
            : Array.isArray(quote?.paymentSchedule?.installments)
                ? quote.paymentSchedule.installments
                : [];

        return {
            id: String(quote?.id ?? quote?._id ?? vendorIndex + 1),
            vendor: String(quote?.vendorName ?? quote?.vendor ?? "Vendor"),
            currency: String(quote?.currency ?? sourceBoq.currency ?? "USD"),
            grandTotal: Number(quote?.grandTotal ?? sourceBoq.grandTotal ?? 0),
            installments: rawSchedule.map((item: any, index: number) => ({
                id: String(item?.id ?? item?._id ?? `${vendorIndex + 1}-${index + 1}`),
                installmentName: String(item?.name ?? item?.installmentName ?? `Installment ${index + 1}`),
                module: Array.isArray(item?.modules) ? item.modules.map(String).join(", ") : String(item?.module ?? ""),
                amount: Number(item?.amount ?? 0),
                dueDate: item?.dueDate ? String(item.dueDate).slice(0, 10) : "",
            })),
        };
    });

    const [liveComparisons, setLiveComparisons] = useState<Record<string, any[]>>({});

    useEffect(() => {
        if (!isOpen || rawQuotations.length === 0) {
            setLiveComparisons({});
            return;
        }
        let active = true;
        void Promise.all(rawQuotations.map(async (item: any) => {
            const id = String(item.id ?? item._id ?? "");
            if (!id) return { id: "", rows: [] as any[] };
            try {
                const rows = await getQuotationComparison(id);
                return { id, rows: Array.isArray(rows) ? rows : [] };
            } catch {
                return { id, rows: [] as any[] };
            }
        })).then((results) => {
            if (!active) return;
            setLiveComparisons(Object.fromEntries(results.filter((result) => result.id).map((result) => [result.id, result.rows])));
        });
        return () => { active = false; };
    }, [isOpen, quotation?.id, rawQuotations.map((item: any) => String(item.id ?? item._id ?? "")).join(",")]);

    if (!quotation) return null;

    const isDraft = quotation.status === "Draft";
    const getVarianceStatus = (variance: number) => {
        if (variance > 10) {
            return {
                color: "text-red-600",
                bg: "bg-red-50",
                label: "High",
                icon: WarningIcon,
            };
        }

        if (variance > 5) {
            return {
                color: "text-amber-600",
                bg: "bg-amber-50",
                label: "Moderate",
                icon: ClockIcon,
            };
        }

        if (variance < -5) {
            return {
                color: "text-emerald-600",
                bg: "bg-emerald-50",
                label: "Below",
                icon: CheckCircleIcon,
            };
        }

        return {
            color: "text-blue-600",
            bg: "bg-blue-50",
            label: "Within Range",
            icon: CheckCircleIcon,
        };
    };

    return (
        <div
            className={`fixed inset-0 z-50 transition-opacity ${
                isOpen
                    ? "opacity-100"
                    : "pointer-events-none opacity-0"
            }`}
        >
            <div
                className="absolute inset-0 bg-black/40 backdrop-blur-sm"
                onClick={onClose}
            />

            <div
                className={`absolute right-0 top-0 h-full w-full max-w-5xl transform overflow-y-auto bg-white transition-transform duration-300 ease-in-out ${
                    isOpen
                        ? "translate-x-0"
                        : "translate-x-full"
                }`}
            >
                <div className="sticky top-0 z-10 border-b border-slate-200 bg-white px-6 py-5">
                    <div className="flex items-start justify-between">
                        <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-3">
                                <h2 className="truncate text-xl font-bold text-slate-900">
                                    {quotation.projectTitle}
                                </h2>

                                <span
                                    className={`inline-flex rounded-full px-3 py-1 text-xs font-bold ${getStatusClass(
                                        quotation.status
                                    )}`}
                                >
                                    {quotation.status}
                                </span>

                                <span className="inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600">
                                    {quotation.quotationNo}
                                </span>

                                {quotation.status === "Awarded" && quotation.awardedVendor && (
                                    <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700">
                                        <CheckCircleIcon
                                            size={14}
                                            weight="fill"
                                        />
                                        {quotation.awardedVendor}
                                    </span>
                                )}
                            </div>

                            <p className="mt-1 text-sm text-slate-500">
                                {quotation.category} • {quotation.items} Items •{" "}
                                {quotation.workflowStage}
                            </p>

                                {quotation.status === "Awarded" && (
                                    <div className="mt-3 flex flex-wrap items-start gap-3">
                                        <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2">
                                            <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-600">
                                                Awarded Vendor
                                            </p>

                                            <p className="mt-0.5 text-sm font-bold text-emerald-800">
                                                {quotation.awardedVendor || "Flow Jamaica"}
                                            </p>
                                        </div>

                                        <div className="max-w-xl rounded-lg border border-slate-200 bg-slate-50 px-3 py-2">
                                            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                                                Award Remarks
                                            </p>

                                            <p className="mt-0.5 text-xs leading-5 text-slate-600">
                                                {"Vendor selected based on lowest evaluated rate, previous project performance, and delivery capability."}
                                            </p>
                                        </div>
                                    </div>
                                )}
                        </div>

                        <div className="ml-4 flex shrink-0 items-center gap-2">
                           {quotation.status === "Awarded" && (
                                <button
                                    type="button"
                                    onClick={() => setShowConvertModal(true)}
                                    className="inline-flex h-10 items-center gap-2 rounded-lg bg-emerald-600 px-4 text-sm font-semibold text-white transition hover:bg-emerald-700"
                                >
                                    <ArrowRightIcon size={16} weight="bold" />
                                    Convert to Project
                                </button>
                            )}


                            <button
                                onClick={onClose}
                                className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                            >
                                <XIcon size={20} weight="bold" />
                            </button>
                        </div>
                    </div>


                    <div className="mt-4 flex flex-wrap items-center gap-2">
                        {quotation.status === "Draft" &&
                            onEdit && ( 
                                <button
                                    onClick={() =>
                                        onEdit(quotation)
                                    }
                                    className="flex items-center gap-2 rounded-lg bg-amber-50 px-4 py-2 text-sm font-semibold text-amber-600 transition hover:bg-amber-100"
                                >
                                    <PencilSimpleIcon
                                        size={16}
                                        weight="bold"
                                    />
                                    Edit
                                </button>
                            )}

                        <button
                            onClick={() =>
                                onExport?.(quotation)
                            }
                            className="flex items-center gap-2 rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
                        >
                            <DownloadSimpleIcon
                                size={16}
                                weight="bold"
                            />
                            Export
                        </button>

                        <button className="flex items-center gap-2 rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition hover:bg-slate-50">
                            <PrinterIcon
                                size={16}
                                weight="bold"
                            />
                            Print
                        </button>

                        {onGenerateQuotation && (
                            <button
                                onClick={
                                    onGenerateQuotation
                                }
                                className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-700"
                            >
                                <FileTextIcon
                                    size={16}
                                    weight="bold"
                                />
                                Generate Final Quotation
                            </button>
                        )}
                    </div>

                    {/* TABS */}

                    <div className="mt-4 flex gap-1 overflow-x-auto border-b border-slate-200">
                       {[
    {
        id: "boq",
        label: "BOQ Details",
    },

    ...(!isDraft
        ? [
            {
                id: "comparison",
                label: "Master Rate Comparison",
            },
        ]
        : []),

    {
        id: "manual",
        label: "Manual Additions",
    },

    ...(!isDraft
        ? [
            {
                id: "payment",
                label: "Payment Schedule",
            },
        ]
        : []),
].map((tab) => (
    <button
        key={tab.id}
        type="button"
        onClick={() =>
            setActiveTab(tab.id as typeof activeTab)
        }
        className={`whitespace-nowrap px-4 py-2.5 text-sm font-semibold transition ${
            activeTab === tab.id
                ? "border-b-2 border-red-600 text-red-600"
                : "text-slate-500 hover:text-slate-700"
        }`}
    >
        {tab.label}
    </button>
))}

                    </div>
                </div>

                {/* CONTENT */}

                <div className="p-6">
                    {activeTab === "boq" && (
                        <BOQDetailsTab
                            quotation={quotation}
                            boqItems={boqItems}
                            manualItems={manualItems}
                            subtotal={subtotal}
                            manualTotal={manualTotal}
                            totalItems={totalItems} 
                            contingency={contingency}
                            grandTotal={grandTotal}
                            formatCurrency={formatCurrency}
                        />
                    )}

                    {activeTab === "comparison" && !isDraft && (
                        <ComparisonTab
                            quotation={quotation}
                            boqItems={boqItems}
                            masterRates={masterRates}
                            formatCurrency={formatCurrency}
                            getVarianceStatus={
                                getVarianceStatus
                            }
                            quoteRows={rawQuotations}
                            liveComparisons={liveComparisons}
                            onAward={async (vendorId, remarks) => {
                                await awardBOQ(String(quotation.id), vendorId, remarks);
                                onAwarded?.();
                            }}
                        />
                    )}

                    {activeTab === "manual" && (
                        <ManualItemsTab
                            manualItems={manualItems}
                            formatCurrency={formatCurrency}
                        />
                    )}

                    {activeTab === "payment" && (
                        <PaymentTab
                            vendorSchedules={vendorPaymentSchedules}
                            formatCurrency={formatCurrency}
                        />
                    )}
                </div>
            </div>
            {showConvertModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                    <div className="w-full max-w-lg rounded-md bg-white shadow-xl">

                        {/* Header */}
                        <div className="flex items-center justify-between border-b px-6 py-4">
                            <div>
                                <h2 className="text-lg font-semibold text-gray-900">
                                    Convert to Project
                                </h2>
                                <p className="mt-1 text-sm text-gray-500">
                                    Set the project timeline and assign a manager.
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={() => setShowConvertModal(false)}
                                className="rounded-lg p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-600"
                            >
                                <XIcon size={20} />
                            </button>
                        </div>

                        {/* Form */}
                        <div className="space-y-5 px-6 py-6">

                            {/* Start Date */}
                            <div>
                                <label className="mb-1.5 block text-sm font-medium text-gray-700">
                                    Start Date
                                </label>

                                <input
                                    type="date"
                                    value={startDate}
                                    onChange={(e) => setStartDate(e.target.value)}
                                    className="h-10 w-full rounded-lg border border-gray-300 px-3 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                                />
                            </div>

                            {/* End Date */}
                            <div>
                                <label className="mb-1.5 block text-sm font-medium text-gray-700">
                                    End Date
                                </label>

                                <input
                                    type="date"
                                    value={endDate}
                                    onChange={(e) => setEndDate(e.target.value)}
                                    className="h-10 w-full rounded-lg border border-gray-300 px-3 text-sm outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
                                />
                            </div>

                            {/* Assign Manager */}
                            <div>
                                <label className="mb-1.5 block text-sm font-medium text-gray-700">
                                    Assign Manager
                                </label>

                                <Select<SelectOption, false>
                                    options={managerOptions}
                                    value={assignedManager}
                                    onChange={(selectedOption) =>
                                        setAssignedManager(selectedOption)
                                    }
                                    placeholder="Select Manager"
                                    styles={getSelectStyles()}
                                    isSearchable={false}
                                    isClearable
                                />

                            </div>
                        </div>

                        {/* Footer */}
                        <div className="flex justify-end gap-3 border-t rounded-md bg-gray-50 px-6 py-4">
                            <button
                                type="button"
                                onClick={() => setShowConvertModal(false)}
                                className="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                onClick={() => {
                                    // Your conversion logic here
                                    console.log({
                                        quotationId: quotation.id,
                                        startDate,
                                        endDate,
                                        assignedManager,
                                    });

                                    setShowConvertModal(false);
                                }}
                                className="inline-flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-700"
                            >
                                <ArrowRightIcon size={16} weight="bold" />
                                Convert to Project
                            </button>
                        </div>
                    </div>
                </div>
            )}

        </div>
    );
};


const boqItemColumns: DataTableColumn<BOQItem>[] = [
    {
        key: "index",
        label: "#",
        width: "50px",
        align: "center",
        render: (_item, index) => (
            <span className="text-xs text-slate-500">
                {index + 1}
            </span>
        ),
    },
    {
        key: "moduleCategory",
        label: "Module / Category",
        width: "200px",
        align: "left",
        render: (item) => (
            <div className="flex flex-col justify-center">
                <span className="text-xs font-semibold leading-4 text-slate-700">
                    {item.module}
                </span>

                <span className="mt-0.5 text-[10px] leading-4 text-slate-500">
                    {item.category}
                </span>
            </div>
        ),
    },
    {
        key: "description",
        label: "Description",
        width: "320px",
        align: "left",
        render: (item) => (
            <span className="text-xs leading-4 text-slate-600">
                {item.description}
            </span>
        ),
    },
    {
        key: "unitQuantity",
        label: "Unit / Qty",
        width: "120px",
        align: "center",
        sortable: true,
        render: (item) => (
            <div className="flex items-center justify-center gap-2 whitespace-nowrap">
                <span className="text-xs font-semibold text-slate-700">
                    {item.quantity}
                </span>

                <span className="text-[10px] text-slate-400">
                    {item.unit}
                </span>
            </div>
        ),
    },
    {
        key: "rate",
        label: "Rate",
        width: "120px",
        align: "right",
        sortable: true,
        render: (item) => (
            <span className="whitespace-nowrap text-xs text-slate-600">
                $ {formatCurrency(item.rate)}
            </span>
        ),
    },
    {
        key: "total",
        label: "Total",
        width: "130px",
        align: "right",
        sortable: true,
        render: (item) => (
            <span className="whitespace-nowrap text-xs font-semibold text-slate-900">
                $ {formatCurrency(item.total)}
            </span>
        ),
    },
];


const BOQDetailsTab = ({
    quotation,
    boqItems,
    manualItems,
    subtotal,
    manualTotal,
    totalItems,
    contingency,
    grandTotal,
    formatCurrency,
}: {
    quotation: ProjectBOQQuotation;
    boqItems: BOQItem[];
    manualItems: ManuallyCreatedItem[];
    subtotal: number;
    manualTotal: number;
    totalItems: number;
    contingency: number;
    grandTotal: number;
    formatCurrency: (value: number) => string;
    awardedVendor?: string;
}) => {
    return (
        <div className="space-y-6">
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-5">
                <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">
                    Project Information
                </h3>

                <div className="mt-3 grid grid-cols-2 gap-4">
                    <div>
                        <p className="text-xs text-slate-500">
                            Project Name
                        </p>

                        <p className="text-sm font-semibold text-slate-900">
                            {quotation.projectTitle}
                        </p>
                    </div>

                    <div>
                        <p className="text-xs text-slate-500">
                            Quotation No
                        </p>

                        <p className="text-sm font-semibold text-slate-900">
                            {quotation.quotationNo}
                        </p>
                    </div>

                    <div>
                        <p className="text-xs text-slate-500">
                            Date
                        </p>

                        <p className="text-sm font-semibold text-slate-900">
                            {quotation.date}
                        </p>
                    </div>

                    <div>
                        <p className="text-xs text-slate-500">
                            Category
                        </p>

                        <p className="text-sm font-semibold text-slate-900">
                            {quotation.category}
                        </p>
                    </div>

                    <div className="col-span-2">
                        <p className="text-xs text-slate-500">
                            Vendors
                        </p>

                        <div className="mt-1 flex flex-wrap gap-2">
                            {quotation.vendor.map(
                                (vendor, index) => (
                                    <span
                                        key={index}
                                        className="rounded-md bg-white px-3 py-1 text-sm font-medium text-slate-700"
                                    >
                                        {vendor}
                                    </span>
                                )
                            )}
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <div className="mb-3 flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">
                        BOQ Items ({boqItems.length})
                    </h3>

                    <span className="text-xs text-slate-500">
                        Subtotal: ${" "}
                        {formatCurrency(subtotal)}
                    </span>
                </div>

                <DataTable
                    columns={boqItemColumns}
                    data={boqItems}
                    rowKey={(item) => item.id}
                    minWidth="900px"
                    emptyMessage="No BOQ items found."
                    footer={
                        <>
                            <tr className="border-t-2 border-slate-200 bg-slate-50">
                                
                                <td
                                    colSpan={5}
                                    className="px-2.5 py-2.5 text-right text-xs font-semibold text-slate-700"
                                >
                                    Subtotal
                                </td>

                                <td className="px-2.5 py-2.5 text-right text-xs font-bold text-slate-900">
                                    ${" "}
                                    {formatCurrency(
                                        subtotal
                                    )}
                                </td>
                            </tr>

                            {manualTotal > 0 && (
                                <tr className="bg-amber-50">
                                    <td
                                        colSpan={5}
                                        className="px-2.5 py-2.5 text-right text-xs font-semibold text-amber-700"
                                    >
                                        Manual Additions
                                    </td>

                                    <td className="px-2.5 py-2.5 text-right text-xs font-bold text-amber-700">
                                        ${" "}
                                        {formatCurrency(
                                            manualTotal
                                        )}
                                    </td>
                                </tr>
                            )}

                            <tr className="bg-slate-50">
                                <td
                                    colSpan={5}
                                    className="px-2.5 py-2.5 text-right text-xs font-semibold text-slate-700"
                                >
                                    Contingency (10%)
                                </td>

                                <td className="px-2.5 py-2.5 text-right text-xs font-bold text-slate-900">
                                    ${" "}
                                    {formatCurrency(
                                        contingency
                                    )}
                                </td>
                            </tr>

                            <tr className="border-t border-red-200 bg-red-50">
                                <td
                                    colSpan={5}
                                    className="px-2.5 py-3 text-right text-xs font-bold text-red-600"
                                >
                                    Grand Total
                                </td>

                                <td className="px-2.5 py-3 text-right text-base font-bold text-red-600">
                                    ${" "}
                                    {formatCurrency(
                                        grandTotal
                                    )}
                                </td>
                            </tr>
                        </>
                    }
                />
            </div>
        </div>
    );
};


const ComparisonTab = ({
    quotation,
    boqItems,
    masterRates,
    formatCurrency,
    getVarianceStatus,
    quoteRows = [],
    liveComparisons = {},
    onAward,
}: {
    quotation: ProjectBOQQuotation;
    boqItems: BOQItem[];
    masterRates: MasterRateItem[];
    formatCurrency: (value: number) => string;
    quoteRows?: any[];
    liveComparisons?: Record<string, any[]>;
    onAward?: (vendorId: string, remarks: string) => Promise<void>;
    getVarianceStatus: (
        variance: number
    ) => {
        color: string;
        bg: string;
        label: string;
        icon: React.ElementType;
    };
}) => {

    // 1. STATE — keep this here
    const [vendorAction, setVendorAction] = useState<
        "" | "awarded" | "converted" | "quotation"
    >("");

    // 2. LIVE VENDOR RATES
    const eligibleQuotes = quoteRows.filter((row: any) => ["Submitted", "Form Approved", "Awarded"].includes(String(row.status)));
    const vendorNames = eligibleQuotes.length
        ? eligibleQuotes.map((row: any) => String(row.vendorName ?? row.vendor ?? "Vendor"))
        : quoteRows.map((row: any) => String(row.vendorName ?? row.vendor ?? "Vendor"));

    const vendorIdByName = new Map(eligibleQuotes.map((row: any) => [
        String(row.vendorName ?? row.vendor ?? "Vendor"),
        String(row.vendorId ?? row.vendor ?? ""),
    ]));

    const getLiveLine = (row: any, boqItem: BOQItem) => {
        const quotationId = String(row.id ?? row._id ?? "");
        const rows = liveComparisons[quotationId] || [];
        const boqLineId = String(boqItem.boqLineId ?? "");
        const masterRateItemId = String(boqItem.masterRateItemId ?? "");
        const sourceLines = [
            ...(Array.isArray(row.lines) ? row.lines : []),
            ...(Array.isArray(row.manualAdditions) ? row.manualAdditions : []),
        ];
        const liveMatch = rows.find((item: any) =>
            (boqLineId && String(item.boqLineId ?? "") === boqLineId)
            || (masterRateItemId && String(item.masterRateItemId ?? item.marketRateItemId ?? "") === masterRateItemId)
        );
        const sourceMatch = sourceLines.find((item: any) =>
            (boqLineId && String(item.boqLineId ?? item.id ?? item._id ?? "") === boqLineId)
            || (masterRateItemId && String(item.masterRateItemId ?? item.marketRateItemId ?? "") === masterRateItemId)
        );
        return liveMatch || sourceMatch || {};
    };

    // 3. BUILD COMPARISON DATA FROM SERVER-SIDE QUOTATION COMPARISONS
    const comparisonData: ComparisonItem[] = boqItems.map((boqItem) => {
        const masterMatch: any = masterRates.find((item) =>
            (boqItem.boqLineId && item.boqLineId === boqItem.boqLineId)
            || (boqItem.masterRateItemId && item.masterRateItemId === boqItem.masterRateItemId)
        ) || {};
        const benchmarkSource = eligibleQuotes[0] ? getLiveLine(eligibleQuotes[0], boqItem) : {};
        const benchmark = Number(benchmarkSource.masterRate ?? masterMatch.standardRate ?? boqItem.rate ?? 0);
        const variance = benchmark > 0 ? ((Number(boqItem.rate ?? 0) - benchmark) / benchmark) * 100 : 0;
        const vendors: VendorQuote[] = vendorNames.map((vendor) => {
            const quoteRow = eligibleQuotes.find((row: any) => String(row.vendorName ?? row.vendor ?? "Vendor") === vendor);
            const line = quoteRow ? getLiveLine(quoteRow, boqItem) : {};
            const vendorRate = Number(line.vendorRate ?? line.quotedRate ?? line.salesPrice ?? 0);
            const vendorVariance = benchmark > 0 ? ((vendorRate - benchmark) / benchmark) * 100 : 0;
            return { vendor, rate: vendorRate, variance: vendorVariance };
        });
        return {
            ...boqItem,
            masterRate: benchmark,
            variance,
            lastUpdated: String(benchmarkSource.updatedAt ?? masterMatch.lastUpdated ?? "").slice(0, 10),
            status: getVarianceStatus(variance),
            vendors,
        };
    });

    // 4. EXISTING SUMMARY LOGIC
    const totalVariance =
        comparisonData.reduce(
            (sum, item) =>
                sum + item.variance,
            0
        );

    const avgVariance =
        totalVariance /
        (comparisonData.length || 1);


    // 5. VENDOR HELPER — MUST COME BEFORE vendorTotals
    const getVendorQuote = (
        item: ComparisonItem,
        vendor: string
    ) => {
        return item.vendors.find(
            (quote) =>
                quote.vendor === vendor
        );
    };


    // 6. VENDOR LOWEST RATE HELPER
    const getLowestRate = (
        item: ComparisonItem
    ) => {
        const rates = item.vendors
            .map((quote) => quote.rate)
            .filter(
                (rate) =>
                    Number.isFinite(rate) &&
                    rate > 0
            );

        return rates.length > 0
            ? Math.min(...rates)
            : null;
    };


    // 7. NOW calculate vendor totals
    // comparisonData and getVendorQuote both exist here
    const vendorTotals = vendorNames.map((vendor) => {

        const total = comparisonData.reduce(
            (sum, item) => {

                const quote =
                    getVendorQuote(item, vendor);

                return (
                    sum +
                    (quote?.rate || 0) *
                    item.quantity
                );
            },
            0
        );

        return {
            vendor,
            total,
        };
    });


    // 8. FIND LOWEST VENDOR
    const lowestQuoteVendor =
        vendorTotals.length > 0
            ? vendorTotals.reduce(
                (lowest, current) =>
                    current.total < lowest.total
                        ? current
                        : lowest,
                vendorTotals[0]
            )
            : undefined;

              const [selectedVendor, setSelectedVendor] = useState("");
              const [awardRemarks, setAwardRemarks] = useState("");
              const [awarding, setAwarding] = useState(false);

              const handleAwardVendor = async (vendor: string, remarks: string) => {
                    const vendorId = vendorIdByName.get(vendor) || "";
                    if (!vendorId || !remarks.trim() || !onAward) return;
                    setAwarding(true);
                    try {
                        await onAward(vendorId, remarks.trim());
                        setAwardRemarks("");
                    } catch (error: any) {
                        window.alert(error?.response?.data?.message || error?.message || "Failed to award vendor.");
                    } finally {
                        setAwarding(false);
                    }
              };

    return (
        <div className="space-y-6">
            {/* =================================================
                SUMMARY CARDS
            ================================================= */}

            <div className="grid grid-cols-4 gap-4">
                <div className="rounded-xl border border-slate-200 bg-white p-4">
                    <p className="text-xs text-slate-500">
                        Total Items
                    </p>

                    <p className="text-2xl font-bold text-slate-900">
                        {comparisonData.length}
                    </p>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-4">
                    <p className="text-xs text-slate-500">
                        Above Master Rate
                    </p>

                    <p className="text-2xl font-bold text-red-600">
                        {
                            comparisonData.filter(
                                (item) =>
                                    item.variance >
                                    5
                            ).length
                        }
                    </p>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-4">
                    <p className="text-xs text-slate-500">
                        Below Master Rate
                    </p>

                    <p className="text-2xl font-bold text-emerald-600">
                        {
                            comparisonData.filter(
                                (item) =>
                                    item.variance <
                                    -5
                            ).length
                        }
                    </p>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-4">
                    <p className="text-xs text-slate-500">
                        Average Variance
                    </p>

                    <p
                        className={`text-2xl font-bold ${
                            avgVariance > 0
                                ? "text-red-600"
                                : "text-emerald-600"
                        }`}
                    >
                        {avgVariance > 0
                            ? "+"
                            : ""}
                        {avgVariance.toFixed(1)}
                        %
                    </p>
                </div>
            </div>

            {/* =================================================
                COMPARISON TABLE
            ================================================= */}

            <div>
                <div className="mb-3 flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">
                        Vendor Rate Comparison
                    </h3>

                    <span className="text-xs text-slate-500">
                        Master Rate Updated:{" "}
                        {masterRates[0]
                            ?.lastUpdated ||
                            "N/A"}
                    </span>
                </div>

                <div className="overflow-hidden rounded-xl border border-slate-200">
                    <div className="overflow-x-auto">
                        <table className="min-w-max w-full border-collapse">
                           <thead>
                                {/* MAIN HEADER ROW */}
                                <tr className="bg-slate-50">
                                    {/* MODULE / CATEGORY */}
                                    <th
                                        rowSpan={2}
                                        className="
                                            sticky left-0

                                            border-b border-r border-slate-200
                                            bg-slate-50
                                            px-3 py-3
                                            text-left text-[10px] font-bold text-slate-600
                                        "
                                    >
                                        Module / Category
                                    </th>

                                    {/* QUANTITY / UNIT */}
                                    <th
                                        rowSpan={2}
                                        className="
                                            sticky left-[200px]
                                            w-[120px]
                                            border-b border-r border-slate-200
                                            bg-slate-50
                                            px-3 py-3
                                            text-center text-[10px] font-bold text-slate-600
                                        "
                                    >
                                        Quantity / Unit
                                    </th>

                                    {/* RATE */}
                                    <th
                                        rowSpan={2}
                                        className="
                                            sticky left-[320px]
                                            w-[120px]
                                            border-b border-r-2 border-slate-300
                                            bg-slate-50
                                            px-3 py-3
                                            text-right text-[10px] font-bold text-slate-600
                                        "
                                    >
                                        Rate
                                    </th>

                                    {/* VENDOR GROUP HEADERS */}
                                    {vendorNames.map((vendor) => (
                                        <th
                                            key={vendor}
                                            colSpan={2}
                                            className="
                                                w-[195px]
                                                border-b border-r border-slate-200
                                                bg-slate-100
                                                px-3 py-3
                                                text-center text-[10px] font-bold text-slate-700
                                            "
                                        >
                                            {vendor}
                                        </th>
                                    ))}
                                </tr>

                                {/* VENDOR SUB HEADERS */}
                                <tr className="bg-slate-50">
                                    {vendorNames.map((vendor) => (
                                        <React.Fragment key={vendor}>
                                            {/* VENDOR RATE */}
                                            <th
                                                className="
                                                    w-[115px]
                                                    border-b border-r border-slate-200
                                                    bg-slate-50
                                                    px-3 py-2
                                                    text-right text-[9px] font-semibold text-slate-500
                                                "
                                            >
                                                Rate
                                            </th>

                                            {/* VENDOR VARIANCE */}
                                            <th
                                                className="
                                                    w-[80px] min-w-[80px]
                                                    border-b border-r border-slate-200
                                                    bg-slate-50
                                                    px-3 py-2
                                                    text-right text-[9px] font-semibold text-slate-500
                                                "
                                            >
                                                %
                                            </th>
                                        </React.Fragment>
                                    ))}
                                </tr>
                            </thead>


                            <tbody>
                                {comparisonData.map(
                                    (item,index) => {
                                        const lowestRate = getLowestRate(item);
                                        return (
                                            <tr
                                                key={item.id}
                                                className="border-b border-slate-100 hover:bg-slate-50">
                                                <td className="sticky left-0 w-[200px]  border-r border-slate-100 bg-white px-3 py-3">
                                                    <div className="flex flex-col">
                                                        <span className="text-xs font-semibold leading-4 text-slate-700">
                                                            {item.module}
                                                        </span>

                                                        <span className="mt-0.5 text-[10px] leading-4 text-slate-500">
                                                            {item.category}
                                                        </span>
                                                    </div>
                                                </td>

                                                {/* =================================================
                                                    STATIC COLUMN 2
                                                ================================================= */}

                                                <td className="sticky left-[200px]  w-[120px]  border-r border-slate-100 bg-white px-3 py-3 text-center">
                                                    <div className="flex flex-col items-center">
                                                        <span className="text-xs font-semibold text-slate-700">
                                                            {
                                                                item.quantity
                                                            }
                                                        </span>

                                                        <span className="text-[9px] text-slate-400">
                                                            {
                                                                item.unit
                                                            }
                                                        </span>
                                                    </div>
                                                </td>

                                                {/* =================================================
                                                    STATIC COLUMN 3
                                                ================================================= */}

                                                <td className="sticky left-[320px]  w-[120px]  border-r-2 border-slate-300 bg-white px-3 py-3 text-right">
                                                    <span className="whitespace-nowrap text-xs font-semibold text-slate-700">
                                                        ${" "}
                                                        {formatCurrency(
                                                            item.rate
                                                        )}
                                                    </span>
                                                </td>

                                                {/* =================================================
                                                    VENDOR COLUMNS
                                                ================================================= */}

                                                {vendorNames.map(
                                                    (
                                                        vendor
                                                    ) => {
                                                        const quote =
                                                            getVendorQuote(
                                                                item,
                                                                vendor
                                                            );

                                                        if (
                                                            !quote
                                                        ) {
                                                            return (
                                                                <React.Fragment
                                                                    key={
                                                                        vendor
                                                                    }
                                                                >
                                                                    <td className="w-[115px]  border-r border-slate-100 px-3 py-3 text-right">
                                                                        <span className="text-xs text-slate-300">
                                                                            —
                                                                        </span>
                                                                    </td>

                                                                    <td className="w-[80px]  border-r border-slate-100 px-3 py-3 text-right">
                                                                        <span className="text-xs text-slate-300">
                                                                            —
                                                                        </span>
                                                                    </td>
                                                                </React.Fragment>
                                                            );
                                                        }

                                                        const isLowest =
                                                            lowestRate !==
                                                                null &&
                                                            quote.rate ===
                                                                lowestRate;

                                                        return (
                                                            <React.Fragment
                                                                key={
                                                                    vendor
                                                                }
                                                            >
                                                                {/* VENDOR RATE */}

                                                                <td className="w-[115px]  border-r border-slate-100 px-3 py-3 text-right">
                                                                    <span
                                                                        className={`inline-flex whitespace-nowrap rounded-md px-2 py-1 text-xs font-semibold ${
                                                                            isLowest
                                                                                ? "bg-emerald-100 text-emerald-700"
                                                                                : "text-slate-700"
                                                                        }`}
                                                                    >
                                                                        ${" "}
                                                                        {formatCurrency(
                                                                            quote.rate
                                                                        )}
                                                                    </span>
                                                                </td>

                                                                {/* VENDOR % */}

                                                                <td className="w-[80px]  border-r border-slate-100 px-3 py-3 text-right">
                                                                    <span
                                                                        className={`inline-flex whitespace-nowrap rounded-md px-2 py-1 text-xs font-bold ${
                                                                            quote.variance >
                                                                            0
                                                                                ? "text-red-600"
                                                                                : quote.variance <
                                                                                    0
                                                                                  ? "text-emerald-600"
                                                                                  : "text-slate-500"
                                                                        }`}
                                                                    >
                                                                        {quote.variance >
                                                                        0
                                                                            ? "+"
                                                                            : ""}
                                                                        {quote.variance.toFixed(
                                                                            1
                                                                        )}
                                                                        %
                                                                    </span>
                                                                </td>
                                                            </React.Fragment>
                                                        );
                                                    }
                                                )}
                                            </tr>
                                        );
                                    }
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {/* =================================================
                LEGEND
            ================================================= */}

            <div className="flex flex-wrap items-center gap-5 text-[10px] text-slate-500">
                <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                    Lowest vendor rate
                </div>

                <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-red-500" />
                    Above BOQ rate
                </div>

                <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                    Below BOQ rate
                </div>
            </div>
                
           {(quotation.status === "Pending Approval" || quotation.status === "Generated Quotation") && quoteRows.some((item: any) => ["Submitted", "Form Approved", "Awarded"].includes(String(item.status))) && (
                <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-4">
                    <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                            <CheckCircleIcon size={16} weight="bold" />
                        </div>

                        <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-3">
                                <div>
                                    <h4 className="text-sm font-semibold text-emerald-900">
                                        Vendor Awarding
                                    </h4>

                                    <p className="mt-0.5 text-xs text-emerald-700">
                                        Select the vendor to award this quotation.
                                    </p>
                                </div>

                                <span className="shrink-0 rounded-full bg-emerald-100 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-emerald-700">
                                    Lowest Quote
                                </span>
                            </div>
                        </div>
                    </div>

                    {lowestQuoteVendor && (
                        <div className="mt-4 overflow-hidden rounded-lg border border-emerald-200 bg-white">
                            {/* Recommended Vendor / Total Quote */}
                            <div className="flex items-center justify-between gap-4 px-4 py-3">
                                <div className="min-w-0">
                                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                                        Recommended Vendor
                                    </p>

                                    <p className="mt-1 truncate text-sm font-semibold text-slate-900">
                                        {lowestQuoteVendor.vendor}
                                    </p>
                                </div>

                                <div className="shrink-0 text-right">
                                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                                        Total Quote
                                    </p>

                                    <p className="mt-1 text-sm font-bold text-emerald-600">
                                        $ {formatCurrency(lowestQuoteVendor.total)}
                                    </p>
                                </div>
                            </div>

                            {/* Vendor Selection */}
                            <div className="border-t border-slate-100 px-4 py-3">
                                <div className="mb-2 flex items-center justify-between">
                                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                                        Select Vendor
                                    </p>

                                    {selectedVendor && (
                                        <span className="text-[11px] font-semibold text-emerald-600">
                                            Selected: {selectedVendor}
                                        </span>
                                    )}
                                </div>

                                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                                    {vendorNames.map((vendor) => {
                                        const isSelected = selectedVendor === vendor;
                                        const isRecommended =
                                            lowestQuoteVendor.vendor === vendor;

                                        return (
                                            <button
                                                key={vendor}
                                                type="button"
                                                onClick={() => setSelectedVendor(vendor)}
                                                className={`flex min-h-[44px] items-center justify-between rounded-lg border px-3 py-2 text-left transition ${
                                                    isSelected
                                                        ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                                                        : "border-slate-200 bg-white text-slate-700 hover:border-emerald-300 hover:bg-emerald-50/40"
                                                }`}
                                            >
                                                <div className="flex min-w-0 items-center gap-2">
                                                    <span
                                                        className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full border ${
                                                            isSelected
                                                                ? "border-emerald-500 bg-emerald-500"
                                                                : "border-slate-300"
                                                        }`}
                                                    >
                                                        {isSelected && (
                                                            <span className="h-1.5 w-1.5 rounded-full bg-white" />
                                                        )}
                                                    </span>

                                                    <span className="truncate text-xs font-semibold">
                                                        {vendor}
                                                    </span>
                                                </div>

                                                {isRecommended && (
                                                    <span className="ml-2 shrink-0 text-[9px] font-bold uppercase tracking-wide text-emerald-600">
                                                        Lowest
                                                    </span>
                                                )}
                                            </button>
                                        );
                                    })}
                                </div>
                            </div>

                            {/* Remarks + Award */}
                            <div className="border-t border-slate-100 px-4 py-3">
                                <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
                                    {/* Remarks */}
                                    <div className="min-w-0 flex-1">
                                        <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                                            Remarks
                                        </label>

                                        <textarea
                                            value={awardRemarks}
                                            onChange={(e) => setAwardRemarks(e.target.value)}
                                            placeholder="Enter remarks"
                                            rows={2}
                                            className="block w-full resize-none rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
                                        />
                                    </div>

                                    {/* Award Button */}
                                    <button
                                        type="button"
                                        disabled={!selectedVendor || !awardRemarks.trim() || awarding}
                                        onClick={() =>
                                            handleAwardVendor(selectedVendor, awardRemarks)
                                        }
                                        className="inline-flex h-9 shrink-0 items-center justify-center rounded-lg bg-emerald-600 px-5 text-xs font-semibold text-white shadow-sm transition hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-200 disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400"
                                    >
                                        {awarding ? "Awarding..." : "Award Vendor"}
                                    </button>
                                </div>
                            </div>

                            {/* Footer */}
                            <div className="flex items-center justify-between gap-3 border-t border-slate-100 px-4 py-2.5">
                                <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                                    <ArrowRightIcon
                                        size={12}
                                        className="text-emerald-500"
                                    />

                                    <span>
                                        {vendorNames.length} vendors available
                                    </span>
                                </div>
                            </div>
                        </div>
                    )}


                </div>
            )}


        </div>
    );
};

/* =========================================================
   MANUAL ITEMS TAB
========================================================= */

const ManualItemsTab = ({
    manualItems,
    formatCurrency,
}: {
    manualItems: ManuallyCreatedItem[];
    formatCurrency: (value: number) => string;
}) => {
    const total = manualItems.reduce(
        (sum, item) => sum + item.total,
        0
    );

    const manualItemColumns: DataTableColumn<ManuallyCreatedItem>[] =
        [
            {
                key: "index",
                label: "#",
                width: "50px",
                render: (_item, index) => (
                    <span className="text-xs text-slate-500">
                        {index + 1}
                    </span>
                ),
            },
            {
                key: "module",
                label: "Module",
                width: "120px",
                render: (item) => (
                    <span className="text-xs font-medium text-slate-700">
                        {item.module}
                    </span>
                ),
            },
            {
                key: "category",
                label: "Category",
                width: "120px",
                render: (item) => (
                    <span className="text-xs text-slate-600">
                        {item.category}
                    </span>
                ),
            },
            {
                key: "description",
                label: "Description",
                width: "280px",
                render: (item) => (
                    <div>
                        <div className="text-xs text-slate-600">
                            {item.description}
                        </div>

                        {item.notes && (
                            <p className="mt-0.5 text-[10px] text-slate-400">
                                Note:{" "}
                                {item.notes}
                            </p>
                        )}
                    </div>
                ),
            },
            {
                key: "unit",
                label: "Unit",
                width: "80px",
                render: (item) => (
                    <span className="text-xs text-slate-600">
                        {item.unit}
                    </span>
                ),
            },
            {
                key: "quantity",
                label: "Qty",
                width: "70px",
                align: "right",
                sortable: true,
                render: (item) => (
                    <span className="text-xs font-medium text-slate-700">
                        {item.quantity}
                    </span>
                ),
            },
            {
                key: "rate",
                label: "Rate",
                width: "110px",
                align: "right",
                sortable: true,
                render: (item) => (
                    <span className="text-xs text-slate-600">
                        ${" "}
                        {formatCurrency(
                            item.rate
                        )}
                    </span>
                ),
            },
            {
                key: "total",
                label: "Total",
                width: "120px",
                align: "right",
                sortable: true,
                render: (item) => (
                    <span className="text-xs font-semibold text-amber-700">
                        ${" "}
                        {formatCurrency(
                            item.total
                        )}
                    </span>
                ),
            },
        ];

    return (
        <div className="space-y-6">
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
                <div className="flex items-start gap-3">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-amber-100 text-amber-600">
                        <FileTextIcon
                            size={16}
                            weight="bold"
                        />
                    </div>

                    <div>
                        <h4 className="text-sm font-semibold text-amber-900">
                            Manually Created Items
                        </h4>

                        <p className="text-sm text-amber-800">
                            These items were manually added to the quotation and are not from the master rate schedule.
                        </p>
                    </div>
                </div>
            </div>

            {manualItems.length === 0 ? (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-8 text-center">
                    <p className="text-sm text-slate-500">
                        No manual items added to this quotation.
                    </p>
                </div>
            ) : (
                <>
                    <DataTable
                        columns={manualItemColumns}
                        data={manualItems}
                        rowKey={(item) => item.id}
                        emptyMessage="No manual items found."
                    />

                    <div className="grid grid-cols-2 gap-4">
                        <div className="rounded-xl border border-slate-200 p-4">
                            <p className="text-xs text-slate-500">
                                Created By
                            </p>

                            <div className="mt-1 space-y-1">
                                {manualItems.map(
                                    (item) => (
                                        <p
                                            key={
                                                item.id
                                            }
                                            className="text-sm text-slate-700"
                                        >
                                            {
                                                item.createdBy
                                            }{" "}
                                            <span className="text-xs text-slate-400">
                                                (
                                                {
                                                    item.createdAt
                                                }
                                                )
                                            </span>
                                        </p>
                                    )
                                )}
                            </div>
                        </div>

                        <div className="rounded-xl border border-slate-200 p-4">
                            <p className="text-xs text-slate-500">
                                Total Manual Additions
                            </p>

                            <p className="mt-1 text-2xl font-bold text-amber-700">
                                ${" "}
                                {formatCurrency(
                                    total
                                )}
                            </p>

                            <p className="mt-1 text-xs text-slate-500">
                                {manualItems.length}{" "}
                                items added manually
                            </p>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};

/* =========================================================
   PAYMENT TAB
========================================================= */

const PaymentTab = ({
    vendorSchedules,
    formatCurrency,
}: {
    vendorSchedules: Array<{
        id: string;
        vendor: string;
        currency: string;
        grandTotal: number;
        installments: Array<{
            id: string;
            installmentName: string;
            module: string;
            amount: number;
            dueDate: string;
        }>;
    }>;
    formatCurrency: (value: number) => string;
}) => {
    return (
        <div className="space-y-6">
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                <div className="border-b border-slate-200 bg-slate-50 px-5 py-4">
                    <h3 className="text-sm font-bold text-slate-800">
                        Vendor Payment Schedule
                    </h3>

                    <p className="mt-1 text-xs text-slate-500">
                        Payment installment details for each vendor.
                    </p>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full min-w-[1100px] border-collapse">
                        <thead>
                            <tr className="bg-slate-50">
                                <th className="w-[180px] border-b border-r border-slate-200 px-4 py-4 text-left text-xs font-bold uppercase tracking-wide text-slate-500">
                                    Payment Details
                                </th>

                                {vendorSchedules.map((vendor) => (
                                    <th
                                        key={vendor.id}
                                        className="border-b border-r border-slate-200 px-4 py-4 text-left text-sm font-bold text-slate-800 last:border-r-0"
                                    >
                                        <div className="flex items-center justify-between">
                                            <span>{vendor.vendor}</span>
                                            <span className="rounded-full bg-blue-50 px-2 py-1 text-[10px] font-bold text-blue-700">
                                                {vendor.installments.length}
                                            </span>
                                        </div>
                                    </th>
                                ))}
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td className="border-r border-slate-200 bg-slate-50 px-4 py-4 align-top">
                                    <div className="space-y-2">
                                        <p className="text-xs font-semibold text-slate-600">
                                            Installments
                                        </p>

                                        <p className="text-[11px] leading-5 text-slate-400">
                                            Each vendor's payment schedule,
                                            amount and due date.
                                        </p>
                                    </div>
                                </td>

                                {vendorSchedules.length === 0 ? (
                                    <td colSpan={1} className="px-4 py-4 align-top">
                                        <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-6 text-center">
                                            <p className="text-xs text-slate-400">
                                                No payment schedule configured
                                            </p>
                                        </div>
                                    </td>
                                ) : vendorSchedules.map((vendor, vendorIndex) => (
                                    <td
                                        key={vendor.id}
                                        className={`px-4 py-4 align-top ${vendorIndex < vendorSchedules.length - 1 ? "border-r border-slate-200" : ""}`}
                                    >
                                        {vendor.installments.length > 0 ? (
                                            <div className="space-y-3">
                                                {vendor.installments.map((item, index) => {
                                                    const dueDate = item.dueDate ? new Date(`${item.dueDate}T00:00:00`) : null;
                                                    const validDueDate = dueDate && !Number.isNaN(dueDate.getTime());

                                                    return (
                                                        <div
                                                            key={item.id}
                                                            className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm transition hover:border-slate-300 hover:shadow-md"
                                                        >
                                                            <div className="flex items-start gap-2">
                                                                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-red-50 text-[10px] font-bold text-red-600">
                                                                    {index + 1}
                                                                </span>

                                                                <div className="min-w-0 flex-1">
                                                                    <p
                                                                        className="truncate text-sm font-semibold text-slate-800"
                                                                        title={item.installmentName}
                                                                    >
                                                                        {item.installmentName}
                                                                    </p>

                                                                    <p
                                                                        className="mt-0.5 truncate text-[11px] text-slate-400"
                                                                        title={item.module}
                                                                    >
                                                                        {item.module || "-"}
                                                                    </p>
                                                                </div>
                                                            </div>

                                                            <div className="mt-3 grid grid-cols-2 gap-3 border-t border-slate-100 pt-3">
                                                                <div className="min-w-0">
                                                                    <p className="text-[10px] font-medium uppercase tracking-wide text-slate-400">
                                                                        Amount
                                                                    </p>

                                                                    <p className="mt-1 truncate text-sm font-bold text-emerald-600">
                                                                        {vendor.currency} {formatCurrency(item.amount)}
                                                                    </p>
                                                                </div>

                                                                <div className="min-w-0">
                                                                    <p className="text-[10px] font-medium uppercase tracking-wide text-slate-400">
                                                                        Due Date
                                                                    </p>

                                                                    <p className="mt-1 whitespace-nowrap text-xs font-semibold text-slate-700">
                                                                        {validDueDate
                                                                            ? dueDate.toLocaleDateString("en-GB", {
                                                                                day: "2-digit",
                                                                                month: "short",
                                                                                year: "numeric",
                                                                            })
                                                                            : "-"}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        ) : (
                                            <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-6 text-center">
                                                <p className="text-xs text-slate-400">
                                                    No payment schedule configured
                                                </p>
                                            </div>
                                        )}
                                    </td>
                                ))}
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default ViewQuotationDrawer;
