    import { useEffect, useMemo, useState } from "react";
    import {
        MagnifyingGlassIcon,
        PlusIcon,
    } from "@phosphor-icons/react";
    import Select, { MultiValue } from "react-select";

    import OffCanvas from "../../components/OffCanvas";
    import { RateItem } from "../../types/rateSchedule";
    import { listActiveMasterRates } from "../../api/quotationApi";

    interface BrowseAddRateProps {
        isOpen: boolean;
        onClose: () => void;
        onAddRates: (rateItems: RateItem[]) => void;
    }

    interface ModuleOption {
        id: string;
        code: string;
        module: string;
        description: string;
    }

    interface CategoryOption {
        value: string;
        label: string;
    }

    const BrowseAddRate = ({
        isOpen,
        onClose,
        onAddRates,
    }: BrowseAddRateProps) => {
        const [search, setSearch] = useState<string>("");

        const [selectedCategories, setSelectedCategories] =
            useState<CategoryOption[]>([]);

        const [selectedRateIds, setSelectedRateIds] =
            useState<string[]>([]);

        const [rateData, setRateData] = useState<RateItem[]>([]);

        const getRateId = (rate: any) => String(rate?.id ?? rate?._id ?? rate?.itemId ?? "").trim();
        const getRateCategory = (rate: any) => typeof rate?.category === "object"
            ? String(rate.category?.label ?? rate.category?.name ?? rate.category?.value ?? "").trim()
            : String(rate?.category ?? "").trim();

        useEffect(() => {
            if (!isOpen) return;
            setSelectedRateIds([]);
            let active = true;
            void listActiveMasterRates().then((rows) => {
                if (active) setRateData(Array.isArray(rows) ? rows as RateItem[] : []);
            }).catch((error) => {
                console.error("Failed to load master rate items", error);
                if (active) setRateData([]);
            });
            return () => { active = false; };
        }, [isOpen]);

        const dynamicModules = useMemo<ModuleOption[]>(() => {
            return rateData.map((rate: any) => {
                const id = getRateId(rate);
                const code = String(rate.code ?? "").trim();
                return {
                    id,
                    code,
                    module: String(rate.module ?? rate.subcategory ?? rate.moduleName ?? rate.module_title ?? rate.category ?? "General").trim(),
                    description: String(rate.description ?? rate.itemDescription ?? rate.name ?? "").trim(),
                };
            }).filter((row) => row.id && row.description);
        }, [rateData]);

        const dynamicCategories = useMemo<CategoryOption[]>(() => {
            return Array.from(new Set(rateData.map((rate: any) => String(typeof rate.category === "object" ? (rate.category?.label ?? rate.category?.name ?? rate.category?.value ?? "") : (rate.category ?? "")).trim()).filter(Boolean)))
                .map((value) => ({ value, label: value }));
        }, [rateData]);

        const filteredModules = useMemo(() => {
            const searchValue = search.trim().toLowerCase();

            const selectedCategoryValues =
                selectedCategories.map(
                    (category) => category.value
                );

            return dynamicModules.filter((moduleItem) => {
                const rate: any = rateData.find(
                    (item: any) => getRateId(item) === moduleItem.id
                );

                if (!rate) {
                    return false;
                }

                const rateCategory = getRateCategory(rate);
                const matchesCategory =
                    selectedCategoryValues.length === 0 ||
                    selectedCategoryValues.includes(rateCategory);

                const matchesSearch =
                    !searchValue ||
                    moduleItem.module
                        .toLowerCase()
                        .includes(searchValue) ||
                    moduleItem.description
                        .toLowerCase()
                        .includes(searchValue) ||
                    String(rate.code ?? "")
                        .toLowerCase()
                        .includes(searchValue) ||
                    String(rate.category ?? "")
                        .toLowerCase()
                        .includes(searchValue) ||
                    String(rate.unit ?? "")
                        .toLowerCase()
                        .includes(searchValue);

                return (
                    matchesCategory &&
                    matchesSearch
                );
            });
        }, [search, selectedCategories, dynamicModules, rateData]);

        const toggleRate = (rateId: string) => {
            setSelectedRateIds((current) => {
                if (current.includes(rateId)) {
                    return current.filter(
                        (id) => id !== rateId
                    );
                }

                return [...current, rateId];
            });
        };

        const toggleSelectAll = () => {
            const visibleIds = filteredModules.map((item) => item.id);

            if (visibleIds.length === 0) {
                return;
            }

            const allSelected = visibleIds.every((id) =>
                selectedRateIds.includes(id)
            );

            if (allSelected) {
                setSelectedRateIds((current) =>
                    current.filter(
                        (id) => !visibleIds.includes(id)
                    )
                );
            } else {
                setSelectedRateIds((current) => [
                    ...new Set([
                        ...current,
                        ...visibleIds,
                    ]),
                ]);
            }
        };

        const handleAddRates = () => {
            if (selectedRateIds.length === 0) return;

            const selectedRates = selectedRateIds
                .map((rateId) => rateData.find((rate: any) => getRateId(rate) === rateId))
                .filter(Boolean) as RateItem[];

            if (selectedRates.length === 0) return;

            onAddRates(selectedRates);
            setSelectedRateIds([]);
            setSearch("");
            setSelectedCategories([]);
            onClose();
        };

        const clearSelection = () => {
            setSelectedRateIds([]);
        };

        const resetFilters = () => {
            setSearch("");
            setSelectedCategories([]);
        };

        const allVisibleSelected =
            filteredModules.length > 0 &&
            filteredModules.every((item) =>
                selectedRateIds.includes(item.id)
            );

        return (
            <OffCanvas
                isOpen={isOpen}
                onClose={onClose}
                title="Select Master Rate Item"
                subtitle="Browse and add items from the master rate schedule"
                widthClass="max-w-xl"
                footer={
                    <div className="flex items-center justify-between gap-4">
                        <div className="min-w-0">
                            <p className="text-[10px] font-semibold text-slate-500">
                                {selectedRateIds.length}{" "}
                                {selectedRateIds.length === 1
                                    ? "item"
                                    : "items"}{" "}
                                selected
                            </p>

                            <p className="mt-0.5 text-[9px] text-slate-400">
                                Select one or more master rate items.
                            </p>
                        </div>

                        <div className="flex shrink-0 items-center gap-2">
                            <button
                                type="button"
                                onClick={onClose}
                                className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                disabled={
                                    selectedRateIds.length === 0
                                }
                                onClick={handleAddRates}
                                className="flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2.5 text-xs font-bold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:bg-slate-300"
                            >
                                <PlusIcon
                                    size={14}
                                    weight="bold"
                                />
                                Add Selected Rates
                            </button>
                        </div>
                    </div>
                }
            >
                <div className="space-y-5">
                    <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                        <div className="space-y-4">
                            <div>
                                <p className="mb-2 text-[9px] font-bold uppercase tracking-widest text-slate-400">
                                    Search
                                </p>

                                <div className="relative">
                                    <MagnifyingGlassIcon
                                        size={16}
                                        className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                                    />

                                    <input
                                        type="text"
                                        value={search}
                                        onChange={(e) =>
                                            setSearch(
                                                e.target.value
                                            )
                                        }
                                        placeholder="Search modules or descriptions..."
                                        className="h-10 w-full rounded-lg border border-slate-200 bg-white pl-9 pr-3 text-xs text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-red-400 focus:ring-2 focus:ring-red-100"
                                    />
                                </div>
                            </div>

                            <div>
                                <div className="mb-2 flex items-center justify-between">
                                    <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400">
                                        Category
                                    </p>

                                    {selectedCategories.length > 0 && (
                                        <button
                                            type="button"
                                            onClick={() =>
                                                setSelectedCategories(
                                                    []
                                                )
                                            }
                                            className="text-[9px] font-bold uppercase tracking-wide text-red-600 hover:text-red-700"
                                        >
                                            Clear
                                        </button>
                                    )}
                                </div>

                                <Select<CategoryOption, true>
                                    isMulti
                                    options={dynamicCategories}
                                    value={selectedCategories}
                                    onChange={(
                                        options: MultiValue<CategoryOption>
                                    ) => {
                                        setSelectedCategories(
                                            [...options]
                                        );
                                    }}
                                    placeholder="Select categories..."
                                    closeMenuOnSelect={false}
                                    hideSelectedOptions={false}
                                    isSearchable
                                    styles={{
                                        control: (
                                            base,
                                            state
                                        ) => ({
                                            ...base,
                                            minHeight: "40px",
                                            borderRadius: "8px",
                                            borderColor:
                                                state.isFocused
                                                    ? "#f87171"
                                                    : "#e2e8f0",
                                            boxShadow:
                                                state.isFocused
                                                    ? "0 0 0 2px rgba(254, 226, 226, 1)"
                                                    : "none",
                                            backgroundColor:
                                                "#ffffff",
                                            "&:hover": {
                                                borderColor:
                                                    "#f87171",
                                            },
                                        }),

                                        valueContainer: (
                                            base
                                        ) => ({
                                            ...base,
                                            padding: "2px 8px",
                                        }),

                                        input: (base) => ({
                                            ...base,
                                            fontSize: "12px",
                                            color: "#334155",
                                        }),

                                        placeholder: (
                                            base
                                        ) => ({
                                            ...base,
                                            fontSize: "12px",
                                            color: "#94a3b8",
                                        }),

                                        multiValue: (
                                            base
                                        ) => ({
                                            ...base,
                                            backgroundColor:
                                                "#fef2f2",
                                            borderRadius: "6px",
                                        }),

                                        multiValueLabel: (
                                            base
                                        ) => ({
                                            ...base,
                                            color: "#b91c1c",
                                            fontSize: "10px",
                                            fontWeight: 600,
                                            padding: "3px 6px",
                                        }),

                                        multiValueRemove: (
                                            base
                                        ) => ({
                                            ...base,
                                            color: "#b91c1c",
                                            borderRadius:
                                                "0 6px 6px 0",
                                            ":hover": {
                                                backgroundColor:
                                                    "#fee2e2",
                                                color: "#991b1b",
                                            },
                                        }),

                                        menu: (base) => ({
                                            ...base,
                                            zIndex: 9999,
                                            borderRadius: "8px",
                                            overflow: "hidden",
                                        }),

                                        option: (
                                            base,
                                            state
                                        ) => ({
                                            ...base,
                                            fontSize: "11px",
                                            padding: "9px 12px",
                                            backgroundColor:
                                                state.isSelected
                                                    ? "#fee2e2"
                                                    : state.isFocused
                                                    ? "#f8fafc"
                                                    : "#ffffff",
                                            color:
                                                state.isSelected
                                                    ? "#b91c1c"
                                                    : "#334155",
                                            cursor: "pointer",
                                        }),

                                        indicatorSeparator: (
                                            base
                                        ) => ({
                                            ...base,
                                            backgroundColor:
                                                "#e2e8f0",
                                        }),

                                        dropdownIndicator: (
                                            base,
                                            state
                                        ) => ({
                                            ...base,
                                            color:
                                                state.isFocused
                                                    ? "#dc2626"
                                                    : "#94a3b8",
                                            ":hover": {
                                                color: "#dc2626",
                                            },
                                        }),

                                        clearIndicator: (
                                            base
                                        ) => ({
                                            ...base,
                                            color: "#94a3b8",
                                            ":hover": {
                                                color: "#dc2626",
                                            },
                                        }),
                                    }}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                        <div className="grid grid-cols-[40px_180px_minmax(0,1fr)] items-center border-b border-slate-200 bg-slate-50 px-4 py-3">
                            <div className="flex items-center">
                                <input
                                    type="checkbox"
                                    checked={allVisibleSelected}
                                    onChange={toggleSelectAll}
                                    className="h-3.5 w-3.5 accent-red-600"
                                />
                            </div>

                            <div className="text-[9px] font-bold uppercase tracking-wide text-slate-400">
                                Module
                            </div>

                            <div className="text-[9px] font-bold uppercase tracking-wide text-slate-400">
                                Description
                            </div>
                        </div>

                        {filteredModules.length === 0 ? (
                            <div className="px-6 py-16 text-center">
                                <p className="text-xs font-semibold text-slate-500">
                                    No master rate items found.
                                </p>

                                <p className="mt-1 text-[10px] text-slate-400">
                                    Try changing your search or category filters.
                                </p>

                                <button
                                    type="button"
                                    onClick={resetFilters}
                                    className="mt-3 text-[9px] font-bold uppercase tracking-wide text-red-600 hover:text-red-700"
                                >
                                    Reset Filters
                                </button>
                            </div>
                        ) : (
                            <div>
                                {filteredModules.map(
                                    (item) => {
                                        const selected =
                                            selectedRateIds.includes(
                                                item.id
                                            );

                                        const rate: any = rateData.find(
                                            (rateItem: any) => String(rateItem.id ?? rateItem._id ?? rateItem.itemId ?? rateItem.code) === item.id
                                        );

                                        return (
                                            <div
                                                key={item.id}
                                                onClick={() =>
                                                    toggleRate(
                                                        item.id
                                                    )
                                                }
                                                className={`grid cursor-pointer grid-cols-[40px_180px_minmax(0,1fr)] items-center border-b border-slate-100 px-4 py-3 transition last:border-b-0 ${
                                                    selected
                                                        ? "bg-red-50/60"
                                                        : "hover:bg-slate-50"
                                                }`}
                                            >
                                                <div className="flex items-center">
                                                    <input
                                                        type="checkbox"
                                                        checked={
                                                            selected
                                                        }
                                                        onChange={() =>
                                                            toggleRate(
                                                                item.id
                                                            )
                                                        }
                                                        onClick={(
                                                            e
                                                        ) =>
                                                            e.stopPropagation()
                                                        }
                                                        className="h-3.5 w-3.5 accent-red-600"
                                                    />
                                                </div>

                                                <div className="min-w-0 pr-4">
                                                    <span className="inline-flex max-w-full truncate rounded-md bg-slate-100 px-2 py-1 text-[10px] font-semibold text-slate-600">
                                                        {
                                                            item.module
                                                        }
                                                    </span>
                                                </div>

                                                <div className="min-w-0">
                                                    <p className="text-[11px] font-medium leading-5 text-slate-700">
                                                        {
                                                            item.description
                                                        }
                                                    </p>

                                                    {rate && (
                                                        <div className="mt-1 flex items-center gap-2">
                                                            <span className="text-[9px] text-slate-400">
                                                                {
                                                                    rate.code
                                                                }
                                                            </span>

                                                            <span className="text-[9px] text-slate-300">
                                                                •
                                                            </span>

                                                            <span className="text-[9px] text-slate-400">
                                                                {
                                                                    rate.unit
                                                                }
                                                            </span>

                                                            <span className="text-[9px] text-slate-300">
                                                                •
                                                            </span>

                                                            <span className="text-[9px] font-semibold text-slate-500">
                                                                ${" "}
                                                                {Number(
                                                                    rate.standardRate ??
                                                                        rate.rate ??
                                                                        0
                                                                ).toLocaleString(
                                                                    "en-US",
                                                                    {
                                                                        minimumFractionDigits: 2,
                                                                        maximumFractionDigits: 2,
                                                                    }
                                                                )}
                                                            </span>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    }
                                )}
                            </div>
                        )}
                    </div>

                    <div className="flex items-center justify-between">
                        <p className="text-[9px] font-semibold uppercase tracking-wide text-slate-400">
                            {filteredModules.length}{" "}
                            {filteredModules.length === 1
                                ? "module"
                                : "modules"}{" "}
                            available
                        </p>

                        {selectedRateIds.length > 0 && (
                            <button
                                type="button"
                                onClick={clearSelection}
                                className="text-[9px] font-bold uppercase tracking-wide text-red-600 hover:text-red-700"
                            >
                                Clear Selection
                            </button>
                        )}
                    </div>
                </div>
            </OffCanvas>
        );
    };

    export default BrowseAddRate;
