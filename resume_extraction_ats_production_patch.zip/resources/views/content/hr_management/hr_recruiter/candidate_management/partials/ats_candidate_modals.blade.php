<style>
.vip-profile-card{
        background:#fff;
        border-radius:16px;
        padding:25px;
        box-shadow:0 3px 20px rgba(0,0,0,.08);
    }

    .vip-avatar{
        width:90px;
        height:90px;
        border-radius:50%;
        background:linear-gradient(
            135deg,
            #f59e0b,
            #f97316
        );
        color:#fff;
        font-size:36px;
        font-weight:700;
        display:flex;
        align-items:center;
        justify-content:center;
    }

.candidate-history-timeline{
        position:relative;
        padding-left:40px;
    }

    .history-item{
        position:relative;
        margin-bottom:20px;
    }

    .history-line{
        position:absolute;
        left:-23px;
        top:35px;
        width:2px;
        height:100%;
        background:#e5e7eb;
    }

    .history-item:last-child .history-line{
        display:none;
    }

    .history-dot{
        position:absolute;
        left:-38px;
        top:15px;
        width:30px;
        height:30px;
        border-radius:50%;
        color:#fff;
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:12px;
        font-weight:700;
        box-shadow:0 4px 10px rgba(0,0,0,.15);
    }

    .history-card{
        background:#fff;
        border-radius:12px;
        padding:16px;
        border:1px solid #eef2f7;
        box-shadow:0 3px 10px rgba(0,0,0,.05);
        transition:.2s;
    }

    .history-card:hover{
        transform:translateY(-2px);
        box-shadow:0 8px 18px rgba(0,0,0,.08);
    }

    .history-remarks{
        background:#f8fafc;
        border-left:4px solid #f59e0b;
        padding:12px;
        border-radius:8px;
        margin-top:12px;
    }

.history-profile-card{
        background:#fff;
        border-radius:16px;
        padding:25px;
        box-shadow:0 3px 20px rgba(0,0,0,.08);
    }

    .history-avatar{
        width:90px;
        height:90px;
        border-radius:50%;
        background:linear-gradient(
            135deg,
            #f59e0b,
            #f97316
        );
        color:#fff;
        font-size:36px;
        font-weight:700;
        display:flex;
        align-items:center;
        justify-content:center;
    }

    .history-section{
        background:#fff;
        border-radius:12px;
        padding:20px;
        border:1px solid #eee;
    }

    .history-remark-box{
        border-radius:12px;
        min-height:120px;
    }

.application-answers-wrapper {
        padding: 4px 2px 20px;
    }

    .application-answer-summary {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 18px 20px;
        margin-bottom: 20px;
        border: 1px solid #e8ebf0;
        border-radius: 14px;
        background: linear-gradient(
            135deg,
            #f8fbff,
            #ffffff
        );
    }

    .answer-summary-icon {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #eaf4ff;
        color: #ab2b22;
        font-size: 23px;
    }

    .answer-summary-count {
        min-width: 44px;
        height: 44px;
        padding: 0 12px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #ab2b22;
        color: #fff;
        font-size: 17px;
        font-weight: 700;
    }

    .application-answer-list {
        display: flex;
        flex-direction: column;
        gap: 14px;
    }

    .application-answer-card {
        display: flex;
        gap: 16px;
        padding: 20px;
        background: #fff;
        border: 1px solid #e8ebf0;
        border-radius: 14px;
        transition: all .18s ease;
    }

    .application-answer-card:hover {
        border-color: #cfd8e3;
        box-shadow: 0 5px 18px rgba(20, 40, 80, .07);
    }

    .answer-number {
        flex: 0 0 38px;
        height: 38px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f1f4f8;
        color: #667085;
        font-size: 12px;
        font-weight: 700;
    }

    .answer-card-body {
        flex: 1;
        min-width: 0;
    }

    .answer-question {
        color: #172033;
        font-size: 15px;
        font-weight: 700;
        line-height: 1.5;
    }

    .answer-type {
        display: inline-block;
        margin-top: 5px;
        color: #98a2b3;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: .4px;
        font-weight: 600;
    }

    .answer-value {
        margin-top: 14px;
    }

    .answer-text {
        padding: 12px 14px;
        border-radius: 10px;
        background: #f8fafc;
        color: #344054;
        font-size: 14px;
        line-height: 1.6;
        white-space: normal;
    }

    .answer-badge-list {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }

    .answer-badge {
        display: inline-flex;
        align-items: center;
        padding: 7px 11px;
        border-radius: 8px;
        background: #eef5ff;
        color: #175cd3;
        font-size: 12px;
        font-weight: 600;
    }

    .answer-not-provided {
        color: #98a2b3;
        font-size: 13px;
        font-style: italic;
    }

    .application-answer-empty,
    .application-answer-error {
        padding: 60px 20px;
        text-align: center;
    }

    .application-answer-empty .empty-icon,
    .application-answer-error .empty-icon {
        width: 64px;
        height: 64px;
        margin: 0 auto 16px;
        border-radius: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f4f6f8;
        color: #98a2b3;
        font-size: 30px;
    }

    .application-answer-empty h5,
    .application-answer-error h5 {
        color: #344054;
        font-weight: 700;
    }

    .application-answer-empty p,
    .application-answer-error p {
        max-width: 500px;
        margin: 6px auto 0;
        color: #98a2b3;
        font-size: 13px;
    }

    @media (max-width: 576px) {

        .application-answer-card {
            padding: 15px;
            gap: 10px;
        }

        .answer-number {
            flex-basis: 32px;
            height: 32px;
        }

        .answer-question {
            font-size: 14px;
        }

        .application-answer-summary {
            padding: 14px;
        }
    }
    .candidate-profile-modal .modal-dialog { max-width: 1180px; }
    .candidate-profile-hero {
        border-radius: 18px; padding: 22px; color: #fff;
        background: var(--bs-primary, #ab2b22);
        background: linear-gradient(120deg,
            color-mix(in srgb, var(--bs-primary, #ab2b22) 88%, #000 12%) 0%,
            var(--bs-primary, #ab2b22) 58%,
            color-mix(in srgb, var(--bs-primary, #ab2b22) 88%, #fff 12%) 100%);
    }
    .candidate-profile-modal .nav-pills .nav-link.active {
        background: var(--bs-primary, #ab2b22);
        color: #fff;
    }
    .candidate-profile-resume-frame {
        width: 100%; min-height: 66vh; border: 1px solid #e7edf5;
        border-radius: 12px; background: #f8fafc;
    }
    .candidate-profile-resume-unavailable {
        min-height: 240px; display: flex; align-items: center; justify-content: center;
        text-align: center; border: 1px dashed #d9e1eb; border-radius: 12px;
        background: #f8fafc; padding: 24px;
    }
    .candidate-profile-answer-card {
        border: 1px solid #e8edf4; border-radius: 14px; padding: 17px;
        background: #fff; display: flex; gap: 14px; margin-bottom: 12px;
    }
    .candidate-profile-answer-value {
        margin-top: 12px; border-radius: 10px; padding: 12px 14px;
        background: #f8fafc; color: #344054; line-height: 1.6;
        overflow-wrap: anywhere; white-space: pre-wrap;
    }
    .candidate-profile-answer-pill {
        display: inline-block; margin: 3px 5px 3px 0; padding: 6px 10px;
        border-radius: 8px; color: #5b2a25; background: #f9e9e7; font-size: 12px;
    }
    .candidate-profile-avatar {
        width: 58px; height: 58px; display:flex; align-items:center; justify-content:center;
        border-radius: 17px; background:rgba(255,255,255,.16); font-size:25px; flex:0 0 auto;
    }
    .candidate-profile-stat {
        height:100%; border:1px solid #e7edf5; border-radius:14px; padding:14px 16px; background:#fff;
    }
    .candidate-profile-stat .value { font-size:25px; line-height:1.2; font-weight:800; color:#172b4d; }
    .candidate-profile-section { border:1px solid #e8edf4; border-radius:15px; padding:17px; background:#fff; }
    .candidate-profile-label { color:#748197; font-size:11px; text-transform:uppercase; font-weight:800; letter-spacing:.06em; }
    .candidate-profile-value { color:#24344d; font-size:14px; font-weight:600; overflow-wrap:anywhere; }
    .candidate-ats-match-card { border:1px solid #e4eaf2; border-radius:14px; padding:16px; background:#fff; }
    .candidate-ats-score { min-width:58px; height:58px; border-radius:15px; display:flex; align-items:center; justify-content:center; background:#edf5ff; color:#175ca7; font-size:19px; font-weight:800; }
    .candidate-ats-evidence { display:flex; flex-wrap:wrap; gap:7px; }
    .candidate-ats-evidence span { border-radius:999px; background:#eff5fb; color:#36516e; padding:5px 9px; font-size:11px; font-weight:600; }
    .candidate-bulk-panel { border:1px solid #e7edf5; border-radius:15px; padding:17px; background:#fff; }
    .candidate-bulk-stat { border:1px solid #e8edf4; border-radius:13px; padding:13px; background:#fff; }
    .candidate-bulk-stat .value { font-size:24px; font-weight:800; color:#172b4d; line-height:1.15; }
    .candidate-bulk-progress { height:11px; border-radius:30px; background:#edf1f6; overflow:hidden; }
    .candidate-bulk-progress > span { height:100%; width:0; display:block; border-radius:30px; background:linear-gradient(90deg,#2671c8,#31a1c8); transition:width .25s ease; }
    .candidate-bulk-log { max-height:220px; overflow:auto; border:1px solid #e8edf4; border-radius:12px; }
    .candidate-bulk-log-row { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:10px 13px; border-bottom:1px solid #edf1f6; font-size:12px; }
    .candidate-bulk-log-row:last-child { border-bottom:0; }
    .candidate-muted-note { color:#718096; font-size:12px; }
    @media(max-width:767.98px) {
        .candidate-profile-hero { padding:16px; }
        .candidate-profile-modal .modal-dialog { margin: .5rem; }
        .candidate-bulk-log-row { align-items:flex-start; flex-direction:column; }
    }
</style>

<div class="modal fade candidate-profile-modal" id="candidateProfileModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <div>
                    <div class="text-primary fw-bold small text-uppercase">Recruitment workspace</div>
                    <h4 class="modal-title fw-bold text-dark mb-0">Candidate profile</h4>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-3" id="candidateProfileBody">
                <div class="text-center py-5" id="candidateProfileLoading">
                    <div class="spinner-border text-primary mb-3" role="status"></div>
                    <div class="fw-semibold text-dark">Loading candidate details</div>
                    <div class="candidate-muted-note">Fetching profile, resume extraction and ATS role analysis.</div>
                </div>
                <div id="candidateProfileContent" class="d-none"></div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

@if($canUseAtsRoleMatching)
<div class="modal fade" id="candidateBulkAtsModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <div>
                    <div class="text-primary small fw-bold text-uppercase">Recruitment intelligence</div>
                    <h4 class="modal-title fw-bold text-dark mb-1">Bulk ATS role analysis</h4>
                    <div class="candidate-muted-note">Process existing readable resumes in small, sequential batches. Each candidate report is saved separately.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-3">
                <div class="candidate-bulk-panel mb-3">
                    <div class="d-flex align-items-center justify-content-between gap-3 mb-3">
                        <div>
                            <div class="fw-bold text-dark">Analysis coverage</div>
                            <div class="candidate-muted-note" id="candidateBulkStatsNote">Loading current candidate and role counts…</div>
                        </div>
                        <button type="button" class="btn btn-sm btn-light-primary" id="candidateBulkRefreshBtn" onclick="loadCandidateBulkStats()">
                            <i class="mdi mdi-refresh me-1"></i>Refresh
                        </button>
                    </div>
                    <div class="row g-2">
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">Resumes</div><div class="value" id="candidateBulkTotal">—</div></div></div>
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">Pending</div><div class="value" id="candidateBulkPending">—</div></div></div>
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">Analyzed</div><div class="value" id="candidateBulkAnalyzed">—</div></div></div>
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">Active roles</div><div class="value" id="candidateBulkRoles">—</div></div></div>
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">Resume text missing</div><div class="value" id="candidateBulkMissingText">—</div></div></div>
                    </div>
                </div>

                <div class="candidate-bulk-panel mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="fw-bold text-dark">Run progress</div>
                        <div class="fw-bold text-primary" id="candidateBulkPercent">0%</div>
                    </div>
                    <div class="candidate-bulk-progress mb-3"><span id="candidateBulkProgressBar"></span></div>
                    <div class="row g-2 mb-3">
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">Processed</div><div class="value" id="candidateBulkProcessed">0</div></div></div>
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">With matches</div><div class="value" id="candidateBulkMatched">0</div></div></div>
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">No reliable match</div><div class="value" id="candidateBulkUnmatched">0</div></div></div>
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">Failed</div><div class="value" id="candidateBulkFailed">0</div></div></div>
                        <div class="col-6 col-md-3"><div class="candidate-bulk-stat"><div class="candidate-muted-note">Resumes recovered</div><div class="value" id="candidateBulkBackfilled">0</div></div></div>
                    </div>
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                        <label class="d-flex align-items-center gap-2 small text-dark">
                            <input type="checkbox" class="form-check-input mt-0" id="candidateBulkForceReprocess">
                            Reprocess candidates that already have an ATS report
                        </label>
                        <div class="d-flex align-items-center gap-2">
                            <label for="candidateBulkBatchSize" class="small text-muted mb-0">Batch size</label>
                            <select id="candidateBulkBatchSize" class="form-select form-select-sm" style="width:82px">
                                <option value="1" selected>1</option>
                            </select>
                        </div>
                    </div>
                    <div class="candidate-muted-note mt-2">This runs as short browser-initiated requests, not a background queue. Keep this page open until the run completes. When a candidate's resume_text is empty, the system reads the saved local, Wasabi or Google Drive resume and stores the extracted text before matching. The original resume file is not modified.</div>
                </div>

                <div class="candidate-bulk-panel">
                    <div class="fw-bold text-dark mb-2">Recently analyzed candidates</div>
                    <div class="candidate-bulk-log" id="candidateBulkLog">
                        <div class="text-center text-muted small py-4">No batch activity yet.</div>
                    </div>
                    <div class="small mt-2" id="candidateBulkStatus" role="status" aria-live="polite">Ready to start.</div>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-danger" id="candidateBulkStopBtn" onclick="stopCandidateBulkAnalysis()" disabled>
                    <i class="mdi mdi-stop-circle-outline me-1"></i>Stop after current batch
                </button>
                <button type="button" class="btn btn-primary" id="candidateBulkStartBtn" onclick="startCandidateBulkAnalysis()">
                    <i class="mdi mdi-play-circle-outline me-1"></i>Start analysis
                </button>
            </div>
        </div>
    </div>
</div>
@endif

<script>
    const candidateManagementAtsBaseUrl = @json(url('/hr_recruitment/candidate_management'));
    const candidateManagementCsrf = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || @json(csrf_token());
    const candidateManagementCanRunAts = @json($canUseAtsRoleMatching);

    function candidateModalEscape(value) {
        return $('<div>').text(value === null || value === undefined ? '' : String(value)).html();
    }

    function candidateModalJson(value, fallback) {
        if (Array.isArray(value) || (value && typeof value === 'object')) return value;
        if (typeof value === 'string' && value.trim()) {
            try { return JSON.parse(value); } catch (error) { return fallback; }
        }
        return fallback;
    }

    function openCandidateProfile(sno) {
        const modalElement = document.getElementById('candidateProfileModal');
        if (!modalElement || !sno) return;
        $('#candidateProfileLoading').removeClass('d-none');
        $('#candidateProfileContent').addClass('d-none').empty();
        bootstrap.Modal.getOrCreateInstance(modalElement).show();
        $.ajax({
            url: candidateManagementAtsBaseUrl + '/' + encodeURIComponent(sno) + '/details',
            method: 'GET',
            dataType: 'json',
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            success: function (response) {
                if (Number(response.status) !== 200 || !response.data) throw new Error('Candidate details were not returned.');
                renderCandidateProfileModal(response.data);
            },
            error: function (xhr) {
                $('#candidateProfileLoading').html('<div class="text-danger fw-semibold">Unable to load this candidate.</div><div class="candidate-muted-note mt-1">' + candidateModalEscape(xhr.responseJSON?.message || 'Please refresh and try again.') + '</div>');
            }
        });
    }

    // Backward-compatible name used by the previous candidate table row action.
    function viewApplicantAI(sno) { openCandidateProfile(sno); }

    function renderCandidateProfileModal(payload) {
        const c = payload.candidate || {};
        const a = payload.analysis || null;
        const x = payload.extraction || null;
        const legacyAi = payload.legacy_ai_response || null;
        const report = a?.report || {};
        const matches = Array.isArray(a?.matches) ? a.matches : (Array.isArray(report.role_matches) ? report.role_matches : []);
        const selectedRoles = Array.isArray(c.selected_roles) ? c.selected_roles : [];
        const fullName = candidateModalEscape(c.name || 'Candidate');
        const bestScore = a && a.best_role_score !== null && a.best_role_score !== undefined ? Number(a.best_role_score).toFixed(0) + '%' : '—';
        const overall = a && a.overall_match_score !== null && a.overall_match_score !== undefined ? Number(a.overall_match_score).toFixed(0) + '%' : '—';
        const roleCards = matches.length ? matches.map(function (m, index) {
            const evidenceObject = candidateModalJson(m.evidence_json, {});
            const evidence = Array.isArray(evidenceObject) ? evidenceObject : (Array.isArray(evidenceObject.items) ? evidenceObject.items : []);
            const categories = Array.isArray(evidenceObject.categories) ? evidenceObject.categories : [];
            const score = Number(m.match_score || 0);
            const roleName = candidateModalEscape(m.role_name || m.role_code || 'Matched role');
            const reason = candidateModalEscape(m.reason || 'Evidence-backed match score based on resume and role profile.');
            const evidenceHtml = evidence.length
                ? evidence.slice(0, 8).map(item => '<span>' + candidateModalEscape(item) + '</span>').join('')
                : '<span>No granular evidence was stored for this role.</span>';
            const categoryHtml = categories.length ? '<div class="small text-muted mt-2">Evidence groups: ' + candidateModalEscape(categories.join(', ')) + '</div>' : '';
            return '<div class="candidate-ats-match-card mb-2"><div class="d-flex gap-3"><div class="candidate-ats-score">' + score.toFixed(0) + '%</div><div class="flex-grow-1"><div class="d-flex align-items-start justify-content-between gap-2 flex-wrap"><div><div class="fw-bold text-dark">' + roleName + '</div><div class="small text-muted">' + candidateModalEscape(m.role_code || '') + (m.role_family ? ' · ' + candidateModalEscape(m.role_family) : '') + '</div></div><span class="badge bg-label-primary">' + candidateModalEscape(m.decision || 'Evidence match') + '</span></div><div class="small text-dark mt-2">' + reason + '</div><div class="candidate-ats-evidence mt-2">' + evidenceHtml + '</div>' + categoryHtml + '</div></div></div>';
        }).join('') : '<div class="text-center py-4 border rounded-3"><i class="mdi mdi-chart-timeline-variant fs-1 text-muted"></i><div class="fw-semibold mt-2">No role matches saved yet</div><div class="candidate-muted-note">Run an individual ATS analysis to rank this resume against active recruitment roles.</div></div>';

        const selectedRoleHtml = selectedRoles.length ? selectedRoles.map(r => '<span class="badge bg-label-info me-1 mb-1">' + candidateModalEscape(r.role_name) + '</span>').join('') : '<span class="text-muted small">No role assignment selected during intake.</span>';
        const parserVersion = candidateModalEscape(x?.parser_version || report.extraction?.parser_version || 'Not available');
        const modelName = candidateModalEscape(x?.ai_primary_model || report.extraction?.name_ai_model || 'Local parser / no model recorded');
        const reviewNeeded = Boolean(a?.review_required || x?.review_required);
        const legacyScoreFields = [
            ['Overall match', legacyAi?.overall_match_score ?? legacyAi?.overall_resume_score],
            ['ATS keyword match', legacyAi?.ats_keyword_match_score ?? legacyAi?.ats_keyword_strength_score],
            ['Skills alignment', legacyAi?.skills_alignment_score ?? legacyAi?.skills_quality_score],
            ['Experience relevance', legacyAi?.experience_relevance_score ?? legacyAi?.experience_quality_score],
            ['Impact & metrics', legacyAi?.impact_metrics_score],
            ['Role responsibility', legacyAi?.role_responsibility_match_score ?? legacyAi?.resume_structure_score]
        ].filter(item => item[1] !== null && item[1] !== undefined && item[1] !== '');
        const legacyScoreHtml = legacyScoreFields.length
            ? '<div class="row g-2 mb-3">' + legacyScoreFields.map(item => '<div class="col-6 col-md-4"><div class="candidate-profile-stat"><div class="candidate-profile-label">' + candidateModalEscape(item[0]) + '</div><div class="value">' + candidateModalEscape(Number(item[1]).toFixed(0)) + '%</div></div></div>').join('') + '</div>'
            : '';
        const legacyList = (value) => Array.isArray(value) && value.length
            ? '<ul class="mb-0 ps-3">' + value.map(item => '<li class="mb-1">' + candidateModalEscape(typeof item === 'string' ? item : JSON.stringify(item)) + '</li>').join('') + '</ul>'
            : '<div class="candidate-muted-note">No saved details.</div>';
        const legacyQualityHtml = legacyAi
            ? '<div class="candidate-profile-section mb-3"><div class="fw-bold mb-3">Saved resume quality scores</div>' + legacyScoreHtml + '</div>' +
                '<div class="row g-3"><div class="col-lg-6"><div class="candidate-profile-section h-100"><div class="fw-bold mb-2">Strengths</div>' + legacyList(legacyAi.strengths) + '</div></div>' +
                '<div class="col-lg-6"><div class="candidate-profile-section h-100"><div class="fw-bold mb-2">Weaknesses / gaps</div>' + legacyList(legacyAi.weaknesses) + '</div></div>' +
                '<div class="col-lg-6"><div class="candidate-profile-section h-100"><div class="fw-bold mb-2">Missing resume elements / keywords</div>' + legacyList(legacyAi.missing_keywords || legacyAi.missing_resume_elements) + '</div></div>' +
                '<div class="col-lg-6"><div class="candidate-profile-section h-100"><div class="fw-bold mb-2">Recommended improvements</div>' + legacyList(legacyAi.resume_improvements || legacyAi.improvements) + '</div></div></div>' +
                (legacyAi.optimized_summary ? '<div class="candidate-profile-section mt-3"><div class="fw-bold mb-2">Optimized professional summary</div><div class="candidate-profile-value">' + candidateModalEscape(legacyAi.optimized_summary) + '</div></div>' : '') +
                (Array.isArray(legacyAi.rewritten_bullets) && legacyAi.rewritten_bullets.length ? '<div class="candidate-profile-section mt-3"><div class="fw-bold mb-2">Rewritten achievement bullets</div>' + legacyList(legacyAi.rewritten_bullets) + '</div>' : '')
            : '<div class="candidate-profile-section"><div class="fw-bold mb-1">No legacy AI resume-quality report</div><div class="candidate-muted-note">This candidate has no previously saved ai_response. The current intake pipeline saves extraction provenance and evidence-based role matching separately.</div></div>';

        const answersData = payload.application_answers || {};
        const applicationAnswers = Array.isArray(answersData.answers) ? answersData.answers : [];
        const applicationAnswersCount = Number(answersData.answer_count || applicationAnswers.length || 0);
        const questionTypeLabel = (type) => {
            const labels = {
                text_field: 'Text response', check_box: 'Multiple selection',
                list_box: 'Dropdown selection', radio_button: 'Single selection',
                textarea: 'Text response'
            };
            return labels[String(type || '').toLowerCase()] || (type ? String(type).replace(/[_-]+/g, ' ') : 'Application response');
        };
        const answerValueHtml = (value) => {
            if (value === null || value === undefined || value === '' || (Array.isArray(value) && !value.length)) {
                return '<span class="text-muted fst-italic">Not answered</span>';
            }
            if (Array.isArray(value)) {
                const values = value.filter(v => v !== null && v !== '');
                return values.length ? values.map(v => '<span class="candidate-profile-answer-pill">' + candidateModalEscape(v) + '</span>').join('') : '<span class="text-muted fst-italic">Not answered</span>';
            }
            return '<div class="candidate-profile-answer-value">' + candidateModalEscape(value) + '</div>';
        };
        const applicationAnswersHtml = applicationAnswers.length
            ? '<div class="application-answers-wrapper"><div class="application-answer-summary"><div class="answer-summary-icon"><i class="mdi mdi-check-circle-outline"></i></div><div class="flex-grow-1"><div class="fw-bold fs-6">Application Questions Completed</div><div class="text-muted fs-7">Candidate submitted ' + applicationAnswersCount + ' ' + (applicationAnswersCount === 1 ? 'answer' : 'answers') + ' with the application.</div></div><div class="answer-summary-count">' + applicationAnswersCount + '</div></div><div class="application-answer-list">' + applicationAnswers.map((item, index) => '<div class="candidate-profile-answer-card"><div class="answer-number">' + String(index + 1).padStart(2, '0') + '</div><div class="answer-card-body"><div class="answer-question">' + candidateModalEscape(item.question || 'Question') + '</div><div class="answer-type">' + candidateModalEscape(questionTypeLabel(item.type)) + '</div><div class="answer-value">' + answerValueHtml(item.answer) + '</div></div></div>').join('') + '</div></div>'
            : '<div class="application-answer-empty"><div class="empty-icon"><i class="mdi mdi-clipboard-text-outline"></i></div><h5>No application answers</h5><p>This applicant did not submit any additional questions with the application.</p></div>';

        // Use the authenticated ERP resume resolver (Wasabi -> Drive -> local fallback).
        // Render native browser previews only for formats browsers reliably support.
        const resumeUrl = c.resume_url ? candidateModalEscape(c.resume_url) : '';
        const resumeDownloadUrl = c.resume_download_url ? candidateModalEscape(c.resume_download_url) : resumeUrl;
        const resumeFileName = String(c.resume_filename || c.attachment || 'Resume');
        const resumeExtension = resumeFileName.includes('.') ? resumeFileName.split('.').pop().toLowerCase() : '';
        let resumePreviewHtml = '<div class="candidate-profile-resume-unavailable"><div><i class="mdi mdi-file-document-outline fs-1 text-muted"></i><div class="fw-semibold text-dark mt-2">No resume is attached to this candidate</div><div class="candidate-muted-note mt-1">Upload a resume from the candidate edit form to enable preview here.</div></div></div>';
        if (resumeUrl && resumeExtension === 'pdf') {
            resumePreviewHtml = '<iframe class="candidate-profile-resume-frame" src="' + resumeUrl + '#toolbar=1&navpanes=0&view=FitH" title="Candidate PDF resume preview" loading="lazy"></iframe>';
        } else if (resumeUrl && ['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(resumeExtension)) {
            resumePreviewHtml = '<div class="text-center p-3 border rounded-3 bg-light"><img src="' + resumeUrl + '" alt="Candidate resume" style="max-width:100%;max-height:68vh;object-fit:contain"></div>';
        } else if (resumeUrl && resumeExtension === 'txt') {
            resumePreviewHtml = '<iframe class="candidate-profile-resume-frame" src="' + resumeUrl + '" title="Candidate text resume preview" loading="lazy"></iframe>';
        } else if (resumeUrl) {
            resumePreviewHtml = '<div class="candidate-profile-resume-unavailable"><div><i class="mdi mdi-file-word-outline fs-1 text-primary"></i><div class="fw-semibold text-dark mt-2">' + candidateModalEscape(resumeExtension ? resumeExtension.toUpperCase() + ' resume' : 'Resume file') + '</div><div class="candidate-muted-note mt-1">This document format cannot be reliably rendered in every browser. Open or download it for full viewing.</div><div class="d-flex justify-content-center gap-2 mt-3"><a class="btn btn-sm btn-primary" href="' + resumeUrl + '" target="_blank" rel="noopener">Open document</a><a class="btn btn-sm btn-outline-primary" href="' + resumeDownloadUrl + '" target="_blank" rel="noopener">Download</a></div></div></div>';
        }

        $('#candidateProfileContent').html(`
            <div class="candidate-profile-hero mb-3">
                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <div class="candidate-profile-avatar"><i class="mdi mdi-account-tie-outline"></i></div>
                    <div class="flex-grow-1"><div class="h4 fw-bold mb-1 text-white">${fullName}</div><div class="small text-white-50">${candidateModalEscape(c.applicant_id || ('Candidate #' + c.sno))}</div><div class="small text-white mt-2">${candidateModalEscape(c.email || 'Email not provided')} &nbsp;·&nbsp; ${candidateModalEscape(c.mobile || 'Mobile not provided')}</div></div>
                    <div class="d-flex gap-2 flex-wrap">${c.resume_url ? '<a href="' + candidateModalEscape(c.resume_url) + '" target="_blank" rel="noopener" class="btn btn-light btn-sm"><i class="mdi mdi-file-eye-outline me-1"></i>Open resume</a>' : ''}${candidateManagementCanRunAts ? '<button type="button" class="btn btn-outline-light btn-sm" onclick="runCandidateIndividualAts(' + Number(c.sno) + ')"><i class="mdi mdi-refresh me-1"></i>Run ATS again</button>' : ''}</div>
                </div>
            </div>
            <div class="row g-2 mb-3">
                <div class="col-6 col-md-3"><div class="candidate-profile-stat"><div class="candidate-profile-label">Overall fit</div><div class="value">${overall}</div></div></div>
                <div class="col-6 col-md-3"><div class="candidate-profile-stat"><div class="candidate-profile-label">Best role</div><div class="value">${bestScore}</div></div></div>
                <div class="col-6 col-md-3"><div class="candidate-profile-stat"><div class="candidate-profile-label">Roles matched</div><div class="value">${Number(a?.match_count || 0)}</div></div></div>
                <div class="col-6 col-md-3"><div class="candidate-profile-stat"><div class="candidate-profile-label">Recruiter review</div><div class="value fs-5">${reviewNeeded ? '<span class="text-warning">Required</span>' : '<span class="text-success">Ready</span>'}</div></div></div>
            </div>
            <ul class="nav nav-pills gap-2 mb-3" role="tablist">
                <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#candidateProfileOverview" type="button">Overview</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#candidateProfileAts" type="button">ATS & role match</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#candidateProfileResume" type="button">Resume</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#candidateProfileAnswers" type="button">Application answers <span class="badge bg-light text-dark ms-1">${Number(payload.application_answers?.answer_count || 0)}</span></button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#candidateProfileExtraction" type="button">Resume extraction</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#candidateProfileLegacyAi" type="button">Resume quality report</button></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="candidateProfileOverview">
                    <div class="candidate-profile-section mb-3"><div class="fw-bold text-dark mb-3">Candidate information</div><div class="row g-3">
                        ${candidateProfileField('Gender', c.gender)}${candidateProfileField('Qualification', c.qualification_name || c.qualification_id)}${candidateProfileField('Major', c.major_name || c.major_id)}${candidateProfileField('Experience', c.experience_id == 1 ? 'Fresher' : (c.experience_count ? c.experience_count + ' years' : 'Not provided'))}${candidateProfileField('Marital status', c.marital_status_id)}${candidateProfileField('Resume characters', c.resume_chars)}
                    </div></div>
                    <div class="candidate-profile-section"><div class="fw-bold text-dark mb-2">Recruiter-selected roles</div><div>${selectedRoleHtml}</div>${c.description ? '<div class="candidate-profile-label mt-3">Notes</div><div class="candidate-profile-value mt-1">' + candidateModalEscape(c.description) + '</div>' : ''}</div>
                </div>
                <div class="tab-pane fade" id="candidateProfileAts">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3"><div><div class="fw-bold text-dark">Evidence-backed role ranking</div><div class="candidate-muted-note">' + (a ? 'Last processed: ' + candidateModalEscape(a.processed_at || 'Date not available') : 'This resume has not been analyzed yet') + '</div></div><span class="badge bg-label-secondary">${candidateModalEscape(a?.version || 'ATS not run')}</span></div>
                    <div class="candidate-muted-note mb-3">ATS scores are generated by the local rule-based role matcher. They assist recruiter review and do not make hiring decisions.</div>
                    ${roleCards}
                </div>
                <div class="tab-pane fade" id="candidateProfileResume">
                    <div class="candidate-profile-section mb-3">
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                            <div><div class="fw-bold text-dark">Uploaded resume</div><div class="candidate-muted-note">${candidateModalEscape(c.resume_filename || c.attachment || 'Resume file')}</div></div>
                            ${c.resume_url ? '<div class="d-flex gap-2"><a class="btn btn-sm btn-primary" href="' + candidateModalEscape(c.resume_url) + '" target="_blank" rel="noopener"><i class="mdi mdi-open-in-new me-1"></i>Open resume</a><a class="btn btn-sm btn-outline-primary" href="' + candidateModalEscape(c.resume_download_url || c.resume_url) + '" target="_blank" rel="noopener"><i class="mdi mdi-download me-1"></i>Download</a></div>' : ''}
                        </div>
                    </div>
                    ${resumePreviewHtml}
                </div>
                <div class="tab-pane fade" id="candidateProfileAnswers">
                    ${applicationAnswersHtml}
                </div>
                <div class="tab-pane fade" id="candidateProfileExtraction">
                    <div class="candidate-profile-section mb-3"><div class="fw-bold text-dark mb-3">Extraction provenance</div><div class="row g-3">${candidateProfileField('Parser version', parserVersion)}${candidateProfileField('Primary model', modelName)}${candidateProfileField('AI verified', x?.ai_verified ? 'Yes' : 'Not verified')}${candidateProfileField('Confidence', x?.confidence !== null && x?.confidence !== undefined ? x.confidence + '%' : 'Not scored')}${candidateProfileField('Text length', x?.resume_chars || c.resume_chars)}${candidateProfileField('Manual review', reviewNeeded ? 'Required' : 'Not flagged')}</div></div>
                    <div class="candidate-profile-section"><div class="fw-bold text-dark mb-2">Extracted fields</div><pre class="small bg-light rounded-3 p-3 mb-0" style="white-space:pre-wrap;max-height:280px;overflow:auto;">${candidateModalEscape(JSON.stringify(x?.extracted || {}, null, 2))}</pre></div>
                </div>
                <div class="tab-pane fade" id="candidateProfileLegacyAi">
                    <div class="candidate-muted-note mb-3">Historical AI quality data is shown exactly as it was saved. It is separate from the current evidence-based role-fit analysis.</div>
                    ${legacyQualityHtml}
                </div>
            </div>
        `);
        $('#candidateProfileLoading').addClass('d-none');
        $('#candidateProfileContent').removeClass('d-none');
        window.currentCandidateProfileSno = Number(c.sno);
    }

    function candidateProfileField(label, value) {
        const rendered = value === null || value === undefined || value === '' ? '—' : value;
        return '<div class="col-6 col-md-4"><div class="candidate-profile-label">' + candidateModalEscape(label) + '</div><div class="candidate-profile-value mt-1">' + candidateModalEscape(rendered) + '</div></div>';
    }

    function runCandidateIndividualAts(sno) {
        const candidateSno = Number(sno || window.currentCandidateProfileSno || 0);
        if (!candidateSno) return;
        const $buttons = $('#candidateProfileModal button[onclick^="runCandidateIndividualAts"]');
        $buttons.prop('disabled', true);
        $.ajax({
            url: candidateManagementAtsBaseUrl + '/' + candidateSno + '/ats-match',
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': candidateManagementCsrf, 'Accept': 'application/json' },
            success: function (response) {
                if (response.data?.warning) toastr.warning(response.data.warning);
                else toastr.success(response.message || 'ATS analysis saved.');
                openCandidateProfile(candidateSno);
            },
            error: function (xhr) { toastr.error(xhr.responseJSON?.message || 'ATS analysis failed.'); },
            complete: function () { $buttons.prop('disabled', false); }
        });
    }

    let candidateBulkAnalysis = { running: false, stopRequested: false, cursor: 0, processed: 0, matched: 0, unmatched: 0, failed: 0, backfilled: 0, target: 0 };

    function openBulkAiMatchingModal() {
        const element = document.getElementById('candidateBulkAtsModal');
        if (!element) return;
        bootstrap.Modal.getOrCreateInstance(element).show();
        loadCandidateBulkStats();
    }

    function loadCandidateBulkStats() {
        $('#candidateBulkStatsNote').text('Refreshing candidate and role counts…');
        $.ajax({
            url: candidateManagementAtsBaseUrl + '/ats/bulk/stats', method: 'GET', dataType: 'json',
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            success: function (response) {
                const d = response.data || {};
                $('#candidateBulkTotal').text(Number(d.total_candidates || 0).toLocaleString());
                $('#candidateBulkPending').text(Number(d.pending_count || 0).toLocaleString());
                $('#candidateBulkAnalyzed').text(Number(d.analyzed_count || 0).toLocaleString());
                $('#candidateBulkRoles').text(Number(d.active_role_count || 0).toLocaleString());
                $('#candidateBulkMissingText').text(Number(d.resume_text_missing_count || 0).toLocaleString());
                $('#candidateBulkStatsNote').text(d.ats_tables_ready ? 'Ready. Candidates with stored resume files are eligible. Missing resume text will be extracted and saved before ATS matching.' : 'ATS SQL tables are missing. Apply the ATS database schema before starting analysis.');
                $('#candidateBulkStartBtn').prop('disabled', !d.ats_tables_ready || Number(d.active_role_count || 0) < 1 || candidateBulkAnalysis.running);
            },
            error: function (xhr) { $('#candidateBulkStatsNote').text(xhr.responseJSON?.message || 'Unable to load ATS statistics.'); }
        });
    }

    function updateCandidateBulkCounters() {
        $('#candidateBulkProcessed').text(candidateBulkAnalysis.processed.toLocaleString());
        $('#candidateBulkMatched').text(candidateBulkAnalysis.matched.toLocaleString());
        $('#candidateBulkUnmatched').text(candidateBulkAnalysis.unmatched.toLocaleString());
        $('#candidateBulkFailed').text(candidateBulkAnalysis.failed.toLocaleString());
        $('#candidateBulkBackfilled').text(candidateBulkAnalysis.backfilled.toLocaleString());
        const percent = candidateBulkAnalysis.target > 0 ? Math.min(100, Math.round((candidateBulkAnalysis.processed + candidateBulkAnalysis.failed) / candidateBulkAnalysis.target * 100)) : 0;
        $('#candidateBulkPercent').text(percent + '%');
        $('#candidateBulkProgressBar').css('width', percent + '%');
    }

    function appendCandidateBulkLog(items) {
        if (!Array.isArray(items) || !items.length) return;
        const $log = $('#candidateBulkLog');
        if ($log.find('.text-center').length) $log.empty();
        items.forEach(function (item) {
            const labels = {
                matched: 'Matched',
                no_reliable_match: 'No reliable match',
                unreadable_resume: 'Resume needs review',
                save_failed: 'Report save failed',
                failed: 'Processing failed'
            };
            const label = labels[item.status] || 'Processed';
            const badgeClass = item.status === 'matched' ? 'bg-label-success'
                : item.status === 'no_reliable_match' ? 'bg-label-warning' : 'bg-label-danger';
            const recovered = item.resume_recovered ? '<span class="badge bg-label-info ms-1">Text recovered</span>' : '';
            const message = item.message ? '<div class="small text-danger mt-1">' + candidateModalEscape(item.message) + '</div>' : '';
            const score = item.best_score === null || item.best_score === undefined ? '—' : Number(item.best_score).toFixed(0) + '%';
            $log.prepend('<div class="candidate-bulk-log-row"><div><div class="fw-semibold text-dark">' + candidateModalEscape(item.name || ('Candidate #' + item.sno)) + '</div><div class="text-muted">#' + Number(item.sno) + ' · ' + Number(item.match_count || 0) + ' role match(es)</div>' + message + '</div><div class="text-end"><span class="badge ' + badgeClass + '">' + label + '</span>' + recovered + '<div class="small text-muted mt-1">Best score: ' + score + '</div></div></div>');
        });
        while ($log.children().length > 12) $log.children().last().remove();
    }

    async function startCandidateBulkAnalysis() {
        if (candidateBulkAnalysis.running) return;
        const force = $('#candidateBulkForceReprocess').is(':checked');
        const batchSize = Number($('#candidateBulkBatchSize').val() || 1);
        const statsResponse = await $.ajax({ url: candidateManagementAtsBaseUrl + '/ats/bulk/stats', method: 'GET', dataType: 'json' }).catch(xhr => null);
        if (!statsResponse?.data?.ats_tables_ready) {
            toastr.error('ATS tables are not ready. Apply the ATS database schema first.');
            loadCandidateBulkStats();
            return;
        }
        candidateBulkAnalysis = { running: true, stopRequested: false, cursor: 0, processed: 0, matched: 0, unmatched: 0, failed: 0, backfilled: 0, target: force ? Number(statsResponse.data.total_candidates || 0) : Number(statsResponse.data.pending_count || 0) };
        $('#candidateBulkLog').html('<div class="text-center text-muted small py-4">Analysis started…</div>');
        $('#candidateBulkStatus').removeClass('text-danger text-success').addClass('text-primary').text('Processing resumes in short batches…');
        $('#candidateBulkStartBtn').prop('disabled', true);
        $('#candidateBulkStopBtn').prop('disabled', false);
        updateCandidateBulkCounters();

        try {
            let hasMore = candidateBulkAnalysis.target > 0;
            while (hasMore && !candidateBulkAnalysis.stopRequested) {
                const response = await $.ajax({
                    url: candidateManagementAtsBaseUrl + '/ats/bulk/process',
                    method: 'POST',
                    dataType: 'json',
                    headers: { 'X-CSRF-TOKEN': candidateManagementCsrf, 'Accept': 'application/json' },
                    data: { cursor: candidateBulkAnalysis.cursor, batch_size: batchSize, force_reprocess: force ? 1 : 0 }
                });
                const d = response.data || {};
                candidateBulkAnalysis.cursor = Number(d.cursor || candidateBulkAnalysis.cursor);
                candidateBulkAnalysis.processed += Number(d.processed_count || 0);
                candidateBulkAnalysis.matched += Number(d.matched_count || 0);
                candidateBulkAnalysis.unmatched += Number(d.unmatched_count || 0);
                candidateBulkAnalysis.failed += Number(d.failed_count || 0);
                candidateBulkAnalysis.backfilled += Number(d.backfilled_count || 0);
                hasMore = Boolean(d.has_more);
                appendCandidateBulkLog(d.recent_items || []);
                updateCandidateBulkCounters();
                $('#candidateBulkStatus').text(hasMore ? 'Processed through candidate #' + candidateBulkAnalysis.cursor + '. Continuing…' : 'All eligible candidates have been processed.');
            }
            if (candidateBulkAnalysis.stopRequested) {
                $('#candidateBulkStatus').text('Stopped after the current batch. Completed reports remain saved.').addClass('text-warning');
            } else {
                $('#candidateBulkStatus').text('Bulk ATS analysis completed. Candidate reports are saved.').addClass('text-success');
                $('#candidateBulkPercent').text(candidateBulkAnalysis.target ? '100%' : '0%');
                if (candidateBulkAnalysis.target) $('#candidateBulkProgressBar').css('width', '100%');
            }
        } catch (xhr) {
            $('#candidateBulkStatus').text(xhr.responseJSON?.message || 'A batch failed. Refresh statistics and retry.').addClass('text-danger');
        } finally {
            candidateBulkAnalysis.running = false;
            $('#candidateBulkStartBtn').prop('disabled', false);
            $('#candidateBulkStopBtn').prop('disabled', true);
            loadCandidateBulkStats();
        }
    }

    function stopCandidateBulkAnalysis() {
        candidateBulkAnalysis.stopRequested = true;
        $('#candidateBulkStopBtn').prop('disabled', true);
        $('#candidateBulkStatus').text('Stop requested. The current batch will finish before stopping.');
    }
</script>
