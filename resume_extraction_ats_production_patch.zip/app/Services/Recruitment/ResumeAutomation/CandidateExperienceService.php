<?php

namespace App\Services\Recruitment\ResumeAutomation;

use DateTimeImmutable;
use Throwable;

/**
 * Conservative resume-based experience classifier for the existing applicant fields.
 *
 * Stored field conventions: experience_id=1 means Fresher, experience_id=2 means
 * Experience. Month/year ranges are unioned so concurrent jobs are not double-counted.
 * Internship/trainee periods are not treated as professional employment by default.
 */
class CandidateExperienceService
{
    public const VERSION = '2026-11-06.1';
    private const MAX_MONTHS = 720; // 60 years; avoids bad OCR ranges producing absurd results.

    private const WORK_HEADINGS = [
        'professional experience', 'work experience', 'employment history', 'career history',
        'work history', 'professional background', 'professional experience summary',
        'experience', 'employment', 'career experience',
    ];

    private const INTERNSHIP_HEADINGS = [
        'internship experience', 'internships', 'internship', 'industrial training',
        'apprenticeship', 'training experience', 'training',
    ];

    private const SUMMARY_HEADINGS = [
        'professional summary', 'career summary', 'executive summary', 'profile summary',
        'summary', 'profile', 'about me', 'career objective', 'objective', 'career profile',
    ];

    private const OTHER_HEADINGS = [
        'education', 'educational qualification', 'educational qualifications', 'education history',
        'academic qualification', 'academic qualifications', 'academics', 'qualification',
        'technical skills', 'key skills', 'skills', 'core competencies', 'competencies',
        'projects', 'project experience', 'certifications', 'certificate', 'achievements',
        'awards', 'personal details', 'personal information', 'contact details', 'languages',
        'interests', 'hobbies', 'references', 'declaration', 'publications', 'research',
        'job description', 'requirements', 'role requirements', 'position requirements',
    ];

    /**
     * @param string $resumeText Extracted resume text.
     * @param DateTimeImmutable|null $asOf Optional date for deterministic tests.
     */
    public function suggest(string $resumeText, ?DateTimeImmutable $asOf = null): array
    {
        $text = $this->normalize($resumeText);
        if ($text === '' || (function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text)) < 25) {
            return $this->emptyResult('insufficient_evidence');
        }

        try {
            $asOf = $asOf ?? new DateTimeImmutable('now');
            $sections = $this->extractSections($text);
            $workText = trim($sections['work']);
            $internshipText = trim($sections['internship']);
            $summaryText = trim($sections['summary']);
            $hasWorkHeading = $sections['has_work_heading'];
            $hasInternshipHeading = $sections['has_internship_heading'];

            // Where section headings were lost by the PDF/DOC parser, only accept date
            // ranges when their local context looks like employment and not education.
            $rangeSource = $hasWorkHeading ? $workText : $text;
            $ranges = $this->findEmploymentRanges($rangeSource, $asOf, !$hasWorkHeading);
            $rangeMonths = $this->unionMonths($ranges);

            // Trust an explicit total-years statement only in summary/work evidence. If
            // no distinct section survived extraction, require the actual word
            // "experience" and reject obvious job-requirement wording.
            $explicitSource = trim($summaryText . "\n" . $workText . "\n" . trim((string) ($sections['general'] ?? '')));
            if ($explicitSource === '') {
                $explicitSource = $text;
            }
            // Scan both section-selected evidence and the original normalized text.
            // This preserves totals when a parser has split an inline heading such as
            // `Professional Experience: 5 years` into a heading and suffix.
            $explicitMonths = max(
                $this->explicitExperienceMonths($explicitSource),
                $this->explicitExperienceMonths($text)
            );

            // Dated work periods are the primary estimate, while a clear self-reported
            // total can rescue resumes with missing employer dates or omitted roles.
            $totalMonths = max($rangeMonths, $explicitMonths);
            $hasInternshipEvidence = $hasInternshipHeading
                || preg_match('/\b(internship|intern|trainee|apprentice|apprenticeship|industrial training)\b/i', $workText . "\n" . $internshipText) === 1;
            $freshSignals = preg_match('/\b(fresher|fresh graduate|recent graduate|no professional experience|no work experience|without work experience)\b/i', $text) === 1;

            $workEvidenceText = $hasWorkHeading ? $workText : $this->fallbackEmploymentEvidence($text);
            $hasSubstantiveWork = $this->looksLikeEmployment($workEvidenceText);

            if ($totalMonths > 0) {
                $type = 2;
                $source = $rangeMonths >= $explicitMonths && $rangeMonths > 0
                    ? 'employment_date_ranges'
                    : ($explicitMonths > 0 ? 'explicit_experience_duration' : 'employment_evidence');
                $confidence = $rangeMonths > 0 && $explicitMonths > 0
                    ? 'high'
                    : (($rangeMonths > 0 || $explicitMonths > 0) ? 'high' : 'medium');
            } elseif ($hasWorkHeading && $hasSubstantiveWork) {
                // Do not make up a year count when a job is listed but dates are absent.
                $type = 2;
                $source = 'employment_history_without_dates';
                $confidence = 'medium';
            } elseif ($freshSignals || $hasInternshipEvidence || $this->hasEducationEvidence($text)) {
                // Internship-only, education-only and explicit fresher resumes are
                // Fresher classifications. The UI still makes the suggestion editable.
                $type = 1;
                $source = $freshSignals ? 'explicit_fresher_statement'
                    : ($hasInternshipEvidence ? 'internship_only_or_training' : 'no_professional_employment_found');
                $confidence = $freshSignals ? 'high' : 'medium';
            } else {
                return $this->emptyResult('insufficient_evidence');
            }

            $years = $type === 2 && $totalMonths > 0
                ? round($totalMonths / 12, 1)
                : null;

            // Store/display conventional decimal years; never suggest 0 years for an
            // experienced candidate whose dates are incomplete.
            $count = $years !== null ? rtrim(rtrim(number_format($years, 1, '.', ''), '0'), '.') : null;
            if ($count === '') $count = '0';

            return [
                'candidate_experience_type' => $type,
                'candidate_experience_type_name' => $type === 1 ? 'Fresher' : 'Experience',
                'candidate_exper_count' => $type === 1 ? '0' : $count,
                'candidate_experience_years' => $years,
                'candidate_experience_months' => $type === 1 ? 0 : ($totalMonths > 0 ? $totalMonths : null),
                'candidate_experience_source' => $source,
                'candidate_experience_confidence' => $confidence,
                'candidate_experience_date_range_count' => count($ranges),
                'candidate_experience_parser_version' => self::VERSION,
            ];
        } catch (Throwable $e) {
            // Experience suggestions are optional and must never block upload or other
            // candidate fields. The controller logs only the exception class/trace ID.
            return $this->emptyResult('parser_error');
        }
    }

    /** Split resume content into meaningful sections while tolerating inline headings. */
    private function extractSections(string $text): array
    {
        $text = $this->separateInlineHeadings($text);
        $sections = [
            'work' => [], 'internship' => [], 'summary' => [], 'other' => [], 'general' => [],
            'has_work_heading' => false, 'has_internship_heading' => false,
        ];
        $current = 'general';
        foreach (preg_split('/\R/u', $text) ?: [] as $line) {
            $line = trim((string) $line);
            if ($line === '') continue;

            $heading = $this->matchHeading($line);
            if ($heading !== null) {
                $current = $heading['section'];
                if ($current === 'work') $sections['has_work_heading'] = true;
                if ($current === 'internship') $sections['has_internship_heading'] = true;
                if ($heading['suffix'] !== '') $sections[$current][] = $heading['suffix'];
                continue;
            }
            $sections[$current][] = $line;
        }

        foreach (['work', 'internship', 'summary', 'other', 'general'] as $key) {
            $sections[$key] = implode("\n", $sections[$key]);
        }
        return $sections;
    }

    private function separateInlineHeadings(string $text): string
    {
        $all = array_merge(self::WORK_HEADINGS, self::INTERNSHIP_HEADINGS, self::SUMMARY_HEADINGS, self::OTHER_HEADINGS);
        usort($all, static fn ($a, $b) => strlen($b) <=> strlen($a));
        foreach ($all as $heading) {
            $quoted = preg_quote($heading, '/');
            // Any capitalization is accepted at a line/column boundary. In flattened
            // text, only a fully uppercase heading is split; this avoids turning prose
            // such as "required experience: 5 years" into a fake EXPERIENCE section.
            $text = preg_replace('/(^|[\r\n|•])\s*(' . $quoted . ')\s*[:|]\s*/imu', "$1\n$2: ", $text) ?? $text;
            $uppercaseHeading = preg_quote(strtoupper($heading), '/');
            $text = preg_replace('/(?<![\pL\pN])(' . $uppercaseHeading . ')\s*[:|]\s*/u', "\n$1: ", $text) ?? $text;
        }
        // Layout-preserving PDF extraction often places a heading at the far-right
        // end of a contact/details row, separated by a wide column gap, e.g.
        // "candidate@email.com          Experience". The normalizer retains a
        // two-space marker so only a known employment heading at line-end is split.
        $text = preg_replace(
            '/([^\r\n])[ \t]{2,}(professional experience|work experience|employment history|work history|experience)[ \t]*$/imu',
            "$1\n$2",
            $text
        ) ?? $text;

        return $text;
    }

    /** @return array{section:string,suffix:string}|null */
    private function matchHeading(string $line): ?array
    {
        $sets = [
            'work' => self::WORK_HEADINGS,
            'internship' => self::INTERNSHIP_HEADINGS,
            'summary' => self::SUMMARY_HEADINGS,
            'other' => self::OTHER_HEADINGS,
        ];
        foreach ($sets as $section => $labels) {
            usort($labels, static fn ($a, $b) => strlen($b) <=> strlen($a));
            $pattern = '/^\s*(' . implode('|', array_map(static fn ($v) => preg_quote($v, '/'), $labels)) . ')\s*(?:(?:[:|–—-])\s*(.*))?\s*$/iu';
            if (preg_match($pattern, $line, $match)) {
                return ['section' => $section, 'suffix' => trim((string) ($match[2] ?? ''))];
            }
        }
        return null;
    }

    /** @return array<int,array{start:int,end:int}> */
    private function findEmploymentRanges(string $text, DateTimeImmutable $asOf, bool $requireEmploymentContext): array
    {
        $months = '(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\.?[ ,\.\/-]+(?:19|20)\d{2}';
        $dayMonthYear = '(?:0?[1-9]|[12]\d|3[01])[\/.\-](?:0?[1-9]|1[0-2])[\/.\-](?:19|20)\d{2}';
        $monthYear = '(?:0?[1-9]|1[0-2])[\/.\-](?:19|20)\d{2}';
        $year = '(?:19|20)\d{2}';
        $atom = '(?:' . $months . '|' . $dayMonthYear . '|' . $monthYear . '|' . $year . ')';
        $end = '(?:' . $atom . '|present|current|now|ongoing|date|till\s+date|to\s+date|until\s+date)';
        $pattern = '/(?<![\pL\pN])(' . $atom . ')\s*(?:–|—|-|\bto\b|\bthrough\b|\btill\b|\buntil\b)\s*(' . $end . ')(?![\pL\pN])/iu';
        $rangeMatchCount = preg_match_all($pattern, $text, $matches, PREG_OFFSET_CAPTURE);
        if ($rangeMatchCount === false) return [];

        $ranges = [];
        foreach ($matches[0] as $i => $wholeMatch) {
            $full = (string) $wholeMatch[0];
            $offset = (int) $wholeMatch[1];
            $startRaw = (string) $matches[1][$i][0];
            $endRaw = (string) $matches[2][$i][0];
            $context = $this->dateRangeContext($text, $offset, strlen($full));
            if ($this->looksOnlyLikeInternship($context)) continue;
            if ($requireEmploymentContext && !$this->hasEmploymentContext($context)) continue;

            $start = $this->parseDateAtom($startRaw);
            $endDate = $this->parseDateAtom($endRaw, $asOf);
            if ($start === null || $endDate === null) continue;
            $startIndex = $start['year'] * 12 + ($start['month'] - 1);
            // End ranges are half-open. A month-specific end includes that month; a
            // year-only end is the start of that year, making 2020–2023 = 3 years.
            $endIndex = $endDate['year'] * 12 + ($endDate['month'] - 1);
            if ($endDate['precision'] === 'month') $endIndex++;
            $asOfExclusive = (int) $asOf->format('Y') * 12 + (int) $asOf->format('n');
            if ($endDate['relative'] === true) $endIndex = $asOfExclusive;
            if ($startIndex > $asOfExclusive - 1) continue;
            // A mistaken/future end year is clipped at the current month, never counted
            // as future work experience.
            $endIndex = min($endIndex, $asOfExclusive);
            if ($endIndex <= $startIndex) continue;
            if ($endIndex - $startIndex > self::MAX_MONTHS) continue;
            $ranges[] = ['start' => $startIndex, 'end' => $endIndex];
        }
        // Real resumes often say "Since 2021" or "From Jan 2020" instead of
        // writing an explicit end date. Treat that as ongoing only when a range
        // separator/end date does not immediately follow it.
        $singlePattern = '/(?<![\pL\pN])(?:since|from)\s+(' . $atom . ')(?![\pL\pN])/iu';
        if (preg_match_all($singlePattern, $text, $singleMatches, PREG_OFFSET_CAPTURE)) {
            foreach ($singleMatches[0] as $i => $wholeMatch) {
                $full = (string) $wholeMatch[0];
                $offset = (int) $wholeMatch[1];
                $tail = substr($text, $offset + strlen($full), 60);
                if (preg_match('/^\s*(?:–|—|-|\bto\b|\bthrough\b|\btill\b|\buntil\b)\s*(?:' . $end . ')/iu', $tail)) continue;
                $context = $this->dateRangeContext($text, $offset, strlen($full));
                if ($this->looksOnlyLikeInternship($context)) continue;
                if ($requireEmploymentContext && !$this->hasEmploymentContext($context)) continue;
                $start = $this->parseDateAtom((string) $singleMatches[1][$i][0]);
                if ($start === null) continue;
                $startIndex = $start['year'] * 12 + ($start['month'] - 1);
                $asOfExclusive = (int) $asOf->format('Y') * 12 + (int) $asOf->format('n');
                if ($startIndex >= $asOfExclusive || $asOfExclusive - $startIndex > self::MAX_MONTHS) continue;
                $ranges[] = ['start' => $startIndex, 'end' => $asOfExclusive];
            }
        }
        return $ranges;
    }

    /**
     * A range should be classified from the nearby job entry, not unrelated entries
     * 100+ characters away. Prefer the date line plus the immediately preceding title
     * line; flattened single-line PDFs use a bounded window instead.
     */
    private function dateRangeContext(string $text, int $offset, int $matchLength): string
    {
        $prefix = substr($text, 0, $offset);
        $lineStart = strrpos($prefix, "\n");
        $lineStart = $lineStart === false ? 0 : $lineStart + 1;
        $lineEnd = strpos($text, "\n", $offset + $matchLength);
        $lineEnd = $lineEnd === false ? strlen($text) : $lineEnd;
        $currentLine = substr($text, $lineStart, $lineEnd - $lineStart);

        if (strpos($text, "\n") !== false && strlen($currentLine) <= 1200) {
            $previousLine = '';
            if ($lineStart > 0) {
                $previousPrefix = substr($text, 0, $lineStart - 1);
                $previousStart = strrpos($previousPrefix, "\n");
                $previousStart = $previousStart === false ? 0 : $previousStart + 1;
                $previousLine = substr($text, $previousStart, ($lineStart - 1) - $previousStart);
            }
            return substr(trim($previousLine), -300) . "\n" . substr(trim($currentLine), 0, 600);
        }

        return substr($text, max(0, $offset - 80), min(strlen($text) - max(0, $offset - 80), 80 + $matchLength + 55));
    }

    /** @return array{year:int,month:int,precision:string,relative:bool}|null */
    private function parseDateAtom(string $value, ?DateTimeImmutable $asOf = null): ?array
    {
        $value = trim(strtolower($value));
        $value = preg_replace('/(?<=[a-z])\.(?=\s|,|$)/i', '', $value) ?? $value;
        if (preg_match('/^(present|current|now|ongoing|date|till\s+date|to\s+date|until\s+date)$/i', $value)) {
            $asOf = $asOf ?? new DateTimeImmutable('now');
            return ['year' => (int) $asOf->format('Y'), 'month' => (int) $asOf->format('n'), 'precision' => 'month', 'relative' => true];
        }
        $monthNumbers = [
            'jan' => 1, 'january' => 1, 'feb' => 2, 'february' => 2, 'mar' => 3, 'march' => 3,
            'apr' => 4, 'april' => 4, 'may' => 5, 'jun' => 6, 'june' => 6, 'jul' => 7, 'july' => 7,
            'aug' => 8, 'august' => 8, 'sep' => 9, 'sept' => 9, 'september' => 9,
            'oct' => 10, 'october' => 10, 'nov' => 11, 'november' => 11, 'dec' => 12, 'december' => 12,
        ];
        if (preg_match('/^([a-z]+)\s+((?:19|20)\d{2})$/i', $value, $m) && isset($monthNumbers[$m[1]])) {
            return ['year' => (int) $m[2], 'month' => $monthNumbers[$m[1]], 'precision' => 'month', 'relative' => false];
        }
        if (preg_match('/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-]((?:19|20)\d{2})$/', $value, $m)) {
            // Indian resume convention: DD/MM/YYYY. If the first component cannot be
            // a month, use it as the day and the second as the month; accept MM/DD too.
            $month = (int) $m[2];
            if ((int) $m[2] > 12 && (int) $m[1] <= 12) $month = (int) $m[1];
            if ($month < 1 || $month > 12) return null;
            return ['year' => (int) $m[3], 'month' => $month, 'precision' => 'month', 'relative' => false];
        }
        if (preg_match('/^(\d{1,2})[\/.\-]((?:19|20)\d{2})$/', $value, $m)) {
            $month = (int) $m[1];
            if ($month < 1 || $month > 12) return null;
            return ['year' => (int) $m[2], 'month' => $month, 'precision' => 'month', 'relative' => false];
        }
        if (preg_match('/^((?:19|20)\d{2})$/', $value, $m)) {
            return ['year' => (int) $m[1], 'month' => 1, 'precision' => 'year', 'relative' => false];
        }
        return null;
    }

    /** @param array<int,array{start:int,end:int}> $ranges */
    private function unionMonths(array $ranges): int
    {
        if (!$ranges) return 0;
        usort($ranges, static fn ($a, $b) => $a['start'] <=> $b['start']);
        $start = $ranges[0]['start'];
        $end = $ranges[0]['end'];
        $total = 0;
        foreach (array_slice($ranges, 1) as $range) {
            if ($range['start'] <= $end) {
                $end = max($end, $range['end']);
                continue;
            }
            $total += $end - $start;
            $start = $range['start'];
            $end = $range['end'];
        }
        $total += $end - $start;
        return min(self::MAX_MONTHS, max(0, $total));
    }

    private function explicitExperienceMonths(string $text): int
    {
        $best = 0;
        $lines = preg_split('/\R/u', $text) ?: [$text];
        foreach ($lines as $lineIndex => $line) {
            $line = trim((string) $line);
            $previousLine = trim((string) ($lines[$lineIndex - 1] ?? ''));
            $requirementPattern = '/\b(required experience|minimum experience|experience required|job requirement|job description|vacancy|candidates must|qualification required|years of experience required)\b|\b(?:minimum|required|preferred|at least|must have|should have)\b.{0,45}\b(?:years?|yrs?|months?|mos?)\b.{0,35}\bexperience\b|\bexperience\b.{0,35}\b(?:required|minimum|preferred|must have|should have)\b/i';
            if ($line === ''
                || preg_match($requirementPattern, $line . ' ' . $previousLine)
                || preg_match('/\b(internship|intern|trainee|apprentice|apprenticeship|industrial training)\b/i', $line)
                || preg_match('/\b(internship|intern|trainee|apprentice|apprenticeship|industrial training)\b/i', $previousLine)) continue;
            $patterns = [
                '/\b(\d{1,2}(?:\.\d{1,2})?)\s*(?:\+|plus)?\s*(?:years?|yrs?)\s*(?:(?:(?:and|,)\s*)?(\d{1,2})\s*(?:months?|mos?))?.{0,45}\bexperience\b/iu',
                '/\bexperience\s*(?:of|is|:|[-–])?\s*(\d{1,2}(?:\.\d{1,2})?)\s*(?:\+|plus)?\s*(?:years?|yrs?)\s*(?:(?:(?:and|,)\s*)?(\d{1,2})\s*(?:months?|mos?))?/iu',
                '/\b(\d{1,2})\s*(?:years?|yrs?)\s*(?:(?:and|,)\s*)?(\d{1,2})\s*(?:months?|mos?)\s*(?:of\s+)?(?:professional\s+|work\s+)?experience\b/iu',
            ];
            foreach ($patterns as $pattern) {
                if (!preg_match_all($pattern, $line, $hits, PREG_SET_ORDER)) continue;
                foreach ($hits as $hit) {
                    $years = (float) $hit[1];
                    $months = isset($hit[2]) && $hit[2] !== '' ? (int) $hit[2] : 0;
                    $candidate = (int) round($years * 12) + min(11, max(0, $months));
                    if ($candidate > 0 && $candidate <= self::MAX_MONTHS) $best = max($best, $candidate);
                }
            }
            if (preg_match_all('/\b(\d{1,2})\s*(?:months?|mos?)\s*(?:of\s+)?(?:professional\s+|work\s+)?experience\b/iu', $line, $monthHits, PREG_SET_ORDER)) {
                foreach ($monthHits as $hit) {
                    $candidate = min(self::MAX_MONTHS, max(0, (int) $hit[1]));
                    $best = max($best, $candidate);
                }
            }
            if (preg_match_all('/\bexperience\s*(?:of|is|:|[-–])?\s*(\d{1,2})\s*(?:months?|mos?)\b/iu', $line, $monthHits, PREG_SET_ORDER)) {
                foreach ($monthHits as $hit) {
                    $candidate = min(self::MAX_MONTHS, max(0, (int) $hit[1]));
                    $best = max($best, $candidate);
                }
            }
        }
        return $best;
    }

    private function hasEmploymentContext(string $context): bool
    {
        if (preg_match('/\b(education|academic|university|college|school|graduation|bachelor|master|diploma|class\s*(?:10|12)|hsc|sslc|internship|intern|trainee|apprentice|project|certification|certified)\b/i', $context)) {
            // A mixed context can have both a job cue and education cue; reject only if
            // it contains no credible employment marker after stripping those terms.
            $clean = preg_replace('/\b(education|academic|university|college|school|graduation|bachelor|master|diploma|class\s*(?:10|12)|hsc|sslc|internship|intern|trainee|apprentice|project|certification|certified)\b/i', ' ', $context) ?? $context;
            if (!$this->hasEmploymentCue($clean)) return false;
        }
        return $this->hasEmploymentCue($context);
    }

    private function hasEmploymentCue(string $text): bool
    {
        return preg_match('/\b(software|web|app|front[ -]?end|back[ -]?end|full[ -]?stack|developer|engineer|designer|analyst|accountant|accounts|executive|manager|officer|consultant|teacher|professor|lecturer|nurse|doctor|technician|administrator|coordinator|recruiter|hr executive|sales|marketing|operator|cashier|supervisor|director|worked at|working at|employed|employment|responsible for|handled|managed|maintained|processed|prepared|developed|coordinated|organization|organisation|company|corporation|limited|pvt\.?\s*ltd|llp|inc\b|designation|job title|work experience|professional experience|representative|specialist|associate|clerk|support|customer service|operations|quality assurance|tester|technologist|data entry|paralegal|product manager|civil|mechanical|electrical|researcher|scientist|writer|editor|driver|laboratory|lab assistant|admin assistant)\b/i', $text) === 1;
    }

    private function fallbackEmploymentEvidence(string $text): string
    {
        $lines = preg_split('/\R/u', $text) ?: [];
        $selected = [];
        foreach ($lines as $i => $line) {
            $line = trim((string) $line);
            if ($line === '' || $this->looksOnlyLikeInternship($line)) continue;
            $neighbors = array_filter([
                trim((string) ($lines[$i - 1] ?? '')),
                $line,
                trim((string) ($lines[$i + 1] ?? '')),
            ], static fn ($part) => $part !== '' && preg_match('/\b(internship|intern|trainee|apprentice|apprenticeship|industrial training)\b/i', $part) !== 1);
            $context = trim(implode(' ', $neighbors));
            if ($this->hasEmploymentCue($context)) $selected[] = $context;
        }
        return implode("\n", array_unique($selected));
    }

    private function looksLikeEmployment(string $text): bool
    {
        $text = trim($text);
        if ($text === '') return false;

        $lines = preg_split('/\R/u', $text) ?: [];
        $hasInternshipLanguage = preg_match('/\b(internship|intern|trainee|apprentice|apprenticeship|industrial training)\b/i', $text) === 1;
        $nonInternshipLines = [];
        foreach ($lines as $line) {
            $line = trim((string) $line);
            if ($line === '' || preg_match('/\b(internship|intern|trainee|apprentice|apprenticeship|industrial training)\b/i', $line) === 1) continue;
            $nonInternshipLines[] = $line;
        }
        $nonInternshipText = trim(implode("\n", $nonInternshipLines));
        if ($nonInternshipText === '') return false;

        // Mixed internship + regular job content must contain a role/employer cue
        // on a non-internship line; generic intern duties alone are not employment.
        if ($hasInternshipLanguage) {
            return preg_match('/\b(developer|engineer|designer|analyst|accountant|accounts executive|manager|officer|consultant|teacher|professor|lecturer|nurse|doctor|technician|administrator|coordinator|recruiter|hr executive|sales executive|marketing executive|operator|cashier|supervisor|director|company|corporation|limited|pvt\.?\s*ltd|llp|inc\b|designation|job title|employer|worked at|working at|employed|full[- ]time|part[- ]time|permanent role|customer support executive|customer service representative|data entry operator|lab assistant|quality assurance)\b/i', $nonInternshipText) === 1;
        }

        return $this->hasEmploymentCue($nonInternshipText)
            || preg_match('/\b(responsible for|worked on|work(ed)? at|job title|designation|employer|company|full[- ]time|part[- ]time|permanent role)\b/i', $nonInternshipText) === 1;
    }

    private function looksOnlyLikeInternship(string $text): bool
    {
        return preg_match('/\\b(internship|intern|trainee|apprentice|apprenticeship|industrial training)\\b/i', $text) === 1;
    }

    private function hasEducationEvidence(string $text): bool
    {
        return preg_match('/\b(education|academic qualification|university|college|school|bachelor|master|b\.?tech|b\.?e\.?|bca|b\.?com|b\.?sc|mca|m\.?com|m\.?sc|mba|ph\.?d|doctorate|diploma|hsc|sslc|12th|10th|higher secondary|undergraduate|postgraduate)\b/i', $text) === 1;
    }

    private function normalize(string $text): string
    {
        $text = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        $text = preg_replace('/[\x{00A0}\x{200B}\x{FEFF}]+/u', ' ', $text) ?? $text;
        $text = preg_replace('/[ \t]{3,}/u', '  ', $text) ?? $text;
        $text = preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text;
        return trim($text);
    }

    private function emptyResult(string $status): array
    {
        return [
            'candidate_experience_type' => null,
            'candidate_experience_type_name' => null,
            'candidate_exper_count' => null,
            'candidate_experience_years' => null,
            'candidate_experience_months' => null,
            'candidate_experience_source' => $status,
            'candidate_experience_confidence' => 'low',
            'candidate_experience_date_range_count' => 0,
            'candidate_experience_parser_version' => self::VERSION,
        ];
    }
}
