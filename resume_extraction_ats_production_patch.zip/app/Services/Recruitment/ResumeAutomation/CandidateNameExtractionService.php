<?php

namespace App\Services\Recruitment\ResumeAutomation;

use Illuminate\Support\Facades\Log;
use Throwable;

/** Extracts and verifies the candidate's name from a bounded resume excerpt. */
class CandidateNameExtractionService
{
    public const VERSION = '2026-11-06.2';

    private const MAX_EXTERNAL_HEADER_LINES = 48;
    private const MAX_EXTERNAL_HEADER_CHARS = 5200;

    /** Safe, non-PII counters for diagnosing extraction order/formatting problems. */
    private array $lastDiagnostics = [];

    /** Non-PII AI outcome for troubleshooting 200-but-unusable model responses. */
    private string $lastAiResultStatus = 'not_attempted';

    public function __construct(private HuggingFaceInferenceService $huggingFace)
    {
    }

    /**
     * @return array{candidate_name:?string,source:string,model:?string,review_required:bool,parser_version:string,ai_attempted:bool}
     */
    public function extract(string $resumeText): array
    {
        $this->lastAiResultStatus = 'not_attempted';

        // Run the free, source-grounded parser first. When the identity header is
        // sufficiently clear, do not spend a paid inference request just to repeat
        // the same answer. AI is reserved for genuinely ambiguous/irregular headers.
        $localResult = $this->extractLocallyOnly($resumeText);
        if (!empty($localResult['candidate_name'])) {
            $this->lastAiResultStatus = 'not_needed_local_verified';
            $localResult['ai_attempted'] = false;
            $localResult['ai_result_status'] = $this->lastAiResultStatus;
            return $localResult;
        }

        $normalizedText = $this->normalizeResumeTextForNameParsing($resumeText);
        $context = $this->getHeader($normalizedText);
        $aiAttempted = false;

        if ($context !== '') {
            $redactedContext = $this->redactHeaderForExternalInference($context);
            try {
                foreach ($this->huggingFace->extractNameCandidates($redactedContext) as $candidate) {
                    $aiAttempted = true;
                    $rawName = trim((string) ($candidate['name'] ?? ''));
                    if ($rawName === '') {
                        $this->lastAiResultStatus = 'empty_name';
                        break;
                    }

                    // Repair only empty separators. Never invent letters or accept
                    // markup; all returned values must still match source evidence.
                    $hadEmptySeparators = (bool) preg_match('/<>/u', $rawName);
                    if ($hadEmptySeparators) {
                        $rawName = preg_replace('/\s*<>\s*/u', '', $rawName) ?? $rawName;
                        $rawName = preg_replace('/\s+/u', ' ', trim($rawName)) ?? trim($rawName);
                    }
                    if (preg_match('/[<>]/u', $rawName)) {
                        $this->lastAiResultStatus = 'malformed_name';
                        break;
                    }

                    $formatted = $this->formatNameForDisplay($rawName);
                    $repaired = $formatted !== ''
                        ? $this->completeModelNameFromSourceLine($formatted, $resumeText)
                        : null;
                    if ($repaired === null) {
                        $repaired = $this->recoverExactSourceNameByCompactLetters($rawName, $resumeText);
                    }
                    if ($repaired === null && $formatted !== '') {
                        $repaired = $this->completeModelNameFromCompactOcrLine($formatted, $resumeText);
                    }
                    if ($repaired !== null) $formatted = $repaired;

                    // Single-token names are accepted only when the source verifier
                    // can place them in the opening identity header or an explicit
                    // name field. A contact-adjacent employer line is never enough.
                    if ($formatted === '' || !$this->isPlausibleName($formatted, true)) {
                        $this->lastAiResultStatus = $hadEmptySeparators ? 'malformed_name' : 'implausible_name';
                        break;
                    }

                    if (!$this->hasReliableNameEvidence($formatted, $resumeText)) {
                        $this->lastAiResultStatus = 'source_evidence_rejected';
                        break;
                    }

                    $this->lastAiResultStatus = $hadEmptySeparators ? 'accepted_after_artifact_repair' : 'accepted';
                    $source = ((int) ($candidate['model_index'] ?? 0)) === 0
                        ? 'huggingface_primary'
                        : 'huggingface_fallback';

                    return [
                        'candidate_name' => $formatted,
                        'source' => $source,
                        'model' => isset($candidate['model']) ? (string) $candidate['model'] : null,
                        'review_required' => true,
                        'parser_version' => self::VERSION,
                        'ai_attempted' => true,
                        'ai_result_status' => $this->lastAiResultStatus,
                    ];
                }

                $didAttemptRequest = method_exists($this->huggingFace, 'wasLastRequestAttempted')
                    ? (bool) $this->huggingFace->wasLastRequestAttempted()
                    : $aiAttempted;
                $aiAttempted = $aiAttempted || $didAttemptRequest;
                if ($didAttemptRequest && $this->lastAiResultStatus === 'not_attempted') {
                    $this->lastAiResultStatus = 'empty_or_invalid_model_output';
                }
            } catch (Throwable $e) {
                Log::warning('Candidate name AI extraction failed; retaining deterministic result', [
                    'exception' => get_class($e),
                ]);
                $this->lastAiResultStatus = 'request_failed';
                $aiAttempted = true;
            }
        }

        // The local scan already ran before inference. Reuse its result rather than
        // running the same parser twice or using another model request as a retry.
        $localResult['ai_attempted'] = $aiAttempted;
        $localResult['ai_result_status'] = $this->lastAiResultStatus;
        return $localResult;
    }

    /**
     * Run deterministic extraction only. Used after AI has been attempted or on OCR text.
     *
     * @return array{candidate_name:?string,source:string,model:?string,review_required:bool,parser_version:string,ai_attempted:bool}
     */
    public function extractLocallyOnly(string $resumeText): array
    {
        $local = $this->extractLocally($resumeText);
        if ($local !== null) {
            return [
                'candidate_name' => $local,
                'source' => 'local_parser',
                'model' => null,
                'review_required' => true,
                'parser_version' => self::VERSION,
                'ai_attempted' => false,
                'ai_result_status' => 'not_needed_local_verified',
            ];
        }

        $notFound = $this->notFound(false);
        $notFound['ai_result_status'] = 'not_attempted';
        return $notFound;
    }

    /** Diagnostics are counters only; they never contain extracted resume text. */
    public function getLastDiagnostics(): array
    {
        return $this->lastDiagnostics;
    }

    /** Non-PII status code for AI output quality; never expose the model text. */
    public function getLastAiResultStatus(): string
    {
        return $this->lastAiResultStatus;
    }

    /** Server-side display normalization for the value saved in egc_applicant. */
    public function formatNameForDisplay(string $value): string
    {
        $name = $this->cleanNameCandidate($value);
        if ($name === '') return '';

        $lower = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
        $formatted = preg_replace_callback(
            '/(^|[\s.\'’\-])([\p{L}])/u',
            static function (array $match): string {
                $letter = function_exists('mb_strtoupper')
                    ? mb_strtoupper($match[2], 'UTF-8')
                    : strtoupper($match[2]);
                return $match[1] . $letter;
            },
            $lower
        );
        $formatted = is_string($formatted) ? $formatted : $name;
        $formatted = preg_replace_callback('/\bMc([\p{L}])/u', static function (array $match): string {
            $letter = function_exists('mb_strtoupper') ? mb_strtoupper($match[1], 'UTF-8') : strtoupper($match[1]);
            return 'Mc' . $letter;
        }, $formatted) ?? $formatted;

        return trim(preg_replace('/\s+/u', ' ', $formatted) ?? $formatted);
    }

    private function extractLocally(string $resumeText): ?string
    {
        // Bounded full-text fallback. Header placement gets priority, but out-of-order
        // PDF reading can place the name elsewhere, so also allow candidates close to
        // their phone/email evidence. Never choose a phrase merely because it looks
        // title-cased inside a skills, projects, education or certifications list.
        $scanText = function_exists('mb_substr')
            ? mb_substr($resumeText, 0, 20000, 'UTF-8')
            : substr($resumeText, 0, 20000);
        $originalLines = preg_split('/\R/u', str_replace(["\r\n", "\r"], "\n", $scanText)) ?: [];
        $longLineCount = 0;
        foreach ($originalLines as $rawLine) {
            if ((function_exists('mb_strlen') ? mb_strlen(trim((string) $rawLine), 'UTF-8') : strlen(trim((string) $rawLine))) > 180) {
                $longLineCount++;
            }
        }
        $normalized = $this->normalizeResumeTextForNameParsing($scanText);
        $rawLines = preg_split('/\R/u', str_replace(["\r\n", "\r"], "\n", $normalized)) ?: [];
        $lines = $this->expandLinesForNameParsing($rawLines);
        $this->lastDiagnostics = [
            'raw_line_count' => count($rawLines),
            'expanded_line_count' => count($lines),
            'long_raw_line_count' => $longLineCount,
            'candidate_segments_scanned' => 0,
            'plausible_candidates' => 0,
            'rejected_section_candidates' => 0,
            'best_candidate_score' => 0,
            'best_candidate_non_empty_index' => 0,
            'best_candidate_has_identity_contact' => false,
            'best_candidate_in_list_section' => false,
            'explicit_name_label_match' => false,
        ];
        $explicitPattern = '/^\s*(?:(?:candidate|applicant)(?:\s+(?:full\s+)?name)?|full\s+name|name\s+of\s+(?:the\s+)?(?:candidate|applicant)|name)\s*[:\-–]\s*(.*?)\s*$/iu';

        // Explicit labels are strong evidence regardless of where a PDF parser put
        // the line, but require the value itself to be plausible and exact.
        foreach (array_slice($lines, 0, 100) as $line) {
            $line = trim((string) $line);
            if ($line === '' || !preg_match($explicitPattern, $line, $match)) continue;
            $candidate = $this->formatNameForDisplay((string) ($match[1] ?? ''));
            if ($this->isPlausibleName($candidate, true)
                && $this->hasExactNameLineEvidence($candidate, $line)) {
                $this->lastDiagnostics['explicit_name_label_match'] = true;
                $this->lastDiagnostics['best_candidate_score'] = 200;
                $this->lastDiagnostics['best_candidate_non_empty_index'] = 1;
                return $candidate;
            }
        }

        // High-confidence PDF header recovery: some two-column resumes are emitted
        // in visual order with the candidate's name on the first page before the
        // "Education" heading, while the contact column is emitted much later.
        // Do not require nearby phone/email evidence in this bounded header zone.
        // This prevents a summary phrase (e.g. "Organization Improve") from winning
        // merely because the PDF text order placed it next to Contact Details.
        $headerCandidates = [];
        $headerNonEmpty = 0;
        $headerLimit = min(count($lines), 24);
        for ($headerIndex = 0; $headerIndex < $headerLimit; $headerIndex++) {
            $headerLine = trim((string) $lines[$headerIndex]);
            if ($headerLine === '') continue;
            if ($this->isSectionHeading($headerLine)) break;
            $headerNonEmpty++;
            if ($this->isNonOwnerIdentityLine($headerLine)
                || preg_match('/^\\s*(?:[•●▪◦‣·*]+|[-–—]\\s+|\\d{1,3}\\s*[.)])/u', $headerLine)) {
                continue;
            }
            $segment = $this->candidateSegmentFromLine($headerLine);
            if ($segment === null) continue;
            $candidate = $this->formatNameForDisplay($segment);
            if ($this->isPlausibleName($candidate, false)) {
                $headerCandidates[] = ['name' => $candidate, 'index' => $headerNonEmpty, 'priority' => 0];
                continue;
            }

            // A PDF may split a two-word name over adjacent text runs ("Aditi" +
            // "Rao"). Try the joined value first. If the next line is merely a
            // subtitle/design label, retain a one-word identity only when it is the
            // very first non-empty, standalone line. This supports mononyms without
            // promoting one-word job titles or body text.
            $joinedAccepted = false;
            $nextIndex = $headerIndex + 1;
            while ($nextIndex < $headerLimit && trim((string) $lines[$nextIndex]) === '') $nextIndex++;
            $nextLine = $nextIndex < $headerLimit ? trim((string) $lines[$nextIndex]) : '';
            if ($nextLine !== '' && !$this->isSectionHeading($nextLine)
                && !$this->isNonOwnerIdentityLine($nextLine)
                && !preg_match('/@|\b(?:phone|mobile|contact|email|dob|date of birth|address)\b|\d{7,}/iu', $nextLine)) {
                $nextSegment = $this->candidateSegmentFromLine($nextLine);
                if ($nextSegment !== null) {
                    $joined = $this->formatNameForDisplay($segment . ' ' . $nextSegment);
                    if ($this->isPlausibleName($joined, false)) {
                        $headerCandidates[] = ['name' => $joined, 'index' => $headerNonEmpty, 'priority' => -1];
                        $joinedAccepted = true;
                    }
                }
            }

            $genericHeaderPrefix = true;
            foreach (array_slice($lines, 0, $headerIndex) as $previousHeaderLine) {
                $previousHeaderLine = trim((string) $previousHeaderLine);
                if ($previousHeaderLine === '') continue;
                $previousNorm = $this->normalizeForMatch($previousHeaderLine);
                if (!in_array($previousNorm, ['resume', 'curriculum vitae', 'cv', 'profile', 'common', 'candidate profile', 'biodata', 'bio data'], true)) {
                    $genericHeaderPrefix = false;
                    break;
                }
            }
            if (!$joinedAccepted && $headerNonEmpty <= 3 && $genericHeaderPrefix
                && $this->isPlausibleName($candidate, true)
                && $this->hasExactNameLineEvidence($candidate, $headerLine)) {
                $headerCandidates[] = ['name' => $candidate, 'index' => $headerNonEmpty, 'priority' => 1];
            }
        }
        if ($headerCandidates !== []) {
            // Prefer the earliest complete name in the identity header.
            usort($headerCandidates, static fn (array $a, array $b): int => ($a['index'] <=> $b['index']) ?: (($a['priority'] ?? 0) <=> ($b['priority'] ?? 0)));
            $this->lastDiagnostics['best_candidate_score'] = 180;
            $this->lastDiagnostics['best_candidate_non_empty_index'] = $headerCandidates[0]['index'];
            $this->lastDiagnostics['best_candidate_has_identity_contact'] = false;
            $this->lastDiagnostics['best_candidate_in_list_section'] = false;
            $this->lastDiagnostics['header_identity_match'] = true;
            return $headerCandidates[0]['name'];
        }

        $bestName = null;
        $bestScore = -INF;
        $nonEmptyIndex = 0;
        $activeSection = '';
        $listSections = [
            'technical skills', 'skills', 'key skills', 'soft skills', 'projects',
            'certifications', 'certification', 'education', 'academic details',
            'professional experience', 'work experience', 'experience',
            'awards', 'achievements', 'interests', 'hobbies',
        ];
        $maxLines = min(count($lines), 220);

        for ($i = 0; $i < $maxLines; $i++) {
            $lineWithMarkers = (string) $lines[$i];
            $rawLine = trim($lineWithMarkers);
            if ($rawLine === '') continue;
            $this->lastDiagnostics['candidate_segments_scanned']++;
            $nonEmptyIndex++;

            if ($this->isSectionHeading($rawLine)) {
                $activeSection = $this->normalizeForMatch($rawLine);
                continue;
            }
            // Never select a company, position or project label from the body of
            // the resume, even when the PDF reading order puts contact details next
            // to it. Explicit candidate-name labels were handled above.
            if (in_array($activeSection, ['professional experience', 'work experience', 'experience'], true)) {
                $this->lastDiagnostics['rejected_section_candidates']++;
                continue;
            }

            $isListItem = preg_match('/^\s*(?:[•●▪◦‣·*]+|[-–—]\s+|\d{1,3}\s*[.)])\s*/u', $lineWithMarkers) === 1;
            if ($isListItem || $this->isNonOwnerIdentityLine($rawLine)) continue;

            $candidateSegment = $this->candidateSegmentFromLine($rawLine);
            if ($candidateSegment === null) continue;
            $candidate = $this->formatNameForDisplay($candidateSegment);
            $evidenceText = $candidateSegment;

            // Support line-wrapped names only when an initial/first token is followed
            // by a short continuation, not a list item or contact/body line.
            if (!$this->isPlausibleName($candidate, false)
                && count(preg_split('/\s+/u', trim($candidateSegment)) ?: []) === 1) {
                $nextIndex = $i + 1;
                while ($nextIndex < $maxLines && trim((string) $lines[$nextIndex]) === '') $nextIndex++;
                $nextRaw = $nextIndex < $maxLines ? trim((string) $lines[$nextIndex]) : '';
                $nextIsList = preg_match('/^\s*(?:[•●▪◦‣·*]+|[-–—]\s+|\d{1,3}\s*[.)])\s*/u', (string) ($lines[$nextIndex] ?? '')) === 1;
                if ($nextRaw !== '' && !$nextIsList && !$this->isSectionHeading($nextRaw)
                    && !preg_match('/@|\b(?:phone|mobile|contact|email)\b|\b\d{7,}\b/iu', $nextRaw)) {
                    $nextSegment = $this->candidateSegmentFromLine($nextRaw);
                    if ($nextSegment !== null && count(preg_split('/\s+/u', trim($nextSegment)) ?: []) <= 3) {
                        $joined = $candidateSegment . ' ' . $nextSegment;
                        $joinedCandidate = $this->formatNameForDisplay($joined);
                        if ($this->isPlausibleName($joinedCandidate, false)) {
                            $candidateSegment = $joined;
                            $candidate = $joinedCandidate;
                            $evidenceText = $joined;
                        }
                    }
                }
            }

            if (!$this->isPlausibleName($candidate, false)) continue;
            $this->lastDiagnostics['plausible_candidates']++;
            if (!$this->hasExactNameLineEvidence($candidate, $evidenceText)) continue;

            $nearby = (string) ($lines[$i - 1] ?? '') . ' ' . (string) ($lines[$i + 1] ?? '') . ' ' . (string) ($lines[$i + 2] ?? '');
            $hasIdentityContact = (bool) preg_match('/@|\b(?:phone|mobile|contact|email)\b|\b[6-9]\d{9}\b|\+?\d[\d\s().-]{7,}\d/iu', $nearby);
            $inListSection = in_array($activeSection, $listSections, true);

            // Employment entries are never candidate-name evidence. Skills/projects
            // may be encountered before the identity block in flattened two-column
            // PDFs, but are accepted only with immediate owner-contact evidence.
            if (in_array($activeSection, ['professional experience', 'work experience', 'experience'], true)
                || ($inListSection && !$hasIdentityContact)) {
                $this->lastDiagnostics['rejected_section_candidates']++;
                continue;
            }

            // A candidate far into body text requires neighboring identity evidence;
            // this prevents award names such as "Poetry Competition" from winning.
            if ($nonEmptyIndex > 12 && !$hasIdentityContact) continue;

            $score = 100.0;
            $score -= min(60, max(0, $nonEmptyIndex - 1)) * 1.5;
            if (preg_match('/\p{Lu}/u', $candidateSegment) && !preg_match('/\p{Ll}/u', $candidateSegment)) {
                $score += 28;
            } elseif (preg_match('/^\p{Lu}[\p{L}\p{M}]+(?:\s|$)/u', $candidateSegment)) {
                $score += 10;
            }
            $tokens = preg_split('/\s+/u', trim($candidate)) ?: [];
            if (count($tokens) >= 2 && count($tokens) <= 5) $score += 6;
            if ($nonEmptyIndex <= 8) $score += 16;
            if ($hasIdentityContact) $score += 60;
            if ($inListSection) $score -= 8; // only possible with nearby contact evidence

            if ($score > $bestScore) {
                $bestScore = $score;
                $bestName = $candidate;
                $this->lastDiagnostics['best_candidate_score'] = (int) round($score);
                $this->lastDiagnostics['best_candidate_non_empty_index'] = $nonEmptyIndex;
                $this->lastDiagnostics['best_candidate_has_identity_contact'] = $hasIdentityContact;
                $this->lastDiagnostics['best_candidate_in_list_section'] = $inListSection;
            }
        }

        if ($bestScore >= 70 && $bestName !== null) {
            return $bestName;
        }

        // Last-resort high-precision identity-header pass. In some deployed PDF
        // parsers the line normalization differs between evidence checks and the
        // original segment; this pass re-evaluates only early identity-like lines
        // and lines directly adjacent to the owner's contact block. It never scans
        // skills/certifications as possible names without identity-contact evidence.
        return $this->extractFromIdentityHeader($lines);
    }

    /** @param list<string> $lines */
    private function extractFromIdentityHeader(array $lines): ?string
    {
        $activeSection = '';
        $nonEmptyIndex = 0;
        $listSections = [
            'technical skills', 'skills', 'key skills', 'soft skills', 'projects',
            'certifications', 'certification', 'education', 'academic details',
            'professional experience', 'work experience', 'experience', 'awards',
            'achievements', 'interests', 'hobbies', 'languages', 'key competencies',
        ];
        $best = null;
        $bestScore = -INF;
        $max = min(count($lines), 120);

        for ($i = 0; $i < $max; $i++) {
            $raw = trim((string) $lines[$i]);
            if ($raw === '') continue;
            $nonEmptyIndex++;
            if ($this->isSectionHeading($raw)) {
                $activeSection = $this->normalizeForMatch($raw);
                continue;
            }
            if (in_array($activeSection, ['professional experience', 'work experience', 'experience'], true)) continue;
            if ($this->isNonOwnerIdentityLine($raw)) continue;
            if ($nonEmptyIndex > 30 && !in_array($activeSection, $listSections, true)) break;
            if (preg_match('/^\s*(?:[•●▪◦‣·*]+|[-–—]\s+|\d{1,3}\s*[.)])\s*/u', $raw)) continue;

            $segment = $this->candidateSegmentFromLine($raw);
            if ($segment === null) continue;
            $candidate = $this->formatNameForDisplay($segment);
            if (!$this->isPlausibleName($candidate, false)) continue;

            $nearby = $raw . ' ' . (string) ($lines[$i - 1] ?? '') . ' ' . (string) ($lines[$i + 1] ?? '') . ' ' . (string) ($lines[$i + 2] ?? '');
            $hasContact = (bool) preg_match('/@|\b(?:phone|mobile|contact|email)\b|(?<!\d)[6-9](?:[\s().-]*\d){9}(?!\d)|(?:\+|00)?91[\s().-]*[6-9](?:[\s().-]*\d){9}/iu', $nearby);
            if (in_array($activeSection, ['professional experience', 'work experience', 'experience'], true)) continue;
            if (in_array($activeSection, $listSections, true) && !$hasContact) continue;
            if ($nonEmptyIndex > 12 && !$hasContact) continue;

            $score = 100 - min(45, max(0, $nonEmptyIndex - 1) * 3);
            if ($nonEmptyIndex <= 4) $score += 25;
            if ($hasContact) $score += 55;
            if (preg_match('/^\s*\p{Lu}[\p{L}\p{M} .\'’\-]{1,70}\s*$/u', $segment)
                && !preg_match('/\p{Ll}/u', $segment)) $score += 12;
            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $candidate;
                $this->lastDiagnostics['best_candidate_score'] = (int) round($score);
                $this->lastDiagnostics['best_candidate_non_empty_index'] = $nonEmptyIndex;
                $this->lastDiagnostics['best_candidate_has_identity_contact'] = $hasContact;
                $this->lastDiagnostics['best_candidate_in_list_section'] = in_array($activeSection, $listSections, true);
            }
        }

        return $bestScore >= 100 ? $best : null;
    }

    /** Return a possible single-line name before contact data; null means noisy text. */
    private function candidateSegmentFromLine(string $line): ?string
    {
        $line = trim($line);
        $lineLength = function_exists('mb_strlen') ? mb_strlen($line, 'UTF-8') : strlen($line);
        if ($line === '' || $lineLength > 180 || $this->isNonOwnerIdentityLine($line)) return null;
        $line = preg_replace('/^\s*(?:(?:candidate|applicant)(?:\s+(?:full\s+)?name)?|full\s+name|name\s+of\s+(?:the\s+)?(?:candidate|applicant)|name)\s*[:\-–]\s*/iu', '', $line) ?? $line;
        // Some Indian resume headers put the contact label before the value, e.g.
        // "Aditi Rao - Mobile: 987...". Cut the label and everything after it.
        $line = preg_replace('/\s*[-–|,]?\s*(?:phone|mobile|contact|email|e-mail)\s*[:\-].*$/iu', '', $line) ?? $line;
        if (preg_match('/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/iu', $line)
            && !preg_match('/\s*[|•]\s*/u', $line)) {
            $line = preg_replace('/\s+[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}.*$/iu', '', $line) ?? $line;
        }
        // Common PDF header layout: NAME | PHONE | EMAIL | CITY.
        if (preg_match('/\s*[|]\s*/u', $line)) {
            $line = (preg_split('/\s*[|]\s*/u', $line) ?: [$line])[0];
        }
        $line = preg_replace('/\s+\+?\d[\d\s().-]{7,}\d\b.*$/u', '', $line) ?? $line;
        $line = preg_replace('/\s+[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}.*$/iu', '', $line) ?? $line;
        $line = preg_replace('~\s+(?:https?://|www\.).*$~iu', '', $line) ?? $line;
        $line = trim($line, " \t\n\r\0\x0B,;:|•●▪◦‣·");

        // Layout parsers may pad the left edge, already trimmed above. Reject line
        // fragments that look like a sentence or metadata rather than a name.
        if ($line === '' || preg_match('/[:@]/u', $line)) return null;
        if (preg_match('/\b(?:madurai|tamil\s+nadu|india)\b/iu', $line) && str_word_count($line) > 2) return null;
        return $line;
    }

    /**
     * Reliable candidate evidence must be in a header-like line, be explicitly
     * labelled, or be close to phone/email identity details. A match solely inside
     * certifications, projects, skills, education or experience is not sufficient.
     */
    private function hasReliableNameEvidence(string $candidateName, string $sourceText): bool
    {
        $wanted = $this->normalizeForMatch($candidateName);
        if ($wanted === '') return false;

        $sourceText = function_exists('mb_substr')
            ? mb_substr($sourceText, 0, 20000, 'UTF-8')
            : substr($sourceText, 0, 20000);
        $normalized = $this->normalizeResumeTextForNameParsing($sourceText);
        $lines = $this->expandLinesForNameParsing(preg_split('/\R/u', $normalized) ?: []);
        $activeSection = '';
        $nonEmptyIndex = 0;
        $previousHeaderSegment = null;
        $previousHeaderIndex = 0;
        $explicitPattern = '/^\s*(?:(?:candidate|applicant)(?:\s+(?:full\s+)?name)?|full\s+name|name\s+of\s+(?:the\s+)?(?:candidate|applicant)|name)\s*[:\-–]\s*(.*?)\s*$/iu';
        $listSections = [
            'technical skills', 'skills', 'key skills', 'soft skills', 'projects',
            'certifications', 'certification', 'education', 'academic details',
            'professional experience', 'work experience', 'experience',
            'awards', 'achievements', 'interests', 'hobbies',
        ];

        foreach ($lines as $i => $rawLine) {
            $line = trim((string) $rawLine);
            if ($line === '') continue;
            $nonEmptyIndex++;

            if ($this->isSectionHeading($line)) {
                $activeSection = $this->normalizeForMatch($line);
                $previousHeaderSegment = null;
                $previousHeaderIndex = 0;
                continue;
            }
            if ($this->isNonOwnerIdentityLine($line)) {
                $previousHeaderSegment = null;
                $previousHeaderIndex = 0;
                continue;
            }

            if (preg_match($explicitPattern, $line, $match)) {
                $labelValue = $this->formatNameForDisplay((string) ($match[1] ?? ''));
                if ($this->normalizeForMatch($labelValue) === $wanted
                    && $this->isPlausibleName($labelValue, true)) {
                    return true;
                }
            }

            if (preg_match('/^\s*(?:[•●▪◦‣·*]+|[-–—]\s+|\d{1,3}\s*[.)])\s*/u', $line)
                || in_array($activeSection, ['professional experience', 'work experience', 'experience'], true)) {
                $previousHeaderSegment = null;
                $previousHeaderIndex = 0;
                continue;
            }

            $segment = $this->candidateSegmentFromLine($line);
            if ($segment === null) {
                $previousHeaderSegment = null;
                $previousHeaderIndex = 0;
                continue;
            }
            $formattedSegment = $this->formatNameForDisplay($segment);
            $segmentNorm = $this->normalizeForMatch($formattedSegment);
            $nearby = $line . ' ' . (string) ($lines[$i - 1] ?? '') . ' '
                . (string) ($lines[$i + 1] ?? '') . ' ' . (string) ($lines[$i + 2] ?? '');
            $hasIdentityContact = (bool) preg_match(
                '/@|\b(?:phone|mobile|contact|email)\b|\b[6-9]\d{9}\b|\+?\d[\d\s().-]{7,}\d/iu',
                $nearby
            );
            $inListSection = in_array($activeSection, $listSections, true);
            if ($inListSection && !$hasIdentityContact) {
                $previousHeaderSegment = null;
                $previousHeaderIndex = 0;
                continue;
            }
            $identityContext = (!$inListSection && $nonEmptyIndex <= 12) || $hasIdentityContact;

            // Exact line match is strongest. Also permit the model to omit one or
            // more source initials, but only when every omitted source token is a
            // single-letter initial and every model token is found in order.
            $allowSingleToken = $nonEmptyIndex <= 3 && !$inListSection;
            if ($identityContext && $this->isPlausibleName($formattedSegment, $allowSingleToken)
                && ($segmentNorm === $wanted || $this->matchesNameIgnoringSourceInitials($wanted, $segmentNorm))) {
                return true;
            }

            // OCR/PDF layout can wrap one identity name over two adjacent short
            // lines ("Deepika" followed by "A R"). Join only in the opening header,
            // never across a section, list bullet, reference or contact-only row.
            if ($identityContext && $previousHeaderSegment !== null
                && $previousHeaderIndex === $nonEmptyIndex - 1) {
                $joined = $this->formatNameForDisplay($previousHeaderSegment . ' ' . $segment);
                $joinedNorm = $this->normalizeForMatch($joined);
                if ($this->isPlausibleName($joined, false)
                    && ($joinedNorm === $wanted || $this->matchesNameIgnoringSourceInitials($wanted, $joinedNorm))) {
                    return true;
                }
            }

            if ($identityContext && $this->isPlausibleName($formattedSegment, true)) {
                $previousHeaderSegment = $segment;
                $previousHeaderIndex = $nonEmptyIndex;
            } else {
                $previousHeaderSegment = null;
                $previousHeaderIndex = 0;
            }
        }

        // Compact OCR equivalence is accepted only for an uppercase source identity
        // token in the bounded header/contact area.
        return $this->hasCompactNameLineEvidence($candidateName, $sourceText);
    }

    /** Model tokens must be found in order; only omitted source initials are tolerated. */
    private function matchesNameIgnoringSourceInitials(string $modelName, string $sourceName): bool
    {
        $modelTokens = preg_split('/\s+/u', trim($modelName)) ?: [];
        $sourceTokens = preg_split('/\s+/u', trim($sourceName)) ?: [];
        if (!$modelTokens || !$sourceTokens) return false;

        $modelSignificant = 0;
        foreach ($modelTokens as $token) {
            $length = function_exists('mb_strlen') ? mb_strlen($token, 'UTF-8') : strlen($token);
            if ($length > 1) $modelSignificant++;
        }
        if ($modelSignificant === 0) return false;

        $modelIndex = 0;
        foreach ($sourceTokens as $sourceToken) {
            if (($modelTokens[$modelIndex] ?? null) === $sourceToken) {
                $modelIndex++;
                continue;
            }
            $sourceLetters = preg_replace('/[^\p{L}\p{M}]/u', '', $sourceToken) ?? '';
            if ((function_exists('mb_strlen') ? mb_strlen($sourceLetters, 'UTF-8') : strlen($sourceLetters)) === 1) {
                continue;
            }
            return false;
        }

        return $modelIndex === count($modelTokens);
    }

    /** A source line beginning with a family/reference label is not the resume owner. */
    private function isNonOwnerIdentityLine(string $line): bool
    {
        return (bool) preg_match(
            '/^\s*(?:s\s*\/\s*o|d\s*\/\s*o|w\s*\/\s*o|son\s+of|daughter\s+of|wife\s+of|husband\s+of|father.?s?\s+name|mother.?s?\s+name|parent.?s?\s+name|spouse.?s?\s+name|husband.?s?\s+name|wife.?s?\s+name|guardian|reference(?:s)?|referee|emergency\s+contact)\b/iu',
            trim($line)
        );
    }


    private function hasExactNameLineEvidence(string $candidateName, string $sourceText): bool
    {
        $wanted = $this->normalizeForMatch($candidateName);
        if ($wanted === '') return false;
        $lines = preg_split('/\R/u', $sourceText) ?: [];
        foreach (array_slice($lines, 0, 100) as $rawLine) {
            $line = trim((string) $rawLine);
            if ($line === '') continue;

            if (preg_match('/^\s*(?:(?:candidate|applicant)(?:\s+(?:full\s+)?name)?|full\s+name|name\s+of\s+(?:the\s+)?(?:candidate|applicant)|name)\s*[:\-–]\s*(.*?)\s*$/iu', $line, $match)) {
                $line = trim((string) ($match[1] ?? ''));
            } else {
                // Split combined contact rows at common separators before comparing.
                $segments = preg_split('/\s*[|]\s*/u', $line) ?: [$line];
                $line = trim((string) ($segments[0] ?? $line));
                $line = preg_replace('/\s+[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}.*$/iu', '', $line) ?? $line;
                $line = preg_replace('/\s+\+?\d[\d\s().-]{7,}\d\b.*$/u', '', $line) ?? $line;
                $line = trim($line, " \t\n\r\0\x0B,;:|•●▪◦‣·");
            }

            if ($this->normalizeForMatch($line) === $wanted) return true;
        }
        return false;
    }

    private function containsBlockedResumeTerms(string $normalized): bool
    {
        // Name-shaped skills and résumé boilerplate seen in production. Use token
        // boundaries so terms like JavaScript are not rejected merely for containing
        // 'java'. These terms are deliberately conservative to prevent false names.
        $terms = [
            'canva', 'designing', 'design', 'python', 'javascript', 'java', 'html', 'css', 'sql',
            'mysql', 'postgresql', 'excel', 'microsoft office', 'ms office', 'office', 'windows',
            'linux', 'photoshop', 'figma', 'react', 'angular', 'vue', 'node js', 'django',
            'flask', 'machine learning', 'artificial intelligence', 'operating system',
            'software installation', 'communication', 'teamwork', 'quick learner',
            'problem solving', 'problem solving ability', 'organizational growth',
            'organization growth', 'full stack developer', 'software developer',
            'computer science', 'engineering diploma', 'proficient', 'intermediate',
            'certification', 'certifications', 'competition', 'certificate', 'award', 'participation', 'achievement', 'technical skills', 'soft skills',
            'professional summary', 'career objective', 'looking for', 'seeking a',
            'team collaboration', 'collaboration abilities', 'creative thinker',
            'marketing', 'development', 'developer', 'management', 'programming',
            'proficiency', 'installation', 'configuration', 'customer', 'support',
            'analysis', 'analyst', 'operations', 'testing', 'automation', 'software',
            'hardware', 'quality assurance', 'administration', 'logistics', 'accounting',
            'finance', 'sales', 'leadership', 'creative', 'designer', 'manager', 'internship',
            'intern', 'cloud', 'networking', 'cyber security', 'security', 'digital',
            'portal', 'website', 'ecommerce', 'e commerce', 'detector', 'twin', 'game',
            'book shop', 'real estate', 'listing', 'memory game', 'online book shop',
            'project', 'projects', 'graduate', 'diploma', 'engineering', 'computer', 'science',
            'entry level', 'full stack', 'entry-level', 'quick learner', 'problem-solving',
            'quality', 'controller', 'quality controller', 'assistant', 'executive', 'officer', 'technician',
            'engineer', 'analyst', 'accountant', 'supervisor', 'administrator', 'trainee', 'intern', 'consultant',
        ];
        foreach ($terms as $term) {
            if (preg_match('/\b' . preg_quote($term, '/') . '\b/iu', $normalized)) return true;
        }
        return false;
    }

    private function isSectionHeading(string $line): bool
    {
        $normalized = $this->normalizeForMatch($line);
        return in_array($normalized, [
            'about me', 'objective', 'career objective', 'career summary', 'profile', 'professional profile', 'personal profile', 'professional summary',
            'summary', 'technical skills', 'skills', 'education', 'academic details',
            'professional experience', 'work experience', 'experience', 'projects',
            'certifications', 'certification', 'certificates', 'soft skills', 'personal details', 'declaration', 'key competencies', 'languages',
            'awards', 'achievements', 'activities', 'extracurricular activities', 'interests', 'hobbies',
        ], true);
    }

    private function isPlausibleName(string $name, bool $allowSingleToken): bool
    {
        $name = $this->cleanNameCandidate($name);
        if ($name === '' || strlen($name) > 180) return false;
        if (preg_match('/\d/u', $name)) return false;
        if (preg_match('/[@\/:\\\\]|https?\b|www\./iu', $name)) return false;
        if (!preg_match('/^[\p{L}\p{M}][\p{L}\p{M} .\'’\-]{0,178}[\p{L}\p{M}.]$/u', $name)) return false;

        $tokens = preg_split('/\s+/u', trim($name)) ?: [];
        $tokens = array_values(array_filter($tokens, static fn ($token) => $token !== ''));
        if (count($tokens) > 7) return false;
        if (!$allowSingleToken && count(array_filter($tokens, static fn ($token) => preg_match('/\p{L}/u', $token))) < 2) return false;
        if (count($tokens) === 1) {
            if (!$allowSingleToken) return false;
            $singleLetters = preg_replace('/[^\p{L}\p{M}]/u', '', $tokens[0]) ?? '';
            $singleLength = function_exists('mb_strlen') ? mb_strlen($singleLetters, 'UTF-8') : strlen($singleLetters);
            if ($singleLength < 3 || $singleLength > 35) return false;
        }

        $normalized = $this->normalizeForMatch($name);
        $blocked = [
            'resume', 'curriculum vitae', 'profile', 'professional summary', 'career objective',
            'objective', 'contact', 'contact details', 'personal details', 'personal information',
            'education', 'education details', 'academic details', 'academic qualifications',
            'academic qualification', 'skills', 'key skills', 'technical skills', 'work experience',
            'professional experience', 'experience', 'employment history', 'projects', 'references',
            'declaration', 'summary', 'about me', 'common', 'unknown', 'not available', 'hardworking person', 'seeking a challenging role',
            'candidate name', 'full name', 'applicant name', 'name', 'curriculum vitae resume',
        ];
        if (in_array($normalized, $blocked, true)) return false;
        // Resume templates sometimes place a lowercase design/theme label directly
        // under a one-word name (e.g. "Vijayakumar" then "common"). Never join
        // these generic labels into the candidate's personal name.
        foreach ($tokens as $token) {
            $tokenNorm = $this->normalizeForMatch((string) $token);
            if (in_array($tokenNorm, ['common', 'resume', 'curriculum', 'vitae', 'profile', 'cv'], true)) {
                return false;
            }
        }
        foreach (['email', 'phone', 'mobile', 'address', 'linkedin', 'objective', 'experience', 'qualification'] as $keyword) {
            if (preg_match('/\b' . preg_quote($keyword, '/') . '\b/iu', $normalized)) return false;
        }
        // Exclude common objective/summary prose and name-shaped skill items.
        if (preg_match('/\b(?:seeking|looking for|hardworking|motivated|dedicated|professional|aspiring|experienced|result oriented|results driven|team player|career|graduate|to obtain|to work|willing to|passionate|self motivated|energetic|dynamic)\b/iu', $normalized)) {
            return false;
        }
        // A company/employer line can appear beside contact details in a two-column
        // PDF reading order. Reject legal entity suffixes as standalone tokens too
        // (e.g. "Penguin Apparels Pvt.", not only "Pvt Ltd").
        if (preg_match('/\b(?:pvt|private limited|private ltd|ltd|limited|llp|inc|incorporated|corporation|corp|company|co|enterprises|industries|apparels|textiles|technologies|solutions|consultancy|consultants|university|college|institute|hospital|school|services|systems|foundation|trust)\b/iu', $normalized)) {
            return false;
        }
        if ($this->containsBlockedResumeTerms($normalized)) return false;

        // An unlabelled name normally has at least one non-initial token. A line such
        // as 'A R' is too weak, while 'Deepika A R' is valid.
        if (!$allowSingleToken && !array_filter($tokens, static function ($token): bool {
            $letters = preg_replace('/[^\p{L}\p{M}]/u', '', $token) ?? $token;
            return (function_exists('mb_strlen') ? mb_strlen($letters, 'UTF-8') : strlen($letters)) >= 2;
        })) {
            return false;
        }

        return true;
    }

    private function hasSourceEvidence(string $candidateName, string $sourceText, bool $allowSingleToken): bool
    {
        // Remove contact data before evidence matching as well. Otherwise a name-shaped
        // email local-part (e.g. arun.kumar@gmail.com) could falsely validate an AI guess.
        $sourceText = preg_replace('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/iu', ' ', $sourceText) ?? $sourceText;
        $sourceText = preg_replace('~\bhttps?://\S+|\bwww\.\S+~iu', ' ', $sourceText) ?? $sourceText;
        $sourceText = preg_replace('/\b(?:email|e-mail|mobile|phone|contact)\s*[:\-].*$/imu', ' ', $sourceText) ?? $sourceText;
        $sourceText = preg_replace('/\b(?:date\s+of\s+birth|dob|aadhaar|aadhar|pan\s*(?:no|number)|passport|address)\b.*$/imu', ' ', $sourceText) ?? $sourceText;
        // Indian resumes frequently list the candidate's parent/spouse or references
        // immediately under the name. Do not let those lines validate an AI guess.
        $sourceText = preg_replace('/^\s*(?:s\s*\/\s*o|d\s*\/\s*o|w\s*\/\s*o|son\s+of|daughter\s+of|wife\s+of|husband\s+of|father.?s?\s+name|mother.?s?\s+name|guardian|reference(?:s)?)(?:\s*[:\-].*)?.*$/imu', ' ', $sourceText) ?? $sourceText;
        $sourceText = preg_replace('/\b\+?\d[\d\s().-]{7,}\d\b/u', ' ', $sourceText) ?? $sourceText;
        $sourceText = preg_replace('/\b\d{12}\b|\b[A-Z]{5}\d{4}[A-Z]\b/iu', ' ', $sourceText) ?? $sourceText;

        $candidate = $this->normalizeForMatch($candidateName);
        $source = $this->normalizeForMatch($sourceText);
        if ($candidate === '' || $source === '') return false;
        if (str_contains(' ' . $source . ' ', ' ' . $candidate . ' ')) return true;

        $candidateTokens = preg_split('/\s+/u', $candidate) ?: [];
        $sourceTokens = preg_split('/\s+/u', $source) ?: [];
        $matchedSignificant = 0;
        $significant = 0;
        foreach ($candidateTokens as $token) {
            $tokenLetters = preg_replace('/[^\p{L}\p{M}]/u', '', $token) ?? $token;
            if ($tokenLetters === '') continue;
            $length = function_exists('mb_strlen') ? mb_strlen($tokenLetters, 'UTF-8') : strlen($tokenLetters);
            if ($length > 1) {
                $significant++;
                if (in_array($tokenLetters, $sourceTokens, true)) $matchedSignificant++;
            } else {
                // Initials must occur as a first-letter token or be attached to the
                // following name token in OCR output; do not count them as strong evidence.
                if ($length === 1 && !in_array($tokenLetters, $sourceTokens, true)) {
                    $attached = false;
                    foreach ($sourceTokens as $sourceToken) {
                        if (str_starts_with($sourceToken, $tokenLetters) && strlen($sourceToken) > 1) {
                            $attached = true;
                            break;
                        }
                    }
                    if (!$attached) continue;
                }
            }
        }

        if ($significant === 0) return $allowSingleToken && in_array($candidate, $sourceTokens, true);
        return $matchedSignificant === $significant && ($significant >= 2 || $allowSingleToken);
    }

    private function hasExplicitNameLabel(string $header): bool
    {
        return (bool) preg_match('/^\s*(?:(?:candidate|applicant)(?:\s+(?:full\s+)?name)?|full\s+name|name\s+of\s+(?:the\s+)?(?:candidate|applicant)|name)\s*[:\-–]/imu', $header);
    }

    private function getHeader(string $resumeText): string
    {
        // This is a bounded inference excerpt, not just the first two header lines.
        // PDF text operators sometimes reorder blocks, so include headings and nearby
        // identity candidates from a limited beginning portion of the resume.
        $normalized = $this->normalizeResumeTextForNameParsing($resumeText);
        if ($normalized === '') return '';
        $rawLines = preg_split('/\R/u', $normalized) ?: [];
        $allLines = $this->expandLinesForNameParsing($rawLines);
        $excerptLines = [];
        $nonEmpty = 0;
        $charCount = 0;
        foreach ($allLines as $line) {
            $trimmed = trim((string) $line);
            if ($trimmed === '') continue;
            $lineLength = function_exists('mb_strlen') ? mb_strlen($trimmed, 'UTF-8') : strlen($trimmed);
            if ($nonEmpty >= self::MAX_EXTERNAL_HEADER_LINES || $charCount + $lineLength > self::MAX_EXTERNAL_HEADER_CHARS) break;
            $excerptLines[] = $trimmed;
            $nonEmpty++;
            $charCount += $lineLength + 1;
        }
        return trim(implode("\n", $excerptLines));
    }

    /** Normalize common PDF/OCR whitespace artifacts without changing word spelling. */
    private function normalizeResumeTextForNameParsing(string $text): string
    {
        if ($text === '') return '';
        $text = str_replace(["\r\n", "\r", "\0"], ["\n", "\n", ''], $text);
        // NBSP/thin spaces/figure spaces are common in PDF text operators; zero-width
        // controls can make a visually valid name fail a Unicode name regex.
        $text = str_replace(["\xC2\xA0", "\xE2\x80\x80", "\xE2\x80\x81", "\xE2\x80\x82", "\xE2\x80\x83", "\xE2\x80\x89", "\xE2\x80\xAF"], ' ', $text);
        $text = preg_replace('/[\x{200B}-\x{200D}\x{2060}\x{FEFF}\x{00AD}]/u', '', $text) ?? $text;
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', ' ', $text) ?? $text;
        $text = preg_replace('/\p{Zs}+/u', ' ', $text) ?? $text;
        $text = preg_replace('/[\t ]+/u', ' ', $text) ?? $text;
        // Some native PDF parsers return a whole page in one line. Insert boundaries
        // before recognizable resume headings and bullets so the header stays bounded.
        $text = preg_replace('/(?<!\n)\s+(?=(?:ABOUT\s+ME|OBJECTIVE|CAREER\s+OBJECTIVE|PROFILE|PROFESSIONAL\s+SUMMARY|SUMMARY|EDUCATION|ACADEMIC\s+(?:DETAILS|QUALIFICATIONS?)|TECHNICAL\s+SKILLS|SKILLS|PROJECTS|CERTIFICATIONS?|SOFT\s+SKILLS|WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EXPERIENCE|PERSONAL\s+DETAILS|DECLARATION)\b)/iu', "\n", $text) ?? $text;
        $text = preg_replace('/(?<!\n)[ ]*(?=[•●▪◦‣·])/u', "\n", $text) ?? $text;
        $text = preg_replace('/\n[ ]+/u', "\n", $text) ?? $text;
        $text = preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text;
        return trim($text);
    }

    /**
     * Expand flattened PDF text into bounded candidate-sized segments. This is
     * critical for Smalot/host PDF parsers that return an entire page as one line:
     * the old 180-character line guard discarded the name and all useful context.
     *
     * @param list<string> $rawLines
     * @return list<string>
     */
    private function expandLinesForNameParsing(array $rawLines): array
    {
        $expanded = [];
        $headingPattern = '/(?=\b(?:ABOUT\s+ME|OBJECTIVE|CAREER\s+OBJECTIVE|PROFILE|PROFESSIONAL\s+SUMMARY|SUMMARY|EDUCATION|ACADEMIC\s+(?:DETAILS|QUALIFICATIONS?)|TECHNICAL\s+SKILLS|SKILLS|PROJECTS|CERTIFICATIONS?|SOFT\s+SKILLS|WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EXPERIENCE|PERSONAL\s+DETAILS|DECLARATION)\b)/iu';
        $emailPattern = '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/iu';
        $phonePattern = '/\s+(?=\+?\d[\d\s().-]{7,}\d\b)/u';

        foreach ($rawLines as $rawLine) {
            $line = trim((string) $rawLine);
            if ($line === '') {
                $expanded[] = '';
                continue;
            }
            $length = function_exists('mb_strlen') ? mb_strlen($line, 'UTF-8') : strlen($line);
            if ($length <= 180) {
                // Even a short line may have skill text and a candidate name fused
                // before its contact field by a layout-ordering PDF parser.
                $contactCutPositions = [];
                foreach ([$emailPattern, $phonePattern] as $contactPattern) {
                    if (preg_match($contactPattern, $line, $contactMatch, PREG_OFFSET_CAPTURE)) {
                        $contactCutPositions[] = (int) $contactMatch[0][1];
                    }
                }
                foreach ($contactCutPositions as $contactPosition) {
                    if ($contactPosition <= 0) continue;
                    $prefix = trim(substr($line, 0, $contactPosition));
                    $prefix = preg_replace('/\s+\+?\d[\d\s().-]{7,}\d\b.*$/u', '', $prefix) ?? $prefix;
                    $prefix = preg_replace('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}.*$/iu', '', $prefix) ?? $prefix;
                    $prefix = trim($prefix, " \t\r\n,;:|•●▪◦‣·");
                    if ($prefix === '' || preg_match('/[@\d]/u', $prefix)) continue;
                    $prefixTokens = preg_split('/\s+/u', $prefix) ?: [];
                    $prefixTokens = array_values(array_filter($prefixTokens, static fn ($token) => $token !== ''));
                    foreach ([2, 3, 4] as $windowSize) {
                        if (count($prefixTokens) < $windowSize) continue;
                        $suffix = trim(implode(' ', array_slice($prefixTokens, -$windowSize)));
                        if ($suffix !== '' && !in_array($suffix, $expanded, true)) $expanded[] = $suffix;
                    }
                }
                $expanded[] = $line;
                continue;
            }

            // First split section labels, then contact-column separators and bullets.
            $sectionParts = preg_split($headingPattern, $line, -1, PREG_SPLIT_NO_EMPTY) ?: [$line];
            foreach ($sectionParts as $sectionPart) {
                $sectionPart = trim((string) $sectionPart);
                if ($sectionPart === '') continue;
                $chunks = preg_split('/\s*[|]\s*|\s*(?=[•●▪◦‣·])\s*/u', $sectionPart, -1, PREG_SPLIT_NO_EMPTY) ?: [$sectionPart];
                foreach ($chunks as $chunk) {
                    $chunk = trim((string) $chunk);
                    if ($chunk === '') continue;

                    // If a parser flattened layout columns, a skills block may appear
                    // before the name on the same line as the phone/email. Also add a
                    // few bounded suffix windows immediately before contact data; this
                    // can recover the name without promoting the preceding skill text.
                    $contactCutPositions = [];
                    foreach ([$emailPattern, $phonePattern] as $contactPattern) {
                        if (preg_match($contactPattern, $chunk, $contactMatch, PREG_OFFSET_CAPTURE)) {
                            $contactCutPositions[] = (int) $contactMatch[0][1];
                        }
                    }
                    foreach ($contactCutPositions as $contactPosition) {
                        if ($contactPosition <= 0) continue;
                        $prefix = trim(substr($chunk, 0, $contactPosition));
                        $prefix = preg_replace('/\s+\+?\d[\d\s().-]{7,}\d\b.*$/u', '', $prefix) ?? $prefix;
                        $prefix = preg_replace('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}.*$/iu', '', $prefix) ?? $prefix;
                        $prefix = trim($prefix, " \t\r\n,;:|•●▪◦‣·");
                        if ($prefix === '' || preg_match('/[@\d]/u', $prefix)) continue;
                        $prefixTokens = preg_split('/\s+/u', $prefix) ?: [];
                        $prefixTokens = array_values(array_filter($prefixTokens, static fn ($token) => $token !== ''));
                        foreach ([2, 3, 4] as $windowSize) {
                            if (count($prefixTokens) < $windowSize) continue;
                            $suffix = trim(implode(' ', array_slice($prefixTokens, -$windowSize)));
                            $suffixLength = function_exists('mb_strlen') ? mb_strlen($suffix, 'UTF-8') : strlen($suffix);
                            if ($suffix !== '' && $suffixLength <= 100 && !in_array($suffix, $expanded, true)) {
                                $expanded[] = $suffix;
                            }
                        }
                    }

                    $chunkLength = function_exists('mb_strlen') ? mb_strlen($chunk, 'UTF-8') : strlen($chunk);
                    if ($chunkLength <= 180) {
                        $expanded[] = $chunk;
                        continue;
                    }

                    // Reduce a long contact/body fragment at the first recognizable
                    // email, phone, URL, or heading boundary.
                    $cutPositions = [];
                    foreach ([
                        $emailPattern,
                        '/\b(?:https?:\/\/|www\.)/iu',
                        '/\b(?:ABOUT\s+ME|OBJECTIVE|EDUCATION|TECHNICAL\s+SKILLS|SKILLS|PROJECTS|CERTIFICATIONS?|SOFT\s+SKILLS|WORK\s+EXPERIENCE|EXPERIENCE)\b/iu',
                        $phonePattern,
                    ] as $pattern) {
                        if (preg_match($pattern, $chunk, $match, PREG_OFFSET_CAPTURE) && ($match[0][1] ?? 0) > 1) {
                            $cutPositions[] = (int) $match[0][1];
                        }
                    }
                    if ($cutPositions) {
                        $prefix = trim(substr($chunk, 0, min($cutPositions)));
                        if ($prefix !== '') $expanded[] = $prefix;
                    }

                    // Split sentence-like/body text into a bounded number of short
                    // pieces. Phrases remain subject to conservative name filters.
                    $sentences = preg_split('/(?<=[.!?])\s+(?=\p{Lu})/u', $chunk, -1, PREG_SPLIT_NO_EMPTY) ?: [];
                    foreach ($sentences as $sentence) {
                        $sentence = trim((string) $sentence);
                        if ($sentence === '') continue;
                        $sentenceLength = function_exists('mb_strlen') ? mb_strlen($sentence, 'UTF-8') : strlen($sentence);
                        if ($sentenceLength <= 180) {
                            $expanded[] = $sentence;
                        } else {
                            // A long prose segment isn't a name candidate; only keep
                            // its initial bounded span so the scan remains predictable.
                            $expanded[] = function_exists('mb_substr') ? mb_substr($sentence, 0, 180, 'UTF-8') : substr($sentence, 0, 180);
                        }
                    }
                }
            }
            if (count($expanded) >= 300) break;
        }

        return array_slice($expanded, 0, 300);
    }

    /** Complete a model answer only when any omitted source tokens are verified initials. */
    private function completeModelNameFromSourceLine(string $partialName, string $sourceText): ?string
    {
        $partial = $this->normalizeForMatch($partialName);
        if ($partial === '') return null;
        $partialTokens = preg_split('/\s+/u', $partial) ?: [];
        $significantTokens = array_filter($partialTokens, static function (string $token): bool {
            return (function_exists('mb_strlen') ? mb_strlen($token, 'UTF-8') : strlen($token)) > 1;
        });
        if (!$significantTokens) return null;

        $sourceLines = $this->expandLinesForNameParsing(
            preg_split('/\R/u', $this->normalizeResumeTextForNameParsing($sourceText)) ?: []
        );
        $nonEmptyIndex = 0;
        foreach (array_slice($sourceLines, 0, 80) as $line) {
            $line = trim((string) $line);
            if ($line === '') continue;
            $nonEmptyIndex++;
            if ($this->isNonOwnerIdentityLine($line)) continue;
            $segment = $this->candidateSegmentFromLine($line);
            if ($segment === null) continue;
            $formatted = $this->formatNameForDisplay($segment);
            if (!$this->isPlausibleName($formatted, false)) continue;

            $fullNorm = $this->normalizeForMatch($formatted);
            if ($fullNorm === '') continue;
            $fullTokens = preg_split('/\s+/u', $fullNorm) ?: [];
            $modelIndex = 0;
            $onlyInitialsOmitted = true;
            foreach ($fullTokens as $fullToken) {
                if (($partialTokens[$modelIndex] ?? null) === $fullToken) {
                    $modelIndex++;
                    continue;
                }
                $letters = preg_replace('/[^\p{L}\p{M}]/u', '', $fullToken) ?? '';
                $length = function_exists('mb_strlen') ? mb_strlen($letters, 'UTF-8') : strlen($letters);
                if ($length === 1) continue;
                $onlyInitialsOmitted = false;
                break;
            }

            if ($onlyInitialsOmitted && $modelIndex === count($partialTokens)
                && ($nonEmptyIndex <= 16 || $this->hasIdentityContactNearLine($sourceLines, $line))) {
                return $formatted;
            }
        }
        return null;
    }

    private function hasIdentityContactNearLine(array $lines, string $targetLine): bool
    {
        foreach ($lines as $index => $line) {
            if (trim((string) $line) !== trim($targetLine)) continue;
            $nearby = (string) ($lines[$index] ?? '') . ' ' . (string) ($lines[$index - 1] ?? '') . ' '
                . (string) ($lines[$index + 1] ?? '') . ' ' . (string) ($lines[$index + 2] ?? '');
            return (bool) preg_match('/@|\b(?:phone|mobile|contact|email)\b|\b[6-9]\d{9}\b|\+?\d[\d\s().-]{7,}\d/iu', $nearby);
        }
        return false;
    }

    /** Recover an OCR-spaced model response only when its letters exactly equal a source header name. */
    private function recoverExactSourceNameByCompactLetters(string $rawModelName, string $sourceText): ?string
    {
        $modelCompact = preg_replace('/[^\p{L}\p{M}]/u', '', $this->normalizeForMatch($rawModelName)) ?? '';
        if (strlen($modelCompact) < 4) return null;

        $lines = preg_split('/\R/u', $this->normalizeResumeTextForNameParsing($sourceText)) ?: [];
        foreach (array_slice($lines, 0, 48) as $index => $line) {
            $segment = $this->candidateSegmentFromLine((string) $line);
            if ($segment === null || !preg_match('/^\p{Lu}{4,}(?:\s+\p{Lu}(?:\s+\p{Lu})*)?$/u', trim($segment))) continue;
            $formatted = $this->formatNameForDisplay($segment);
            if (!$this->isPlausibleName($formatted, false)) continue;
            $sourceCompact = preg_replace('/[^\p{L}\p{M}]/u', '', $this->normalizeForMatch($formatted)) ?? '';
            if ($sourceCompact !== $modelCompact) continue;
            $nearby = (string) $line . ' ' . (string) ($lines[$index + 1] ?? '') . ' ' . (string) ($lines[$index + 2] ?? '');
            if ($index <= 8 || preg_match('/@|\b(?:phone|mobile|contact|email)\b|\b[6-9]\d{9}\b/iu', $nearby)) {
                return $formatted;
            }
        }
        return null;
    }

    /**
     * OCR occasionally collapses an uppercase multi-token name into one word (e.g.
     * DEEPIKA A R -> DEEPIKAAR). Use a model-proposed split only when its complete
     * letters exactly match that uppercase source token and contact details establish
     * that the token is in the identity header. The result remains review-required.
     */
    private function completeModelNameFromCompactOcrLine(string $partialName, string $sourceText): ?string
    {
        $partial = $this->formatNameForDisplay($partialName);
        $tokens = preg_split('/\s+/u', trim($partial)) ?: [];
        if (count($tokens) < 2) return null;
        $lastToken = end($tokens);
        $lastLetters = preg_replace('/[^\p{L}\p{M}]/u', '', (string) $lastToken) ?? (string) $lastToken;
        $lastLength = function_exists('mb_strlen') ? mb_strlen($lastLetters, 'UTF-8') : strlen($lastLetters);
        if ($lastLength !== 1) return null;

        $partialCompact = preg_replace('/[^\p{L}\p{M}]/u', '', $this->normalizeForMatch($partial)) ?? '';
        if ($partialCompact === '') return null;
        $lines = preg_split('/\R/u', $this->normalizeResumeTextForNameParsing($sourceText)) ?: [];
        foreach (array_slice($lines, 0, 30) as $index => $rawLine) {
            $segment = $this->candidateSegmentFromLine((string) $rawLine);
            if ($segment === null || !preg_match('/^\p{Lu}{6,}$/u', trim($segment))) continue;
            $sourceCompact = preg_replace('/[^\p{L}\p{M}]/u', '', $this->normalizeForMatch($segment)) ?? '';
            if (!str_starts_with($sourceCompact, $partialCompact)) continue;
            $remainder = substr($sourceCompact, strlen($partialCompact));
            if (strlen($remainder) !== 1 || !preg_match('/^[a-z]$/i', $remainder)) continue;

            $context = (string) $rawLine . ' ' . (string) ($lines[$index + 1] ?? '') . ' ' . (string) ($lines[$index + 2] ?? '');
            if (!preg_match('/@|\b[6-9]\d{9}\b|\b(?:phone|mobile|email|contact)\b/iu', $context)) continue;

            $completed = $this->formatNameForDisplay($partial . ' ' . strtoupper($remainder));
            if ($this->isPlausibleName($completed, $this->hasExplicitNameLabel($sourceText))
                && $this->hasCompactNameLineEvidence($completed, $sourceText)) {
                return $completed;
            }
        }
        return null;
    }

    /** Compact letter equivalence is accepted only for a single all-caps OCR token in contact-header context. */
    private function hasCompactNameLineEvidence(string $candidateName, string $sourceText): bool
    {
        $wanted = preg_replace('/[^\p{L}\p{M}]/u', '', $this->normalizeForMatch($candidateName)) ?? '';
        if ($wanted === '') return false;
        $lines = preg_split('/\R/u', $this->normalizeResumeTextForNameParsing($sourceText)) ?: [];
        foreach (array_slice($lines, 0, 30) as $index => $rawLine) {
            $segment = $this->candidateSegmentFromLine((string) $rawLine);
            if ($segment === null || !preg_match('/^\p{Lu}{6,}$/u', trim($segment))) continue;
            $sourceCompact = preg_replace('/[^\p{L}\p{M}]/u', '', $this->normalizeForMatch($segment)) ?? '';
            if ($sourceCompact !== $wanted) continue;
            $context = (string) $rawLine . ' ' . (string) ($lines[$index + 1] ?? '') . ' ' . (string) ($lines[$index + 2] ?? '');
            if (preg_match('/@|\b[6-9]\d{9}\b|\b(?:phone|mobile|email|contact)\b/iu', $context)) return true;
        }
        return false;
    }

    private function redactHeaderForExternalInference(string $header): string
    {
        $lines = preg_split('/\R/u', $header) ?: [];
        $safeLines = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;
            if (preg_match('/\b(?:date\s+of\s+birth|dob|aadhaar|aadhar|pan\s*(?:no|number)|passport|(?:permanent|current|residential|present)?\s*address)\b/iu', $line)
                || preg_match('/^\s*(?:s\s*\/\s*o|d\s*\/\s*o|w\s*\/\s*o|son\s+of|daughter\s+of|wife\s+of|husband\s+of|father.?s?\s+name|mother.?s?\s+name|guardian|reference(?:s)?)(?:\s*[:\-]|\b)/iu', $line)) {
                continue;
            }
            $line = preg_replace('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/iu', '[EMAIL REDACTED]', $line) ?? $line;
            $line = preg_replace('~\bhttps?://\S+|\bwww\.\S+~iu', '[URL REDACTED]', $line) ?? $line;
            $line = preg_replace('/\b[6-9]\d{9}\b/u', '[PHONE REDACTED]', $line) ?? $line;
            $line = preg_replace('/\b\d{12}\b/u', '[ID REDACTED]', $line) ?? $line;
            $line = preg_replace('/\b[A-Z]{5}\d{4}[A-Z]\b/iu', '[ID REDACTED]', $line) ?? $line;
            $line = preg_replace('/\b\+?\d[\d\s().-]{7,}\d\b/u', '[PHONE REDACTED]', $line) ?? $line;
            $line = preg_replace('/\b(?:email|e-mail|mobile|phone|contact)\s*[:\-].*$/iu', '', $line) ?? $line;
            if (trim($line) !== '') $safeLines[] = $line;
        }

        $redacted = trim(implode("\n", array_slice($safeLines, 0, self::MAX_EXTERNAL_HEADER_LINES)));
        return function_exists('mb_substr')
            ? mb_substr($redacted, 0, self::MAX_EXTERNAL_HEADER_CHARS, 'UTF-8')
            : substr($redacted, 0, self::MAX_EXTERNAL_HEADER_CHARS);
    }

    private function cleanNameCandidate(string $value): string
    {
        $name = trim($value);
        if ($name === '') return '';
        // Some chat models unexpectedly insert literal <> between generated pieces.
        // Remove those separators, then rely on exact source-line evidence; never
        // accept a repaired but incomplete name such as 'Deepika A' from 'Deepika A R'.
        $name = preg_replace('/<>/u', '', $name) ?? $name;
        $name = preg_replace('/^```(?:json)?\s*|\s*```$/iu', '', $name) ?? $name;
        $name = preg_replace('/^\s*(?:(?:candidate|applicant|full)\s+)?name\s*[:\-–]\s*/iu', '', $name) ?? $name;
        $name = preg_replace('/^(?:mr\.?|mrs\.?|ms\.?|miss\.?|dr\.?|prof\.?|shri|sri|smt\.?|kumari|thiru|selvi)\s+/iu', '', $name) ?? $name;
        $name = preg_replace('/\s+(?:resume|curriculum vitae|profile)\s*$/iu', '', $name) ?? $name;
        $name = preg_replace('/\s+/u', ' ', $name) ?? $name;
        $name = trim($name, " \t\n\r\0\x0B,;:|_");
        return trim($name);
    }

    private function normalizeForMatch(string $value): string
    {
        $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
        $value = preg_replace('/[^\p{L}\p{M}]+/u', ' ', $value) ?? $value;
        return trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
    }

    /** @return array{candidate_name:null,source:string,model:null,review_required:bool,parser_version:string} */
    private function notFound(bool $aiAttempted = false): array
    {
        return [
            'candidate_name' => null,
            'source' => 'not_found',
            'model' => null,
            'review_required' => true,
            'parser_version' => self::VERSION,
            'ai_attempted' => $aiAttempted,
            'ai_result_status' => $this->lastAiResultStatus,
        ];
    }
}
