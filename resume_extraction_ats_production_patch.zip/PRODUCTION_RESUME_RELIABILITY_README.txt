CANDIDATE RESUME EXTRACTION + ATS BACKFILL — PRODUCTION PATCH
Generated: 2026-11-06
Purpose: Reliability fix for the existing Candidate Management / ATS workflow.

SCOPE
-----
This is a focused overlay. It changes only the Candidate Management controller,
resume extraction/name/email/experience services, the Candidate Management ATS UI
partials, and targeted regression tests. No other ERP module, route group, menu,
payroll, HR, or applicant workflow is intentionally changed.

WHAT THIS PATCH FIXES
---------------------
1. Candidate name selection is local-first. When the opening resume identity block
   contains a clear personal name, the parser returns it without calling Hugging Face.
   A single bounded model fallback remains for genuinely ambiguous cases. A model
   answer must still match source evidence; employer names and job titles are rejected.
2. Layout-preserving PDF text is retained through normalization. Wide two-column
   separators are no longer collapsed before candidate field parsers see them.
3. Wrapped email addresses are reconstructed using only the required continuation
   token. Text from the neighbouring column (for example an employer name) is not
   appended to the email.
4. Employment headings printed in the far-right column beside contact details are
   separated from the contact line, allowing employment date ranges to be counted.
5. The extraction cache is invalidated when any field parser version changes, not only
   when the candidate-name parser changes.
6. ATS eligibility no longer excludes a candidate just because egc_applicant.resume_text
   is NULL, empty, or whitespace-only. A saved resume file is enough to enter the
   recovery workflow.
7. Before ATS matching, the server attempts to recover missing text from:
      a. public/job_applications/resume_files (safe basename-only resolution)
      b. an active verified Wasabi applicant-resume object
      c. the existing GoogleDriveService::downloadFile() API
   Extracted text is written to egc_applicant.resume_text before role matching.
8. If a resume cannot be recovered, only that candidate is marked failed; the batch
   continues and reports the candidate for review. No empty ATS analysis is written.
9. The optional egc_applicant.recruitment_resume_sha256 column is guarded. Its absence
   does not block candidate creation or resume_text backfill.
10. Bulk ATS requests are limited to one candidate per HTTP request. The existing
    browser flow sends sequential requests; this patch does not add a background queue.

REFERENCE RESUME REPLAY
-----------------------
The attached EGCJA-4310-26.pdf was replayed using Poppler's layout-preserving text
output and the same resume normalization and field parsers. The local result was:

  candidate_name:   Vijayakumar
  name_source:      local_parser
  ai_attempted:     false
  candidate_mobile: 8778106512
  candidate_email:  vijayvijigerne@gmail.com
  experience_type:  Experience
  date_ranges:      2
  experience_months:70 (May 2024–Present and Feb 2021–Apr 2024, as of Nov 2026)

The PDF's visible header contains “Vijayakumar” with “common” as a lower-case
subtitle/template word; “Penguin Apperals Pvt., Limited” appears in the employment
history, not as the candidate name. The parser now uses the header name and does not
make a Hugging Face request for this example.

IMPORTANT: the experience period marked “Present” is recalculated through the current
server date. Recruiters should review the resulting duration. The parser does not
invent a duration when it cannot establish reliable employment dates.

FORMAT COVERAGE AND LIMITS
--------------------------
The extractor has best-effort paths for PDF, DOC/DOCX/DOCM, ODT, RTF, TXT/TEXT,
Markdown, HTML/HTM, XML, JSON, CSV, PPT/PPTX, XLS/XLSX, ODS/ODP, EPUB, Pages/WPS
containers where the installed conversion tools support them, and common raster
image resumes (JPG/JPEG/JFIF, PNG, WEBP, BMP, GIF, TIF/TIFF, HEIC/HEIF where the
server libraries support the codec).

No parser can guarantee extraction from every proprietary, password-protected,
corrupt, encrypted, unsupported, or extremely low-quality file. Scanned PDFs are
OCRed for a bounded number of initial pages. Word/ODT/PowerPoint embedded images are
OCRed as a fallback when their text layer is weak. Manual review remains necessary.

SERVER REQUIREMENTS
-------------------
Recommended PHP extensions:
  fileinfo, zip, dom, xml, mbstring

The app also uses the project's existing dependencies, including Symfony Process,
Smalot PDF Parser, PhpOffice PHPWord, Laravel HTTP client, and AWS SDK for Wasabi.
The uploaded archive does not include composer.json/vendor, so this patch does not
change Composer dependencies.

Recommended Linux system packages:
  poppler-utils       (pdftotext and pdftoppm for PDFs)
  tesseract-ocr       (OCR engine)
  tesseract-ocr-eng   (English language data)
  antiword            (legacy .doc fallback)
  libreoffice         (legacy Office/OpenDocument conversion fallback)

For Tamil + English scanned resumes, install Tesseract Tamil language data and set:
  RECRUITMENT_RESUME_AI_OCR_LANGUAGES=eng+tam
If only English data is installed, use eng. OCR quality depends on language data and
scan quality. Imagick/Ghostscript are optional alternate PDF renderers.

Ensure PHP-FPM, the web server, and the request proxy allow enough time for bounded
OCR. Suggested starting values for this synchronous workflow:
  max_execution_time = 240
  request_terminate_timeout = 240s (PHP-FPM, where applicable)
  fastcgi_read_timeout / proxy_read_timeout = 240s
  memory_limit = 512M
  upload_max_filesize = 20M
  post_max_size = 22M

Make sure storage/app/private is writable by the PHP user and is not web-accessible.
The ATS Drive/Wasabi recovery paths create short-lived temporary files and remove them
after processing. The local resume directory must remain readable by PHP.

CONFIGURATION
-------------
The existing config/recruitment_resume_ai.php is used. These values are recommended:

  RECRUITMENT_RESUME_AI_OCR_ENABLED=true
  RECRUITMENT_RESUME_AI_OCR_PDF_MAX_PAGES=3
  RECRUITMENT_RESUME_AI_PDFTOTEXT_BINARY=pdftotext
  RECRUITMENT_RESUME_AI_PDFTOPPM_BINARY=pdftoppm
  RECRUITMENT_RESUME_AI_TESSERACT_BINARY=tesseract
  RECRUITMENT_RESUME_AI_OCR_LANGUAGES=eng
  RECRUITMENT_RESUME_AI_LIBREOFFICE_BINARY=libreoffice
  RECRUITMENT_RESUME_AI_ANTIWORD_BINARY=antiword
  RECRUITMENT_RESUME_AI_HF_ENABLED=true
  RECRUITMENT_RESUME_AI_HF_MAX_MODEL_ATTEMPTS=1
  RECRUITMENT_RESUME_AI_HF_TIMEOUT_SECONDS=8
  RECRUITMENT_RESUME_AI_HF_CONNECT_TIMEOUT_SECONDS=2

Keep HF_TOKEN in the server environment or continue using the existing integration
credential. The exact reference resume is handled locally and should show
candidate_name_ai_attempted=false. For an ambiguous name only, one bounded model
request can be made; this is intentional and configurable.

ATS NOTE
--------
The active CandidateJobRoleMatchingService is an explainable, local/rule-based role
matcher, not a generative LLM resume-quality evaluator. Bulk ATS matching does not
send the resume text to Hugging Face. It recovers text, compares it with active role
profiles, then saves the match report/evidence in the existing ATS tables. The UI
labels it as evidence-backed role matching. Historical ai_response data is not
rewritten by this patch.

The ATS SQL from the previous Candidate Management patch is included in this ZIP.
It creates missing ATS/extraction tables with CREATE TABLE IF NOT EXISTS and does not
alter or delete existing applicant rows. Run it only if these tables are not already
installed:
  database/sql/candidate_ats_analysis.sql

Wasabi recovery depends on the existing common-storage schema and configuration:
  egc_applicant_file_storage
  egc_applicant_storage_audit
  egc_storage_feature_settings
  egc_storage_objects
  egc_storage_audit
The supplied ZIP does not contain the separate common-storage SQL file. Do not invent
or replace that schema: verify the same common-storage SQL from your existing Wasabi
feature deployment has been applied. The existing Google Drive integration must also
remain in place.

DEPLOYMENT
----------
1. Back up the live CandidateManagement.php, the four resume services, the two Blade
   files, and the database. Test the overlay in staging first.
2. Copy the files from this ZIP over the matching application paths. Do not replace
   routes/web.php, GoogleDriveService.php, applicant models, Wasabi controllers, or
   unrelated menus with files from another archive.
3. Confirm egc_applicant.resume_text exists and is writable through ApplicantModel.
   recruitment_resume_sha256 is optional; this patch checks for it before writing.
4. If the ATS tables do not exist, run database/sql/candidate_ats_analysis.sql.
5. If Wasabi backfill is expected, verify the common-storage tables, AWS SDK, feature
   registry, bucket, endpoint and credentials. Keep the local fallback until both
   cloud destinations have actually been verified.
6. Verify Poppler/Tesseract/Office tools are installed and executable by the PHP-FPM
   user, not only by an interactive SSH user.
7. Clear Laravel compiled/config/view caches using the project's normal deployment
   process. At minimum, after changing config/environment values run:
     php artisan config:clear
     php artisan route:clear
     php artisan view:clear
   Rebuild config cache if the deployment normally uses it.
8. Run PHP syntax checks on the changed PHP files and confirm the existing candidate
   routes still resolve. This overlay does not modify route definitions.
9. In staging, upload the attached reference resume. Check the candidate name, phone,
   email and experience suggestions above, then review and save the candidate.
10. Test ATS backfill with separate staging candidates where resume_text is NULL or
    whitespace-only and the only binary source is (a) local, (b) Wasabi, or (c) Drive.
    Confirm resume_text is populated before a role-match report is written.
11. Test missing, unreadable, encrypted and corrupt files. Those candidates should be
    reported as needing resume review; other candidates in the bulk run must continue.
12. Test a duplicate mobile, manual corrections, and a resume with a non-standard
    layout before releasing to production.

VALIDATION LIMITS
-----------------
Static PHP syntax checks passed for the modified PHP/controller/test files. The ATS
modal script passed Node syntax checking after substituting the three Blade @json
expressions. The exact sample PDF was read using Poppler, then replayed through the
same normalizer and local field parsers; the reference values above were returned.

The uploaded project archive has no vendor directory/PHPUnit executable and no live
production database, Wasabi credentials, Google Drive credentials, or PHP-FPM runtime.
Therefore PHPUnit, complete Laravel request tests, database backfill tests, cloud
integrations and browser/UI end-to-end tests could not be run here. Treat this as a
reviewed code overlay that must pass the staging checklist before production release.

ROLLBACK
--------
Restore the backed-up changed controller, service and Blade files. No existing
applicant rows are deleted or modified by deployment itself. Backfilled resume_text
is retained as source text; rollback does not require deleting it or dropping ATS
reports/tables. Do not drop tables while ATS history is still needed.
