<?php

namespace Tests\Unit;

use App\Services\Recruitment\ResumeAutomation\CandidateEmailService;
use Tests\TestCase;

class CandidateEmailServiceTest extends TestCase
{
    public function test_extracts_candidate_email_from_resume_header_and_normalizes_case(): void
    {
        $service = new CandidateEmailService();
        $result = $service->extractFromResume("DEEPIKA A R\n8300350913 | DeepiJP2004@GMAIL.COM | Madurai, Tamil Nadu\nABOUT ME\nSeeking an entry-level role.");

        $this->assertSame('deepijp2004@gmail.com', $result['candidate_email']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertSame(CandidateEmailService::VERSION, $result['parser_version']);
    }

    public function test_recovers_email_with_spaces_around_at_and_domain_dots(): void
    {
        $service = new CandidateEmailService();
        $result = $service->extractFromResume("Candidate Name\nEmail: deepika @ gmail . com\nSkills\nPHP, Laravel");

        $this->assertSame('deepika@gmail.com', $result['candidate_email']);
    }

    public function test_recovers_email_wrapped_across_pdf_lines(): void
    {
        $service = new CandidateEmailService();
        $result = $service->extractFromResume("Candidate Name\nEmail: deepika@gmail.\ncom\nABOUT ME\nSeeking a role");

        $this->assertSame('deepika@gmail.com', $result['candidate_email']);
    }

    public function test_prefers_candidate_header_email_over_reference_email(): void
    {
        $service = new CandidateEmailService();
        $text = "CANDIDATE NAME\nEmail: candidate.person@gmail.com\nMobile: 9876543210\n\nREFERENCES\nContact: recruiter@company.example.org";
        $result = $service->extractFromResume($text);

        $this->assertSame('candidate.person@gmail.com', $result['candidate_email']);
    }

    public function test_skips_placeholder_emails_and_finds_a_real_candidate_email(): void
    {
        $service = new CandidateEmailService();
        $result = $service->extractFromResume("Email: candidate@example.com\nMail: yourname@gmail.com\nContact: deepika.r@outlook.com");

        $this->assertSame('deepika.r@outlook.com', $result['candidate_email']);
    }

    public function test_returns_not_found_when_resume_has_no_reliable_email(): void
    {
        $service = new CandidateEmailService();
        $result = $service->extractFromResume("DEEPIKA A R\nTechnical Skills\nPHP\nLaravel\nReferences available on request");

        $this->assertNull($result['candidate_email']);
        $this->assertSame('not_found', $result['source']);
    }

    public function test_does_not_select_only_a_generic_company_support_email(): void
    {
        $service = new CandidateEmailService();
        $result = $service->extractFromResume("Company contact: support@company.org\nRecruitment: careers@company.in");

        $this->assertNull($result['candidate_email']);
        $this->assertSame('not_found', $result['source']);
    }

    public function test_joins_a_pdf_split_final_email_domain_suffix(): void
    {
        $service = new CandidateEmailService();
        $result = $service->extractFromResume(
            "Vijayakumar Common\nContact Details\n8778106512\nvijayvijigerne@gmail.c\nom"
        );

        $this->assertSame('vijayvijigerne@gmail.com', $result['candidate_email']);
    }
    public function test_recovers_wrapped_email_when_next_pdf_line_contains_another_column(): void
    {
        $service = new CandidateEmailService();
        $text = "Vijayakumar\ncommon\nContact Details\n8778106512\nvijayvijigerne@gmail.c          Experience\nom                         Penguin Apperals Pvt., Limited\nQuality Controller";
        $result = $service->extractFromResume($text);

        $this->assertSame('vijayvijigerne@gmail.com', $result['candidate_email']);
        $this->assertSame('local_parser', $result['source']);
    }

}
