<?php

namespace Tests\Unit;

use App\Services\Recruitment\ResumeAutomation\ResumeTextExtractionService;
use Tests\TestCase;

class ResumeTextExtractionServiceTest extends TestCase
{
    public function test_pdf_signature_overrides_a_misleading_extension(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'resume_sig_');
        try {
            file_put_contents($path, "%PDF-1.7\n% signature-only fixture");
            $this->assertSame('pdf', ResumeTextExtractionService::detectExtension($path, 'doc'));
        } finally {
            if (is_file($path)) unlink($path);
        }
    }

    public function test_plain_text_resume_with_a_generic_extension_is_detected(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'resume_text_');
        try {
            file_put_contents($path, "Vijayakumar\nEmail: vijay@example.com\nExperience\nQuality Controller");
            $this->assertSame('txt', ResumeTextExtractionService::detectExtension($path, 'data'));
        } finally {
            if (is_file($path)) unlink($path);
        }
    }

    public function test_text_resume_is_detected_even_when_it_has_a_word_extension(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'resume_text_docx_');
        try {
            file_put_contents($path, "Vijayakumar\nEmail: vijay@example.com\nExperience\nQuality Controller");
            $this->assertSame('txt', ResumeTextExtractionService::detectExtension($path, 'docx'));
        } finally {
            if (is_file($path)) unlink($path);
        }
    }

    public function test_rtf_signature_is_detected_even_when_extension_is_missing(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'resume_rtf_');
        try {
            file_put_contents($path, "{\\rtf1\\ansi\\deff0 Candidate Resume}");
            $this->assertSame('rtf', ResumeTextExtractionService::detectExtension($path, 'data'));
        } finally {
            if (is_file($path)) unlink($path);
        }
    }

    public function test_unknown_binary_file_is_not_treated_as_a_resume(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'resume_bin_');
        try {
            file_put_contents($path, "\x00\x01\x02\x03\xff\xfe\x10");
            $this->assertNull(ResumeTextExtractionService::detectExtension($path, 'unknown'));
        } finally {
            if (is_file($path)) unlink($path);
        }
    }
    public function test_text_extraction_preserves_two_column_boundaries_for_downstream_parsers(): void
    {
        $path = tempnam(sys_get_temp_dir(), 'resume_layout_');
        try {
            file_put_contents(
                $path,
                "Vijayakumar\nvijayvijigerne@gmail.c          Experience\nom                         Penguin Apparels Pvt. Limited"
            );

            $result = (new ResumeTextExtractionService())->extractPath($path, 'txt');

            $this->assertStringContainsString('gmail.c  Experience', $result['text']);
            $this->assertStringContainsString("\nom  Penguin", $result['text']);
        } finally {
            if (is_file($path)) unlink($path);
        }
    }

}
