<?php

namespace Tests\Unit;

use App\Services\Recruitment\ResumeAutomation\CandidateExperienceService;
use DateTimeImmutable;
use PHPUnit\Framework\TestCase;

class CandidateExperienceServiceTest extends TestCase
{
    private function service(): CandidateExperienceService
    {
        return new CandidateExperienceService();
    }

    private function asOf(): DateTimeImmutable
    {
        return new DateTimeImmutable('2026-10-21 12:00:00');
    }

    public function test_month_year_employment_period_is_counted(): void
    {
        $result = $this->service()->suggest(
            "PROFESSIONAL EXPERIENCE\nSoftware Engineer at ABC Pvt Ltd\nJan 2020 - Dec 2022\nDeveloped APIs and maintained applications",
            $this->asOf()
        );
        $this->assertSame(2, $result['candidate_experience_type']);
        $this->assertSame(36, $result['candidate_experience_months']);
        $this->assertSame(3.0, $result['candidate_experience_years']);
        $this->assertSame('employment_date_ranges', $result['candidate_experience_source']);
    }

    public function test_year_only_range_does_not_count_both_endpoint_years_inclusively(): void
    {
        $result = $this->service()->suggest("WORK EXPERIENCE\nAccountant\n2020 - 2022\nPrepared accounts and GST returns", $this->asOf());
        $this->assertSame(24, $result['candidate_experience_months']);
        $this->assertSame('2', $result['candidate_exper_count']);
    }

    public function test_current_employment_is_counted_only_through_as_of_month(): void
    {
        $result = $this->service()->suggest("WORK EXPERIENCE\nSoftware Engineer\nJan 2023 - Present\nDeveloped APIs", $this->asOf());
        $this->assertSame(46, $result['candidate_experience_months']);
        $this->assertSame(3.8, $result['candidate_experience_years']);
    }

    public function test_since_date_is_treated_as_ongoing_when_employment_context_exists(): void
    {
        $result = $this->service()->suggest("Software Engineer at ABC Pvt Ltd since Jan 2024\nDeveloped APIs and supported production", $this->asOf());
        $this->assertSame(34, $result['candidate_experience_months']);
        $this->assertSame(2.8, $result['candidate_experience_years']);
    }

    public function test_overlapping_jobs_are_not_double_counted(): void
    {
        $resume = "WORK EXPERIENCE\nSoftware Engineer | Jan 2020 - Dec 2021\nBackend Developer | Jan 2021 - Dec 2022\nDeveloped and maintained APIs";
        $result = $this->service()->suggest($resume, $this->asOf());
        $this->assertSame(36, $result['candidate_experience_months']);
        $this->assertSame(2, $result['candidate_experience_date_range_count']);
    }

    public function test_non_overlapping_employment_periods_are_added_without_counting_gaps(): void
    {
        $resume = "WORK EXPERIENCE\nAccountant | 2018 - 2019\nAccounts Executive | 2021 - 2022\nPrepared accounts and bank reconciliation";
        $result = $this->service()->suggest($resume, $this->asOf());
        $this->assertSame(24, $result['candidate_experience_months']);
    }

    public function test_internship_only_resume_is_fresher_and_internship_dates_are_not_professional_years(): void
    {
        $resume = "EDUCATION\nBCA 2021\nINTERNSHIP\nSoftware Developer Intern\nJan 2024 - Dec 2024\nBuilt a practice project";
        $result = $this->service()->suggest($resume, $this->asOf());
        $this->assertSame(1, $result['candidate_experience_type']);
        $this->assertSame('Fresher', $result['candidate_experience_type_name']);
        $this->assertSame('0', $result['candidate_exper_count']);
        $this->assertSame(0, $result['candidate_experience_months']);
    }

    public function test_education_dates_are_not_counted_as_work_experience(): void
    {
        $result = $this->service()->suggest("EDUCATION\nBCA | 2018 - 2021\nBachelor of Computer Applications\nSKILLS\nPHP, MySQL", $this->asOf());
        $this->assertSame(1, $result['candidate_experience_type']);
        $this->assertSame(0, $result['candidate_experience_months']);
    }

    public function test_education_only_profile_is_fresher(): void
    {
        $result = $this->service()->suggest("EDUCATION\nBachelor of Computer Applications (BCA), 2021\nSKILLS\nPHP, MySQL, Excel", $this->asOf());
        $this->assertSame(1, $result['candidate_experience_type']);
        $this->assertSame('no_professional_employment_found', $result['candidate_experience_source']);
    }

    public function test_explicit_years_of_experience_is_supported(): void
    {
        $result = $this->service()->suggest("PROFESSIONAL SUMMARY\nSoftware developer with 4+ years of experience in PHP and Laravel", $this->asOf());
        $this->assertSame(2, $result['candidate_experience_type']);
        $this->assertSame(48, $result['candidate_experience_months']);
        $this->assertSame('4', $result['candidate_exper_count']);
    }

    public function test_years_and_months_and_month_only_experience_are_supported(): void
    {
        $result = $this->service()->suggest("SUMMARY\nAccountant with 4 years 6 months of experience in accounts", $this->asOf());
        $this->assertSame(54, $result['candidate_experience_months']);
        $this->assertSame(4.5, $result['candidate_experience_years']);

        $short = $this->service()->suggest("SUMMARY\nDeveloper with 6 months of experience in PHP", $this->asOf());
        $this->assertSame(6, $short['candidate_experience_months']);
        $this->assertSame(0.5, $short['candidate_experience_years']);
    }

    public function test_employment_history_without_dates_gets_type_but_no_invented_year_count(): void
    {
        $result = $this->service()->suggest("WORK EXPERIENCE\nAccountant at ABC Pvt Ltd\nPrepared bank reconciliation and GST filings", $this->asOf());
        $this->assertSame(2, $result['candidate_experience_type']);
        $this->assertNull($result['candidate_experience_years']);
        $this->assertNull($result['candidate_exper_count']);
    }

    public function test_internship_does_not_override_real_work_history(): void
    {
        $resume = "WORK EXPERIENCE\nSoftware Engineer\nABC Tech\nJan 2020 - Dec 2022\nMaintained APIs\nINTERNSHIP\nDeveloper Intern\nJan 2019 - Dec 2019";
        $result = $this->service()->suggest($resume, $this->asOf());
        $this->assertSame(36, $result['candidate_experience_months']);
        $this->assertSame(3.0, $result['candidate_experience_years']);
    }

    public function test_indian_day_month_dates_and_month_year_numeric_dates_are_supported(): void
    {
        $dayMonth = $this->service()->suggest("WORK EXPERIENCE\nSoftware Engineer at Tech Pvt Ltd\n01/06/2020 - 31/05/2022\nCreated APIs", $this->asOf());
        $this->assertSame(24, $dayMonth['candidate_experience_months']);

        $monthYear = $this->service()->suggest("WORK EXPERIENCE\nEngineer at Tech Pvt Ltd\n06/2020 - 05/2022\nCreated APIs", $this->asOf());
        $this->assertSame(24, $monthYear['candidate_experience_months']);
    }

    public function test_future_end_date_is_clipped_to_the_current_month(): void
    {
        $result = $this->service()->suggest("WORK EXPERIENCE\nSoftware Engineer at ABC Pvt Ltd\n2024 - 2030\nDeveloped APIs", $this->asOf());
        $this->assertSame(34, $result['candidate_experience_months']);
        $this->assertSame(2.8, $result['candidate_experience_years']);
    }

    public function test_job_requirement_text_does_not_create_candidate_experience(): void
    {
        $result = $this->service()->suggest("Job Description\nRequired experience: 5 years\nNo candidate employment information", $this->asOf());
        $this->assertNull($result['candidate_experience_type']);
        $this->assertSame('insufficient_evidence', $result['candidate_experience_source']);
    }

    public function test_empty_or_low_evidence_resume_returns_no_guess(): void
    {
        $result = $this->service()->suggest("Contact\nabc@example.com", $this->asOf());
        $this->assertNull($result['candidate_experience_type']);
        $this->assertNull($result['candidate_exper_count']);
    }
    public function test_internship_duration_is_not_counted_as_professional_experience(): void
    {
        $resume = "EDUCATION\nBCA 2022\nWORK EXPERIENCE\nSoftware Developer Intern\n6 months of experience building software projects";
        $result = $this->service()->suggest($resume, $this->asOf());
        $this->assertSame(1, $result['candidate_experience_type']);
        $this->assertSame(0, $result['candidate_experience_months']);
    }

    public function test_undated_regular_job_is_not_suppressed_by_an_adjacent_internship(): void
    {
        $resume = "WORK EXPERIENCE\nSoftware Developer Intern\nBuilt a practice application\nSoftware Engineer\nABC Technologies\nMaintained production APIs\nINTERNSHIP\nPHP Intern\nCreated training examples";
        $result = $this->service()->suggest($resume, $this->asOf());
        $this->assertSame(2, $result['candidate_experience_type']);
        $this->assertNull($result['candidate_experience_years']);
        $this->assertNull($result['candidate_exper_count']);
    }

    public function test_inline_professional_experience_heading_preserves_explicit_year_total(): void
    {
        $result = $this->service()->suggest("PROFESSIONAL EXPERIENCE: 5 years", $this->asOf());
        $this->assertSame(2, $result['candidate_experience_type']);
        $this->assertSame(60, $result['candidate_experience_months']);
        $this->assertSame('5', $result['candidate_exper_count']);
    }

    public function test_job_post_minimum_year_requirement_is_not_mistaken_for_candidate_experience(): void
    {
        $result = $this->service()->suggest("JOB DESCRIPTION\nMinimum 5 years of experience required\nCandidates must have 5 years experience", $this->asOf());
        $this->assertNull($result['candidate_experience_type']);
        $this->assertNull($result['candidate_experience_months']);
    }

    public function test_internship_only_entry_inside_work_experience_heading_remains_fresher(): void
    {
        $resume = "WORK EXPERIENCE\nSoftware Developer Intern\nDeveloped a software application during internship";
        $result = $this->service()->suggest($resume, $this->asOf());
        $this->assertSame(1, $result['candidate_experience_type']);
        $this->assertSame(0, $result['candidate_experience_months']);
    }

    public function test_experience_heading_at_two_column_contact_row_is_separated_and_dates_are_counted(): void
    {
        $resume = implode("\n", [
            'Vijayakumar',
            'vijayvijigerne@gmail.com          Experience',
            'Penguin Apparels Pvt. Limited       May 2024 - Present',
            'Quality Controller',
            'Worked in garment production and quality control.',
            'PKN Higher Secondary School         Feb 2021 - Apr 2024',
            'Computer Instructor',
            'Managed computer lab and taught programming languages.',
        ]);

        $result = $this->service()->suggest($resume, $this->asOf());

        $this->assertSame(2, $result['candidate_experience_type']);
        $this->assertSame('employment_date_ranges', $result['candidate_experience_source']);
        $this->assertSame(2, $result['candidate_experience_date_range_count']);
        $this->assertGreaterThan(0, $result['candidate_experience_months']);
    }

}
