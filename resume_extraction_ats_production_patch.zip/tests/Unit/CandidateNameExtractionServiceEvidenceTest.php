<?php

namespace Tests\Unit;

use App\Services\Recruitment\ResumeAutomation\CandidateNameExtractionService;
use App\Services\Recruitment\ResumeAutomation\HuggingFaceInferenceService;
use Generator;
use Tests\TestCase;

class CandidateNameExtractionServiceEvidenceTest extends TestCase
{
    public function test_local_header_name_is_used_without_spending_an_inference_request(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');

        $service = new CandidateNameExtractionService($client);
        $result = $service->extract("ADITI RAO\nMobile: 9876543210\nEmail: aditi.rao@example.com\nEDUCATION\nB.Com");

        $this->assertSame('Aditi Rao', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertFalse($result['ai_attempted']);
        $this->assertSame('not_needed_local_verified', $result['ai_result_status']);
    }

    public function test_ai_name_with_an_omitted_middle_initial_is_recovered_from_the_source_line(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');

        $service = new CandidateNameExtractionService($client);
        $resume = implode("\n", [
            'PERSONAL DETAILS',
            'DOB: 01-01-2000',
            'Gender: Female',
            'Marital Status: Single',
            'Nationality: Indian',
            'Location: Chennai',
            'Address: Chennai, Tamil Nadu',
            'LinkedIn: linkedin.com/in/example',
            'Availability: Immediate',
            'Aditi A R',
            'EDUCATION',
            'B.Com',
        ]);

        $result = $service->extract($resume);

        $this->assertSame('Aditi A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertFalse($result['ai_attempted']);
        $this->assertSame('not_needed_local_verified', $result['ai_result_status']);
    }

    public function test_model_name_split_over_adjacent_header_lines_is_supported(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');

        $service = new CandidateNameExtractionService($client);
        $resume = implode("\n", [
            'PERSONAL DETAILS',
            'DOB: 01-01-2000',
            'Gender: Female',
            'Marital Status: Single',
            'Nationality: Indian',
            'Location: Chennai',
            'Address: Chennai, Tamil Nadu',
            'LinkedIn: linkedin.com/in/example',
            'Availability: Immediate',
            'Aditi',
            'Rao',
            'EDUCATION',
        ]);

        $result = $service->extract($resume);

        $this->assertSame('Aditi Rao', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertFalse($result['ai_attempted']);
        $this->assertSame('not_needed_local_verified', $result['ai_result_status']);
    }


    public function test_contact_label_attached_to_the_name_line_does_not_break_source_matching(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');

        $service = new CandidateNameExtractionService($client);
        $result = $service->extract("Aditi Rao - Mobile: 9876543210 - Email: aditi.rao@example.com\nEDUCATION\nB.Com");

        $this->assertSame('Aditi Rao', $result['candidate_name']);
        $this->assertSame('not_needed_local_verified', $result['ai_result_status']);
        $this->assertFalse($result['ai_attempted']);
    }

    public function test_compact_uppercase_ocr_name_is_recovered_only_when_letters_match_exactly(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');

        $service = new CandidateNameExtractionService($client);
        $resume = "DEEPIKA A R\n8300350913 | deepijp2004@gmail.com | Madurai, Tamil Nadu\nABOUT ME\nA motivated graduate.";
        $result = $service->extract($resume);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertFalse($result['ai_attempted']);
        $this->assertSame('not_needed_local_verified', $result['ai_result_status']);
    }

    public function test_father_or_reference_name_is_not_accepted_as_the_candidate(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([
                ['name' => 'Rajesh Kumar', 'model' => 'test-model', 'model_index' => 0],
            ])
        );
        $client->method('wasLastRequestAttempted')->willReturn(true);

        $service = new CandidateNameExtractionService($client);
        $resume = implode("\n", [
            'PERSONAL DETAILS',
            "Father's Name: Rajesh Kumar",
            'DOB: 01-01-2000',
            'Gender: Male',
            'Nationality: Indian',
            'EDUCATION',
            'B.Com',
        ]);

        $result = $service->extract($resume);

        $this->assertNull($result['candidate_name']);
        $this->assertSame('not_found', $result['source']);
        $this->assertSame('source_evidence_rejected', $result['ai_result_status']);
    }


    public function test_pdf_visual_header_name_wins_over_summary_phrase_after_ai_returns_implausible_text(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');

        $service = new CandidateNameExtractionService($client);
        $resume = implode("\n", [
            'Vijayakumar',
            'common',
            'Education',
            'Sourashtra Arts & Science College',
            'Master of Computer Applications',
            '69.2%',
            'Aug 2018 - Oct 2020',
            'Summary',
            'I am a highly driven recent business school graduate seeking a full-time position in finance',
            'organization improve profitability.',
            'Contact Details',
            '8778106512',
            'vijayvijigerne@gmail.c',
            'om',
        ]);

        $result = $service->extract($resume);

        $this->assertSame('Vijayakumar', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertSame('not_needed_local_verified', $result['ai_result_status']);
        $this->assertFalse($result['ai_attempted']);
    }


    public function test_employer_name_is_not_selected_as_candidate_name(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([
                ['name' => 'Penguin Apparels Pvt', 'model' => 'test-model', 'model_index' => 0],
            ])
        );
        $client->method('wasLastRequestAttempted')->willReturn(true);

        $service = new CandidateNameExtractionService($client);
        $resume = "EDUCATION\nMCA\nEXPERIENCE\nPenguin Apperals Pvt.\nLimited\nQuality Controller\nContact Details\n8778106512";
        $result = $service->extract($resume);

        $this->assertNull($result['candidate_name']);
        $this->assertSame('not_found', $result['source']);
        $this->assertSame('implausible_name', $result['ai_result_status']);
    }


    public function test_employer_in_experience_section_is_not_used_as_candidate_even_beside_contact_details(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->once())->method('extractNameCandidates')->willReturn(
            $this->candidateGenerator([
                ['name' => 'Penguin Global', 'model' => 'test-model', 'model_index' => 0],
            ])
        );
        $client->method('wasLastRequestAttempted')->willReturn(true);

        $service = new CandidateNameExtractionService($client);
        $resume = "Experience\nPenguin Global\nQuality Controller\nContact Details\n8778106512\ncontact@example.com";
        $result = $service->extract($resume);

        $this->assertNull($result['candidate_name']);
        $this->assertSame('not_found', $result['source']);
        $this->assertSame('source_evidence_rejected', $result['ai_result_status']);
    }

    /** @param list<array{name:string,model:string,model_index:int}> $items */
    private function candidateGenerator(array $items): Generator
    {
        foreach ($items as $item) {
            yield $item;
        }
    }
}
