<?php

namespace Tests\Unit;

use App\Services\Recruitment\ResumeAutomation\CandidateNameExtractionService;
use App\Services\Recruitment\ResumeAutomation\HuggingFaceInferenceService;
use Generator;
use Tests\TestCase;

class CandidateNameExtractionServiceTest extends TestCase
{
    private const DEEPIKA_RESUME = "DEEPIKA A R\n8300350913 | deepijp2004@gmail.com | Madurai, Tamil Nadu\n\nABOUT ME\nA highly motivated Computer Science Engineering Diploma graduate seeking an entry-level role.\n\nEDUCATION\nGovernment Polytechnic College for Women, Madurai\n\nTECHNICAL SKILLS\nPython (Proficient)\nJava (Basics)\nCanva Designing\n\nCERTIFICATIONS\nPoetry Competition Certification\nSports Certification";

    public function test_verified_local_name_avoids_an_unnecessary_ai_request(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertNull($result['model']);
        $this->assertFalse($result['ai_attempted']);
        $this->assertSame('not_needed_local_verified', $result['ai_result_status']);
        $this->assertSame(CandidateNameExtractionService::VERSION, $result['parser_version']);
    }

    public function test_ai_result_that_matches_a_certification_is_rejected_then_local_header_wins(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertFalse($result['ai_attempted']);
    }

    public function test_local_source_name_is_preferred_to_ai_name_repetition(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertNull($result['model']);
        $this->assertFalse($result['ai_attempted']);
    }

    public function test_local_parser_recovers_name_with_trailing_initial_without_ai(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertFalse($result['ai_attempted']);
    }

    public function test_unavailable_or_empty_ai_result_falls_back_to_local_parser(): void
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->expects($this->never())->method('extractNameCandidates');
        $service = new CandidateNameExtractionService($client);

        $result = $service->extract(self::DEEPIKA_RESUME);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertNull($result['model']);
        $this->assertFalse($result['ai_attempted']);
    }

    public function test_flattened_pdf_text_recovers_identity_name_and_not_certification_item(): void
    {
        $text = "DEEPIKA A R 8300350913 | deepijp2004@gmail.com | Madurai, Tamil Nadu ABOUT ME A motivated diploma graduate EDUCATION Government Polytechnic College TECHNICAL SKILLS Python Java Canva Designing CERTIFICATIONS Poetry Competition Certification";
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));

        $result = $service->extract($text);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
        $this->assertFalse($result['ai_attempted']);
        $this->assertGreaterThan(0, $service->getLastDiagnostics()['long_raw_line_count'] ?? 0);
    }

    public function test_no_name_in_skills_or_certification_lists_returns_not_found(): void
    {
        $text = "TECHNICAL SKILLS\nPython\nJava\nCanva Designing\nCERTIFICATIONS\nPoetry Competition\nSports Certification";
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([
            ['name' => 'Poetry Competition', 'model' => 'test-model', 'model_index' => 0],
        ]));

        $result = $service->extract($text);

        $this->assertNull($result['candidate_name']);
        $this->assertSame('not_found', $result['source']);
        $this->assertTrue($result['ai_attempted']);
    }


    public function test_header_fallback_prefers_real_name_over_plausible_skill_and_award_phrases(): void
    {
        $text = "PROFILE\nCanva Designing\nPoetry Competition\nTECHNICAL SKILLS\nPython\nDEEPIKA A R\n9876543210 | deepika@example.com";
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));

        $result = $service->extractLocallyOnly($text);

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
    }

    public function test_objective_prose_is_not_accepted_as_a_name(): void
    {
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));
        $result = $service->extract("ABOUT ME\nA highly motivated graduate seeking to contribute and drive\norganizational growth.");

        $this->assertNull($result['candidate_name']);
        $this->assertSame('not_found', $result['source']);
    }

    public function test_explicit_single_word_name_is_allowed_without_ai_when_source_is_clear(): void
    {
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));
        $result = $service->extract("Name: ARUN\nEmail: arun@example.com\nABOUT ME\nSeeking a career");

        $this->assertSame('Arun', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
    }

    public function test_wrapped_name_is_recovered_locally_without_ai(): void
    {
        $service = new CandidateNameExtractionService($this->fakeHuggingFace([]));
        $result = $service->extract("DEEPIKA\nA R\n8300350913 | deepijp2004@gmail.com\nABOUT ME\nA motivated candidate.");

        $this->assertSame('Deepika A R', $result['candidate_name']);
        $this->assertSame('local_parser', $result['source']);
    }

    /** @param list<array{name:string,model:string,model_index:int}> $items */
    private function fakeHuggingFace(array $items): HuggingFaceInferenceService
    {
        $client = $this->createMock(HuggingFaceInferenceService::class);
        $client->method('extractNameCandidates')->willReturn($this->candidateGenerator($items));
        $client->method('wasLastRequestAttempted')->willReturn(true);
        return $client;
    }

    /** @param list<array{name:string,model:string,model_index:int}> $items */
    private function candidateGenerator(array $items): Generator
    {
        foreach ($items as $item) {
            yield $item;
        }
    }
}
