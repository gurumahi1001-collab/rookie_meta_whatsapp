<?php

namespace App\Services;

use App\Support\WhatsAppTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/** Branch-scoped conversation store using only the new prefix-configured whatsapp_contacts/messages tables. */
class WhatsAppConversationService
{
    private function table(string $suffix): string { return WhatsAppTables::name($suffix); }
    private function digits(string $phone): string { return preg_replace('/\D+/', '', $phone); }

    public function getOrCreateContact(int $branchId, string $phone, ?string $displayName = null, string $kind = 'unknown', ?int $sourceId = null): object
    {
        $digits = $this->digits($phone);
        if ($branchId < 1 || strlen($digits) < 8 || strlen($digits) > 15) throw new \InvalidArgumentException('Invalid branch or WhatsApp phone.');
        $phoneE164 = '+' . $digits;
        $table = $this->table('whatsapp_contacts');
        $contact = DB::table($table)->where('branch_id', $branchId)->where('phone_e164', $phoneE164)->first();
        if ($contact) {
            $update = ['updated_at' => now()];
            if ($displayName && trim($displayName) !== '') $update['display_name'] = mb_substr(trim($displayName), 0, 191);
            if (in_array($kind, ['lead', 'customer', 'common', 'unknown'], true) && ($contact->contact_kind === 'unknown' || $contact->contact_kind === 'common')) {
                $update['contact_kind'] = $kind;
            }
            if ($sourceId) $update['source_id'] = $sourceId;
            DB::table($table)->where('id', $contact->id)->update($update);
            return DB::table($table)->where('id', $contact->id)->first();
        }
        $resolved = $this->resolveCrmContact($branchId, $digits, $kind);
        $id = DB::table($table)->insertGetId([
            'branch_id' => $branchId,
            'phone_e164' => $phoneE164,
            'display_name' => mb_substr(trim((string) ($displayName ?: ($resolved['name'] ?? $phoneE164))), 0, 191),
            'contact_kind' => in_array($kind, ['lead', 'customer', 'common', 'unknown'], true) && $kind !== 'unknown' ? $kind : ($resolved['kind'] ?? 'unknown'),
            'source_id' => $sourceId ?: ($resolved['source_id'] ?? null),
            'last_message_at' => null,
            'last_message_preview' => null,
            'is_archived' => 0,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        return DB::table($table)->where('id', $id)->first();
    }

    private function safeIdentifier(string $value): string
    {
        if (!preg_match('/^[A-Za-z][A-Za-z0-9_]*$/', $value)) throw new \InvalidArgumentException('Invalid configured CRM identifier.');
        return $value;
    }

    /** Search only configured CRM tables/columns and always apply branch scope. */
    public function searchCrmContacts(int $branchId, string $kind, string $term, int $limit = 40): array
    {
        if (!in_array($kind, ['lead', 'customer'], true)) return [];
        $cfg = config('whatsapp.crm', []);
        $prefix = $kind === 'lead' ? 'lead_' : 'customer_';
        $table = $this->safeIdentifier((string) ($cfg[$prefix . 'table'] ?? ''));
        $idCol = $this->safeIdentifier((string) ($cfg[$prefix . 'id'] ?? 'sno'));
        $nameCol = $this->safeIdentifier((string) ($cfg[$prefix . 'name'] ?? ''));
        $phoneCol = $this->safeIdentifier((string) ($cfg[$prefix . 'phone'] ?? ''));
        $branchCol = $this->safeIdentifier((string) ($cfg[$prefix . 'branch'] ?? 'branch_id'));
        $statusCol = $this->safeIdentifier((string) ($cfg[$prefix . 'status'] ?? 'status'));
        if (trim($term) === '') return [];
        try {
            $q = DB::table($table)->select([$idCol . ' as source_id', $nameCol . ' as display_name', $phoneCol . ' as crm_phone'])
                ->where($branchCol, $branchId)->where($phoneCol, '!=', null)
                ->where(function ($sub) use ($nameCol, $phoneCol, $term) {
                    $needle = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim($term)) . '%';
                    $sub->where($nameCol, 'like', $needle)->orWhere($phoneCol, 'like', $needle);
                })
                ->orderByDesc($idCol)->limit(max(1, min(80, $limit)));
            // Legacy ERP convention: status=2 commonly means a deleted lead; keep active statuses only where possible.
            if ($kind === 'lead' && $statusCol !== '') $q->where($statusCol, '!=', 2);
            $rows = $q->get();
            $result = [];
            foreach ($rows as $row) {
                $digits = $this->digits((string) $row->crm_phone);
                if (strlen($digits) < 8 || strlen($digits) > 15) continue;
                // Do not turn a local 10-digit number into a guessed country number.
                if (strlen($digits) === 10) $digits = '91' . $digits;
                $phone = '+' . $digits;
                $result[] = [
                    'contact_id' => null,
                    'phone_e164' => $phone,
                    'display_name' => (string) ($row->display_name ?: $phone),
                    'contact_kind' => $kind,
                    'source_id' => (int) $row->source_id,
                    'last_message_preview' => 'ERP contact · open to view conversation',
                    'last_message_at' => null,
                    'session_open' => false,
                    'from_crm' => true,
                ];
            }
            return $result;
        } catch (Throwable $e) {
            // Customer menus are optional across sister ERP applications; a missing table hides search rather than breaking chat.
            Log::notice('WhatsApp CRM contact search unavailable for configured module.', ['kind' => $kind, 'exception' => class_basename($e)]);
            return [];
        }
    }

    private function resolveCrmContact(int $branchId, string $digits, string $preferredKind = 'unknown'): array
    {
        $searchKinds = in_array($preferredKind, ['lead', 'customer'], true) ? [$preferredKind] : ['customer', 'lead'];
        foreach ($searchKinds as $kind) {
            $matches = $this->searchCrmContacts($branchId, $kind, substr($digits, -10), 3);
            foreach ($matches as $match) {
                if (substr($this->digits($match['phone_e164']), -10) === substr($digits, -10)) {
                    return ['name' => $match['display_name'], 'kind' => $kind, 'source_id' => $match['source_id']];
                }
            }
        }
        return [];
    }

    public function storeInbound(int $branchId, string $phone, ?string $profileName, array $message, ?string $messageDateTime = null): void
    {
        $metaId = (string) ($message['id'] ?? '');
        if ($metaId === '') return;
        $type = strtolower((string) ($message['type'] ?? 'unknown'));
        $body = $this->extractBody($message, $type);
        $contact = $this->getOrCreateContact($branchId, $phone, $profileName, 'unknown');
        $at = $messageDateTime ?: now()->toDateTimeString();
        $values = [
            'branch_id' => $branchId, 'contact_id' => $contact->id,
            'direction' => 'inbound', 'message_type' => $type,
            'body' => mb_substr($body, 0, 20000),
            'media_id' => $message[$type]['id'] ?? null,
            'media_mime_type' => $message[$type]['mime_type'] ?? null,
            'media_filename' => $message[$type]['filename'] ?? null,
            'meta_message_id' => $metaId,
            'outbox_id' => null, 'template_name' => null,
            'status' => 'received', 'context_json' => json_encode($message['context'] ?? null, JSON_UNESCAPED_UNICODE),
            'created_by' => null, 'sent_at' => $at, 'delivered_at' => null, 'read_at' => null, 'failed_at' => null,
            'created_at' => now(), 'updated_at' => now(),
        ];
        // Meta retries webhooks; the unique message ID and insertOrIgnore make ingestion idempotent.
        DB::table($this->table('whatsapp_messages'))->insertOrIgnore($values);
        DB::table($this->table('whatsapp_contacts'))->where('id', $contact->id)->update([
            'last_message_at' => $at, 'last_message_preview' => mb_substr($body, 0, 255), 'updated_at' => now(),
        ]);
    }

    private function extractBody(array $message, string $type): string
    {
        if ($type === 'text') return (string) ($message['text']['body'] ?? '');
        if (in_array($type, ['button', 'interactive'], true)) {
            return (string) ($message['button']['text'] ?? $message['interactive']['button_reply']['title'] ?? $message['interactive']['list_reply']['title'] ?? '[' . ucfirst($type) . ' response]');
        }
        if ($type === 'reaction') return (string) ($message['reaction']['emoji'] ?? '[Reaction]');
        if ($type === 'location') return '[Location] ' . ($message['location']['name'] ?? '') . ' ' . ($message['location']['address'] ?? '');
        if ($type === 'contacts') return '[Contact card]';
        if (in_array($type, ['image', 'video', 'audio', 'document', 'sticker'], true)) {
            return (string) ($message[$type]['caption'] ?? '[' . ucfirst($type) . ' received]');
        }
        return '[' . ucfirst($type) . ' message received]';
    }

    public function storeOutbound(object $outbox, string $messageId): void
    {
        $contact = $this->getOrCreateContact((int) $outbox->branch_id, (string) $outbox->phone_e164);
        $body = $outbox->message_type === 'text' ? (string) $outbox->text_body : '[Template] ' . (string) $outbox->template_name;
        DB::table($this->table('whatsapp_messages'))->insertOrIgnore([
            'branch_id' => (int) $outbox->branch_id, 'contact_id' => (int) $contact->id,
            'direction' => 'outbound', 'message_type' => (string) $outbox->message_type,
            'body' => mb_substr($body, 0, 20000), 'media_id' => null, 'media_mime_type' => null, 'media_filename' => null,
            'meta_message_id' => $messageId, 'outbox_id' => (int) $outbox->id,
            'template_name' => $outbox->template_name, 'status' => 'sent', 'context_json' => null,
            'created_by' => $outbox->created_by, 'sent_at' => now(), 'delivered_at' => null, 'read_at' => null, 'failed_at' => null,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        DB::table($this->table('whatsapp_contacts'))->where('id', $contact->id)->update([
            'last_message_at' => now(), 'last_message_preview' => mb_substr($body, 0, 255), 'updated_at' => now(),
        ]);
    }

    public function updateStatusByMetaId(string $messageId, string $status, ?array $error = null): void
    {
        $allowed = ['sent', 'delivered', 'read', 'failed'];
        if (!in_array($status, $allowed, true)) return;
        $row = DB::table($this->table('whatsapp_messages'))->where('meta_message_id', $messageId)->first(['id', 'status']);
        if (!$row) return;
        $rank = ['queued' => 0, 'sent' => 1, 'delivered' => 2, 'read' => 3, 'received' => 3, 'failed' => 4];
        if ($status !== 'failed' && ($rank[$status] ?? 0) < ($rank[$row->status] ?? 0)) return;
        $data = ['status' => $status, 'updated_at' => now()];
        if ($status === 'delivered') $data['delivered_at'] = now();
        if ($status === 'read') $data['read_at'] = now();
        if ($status === 'failed') {
            $data['failed_at'] = now();
            $data['context_json'] = json_encode(['errors' => $error ?: []], JSON_UNESCAPED_UNICODE);
        }
        DB::table($this->table('whatsapp_messages'))->where('id', $row->id)->update($data);
    }

    public function conversationFor(int $branchId, string $phone): array
    {
        $digits = $this->digits($phone);
        if ($branchId < 1 || strlen($digits) < 8 || strlen($digits) > 15) throw new \InvalidArgumentException('Invalid branch/phone.');
        $e164 = '+' . $digits;
        $contact = DB::table($this->table('whatsapp_contacts'))->where('branch_id', $branchId)->where('phone_e164', $e164)->first();
        if (!$contact) $contact = $this->getOrCreateContact($branchId, $e164);
        $messages = DB::table($this->table('whatsapp_messages'))->where('branch_id', $branchId)->where('contact_id', $contact->id)
            ->orderByDesc('id')->limit(200)->get()->reverse()->values();
        $session = DB::table($this->table('whatsapp_sessions'))->where('branch_id', $branchId)->where('phone_e164', $e164)->first();
        $open = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
        return ['contact' => $contact, 'messages' => $messages, 'session_open' => (bool) $open, 'last_inbound_at' => $session->last_inbound_at ?? null];
    }

    public function listConversations(int $branchId, string $kind = 'all', string $term = ''): array
    {
        $q = DB::table($this->table('whatsapp_contacts'))->where('branch_id', $branchId)->where('is_archived', 0)->orderByDesc('last_message_at');
        if ($kind !== 'all' && in_array($kind, ['lead', 'customer', 'common'], true)) $q->where('contact_kind', $kind);
        if (trim($term) !== '') $q->where(function ($s) use ($term) { $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim($term)) . '%'; $s->where('phone_e164', 'like', $like)->orWhere('display_name', 'like', $like); });
        $rows = $q->limit((int) config('whatsapp.conversation_page_size', 80))->get();
        $result = [];
        foreach ($rows as $row) {
            $session = DB::table($this->table('whatsapp_sessions'))->where('branch_id', $branchId)->where('phone_e164', $row->phone_e164)->first();
            $row->session_open = $session && $session->last_inbound_at && \Carbon\Carbon::parse($session->last_inbound_at)->greaterThan(now()->subHours(24));
            $row->from_crm = false;
            $result[] = $row;
        }
        // CRM lookup is query-driven, so opening the chat page never full-scans the ERP's lead/customer tables.
        if ($term !== '' && in_array($kind, ['lead', 'customer'], true)) {
            $existingPhones = array_fill_keys(array_map(function ($r) { return $this->digits((string) $r->phone_e164); }, $result), true);
            foreach ($this->searchCrmContacts($branchId, $kind, $term, 40) as $candidate) {
                if (isset($existingPhones[$this->digits($candidate['phone_e164'])])) continue;
                $result[] = (object) $candidate;
            }
        }
        return $result;
    }
}
