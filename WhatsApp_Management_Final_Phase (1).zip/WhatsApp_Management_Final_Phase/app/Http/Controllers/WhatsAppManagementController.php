<?php

namespace App\Http\Controllers;

use App\Services\WhatsAppConversationService;
use App\Services\WhatsAppManagerService;
use App\Support\WhatsAppTables;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

/** Administrative pages and AJAX endpoints. Never exposes a stored access token. */
class WhatsAppManagementController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $user = $request->user();
            $allowed = (array) config('whatsapp.admin_user_ids', []);
            $userId = (string) ($user->user_id ?? $user->id ?? '');
            if (!$user || !$allowed || !in_array($userId, array_map('strval', $allowed), true)) abort(403, 'WhatsApp Management administrator access is not configured for this account.');
            return $next($request);
        });
    }

    private function table(string $suffix): string { return WhatsAppTables::name($suffix); }
    private function branch(Request $request): int
    {
        $id = (int) $request->input('branch_id', $request->query('branch_id', $request->user()->branch_id ?? 0));
        if ($id < 1) abort(422, 'Select a valid branch.');
        return $id;
    }
    private function actor(Request $request): int { return (int) ($request->user()->user_id ?? $request->user()->id ?? 0); }
    private function ok($data = [], string $message = 'OK') { return response()->json(['ok' => true, 'message' => $message, 'data' => $data]); }
    private function fail(string $message, int $status = 422, array $details = []) { return response()->json(['ok' => false, 'message' => $message, 'details' => $details], $status); }

    private function page(string $section, ?string $kind = null)
    {
        return view('content.whatsapp_management.layout', [
            'section' => $section,
            'kind' => $kind ?: 'lead',
            'defaultBranchId' => (int) request()->query('branch_id', request()->user()->branch_id ?? 1),
            'features' => config('whatsapp.default_features', []),
        ]);
    }
    public function dashboard() { return $this->page('dashboard'); }
    public function chat(string $kind = 'lead')
    {
        if (!in_array($kind, ['lead', 'customer', 'common'], true)) abort(404);
        $flag = ['lead' => 'lead_chat', 'customer' => 'customer_chat', 'common' => 'common_chat'][$kind];
        if (!$this->featureEnabled((int) request()->query('branch_id', request()->user()->branch_id ?? 1), $flag)) abort(403, 'This WhatsApp chat menu is disabled in Setup.');
        return $this->page('chat', $kind);
    }
    public function groups(Request $request) { $this->requireFeature($request, 'custom_group_chat'); return $this->page('groups'); }
    public function broadcast(Request $request) { $this->requireFeature($request, 'broadcast_channel'); return $this->page('broadcast'); }
    public function calling(Request $request) { $this->requireFeature($request, 'calling'); return $this->page('calling'); }
    public function templatesPage() { return $this->page('templates'); }
    public function automation() { return $this->page('automation'); }
    public function campaignsPage(Request $request) { $this->requireFeature($request, 'bulk_campaigns'); return $this->page('campaigns'); }
    public function logsPage() { return $this->page('logs'); }
    public function setup() { return $this->page('setup'); }
    public function consentPage() { return $this->page('consent'); }

    private function requireFeature(Request $request, string $feature): void
    {
        if (!$this->featureEnabled($this->branch($request), $feature)) abort(403, 'This WhatsApp feature is disabled for the selected branch.');
    }

    private function featureEnabled(int $branchId, string $feature): bool
    {
        $setting = DB::table($this->table('whatsapp_menu_settings'))->where('branch_id', $branchId)->where('feature_key', $feature)->value('is_enabled');
        return $setting === null ? (bool) (config('whatsapp.default_features.' . $feature, false)) : (bool) $setting;
    }
    public function features(Request $request)
    {
        $branch = $this->branch($request); $features = (array) config('whatsapp.default_features', []);
        foreach ($features as $key => $default) $features[$key] = $this->featureEnabled($branch, $key);
        return $this->ok(['branch_id' => $branch, 'features' => $features]);
    }
    public function saveFeatures(Request $request)
    {
        $branch = $this->branch($request); $actor = $this->actor($request); $features = (array) config('whatsapp.default_features', []);
        $values = $request->input('features', []);
        if (!is_array($values)) return $this->fail('Features must be an object.');
        foreach ($values as $key => $value) {
            if (!array_key_exists($key, $features)) continue;
            DB::table($this->table('whatsapp_menu_settings'))->updateOrInsert(
                ['branch_id' => $branch, 'feature_key' => $key],
                ['is_enabled' => filter_var($value, FILTER_VALIDATE_BOOLEAN) ? 1 : 0, 'updated_by' => $actor, 'updated_at' => now(), 'created_at' => now()]
            );
        }
        return $this->features($request);
    }

    public function overview(Request $request)
    {
        $branch = $this->branch($request); $monthStart = now()->startOfMonth();
        $outbox = DB::table($this->table('whatsapp_outbox'))->where('branch_id', $branch)->where('created_at', '>=', $monthStart);
        $counts = (clone $outbox)->select('status', DB::raw('COUNT(*) as total'))->groupBy('status')->pluck('total', 'status')->toArray();
        $settings = app(WhatsAppManagerService::class)->settingsForBranch($branch);
        $templates = DB::table($this->table('whatsapp_template_registry'))->where('branch_id', $branch);
        return $this->ok([
            'branch_id' => $branch,
            'global_kill_switch' => (bool) DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', 0)->value('kill_switch'),
            'profile_enabled' => (bool) ($settings->is_enabled ?? false), 'profile_configured' => (bool) ($settings && $settings->phone_number_id && $settings->waba_id && $settings->access_token_encrypted),
            'templates_approved' => (clone $templates)->where('approval_status', 'APPROVED')->count(),
            'templates_total' => (clone $templates)->count(), 'counts' => $counts,
            'campaigns_month' => DB::table($this->table('whatsapp_campaigns'))->where('branch_id', $branch)->where('created_at', '>=', $monthStart)->count(),
        ]);
    }
    public function analytics(Request $request)
    {
        $branch = $this->branch($request); $year = max(2000, min(2100, (int) $request->input('year', now()->year)));
        $mode = $request->input('period', 'month'); $month = max(1, min(12, (int) $request->input('month', now()->month)));
        $from = $mode === 'year' ? Carbon::create($year, 1, 1)->startOfDay() : Carbon::create($year, $month, 1)->startOfDay();
        $to = $mode === 'year' ? $from->copy()->addYear() : $from->copy()->addMonth();
        $counts = DB::table($this->table('whatsapp_outbox'))->select('status', DB::raw('COUNT(*) as total'))
            ->where('branch_id', $branch)->where('created_at', '>=', $from)->where('created_at', '<', $to)->groupBy('status')->pluck('total', 'status')->toArray();
        $byMonth = DB::table($this->table('whatsapp_outbox'))->select(DB::raw('MONTH(created_at) as month_num'), 'status', DB::raw('COUNT(*) as total'))
            ->where('branch_id', $branch)->where('created_at', '>=', Carbon::create($year, 1, 1))->where('created_at', '<', Carbon::create($year + 1, 1, 1))->groupBy(DB::raw('MONTH(created_at)'), 'status')->get();
        return $this->ok(['year' => $year, 'month' => $month, 'period' => $mode, 'from' => $from->toDateString(), 'to_exclusive' => $to->toDateString(), 'counts' => $counts, 'by_month' => $byMonth]);
    }

    public function configs(Request $request)
    {
        $branch = $this->branch($request); $row = DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', $branch)->first();
        if (!$row) return $this->ok(['branch_id' => $branch, 'configured' => false, 'is_enabled' => false, 'waba_id' => '', 'phone_number_id' => '', 'graph_api_version' => config('whatsapp.api_version', 'v26.0'), 'min_send_interval_seconds' => 10]);
        return $this->ok(['branch_id' => $branch, 'configured' => true, 'provider' => $row->provider, 'waba_id' => $row->waba_id, 'phone_number_id' => $row->phone_number_id, 'graph_api_version' => $row->graph_api_version, 'is_enabled' => (bool) $row->is_enabled, 'kill_switch' => (bool) $row->kill_switch, 'min_send_interval_seconds' => (int) $row->min_send_interval_seconds, 'token_saved' => !empty($row->access_token_encrypted)]);
    }
    public function saveConfig(Request $request)
    {
        $input = $request->validate(['branch_id' => 'required|integer|min:1', 'waba_id' => 'required|string|max:100', 'phone_number_id' => 'required|string|max:100', 'graph_api_version' => ['required','regex:/^v\d+\.0$/'], 'access_token' => 'nullable|string|min:30|max:10000', 'is_enabled' => 'nullable|boolean', 'min_send_interval_seconds' => 'nullable|integer|min:5|max:60']);
        $branch = (int) $input['branch_id']; $current = DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', $branch)->first();
        if (!$current && empty($input['access_token'])) return $this->fail('A permanent/system-user access token is required when creating a profile.');
        $data = ['branch_id' => $branch, 'provider' => 'meta_cloud_api', 'waba_id' => trim($input['waba_id']), 'phone_number_id' => trim($input['phone_number_id']), 'graph_api_version' => $input['graph_api_version'], 'is_enabled' => (int) ($input['is_enabled'] ?? false), 'min_send_interval_seconds' => (int) ($input['min_send_interval_seconds'] ?? 10), 'updated_by' => $this->actor($request), 'updated_at' => now()];
        if (!empty($input['access_token'])) $data['access_token_encrypted'] = Crypt::encryptString($input['access_token']);
        if ($current) DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', $branch)->update($data);
        else { $data['kill_switch'] = 0; $data['created_by'] = $this->actor($request); $data['created_at'] = now(); DB::table($this->table('whatsapp_automation_settings'))->insert($data); }
        return $this->configs($request);
    }
    public function testConfig(Request $request) { $result = app(WhatsAppManagerService::class)->testConnection($this->branch($request)); return response()->json($result, $result['ok'] ? 200 : 422); }
    public function toggleConfig(Request $request)
    {
        $branch = $this->branch($request); $enabled = $request->boolean('enabled');
        $exists = DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', $branch)->exists();
        if (!$exists) return $this->fail('No API profile found for the selected branch.');
        DB::table($this->table('whatsapp_automation_settings'))->where('branch_id', $branch)->update(['is_enabled' => $enabled ? 1 : 0, 'updated_by' => $this->actor($request), 'updated_at' => now()]);
        return $this->ok(['is_enabled' => $enabled], $enabled ? 'Branch API profile enabled.' : 'Branch API profile paused.');
    }
    public function killSwitch(Request $request)
    {
        $on = $request->boolean('enabled');
        DB::table($this->table('whatsapp_automation_settings'))->updateOrInsert(['branch_id' => 0], ['provider' => 'meta_cloud_api', 'waba_id' => '', 'phone_number_id' => '', 'graph_api_version' => config('whatsapp.api_version', 'v26.0'), 'is_enabled' => 0, 'kill_switch' => $on ? 1 : 0, 'min_send_interval_seconds' => 10, 'updated_by' => $this->actor($request), 'created_at' => now(), 'updated_at' => now()]);
        return $this->ok(['global_kill_switch' => $on], $on ? 'Global WhatsApp sending is paused.' : 'Global WhatsApp sending pause has been removed.');
    }

    public function templates(Request $request)
    {
        $branch = $this->branch($request); $rows = DB::table($this->table('whatsapp_template_registry'))->where('branch_id', $branch)->orderBy('name')->orderBy('language')->limit(500)->get(['id','name','language','category','approval_status','is_enabled','last_synced_at','components_json']);
        return $this->ok(['templates' => $rows]);
    }
    public function syncTemplates(Request $request) { $result = app(WhatsAppManagerService::class)->syncTemplates($this->branch($request)); return response()->json($result, $result['ok'] ? 200 : 422); }
    public function toggleTemplate(Request $request)
    {
        $data = $request->validate(['branch_id' => 'required|integer|min:1','id' => 'required|integer|min:1','enabled' => 'required|boolean']);
        $exists = DB::table($this->table('whatsapp_template_registry'))->where('branch_id', $data['branch_id'])->where('id', $data['id'])->where('approval_status', 'APPROVED')->exists();
        if (!$exists) return $this->fail('Template not found or not approved. Only approved templates can be enabled.');
        DB::table($this->table('whatsapp_template_registry'))->where('branch_id', $data['branch_id'])->where('id', $data['id'])->update(['is_enabled' => (int) $data['enabled'], 'updated_at' => now()]);
        return $this->ok([], 'Template setting updated.');
    }

    public function workflowRules(Request $request)
    {
        $branch = $this->branch($request); $rows = DB::table($this->table('whatsapp_workflow_rules'))->where('branch_id', $branch)->orderBy('event_key')->get();
        return $this->ok(['rules' => $rows]);
    }
    public function saveWorkflowRule(Request $request)
    {
        $data = $request->validate(['branch_id'=>'required|integer|min:1','event_key'=>['required','regex:/^[a-z][a-z0-9_.-]{1,99}$/'],'template_name'=>'required|string|max:200','language'=>'required|string|max:20','parameter_map_json'=>'nullable|string|max:12000','notes'=>'nullable|string|max:1000','is_enabled'=>'nullable|boolean']);
        $map = trim((string) ($data['parameter_map_json'] ?? ''));
        if ($map !== '') { $parsed = json_decode($map, true); if (json_last_error() !== JSON_ERROR_NONE || !is_array($parsed)) return $this->fail('Parameter mapping must be valid JSON array.'); }
        $branch = (int) $data['branch_id'];
        $template = DB::table($this->table('whatsapp_template_registry'))->where('branch_id', $branch)->where('name', $data['template_name'])->where('language', $data['language'])->where('approval_status', 'APPROVED')->where('is_enabled', 1)->first();
        if (!$template) return $this->fail('Select a synced, Meta APPROVED, enabled template for this branch and language.');
        DB::table($this->table('whatsapp_workflow_rules'))->updateOrInsert(['branch_id' => $branch, 'event_key' => $data['event_key']], ['template_name' => $data['template_name'], 'language' => $data['language'], 'parameter_map_json' => $map ?: null, 'notes' => $data['notes'] ?? null, 'is_enabled' => (int) ($data['is_enabled'] ?? true), 'updated_by' => $this->actor($request), 'updated_at' => now(), 'created_by' => $this->actor($request), 'created_at' => now()]);
        return $this->ok([], 'Workflow rule saved. Test in staging before enabling production events.');
    }
    public function toggleWorkflowRule(Request $request)
    {
        $data = $request->validate(['branch_id'=>'required|integer|min:1','id'=>'required|integer|min:1','enabled'=>'required|boolean']);
        $changed = DB::table($this->table('whatsapp_workflow_rules'))->where('branch_id', $data['branch_id'])->where('id', $data['id'])->update(['is_enabled' => (int) $data['enabled'], 'updated_by' => $this->actor($request), 'updated_at' => now()]);
        return $changed ? $this->ok() : $this->fail('Workflow rule was not found.');
    }

    public function outbox(Request $request)
    {
        $branch = $this->branch($request); $query = DB::table($this->table('whatsapp_outbox'))->where('branch_id', $branch);
        $period = $request->input('period', 'month'); $year = max(2000, min(2100, (int) $request->input('year', now()->year))); $month = max(1, min(12, (int) $request->input('month', now()->month)));
        $from = $period === 'year' ? Carbon::create($year, 1, 1) : Carbon::create($year, $month, 1); $to = $period === 'year' ? $from->copy()->addYear() : $from->copy()->addMonth();
        $query->where('created_at', '>=', $from)->where('created_at', '<', $to);
        if ($request->filled('status') && $request->input('status') !== 'all') $query->where('status', $request->input('status'));
        if ($request->filled('q')) { $term = trim((string) $request->input('q')); $query->where(function ($sub) use ($term) { $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $term) . '%'; $sub->where('phone_e164','like',$like)->orWhere('template_name','like',$like)->orWhere('workflow_event_key','like',$like)->orWhere('source_type','like',$like); }); }
        $rows = $query->orderByDesc('id')->paginate(50, ['id','phone_e164','message_type','template_name','language','source_type','workflow_event_key','campaign_id','status','error_code','error_message','scheduled_at','meta_message_id','sent_at','delivered_at','read_at','failed_at','created_at']);
        return $this->ok(['rows' => $rows->items(), 'page' => $rows->currentPage(), 'last_page' => $rows->lastPage(), 'total' => $rows->total()]);
    }

    public function sendTemplate(Request $request)
    {
        $data = $request->validate(['branch_id'=>'required|integer|min:1','to'=>'required|string|max:40','template_name'=>'required|string|max:200','language'=>'required|string|max:20','components'=>'nullable|string|max:20000','source_type'=>'nullable|string|max:80']);
        $components = json_decode((string) ($data['components'] ?? '[]'), true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($components)) return $this->fail('Components must be valid JSON array.');
        $result = app(WhatsAppManagerService::class)->queueTemplate(['branch_id'=>(int)$data['branch_id'],'to'=>$data['to'],'template_name'=>$data['template_name'],'language'=>$data['language'],'components'=>$components,'source_type'=>$data['source_type'] ?? 'admin_manual','created_by'=>$this->actor($request),'idempotency_key'=>'manual:'.Str::uuid()]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }
    public function sendText(Request $request)
    {
        $data = $request->validate(['branch_id'=>'required|integer|min:1','to'=>'required|string|max:40','text'=>'required|string|max:4096','kind'=>'nullable|in:lead,customer,common']);
        $kind = $data['kind'] ?? 'common';
        $feature = ['lead'=>'lead_chat','customer'=>'customer_chat','common'=>'common_chat'][$kind];
        $this->requireFeature($request, $feature);
        $result = app(WhatsAppManagerService::class)->queueText(['branch_id'=>(int)$data['branch_id'],'to'=>$data['to'],'text'=>$data['text'],'source_type'=>'chat_text_'.$kind,'created_by'=>$this->actor($request),'idempotency_key'=>'chat:'.$kind.':'.Str::uuid()]);
        return response()->json($result, !empty($result['ok']) ? 202 : 422);
    }
    public function bulkSend(Request $request)
    {
        $this->requireFeature($request, 'bulk_campaigns');
        $data = $request->validate([
            'branch_id' => 'required|integer|min:1',
            'name' => 'required|string|max:191',
            'template_name' => 'required|string|max:200',
            'language' => 'required|string|max:20',
            'components' => 'nullable|string|max:20000',
            'recipients' => 'nullable|string|max:30000',
            'audience_id' => 'nullable|integer|min:1',
        ]);
        $branch = (int) $data['branch_id'];
        $recipients = [];
        $lines = preg_split('/[\r\n,;]+/', (string) ($data['recipients'] ?? ''));
        $recipients = array_merge($recipients, array_filter(array_map('trim', $lines)));

        if (!empty($data['audience_id'])) {
            $audience = DB::table($this->table('whatsapp_audiences'))
                ->where('branch_id', $branch)->where('id', (int) $data['audience_id'])->first();
            if (!$audience) return $this->fail('Selected saved audience was not found in this branch.');
            $memberPhones = DB::table($this->table('whatsapp_audience_members'))
                ->where('branch_id', $branch)->where('audience_id', $audience->id)
                ->orderBy('id')->pluck('phone_e164')->all();
            $recipients = array_merge($recipients, $memberPhones);
        }
        $recipients = array_values(array_unique(array_filter(array_map('trim', $recipients))));
        $max = (int) config('whatsapp.bulk_max_recipients', 250);
        if (!$recipients || count($recipients) > $max) {
            return $this->fail('Recipient count must be between 1 and ' . $max . '. Choose a saved audience or enter international numbers.');
        }
        $components = json_decode((string) ($data['components'] ?? '[]'), true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($components)) return $this->fail('Components must be valid JSON array.');

        $campaignId = DB::table($this->table('whatsapp_campaigns'))->insertGetId([
            'campaign_uuid' => (string) Str::uuid(), 'branch_id' => $branch, 'name' => $data['name'],
            'template_name' => $data['template_name'], 'language' => $data['language'], 'state' => 'queued',
            'total_recipients' => count($recipients), 'queued_count' => 0, 'blocked_count' => 0,
            'created_by' => $this->actor($request), 'created_at' => now(), 'updated_at' => now(),
        ]);
        $queued = 0; $blocked = 0; $results = [];
        $spacing = (int) config('whatsapp.default_bulk_pacing_seconds', 10);
        foreach ($recipients as $idx => $to) {
            $result = app(WhatsAppManagerService::class)->queueTemplate([
                'branch_id' => $branch, 'to' => $to, 'template_name' => $data['template_name'],
                'language' => $data['language'], 'components' => $components, 'source_type' => 'bulk_campaign',
                'campaign_id' => $campaignId, 'created_by' => $this->actor($request), 'delay_seconds' => $idx * $spacing,
                'idempotency_key' => 'campaign:' . $campaignId . ':' . hash('sha256', $to),
            ]);
            if (!empty($result['ok'])) $queued++; else $blocked++;
            // Do not echo recipient numbers back in the campaign response; details belong in secured logs.
            $results[] = ['recipient_ref' => substr(hash('sha256', $to), 0, 12), 'status' => $result['status'] ?? 'blocked', 'reason' => $result['reason'] ?? null, 'outbox_id' => $result['id'] ?? null];
        }
        DB::table($this->table('whatsapp_campaigns'))->where('id', $campaignId)->update([
            'state' => $queued ? ($blocked ? 'partially_queued' : 'queued') : 'blocked',
            'queued_count' => $queued, 'blocked_count' => $blocked, 'updated_at' => now(),
        ]);
        return $this->ok(['campaign_id' => $campaignId, 'total' => count($recipients), 'queued' => $queued, 'blocked' => $blocked, 'results' => $results], 'Campaign queue request processed; queue admission is not final delivery. Check Message Logs for provider receipts.');
    }

    public function conversations(Request $request, WhatsAppConversationService $service)
    {
        $branch = $this->branch($request); $kind = (string) $request->input('kind','all'); $term = trim((string) $request->input('q',''));
        if (!in_array($kind, ['all','lead','customer','common'], true)) $kind = 'all';
        if ($kind !== 'all') {
            $feature = ['lead'=>'lead_chat','customer'=>'customer_chat','common'=>'common_chat'][$kind];
            $this->requireFeature($request, $feature);
        } elseif (!$this->featureEnabled($branch, 'lead_chat') && !$this->featureEnabled($branch, 'customer_chat') && !$this->featureEnabled($branch, 'common_chat')) {
            abort(403, 'All WhatsApp chat features are disabled for the selected branch.');
        }
        return $this->ok(['conversations'=>$service->listConversations($branch,$kind,$term)]);
    }
    public function conversationMessages(Request $request, string $phone, WhatsAppConversationService $service)
    {
        $branch = $this->branch($request);
        $kind = (string) $request->query('kind', 'common');
        if (!in_array($kind, ['lead','customer','common'], true)) $kind = 'common';
        $feature = ['lead'=>'lead_chat','customer'=>'customer_chat','common'=>'common_chat'][$kind];
        $this->requireFeature($request, $feature);
        try { $result = $service->conversationFor($branch, urldecode($phone)); } catch (Throwable $e) { return $this->fail('Conversation phone or branch is invalid.'); }
        return $this->ok($result);
    }
    public function recordConsent(Request $request)
    {
        $data = $request->validate(['branch_id'=>'required|integer|min:1','phone'=>'required|string|max:40','category'=>'required|in:all,marketing,utility,authentication','consent_status'=>'required|in:opted_in,opted_out','source'=>'required|string|max:100','evidence_ref'=>'required|string|max:1000']);
        $data['created_by'] = $this->actor($request); $result = app(WhatsAppManagerService::class)->recordConsent($data);
        return response()->json($result, !empty($result['ok']) ? 200 : 422);
    }

    public function audiences(Request $request)
    {
        $this->requireFeature($request, 'custom_group_chat');
        $branch = $this->branch($request); return $this->ok(['audiences'=>DB::table($this->table('whatsapp_audiences'))->where('branch_id',$branch)->orderByDesc('id')->limit(100)->get()]);
    }
    public function createAudience(Request $request)
    {
        $this->requireFeature($request, 'custom_group_chat');
        $data = $request->validate(['branch_id'=>'required|integer|min:1','name'=>'required|string|max:191','description'=>'nullable|string|max:1000']);
        $id = DB::table($this->table('whatsapp_audiences'))->insertGetId(['branch_id'=>$data['branch_id'],'name'=>$data['name'],'description'=>$data['description'] ?? null,'created_by'=>$this->actor($request),'created_at'=>now(),'updated_at'=>now()]);
        return $this->ok(['id'=>$id], 'ERP audience created. This is a recipient list, not a native WhatsApp group or Channel.');
    }
    public function addAudienceMembers(Request $request)
    {
        $this->requireFeature($request, 'custom_group_chat');
        $data = $request->validate(['branch_id'=>'required|integer|min:1','audience_id'=>'required|integer|min:1','recipients'=>'required|string|max:30000']);
        $aud = DB::table($this->table('whatsapp_audiences'))->where('branch_id',$data['branch_id'])->where('id',$data['audience_id'])->first(); if (!$aud) return $this->fail('Audience not found in this branch.');
        $lines = preg_split('/[\r\n,;]+/', (string)$data['recipients']); $phones = array_values(array_unique(array_filter(array_map('trim',$lines)))); if (count($phones)>250) return $this->fail('Add at most 250 audience members per operation.');
        $inserted = 0; $manager = app(WhatsAppManagerService::class);
        foreach ($phones as $phone) { try { $normal = $manager->normalizePhone($phone); } catch (Throwable $e) { continue; }
            DB::table($this->table('whatsapp_audience_members'))->updateOrInsert(['branch_id'=>$data['branch_id'],'audience_id'=>$aud->id,'phone_e164'=>$normal],['consent_verified'=>0,'created_at'=>now(),'updated_at'=>now()]); $inserted++;
        }
        return $this->ok(['members_saved'=>$inserted], 'Recipients saved. The campaign engine still requires per-recipient consent before sending.');
    }
    public function campaigns(Request $request)
    {
        $this->requireFeature($request, 'bulk_campaigns');
        $branch = $this->branch($request); return $this->ok(['campaigns'=>DB::table($this->table('whatsapp_campaigns'))->where('branch_id',$branch)->orderByDesc('id')->limit(100)->get()]);
    }
}
