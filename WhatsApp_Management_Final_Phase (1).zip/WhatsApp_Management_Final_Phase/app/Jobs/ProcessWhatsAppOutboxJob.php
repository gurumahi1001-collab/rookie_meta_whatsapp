<?php

namespace App\Jobs;

use App\Services\WhatsAppManagerService;
use App\Support\WhatsAppTables;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

/**
 * WhatsApp POSTs are intentionally not automatically retried after ambiguous
 * network failures: Meta does not provide a general idempotency key for sends,
 * so blind retries can deliver a duplicate message.
 */
class ProcessWhatsAppOutboxJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 1;
    public $timeout = 60;
    protected $outboxId;

    public function __construct(int $outboxId)
    {
        $this->outboxId = $outboxId;
        $this->onQueue('whatsapp');
    }

    public function handle(WhatsAppManagerService $service): void
    {
        $service->processOutbox($this->outboxId);
    }

    public function failed(\Throwable $exception): void
    {
        \Illuminate\Support\Facades\DB::table(WhatsAppTables::name('whatsapp_outbox'))
            ->where('id', $this->outboxId)
            ->whereIn('status', ['queued', 'processing'])
            ->update([
                'status' => 'failed',
                'error_code' => 'QUEUE_JOB_FAILED',
                'error_message' => 'Queue job failed unexpectedly; inspect protected server logs.',
                'failed_at' => now(),
                'updated_at' => now(),
            ]);
    }
}
