# WhatsApp Management — Laravel MVC overlay

This is an additive, branch-scoped WhatsApp management module for the supplied ERP. It centralizes new outbound messages through a policy-aware outbox and provides an AJAX/jQuery admin console with a vertical submenu. It is designed for a staged rollout; it is **not a claim that every legacy controller in the production ERP has been migrated or that a Meta restriction can never occur**.

## What is included

- `app/Services/WhatsAppManagerService.php` — Meta Cloud API configuration lookup, template sync, named-event workflow mapping, consent checks, 24-hour free-form-window enforcement, outbox scheduling/pacing, delivery receipt updates, global/branch send kill-switches.
- `app/Services/WhatsAppConversationService.php` — branch-scoped conversation/contact history and query-driven CRM lookup.
- `app/Http/Controllers/WhatsAppManagementController.php` — admin page/API handlers, configuration encryption, analytics, templates, automation rules, outbox logs, chat sends, consent and campaign/audience management.
- `app/Http/Controllers/WhatsAppWebhookController.php` — public GET verification and POST HMAC signature validation; multi-entry, multi-message and status processing.
- `app/Jobs/ProcessWhatsAppOutboxJob.php` — asynchronous send job; single attempt for ambiguous network results to avoid accidental duplicate messages.
- `resources/views/content/whatsapp_management/layout.blade.php` plus `pages/*.blade.php` — WhatsApp-Web-inspired layout and menu-wise pages, all management interactions using jQuery AJAX.
- `database/whatsapp_management_upgrade.sql` — additive MySQL tables, including outbox, template registry, workflow rules, opt-in/opt-out evidence, 24-hour sessions, contacts/messages, campaigns, audiences and per-branch menu features.
- `routes/whatsapp_management.php` — protected admin routes plus a public, signature-validated Meta webhook endpoint.
- `patches/ManageLead.php` — patched copy of the separately uploaded `ManageLead.php`: new-lead welcome, existing manual template and syllabus sends use the central service instead of direct Graph API requests.
- `patches/app/Http/Controllers/whatsapp_management/WhatsappConfig.php` — patched legacy webhook controller without the embedded secret/token; its callback delegates to the new webhook controller.
- `examples/controller_integration_examples.php` — examples for adding the same event-based workflow to customers, event notifications and student certificates.
- `docs/LEGACY_SEND_INVENTORY.md` — static scan inventory from the supplied WhatsApp upgrade ZIP.
- `docs/VALIDATION_AND_LIMITATIONS.md` — checks performed, staging acceptance list and current functional limits.

## Before touching production

1. Back up the deployed code and database, and use a staging clone first. The supplied ERP archive does not include a `composer.json`, an export of the live database schema, `.env`, or complete deployment configuration; live Laravel, SQL, queue, and Meta integration tests cannot be certified from the supplied source alone.
2. Treat any token/secret discovered in old code, comments, log files or old DB records as compromised. Revoke/rotate it in Meta, remove it from source control, and never include it in tickets or logs.
3. A newly created Developer App does not automatically clear enforcement affecting the Business Portfolio, WABA, phone number or templates. Resolve any existing account restriction in Meta Business Support Home/Account Quality and appeal where appropriate instead of using app rotation to evade enforcement.
4. Do not enable outbound sending until Meta asset assignment, access scopes, approved templates, genuine opt-in evidence, webhook subscriptions and staged test sends are verified.

## Installation (staging first)

### 1. Copy overlay files

Copy each file/folder from the package root to the matching path in the Laravel project root. These are new paths, except the two patched controller files. **Do not overwrite a newer live controller without diffing it first**:

- Merge `patches/ManageLead.php` changes into your live `app/Http/Controllers/lead_management/ManageLead.php` (or replace only after confirming it is the same revision).
- Merge `patches/app/Http/Controllers/whatsapp_management/WhatsappConfig.php` into the actual legacy controller.
- Copy all the new `app/`, `config/`, `resources/`, and `routes/` files.

The patched `ManageLead.php` corresponds to the separate uploaded PHP file. It is not the same class/path as the `sales/lead/Lead.php` file listed in the inventory inside the earlier WhatsApp ZIP.

### 2. Apply SQL with the correct prefix

`database/whatsapp_management_upgrade.sql` creates only new tables and does not modify existing ERP tables. The supplied default table prefix is `et_`, matching the supplied `et_lead` / `et_*` ERP naming convention.

For another sister-ERP database, replace **every leading `et_` table prefix in the SQL file** with that app's actual prefix before execution, and set `WHATSAPP_TABLE_PREFIX` to the same prefix. Do not change the suffixes `whatsapp_*`. Confirm the resulting names and backup first. SQL is written for MySQL 5.7+/8.x-style InnoDB.

### 3. Add environment configuration

Merge these settings into `.env` (generate strong independent random secrets; never use these example placeholders literally):

```dotenv
WHATSAPP_GRAPH_API_VERSION=v26.0
WHATSAPP_DEFAULT_HEADER_IMAGE_URL=
WHATSAPP_PUBLIC_MEDIA_BASE_URL=https://your-production-erp.example.com
WHATSAPP_VERIFY_TOKEN=replace-with-a-long-random-webhook-verification-token
META_APP_SECRET=replace-with-the-app-secret-from-meta
WHATSAPP_TABLE_PREFIX=et_
WHATSAPP_ADMIN_USER_IDS=1,2
WHATSAPP_BULK_MAX_RECIPIENTS=250
WHATSAPP_BULK_PACING_SECONDS=10
WHATSAPP_TEMPLATE_SYNC_MAX_PAGES=20
WHATSAPP_CONVERSATION_PAGE_SIZE=80

# Set these according to the actual table/column names in this ERP.
WHATSAPP_LEAD_TABLE=et_lead
WHATSAPP_LEAD_ID_COLUMN=sno
WHATSAPP_LEAD_NAME_COLUMN=lead_name
WHATSAPP_LEAD_PHONE_COLUMN=lead_mobile
WHATSAPP_LEAD_BRANCH_COLUMN=branch_id
WHATSAPP_LEAD_STATUS_COLUMN=status
WHATSAPP_CUSTOMER_TABLE=et_customer
WHATSAPP_CUSTOMER_ID_COLUMN=sno
WHATSAPP_CUSTOMER_NAME_COLUMN=cus_name
WHATSAPP_CUSTOMER_PHONE_COLUMN=cus_mobile
WHATSAPP_CUSTOMER_BRANCH_COLUMN=branch_id
WHATSAPP_CUSTOMER_STATUS_COLUMN=status
```

`WHATSAPP_ADMIN_USER_IDS` must contain the authenticated ERP `user_id` values (the `id` property is used only if there is no `user_id`). An empty list fails closed with 403. The included gate is allowlist-based; align it with your actual role/permission system before rollout. Keep `APP_KEY` stable because tokens are encrypted with Laravel `Crypt`.

After changing config, run `php artisan config:clear`; if your deployment uses cached configuration, rebuild it with `php artisan config:cache`.

### 4. Register routes carefully

The existing source has `/webhook_whatsapp` inside the `auth:web` / `timezone` group. Remove that old route from inside the authenticated group. At the **end of `routes/web.php`, after the existing authenticated group has closed**, add:

```php
require_once base_path('routes/whatsapp_management.php');
```

See `patches/routes_web_integration.php.txt`. Management UI/API routes require `auth:web` and the configured admin allowlist. The `/webhook_whatsapp` route must remain public for Meta callback delivery, but POST requests are checked against `X-Hub-Signature-256` using `META_APP_SECRET`.

In your existing `App\\Http\\Middleware\\VerifyCsrfToken`, append `'webhook_whatsapp'` to the existing `$except` array (do not replace other entries and do not disable CSRF globally). The POST endpoint validates the Meta HMAC signature. See `patches/VerifyCsrfToken.php.txt`.

### 5. Set up queue worker

Use a durable queue driver (Redis or a configured database queue), not the `sync` driver for production bulk messaging. Verify the `jobs` and failed-jobs tables exist if using a database queue. Run a worker supervised by Supervisor/systemd/container orchestration, for example:

```bash
php artisan queue:work --queue=whatsapp,default --tries=1 --timeout=60
```

Restart workers as part of deployment. Monitor queue delay and failed jobs.

### 6. Configure Meta and branch profiles

1. Open `/wa-management` as a listed admin.
2. In **API & menu setup**, configure each branch's WABA ID, phone-number ID, a current System User token, and a supported Graph API version. Keep sending disabled while testing.
3. Test credentials, sync templates, inspect the category/status/components, and enable only approved templates intended for production.
4. In **Automation rules**, add branch/event mappings such as `lead.created`, `customer.created`, `academy.event_certificate` and `academy.event_reminder`.
5. Record real opt-in evidence before sending a template to a customer. A Meta-approved template alone is not proof of consent.
6. Configure Meta to call the HTTPS callback URL `/webhook_whatsapp`; subscribe the app/WABA to relevant `messages` webhook fields, and confirm the GET verify challenge plus signed POST callbacks on staging.
7. Test one opted-in internal number, then a two-recipient controlled group, then expand gradually while watching template/phone quality and error statuses.

## How to call from any ERP controller

Use `WhatsAppManagerService` rather than inline Graph API requests or the legacy `sendRequestToWhatsApp` helper.

```php
$queued = app(\\App\\Services\\WhatsAppManagerService::class)->queueWorkflow([
    'branch_id' => (int) $branchId,
    'event_key' => 'customer.created', // exact key from Automation rules
    'to' => '+919876543210',           // E.164; do not pass an ambiguous local number
    'variables' => [
        'customer_name' => (string) $customer->customer_name,
        'branch_name' => (string) $branch->branch_name,
    ],
    'source_type' => 'customer.created',
    'source_id' => (int) $customer->sno,
    'created_by' => (int) auth()->user()->user_id,
    'idempotency_key' => 'customer.created:' . (int) $branchId . ':' . (int) $customer->sno,
]);

// Do not roll back successful CRM creation just because WhatsApp has been paused/blocked.
if (empty($queued['ok'])) {
    \\Illuminate\\Support\\Facades\\Log::notice('WhatsApp notification not queued', [
        'source_id' => (int) $customer->sno,
        'outbox_id' => $queued['id'] ?? null,
        'queue_status' => $queued['status'] ?? 'blocked',
    ]);
}
```

Then create the exact event rule and parameter mapping in Automation rules for the branch. The patched lead controller now uses `lead.created` for the automatic lead welcome. The legacy manual-template selector is dynamically mapped by selected template name to `lead.manual_template.<template_name_slug>`; for example, `elysium_academy_welcome_message` becomes `lead.manual_template.elysium_academy_welcome_message`. The syllabus button uses `lead.manual_template.eapl_erp_syllabus_send2` by default. Configure each selected template with its matching approved template name/language and mapping; an absent/mismatched rule is blocked and logged rather than silently sending a wrong template. The source variables include safe scalar lead attributes plus aliases such as `lead_name`, `lead_mobile`, `course_name`, `branch_name`, `sales_mobile`, `document_url`, `syllabus_url` and `greeting` where available. A custom sender may pass additional scalar values in `template_variables`. Example parameter map:

```json
[
  {"type":"body","parameters":[
    {"type":"text","source":"customer_name"},
    {"type":"text","source":"branch_name"}
  ]}
]
```

If a workflow uses the header image source, configure `WHATSAPP_DEFAULT_HEADER_IMAGE_URL` to a public HTTPS asset first; the package no longer points production to a hard-coded dev URL. The syllabus event builds its public attachment URL from `WHATSAPP_PUBLIC_MEDIA_BASE_URL` (which defaults to `APP_URL`), so set that value to the correct HTTPS asset origin for this ERP. The map must match the approved template's component/parameter order. Template-name selection stays in the admin UI; event-specific data construction stays in the existing business controller. For no-variable templates use an empty array `[]`. More lead/customer/event/certificate examples are in `examples/controller_integration_examples.php`.

## What this package does and does not implement

Included now: menu-wise admin panel; per-branch configuration; encrypted access tokens; template sync/approval gating; event-to-template mapping; outbox pacing/idempotency; status logs and monthly/yearly counts; signed webhook handling; one-to-one chat/history for supported message metadata; text replies only during the 24-hour customer-service window; per-recipient opt-in checks; opt-out handling; bulk campaigns; saved ERP audiences; menu feature switches; global and branch send pause controls.

Not represented as complete in this version: consumer-WhatsApp-Web parity; native WhatsApp groups/Channels publishing; media-download/preview and all outbound attachment flows; calls/voice/video calling; full campaign drafts/approval and analytics provider dashboards. The Groups/Channels/Calling menu pages clearly show these as capability-gated or ERP-audience features rather than pretending the standard Cloud API automatically makes them available. Do not enable calling until a separately tested Meta Calling API integration is added for the account's eligibility and permission set.

## Legacy sender migration

The earlier WhatsApp upgrade ZIP contains 105 `sendRequestToWhatsApp` references across 29 PHP files, including historical backups. The separately uploaded `ManageLead.php` patch migrates its lead-welcome, existing manual-template and syllabus flow. This package does **not** rewrite all customer/event/cron/staff/assessment controller versions found in that scan. Use the inventory in `docs/LEGACY_SEND_INVENTORY.md` to identify the live ones and migrate each active send site before claiming all application sends are centrally governed.

## Rollback

1. Turn on the global pause and disable branch profiles.
2. Revert the application files to the saved deployment build while leaving the additive WhatsApp tables intact; no existing ERP tables are altered by the included SQL.
3. Confirm no queued job or webhook process still uses the new service before later exporting and removing the new tables.

See `docs/VALIDATION_AND_LIMITATIONS.md` before rollout.
