<?php

namespace App\Http\Controllers\whatsapp_management;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\WhatsappContactModel;
use App\Models\WhatsappMessageModel;
use App\Models\WhatsappTemplateLogModel;
use App\Events\NewMessage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http; // Import Http facade
use Carbon\Carbon;

class WhatsappConfig extends Controller
{
    /**
     * Backwards-compatible wrapper. Configure Meta to call the public /webhook_whatsapp route,
     * which delegates to the signature-verifying central controller. This method has no secrets.
     */
    public function WhatsappWebhook(Request $request)
    {
        return app(\App\Http\Controllers\WhatsAppWebhookController::class)->handle(
            $request,
            app(\App\Services\WhatsAppManagerService::class),
            app(\App\Services\WhatsAppConversationService::class)
        );
    }

    private function getMediaExtension($mimeType)
    {
    $mimeMap = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
        'video/mp4' => 'mp4',
        'video/avi' => 'avi',
        'video/3gpp' => '3gp',
        'audio/mpeg' => 'mp3',
        'audio/ogg' => 'ogg',
        'audio/wav' => 'wav',
        'audio/webm' => 'webm',
        'application/pdf' => 'pdf',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'application/vnd.ms-excel' => 'xls',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
        'application/zip' => 'zip',
        'application/x-rar-compressed' => 'rar',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation' => 'pptx',
    ];

    return $mimeMap[$mimeType] ?? 'bin'; // Default to 'bin' if no match
}

    
    /**
     * Get media folder based on type.
     */
    private function getMediaFolder($messageType)
    {
        return match ($messageType) {
            'image' => 'images',
            'video' => 'videos',
            'document' => 'documents',
            'audio' => 'audios',
            'sticker' => 'stickers',
            default => 'other',
        };
    }
}