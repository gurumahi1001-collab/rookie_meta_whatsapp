<?php

use App\Http\Controllers\WhatsAppManagementController;
use App\Http\Controllers\WhatsAppWebhookController;
use Illuminate\Support\Facades\Route;

/*
 * Include this route file from routes/web.php AFTER the existing authenticated group closes.
 * This file wraps management routes in auth:web/timezone and registers the public signed webhook separately.
 */
Route::prefix('wa-management')->name('wa-management.')->middleware(['auth:web', 'timezone'])->group(function () {
    Route::get('/', [WhatsAppManagementController::class, 'dashboard'])->name('dashboard');
    Route::get('/chats/{kind}', [WhatsAppManagementController::class, 'chat'])->where('kind', 'lead|customer|common')->name('chat');
    Route::get('/groups', [WhatsAppManagementController::class, 'groups'])->name('groups');
    Route::get('/broadcast', [WhatsAppManagementController::class, 'broadcast'])->name('broadcast');
    Route::get('/calling', [WhatsAppManagementController::class, 'calling'])->name('calling');
    Route::get('/templates', [WhatsAppManagementController::class, 'templatesPage'])->name('templates');
    Route::get('/automation', [WhatsAppManagementController::class, 'automation'])->name('automation');
    Route::get('/campaigns', [WhatsAppManagementController::class, 'campaignsPage'])->name('campaigns');
    Route::get('/logs', [WhatsAppManagementController::class, 'logsPage'])->name('logs');
    Route::get('/setup', [WhatsAppManagementController::class, 'setup'])->name('setup');
    Route::get('/consent', [WhatsAppManagementController::class, 'consentPage'])->name('consent');

    Route::prefix('api')->name('api.')->group(function () {
        Route::get('/overview', [WhatsAppManagementController::class, 'overview']);
        Route::get('/analytics', [WhatsAppManagementController::class, 'analytics']);
        Route::get('/config', [WhatsAppManagementController::class, 'configs']);
        Route::post('/config', [WhatsAppManagementController::class, 'saveConfig']);
        Route::post('/config/test', [WhatsAppManagementController::class, 'testConfig']);
        Route::post('/config/toggle', [WhatsAppManagementController::class, 'toggleConfig']);
        Route::post('/kill-switch', [WhatsAppManagementController::class, 'killSwitch']);
        Route::get('/features', [WhatsAppManagementController::class, 'features']);
        Route::post('/features', [WhatsAppManagementController::class, 'saveFeatures']);
        Route::get('/templates', [WhatsAppManagementController::class, 'templates']);
        Route::post('/templates/sync', [WhatsAppManagementController::class, 'syncTemplates']);
        Route::post('/templates/toggle', [WhatsAppManagementController::class, 'toggleTemplate']);
        Route::get('/workflow-rules', [WhatsAppManagementController::class, 'workflowRules']);
        Route::post('/workflow-rules', [WhatsAppManagementController::class, 'saveWorkflowRule']);
        Route::post('/workflow-rules/toggle', [WhatsAppManagementController::class, 'toggleWorkflowRule']);
        Route::get('/outbox', [WhatsAppManagementController::class, 'outbox']);
        Route::post('/send/template', [WhatsAppManagementController::class, 'sendTemplate']);
        Route::post('/send/text', [WhatsAppManagementController::class, 'sendText']);
        Route::post('/send/bulk', [WhatsAppManagementController::class, 'bulkSend']);
        Route::get('/conversations', [WhatsAppManagementController::class, 'conversations']);
        Route::get('/conversations/{phone}/messages', [WhatsAppManagementController::class, 'conversationMessages']);
        Route::post('/consent', [WhatsAppManagementController::class, 'recordConsent']);
        Route::get('/audiences', [WhatsAppManagementController::class, 'audiences']);
        Route::post('/audiences', [WhatsAppManagementController::class, 'createAudience']);
        Route::post('/audiences/members', [WhatsAppManagementController::class, 'addAudienceMembers']);
        Route::get('/campaigns', [WhatsAppManagementController::class, 'campaigns']);
    });
});

// SECURITY: Do not put this endpoint inside auth:web. It verifies Meta's GET challenge and POST HMAC.
// Remove the existing /webhook_whatsapp route from inside the authenticated group and add this after it closes.
Route::match(['get', 'post'], '/webhook_whatsapp', [WhatsAppWebhookController::class, 'handle'])
    ->withoutMiddleware(['auth:web', 'timezone'])->name('whatsapp.webhook');
