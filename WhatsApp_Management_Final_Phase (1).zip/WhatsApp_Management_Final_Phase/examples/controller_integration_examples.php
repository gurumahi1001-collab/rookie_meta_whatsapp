<?php

use App\Services\WhatsAppManagerService;
use Illuminate\Support\Facades\Log;

/**
 * Generic helper for any ERP module. Call this only after the CRM/event write commits successfully.
 * It never throws a WhatsApp error back through the business operation.
 */
function queueErpWhatsAppWorkflow(
    int $branchId,
    string $eventKey,
    string $phoneE164,
    array $variables,
    string $sourceType,
    int $sourceId,
    ?int $actorId = null,
    ?string $idempotencyKey = null
): array {
    try {
        $result = app(WhatsAppManagerService::class)->queueWorkflow([
            'branch_id' => $branchId,
            'event_key' => $eventKey,
            'to' => $phoneE164,
            'variables' => $variables,
            'source_type' => $sourceType,
            'source_id' => $sourceId,
            'created_by' => $actorId,
            'idempotency_key' => $idempotencyKey ?: ($eventKey . ':' . $branchId . ':' . $sourceId),
        ]);
        if (empty($result['ok'])) {
            Log::notice('WhatsApp business notification was not queued; source operation remains committed.', [
                'event_key' => $eventKey,
                'source_type' => $sourceType,
                'source_id' => $sourceId,
                'branch_id' => $branchId,
                'outbox_id' => $result['id'] ?? null,
                'status' => $result['status'] ?? 'blocked',
            ]);
        }
        return $result;
    } catch (\Throwable $exception) {
        // A nonessential notification must not roll back the lead/customer/event record.
        Log::error('WhatsApp workflow adapter failed; source operation remains committed.', [
            'event_key' => $eventKey,
            'source_type' => $sourceType,
            'source_id' => $sourceId,
            'branch_id' => $branchId,
            'exception' => class_basename($exception),
        ]);
        return ['ok' => false, 'status' => 'error', 'reason' => 'WhatsApp workflow adapter failed.'];
    }
}

// Example: after customer creation commits (adapt real model field names to this ERP):
/*
queueErpWhatsAppWorkflow(
    (int) $customer->branch_id,
    'customer.created',
    '+91' . preg_replace('/\\D+/', '', (string) $customer->cus_mobile),
    [
        'customer_name' => (string) $customer->cus_name,
        'branch_name' => (string) ($branch->branch_name ?? ''),
    ],
    'customer.created',
    (int) $customer->sno,
    (int) (auth()->user()->user_id ?? 0),
    'customer.created:' . (int) $customer->sno
);
*/

// Example: event certificate ready. Configure academy.event_certificate in the Automation rules page.
/*
queueErpWhatsAppWorkflow(
    (int) $branchId,
    'academy.event_certificate',
    (string) $student->whatsapp_e164,
    [
        'student_name' => (string) $student->student_name,
        'event_name' => (string) $event->event_name,
        'certificate_url' => (string) $certificatePublicHttpsUrl,
    ],
    'academy.event_certificate',
    (int) $certificate->id,
    (int) (auth()->user()->user_id ?? 0),
    'academy.event_certificate:' . (int) $certificate->id
);
*/

// Example: scheduled reminder. Use a stable scheduler/business key so each reminder is idempotent.
/*
queueErpWhatsAppWorkflow(
    (int) $branchId,
    'academy.event_reminder',
    (string) $student->whatsapp_e164,
    ['student_name' => $student->student_name, 'event_name' => $event->event_name],
    'academy.event_reminder',
    (int) $eventRegistration->id,
    null,
    'academy.event_reminder:' . (int) $eventRegistration->id . ':' . $event->starts_at->format('Ymd')
);
*/

// Example: free-form reply from an agent action. This is deliberately blocked outside the 24-hour window.
/*
$result = app(WhatsAppManagerService::class)->queueText([
    'branch_id' => (int) $branchId,
    'to' => (string) $contact->phone_e164,
    'text' => (string) $replyText,
    'source_type' => 'agent_chat',
    'created_by' => (int) auth()->user()->user_id,
    'idempotency_key' => 'chat.reply:' . (string) \Illuminate\Support\Str::uuid(),
]);
*/
