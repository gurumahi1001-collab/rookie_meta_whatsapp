# Validation, release gates and known limits

## Checks performed on this package

- PHP CLI syntax checks were run on the new controllers, services, job, table-prefix helper, route file, config file, the patched supplied `ManageLead.php`, and the patched legacy WhatsApp controller. See the final delivery summary for the final whole-tree result.
- The package uses an additive schema; the SQL was inspected for table-name alignment against the prefix helper and service queries. It was **not** executed against a live MySQL/MariaDB schema in this environment.
- The uploaded ERP bundle did not contain `composer.json`, `.env`, a database dump, full middleware configuration or complete deployed source history. Laravel boot tests, Blade compilation, route resolution, queue integration, staging HTTP tests and live Meta API tests could not be run here.
- No test credentials were used and no live WhatsApp message was sent.

## Must-pass staging acceptance tests

1. Verify ordinary users receive 403 and only IDs configured in `WHATSAPP_ADMIN_USER_IDS` can enter WhatsApp Management.
2. Verify a missing `META_APP_SECRET`, missing signature and invalid `X-Hub-Signature-256` are rejected. Valid Meta GET verification must return the challenge as plain text.
3. Verify webhook path is outside the ERP `auth:web` group; CSRF is exempted for only `webhook_whatsapp` while signature validation remains active.
4. Send a message from an internal test account and confirm the correct configured `phone_number_id` resolves branch/session and the inbound message is stored idempotently. Test payloads containing multiple entries, changes, messages and status receipts.
5. Open a conversation after an inbound message and verify free-form text is accepted into the outbox only while the last inbound message is within 24 hours. Simulate an older timestamp and confirm the send is blocked with a log row.
6. Sync Meta templates; verify new imports default to disabled, non-approved templates cannot be enabled, and a send without matching opt-in evidence is blocked.
7. Configure a test workflow such as `lead.created`, save its approved template and parameter map, and verify the ERP business operation succeeds even if WhatsApp is disabled or mapping/consent is missing. Disable the workflow/template/profile and confirm future sends are blocked.
8. Record genuine opt-in evidence; queue one template to the opted-in internal number; confirm progression through queued, processing, sent and actual webhook delivered/read/failed statuses.
9. Test `STOP`, `STOP ALL`, `UNSUBSCRIBE`, `CANCEL`, `END`, `QUIT`, `OPT OUT` and `OPT-OUT` inputs; confirm future sends are blocked until a valid explicit re-opt-in is recorded with evidence.
10. Use both manual recipient input and a saved audience. Include valid-consent, no-consent, opted-out and malformed phone values. Check per-recipient queue/block counts, configured batch cap, pacing, idempotency and campaign logs.
11. Enable the global pause while outbox jobs are waiting and verify worker execution cannot send past the pause. Repeat with a branch profile disabled.
12. Test with your actual DB prefix. Confirm table names are correct, all unique indexes work and query performance is acceptable. Inspect worker logs and failed jobs.
13. Pilot a very small recipient set. Monitor Meta account quality, template quality, messaging limits, failures and complaints before raising volume.

## Functional scope and limits

This package includes: menu-wise admin UI, per-branch Meta API credentials stored encrypted at rest, approved-template sync/toggles, branch-specific event-to-template maps, outbox send pacing/idempotency, global and branch pause controls, sent/delivered/read/failed metrics, signed webhook receipt handling, one-to-one text/history UI, 24-hour free-form guard, consent/opt-out guard, template campaigns, saved ERP recipient lists, and branch-specific feature flags.

It does **not** yet include: complete consumer WhatsApp Web parity; a fully integrated inbound media download/preview and attachment sending UI; every rich message/reaction/sticker/voice-note UI; native group conversation support; publishing to WhatsApp Channels; or implemented Calling API end-to-end. The Groups page manages ERP audiences, not native WhatsApp groups. The Broadcast page is capability-labelled and not a Channels publisher. The Calling page is only a gated capability note; do not enable it for agents until a separately tested, eligible Meta Calling API integration is added.

The bulk UI allows template-level component JSON shared across recipients. A personalised CSV variable import/recipient-specific component map is not part of this phase; implement and test it before sending distinct personalised components to each member of a saved audience.

## Legacy migration warning

The earlier WhatsApp upgrade ZIP contains 105 `sendRequestToWhatsApp` text occurrences across 29 PHP files, some possibly archived copies. The separately supplied `ManageLead.php` is patched for its lead-created welcome, existing manual-template send, and syllabus send paths. That does not prove all active customer, event/certificate, cron, assessment, staff, or other controllers in the live ERP have been migrated. Several remaining legacy senders must be identified against deployed routes/scheduler/jobs and switched to `WhatsAppManagerService::queueWorkflow()` / `queueTemplate()` or `queueText()` before the admin pause, consent checks, pacing, and logs can govern every send.

## Enforcement and delivery caveat

Meta may restrict an app, WABA, phone number, business or template for reasons this code cannot control. No architecture can guarantee that an account will never be blocked. If there is an existing restriction, review Account Quality/Business Support Home and use Meta's approved appeal path; do not treat a replacement app as a way to bypass enforcement. Follow Meta opt-in, approved-template, service-window, quality and volume policies.
