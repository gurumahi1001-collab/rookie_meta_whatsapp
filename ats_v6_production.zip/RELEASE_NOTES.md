# Recruitment ATS v6 Production Release

## Purpose
Production hardening for resume extraction and complete-catalog ATS role matching. Scope is limited to the recruitment ATS path; no unrelated ERP module was rewritten.

## Main corrections
1. Education resolution is now qualification-first and database-master-backed. The resolver evaluates `egc_major` only inside the highest supported qualification level and supports additive alias tables plus ambiguity/manual-review gates.
2. Contact extraction is deterministic. Candidate mobile persistence accepts only canonical Indian 10-digit mobile numbers beginning 6–9.
3. Candidate names are extracted from identity/header context and normalized to title case for display. Labeled names are supported.
4. Gender and marital status are explicit-label only. The system does not infer sensitive attributes from names, religion, photographs, or pronouns.
5. Experience reconstruction supports month/year, year-only, `Present/Current/Now`, excludes internship/trainee/project/training periods, and unions overlapping employment months to prevent double counting.
6. Resume extraction stores field-level provenance/audit evidence.
7. ATS role retrieval is hybrid lexical + embedding retrieval, but the final backend deterministically evaluates every active ATS-enabled role. Semantic top-N only limits the expensive LLM pass.
8. Final match scores enforce mandatory skill, minimum experience, education, evidence, and sparse-profile caps. The LLM cannot override hard backend gates.
9. ATS response/UI now shows semantic, title, skills, experience, responsibility, education, seniority, evidence, coverage, confidence, and complete-catalog metadata.
10. Role catalog loading is schema-aware and no longer requires a non-existent `ai_matching_enabled` column in the supplied role table.

## Files changed
- `app/Services/CandidateServices/ResumeExtractionService.php`
- `app/Services/CandidateServices/RecruitmentAtsPromptService.php`
- `app/Services/CandidateServices/RecruitmentAtsResponseValidator.php`
- `app/Services/CandidateServices/RecruitmentAtsRoleCatalogService.php`
- `app/Services/CandidateServices/RecruitmentAtsRoleMatchingService.php`
- `app/Services/CandidateServices/RecruitmentAtsScoringService.php`
- `app/Services/CandidateServices/RecruitmentAtsResumeSourceService.php`
- `app/Services/CandidateServices/RecruitmentHuggingFaceService.php`
- `app/Services/CandidateServices/RecruitmentRoleRetrievalService.php`
- `app/Services/CandidateServices/RecruitmentEducationCatalogService.php` (new)
- `app/Services/CandidateServices/RecruitmentSkillCatalogService.php` (new)
- `app/Models/ApplicantAtsRoleAnalysisModel.php`
- `app/Models/ApplicantAtsRoleMatchModel.php`
- `app/Models/RecruitmentRoleModel.php`
- `app/Http/Controllers/hr_management/hr_recruiter/JobRequest.php`
- `resources/views/content/hr_management/hr_recruiter/manage_candidate/candidate_list.blade.php`
- `config/recruitment_ats.php` (new)

## SQL
Run `database/recruitment_ats/2026_09_28_recruitment_ats_v6.sql` once against the production database. It is additive: it creates ATS support/alias/provenance tables and adds ATS analysis/match columns/indexes. Existing master IDs and existing ATS rows are not deleted or re-keyed.

## Deployment order
1. Back up the production database.
2. Run the supplied SQL migration.
3. Deploy the PHP/config/Blade files.
4. Add `.env.recruitment-ats.example` values to the real production `.env`, including approved model IDs and the `HF_TOKEN` already used by the application.
5. `php artisan config:clear`
6. `php artisan cache:clear`
7. Restart PHP-FPM/Apache and queue workers.
8. Ensure the `ats-role-matching` queue is running for bulk jobs.
9. Test individual extraction, then controlled bulk matching before reprocessing all candidates.

## Verification performed in this sandbox
- PHP lint passed for all changed PHP files.
- ATS smoke test passed for: name normalization, Indian mobile canonicalization, current-role evidence, and overlapping employment calculation (6.7 years in the synthetic overlap case).

Full Laravel integration/database tests were not executed here because the supplied source does not include the application's installed Composer vendor tree and no MariaDB client/server was available in the sandbox.

## Accuracy policy
The implementation is designed for high-confidence production extraction with deterministic evidence, master-data resolution, independent verification, and manual-review gates. Literal 100% accuracy for arbitrary resumes cannot be honestly guaranteed, especially for unreadable scans, contradictory documents, or genuinely ambiguous master-data mappings.
