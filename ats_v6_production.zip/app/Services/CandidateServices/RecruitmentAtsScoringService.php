<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

/**
 * Deterministic final ATS scorer.
 *
 * The LLM supplies semantic evidence only. The backend computes the final
 * decision and applies hard gates for mandatory skills, experience, and
 * education requirements. A missing fact can therefore never become a pass
 * merely because a model produced a high number.
 */
class RecruitmentAtsScoringService
{
    public function __construct(protected RecruitmentSkillCatalogService $skillCatalog)
    {
    }

    public function score(array $match, array $role, string $resume): array
    {
        $resumeNorm = $this->skillCatalog->normalize($resume);

        $semantic = $this->scoreRange($match['semantic_fit_score'] ?? 0);
        $title = $this->blend($this->scoreRange($match['title_alignment_score'] ?? $semantic), $this->titleScore($resumeNorm, $role));
        $skills = $this->blend($this->scoreRange($match['skill_alignment_score'] ?? $semantic), $this->skillScore($resumeNorm, $role));
        $experience = $this->blend($this->scoreRange($match['experience_alignment_score'] ?? $semantic), $this->experienceScore($resumeNorm, $role));
        $responsibility = $this->blend($this->scoreRange($match['responsibility_alignment_score'] ?? $semantic), $this->responsibilityScore($resumeNorm, $role));
        $seniority = $this->blend($this->scoreRange($match['seniority_alignment_score'] ?? $semantic), $this->seniorityScore($resumeNorm, $role));
        $education = $this->educationScore($resumeNorm, $role);
        $evidence = $this->evidenceScore((array) ($match['evidence'] ?? []), $resumeNorm, $role);

        // 100-point deterministic composite.
        $final = round(
            $semantic * 0.10
            + $title * 0.15
            + $skills * 0.25
            + $experience * 0.20
            + $responsibility * 0.15
            + $seniority * 0.05
            + $evidence * 0.05
            + $education * 0.05,
            2
        );

        $required = $this->list($role['mandatory_skills'] ?? []);
        $mandatoryCoverage = $this->skillCatalog->coverage($resume, $required);

        $minimumYears = $this->minimumYears($role);
        $candidateYears = $this->resumeYears($resume);

        $educationRequirements = $this->list($role['education_requirements'] ?? []);
        $educationRequirementCoverage = $educationRequirements
            ? $this->coverage($this->educationSection($resumeNorm), $educationRequirements)
            : 1.0;

        $sparse = $this->isSparseRole($role);

        // Hard requirement gates.
        if ($required && $mandatoryCoverage < 1.0) {
            $final = min($final, (float) config('recruitment_ats.mandatory_skill_fail_cap', 59));
        }

        if ($minimumYears > 0 && $candidateYears + 0.05 < $minimumYears) {
            $final = min($final, (float) config('recruitment_ats.experience_requirement_fail_cap', 59));
        }

        if ($educationRequirements && $educationRequirementCoverage < 1.0) {
            $final = min($final, (float) config('recruitment_ats.education_requirement_fail_cap', 59));
        }

        if ($evidence < 30) {
            $final = min($final, 69.0);
        }

        if ($sparse) {
            $final = min($final, (float) config('recruitment_ats.sparse_role_score_cap', 82));
        }

        $minScore = (float) config('recruitment_ats.minimum_match_score', 70);
        $nearMin = (float) config('recruitment_ats.near_match_min_score', 45);

        $decision = $final >= $minScore
            ? ($final >= (float) config('recruitment_ats.strong_match_score', 85) ? 'strong_match' : 'match')
            : ($final >= $nearMin ? 'near_match' : 'not_match');

        $gaps = $this->list($match['gaps'] ?? []);

        if ($required && $mandatoryCoverage < 1) {
            $gaps[] = 'Mandatory skill coverage: ' . round($mandatoryCoverage * 100) . '%.';
        }

        if ($minimumYears > 0 && $candidateYears + 0.05 < $minimumYears) {
            $gaps[] = 'Required experience: ' . rtrim(rtrim((string) $minimumYears, '0'), '.') . '+ years; resume evidence: ' . number_format($candidateYears, 1) . ' years.';
        }

        if ($educationRequirements && $educationRequirementCoverage < 1) {
            $gaps[] = 'Education requirement coverage: ' . round($educationRequirementCoverage * 100) . '%.';
        }

        if ($sparse) {
            $gaps[] = 'Role profile is incomplete; the result is capped until approved requirements are entered in Manage Roles.';
        }

        $gaps = array_values(array_unique(array_filter($gaps)));

        $verifiedEvidence = $this->verifiedEvidence((array) ($match['evidence'] ?? []), $resumeNorm);
        $confidence = $this->confidence(
            $semantic,
            $evidence,
            $mandatoryCoverage,
            $educationRequirementCoverage,
            $candidateYears,
            $minimumYears,
            count($verifiedEvidence),
            $sparse
        );

        return [
            'role_id' => (int) ($role['sno'] ?? $role['role_id'] ?? 0),
            'role_code' => (string) ($role['role_code'] ?? ''),
            'role_name' => (string) ($role['role_name'] ?? 'Role'),
            'role_family' => $role['role_family'] ?? null,
            'seniority_level' => (int) ($role['seniority_level'] ?? 1),
            'match_score' => $this->scoreRange($final),
            'decision' => $decision,
            'semantic_fit_score' => $this->scoreRange($semantic),
            'title_alignment_score' => $this->scoreRange($title),
            'skill_alignment_score' => $this->scoreRange($skills),
            'experience_alignment_score' => $this->scoreRange($experience),
            'responsibility_alignment_score' => $this->scoreRange($responsibility),
            'seniority_alignment_score' => $this->scoreRange($seniority),
            'education_alignment_score' => $this->scoreRange($education),
            'evidence_quality_score' => $this->scoreRange($evidence),
            'mandatory_skill_coverage' => round($mandatoryCoverage * 100, 2),
            'education_requirement_coverage' => round($educationRequirementCoverage * 100, 2),
            'candidate_experience_years' => round($candidateYears, 1),
            'required_experience_years' => round($minimumYears, 1),
            'confidence_score' => round($confidence, 2),
            'reason' => $this->buildReason($match, $role, $final, $mandatoryCoverage, $educationRequirementCoverage, $candidateYears, $minimumYears, $sparse),
            'evidence' => $verifiedEvidence,
            'gaps' => $gaps,
            'scoring_version' => config('recruitment_ats.scoring_version', 'ats_scoring.v2'),
        ];
    }

    private function titleScore(string $resume, array $role): float
    {
        $employment = $this->employmentSection($resume);
        $header = substr($resume, 0, 6000);

        $terms = array_merge(
            [$role['role_name'] ?? '', $role['role_family'] ?? ''],
            (array) ($role['aliases'] ?? [])
        );

        $best = 0;
        foreach ($terms as $term) {
            $term = trim((string) $term);
            if ($term === '') continue;

            $phrase = $this->canonical($term);
            if ($phrase !== '' && str_contains($employment, $phrase)) $best = max($best, 100);
            if ($phrase !== '' && str_contains($header, $phrase)) $best = max($best, 95);
            $best = max(
                $best,
                $this->tokenCoverage($phrase, $employment) * 100,
                $this->tokenCoverage($phrase, $header) * 90
            );
        }

        return min(100, $best);
    }

    private function skillScore(string $resume, array $role): float
    {
        $required = $this->list($role['mandatory_skills'] ?? []);
        $preferred = $this->list($role['preferred_skills'] ?? []);

        if (!$required && !$preferred) {
            $fallback = array_merge(
                [$role['role_name'] ?? '', $role['role_family'] ?? ''],
                (array) ($role['aliases'] ?? [])
            );
            return min(100, $this->coverage($resume, $fallback) * 100);
        }

        $req = $required ? $this->skillCatalog->coverage($resume, $required) : 1.0;
        $pref = $preferred ? $this->skillCatalog->coverage($resume, $preferred) : 1.0;

        return min(100, round($req * 75 + $pref * 25, 2));
    }

    private function experienceScore(string $resume, array $role): float
    {
        $years = $this->resumeYears($resume);
        $minimum = $this->minimumYears($role);

        if ($minimum <= 0) return $years > 0 ? 95 : 80;
        if ($years <= 0) return 0;
        if ($years >= $minimum) return 100;

        return round(($years / $minimum) * 100, 2);
    }

    private function responsibilityScore(string $resume, array $role): float
    {
        $parts = array_merge(
            (array) ($role['responsibilities'] ?? []),
            [(string) ($role['description'] ?? '')]
        );

        $parts = array_values(array_filter(
            array_map('strval', $parts),
            fn ($v) => trim($v) !== ''
        ));

        if (!$parts) {
            return $this->tokenCoverage(
                $this->canonical(($role['role_family'] ?? '') . ' ' . ($role['role_name'] ?? '')),
                $resume
            ) * 100;
        }

        $best = 0;
        foreach ($parts as $part) {
            $best = max($best, $this->tokenCoverage($this->canonical($part), $resume));
        }

        return min(100, $best * 100);
    }

    private function educationScore(string $resume, array $role): float
    {
        $requirements = $this->list($role['education_requirements'] ?? []);
        if (!$requirements) return 80.0;

        return $this->coverage($this->educationSection($resume), $requirements) * 100;
    }

    private function seniorityScore(string $resume, array $role): float
    {
        $level = (int) ($role['seniority_level'] ?? 1);
        $years = $this->resumeYears($resume);

        $lead = preg_match(
            '/\b(managed|management|leading|lead|supervised|supervisor|mentored|team\s+lead|manager|head\s+of|director)\b/i',
            $resume
        ) === 1;

        return match (true) {
            $level <= 1 => $years <= 3 && !$lead ? 98 : ($years <= 5 ? 80 : 60),
            $level === 2 => $years >= 2 ? ($years >= 5 || $lead ? 98 : 88) : 45,
            $level === 3 => (($years >= 4 && $lead) ? 98 : ($years >= 4 ? 76 : 38)),
            $level === 4 => (($years >= 6 && $lead) ? 98 : ($years >= 6 ? 72 : 32)),
            default => (($years >= 8 && $lead) ? 98 : ($years >= 8 ? 68 : 25)),
        };
    }

    private function evidenceScore(array $evidence, string $resume, array $role): float
    {
        $verified = $this->verifiedEvidence($evidence, $resume);
        if (!$verified) return 0;

        $roleTokens = $this->tokens($this->roleText($role));
        $relevant = 0;

        foreach ($verified as $line) {
            $relevant += count(array_intersect($this->tokens($line), $roleTokens));
        }

        return min(100, 40 + count($verified) * 15 + $relevant * 4);
    }

    private function verifiedEvidence(array $evidence, string $resume): array
    {
        $out = [];
        $resumeTokens = $this->tokens($resume);

        foreach ($evidence as $line) {
            $line = trim((string) $line);
            if ($line === '' || mb_strlen($line) < 8) continue;

            $norm = $this->canonical($line);

            if (str_contains($resume, $norm)) {
                $out[] = mb_substr($line, 0, 1000);
                continue;
            }

            $tokens = $this->tokens($line);
            if (count($tokens) >= 4 && $this->coverage($resume, $tokens) >= 0.75) {
                $out[] = mb_substr($line, 0, 1000);
            }
        }

        return array_values(array_unique($out));
    }

    private function resumeYears(string $resume): float
    {
        $explicit = 0.0;
        if (preg_match_all(
            '/\b(?:total|overall|professional|relevant)\s+(?:work\s+)?experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\b/i',
            $resume,
            $m
        )) {
            foreach ($m[1] as $v) $explicit = max($explicit, min(60, (float) $v));
        }

        $section = $this->employmentSection($resume);
        $ranges = [];

        foreach (preg_split('/\R+/u', $section) ?: [] as $line) {
            if (preg_match('/\b(intern(?:ship)?|trainee|apprentice|volunteer|student|academic|coursework|training)\b/i', $line)) {
                continue;
            }

            foreach ($this->parseDateRanges($line) as $range) {
                $start = $this->parseMonth($range['start']);
                $end = $this->parseMonth($range['end']);

                if ($start === null || $end === null || $end <= $start) continue;
                if ($end > $this->currentMonthIndex() + 1) continue;

                $ranges[] = [$start, $end];
            }
        }

        $covered = [];
        foreach ($ranges as [$a, $b]) {
            for ($month = $a; $month < $b; $month++) $covered[$month] = true;
        }

        if ($covered) return min(60, round(count($covered) / 12, 1));
        return round($explicit, 1);
    }

    private function minimumYears(array $role): float
    {
        $text = trim((string) ($role['minimum_experience'] ?? ''));
        if ($text === '') return 0;

        return preg_match('/(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)/i', $text, $m)
            ? (float) $m[1]
            : 0.0;
    }

    private function parseDateRanges(string $value): array
    {
        $months = '(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)';
        $date = '(?:' . $months . '\s+\d{4}|\d{1,2}\s*[-\/.]\s*\d{4}|\d{4}\s*[-\/.]\s*\d{1,2}|\d{4})';

        preg_match_all(
            '/(?<start>' . $date . ')\s*(?:-|–|—|to|until|through)\s*(?<end>Present|Current|Now|' . $date . ')/i',
            $value,
            $matches,
            PREG_SET_ORDER
        );

        $out = [];
        foreach ($matches as $match) {
            $out[] = [
                'start' => trim((string) ($match['start'] ?? '')),
                'end' => trim((string) ($match['end'] ?? '')),
            ];
        }

        return $out;
    }

    private function parseMonth(string $value): ?int
    {
        $v = trim($value);
        if ($v === '') return null;

        if (preg_match('/\b(?:present|current|now|till\s+date|to\s+date)\b/i', $v)) {
            return $this->currentMonthIndex();
        }

        $map = [
            'jan'=>1,'january'=>1,'feb'=>2,'february'=>2,'mar'=>3,'march'=>3,
            'apr'=>4,'april'=>4,'may'=>5,'jun'=>6,'june'=>6,'jul'=>7,'july'=>7,
            'aug'=>8,'august'=>8,'sep'=>9,'sept'=>9,'september'=>9,'oct'=>10,
            'october'=>10,'nov'=>11,'november'=>11,'dec'=>12,'december'=>12,
        ];

        if (preg_match('/\b([A-Za-z]+)\s+((?:19|20)\d{2})\b/i', $v, $m)) {
            $month = $map[strtolower($m[1])] ?? null;
            return $month ? ((int) $m[2] * 12 + $month) : null;
        }

        if (preg_match('/\b(\d{1,2})\s*[-\/.]\s*((?:19|20)\d{2})\b/', $v, $m)) {
            return (int) $m[2] * 12 + max(1, min(12, (int) $m[1]));
        }

        if (preg_match('/\b((?:19|20)\d{2})\s*[-\/.]\s*(\d{1,2})\b/', $v, $m)) {
            return (int) $m[1] * 12 + max(1, min(12, (int) $m[2]));
        }

        if (preg_match('/\b((?:19|20)\d{2})\b/', $v, $m)) {
            return (int) $m[1] * 12 + 1;
        }

        return null;
    }

    private function currentMonthIndex(): int
    {
        $now = now();
        return ((int) $now->format('Y')) * 12 + (int) $now->format('n');
    }

    private function employmentSection(string $resume): string
    {
        if (preg_match(
            '/\b(?:work\s+experience|professional\s+experience|employment\s+history|career\s+history|experience)\b(.*?)(?=\b(?:education|academic\s+qualifications?|qualifications?|projects?|certifications?|skills|technical\s+skills|personal\s+details|references)\b|$)/is',
            $resume,
            $m
        )) {
            return trim($m[1]);
        }

        return $resume;
    }

    private function educationSection(string $resume): string
    {
        if (preg_match(
            '/\b(?:education|academic\s+qualifications?|qualifications?)\b(.*?)(?=\b(?:work\s+experience|professional\s+experience|employment\s+history|projects?|certifications?|skills|technical\s+skills|personal\s+details|references)\b|$)/is',
            $resume,
            $m
        )) {
            return trim($m[1]);
        }

        return $resume;
    }

    private function isSparseRole(array $role): bool
    {
        $description = trim((string) ($role['description'] ?? ''));
        return empty($role['mandatory_skills'])
            && empty($role['preferred_skills'])
            && empty($role['responsibilities'])
            && trim((string) ($role['minimum_experience'] ?? '')) === ''
            && empty($role['education_requirements'])
            && ($description === '' || $this->canonical($description) === $this->canonical((string) ($role['role_name'] ?? '')));
    }

    private function roleText(array $role): string
    {
        return implode(' ', array_merge(
            [
                $role['role_name'] ?? '',
                $role['role_family'] ?? '',
                $role['description'] ?? '',
            ],
            (array) ($role['mandatory_skills'] ?? []),
            (array) ($role['preferred_skills'] ?? []),
            (array) ($role['responsibilities'] ?? []),
            (array) ($role['education_requirements'] ?? []),
            (array) ($role['aliases'] ?? [])
        ));
    }

    private function coverage(string $haystack, array|string $needles): float
    {
        if (is_string($needles)) $needles = [$needles];

        $needles = array_values(array_filter(
            array_map(fn ($value) => $this->canonical((string) $value), $needles),
            fn ($value) => $value !== ''
        ));

        if (!$needles) return 0;

        $score = 0;
        foreach ($needles as $needle) {
            if (str_contains($haystack, $needle) || $this->tokenCoverage($needle, $haystack) >= 0.72) {
                $score++;
            }
        }

        return $score / count($needles);
    }

    private function tokenCoverage(string $needle, string $haystack): float
    {
        $nt = $this->tokens($needle);
        $ht = $this->tokens($haystack);
        if (!$nt) return 0;

        return count(array_intersect($nt, $ht)) / max(1, count($nt));
    }

    private function tokens(string $text): array
    {
        preg_match_all('/[a-z0-9]+/i', strtolower($this->canonical($text)), $m);

        $stop = [
            'and','the','for','with','from','into','this','that','role','job','position','candidate',
            'years','year','of','in','to','a','an','on','at','as','or','is','be','by','our','your',
            'company','work','working','experience','required','preferred','skills',
        ];

        return array_values(array_unique(array_filter(
            $m[0] ?? [],
            fn ($x) => strlen($x) >= 2 && !in_array($x, $stop, true)
        )));
    }

    private function normalize(string $text): string
    {
        return $this->canonical($text);
    }

    private function canonical(string $text): string
    {
        $text = mb_strtolower(strip_tags($text), 'UTF-8');
        $text = str_replace(['&','/','\\','-','_','.','(',')',',',':','|',';'], ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        return trim($text);
    }

    private function list(mixed $value): array
    {
        if (is_array($value)) {
            return array_values(array_filter(array_map(
                fn ($v) => trim((string) $v),
                $value
            )));
        }

        $value = trim((string) ($value ?? ''));
        if ($value === '') return [];

        $decoded = json_decode($value, true);
        if (is_array($decoded)) {
            return array_values(array_filter(array_map('strval', $decoded)));
        }

        return array_values(array_filter(array_map(
            'trim',
            preg_split('/[,;\n]+/', $value)
        )));
    }

    private function blend(float $a, float $b): float
    {
        return ($a * 0.40) + ($b * 0.60);
    }

    private function scoreRange(mixed $value): float
    {
        return max(0, min(100, round((float) $value, 2)));
    }

    private function confidence(
        float $semantic,
        float $evidence,
        float $mandatoryCoverage,
        float $educationCoverage,
        float $candidateYears,
        float $minimumYears,
        int $evidenceCount,
        bool $sparseRole
    ): float {
        $confidence = 0;
        $confidence += $semantic * 0.25;
        $confidence += $evidence * 0.25;
        $confidence += $mandatoryCoverage * 100 * 0.20;
        $confidence += $educationCoverage * 100 * 0.10;
        $confidence += ($candidateYears > 0 ? 100 : 50) * 0.10;
        $confidence += ($evidenceCount >= 2 ? 100 : ($evidenceCount === 1 ? 70 : 30)) * 0.10;

        if ($sparseRole) $confidence = min($confidence, 75);
        if ($minimumYears > 0 && $candidateYears + 0.05 < $minimumYears) $confidence = min($confidence, 60);

        return min(100, max(0, $confidence));
    }

    private function buildReason(
        array $match,
        array $role,
        float $score,
        float $mandatoryCoverage,
        float $educationCoverage,
        float $candidateYears,
        float $minimumYears,
        bool $sparse
    ): string {
        $parts = [];

        $ai = trim((string) ($match['reason'] ?? ''));
        if ($ai !== '') $parts[] = $ai;

        $parts[] = 'Backend verified evidence against the candidate resume.';
        $parts[] = 'Mandatory skills: ' . round($mandatoryCoverage * 100) . '%.';

        if ($minimumYears > 0) {
            $parts[] = 'Experience: ' . number_format($candidateYears, 1) . ' / ' . number_format($minimumYears, 1) . ' required years.';
        }

        if (!empty($role['education_requirements'])) {
            $parts[] = 'Education requirement coverage: ' . round($educationCoverage * 100) . '%.';
        }

        if ($sparse) {
            $parts[] = 'Role profile is sparse; score is capped until the role requirements are completed.';
        }

        return mb_substr(implode(' ', $parts), 0, 1800);
    }
}
