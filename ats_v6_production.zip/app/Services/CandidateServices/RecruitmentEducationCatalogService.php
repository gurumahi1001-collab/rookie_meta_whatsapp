<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Throwable;

/**
 * Recruitment education entity resolver.
 *
 * The applicant table keeps the existing egc_major/egc_qualification_level IDs.
 * This service adds a deterministic entity-resolution layer so resume text is
 * NEVER mapped to an arbitrary master row by plain free-text similarity.
 *
 * Rules:
 *  - qualification level comes from the highest supported education entry;
 *  - major rows are considered only inside the resolved qualification level;
 *  - exact/full-program matches beat specialization-only matches;
 *  - ambiguous mappings return major_sno = null and retain major_text for review;
 *  - inactive/deleted master records can never be selected.
 */
class RecruitmentEducationCatalogService
{
    private const CACHE_KEY = 'egc:recruitment:education-catalog:v2';
    private const CACHE_MINUTES = 15;

    public function resolve(string $resumeText, array $aiEntries, array $localEducation): array
    {
        $catalog = $this->catalog();

        $entries = $this->normalizeEntries($aiEntries, $resumeText);
        $entries = array_merge(
            $entries,
            $this->deterministicEntries($localEducation, $resumeText)
        );

        $entries = $this->deduplicateEntries($entries);
        if (!$entries) {
            return [
                'qualification_sno' => null,
                'major_sno' => null,
                'major_text' => null,
                'degree_full' => null,
                'major_score' => 0,
                'qualification_score' => 0,
                'evidence' => '',
                'major_evidence' => '',
                'entries' => [],
                'resolution_status' => 'not_found',
                'candidates' => [],
            ];
        }

        foreach ($entries as &$entry) {
            $resolved = $this->resolveEntry($entry, $catalog);
            $entry['resolved'] = $resolved;
        }
        unset($entry);

        usort($entries, function (array $a, array $b): int {
            $ar = (int) data_get($a, 'resolved.level_rank', 0);
            $br = (int) data_get($b, 'resolved.level_rank', 0);
            if ($ar !== $br) return $br <=> $ar;

            $ay = $this->completionYear((string) ($a['year'] ?? ''));
            $by = $this->completionYear((string) ($b['year'] ?? ''));
            if ($ay !== $by) return $by <=> $ay;

            $as = (float) data_get($a, 'resolved.final_score', 0);
            $bs = (float) data_get($b, 'resolved.final_score', 0);
            return $bs <=> $as;
        });

        $chosen = $entries[0];
        $resolved = (array) ($chosen['resolved'] ?? []);

        return [
            'qualification_sno' => $resolved['qualification_sno'] ?? null,
            'major_sno' => $resolved['major_sno'] ?? null,
            'major_text' => $this->nullable($chosen['major'] ?? null),
            'degree_full' => $this->nullable($chosen['degree_title'] ?? null),
            'major_score' => (int) round(((float) ($resolved['major_score'] ?? 0)) * 100),
            'qualification_score' => (int) round(((float) ($resolved['qualification_score'] ?? 0)) * 100),
            'evidence' => trim((string) ($chosen['evidence'] ?? $chosen['degree_title'] ?? '')),
            'major_evidence' => trim((string) ($chosen['evidence'] ?? $chosen['major'] ?? '')),
            'entries' => array_map(function (array $entry): array {
                unset($entry['resolved']);
                return $entry;
            }, $entries),
            'resolution_status' => (string) ($resolved['resolution_status'] ?? 'manual_review'),
            'candidates' => (array) ($resolved['candidates'] ?? []),
        ];
    }

    private function catalog(): array
    {
        return Cache::remember(self::CACHE_KEY, now()->addMinutes(self::CACHE_MINUTES), function (): array {
            try {
                $levels = DB::table('egc_qualification_level')
                    ->where('status', 0)
                    ->orderBy('sno')
                    ->get(['sno', 'qualification_level_name', 'description']);

                $majors = DB::table('egc_major')
                    ->where('status', 0)
                    ->orderBy('sno')
                    ->get(['sno', 'qualification_id', 'major_name', 'description', 'updated_at']);

                $aliases = [];
                $qualificationAliases = [];
                try {
                    $rows = DB::table('egc_recruitment_major_aliases')
                        ->where('status', 0)
                        ->where('match_enabled', 1)
                        ->orderBy('sno')
                        ->get(['major_sno', 'qualification_id', 'alias_name', 'alias_type']);

                    foreach ($rows as $row) {
                        $majorId = (int) $row->major_sno;
                        $alias = trim((string) $row->alias_name);
                        if ($majorId > 0 && $alias !== '') {
                            $aliases[$majorId][] = [
                                'name' => $alias,
                                'type' => (int) ($row->alias_type ?? 0),
                            ];
                        }
                    }
                } catch (Throwable) {
                    // Optional additive table.
                }

                try {
                    $rows = DB::table('egc_recruitment_qualification_aliases')
                        ->where('status', 0)
                        ->where('match_enabled', 1)
                        ->orderBy('sno')
                        ->get(['qualification_sno', 'alias_name', 'alias_type']);

                    foreach ($rows as $row) {
                        $qualificationId = (int) $row->qualification_sno;
                        $alias = trim((string) $row->alias_name);
                        if ($qualificationId > 0 && $alias !== '') {
                            $qualificationAliases[$qualificationId][] = [
                                'name' => $alias,
                                'type' => (int) ($row->alias_type ?? 0),
                            ];
                        }
                    }
                } catch (Throwable) {
                    // Optional additive table.
                }

                return [
                    'levels' => $levels->map(fn ($row) => [
                        'sno' => (int) $row->sno,
                        'name' => trim((string) $row->qualification_level_name),
                        'rank' => $this->levelRank((string) $row->qualification_level_name),
                        'aliases' => array_values($qualificationAliases[(int) $row->sno] ?? []),
                    ])->values()->all(),
                    'majors' => $majors->map(fn ($row) => [
                        'sno' => (int) $row->sno,
                        'qualification_id' => (int) $row->qualification_id,
                        'name' => trim((string) $row->major_name),
                        'description' => trim((string) ($row->description ?? '')),
                        'updated_at' => (string) ($row->updated_at ?? ''),
                        'aliases' => array_values($aliases[(int) $row->sno] ?? []),
                    ])->values()->all(),
                ];
            } catch (Throwable) {
                return ['levels' => [], 'majors' => []];
            }
        });
    }

    private function resolveEntry(array $entry, array $catalog): array
    {
        $degree = trim((string) ($entry['degree_title'] ?? ''));
        $levelText = trim((string) ($entry['qualification_level'] ?? ''));
        $major = trim((string) ($entry['major'] ?? ''));

        $target = trim(preg_replace('/\s+/u', ' ', $degree . ' ' . $major) ?? '');
        $targetNorm = $this->canonical($target);
        $explicitLevel = $this->levelKey($levelText . ' ' . $degree);
        $targetLevelRank = $this->levelRank($explicitLevel);

        $levelCandidates = [];
        foreach ($catalog['levels'] as $level) {
            $score = $this->levelSimilarity($explicitLevel, (string) $level['name'], $degree);
            foreach ((array) ($level['aliases'] ?? []) as $alias) {
                $aliasText = $this->canonical((string) ($alias['name'] ?? ''));
                if ($aliasText === '') continue;
                if ($this->canonical($degree) === $aliasText || str_contains($this->canonical($degree), $aliasText)) {
                    $score = max($score, ((int) ($alias['type'] ?? 0)) === 1 ? 0.995 : 0.999);
                }
            }
            if ($score > 0) {
                $levelCandidates[] = ['row' => $level, 'score' => $score];
            }
        }

        usort($levelCandidates, fn ($a, $b) => $b['score'] <=> $a['score']);
        $bestLevel = $levelCandidates[0]['row'] ?? null;
        $qualificationScore = $levelCandidates[0]['score'] ?? 0.0;

        $qualificationId = $bestLevel['sno'] ?? null;
        $levelRank = $bestLevel['rank'] ?? $targetLevelRank;

        // Stronger level evidence from a specific degree prefix wins.
        if ($targetLevelRank > 0) {
            foreach ($catalog['levels'] as $level) {
                if ($this->levelRank((string) $level['name']) === $targetLevelRank) {
                    $qualificationId = (int) $level['sno'];
                    $levelRank = $targetLevelRank;
                    $qualificationScore = max($qualificationScore, 0.95);
                    break;
                }
            }
        }

        $candidateRows = array_values(array_filter(
            $catalog['majors'],
            fn (array $row): bool =>
                !$qualificationId || (int) $row['qualification_id'] === (int) $qualificationId
        ));

        $scored = [];
        foreach ($candidateRows as $row) {
            $score = $this->majorScore($degree, $major, $targetNorm, $row);
            if ($score <= 0) continue;
            $scored[] = [
                'sno' => (int) $row['sno'],
                'name' => $row['name'],
                'qualification_id' => (int) $row['qualification_id'],
                'updated_at' => (string) ($row['updated_at'] ?? ''),
                'score' => round($score, 4),
            ];
        }

        usort($scored, function (array $a, array $b): int {
            $scoreCompare = (float) $b['score'] <=> (float) $a['score'];
            if ($scoreCompare !== 0) return $scoreCompare;

            // Duplicate master records with the same canonical programme should
            // resolve deterministically to the most recently updated record.
            $aUpdated = strtotime((string) ($a['updated_at'] ?? '')) ?: 0;
            $bUpdated = strtotime((string) ($b['updated_at'] ?? '')) ?: 0;
            if ($aUpdated !== $bUpdated) return $bUpdated <=> $aUpdated;

            return (int) $b['sno'] <=> (int) $a['sno'];
        });
        $best = $scored[0] ?? null;
        $second = $scored[1] ?? null;

        $ambiguousMargin = (float) config('recruitment_ats.education_ambiguity_margin', 0.08);
        $minMajor = (float) config('recruitment_ats.education_min_major_score', 0.88);
        $isAmbiguous = $best
            && $second
            && ((float) $best['score'] - (float) $second['score']) < $ambiguousMargin;

        $majorId = null;
        $status = 'manual_review';

        if ($best && (float) $best['score'] >= $minMajor && !$isAmbiguous) {
            $majorId = (int) $best['sno'];
            $status = 'resolved';
        } elseif ($best && (float) $best['score'] >= 0.98 && !$second) {
            $majorId = (int) $best['sno'];
            $status = 'resolved';
        } elseif (!$best) {
            $status = 'qualification_only';
        }

        return [
            'qualification_sno' => $qualificationId ? (int) $qualificationId : null,
            'qualification_score' => min(1, $qualificationScore),
            'major_sno' => $majorId,
            'major_score' => (float) ($best['score'] ?? 0),
            'final_score' => max((float) $qualificationScore, (float) ($best['score'] ?? 0)),
            'level_rank' => (int) $levelRank,
            'resolution_status' => $status,
            'candidates' => array_slice($scored, 0, 5),
        ];
    }

    private function majorScore(string $degree, string $major, string $targetNorm, array $row): float
    {
        $nameNorm = $this->canonical((string) $row['name']);
        $descNorm = $this->canonical((string) $row['description']);
        $fullDegreeNorm = $this->canonical($degree);
        $majorNorm = $this->canonical($major);

        if ($fullDegreeNorm !== '' && $fullDegreeNorm === $nameNorm) return 1.0;
        if ($targetNorm !== '' && $targetNorm === $nameNorm) return 1.0;

        foreach ((array) $row['aliases'] as $alias) {
            $aliasNorm = $this->canonical((string) ($alias['name'] ?? ''));
            if ($aliasNorm === '') continue;
            if ($fullDegreeNorm === $aliasNorm || $targetNorm === $aliasNorm || $majorNorm === $aliasNorm) {
                return ((int) ($alias['type'] ?? 0)) === 1 ? 0.995 : 0.999;
            }
        }

        $score = 0.0;
        if ($fullDegreeNorm !== '' && $nameNorm !== '') {
            $score = max($score, $this->stringSimilarity($fullDegreeNorm, $nameNorm) * 0.92);
        }
        if ($majorNorm !== '') {
            $specialization = $this->stripDegreeTokens($nameNorm);
            if ($specialization !== '') {
                $majorMatch = $this->tokenSimilarity($majorNorm, $specialization);
                $score = max($score, $majorMatch * 0.80);
            }
        }
        if ($descNorm !== '' && $targetNorm !== '') {
            $score = max($score, $this->tokenSimilarity($targetNorm, $descNorm) * 0.65);
        }

        return min(1, $score);
    }

    private function deterministicEntries(array $localEducation, string $resumeText): array
    {
        $degree = trim((string) ($localEducation['degree_full'] ?? ''));
        $major = trim((string) ($localEducation['major_text'] ?? ''));
        if ($degree === '' && $major === '') return [];

        return [[
            'degree_title' => $degree,
            'qualification_level' => $this->levelKey($degree),
            'major' => $major,
            'institution' => '',
            'year' => $this->findNearestYear($degree . ' ' . $major, $resumeText),
            'evidence' => $this->educationEvidence($degree, $major, $resumeText),
        ]];
    }

    private function normalizeEntries(array $entries, string $resumeText): array
    {
        $out = [];
        foreach ($entries as $entry) {
            if (!is_array($entry)) continue;

            $degree = trim((string) ($entry['degree_title'] ?? ''));
            $major = trim((string) ($entry['major'] ?? ''));
            $evidence = trim((string) ($entry['evidence'] ?? ''));

            if ($degree === '' && $major === '' && $evidence === '') continue;
            if ($evidence !== '' && !$this->evidenceExists($evidence, $resumeText)) continue;

            $out[] = [
                'degree_title' => $degree,
                'qualification_level' => trim((string) ($entry['qualification_level'] ?? '')),
                'major' => $major,
                'institution' => trim((string) ($entry['institution'] ?? '')),
                'year' => trim((string) ($entry['year'] ?? '')),
                'evidence' => $evidence !== '' ? $evidence : trim($degree . ' ' . $major),
            ];
        }
        return $out;
    }

    private function deduplicateEntries(array $entries): array
    {
        $seen = [];
        $out = [];
        foreach ($entries as $entry) {
            $key = $this->canonical(
                (string) ($entry['degree_title'] ?? '') . '|' .
                (string) ($entry['major'] ?? '') . '|' .
                (string) ($entry['institution'] ?? '') . '|' .
                (string) ($entry['year'] ?? '')
            );
            if ($key === '' || isset($seen[$key])) continue;
            $seen[$key] = true;
            $out[] = $entry;
        }
        return $out;
    }

    private function educationEvidence(string $degree, string $major, string $text): string
    {
        $needle = trim($degree . ' ' . $major);
        if ($needle === '') return '';
        $canonicalText = $this->canonical($text);
        $canonicalNeedle = $this->canonical($needle);
        if ($canonicalNeedle !== '' && str_contains($canonicalText, $canonicalNeedle)) {
            $position = stripos($canonicalText, $canonicalNeedle);
            if ($position !== false) return mb_substr($text, max(0, $position - 80), mb_strlen($needle) + 180);
        }

        foreach (preg_split('/\R+/u', $text) ?: [] as $line) {
            if ($this->tokenSimilarity($canonicalNeedle, $this->canonical($line)) >= 0.75) {
                return trim($line);
            }
        }
        return $needle;
    }

    private function findNearestYear(string $needle, string $text): string
    {
        if ($needle === '') return '';
        foreach (preg_split('/\R+/u', $text) ?: [] as $line) {
            if ($this->tokenSimilarity($this->canonical($needle), $this->canonical($line)) < 0.55) continue;
            if (preg_match('/\b(?:19|20)\d{2}\b/', $line, $m)) return $m[0];
        }
        return '';
    }

    private function completionYear(string $year): int
    {
        $years = [];
        if (preg_match_all('/\b(?:19|20)\d{2}\b/', $year, $m)) {
            foreach ($m[0] as $v) $years[] = (int) $v;
        }
        return $years ? max($years) : 0;
    }

    private function levelKey(string $value): string
    {
        $u = $this->canonical($value);
        if ($u === '') return '';
        if (preg_match('/\bPHD\b|\bDOCTORATE\b|DOCTOR OF PHILOSOPHY/', $u)) return 'Doctorate';
        if (preg_match('/\bMASTER\b|\bM\s*TECH\b|\bM\s*E\b|\bMSC\b|\bMBA\b|\bMCA\b|\bM\s*COM\b|\bM\s*A\b|\bLL\s*M\b/', $u)) return 'PG';
        if (preg_match('/\bDIPLOMA\b/', $u)) return 'Diploma';
        if (preg_match('/\bBACHELOR\b|\bB\s*TECH\b|\bB\s*E\b|\bBSC\b|\bBCA\b|\bBCOM\b|\bB\s*A\b|\bBBA\b|\bMBBS\b|\bB\s*PHARM\b|\bB\s*ARCH\b|\bB\s*ED\b|\bLL\s*B\b/', $u)) return 'UG';
        if (preg_match('/\bHSC\b|\bHIGHER SECONDARY\b|\bPLUS TWO\b|\b12TH\b/', $u)) return 'HSC';
        if (preg_match('/\bSSLC\b|\bSECONDARY\b|\b10TH\b/', $u)) return 'SSLC';
        return '';
    }

    private function levelSimilarity(string $key, string $dbName, string $degree): float
    {
        $dbKey = $this->canonical($dbName);
        $candidate = $this->canonical($key . ' ' . $degree);

        $rankA = $this->levelRank($key);
        $rankB = $this->levelRank($dbName);

        if ($rankA > 0 && $rankA === $rankB) return 0.99;
        if (str_contains($candidate, $dbKey) || str_contains($dbKey, $candidate)) return 0.95;
        return $this->tokenSimilarity($candidate, $dbKey) * 0.90;
    }

    private function levelRank(string $value): int
    {
        $u = $this->canonical($value);
        return match (true) {
            preg_match('/\bPHD\b|\bDOCTORATE\b|DOCTOR OF PHILOSOPHY/', $u) => 70,
            preg_match('/\bPG\b|\bMASTER\b|\bM\s*TECH\b|\bM\s*E\b|\bMSC\b|\bMBA\b|\bMCA\b|\bM\s*COM\b|\bM\s*A\b|\bLL\s*M\b/', $u) => 60,
            preg_match('/\bUG\b|\bBACHELOR\b|\bB\s*TECH\b|\bB\s*E\b|\bBSC\b|\bBCA\b|\bBCOM\b|\bB\s*A\b|\bBBA\b|\bMBBS\b|\bB\s*PHARM\b|\bB\s*ARCH\b|\bB\s*ED\b|\bLL\s*B\b/', $u) => 50,
            preg_match('/\bDIPLOMA\b/', $u) => 40,
            preg_match('/\bHSC\b|\bHIGHER SECONDARY\b|\bPLUS TWO\b|\b12TH\b/', $u) => 20,
            preg_match('/\bSSLC\b|\bSECONDARY\b|\b10TH\b/', $u) => 10,
            preg_match('/\bBELOW SSLC\b/', $u) => 5,
            default => 0,
        };
    }

    private function stripDegreeTokens(string $value): string
    {
        $value = preg_replace(
            '/\b(?:BACHELOR|MASTER|DOCTORATE|DOCTOR OF PHILOSOPHY|B\s*TECH|B\s*E|BSC|BCA|BCOM|B\s*A|BBA|MBBS|B\s*PHARM|B\s*ARCH|B\s*ED|LL\s*B|M\s*TECH|M\s*E|MSC|MBA|MCA|M\s*COM|M\s*A|LL\s*M|DIPLOMA|HSC|SSLC|UG|PG)\b/i',
            ' ',
            $value
        ) ?? $value;

        return trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
    }

    private function tokenSimilarity(string $a, string $b): float
    {
        $aTokens = $this->tokens($a);
        $bTokens = $this->tokens($b);
        if (!$aTokens || !$bTokens) return 0;
        $intersection = count(array_intersect($aTokens, $bTokens));
        return $intersection / max(1, count($aTokens));
    }

    private function stringSimilarity(string $a, string $b): float
    {
        if ($a === '' || $b === '') return 0;
        if ($a === $b) return 1.0;
        similar_text($a, $b, $percent);
        return max(
            0.0,
            min(1.0, $percent / 100)
        );
    }

    private function evidenceExists(string $evidence, string $text): bool
    {
        $e = $this->canonical($evidence);
        $t = $this->canonical($text);
        if ($e !== '' && str_contains($t, $e)) return true;

        $tokens = $this->tokens($evidence);
        if (count($tokens) < 3) return false;

        return $this->tokenSimilarity($e, $t) >= 0.65;
    }

    private function tokens(string $text): array
    {
        preg_match_all('/[\p{L}\p{N}]+/u', $this->canonical($text), $m);
        $stop = [
            'and','the','for','with','from','into','this','that','of','in','to','a','an',
            'on','at','as','or','is','be','by','my','degree','university','college',
            'school','higher','education','qualification','master','bachelor'
        ];

        return array_values(array_unique(array_filter(
            $m[0] ?? [],
            fn ($v) => mb_strlen($v) >= 2 && !in_array($v, $stop, true)
        )));
    }

    private function canonical(string $text): string
    {
        $text = mb_strtoupper(strip_tags($text), 'UTF-8');
        $text = str_replace(['&', '/', '\\', '-', '–', '—', '.', ',', '(', ')', ':', '|', '_'], ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;

        $aliases = [
            'COMPUTER SCIENCE AND ENGINEERING' => 'COMPUTER SCIENCE ENGINEERING',
            'ELECTRONICS AND COMMUNICATION ENGINEERING' => 'ELECTRONICS COMMUNICATION ENGINEERING',
            'ELECTRICAL AND ELECTRONICS ENGINEERING' => 'ELECTRICAL ELECTRONICS ENGINEERING',
            'INFORMATION TECHNOLOGY' => 'INFORMATION TECHNOLOGY',
            'ARTIFICAL INTELLIGENCE' => 'ARTIFICIAL INTELLIGENCE',
            'MASTER OF BUSINESS ADMINSTRATION' => 'MASTER OF BUSINESS ADMINISTRATION',
        ];
        foreach ($aliases as $from => $to) {
            $text = str_replace($from, $to, $text);
        }

        return trim($text);
    }

    private function nullable(mixed $value): ?string
    {
        $value = trim((string) ($value ?? ''));
        return $value === '' ? null : $value;
    }
}
