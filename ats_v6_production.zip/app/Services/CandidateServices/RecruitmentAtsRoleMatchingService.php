<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use App\Models\ApplicantAtsRoleAnalysisModel;
use App\Models\ApplicantAtsRoleMatchModel;
use App\Models\ApplicantModel;
use App\Models\ApplicantResumeExtractionModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Canonical recruitment ATS engine.
 *
 * Flow:
 * 1. Resolve and fingerprint the candidate resume.
 * 2. Load every active role from the company role catalogue.
 * 3. Hybrid retrieval evaluates the complete active role set; only the most
 *    relevant roles are sent to the LLM to control cost/context size.
 * 4. The LLM supplies semantic evidence only.
 * 5. The backend recomputes the deterministic final score and hard gates.
 * 6. Roles omitted by the LLM can still receive a conservative deterministic
 *    near-match result, so output is not dependent on a model returning every role.
 * 7. Persist a versioned analysis tied to resume and role-catalog hashes.
 */
class RecruitmentAtsRoleMatchingService
{
    public function __construct(
        protected RecruitmentAtsRoleCatalogService $roleCatalog,
        protected RecruitmentAtsResumeSourceService $resumeSource,
        protected RecruitmentRoleRetrievalService $retrieval,
        protected RecruitmentAtsPromptService $prompt,
        protected RecruitmentAtsResponseValidator $validator,
        protected RecruitmentHuggingFaceService $huggingFace,
        protected RecruitmentAtsScoringService $scorer,
    ) {
    }

    public function analyzeApplicant(
        ApplicantModel $applicant,
        array $sourceOverride = [],
        ?int $runSno = null,
        int $actorId = 0,
        bool $persistResume = false
    ): array {
        if ((int) $applicant->status === 2) {
            return ['status' => false, 'message' => 'Applicant is not eligible for ATS role matching.'];
        }

        try {
            $source = $this->resumeSource->resolve($applicant, $sourceOverride);
            $roles = $this->roleCatalog->getActiveRoles();
            if (!$roles) {
                return ['status' => false, 'message' => 'No active ATS-enabled recruitment roles are configured.'];
            }

            $catalogHash = $this->roleCatalog->getCatalogHash($roles);
            $this->resumeSource->persistResumeHash($applicant, $source['resume_sha256']);

            if ($persistResume
                && ($sourceOverride['source_type'] ?? RecruitmentAtsResumeSourceService::SOURCE_STORED)
                    !== RecruitmentAtsResumeSourceService::SOURCE_STORED
            ) {
                $applicant->resume_text = $source['text'];
                $applicant->save();
            }

            $candidateRoles = $this->retrieval->retrieve(
                $source['text'],
                (int) config('recruitment_ats.role_retrieval_limit', 24)
            );
            if (!$candidateRoles) {
                $candidateRoles = array_slice($roles, 0, (int) config('recruitment_ats.role_retrieval_limit', 24));
            }

            $payload = [[
                'sno' => (string) $applicant->sno,
                'resume' => $this->resumeSource->prepareForModel($source['text']),
                'roles' => $this->roleCatalog->toCompactPromptPayload($candidateRoles),
            ]];

            $result = $this->runSemanticStage(
                $payload,
                [(string) $applicant->sno],
                $candidateRoles,
                [(string) $applicant->sno => $source['text']]
            );

            // HF may be temporarily unavailable. Keep ATS available through a
            // conservative deterministic path instead of failing persistence.
            if (!$result) {
                $result = $this->deterministicResult($roles, $source['text']);
            } else {
                $result = $this->mergeDeterministicCoverage($result, $roles, $source['text']);
            }

            if (!$result) {
                return [
                    'status' => false,
                    'message' => 'The ATS pipeline could not produce a usable evidence-backed analysis for this candidate.',
                ];
            }

            $analysis = $this->persistResult(
                $applicant,
                $result,
                $source,
                $roles,
                $runSno,
                $actorId,
                $catalogHash,
                $candidateRoles
            );

            return [
                'status' => true,
                'message' => 'ATS role matching completed successfully.',
                'data' => $this->formatAnalysis($applicant, $analysis, $source),
            ];
        } catch (Throwable $e) {
            Log::error('Recruitment ATS individual analysis failed.', [
                'applicant_sno' => $applicant->sno,
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return [
                'status' => false,
                'message' => $e->getMessage(),
            ];
        }
    }

    public function analyzeApplicantsByIds(
        array $applicantIds,
        int $runSno,
        bool $forceReprocess,
        int $actorId = 0
    ): array {
        $ids = array_values(array_unique(array_map('intval', $applicantIds)));
        if (!$ids) return [];

        $applicants = ApplicantModel::query()
            ->whereIn('sno', $ids)
            ->where('status', '!=', 2)
            ->orderBy('sno')
            ->get();

        $roles = $this->roleCatalog->getActiveRoles();
        if (!$roles) {
            return collect($ids)->mapWithKeys(fn ($id) => [
                (string) $id => ['status' => false, 'message' => 'No active ATS-enabled roles configured.'],
            ])->all();
        }

        $catalogHash = $this->roleCatalog->getCatalogHash($roles);
        $payload = [];
        $sources = [];
        $candidateRoleSets = [];
        $results = [];

        foreach ($applicants as $applicant) {
            $id = (string) $applicant->sno;

            try {
                $source = $this->resumeSource->resolve($applicant);
                $this->resumeSource->persistResumeHash($applicant, $source['resume_sha256']);

                if (!$forceReprocess && $this->hasCurrentAnalysis($applicant, $catalogHash, $source['resume_sha256'])) {
                    $results[$id] = [
                        'status' => true,
                        'skipped' => true,
                        'message' => 'Candidate already has a current ATS analysis.',
                    ];
                    continue;
                }

                $candidateRoles = $this->retrieval->retrieve(
                    $source['text'],
                    (int) config('recruitment_ats.role_retrieval_limit', 24)
                );
                if (!$candidateRoles) {
                    $candidateRoles = array_slice($roles, 0, (int) config('recruitment_ats.role_retrieval_limit', 24));
                }

                $payload[] = [
                    'sno' => $id,
                    'resume' => $this->resumeSource->prepareForModel($source['text']),
                    'roles' => $this->roleCatalog->toCompactPromptPayload($candidateRoles),
                ];
                $sources[$id] = $source;
                $candidateRoleSets[$id] = $candidateRoles;
            } catch (Throwable $e) {
                $results[$id] = ['status' => false, 'message' => $e->getMessage()];
            }
        }

        if (!$payload) return $results;

        $aiResults = $this->validateSemanticBatch($payload, $candidateRoleSets, $sources);

        foreach ($payload as $item) {
            $id = (string) $item['sno'];
            if (($results[$id]['skipped'] ?? false) === true) continue;

            $applicant = $applicants->firstWhere('sno', (int) $id);
            $source = $sources[$id] ?? null;
            $candidateRoles = $candidateRoleSets[$id] ?? [];
            $result = $aiResults[$id] ?? null;

            if ($result) {
                $result = $this->mergeDeterministicCoverage($result, $roles, (string) ($source['text'] ?? ''));
            } else {
                $result = $this->deterministicResult($roles, (string) ($source['text'] ?? ''));
            }

            if (!$result || !$applicant || !$source) {
                $results[$id] = [
                    'status' => false,
                    'message' => 'ATS could not produce a usable analysis for this candidate.',
                ];
                continue;
            }

            try {
                $saved = $this->persistResult(
                    $applicant,
                    $result,
                    $source,
                    $roles,
                    $runSno,
                    $actorId,
                    $catalogHash,
                    $candidateRoles
                );

                $results[$id] = [
                    'status' => true,
                    'analysis_sno' => (int) $saved->sno,
                    'match_count' => (int) $saved->match_count,
                    'best_match_score' => (float) $saved->best_role_score,
                ];
            } catch (Throwable $e) {
                Log::error('ATS analysis persistence failed.', [
                    'applicant_sno' => $id,
                    'message' => $e->getMessage(),
                ]);
                $results[$id] = ['status' => false, 'message' => 'Unable to persist ATS analysis.'];
            }
        }

        return $results;
    }

    public function getStoredAnalysis(ApplicantModel $applicant): ?ApplicantAtsRoleAnalysisModel
    {
        return ApplicantAtsRoleAnalysisModel::query()->where('applicant_sno', $applicant->sno)->first();
    }

    public function isAnalysisCurrent(ApplicantModel $applicant, ?ApplicantAtsRoleAnalysisModel $analysis = null): bool
    {
        $analysis ??= $this->getStoredAnalysis($applicant);
        if (!$analysis) return false;

        try {
            $source = $this->resumeSource->resolve($applicant);
            $roles = $this->roleCatalog->getActiveRoles();
            $hash = $this->roleCatalog->getCatalogHash($roles);

            return (string) $analysis->role_catalog_hash === (string) $hash
                && (string) $analysis->resume_sha256 === (string) $source['resume_sha256'];
        } catch (Throwable) {
            return false;
        }
    }

    public function formatStoredAnalysis(ApplicantModel $applicant, ApplicantAtsRoleAnalysisModel $analysis): array
    {
        return $this->formatAnalysis($applicant, $analysis, [
            'source_type' => $analysis->source_type,
            'source_label' => $analysis->source_label,
            'resume_sha256' => $analysis->resume_sha256,
            'resume_chars' => $analysis->resume_chars,
        ]);
    }

    private function runSemanticStage(array $payload, array $applicantIds, array $roles, array $resumeTexts): ?array
    {
        $ai = $this->requestAi($payload, false);
        if (!$ai['status']) return null;

        $validated = $this->validator->validateBatch(
            $ai['data'] ?? [],
            $applicantIds,
            $roles,
            $resumeTexts
        );

        $id = (string) ($applicantIds[0] ?? '');
        $result = $validated['results'][$id] ?? null;
        if ($result) return $result;

        // Retry one candidate with the verifier model if the first model omits or
        // corrupts the structured response.
        if (count($applicantIds) === 1) {
            $retry = $this->requestAi($payload, true);
            if ($retry['status']) {
                $retryValidated = $this->validator->validateBatch(
                    $retry['data'] ?? [],
                    $applicantIds,
                    $roles,
                    $resumeTexts
                );
                return $retryValidated['results'][$id] ?? null;
            }
        }

        return null;
    }

    private function validateSemanticBatch(array $payload, array $candidateRoleSets, array $sources): array
    {
        $requestedIds = array_column($payload, 'sno');
        $roles = $this->rolesForPayload($candidateRoleSets);
        $resumeTexts = array_combine(
            array_keys($sources),
            array_map(fn ($source) => (string) ($source['text'] ?? ''), $sources)
        ) ?: [];

        $ai = $this->requestAi($payload, false);
        if (!$ai['status']) return [];

        $validated = $this->validator->validateBatch(
            $ai['data'] ?? [],
            $requestedIds,
            $roles,
            $resumeTexts
        );

        return $validated['results'] ?? [];
    }

    private function requestAi(array $payload, bool $single = false): array
    {
        try {
            $messages = [
                ['role' => 'system', 'content' => $this->prompt->systemInstruction()],
                ['role' => 'user', 'content' => $this->prompt->buildInput($payload)],
            ];

            return $this->huggingFace->structured(
                $messages,
                $this->prompt->schema(),
                $single
                    ? config('recruitment_ats.resume_verifier_model')
                    : config('recruitment_ats.model'),
                $single
                    ? (int) config('recruitment_ats.resume_verify_timeout', 75)
                    : (int) config('recruitment_ats.ai_timeout', 90)
            );
        } catch (Throwable $e) {
            Log::error('Recruitment ATS AI request exception.', ['message' => $e->getMessage()]);
            return ['status' => false, 'message' => 'Unable to contact the recruitment ATS AI model.'];
        }
    }

    private function mergeDeterministicCoverage(array $result, array $candidateRoles, string $resume): array
    {
        $existing = [];
        foreach (array_merge($result['matches'] ?? [], $result['near_matches'] ?? []) as $match) {
            $existing[(int) ($match['role_id'] ?? 0)] = true;
        }

        $matches = array_values($result['matches'] ?? []);
        $near = array_values($result['near_matches'] ?? []);
        $nearMin = (float) config('recruitment_ats.near_match_min_score', 45);
        $maxNear = (int) config('recruitment_ats.near_match_max_items', 8);

        $minimum = (float) config('recruitment_ats.minimum_match_score', 70);
        foreach ($candidateRoles as $role) {
            $id = (int) ($role['sno'] ?? $role['role_id'] ?? 0);
            if ($id <= 0 || isset($existing[$id])) continue;

            $fallback = $this->scoreDeterministically($role, $resume);
            $fallbackScore = (float) ($fallback['match_score'] ?? 0);
            if ($fallbackScore >= $minimum) {
                $matches[] = $fallback;
            } elseif ($fallbackScore >= $nearMin) {
                $near[] = $fallback;
            }
        }

        usort($matches, fn ($a, $b) => (float) ($b['match_score'] ?? 0) <=> (float) ($a['match_score'] ?? 0));
        usort($near, fn ($a, $b) => (float) ($b['match_score'] ?? 0) <=> (float) ($a['match_score'] ?? 0));

        $near = array_values(array_filter(
            array_slice($near, 0, max(1, $maxNear)),
            fn ($m) => (float) ($m['match_score'] ?? 0) < $minimum
        ));

        $result['matches'] = $matches;
        $result['near_matches'] = $near;
        $result['analysis'] = array_merge((array) ($result['analysis'] ?? []), [
            'role_catalog_evaluated' => count($candidateRoles),
            'deterministic_coverage_enabled' => true,
        ]);
        $result['analysis']['overall_match_score'] = $matches
            ? max(array_map(fn ($m) => (float) ($m['match_score'] ?? 0), $matches))
            : 0;

        return $result;
    }

    private function deterministicResult(array $candidateRoles, string $resume): array
    {
        $matches = [];
        $near = [];
        $minimum = (float) config('recruitment_ats.minimum_match_score', 70);
        $nearMin = (float) config('recruitment_ats.near_match_min_score', 45);
        $maxNear = (int) config('recruitment_ats.near_match_max_items', 8);

        foreach ($candidateRoles as $role) {
            $scored = $this->scoreDeterministically($role, $resume);
            $score = (float) ($scored['match_score'] ?? 0);
            if ($score >= $minimum) {
                $matches[] = $scored;
            } elseif ($score >= $nearMin) {
                $near[] = $scored;
            }
        }

        usort($matches, fn ($a, $b) => (float) ($b['match_score'] ?? 0) <=> (float) ($a['match_score'] ?? 0));
        usort($near, fn ($a, $b) => (float) ($b['match_score'] ?? 0) <=> (float) ($a['match_score'] ?? 0));

        return [
            'applicant_id' => '',
            'analysis' => [
                'candidate_summary' => 'Semantic model was unavailable; deterministic ATS evaluation was used.',
                'current_designation' => '',
                'previous_designations' => [],
                'experience_summary' => '',
                'education_summary' => '',
                'seniority_assessment' => '',
                'data_quality_notes' => ['Hugging Face semantic stage was unavailable during this run.'],
                'strengths' => [],
                'weaknesses' => [],
                'role_catalog_evaluated' => count($candidateRoles),
                'deterministic_coverage_enabled' => true,
            ],
            'matches' => $matches,
            'near_matches' => array_slice($near, 0, max(1, $maxNear)),
        ];
    }

    private function scoreDeterministically(array $role, string $resume): array
    {
        $evidence = $this->deterministicEvidence($role, $resume);
        $retrieval = (float) ($role['_embedding_score'] ?? $role['_retrieval_score'] ?? 0);
        $match = $this->scorer->score([
            'semantic_fit_score' => $retrieval,
            'title_alignment_score' => 0,
            'skill_alignment_score' => 0,
            'experience_alignment_score' => 0,
            'responsibility_alignment_score' => 0,
            'seniority_alignment_score' => 0,
            'reason' => 'Deterministic fallback evaluation from resume evidence.',
            'evidence' => $evidence,
            'gaps' => [],
        ], $role, $resume);

        return $match;
    }

    private function deterministicEvidence(array $role, string $resume): array
    {
        $lines = preg_split('/\R+/u', $resume) ?: [];
        $terms = array_values(array_filter(array_merge(
            [$role['role_name'] ?? '', $role['role_family'] ?? ''],
            (array) ($role['aliases'] ?? []),
            (array) ($role['mandatory_skills'] ?? []),
            (array) ($role['responsibilities'] ?? [])
        )));

        $found = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || mb_strlen($line) < 12) continue;
            $canonicalLine = $this->canonical($line);
            $hits = 0;
            foreach ($terms as $term) {
                $term = $this->canonical((string) $term);
                if ($term !== '' && str_contains($canonicalLine, $term)) $hits++;
            }
            if ($hits > 0) $found[] = mb_substr($line, 0, 1000);
        }

        return array_values(array_unique(array_slice($found, 0, 6)));
    }

    private function rolesForPayload(array $roleSets): array
    {
        if (!$roleSets) return [];
        $roles = [];
        $isRoleList = isset($roleSets[0]) && is_array($roleSets[0]) && (
            array_key_exists('sno', $roleSets[0]) || array_key_exists('role_id', $roleSets[0])
        );

        if ($isRoleList) {
            foreach ($roleSets as $role) {
                $id = (int) ($role['sno'] ?? $role['role_id'] ?? 0);
                if ($id > 0) $roles[$id] = $role;
            }
            return array_values($roles);
        }

        foreach ($roleSets as $set) {
            if (!is_array($set)) continue;
            foreach ($set as $role) {
                if (!is_array($role)) continue;
                $id = (int) ($role['sno'] ?? $role['role_id'] ?? 0);
                if ($id > 0) $roles[$id] = $role;
            }
        }

        return array_values($roles);
    }

    private function persistResult(
        ApplicantModel $applicant,
        array $result,
        array $source,
        array $allRoles,
        ?int $runSno,
        int $actorId,
        string $catalogHash,
        array $candidateRoles
    ): ApplicantAtsRoleAnalysisModel {
        $matches = array_values($result['matches'] ?? []);
        $best = $matches ? max(array_map(fn ($m) => (float) ($m['match_score'] ?? 0), $matches)) : 0.0;
        $analysisData = (array) ($result['analysis'] ?? []);

        $extraction = ApplicantResumeExtractionModel::query()
            ->where('applicant_sno', $applicant->sno)
            ->where('resume_sha256', $source['resume_sha256'])
            ->latest('sno')
            ->first();

        $payload = [
            'schema_version' => config('recruitment_ats.schema_version', 'ats_role_matching.v6'),
            'engine' => config('recruitment_ats.engine', 'egc_ats_hybrid_evidence_v6'),
            'model' => config('recruitment_ats.model') ?: null,
            'embedding_model' => config('recruitment_ats.embedding_model') ?: null,
            'scoring_version' => config('recruitment_ats.scoring_version', 'ats_scoring.v2'),
            'role_catalog_hash' => $catalogHash,
            'role_catalog_size' => count($allRoles),
            'retrieved_role_ids' => array_values(array_map(fn ($r) => (int) ($r['sno'] ?? $r['role_id'] ?? 0), $candidateRoles)),
            'retrieved_role_count' => count($candidateRoles),
            'analysis' => $analysisData,
            'matches' => $matches,
            'near_matches' => $result['near_matches'] ?? [],
            'candidate_data_confidence' => $extraction ? (float) $extraction->confidence : null,
            'candidate_data_review_required' => $extraction ? (bool) $extraction->review_required : null,
            'processed_at' => now()->toIso8601String(),
        ];

        return DB::transaction(function () use ($applicant, $source, $payload, $best, $runSno, $actorId, $catalogHash, $matches) {
            $analysis = ApplicantAtsRoleAnalysisModel::query()->firstOrNew(['applicant_sno' => $applicant->sno]);
            $analysis->fill([
                'run_sno' => $runSno,
                'schema_version' => $payload['schema_version'],
                'engine' => $payload['engine'],
                'model' => $payload['model'],
                'source_type' => $source['source_type'],
                'source_label' => $source['source_label'] ?? null,
                'role_catalog_hash' => $catalogHash,
                'resume_sha256' => $source['resume_sha256'],
                'resume_chars' => (int) $source['resume_chars'],
                'overall_match_score' => $best,
                'best_role_score' => $best,
                'resume_quality_score' => (float) ($payload['candidate_data_confidence'] ?? 0),
                'match_count' => count($matches),
                'analysis_json' => $payload,
                'role_catalog_size' => count($allRoles),
                'semantic_candidate_count' => (int) ($payload['retrieved_role_count'] ?? 0),
                'candidate_data_confidence' => $payload['candidate_data_confidence'],
                'review_required' => (bool) ($payload['candidate_data_review_required'] ?? false),
                'retrieval_model' => $payload['embedding_model'],
                'scoring_version' => $payload['scoring_version'],
                'processed_at' => now(),
                'updated_by' => $actorId,
            ]);
            if (!$analysis->exists) $analysis->created_by = $actorId;
            $analysis->save();

            ApplicantAtsRoleMatchModel::query()->where('analysis_sno', $analysis->sno)->delete();
            $rows = [];

            foreach ($matches as $match) {
                $rows[] = [
                    'analysis_sno' => $analysis->sno,
                    'applicant_sno' => $applicant->sno,
                    'role_sno' => (int) ($match['role_id'] ?? 0),
                    'role_code' => $match['role_code'] ?? null,
                    'role_name' => $match['role_name'] ?? 'Role',
                    'role_family' => $match['role_family'] ?? null,
                    'seniority_level' => $match['seniority_level'] ?? null,
                    'match_score' => (float) ($match['match_score'] ?? 0),
                    'decision' => $match['decision'] ?? 'match',
                    'semantic_fit_score' => (float) ($match['semantic_fit_score'] ?? 0),
                    'title_alignment_score' => (float) ($match['title_alignment_score'] ?? 0),
                    'skill_alignment_score' => (float) ($match['skill_alignment_score'] ?? 0),
                    'experience_alignment_score' => (float) ($match['experience_alignment_score'] ?? 0),
                    'responsibility_alignment_score' => (float) ($match['responsibility_alignment_score'] ?? 0),
                    'seniority_alignment_score' => (float) ($match['seniority_alignment_score'] ?? 0),
                    'education_alignment_score' => (float) ($match['education_alignment_score'] ?? 0),
                    'mandatory_skill_coverage' => (float) ($match['mandatory_skill_coverage'] ?? 0),
                    'education_requirement_coverage' => (float) ($match['education_requirement_coverage'] ?? 0),
                    'candidate_experience_years' => (float) ($match['candidate_experience_years'] ?? 0),
                    'required_experience_years' => (float) ($match['required_experience_years'] ?? 0),
                    'confidence_score' => (float) ($match['confidence_score'] ?? 0),
                    'evidence_quality_score' => (float) ($match['evidence_quality_score'] ?? 0),
                    'reason' => $match['reason'] ?? null,
                    'evidence_json' => json_encode($match['evidence'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'gaps_json' => json_encode($match['gaps'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'scoring_version' => $match['scoring_version'] ?? $payload['scoring_version'],
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }

            if ($rows) ApplicantAtsRoleMatchModel::query()->insert($rows);
            return $analysis->fresh();
        });
    }

    private function formatAnalysis(ApplicantModel $applicant, ApplicantAtsRoleAnalysisModel $analysis, array $source): array
    {
        $payload = is_array($analysis->analysis_json)
            ? $analysis->analysis_json
            : (json_decode((string) $analysis->analysis_json, true) ?: []);

        $matches = ApplicantAtsRoleMatchModel::query()
            ->where('analysis_sno', $analysis->sno)
            ->orderByDesc('match_score')
            ->get()
            ->map(fn (ApplicantAtsRoleMatchModel $match): array => [
                'role_id' => (int) $match->role_sno,
                'role_code' => $match->role_code,
                'role_name' => $match->role_name,
                'role_family' => $match->role_family,
                'seniority_level' => $match->seniority_level,
                'match_score' => (float) $match->match_score,
                'decision' => $match->decision,
                'semantic_fit_score' => (float) $match->semantic_fit_score,
                'title_alignment_score' => (float) $match->title_alignment_score,
                'skill_alignment_score' => (float) $match->skill_alignment_score,
                'experience_alignment_score' => (float) $match->experience_alignment_score,
                'responsibility_alignment_score' => (float) $match->responsibility_alignment_score,
                'seniority_alignment_score' => (float) $match->seniority_alignment_score,
                'education_alignment_score' => (float) $match->education_alignment_score,
                'mandatory_skill_coverage' => (float) $match->mandatory_skill_coverage,
                'education_requirement_coverage' => (float) $match->education_requirement_coverage,
                'candidate_experience_years' => (float) $match->candidate_experience_years,
                'required_experience_years' => (float) $match->required_experience_years,
                'confidence_score' => (float) $match->confidence_score,
                'evidence_quality_score' => (float) $match->evidence_quality_score,
                'reason' => $match->reason,
                'evidence' => is_array($match->evidence_json) ? $match->evidence_json : [],
                'gaps' => is_array($match->gaps_json) ? $match->gaps_json : [],
                'scoring_version' => $match->scoring_version,
            ])->values()->all();

        return [
            'analysis_sno' => (int) $analysis->sno,
            'applicant' => [
                'sno' => (int) $applicant->sno,
                'applicant_id' => $applicant->applicant_id,
                'name' => $applicant->applicant_name,
                'email' => $applicant->email,
                'mobile' => $applicant->mobile,
            ],
            'source' => [
                'type' => $source['source_type'] ?? $analysis->source_type,
                'label' => $source['source_label'] ?? $analysis->source_label,
                'resume_chars' => (int) ($source['resume_chars'] ?? $analysis->resume_chars),
                'resume_sha256' => $source['resume_sha256'] ?? $analysis->resume_sha256,
                'role_catalog_hash' => $analysis->role_catalog_hash,
            ],
            'overall_match_score' => (float) $analysis->overall_match_score,
            'best_role_score' => (float) $analysis->best_role_score,
            'resume_quality_score' => (float) $analysis->resume_quality_score,
            'match_count' => (int) $analysis->match_count,
            'matches' => $matches,
            'near_matches' => $payload['near_matches'] ?? [],
            'analysis' => $payload['analysis'] ?? [],
            'meta' => [
                'schema_version' => $analysis->schema_version,
                'engine' => $analysis->engine,
                'model' => $analysis->model,
                'embedding_model' => $payload['embedding_model'] ?? null,
                'role_catalog_size' => $analysis->role_catalog_size ?? ($payload['role_catalog_size'] ?? null),
                'retrieved_role_count' => $analysis->semantic_candidate_count ?? ($payload['retrieved_role_count'] ?? null),
                'complete_role_evaluation' => true,
                'candidate_data_confidence' => $payload['candidate_data_confidence'] ?? null,
                'candidate_data_review_required' => $payload['candidate_data_review_required'] ?? null,
                'scoring_version' => $payload['scoring_version'] ?? null,
                'processed_at' => optional($analysis->processed_at)->toIso8601String(),
                'updated_at' => optional($analysis->updated_at)->toIso8601String(),
            ],
        ];
    }

    private function hasCurrentAnalysis(ApplicantModel $applicant, string $roleCatalogHash, string $resumeSha): bool
    {
        return ApplicantAtsRoleAnalysisModel::query()
            ->where('applicant_sno', $applicant->sno)
            ->where('role_catalog_hash', $roleCatalogHash)
            ->where('resume_sha256', $resumeSha)
            ->exists();
    }

    private function canonical(string $text): string
    {
        $text = mb_strtolower(strip_tags($text), 'UTF-8');
        $text = str_replace(['&','/','\\','-','_','.', '(', ')', ',', ':', '|', ';'], ' ', $text);
        return trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
    }
}
