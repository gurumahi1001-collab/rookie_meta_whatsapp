<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use App\Models\ApplicantModel;
use App\Services\GoogleDriveService;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * Canonical resume source resolver for the recruitment ATS.
 *
 * Every path (stored attachment, Drive, public path, pasted text) ends in the
 * same document extractor and the same normalized SHA-256 fingerprint. This
 * prevents one ATS route from parsing a resume differently from another.
 */
class RecruitmentAtsResumeSourceService
{
    public const SOURCE_STORED = 'stored';
    public const SOURCE_PUBLIC_PATH = 'public_path';
    public const SOURCE_DRIVE_LINK = 'drive_link';
    public const SOURCE_RESUME_TEXT = 'resume_text';

    public function __construct(
        protected RecruitmentDocumentTextExtractor $documents,
        protected GoogleDriveService $googleDrive
    ) {
    }

    public function resolve(ApplicantModel $applicant, array $override = []): array
    {
        $sourceType = trim((string) ($override['source_type'] ?? self::SOURCE_STORED));

        return match ($sourceType) {
            self::SOURCE_STORED => $this->resolveStored($applicant),
            self::SOURCE_PUBLIC_PATH => $this->resolvePublicPath((string) ($override['public_path'] ?? '')),
            self::SOURCE_DRIVE_LINK => $this->resolveDriveLink((string) ($override['drive_link'] ?? '')),
            self::SOURCE_RESUME_TEXT => $this->resolveResumeText((string) ($override['resume_text'] ?? '')),
            default => throw new RuntimeException('Unsupported resume source.'),
        };
    }

    public function prepareForModel(string $resume): string
    {
        $resume = $this->normalize($resume);
        $maxChars = max(12000, (int) config('recruitment_ats.bulk_model_max_resume_chars', 24000));

        if (mb_strlen($resume) <= $maxChars) {
            return $resume;
        }

        $sections = [
            'SUMMARY|PROFILE|OBJECTIVE',
            'WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY|EXPERIENCE',
            'EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS',
            'SKILLS|TECHNICAL\s+SKILLS|CORE\s+SKILLS|KEY\s+SKILLS',
            'PROJECTS|KEY\s+PROJECTS',
            'CERTIFICATIONS?|CERTIFICATES',
            'PERSONAL\s+DETAILS|CONTACT',
        ];

        $chunks = [mb_substr($resume, 0, 10000)];
        foreach ($sections as $heading) {
            if (preg_match('/\b(?:'.$heading.')\b.*?(?=\n\s*\n|\b(?:SUMMARY|PROFILE|OBJECTIVE|WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY|EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS|SKILLS|TECHNICAL\s+SKILLS|CORE\s+SKILLS|KEY\s+SKILLS|PROJECTS|CERTIFICATIONS?|PERSONAL\s+DETAILS|CONTACT|REFERENCES)\b|$)/is', $resume, $m)) {
                $chunks[] = mb_substr(trim($m[0]), 0, 14000);
            }
        }
        $chunks[] = mb_substr($resume, -7000);

        $unique = [];
        foreach ($chunks as $chunk) {
            $chunk = trim($chunk);
            if ($chunk !== '') $unique[$chunk] = true;
        }

        $result = implode("\n\n--- RESUME SECTION ---\n\n", array_keys($unique));
        return mb_strlen($result) > $maxChars ? mb_substr($result, 0, $maxChars) : $result;
    }

    public function persistResumeHash(ApplicantModel $applicant, string $sha256): void
    {
        try {
            if ($this->hasApplicantHashColumn()) {
                ApplicantModel::query()->whereKey($applicant->sno)->update([
                    'recruitment_resume_sha256' => $sha256,
                ]);
                $applicant->recruitment_resume_sha256 = $sha256;
            }
        } catch (Throwable) {
            // The migration is deployable separately; failure to persist this
            // optimization must never break the ATS analysis itself.
        }
    }

    private function resolveStored(ApplicantModel $applicant): array
    {
        $existing = trim((string) ($applicant->resume_text ?? ''));
        if ($existing !== '') {
            return $this->result($existing, self::SOURCE_STORED, 'Candidate stored resume text');
        }

        if (!empty($applicant->attachment)) {
            $path = public_path('job_applications/resume_files/' . basename((string) $applicant->attachment));
            if (is_file($path)) {
                return $this->resultFromFile($path, basename((string) $applicant->attachment), self::SOURCE_STORED, 'Candidate attachment resume');
            }
        }

        $driveFileId = $this->driveFileId($applicant->drive_data);
        if ($driveFileId !== null) {
            return $this->resolveDriveFile($driveFileId, self::SOURCE_STORED, 'Candidate Google Drive resume');
        }

        throw new RuntimeException('Resume content is not available for this candidate.');
    }

    private function resolvePublicPath(string $input): array
    {
        $input = trim($input);
        if ($input === '') throw new RuntimeException('Public resume path is required.');

        $publicRoot = realpath(public_path());
        if ($publicRoot === false) throw new RuntimeException('Public directory is not available.');

        $normalized = str_replace('\\', '/', ltrim($input, '/'));
        if (Str::startsWith(strtolower($normalized), 'public/')) $normalized = substr($normalized, 7);
        $candidatePath = preg_match('/^[A-Za-z]:[\\\/]/', $input) || Str::startsWith($input, DIRECTORY_SEPARATOR)
            ? $input
            : public_path($normalized);
        $real = realpath($candidatePath);
        if ($real === false || !is_file($real)) throw new RuntimeException('The supplied public resume path does not exist.');

        $root = rtrim(str_replace('\\', '/', $publicRoot), '/') . '/';
        $realNormalized = str_replace('\\', '/', $real);
        if (!Str::startsWith($realNormalized . '/', $root)) {
            throw new RuntimeException('The resume path must remain inside the application public directory.');
        }

        return $this->resultFromFile($real, basename($real), self::SOURCE_PUBLIC_PATH, basename($real));
    }

    private function resolveDriveLink(string $input): array
    {
        $id = $this->extractGoogleDriveFileId($input);
        if ($id === null) throw new RuntimeException('Enter a valid Google Drive file link or Drive file ID.');
        $masked = strlen($id) > 8 ? 'Drive file ••••' . substr($id, -6) : 'Drive file';
        return $this->resolveDriveFile($id, self::SOURCE_DRIVE_LINK, $masked);
    }

    private function resolveDriveFile(string $fileId, string $sourceType, string $label): array
    {
        $downloaded = null;
        try {
            $downloaded = $this->googleDrive->downloadFile($fileId);
            if (!is_file($downloaded)) throw new RuntimeException('Google Drive returned no readable file.');

            return $this->resultFromFile($downloaded, basename($downloaded), $sourceType, $label);
        } finally {
            if ($downloaded && is_file($downloaded)) @unlink($downloaded);
        }
    }

    private function resolveResumeText(string $text): array
    {
        if (mb_strlen(trim($text)) < 30) throw new RuntimeException('Resume text is too short for reliable ATS analysis.');
        return $this->result($text, self::SOURCE_RESUME_TEXT, 'Pasted resume text');
    }

    private function resultFromFile(string $path, ?string $originalName, string $type, string $label): array
    {
        $document = $this->documents->extractFile($path, $originalName ?: $path);
        return $this->result($document['text'], $type, $label, [
            'extension' => $document['extension'] ?? null,
            'ocr_used' => (bool) ($document['ocr_used'] ?? false),
            'bytes' => (int) ($document['bytes'] ?? 0),
            'original_name' => $originalName,
        ]);
    }

    private function result(string $text, string $type, string $label, array $extra = []): array
    {
        $text = $this->normalize($text);
        $maxChars = max(30000, (int) config('recruitment_ats.resume_source_max_chars', 180000));
        $text = mb_substr($text, 0, $maxChars);
        if (mb_strlen($text) < 20) throw new RuntimeException('Resume contains insufficient readable text.');

        return array_merge([
            'text' => $text,
            'source_type' => $type,
            'source_label' => $label,
            'resume_sha256' => hash('sha256', $text),
            'resume_chars' => mb_strlen($text),
        ], $extra);
    }

    public function normalize(string $text): string
    {
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        $text = mb_convert_encoding($text, 'UTF-8', 'UTF-8');
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $text) ?? $text;
        $text = preg_replace('/[ \t]+/u', ' ', $text) ?? $text;
        $text = preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text;
        return trim($text);
    }

    private function hasApplicantHashColumn(): bool
    {
        static $exists = null;
        if ($exists !== null) return $exists;
        try {
            $exists = \Schema::hasColumn('egc_applicant', 'recruitment_resume_sha256');
        } catch (Throwable) {
            $exists = false;
        }
        return $exists;
    }

    private function driveFileId(mixed $value): ?string
    {
        if (!$value) return null;
        $decoded = is_string($value) ? json_decode($value, true) : $value;
        if (is_object($decoded)) $decoded = (array) $decoded;
        $id = is_array($decoded) ? ($decoded['file_id'] ?? null) : null;
        return is_string($id) && preg_match('/^[A-Za-z0-9_-]{20,}$/', $id) ? $id : null;
    }

    private function extractGoogleDriveFileId(string $value): ?string
    {
        $value = trim($value);
        if ($value === '') return null;
        if (preg_match('/^[A-Za-z0-9_-]{20,}$/', $value)) return $value;
        if (preg_match('~/(?:file|document)/d/([A-Za-z0-9_-]{20,})~', $value, $m)) return $m[1];
        $query = parse_url($value, PHP_URL_QUERY);
        if (is_string($query)) {
            parse_str($query, $params);
            if (!empty($params['id']) && preg_match('/^[A-Za-z0-9_-]{20,}$/', (string)$params['id'])) return (string)$params['id'];
        }
        return null;
    }
}
