<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * Production resume extraction orchestrator.
 *
 * Design goal: never let a plausible LLM guess become source-of-truth data.
 * Every populated field is either deterministic source extraction or AI output
 * corroborated by text/evidence from the actual resume.
 */
class ResumeExtractionService
{
    public function __construct(
        protected RecruitmentDocumentTextExtractor $documents,
        protected RecruitmentHuggingFaceService $huggingFace,
        protected RecruitmentEducationCatalogService $educationCatalog
    ) {
    }


    public function extract(UploadedFile $file, bool $includeText = false): array
    {
        $started = microtime(true);
        $document = $this->documents->extractUploadedFile($file);
        return $this->extractText(
            $document['text'],
            [
                'extension' => $document['extension'],
                'ocr_used' => (bool) $document['ocr_used'],
                'original_name' => $file->getClientOriginalName(),
                'bytes' => $document['bytes'],
            ],
            $includeText,
            $started
        );
    }

    public function extractFromPath(string $path, ?string $originalName = null, bool $includeText = false): array
    {
        $started = microtime(true);
        $document = $this->documents->extractFile($path, $originalName ?: $path);
        return $this->extractText(
            $document['text'],
            [
                'extension' => $document['extension'],
                'ocr_used' => (bool) $document['ocr_used'],
                'original_name' => $originalName ?: basename($path),
                'bytes' => $document['bytes'],
            ],
            $includeText,
            $started
        );
    }

    /**
     * Parse already-extracted resume text. Used by ATS and by stored resume
     * records, so every pipeline has exactly the same extraction semantics.
     */
    public function extractText(string $text, array $documentMeta = [], bool $includeText = false, ?float $started = null): array
    {
        $started ??= microtime(true);
        $text = $this->documents->normalize($text);
        if (mb_strlen($text) < 20) {
            throw new RuntimeException('The resume contains insufficient readable text.');
        }

        $local = $this->localExtract($text);
        $ai = [];
        $aiAttempted = false;
        $aiVerified = false;
        $aiErrors = [];
        $token = $this->huggingFace->token();

        if ($token && filter_var(config('recruitment_ats.resume_ai_enabled', true), FILTER_VALIDATE_BOOLEAN)) {
            $aiAttempted = true;
            $primary = $this->extractWithAI($text, $this->primarySchema(), (string) config('recruitment_ats.resume_primary_model'));
            if ($primary['status']) {
                $ai = $primary['data'];

                // A second independent model pass is deliberately used for Add
                // Candidate extraction. It is cheaper to review one record now
                // than to create a wrong candidate that contaminates ATS results.
                if (filter_var(config('recruitment_ats.resume_verification_enabled', true), FILTER_VALIDATE_BOOLEAN)) {
                    $verification = $this->verifyWithAI(
                        $text,
                        $ai,
                        $this->primarySchema(),
                        (string) config('recruitment_ats.resume_verifier_model')
                    );
                    if ($verification['status']) {
                        $ai = $verification['data'];
                        $aiVerified = true;
                    } else {
                        $aiErrors[] = $verification['message'] ?? 'AI verification failed.';
                    }
                }
            } else {
                $aiErrors[] = $primary['message'] ?? 'Primary AI extraction failed.';
            }
        }

        $data = $this->buildCandidateData($text, $local, $ai);
        $meta = $this->buildMeta($documentMeta, $data, $aiAttempted, $aiVerified, $aiErrors, $started, $ai);
        $meta['text_length'] = mb_strlen($text);
        $data['confidence'] = $this->overallConfidence($data);
        $data['extraction_meta'] = $meta;
        if ($includeText) $data['resume_text'] = $text;

        return $data;
    }
    private function buildCandidateData(string $text, array $local, array $ai): array
    {
        $localName = $this->cleanName((string) ($local['candidate_name'] ?? ''));
        $aiName = $this->cleanName((string) data_get($ai, 'identity.name', ''));

        // The deterministic header resolver wins when it identifies a valid
        // candidate name. AI may only fill an empty value and must carry source
        // evidence from the same resume.
        $name = $localName;
        $nameEvidence = trim((string) ($local['candidate_name_evidence'] ?? ''));
        if (!$name && $aiName && $this->nameEvidenceSupports($aiName, (string) data_get($ai, 'identity.name_evidence', ''), $text)) {
            $name = $aiName;
            $nameEvidence = (string) data_get($ai, 'identity.name_evidence', '');
        }

        $email = $this->validateIndianContactEmail($local['candidate_email'] ?? null);
        $mobile = $this->cleanPhone($local['candidate_mobile'] ?? null);

        // Contacts are deterministic source extraction. AI never invents or
        // overwrites them.
        $gender = $local['candidate_gender'] ?? null;
        $marital = $local['candidate_marital_status'] ?? null;

        $education = $this->educationCatalog->resolve(
            $text,
            is_array($ai['education'] ?? null) ? $ai['education'] : [],
            [
                'degree_full' => $local['degree_full'] ?? null,
                'major_text' => $local['candidate_major_text'] ?? null,
            ]
        );

        $experienceEntries = $this->validatedExperienceEntries($text, $ai);
        $experience = $this->calculateExperienceYears($text, $experienceEntries, $ai);

        $educationResolved = ($education['resolution_status'] ?? '') === 'resolved';

        $data = [
            'candidate_name' => $name,
            'candidate_email' => $email,
            'candidate_mobile' => $mobile,
            'candidate_gender' => $gender,
            'candidate_marital_status' => $marital,
            'candidate_qualification' => $education['qualification_sno'],
            'candidate_major' => $education['major_sno'],
            'candidate_major_text' => $education['major_text'],
            'candidate_other_major' => $education['major_sno'] ? null : ($education['major_text'] ?: null),
            'degree_full' => $education['degree_full'],
            'education_entries' => $education['entries'],
            'education_resolution_status' => $education['resolution_status'] ?? 'manual_review',
            'education_resolution_candidates' => $education['candidates'] ?? [],
            'employment_entries' => $experienceEntries,
            'candidate_exper_count' => $experience,
            'candidate_exper_type' => $experience > 0 ? 2 : 1,
            'skills' => $this->stringArray($ai['skills'] ?? []),
            'experience_evidence' => $this->experienceEvidence($experienceEntries, $text),
            'field_evidence' => [
                'candidate_name' => $this->fieldEvidence($name, $nameEvidence, $text, 'name'),
                'candidate_email' => $this->fieldEvidence($email, $local['candidate_email_evidence'] ?? $email, $text),
                'candidate_mobile' => $this->fieldEvidence($mobile, $local['candidate_mobile_evidence'] ?? $mobile, $text),
                'candidate_gender' => $this->fieldEvidence($gender, $this->explicitLabelEvidence($text, ['gender', 'sex']), $text),
                'candidate_marital_status' => $this->fieldEvidence($marital, $this->explicitLabelEvidence($text, ['marital status', 'marital']), $text),
                'qualification' => $this->fieldEvidence($education['degree_full'], $education['evidence'], $text),
                'major' => $this->fieldEvidence($education['major_text'], $education['major_evidence'], $text),
                'experience' => $this->fieldEvidence((string) $experience, implode(' | ', $this->experienceEvidence($experienceEntries, $text)), $text),
            ],
        ];

        $data['field_confidence'] = $this->fieldConfidence($data, $education, $text);
        $data['manual_review_fields'] = $this->manualReviewFields($data, $education);
        $data['field_provenance'] = $this->fieldProvenance($data, $education, $text, $ai);
        $data['ai_identity_review'] = [
            'name_raw' => trim((string) data_get($ai, 'identity.name', '')),
            'name_evidence' => trim((string) data_get($ai, 'identity.name_evidence', '')),
        ];
        $data['education_master_source'] = $educationResolved ? 'egc_major' : 'manual_review';

        return $data;
    }


    private function primarySchema(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'identity' => [
                    'type' => 'object',
                    'properties' => [
                        'name' => ['type' => 'string'],
                        'name_evidence' => ['type' => 'string'],
                        'email' => ['type' => 'string'],
                        'email_evidence' => ['type' => 'string'],
                        'phone' => ['type' => 'string'],
                        'phone_evidence' => ['type' => 'string'],
                        'gender' => ['type' => 'string'],
                        'gender_evidence' => ['type' => 'string'],
                        'marital_status' => ['type' => 'string'],
                        'marital_status_evidence' => ['type' => 'string'],
                    ],
                    'required' => ['name','name_evidence','email','email_evidence','phone','phone_evidence','gender','gender_evidence','marital_status','marital_status_evidence'],
                    'additionalProperties' => false,
                ],
                'education' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'degree_title' => ['type' => 'string'],
                            'qualification_level' => ['type' => 'string'],
                            'major' => ['type' => 'string'],
                            'institution' => ['type' => 'string'],
                            'year' => ['type' => 'string'],
                            'evidence' => ['type' => 'string'],
                        ],
                        'required' => ['degree_title','qualification_level','major','institution','year','evidence'],
                        'additionalProperties' => false,
                    ],
                ],
                'employment' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'title' => ['type' => 'string'],
                            'company' => ['type' => 'string'],
                            'start_date' => ['type' => 'string'],
                            'end_date' => ['type' => 'string'],
                            'employment_type' => ['type' => 'string'],
                            'is_professional' => ['type' => 'boolean'],
                            'evidence' => ['type' => 'string'],
                        ],
                        'required' => ['title','company','start_date','end_date','employment_type','is_professional','evidence'],
                        'additionalProperties' => false,
                    ],
                ],
                'explicit_total_experience_years' => ['type' => 'number'],
                'explicit_total_experience_evidence' => ['type' => 'string'],
                'skills' => [
                    'type' => 'array',
                    'items' => ['type' => 'string'],
                ],
                'notes' => ['type' => 'string'],
            ],
            'required' => ['identity','education','employment','explicit_total_experience_years','explicit_total_experience_evidence','skills','notes'],
            'additionalProperties' => false,
        ];
    }

    private function extractionSystemPrompt(): string
    {
        return <<<'PROMPT'
You are a production-grade HR resume extraction and verification engine.
The supplied text is the source of truth. Extract only facts actually supported by it.
Never guess, infer, complete, or hallucinate a missing field.

IDENTITY
- name: candidate's own name from the header/contact identity area. Never use a company, recruiter, reference, emergency contact, author or job title.
- email/phone: candidate contact only. Never invent or copy a recruiter/reference/emergency contact.
- gender/marital_status: only when explicitly labelled in the source. Do not infer from name, pronouns, photo or culture.
- Every non-empty identity value needs a short VERBATIM evidence snippet from the resume.

EDUCATION
- Extract every clearly stated education entry that belongs to the candidate.
- qualification_level must be one of UG, PG, Doctorate, HSC, SSLC, Below SSLC, Diploma, or empty when unclear.
- major must be the explicit specialization, not a job title.
- Evidence must be verbatim.

EMPLOYMENT
- Extract only the candidate's own employment history.
- Do not treat job-ad text, required-experience statements, education, projects, coursework, volunteer work, or training as employment.
- Mark is_professional=false for internships/trainee/apprentice/volunteer/student/academic roles unless the resume explicitly presents them as professional paid employment.
- Preserve each date exactly enough to reconstruct duration; use Present/Current when explicitly shown.
- Preserve evidence verbatim.

EXPERIENCE
- explicit_total_experience_years is valid only when the resume explicitly states a total/overall/professional/relevant experience value.
- Never use arbitrary numbers from the resume.
- The backend will calculate overlapping employment periods itself.

SKILLS
- Extract explicit technologies, tools, platforms, methodologies and functional skills stated by the candidate.
- Do not copy skills from job descriptions or advertisements unrelated to candidate experience.

Return ONLY the requested JSON object.
PROMPT;
    }

    private function extractWithAI(string $text, array $schema, string $model): array
    {
        $context = $this->buildModelContext($text);
        return $this->huggingFace->structured([
            ['role' => 'system', 'content' => $this->extractionSystemPrompt()],
            ['role' => 'user', 'content' => "RESUME SOURCE TEXT:\n" . $context],
        ], $schema, $model, (int) config('recruitment_ats.resume_primary_timeout', 80));
    }

    private function verifyWithAI(string $text, array $initial, array $schema, string $model): array
    {
        $verificationPrompt = <<<'PROMPT'
You are the second-pass verifier for HR resume extraction.
Review the proposed extraction against the resume text.
Correct only fields that are directly supported by the source. Remove unsupported guesses.
For every non-empty name/contact/education/employment field, evidence must be a verbatim snippet from the source.
Gender and marital status remain empty unless the source explicitly labels them.
Do not calculate experience from education/projects. Keep only defensible professional employment entries.
Return the corrected object in the exact requested JSON schema and nothing else.
PROMPT;

        return $this->huggingFace->structured([
            ['role' => 'system', 'content' => $verificationPrompt],
            ['role' => 'user', 'content' => "SOURCE RESUME:\n" . $this->buildModelContext($text) . "\n\nPRIMARY EXTRACTION:\n" . json_encode($initial, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)],
        ], $schema, $model, (int) config('recruitment_ats.resume_verify_timeout', 55));
    }

    private function buildModelContext(string $text): string
    {
        $max = max(12000, (int) config('recruitment_ats.resume_model_max_chars', 60000));
        if (mb_strlen($text) <= $max) return $text;

        $sections = [
            'SUMMARY|PROFILE|OBJECTIVE',
            'WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY|EXPERIENCE',
            'EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS',
            'SKILLS|TECHNICAL\s+SKILLS|CORE\s+SKILLS|KEY\s+SKILLS',
            'PROJECTS|KEY\s+PROJECTS',
            'CERTIFICATIONS?|CERTIFICATES',
            'PERSONAL\s+DETAILS|CONTACT',
        ];

        $chunks = [mb_substr($text, 0, 12000)];
        foreach ($sections as $sectionPattern) {
            $pattern = '/\b(?:' . $sectionPattern . ')\b.*?(?=\n\s*\n|\b(?:WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|EDUCATION|ACADEMIC\s+QUALIFICATIONS?|SKILLS|TECHNICAL\s+SKILLS|PROJECTS|CERTIFICATIONS?|PERSONAL\s+DETAILS|REFERENCES)\b|$)/is';
            if (preg_match($pattern, $text, $m)) $chunks[] = mb_substr(trim($m[0]), 0, 14000);
        }
        $chunks[] = mb_substr($text, -6000);

        $unique=[];
        foreach ($chunks as $chunk) {
            $chunk=trim($chunk);
            if ($chunk!=='') $unique[$chunk]=true;
        }
        $out=implode("\n\n--- RESUME SECTION ---\n\n", array_keys($unique));
        return mb_strlen($out) > $max ? mb_substr($out, 0, $max) : $out;
    }
    private function localExtract(string $text): array
    {
        $email = $this->extractEmail($text);
        $phone = $this->extractPhone($text);
        $name = $this->extractName($text, $email, $phone);
        $education = $this->extractEducationText($text);
        return [
            'candidate_name' => $name,
            'candidate_name_evidence' => $name,
            'candidate_email' => $email,
            'candidate_email_evidence' => $email,
            'candidate_mobile' => $phone,
            'candidate_mobile_evidence' => $phone,
            'candidate_gender' => $this->explicitGenderFromText($text),
            'candidate_marital_status' => $this->explicitMaritalFromText($text),
            'candidate_major_text' => $education['major_text'],
            'degree_full' => $education['degree_full'],
            'candidate_exper_count' => $this->extractExplicitOrDateExperience($text),
        ];
    }
    private function extractName(string $text, ?string $email, ?string $phone): ?string
    {
        $header = mb_substr($text, 0, 5000);
        $lines = preg_split('/\R+/u', $header) ?: [];
        $blocked = '/\b(resume|curriculum\s+vitae|cv|profile|about\s+me|professional\s+summary|summary|objective|career\s+objective|experience|work\s+experience|employment|education|academic|qualifications?|skills?|technical\s+skills|projects?|certifications?|achievements?|linkedin|github|email|e-mail|phone|mobile|contact|address|developer|engineer|manager|executive|recruiter|human\s+resources|hr|director|consultant|analyst|specialist|architect|administrator|designer|software|company|inc|ltd|limited|private|pvt|references?)\b/i';

        $candidates = [];
        foreach (array_slice($lines, 0, 35) as $index => $rawLine) {
            $line = trim(preg_replace('/\s+/u', ' ', $rawLine) ?? $rawLine);
            if ($line === '') continue;

            $clean = $line;
            if ($email) $clean = str_ireplace($email, ' ', $clean);
            if ($phone) $clean = preg_replace('/(?:\+?91[\s\-()]*)?(?:0[\s\-()]*)?[6-9](?:[\s\-()]?\d){9}\b/', ' ', $clean) ?? $clean;
            $clean = trim(preg_replace('/\s+/u', ' ', $clean) ?? $clean, "|,;:.- ");
            $clean = preg_replace('/^(?:candidate\s+)?(?:full\s+)?name\s*[:\-–—]\s*/i', '', $clean) ?? $clean;
            $clean = trim($clean, "|,;:.- ");

            if (!$this->looksLikeName($clean) || preg_match($blocked, $clean)) continue;

            $score = 0;
            $wordCount = count(preg_split('/\s+/u', $clean) ?: []);
            $score += max(0, 35 - ($index * 2));
            $score += min(20, $wordCount * 4);
            if (preg_match('/^[A-Z][A-Z .\'\-]+$/u', $clean)) $score += 8;
            if (preg_match('/^\p{Lu}[\p{Ll}.\'\-]+(?:\s+\p{Lu}[\p{Ll}.\'\-]+)+$/u', $clean)) $score += 10;
            if (preg_match('/\b(?:mr|mrs|ms|miss|dr)\.?\s+/i', $clean)) $score += 3;
            if (preg_match('/\b(?:bangalore|chennai|madurai|india|tamil\s+nadu|india)\b/i', $clean)) $score -= 25;
            $candidates[] = ['name' => $this->formatCandidateName($clean), 'score' => $score, 'line' => $clean];
        }

        usort($candidates, fn ($a, $b) => $b['score'] <=> $a['score']);
        return $candidates[0]['name'] ?? null;
    }

    private function formatCandidateName(string $name): string
    {
        $name = trim(preg_replace('/\s+/u', ' ', $name) ?? $name);
        $name = preg_replace('/^(?:mr|mrs|ms|miss|dr)\.?\s+/i', '', $name) ?? $name;
        $parts = preg_split('/\s+/u', trim($name)) ?: [];
        $formatted = [];

        foreach ($parts as $part) {
            if ($part === '') continue;
            if (preg_match('/^[A-Za-z]\.$/u', $part)) {
                $formatted[] = strtoupper($part);
                continue;
            }
            $formatted[] = mb_convert_case(mb_strtolower($part, 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
        }

        return trim(implode(' ', $formatted));
    }
    private function looksLikeName(string $value): bool
    {
        $value = trim($value);
        $words = preg_split('/\s+/u', $value) ?: [];
        if (count($words) < 2 || count($words) > 5 || mb_strlen($value) < 3 || mb_strlen($value) > 90) return false;

        foreach ($words as $word) {
            if (!preg_match('/^\p{L}[\p{L}.\'\-]*$/u', $word)) return false;
        }

        $blockedWords = '/\b(resume|cv|curriculum|profile|about\s+me|summary|objective|experience|employment|education|academic|qualification|skills?|projects?|certifications?|contact|reference|references|developer|engineer|manager|executive|recruiter|human\s+resources|software)\b/i';
        return !preg_match($blockedWords, $value);
    }
    private function extractEmail(string $text): ?string
    {
        preg_match_all('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $text, $m, PREG_OFFSET_CAPTURE);
        $best = null;
        $bestScore = -INF;

        foreach ($m[0] ?? [] as $hit) {
            $email = strtolower(trim((string) $hit[0]));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) continue;
            if (str_contains($email, 'example.')) continue;

            $position = (int) ($hit[1] ?? 0);
            $context = strtolower(substr($text, max(0, $position - 240), 480));
            $score = $position < 2000 ? 15 : 0;

            if (preg_match('/\b(email|e-mail|mail|contact|personal)\b/', $context)) $score += 20;
            if (preg_match('/\b(recruiter|hr|reference|referee|emergency|manager|company|support|info|admin)\b/', $context)) $score -= 30;
            if (preg_match('/\b(?:gmail|outlook|hotmail|yahoo|proton)\b/i', $email)) $score += 3;

            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $email;
            }
        }

        return $best;
    }

    private function validateIndianContactEmail(?string $value): ?string
    {
        $value = strtolower(trim((string) $value));
        return $value !== '' && filter_var($value, FILTER_VALIDATE_EMAIL) ? $value : null;
    }
    private function extractPhone(string $text): ?string
    {
        // Accept common Indian resume variants: +91..., 0091..., 0..., or bare
        // 10-digit mobile. The final canonical value is always 10 digits.
        preg_match_all('/(?:00\s*91|[\+]?91|0)?[\s\-().]*[6-9](?:[\s\-().]*\d){9}\b/', $text, $m, PREG_OFFSET_CAPTURE);

        $best = null;
        $bestScore = -INF;

        foreach ($m[0] ?? [] as $hit) {
            $phone = $this->cleanPhone((string) $hit[0]);
            if (!$phone) continue;

            $position = (int) ($hit[1] ?? 0);
            $context = strtolower(substr($text, max(0, $position - 240), 480));
            $score = $position < 2000 ? 15 : 0;

            if (preg_match('/\b(mobile|phone|contact|tel|telephone|cell|whatsapp)\b/', $context)) $score += 20;
            if (preg_match('/\b(emergency|reference|referee|parent|father|mother|recruiter|hr|manager)\b/', $context)) $score -= 35;

            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $phone;
            }
        }

        return $best;
    }

    private function cleanPhone(?string $value): ?string
    {
        if (!$value) return null;
        $digits = preg_replace('/\D+/', '', (string) $value) ?? '';

        if (str_starts_with($digits, '0091')) $digits = substr($digits, 4);
        if (strlen($digits) === 12 && str_starts_with($digits, '91')) $digits = substr($digits, 2);
        if (strlen($digits) === 11 && str_starts_with($digits, '0')) $digits = substr($digits, 1);

        return preg_match('/^[6-9]\d{9}$/', $digits) ? $digits : null;
    }


    private function extractExplicitGender(string $text): ?int
    {
        if (preg_match('/\b(?:gender|sex)\s*[:\-]\s*(male|m)\b/i',$text)) return 1;
        if (preg_match('/\b(?:gender|sex)\s*[:\-]\s*(female|f)\b/i',$text)) return 2;
        return null;
    }

    private function explicitGenderFromText(string $text): ?int
    {
        return $this->extractExplicitGender($text);
    }

    private function extractExplicitMarital(string $text): ?int
    {
        if (preg_match('/\b(?:marital\s+status|marital)\s*[:\-]\s*(married)\b/i',$text)) return 1;
        if (preg_match('/\b(?:marital\s+status|marital)\s*[:\-]\s*(single|unmarried|not\s+married)\b/i',$text)) return 2;
        return null;
    }

    private function explicitMaritalFromText(string $text): ?int
    {
        return $this->extractExplicitMarital($text);
    }
    private function extractEducationText(string $text): array
    {
        $section = $text;
        if (preg_match('/\b(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS?)\b(.*?)(?=\b(?:WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|PROJECTS?|CERTIFICATIONS?|SKILLS|TECHNICAL\s+SKILLS|PERSONAL\s+DETAILS|REFERENCES)\b|$)/is', $text, $m)) {
            $section = $m[1];
        }

        $degreePatterns = [
            '\b(?:Bachelor(?:\'s)?|Master(?:\'s)?|Doctor(?:ate)?|Diploma|Higher\s+Secondary|Secondary)\b',
            '\b(?:B\.?\s*(?:Tech|E|Sc|CA|Com|A|BA|BBA|BCA)|M\.?\s*(?:Tech|E|Sc|CA|Com|A|BA)|MBA|MCA|M\.?\s*Com|B\.?\s*Com|Ph\.?D|LL\.?B|LL\.?M)\b',
            '\b(?:12th|10th|Plus\s*Two|HSC|SSLC)\b',
        ];

        $candidates = [];
        foreach (preg_split('/\R+/u', $section) ?: [] as $rawLine) {
            $line = trim(preg_replace('/\s+/u', ' ', $rawLine) ?? $rawLine);
            if ($line === '' || !preg_match('/' . implode('|', $degreePatterns) . '/i', $line)) continue;

            $degreeFull = $line;
            $major = null;

            // Keep institution/year information outside the specialization.
            $degreeFull = preg_replace('/\b(?:19|20)\d{2}\b.*$/', '', $degreeFull) ?? $degreeFull;
            $degreeFull = preg_replace('/\s*(?:-|–|—|\|)\s*(?:cgpa|percentage|score|grade|university|college).*$/i', '', $degreeFull) ?? $degreeFull;
            $degreeFull = trim($degreeFull, " ,;:-");

            if (preg_match('/\b(?:in|with|speciali[sz]ation\s+in|major\s+in)\s+(.+?)(?=\s+(?:from|at|@)\s+|$)/i', $degreeFull, $m)) {
                $major = trim((string) $m[1]);
            } else {
                $major = $this->inferMajorFromDegree($degreeFull);
            }

            $candidates[] = [
                'degree_full' => trim(preg_replace('/\s+/u', ' ', $degreeFull) ?? $degreeFull),
                'major_text' => $major ? trim($major, " ,;:-") : null,
                'evidence' => $line,
            ];
        }

        usort($candidates, function (array $a, array $b): int {
            return $this->degreeRank($b['degree_full']) <=> $this->degreeRank($a['degree_full']);
        });

        return $candidates[0] ?? [
            'degree_full' => null,
            'major_text' => null,
            'evidence' => '',
        ];
    }

    private function inferMajorFromDegree(string $degree): ?string
    {
        $value = trim(preg_replace('/\s+/u', ' ', $degree) ?? $degree);
        $value = preg_replace('/^\s*(?:Bachelor(?:\'s)?|Master(?:\'s)?|Doctor(?:ate)?|Diploma)\s+(?:of\s+)?/i', '', $value) ?? $value;
        $value = preg_replace('/^\s*(?:B\.?\s*(?:Tech|E|Sc|CA|Com|A|BA|BBA|BCA)|M\.?\s*(?:Tech|E|Sc|CA|Com|A|BA)|MBA|MCA|M\.?\s*Com|B\.?\s*Com|Ph\.?D|LL\.?B|LL\.?M)\s*/i', '', $value) ?? $value;
        $value = preg_replace('/^(?:science|engineering|technology|commerce|arts|computer applications)\s*/i', '', $value) ?? $value;
        $value = trim($value, " ,;:-");

        return $value !== '' ? $value : null;
    }
    private function resolveEducation(string $text, array $ai): array
    {
        return $this->educationCatalog->resolve(
            $text,
            is_array($ai['education'] ?? null) ? $ai['education'] : [],
            $this->extractEducationText($text)
        );
    }
    private function degreeRank(string $value): int
    {
        $u = $this->canonical($value);
        return match (true) {
            preg_match('/\bPHD\b|\bDOCTORATE\b|DOCTOR OF PHILOSOPHY/', $u) => 70,
            preg_match('/\bPG\b|\bMASTER\b|M TECH|MTECH|M E|ME|M SC|MSC|MBA|MCA|M COM|M A|LL M/', $u) => 60,
            preg_match('/\bUG\b|\bBACHELOR\b|B TECH|BTECH|B E|BE|B SC|BSC|BCA|BCOM|B COM|B A|BA|BBA|MBBS|B PHARM|B ARCH|B ED|LL B/', $u) => 50,
            preg_match('/\bDIPLOMA\b/', $u) => 40,
            preg_match('/\bHSC\b|\bHIGHER SECONDARY\b|\bPLUS TWO\b|\b12TH\b/', $u) => 20,
            preg_match('/\bSSLC\b|\bSECONDARY\b|\b10TH\b/', $u) => 10,
            default => 0,
        };
    }


    private function qualificationBucket(string $value): ?string
    {
        $u=$this->canonical($value);
        if(preg_match('/\bPHD\b|DOCTORATE|DOCTOR OF PHILOSOPHY/',$u)) return 'Doctorate';
        if(preg_match('/\bMASTER\b|M TECH|MTECH|M E|ME|M SC|MSC|MBA|MCA|M COM|M A/',$u)) return 'PG';
        if(str_contains($u,'DIPLOMA')) return 'Diploma';
        if(preg_match('/\bBACHELOR\b|B TECH|BTECH|B E|BE|B SC|BSC|BCA|BCOM|B COM|B A|BA|BBA|MBBS|B PHARM|B ARCH|B ED/',$u)) return 'UG';
        if(str_contains($u,'HSC')) return 'HSC';
        if(str_contains($u,'SSLC')) return 'SSLC';
        return null;
    }

    private function majorSimilarity(string $target,string $name,string $description): float
    {
        if($target===''||$name==='')return 0;
        if($target===$name||str_contains($target,$name)||str_contains($name,$target))return 1.0;
        $tw=array_values(array_filter(explode(' ',$target)));$nw=array_values(array_filter(explode(' ',$name)));$dw=array_values(array_filter(explode(' ',$description)));
        $generic=['B','BE','BTECH','BACHELOR','M','ME','MTECH','MASTER','OF','IN','THE','ENGINEERING','TECHNOLOGY'];
        $tw=array_values(array_diff($tw,$generic));$nw=array_values(array_diff($nw,$generic));$dw=array_values(array_diff($dw,$generic));
        if(!$tw||!$nw)return 0;
        $common=count(array_intersect($tw,$nw));$nameCoverage=$common/count($nw);$targetCoverage=$common/count($tw);
        $descCommon=count(array_intersect($tw,$dw));$descCoverage=$descCommon/max(1,count($tw));
        return max(($nameCoverage*0.70)+($targetCoverage*0.30),$descCoverage*0.85);
    }
    private function validatedExperienceEntries(string $text, array $ai): array
    {
        $out = [];
        foreach ((array) ($ai['employment'] ?? []) as $entry) {
            if (!is_array($entry)) continue;

            $evidence = trim((string) ($entry['evidence'] ?? ''));
            $title = trim((string) ($entry['title'] ?? ''));
            $company = trim((string) ($entry['company'] ?? ''));
            $type = strtolower(trim((string) ($entry['employment_type'] ?? '')));
            $professional = (bool) ($entry['is_professional'] ?? false);
            $block = $title . ' ' . $company . ' ' . $type . ' ' . $evidence;

            if ($evidence === '' || !$this->evidenceSupports('', $evidence, $text, 'employment')) continue;
            if (!$professional) continue;

            if (preg_match('/\b(intern(?:ship)?|trainee|apprentice|volunteer|student|academic\s+project|coursework|training\s+programme|training\s+program)\b/i', $block)) {
                continue;
            }

            $ranges = $this->parseDateRangesFromText($evidence);
            if (!$ranges) {
                $start = trim((string) ($entry['start_date'] ?? ''));
                $end = trim((string) ($entry['end_date'] ?? ''));
                if ($start !== '' && $end !== '') {
                    $ranges = [['start' => $start, 'end' => $end]];
                }
            }

            $validRanges = [];
            foreach ($ranges as $range) {
                $start = $this->parseMonth((string) ($range['start'] ?? ''));
                $end = $this->parseMonth((string) ($range['end'] ?? ''));
                if ($start !== null && $end !== null && $end >= $start && $end <= ($this->currentMonthIndex() + 1)) {
                    $validRanges[] = [
                        'start_date' => trim((string) ($range['start'] ?? '')),
                        'end_date' => trim((string) ($range['end'] ?? '')),
                    ];
                }
            }

            $out[] = [
                'title' => $title,
                'company' => $company,
                'start_date' => $validRanges[0]['start_date'] ?? trim((string) ($entry['start_date'] ?? '')),
                'end_date' => $validRanges[0]['end_date'] ?? trim((string) ($entry['end_date'] ?? '')),
                'employment_type' => $type,
                'is_professional' => true,
                'ranges' => $validRanges,
                'evidence' => mb_substr($evidence, 0, 2500),
            ];
        }

        return array_values(array_filter($out, fn ($entry) => !empty($entry['ranges']) || ($entry['start_date'] !== '' && $entry['end_date'] !== '')));
    }
    private function calculateExperienceYears(string $text, array $entries, array $ai): float
    {
        $ranges = [];

        foreach ($entries as $entry) {
            $entryRanges = (array) ($entry['ranges'] ?? []);
            if (!$entryRanges && ($entry['start_date'] ?? '') !== '' && ($entry['end_date'] ?? '') !== '') {
                $entryRanges = [[
                    'start_date' => $entry['start_date'],
                    'end_date' => $entry['end_date'],
                ]];
            }

            foreach ($entryRanges as $range) {
                $startText = trim((string) ($range['start_date'] ?? $range['start'] ?? ''));
                $endText = trim((string) ($range['end_date'] ?? $range['end'] ?? ''));

                $start = $this->parseMonth($startText);
                $end = $this->parseMonth($endText);
                if ($start === null || $end === null || $end < $start) continue;

                if (!$this->dateRangeEvidenceSupports($startText, $endText, (string) ($entry['evidence'] ?? ''), $text)) continue;

                // Never count an impossible future employment range as current
                // experience.
                if ($end > $this->currentMonthIndex() + 1) continue;
                $ranges[] = [$start, $end];
            }
        }

        $covered = [];
        foreach ($ranges as [$start, $end]) {
            for ($month = $start; $month < $end; $month++) {
                $covered[$month] = true;
            }
        }

        if ($covered) {
            return min(60, round(count($covered) / 12, 1));
        }

        $explicit = (float) ($ai['explicit_total_experience_years'] ?? 0);
        $explicitEvidence = trim((string) ($ai['explicit_total_experience_evidence'] ?? ''));
        if ($explicit > 0 && $explicit <= 60 && $explicitEvidence !== '' &&
            $this->evidenceSupports('', $explicitEvidence, $text, 'experience_total') &&
            preg_match('/\b(?:experience|worked|work)\b/i', $explicitEvidence)) {
            return round($explicit, 1);
        }

        return 0.0;
    }
    private function extractExplicitOrDateExperience(string $text): float
    {
        $best = 0.0;

        $summaryPatterns = [
            '/\b(?:total|overall|professional|relevant)\s+(?:work\s+)?experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\b/i',
            '/\b(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\s+of\s+(?:professional|work|industry|relevant)\s+experience\b/i',
        ];

        foreach ($summaryPatterns as $pattern) {
            if (preg_match_all($pattern, $text, $m)) {
                foreach ($m[1] as $value) {
                    $v = (float) $value;
                    if ($v >= 0 && $v <= 60) $best = max($best, $v);
                }
            }
        }

        $section = $text;
        if (preg_match('/\b(?:WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY|EXPERIENCE)\b(.*?)(?=\b(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS?|PROJECTS?|CERTIFICATIONS?|SKILLS|TECHNICAL\s+SKILLS|PERSONAL\s+DETAILS|REFERENCES)\b|$)/is', $text, $m)) {
            $section = $m[1];
        }

        $covered = [];
        foreach (preg_split('/\R+/u', $section) ?: [] as $line) {
            if (preg_match('/\b(intern(?:ship)?|trainee|apprentice|volunteer|student|academic|coursework|training)\b/i', $line)) continue;

            foreach ($this->parseDateRangesFromText($line) as $range) {
                $start = $this->parseMonth((string) ($range['start'] ?? ''));
                $end = $this->parseMonth((string) ($range['end'] ?? ''));
                if ($start === null || $end === null || $end < $start) continue;
                if ($end > $this->currentMonthIndex() + 1) continue;

                for ($month = $start; $month < $end; $month++) $covered[$month] = true;
            }
        }

        if ($covered) $best = max($best, round(count($covered) / 12, 1));
        return min(60, round($best, 1));
    }
    private function parseMonth(string $value): ?int
    {
        $v = trim($value);
        if ($v === '') return null;

        if (preg_match('/\b(?:present|current|now|till\s+date|to\s+date)\b/i', $v)) {
            return $this->currentMonthIndex();
        }

        $map = [
            'jan'=>1,'january'=>1,'feb'=>2,'february'=>2,'mar'=>3,'march'=>3,'apr'=>4,'april'=>4,
            'may'=>5,'jun'=>6,'june'=>6,'jul'=>7,'july'=>7,'aug'=>8,'august'=>8,
            'sep'=>9,'sept'=>9,'september'=>9,'oct'=>10,'october'=>10,'nov'=>11,'november'=>11,
            'dec'=>12,'december'=>12,
        ];

        if (preg_match('/\b([A-Za-z]+)\s+((?:19|20)\d{2})\b/i', $v, $m)) {
            $month = $map[strtolower($m[1])] ?? null;
            return $month ? ((int) $m[2] * 12 + $month) : null;
        }

        if (preg_match('/\b((?:19|20)\d{2})\s*[-\/.]\s*(\d{1,2})\b/', $v, $m)) {
            $month = max(1, min(12, (int) $m[2]));
            return (int) $m[1] * 12 + $month;
        }

        // Common Indian resume date format: MM/YYYY.
        if (preg_match('/\b(\d{1,2})\s*[-\/.]\s*((?:19|20)\d{2})\b/', $v, $m)) {
            $month = max(1, min(12, (int) $m[1]));
            return (int) $m[2] * 12 + $month;
        }

        if (preg_match('/\b((?:19|20)\d{2})\b/', $v, $m)) {
            return (int) $m[1] * 12 + 1;
        }

        return null;
    }

    private function currentMonthIndex(): int
    {
        $now = now();
        return ((int) $now->format('Y')) * 12 + (int) $now->format('n');
    }

    private function parseDateRangesFromText(string $value): array
    {
        $months = '(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)';
        $date = '(?:' . $months . '\s+((?:19|20)\d{2})|\d{1,2}\s*[-\/.]\s*(?:19|20)\d{2}|(?:19|20)\d{2}(?:\s*[-\/.]\s*\d{1,2})?)';
        $pattern = '/(?<start>' . $date . ')\s*(?:-|–|—|to|until|through)\s*(?<end>Present|Current|Now|' . $date . ')/i';

        preg_match_all($pattern, $value, $matches, PREG_SET_ORDER);
        $out = [];

        foreach ($matches as $match) {
            $start = trim((string) ($match['start'] ?? ''));
            $end = trim((string) ($match['end'] ?? ''));
            if ($start !== '' && $end !== '') {
                $out[] = ['start' => $start, 'end' => $end];
            }
        }

        return $out;
    }

    private function dateRangeEvidenceSupports(string $start, string $end, string $evidence, string $text): bool
    {
        if ($evidence === '') return false;
        $candidate = $this->canonical($evidence);

        $startYear = $this->extractYear($start);
        if ($startYear === null || !str_contains($candidate, (string) $startYear)) return false;

        $isCurrentEnd = preg_match('/\b(?:present|current|now|till\s+date|to\s+date)\b/i', $end) === 1;
        if ($isCurrentEnd) {
            if (!preg_match('/\b(?:present|current|now|till\s+date|to\s+date)\b/i', $evidence)) return false;
        } else {
            $endYear = $this->extractYear($end);
            if ($endYear === null || !str_contains($candidate, (string) $endYear)) return false;
        }

        $startMonth = $this->extractMonthName($start);
        if ($startMonth !== null && !str_contains($candidate, $startMonth)) return false;

        $endMonth = $this->extractMonthName($end);
        if ($endMonth !== null && !$isCurrentEnd && !str_contains($candidate, $endMonth)) return false;

        return $this->evidenceSupports('', $evidence, $text, 'employment');
    }

    private function extractYear(string $value): ?int
    {
        return preg_match('/\b((?:19|20)\d{2})\b/', $value, $m) ? (int) $m[1] : null;
    }

    private function extractMonthName(string $value): ?string
    {
        if (preg_match('/\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\b/i', $value, $m)) {
            return $this->canonical($m[1]);
        }
        return null;
    }

    private function dateAppearsInEvidence(string $date, string $evidence, string $text): bool
    {
        $year = $this->extractYear($date);
        if ($year === null) return false;
        if (!str_contains($this->canonical($evidence), (string) $year)) return false;
        return $this->evidenceSupports('', $evidence, $text, 'employment');
    }


    private function fieldConfidence(array $data, array $education, string $text): array
    {
        $educationStatus = (string) ($education['resolution_status'] ?? 'manual_review');

        return [
            'candidate_name' => !empty($data['candidate_name'])
                ? ($data['field_evidence']['candidate_name']['verified'] ? 99 : 75) : 0,
            'candidate_email' => !empty($data['candidate_email']) ? 99 : 0,
            'candidate_mobile' => !empty($data['candidate_mobile']) ? 99 : 0,
            'candidate_gender' => $data['candidate_gender'] !== null ? 99 : 0,
            'candidate_marital_status' => $data['candidate_marital_status'] !== null ? 99 : 0,
            'candidate_qualification' => !empty($data['candidate_qualification'])
                ? (($education['qualification_score'] ?? 0) >= 95 ? 98 : 90) : (!empty($data['degree_full']) ? 60 : 0),
            'candidate_major' => !empty($data['candidate_major'])
                ? ($educationStatus === 'resolved' ? max(95, (int) ($education['major_score'] ?? 0)) : 80)
                : (!empty($data['candidate_major_text']) ? 60 : 0),
            'candidate_exper_count' => (float) $data['candidate_exper_count'] > 0
                ? ($data['employment_entries'] ? 98 : 88) : 0,
        ];
    }
    private function manualReviewFields(array $data, array $education): array
    {
        $review = [];

        foreach (['candidate_name', 'candidate_email', 'candidate_mobile'] as $field) {
            if (empty($data[$field])) $review[] = $field;
        }

        if (empty($data['candidate_qualification']) && empty($data['degree_full'])) {
            $review[] = 'candidate_qualification';
        }

        if (($education['resolution_status'] ?? '') === 'manual_review') {
            $review[] = 'candidate_major';
        } elseif (empty($data['candidate_major']) && empty($data['candidate_major_text'])) {
            $review[] = 'candidate_major';
        }

        if ((float) ($data['candidate_exper_count'] ?? 0) <= 0 && empty($data['experience_evidence'])) {
            $review[] = 'candidate_exper_count';
        }

        return array_values(array_unique($review));
    }


    private function overallConfidence(array $data): int
    {
        $weights=['candidate_name'=>20,'candidate_email'=>15,'candidate_mobile'=>15,'candidate_qualification'=>15,'candidate_major'=>20,'candidate_exper_count'=>15];
        $score=0.0;$fields=$data['field_confidence']??[];
        foreach($weights as $field=>$weight)$score+=(($fields[$field]??0)/100)*$weight;
        if(!empty($data['manual_review_fields']))$score=min($score,84);
        return (int)round(max(0,min(100,$score)));
    }
    private function evidenceSupports(string $value, string $evidence, string $text, string $type = 'field'): bool
    {
        $evidence = $this->canonical($evidence);
        $textCanonical = $this->canonical($text);
        $valueCanonical = $this->canonical($value);

        if ($evidence !== '' && str_contains($textCanonical, $evidence)) return true;
        if ($valueCanonical !== '' && str_contains($textCanonical, $valueCanonical)) return true;

        if ($evidence === '') return false;

        $tokens = array_values(array_filter(explode(' ', $evidence), fn ($v) => mb_strlen($v) >= 3));
        $textTokens = array_flip(explode(' ', $textCanonical));
        $hits = 0;
        foreach (array_unique($tokens) as $token) {
            if (isset($textTokens[$token])) $hits++;
        }

        if ($type === 'name') return count($tokens) >= 2 && ($hits / max(1, count(array_unique($tokens)))) >= 0.85;
        return count($tokens) >= 3 && ($hits / max(1, count(array_unique($tokens)))) >= 0.75;
    }

    private function nameEvidenceSupports(string $name, string $evidence, string $text): bool
    {
        if (!$this->looksLikeName($name)) return false;
        if (preg_match('/\b(?:about\s+me|summary|objective|experience|education|skills?)\b/i', $evidence)) return false;
        return $this->evidenceSupports($name, $evidence, $text, 'name');
    }

    private function fieldProvenance(array $data, array $education, string $text, array $ai): array
    {
        $fields = [];
        foreach (['candidate_name','candidate_email','candidate_mobile','candidate_gender','candidate_marital_status','candidate_qualification','candidate_major','candidate_exper_count'] as $field) {
            $item = $data['field_evidence'][$field] ?? [];
            $fields[$field] = [
                'value' => $data[$field] ?? null,
                'method' => match ($field) {
                    'candidate_email','candidate_mobile' => 'deterministic_contact_parser',
                    'candidate_name' => !empty($data['candidate_name']) && !empty($data['ai_identity_review']['name_raw']) ? 'header_parser+ai_verifier' : 'header_parser',
                    'candidate_gender','candidate_marital_status' => 'explicit_label_only',
                    'candidate_qualification','candidate_major' => 'db_master_entity_resolution',
                    'candidate_exper_count' => !empty($data['employment_entries']) ? 'employment_timeline_union' : 'explicit_resume_total',
                    default => 'source_evidence',
                },
                'verified' => (bool) ($item['verified'] ?? false),
                'evidence' => mb_substr((string) ($item['evidence'] ?? ''), 0, 1000),
                'confidence' => (float) data_get($data, "field_confidence.$field", 0),
            ];
        }

        $fields['_meta'] = [
            'education_status' => $education['resolution_status'] ?? 'manual_review',
            'education_candidates' => $education['candidates'] ?? [],
            'model_schema' => config('recruitment_ats.resume_parser_version', 'resume_parser.v5'),
        ];

        return $fields;
    }


    private function explicitAiFieldSupported(array $ai,string $field,string $text): bool
    {
        $value=(string)($ai['identity'][$field]??'');$evidence=(string)($ai['identity'][$field.'_evidence']??'');
        return $value!==''&&$evidence!==''&&$this->evidenceSupports($value,$evidence,$text,$field);
    }
    private function fieldEvidence(?string $value, string $evidence, string $text, string $type = 'field'): array
    {
        $value = trim((string) $value);
        $evidence = trim($evidence);
        $verified = $value !== '' && $this->evidenceSupports($value, $evidence, $text, $type);
        return [
            'value' => $value !== '' ? $value : null,
            'evidence' => mb_substr($evidence, 0, 1000),
            'verified' => $verified,
        ];
    }


    private function explicitLabelEvidence(string $text,array $labels): string
    {
        foreach($labels as $label){if(preg_match('/'.preg_quote($label,'/').'\s*[:\-]?\s*[^\n|]{0,80}/i',$text,$m))return trim($m[0]);}
        return '';
    }

    private function experienceEvidence(array $entries,string $text): array
    {
        return array_values(array_unique(array_map(fn($e)=>$e['evidence'],array_filter($entries,fn($e)=>!empty($e['evidence'])))));
    }

    private function stringArray(mixed $values): array
    {
        if(!is_array($values))return [];
        return array_values(array_unique(array_filter(array_map(fn($v)=>mb_substr(trim((string)$v),0,300),$values))));
    }

    private function cleanName(?string $name): ?string
    {
        $name = trim(preg_replace('/\s+/u', ' ', (string) $name) ?? '');
        $name = trim($name, "|,;:.- ");
        if ($name === '' || !$this->looksLikeName($name)) return null;
        return $this->formatCandidateName($name);
    }

    private function canonical(string $text): string
    {
        $text = mb_strtoupper(strip_tags($text), 'UTF-8');
        $text = str_replace(['&', '/', '\\', '-', '–', '—', '.', ',', '(', ')', ':', '|', '_', ';'], ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        return trim($text);
    }

    private function buildMeta(array $documentMeta, array $data, bool $aiAttempted, bool $aiVerified, array $errors, float $started, array $ai): array
    {
        return [
            'engine' => 'rules+source-evidence+hf-structured+db-entity-resolution+verification',
            'extension' => $documentMeta['extension'] ?? null,
            'original_name' => $documentMeta['original_name'] ?? null,
            'bytes' => (int) ($documentMeta['bytes'] ?? 0),
            'text_length' => null,
            'ocr_used' => (bool) ($documentMeta['ocr_used'] ?? false),
            'ai_configured' => $this->huggingFace->token() !== null,
            'ai_attempted' => $aiAttempted,
            'ai_verified' => $aiVerified,
            'ai_errors' => $errors,
            'primary_model' => $aiAttempted ? config('recruitment_ats.resume_primary_model') : null,
            'verifier_model' => $aiVerified ? config('recruitment_ats.resume_verifier_model') : null,
            'parser_version' => config('recruitment_ats.resume_parser_version', 'resume_parser.v5'),
            'processing_ms' => (int) round((microtime(true) - $started) * 1000),
            'experience_entry_count' => count($data['employment_entries'] ?? []),
            'education_entry_count' => count($data['education_entries'] ?? []),
            'education_resolution_status' => $data['education_resolution_status'] ?? null,
            'manual_review_fields' => $data['manual_review_fields'] ?? [],
        ];
    }
}
