# Recruitment ATS v6 — Production Deployment

## Scope

This release is isolated to the recruitment candidate extraction and ATS role-matching stack. Existing ERP candidate, HR, finance, vendor, and other modules are not rewritten.

## Pipeline

`Resume file -> document text/OCR -> deterministic field extraction -> primary HF structured extraction -> independent verification -> master-data entity resolution -> field provenance -> candidate save`

`Candidate resume -> complete active role catalogue -> hybrid lexical + embedding retrieval -> top semantic candidates to LLM -> deterministic scoring for ALL active roles -> mandatory requirement gates -> persisted analysis/matches -> advanced ATS modal`

The LLM is not the final authority for IDs, contacts, dates, or the final match score. The database masters and backend evidence rules are the source of truth.

## New additive tables

- `egc_recruitment_role_requirements`
- `egc_recruitment_major_aliases`
- `egc_recruitment_qualification_aliases`
- `egc_recruitment_skill_aliases`
- `egc_applicant_resume_extraction_fields`

## New additive ATS columns

`egc_applicant_ats_role_analyses` now stores catalogue size, semantic candidate count, candidate extraction confidence, review state, retrieval model, and scoring version.

`egc_applicant_ats_role_matches` now stores semantic score, education score, mandatory-skill coverage, education coverage, candidate/required experience, confidence, and scoring version.

## Environment

Recommended production settings:

```dotenv
RECRUITMENT_ATS_ENABLED=true
RECRUITMENT_RESUME_AI_ENABLED=true
RECRUITMENT_RESUME_VERIFICATION_ENABLED=true
RECRUITMENT_ATS_MODEL=<approved-structured-generation-model>
RECRUITMENT_RESUME_PRIMARY_MODEL=<approved-resume-extraction-model>
RECRUITMENT_RESUME_VERIFIER_MODEL=<approved-verifier-model>
RECRUITMENT_EMBEDDING_MODEL=BAAI/bge-m3
RECRUITMENT_ROLE_EMBEDDING_ENABLED=true
RECRUITMENT_ROLE_RETRIEVAL_LIMIT=24
RECRUITMENT_ATS_MINIMUM_MATCH_SCORE=70
RECRUITMENT_ATS_STRONG_MATCH_SCORE=85
RECRUITMENT_ATS_NEAR_MATCH_MIN_SCORE=45
RECRUITMENT_ATS_MANUAL_REVIEW_SCORE_CAP=79
```

Use `RECRUITMENT_HF_EMBEDDING_URL` only when a dedicated inference endpoint is available. Otherwise the service uses the Hugging Face feature-extraction router endpoint.

## DB deployment

1. Back up the production `egc` database.
2. Run `database/recruitment_ats/2026_09_28_recruitment_ats_v6.sql`.
3. Verify the new tables exist and the existing ATS tables still contain their prior rows.
4. Deploy the changed PHP/Blade files.
5. Run `php artisan config:clear` and `php artisan cache:clear`.
6. Restart PHP-FPM/Apache or the relevant application workers.
7. Ensure the Laravel queue driver is asynchronous for bulk ATS and that the `ats-role-matching` queue is running.
8. Re-analyse a controlled test group before bulk reprocessing all candidates.

## Accuracy controls

- Candidate name is extracted from candidate identity/header context and title-cased for display.
- Indian mobile persistence requires a 10-digit number beginning with 6–9 after canonicalization.
- Gender and marital status are populated only from explicit labels in the source; they are never inferred from a person's name, religion, photograph, or pronouns.
- Qualification/major resolution is restricted to active `egc_qualification_level` / `egc_major` masters and uses aliases plus ambiguity/manual-review gates.
- Experience is reconstructed from evidenced professional date ranges, supports `Present/Current/Now`, removes internship/trainee/project/training periods, and unions overlapping months instead of double-counting them.
- The final role score is recomputed server-side. Missing mandatory skills, minimum experience, or required education cap the match rather than allowing a model-generated high score to bypass hard requirements.
- Every active ATS-enabled company role is deterministically evaluated; the top-N setting only controls which roles receive the expensive semantic LLM pass.

## Important operational point

No resume parser can honestly guarantee literal 100% accuracy across arbitrary malformed scans, ambiguous names, or contradictory source documents. The production design therefore favors evidence, deterministic normalization, database master matching, independent verification, and explicit manual review over silently inventing a value.
