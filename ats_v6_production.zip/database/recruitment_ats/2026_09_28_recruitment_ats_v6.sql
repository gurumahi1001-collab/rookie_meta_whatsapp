-- EGC Recruitment ATS v6 - additive production migration
-- Target: MariaDB 10.4+
-- Scope: recruitment ATS only. No existing business data is deleted or rewritten.
-- Run once after taking the normal production DB backup.

SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET NAMES utf8mb4;

-- 1) Versioned, structured role requirements.
-- Existing egc_recruitment_roles remains the role identity/source-of-truth.
-- This table stores optional ATS criteria without forcing a schema change into the role master.
CREATE TABLE IF NOT EXISTS egc_recruitment_role_requirements (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    role_sno BIGINT UNSIGNED NOT NULL,
    version_no INT UNSIGNED NOT NULL DEFAULT 1,
    title_override VARCHAR(150) DEFAULT NULL,
    description TEXT DEFAULT NULL,
    mandatory_skills_json LONGTEXT DEFAULT NULL,
    preferred_skills_json LONGTEXT DEFAULT NULL,
    responsibilities_json LONGTEXT DEFAULT NULL,
    education_requirements_json LONGTEXT DEFAULT NULL,
    minimum_experience_years DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    maximum_experience_years DECIMAL(5,2) DEFAULT NULL,
    seniority_level TINYINT UNSIGNED DEFAULT NULL,
    status TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0=Active,1=Inactive,2=Deleted',
    effective_from DATETIME DEFAULT NULL,
    created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
    updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_recruitment_role_requirement_version (role_sno, version_no),
    KEY idx_recruitment_role_requirements_role_status (role_sno, status),
    KEY idx_recruitment_role_requirements_effective (effective_from)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2) Education alias/entity-resolution layer.
CREATE TABLE IF NOT EXISTS egc_recruitment_major_aliases (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    major_sno INT NOT NULL,
    qualification_id INT NOT NULL DEFAULT 0,
    alias_name VARCHAR(250) NOT NULL,
    alias_type TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0=Synonym,1=Abbreviation,2=Full degree wording,3=Legacy/Misspelling',
    match_enabled TINYINT UNSIGNED NOT NULL DEFAULT 1,
    status TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0=Active,1=Inactive,2=Deleted',
    created_by INT NOT NULL DEFAULT 0,
    updated_by INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_recruitment_major_alias (major_sno, alias_name),
    KEY idx_recruitment_major_alias_lookup (qualification_id, major_sno, match_enabled, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_recruitment_qualification_aliases (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    qualification_sno INT NOT NULL,
    alias_name VARCHAR(150) NOT NULL,
    alias_type TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0=Synonym,1=Abbreviation,2=Common wording,3=Legacy wording',
    match_enabled TINYINT UNSIGNED NOT NULL DEFAULT 1,
    status TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0=Active,1=Inactive,2=Deleted',
    created_by INT NOT NULL DEFAULT 0,
    updated_by INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_recruitment_qualification_alias (qualification_sno, alias_name),
    KEY idx_recruitment_qualification_alias_lookup (qualification_sno, match_enabled, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3) Dynamic skill alias/entity-resolution layer.
CREATE TABLE IF NOT EXISTS egc_recruitment_skill_aliases (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    canonical_skill VARCHAR(150) NOT NULL,
    alias_name VARCHAR(150) NOT NULL,
    alias_type TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0=Synonym,1=Abbreviation,2=Legacy/Common wording,3=Version variant',
    match_enabled TINYINT UNSIGNED NOT NULL DEFAULT 1,
    status TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0=Active,1=Inactive,2=Deleted',
    created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
    updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_recruitment_skill_alias (canonical_skill, alias_name),
    KEY idx_recruitment_skill_alias_lookup (match_enabled, status, canonical_skill)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4) Field-level extraction audit/provenance.
CREATE TABLE IF NOT EXISTS egc_applicant_resume_extraction_fields (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    extraction_sno BIGINT UNSIGNED NOT NULL,
    applicant_sno BIGINT UNSIGNED NOT NULL,
    field_name VARCHAR(80) NOT NULL,
    field_value LONGTEXT DEFAULT NULL,
    normalized_value LONGTEXT DEFAULT NULL,
    source_method VARCHAR(40) NOT NULL DEFAULT 'deterministic',
    confidence DECIMAL(5,2) DEFAULT NULL,
    verification_status VARCHAR(30) NOT NULL DEFAULT 'verified',
    evidence_text TEXT DEFAULT NULL,
    evidence_hash CHAR(64) DEFAULT NULL,
    model_name VARCHAR(255) DEFAULT NULL,
    parser_version VARCHAR(60) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_resume_extraction_field (extraction_sno, field_name),
    KEY idx_resume_extraction_fields_applicant (applicant_sno, field_name),
    KEY idx_resume_extraction_fields_status (verification_status),
    KEY idx_resume_extraction_fields_evidence_hash (evidence_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5) Additive ATS analysis columns.
ALTER TABLE egc_applicant_ats_role_analyses
    ADD COLUMN IF NOT EXISTS role_catalog_size INT UNSIGNED NOT NULL DEFAULT 0 AFTER match_count,
    ADD COLUMN IF NOT EXISTS semantic_candidate_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER role_catalog_size,
    ADD COLUMN IF NOT EXISTS candidate_data_confidence DECIMAL(5,2) DEFAULT NULL AFTER semantic_candidate_count,
    ADD COLUMN IF NOT EXISTS review_required TINYINT(1) NOT NULL DEFAULT 0 AFTER candidate_data_confidence,
    ADD COLUMN IF NOT EXISTS retrieval_model VARCHAR(255) DEFAULT NULL AFTER review_required,
    ADD COLUMN IF NOT EXISTS scoring_version VARCHAR(80) DEFAULT NULL AFTER retrieval_model;

CREATE INDEX IF NOT EXISTS idx_ats_analysis_catalog_size
    ON egc_applicant_ats_role_analyses (role_catalog_size, processed_at);
CREATE INDEX IF NOT EXISTS idx_ats_analysis_review_required
    ON egc_applicant_ats_role_analyses (review_required, processed_at);

-- 6) Additive ATS match columns.
ALTER TABLE egc_applicant_ats_role_matches
    ADD COLUMN IF NOT EXISTS semantic_fit_score DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER match_score,
    ADD COLUMN IF NOT EXISTS education_alignment_score DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER skill_alignment_score,
    ADD COLUMN IF NOT EXISTS mandatory_skill_coverage DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER education_alignment_score,
    ADD COLUMN IF NOT EXISTS education_requirement_coverage DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER mandatory_skill_coverage,
    ADD COLUMN IF NOT EXISTS candidate_experience_years DECIMAL(5,1) NOT NULL DEFAULT 0.0 AFTER education_requirement_coverage,
    ADD COLUMN IF NOT EXISTS required_experience_years DECIMAL(5,1) NOT NULL DEFAULT 0.0 AFTER candidate_experience_years,
    ADD COLUMN IF NOT EXISTS confidence_score DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER required_experience_years,
    ADD COLUMN IF NOT EXISTS scoring_version VARCHAR(80) DEFAULT NULL AFTER confidence_score;

CREATE INDEX IF NOT EXISTS idx_ats_role_matches_applicant_decision_score
    ON egc_applicant_ats_role_matches (applicant_sno, decision, match_score);
CREATE INDEX IF NOT EXISTS idx_ats_role_matches_confidence
    ON egc_applicant_ats_role_matches (confidence_score, match_score);

-- 7) Qualification aliases. IDs are from the supplied production dump.
INSERT IGNORE INTO egc_recruitment_qualification_aliases
    (qualification_sno, alias_name, alias_type, match_enabled, status, created_by, updated_by)
VALUES
    (1, 'Bachelor', 0, 1, 0, 0, 0),
    (1, "Bachelor's", 0, 1, 0, 0, 0),
    (1, 'Undergraduate', 2, 1, 0, 0, 0),
    (1, 'UG', 1, 1, 0, 0, 0),
    (2, 'Master', 0, 1, 0, 0, 0),
    (2, "Master's", 0, 1, 0, 0, 0),
    (2, 'Postgraduate', 2, 1, 0, 0, 0),
    (2, 'PG', 1, 1, 0, 0, 0),
    (3, 'PhD', 1, 1, 0, 0, 0),
    (3, 'Ph.D', 1, 1, 0, 0, 0),
    (3, 'Doctor of Philosophy', 2, 1, 0, 0, 0),
    (4, '12th', 1, 1, 0, 0, 0),
    (4, '12th Standard', 2, 1, 0, 0, 0),
    (4, 'Plus Two', 0, 1, 0, 0, 0),
    (5, '10th', 1, 1, 0, 0, 0),
    (5, '10th Standard', 2, 1, 0, 0, 0),
    (5, 'Secondary School', 0, 1, 0, 0, 0),
    (7, 'Diploma', 0, 1, 0, 0, 0);

-- 8) Major aliases for the supplied master data. These are additive and safe to re-run.
INSERT IGNORE INTO egc_recruitment_major_aliases
    (major_sno, qualification_id, alias_name, alias_type, match_enabled, status, created_by, updated_by)
VALUES
    (1, 1, 'B.Com Computer Applications', 2, 1, 0, 0, 0),
    (3, 2, 'Master of Computer Applications', 2, 1, 0, 0, 0),
    (3, 2, 'MCA', 1, 1, 0, 0, 0),
    (4, 2, 'Master of Science', 2, 1, 0, 0, 0),
    (5, 1, 'Bachelor of Science', 2, 1, 0, 0, 0),
    (5, 1, 'BSc', 1, 1, 0, 0, 0),
    (6, 1, 'Bachelor of Computer Applications', 2, 1, 0, 0, 0),
    (7, 2, 'Master of Commerce', 2, 1, 0, 0, 0),
    (9, 1, 'Bachelor of Technology', 2, 1, 0, 0, 0),
    (10, 2, 'Master of Business Administration', 2, 1, 0, 0, 0),
    (11, 1, 'Bachelor of Commerce', 2, 1, 0, 0, 0),
    (12, 1, 'Bachelor of Arts', 2, 1, 0, 0, 0),
    (13, 1, 'Bachelor of Business Administration', 2, 1, 0, 0, 0),
    (15, 3, 'Doctor of Philosophy', 2, 1, 0, 0, 0),
    (21, 2, 'Master of Technology', 2, 1, 0, 0, 0),
    (26, 2, 'MSc IT', 1, 1, 0, 0, 0),
    (26, 2, 'M.Sc IT', 1, 1, 0, 0, 0),
    (26, 2, 'Master of Science in Information Technology', 2, 1, 0, 0, 0),
    (27, 2, 'MSc CS', 1, 1, 0, 0, 0),
    (27, 2, 'M.Sc CS', 1, 1, 0, 0, 0),
    (27, 2, 'Master of Science in Computer Science', 2, 1, 0, 0, 0),
    (33, 2, 'M.Com Computer Applications', 2, 1, 0, 0, 0),
    (40, 1, 'BSc Computer Science', 2, 1, 0, 0, 0),
    (40, 1, 'B.Sc CS', 1, 1, 0, 0, 0),
    (40, 1, 'BSc CS', 1, 1, 0, 0, 0),
    (40, 1, 'Bachelor of Science in Computer Science', 2, 1, 0, 0, 0),
    (40, 1, 'Bachelor of Science Computer Science', 2, 1, 0, 0, 0),
    (41, 1, 'BSc IT', 1, 1, 0, 0, 0),
    (41, 1, 'B.Sc IT', 1, 1, 0, 0, 0),
    (41, 1, 'Bachelor of Science in Information Technology', 2, 1, 0, 0, 0),
    (56, 2, 'ME Software Engineering', 1, 1, 0, 0, 0),
    (56, 2, 'M.E Software Engineering', 1, 1, 0, 0, 0),
    (57, 2, 'MTech IT', 1, 1, 0, 0, 0),
    (57, 2, 'M.Tech IT', 1, 1, 0, 0, 0),
    (57, 2, 'Master of Technology in Information Technology', 2, 1, 0, 0, 0),
    (58, 2, 'ME CSE', 1, 1, 0, 0, 0),
    (58, 2, 'M.E CSE', 1, 1, 0, 0, 0),
    (58, 2, 'Master of Engineering in Computer Science and Engineering', 2, 1, 0, 0, 0),
    (62, 1, 'BE EEE', 1, 1, 0, 0, 0),
    (67, 1, 'BE Artificial Intelligence and Data Science', 2, 1, 0, 0, 0),
    (68, 1, 'BE Artificial Intelligence and Machine Learning', 2, 1, 0, 0, 0),
    (69, 1, 'BTech IT', 1, 1, 0, 0, 0),
    (69, 1, 'B.Tech IT', 1, 1, 0, 0, 0),
    (69, 1, 'Bachelor of Technology in Information Technology', 2, 1, 0, 0, 0),
    (76, 1, 'BE CSE', 1, 1, 0, 0, 0),
    (76, 1, 'B.E CSE', 1, 1, 0, 0, 0),
    (76, 1, 'B.E. Computer Science and Engineering', 2, 1, 0, 0, 0),
    (76, 1, 'Bachelor of Engineering in Computer Science and Engineering', 2, 1, 0, 0, 0),
    (78, 1, 'BE ECE', 1, 1, 0, 0, 0),
    (78, 1, 'Bachelor of Engineering in Electronics and Communication Engineering', 2, 1, 0, 0, 0),
    (80, 1, 'BE IT', 1, 1, 0, 0, 0),
    (80, 1, 'B.E IT', 1, 1, 0, 0, 0),
    (80, 1, 'Bachelor of Engineering in Information Technology', 2, 1, 0, 0, 0),
    (83, 2, 'MBA HR and Marketing', 2, 1, 0, 0, 0),
    (86, 1, 'Bachelor of Science in Information Technology', 2, 1, 0, 0, 0),
    (88, 2, 'Master of Computer Applications', 2, 1, 0, 0, 0),
    (88, 2, 'MCA', 1, 1, 0, 0, 0),
    (89, 1, 'Bachelor of Commerce', 2, 1, 0, 0, 0),
    (89, 1, 'B.Com', 1, 1, 0, 0, 0),
    (90, 1, 'Bachelor of Commerce from Madras University', 2, 1, 0, 0, 0),
    (94, 2, 'Master of Business Management', 2, 1, 0, 0, 0),
    (95, 1, 'Bachelor of Commerce (B.Com)', 2, 1, 0, 0, 0),
    (100, 1, 'BTech Information and Communication Technology', 2, 1, 0, 0, 0);

-- 9) Practical default skill aliases. HR can extend this table without code changes.
INSERT IGNORE INTO egc_recruitment_skill_aliases
    (canonical_skill, alias_name, alias_type, match_enabled, status, created_by, updated_by)
VALUES
    ('javascript', 'JS', 1, 1, 0, 0, 0),
    ('typescript', 'TS', 1, 1, 0, 0, 0),
    ('react', 'ReactJS', 0, 1, 0, 0, 0),
    ('react', 'React JS', 0, 1, 0, 0, 0),
    ('react', 'React.js', 0, 1, 0, 0, 0),
    ('nodejs', 'Node.js', 0, 1, 0, 0, 0),
    ('nodejs', 'Node JS', 0, 1, 0, 0, 0),
    ('nodejs', 'NodeJS', 0, 1, 0, 0, 0),
    ('postgresql', 'Postgres', 0, 1, 0, 0, 0),
    ('postgresql', 'PostgreSQL', 0, 1, 0, 0, 0),
    ('mongodb', 'MongoDB', 0, 1, 0, 0, 0),
    ('rest api', 'RESTful API', 0, 1, 0, 0, 0),
    ('rest api', 'REST API', 0, 1, 0, 0, 0),
    ('artificial intelligence', 'AI', 1, 1, 0, 0, 0),
    ('machine learning', 'ML', 1, 1, 0, 0, 0),
    ('generative ai', 'GenAI', 1, 1, 0, 0, 0),
    ('generative ai', 'Generative AI', 0, 1, 0, 0, 0);

COMMIT;
