<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\api\StaffMobileApiController;

// Existing endpoint retained.
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});



Route::prefix('v1/staff')->name('api.staff.')->group(function () {
    Route::post('/login', [StaffMobileApiController::class, 'login'])
        ->middleware('throttle:5,1')
        ->name('login');

    Route::middleware(['auth.jwt'])->group(function () {
        Route::get('/profile', [StaffMobileApiController::class, 'profile'])->name('profile');
        Route::get('/profile/photo', [StaffMobileApiController::class, 'photo'])->name('profile.photo');
        Route::post('/leave-requests', [StaffMobileApiController::class, 'leaveRequest'])->name('leave.request');
        Route::post('/check-in', [StaffMobileApiController::class, 'checkIn'])->name('attendance.checkin');
        Route::post('/check-out', [StaffMobileApiController::class, 'checkOut'])->name('attendance.checkout');
        Route::get('/attendance-history', [StaffMobileApiController::class, 'attendanceHistory'])->name('attendance.history');
        Route::post('/logout', [StaffMobileApiController::class, 'logout'])->name('logout');
    });
});