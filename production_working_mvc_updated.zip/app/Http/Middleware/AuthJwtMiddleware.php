<?php

namespace App\Http\Middleware;

use App\Models\HR\StaffModel;
use Closure;
use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;

class AuthJwtMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        $bearerToken = $request->bearerToken();
        if (!$bearerToken) {
            return response()->json(['success' => false, 'status' => 401, 'message' => 'Bearer token is required.'], 401);
        }

        $token = PersonalAccessToken::query()
            ->where('token', hash('sha256', $bearerToken))
            ->where(function ($query) {
                $query->whereNull('expires_at')->orWhere('expires_at', '>', now());
            })
            ->first();

        if (!$token || $token->tokenable_type !== StaffModel::class || !$token->tokenable) {
            return response()->json(['success' => false, 'status' => 401, 'message' => 'Bearer token is invalid or expired.'], 401);
        }

        $request->attributes->set('mobile_access_token', $token);
        $staff = $token->tokenable;
        $request->setUserResolver(static fn () => $staff);

        return $next($request);
    }
}
