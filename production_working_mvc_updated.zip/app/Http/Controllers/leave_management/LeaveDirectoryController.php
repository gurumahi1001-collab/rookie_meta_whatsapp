<?php

namespace App\Http\Controllers\leave_management;

use App\Http\Controllers\Controller;
use App\Services\HR\LeaveService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class LeaveDirectoryController extends Controller
{
    public function __construct(private LeaveService $leaveService) {}

    public function index(Request $request, string $type)
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:120'], 'employee' => ['nullable', 'string', 'max:120'],
            'leave_type' => ['nullable', 'string', 'max:80'],
            'status' => ['nullable', Rule::in(['ALL', 'Pending', 'Approved', 'Rejected'])],
            'leave_status' => ['nullable', Rule::in(['ALL', 'Pending', 'Approved', 'Rejected'])],
            'from_date' => ['nullable', 'date_format:Y-m-d'], 'to_date' => ['nullable', 'date_format:Y-m-d', 'after_or_equal:from_date'],
            'page' => ['nullable', 'integer', 'min:1'], 'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);
        $p = $this->leaveService->paginate($type, array_merge(['per_page' => 10], $filters));
        return response()->json([
            'success' => true, 'data' => $p->items(), 'meta' => $this->meta($p),
            'summary' => $this->leaveService->summary($type, $filters),
        ]);
    }

    public function entitlements(Request $request, string $type)
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:120'], 'as_of' => ['nullable', 'date_format:Y-m-d'],
            'page' => ['nullable', 'integer', 'min:1'], 'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);
        $p = $this->leaveService->entitlements($type, array_merge(['per_page' => 10], $filters));
        return response()->json(['success' => true, 'data' => $p->items(), 'meta' => $this->meta($p), 'as_of' => $filters['as_of'] ?? now()->toDateString()]);
    }

    public function storeRequest(Request $request, string $type)
    {
        $v = $request->validate([
            'staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'],
            'leave_type' => ['required', 'string', 'max:80'],
            'from_date' => ['required', 'date_format:Y-m-d'],
            'to_date' => ['required', 'date_format:Y-m-d', 'after_or_equal:from_date'],
            'reason' => ['required', 'string', 'max:2000'],
        ]);
        $leave = $this->leaveService->createRequest((int) $v['staff_id'], $v, $type, $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Leave request submitted for approval.', 'data' => $leave], 201);
    }

    public function review(Request $request, string $type, int $id)
    {
        $v = $request->validate([
            'approval_status' => ['required', Rule::in(['Approved', 'Rejected'])],
            'review_note' => ['nullable', 'string', 'max:1000'],
        ]);
        $this->leaveService->review($id, $v['approval_status'], $v['review_note'] ?? null, $this->actor($request), $type);
        return response()->json(['success' => true, 'message' => $v['approval_status'] === 'Approved' ? 'Leave approved and attendance synchronized.' : 'Leave request rejected.']);
    }

    public function saveEntitlement(Request $request, string $type)
    {
        $v = $request->validate([
            'staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'],
            'leave_type' => ['required', 'string', 'max:80'],
            'annual_days' => ['required', 'numeric', 'min:0', 'max:366'],
            'carry_forward_days' => ['nullable', 'numeric', 'min:0', 'max:366'],
            'as_of' => ['nullable', 'date_format:Y-m-d'],
        ]);
        $this->leaveService->saveEntitlement($type, $v, $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Leave entitlement saved for the staff member’s current joining-date cycle.']);
    }

    public function saveEntitlementsBulk(Request $request, string $type)
    {
        $v = $request->validate([
            'staff_id' => ['required', 'integer', 'exists:ryans_staff,sno'],
            'as_of' => ['nullable', 'date_format:Y-m-d'],
            'entitlements' => ['required', 'array', 'min:1', 'max:20'],
            'entitlements.*.leave_type' => ['required', 'string', 'max:80'],
            'entitlements.*.annual_days' => ['required', 'numeric', 'min:0', 'max:366'],
            'entitlements.*.carry_forward_days' => ['nullable', 'numeric', 'min:0', 'max:366'],
        ]);
        $this->leaveService->saveEntitlementsBulk($type, (int) $v['staff_id'], $v['entitlements'], $this->actor($request), $v['as_of'] ?? null);
        return response()->json(['success' => true, 'message' => 'Leave balance saved for the staff member’s joining-date cycle.']);
    }

    public function batchCredit(Request $request, string $type)
    {
        $v = $request->validate([
            'leave_type' => ['required', 'string', 'max:80'],
            'annual_days' => ['required', 'numeric', 'min:0.01', 'max:366'],
        ]);
        $count = $this->leaveService->creditEntitlementForCategory($type, $v['leave_type'], (float) $v['annual_days'], $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Batch credit applied to ' . $count . ' staff in their current joining-date cycles.', 'data' => ['updated_staff' => $count]]);
    }

    public function batchCreditGroup(Request $request)
    {
        $v = $request->validate([
            'staff_group' => ['required', Rule::in(['Permanent', 'Contract', 'ALL'])],
            'leave_type' => ['required', 'string', 'max:80'],
            'annual_days' => ['required', 'numeric', 'min:0.01', 'max:366'],
        ]);
        $group = match ($v['staff_group']) { 'Permanent' => 'permanent', 'Contract' => 'contract', default => 'all' };
        $count = $this->leaveService->creditEntitlementForGroup($group, $v['leave_type'], (float) $v['annual_days'], $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Batch credit applied to ' . $count . ' staff in their current joining-date cycles.', 'data' => ['updated_staff' => $count]]);
    }

    public function policies(string $type)
    {
        return response()->json(['success' => true, 'data' => $this->leaveService->policies($type)]);
    }

    public function savePolicies(Request $request, string $type)
    {
        $v = $request->validate([
            'policies' => ['required', 'array', 'min:3', 'max:10'],
            'policies.*.leave_type' => ['required', 'string', 'max:80'],
            'policies.*.annual_days' => ['required', 'numeric', 'min:0', 'max:366'],
            'policies.*.carry_forward_enabled' => ['nullable', 'boolean'],
            'policies.*.max_carry_forward_days' => ['nullable', 'numeric', 'min:0', 'max:366'],
            'policies.*.accrual_method' => ['nullable', Rule::in(['annual', 'monthly', 'pro_rata'])],
        ]);
        $this->leaveService->savePolicies($type, $v['policies'], $this->actor($request));
        return response()->json(['success' => true, 'message' => 'Leave policy saved. It applies to future cycle initialization; existing balances were not overwritten.']);
    }

    public function history(Request $request, string $type)
    {
        $filters = $request->validate([
            'staff_id' => ['nullable', 'integer', 'min:1'], 'event_type' => ['nullable', 'string', 'max:40'],
            'search' => ['nullable', 'string', 'max:120'], 'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:5', 'max:100'],
        ]);
        $p = $this->leaveService->history($type, array_merge(['per_page' => 20], $filters));
        return response()->json(['success' => true, 'data' => $p->items(), 'meta' => $this->meta($p)]);
    }

    private function actor(Request $request): int
    {
        return (int) (($request->user()->user_id ?? 0) ?: ($request->user()->id ?? session('user_id', 1)));
    }

    private function meta($p): array
    {
        return ['current_page' => $p->currentPage(), 'last_page' => $p->lastPage(), 'per_page' => $p->perPage(), 'total' => $p->total()];
    }
}
