<?php

namespace App\Http\Controllers\leave_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ContractLeave extends Controller
{
  public function cleave ()
  {
    return view('content.admin_hr.leave_manage.contract_lisst');
  }
}