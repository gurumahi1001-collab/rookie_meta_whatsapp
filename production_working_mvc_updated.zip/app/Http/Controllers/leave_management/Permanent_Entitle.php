<?php

namespace App\Http\Controllers\leave_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Permanent_Entitle extends Controller
{
  public function p_entitle ()
  {
    return view('content.admin_hr.leave_manage.permanent_entitle');
  }
}
