<?php

namespace App\Http\Controllers\payroll\permanent;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PayslipPermanent extends Controller
{
  public function payslip_pcontroller ()
  {
    return view('content.admin_hr.payroll.permanent.payslip_permanent');
  }
}
