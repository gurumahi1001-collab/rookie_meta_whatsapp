<?php

namespace App\Http\Controllers\payroll\permanent;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MonthlyPermanent extends Controller
{
  public function monthly_pcontroller ()
  {
    return view('content.admin_hr.payroll.permanent.monthly_permanent');
  }
}
