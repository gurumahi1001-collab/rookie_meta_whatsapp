<?php

namespace App\Http\Controllers\payroll\contract;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PayslipContract extends Controller
{
  public function payslip_ccontroller ()
  {
    return view('content.admin_hr.payroll.contract.payslip_contract');
  }
}
