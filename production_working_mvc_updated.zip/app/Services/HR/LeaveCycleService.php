<?php

namespace App\Services\HR;

use App\Models\HR\LeaveCycleLedgerModel;
use App\Models\HR\LeavePolicyModel;
use Illuminate\Support\Carbon;
use Illuminate\Support\CarbonPeriod;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Leave-cycle domain service. A leave year is anchored to the staff member's
 * joining anniversary, not January 1. Every allocation/rollover/debit has an
 * immutable audit entry in ryans_leave_cycle_ledger.
 */
class LeaveCycleService
{
    private const TYPES = ['Casual Leave', 'Paid Leave', 'Sick Leave'];

    public function canonicalType(string $type): string
    {
        $key = strtolower(trim(preg_replace('/\s+/', ' ', $type)));
        $compact = preg_replace('/[^a-z]/', '', $key);
        if (in_array($compact, ['cl', 'casual', 'casualleave'], true)) return 'Casual Leave';
        if (in_array($compact, ['pl', 'paid', 'paidleave', 'privilege', 'privilegeleave', 'earnedleave'], true)) return 'Paid Leave';
        if (in_array($compact, ['sl', 'sick', 'sickleave', 'medicalleave'], true)) return 'Sick Leave';
        return trim($type);
    }

    public function typeAliases(string $type): array
    {
        return match ($this->canonicalType($type)) {
            'Casual Leave' => ['Casual Leave', 'Casual', 'CL'],
            'Paid Leave' => ['Paid Leave', 'Privilege Leave', 'Privilege', 'PL', 'Earned Leave'],
            'Sick Leave' => ['Sick Leave', 'Sick', 'SL', 'Medical Leave'],
            default => [trim($type)],
        };
    }

    public function balanceKey(string $type): ?string
    {
        return match ($this->canonicalType($type)) {
            'Casual Leave' => 'Casual',
            'Paid Leave' => 'Privilege',
            'Sick Leave' => 'Sick',
            default => null,
        };
    }

    public function cycleForStaff(int $staffId, ?string $asOf = null): array
    {
        $staff = DB::table('ryans_staff')->where('sno', $staffId)->first(['date_of_joining']);
        if (!$staff) abort(404, 'Staff profile not found.');
        return $this->cycleFromJoiningDate($staff->date_of_joining, $asOf);
    }

    public function cycleFromJoiningDate(?string $joiningDate, ?string $asOf = null): array
    {
        $reference = Carbon::parse($asOf ?: now()->toDateString())->startOfDay();
        if (!$joiningDate) {
            $start = Carbon::create($reference->year, 1, 1)->startOfDay();
            $end = $start->copy()->addYear()->subDay();
            return ['start_date' => $start->toDateString(), 'end_date' => $end->toDateString(), 'cycle_year' => $start->year, 'cycle_basis' => 'calendar_fallback'];
        }
        $joining = Carbon::parse($joiningDate)->startOfDay();
        // A not-yet-joined employee has an upcoming first cycle, never a cycle before hire.
        if ($reference->lt($joining)) {
            $start = $joining->copy();
            $end = $this->anniversary($joining, $joining->year + 1)->subDay();
            return ['start_date' => $start->toDateString(), 'end_date' => $end->toDateString(), 'cycle_year' => $start->year, 'cycle_basis' => 'joining_anniversary'];
        }
        $start = $this->anniversary($joining, $reference->year);
        if ($start->greaterThan($reference)) $start = $this->anniversary($joining, $reference->year - 1);
        $end = $this->anniversary($joining, $start->year + 1)->subDay();
        return ['start_date' => $start->toDateString(), 'end_date' => $end->toDateString(), 'cycle_year' => $start->year, 'cycle_basis' => 'joining_anniversary'];
    }

    private function anniversary(Carbon $joining, int $year): Carbon
    {
        $month = $joining->month;
        $day = min($joining->day, Carbon::create($year, $month, 1)->daysInMonth);
        return Carbon::create($year, $month, $day)->startOfDay();
    }

    /** Count workdays by the current HR screen convention: Sunday and configured holidays are excluded. */
    public function workingDaysBetween(string $from, string $to): int
    {
        $start = Carbon::parse($from)->startOfDay();
        $end = Carbon::parse($to)->startOfDay();
        if ($end->lt($start)) return 0;
        $holidayQuery = DB::table('ryans_holiday')->where('status', 0)
            ->whereDate('hol_date', '<=', $end->toDateString())
            ->whereRaw('COALESCE(hol_end_date, hol_date) >= ?', [$start->toDateString()]);
        $holidayRows = $holidayQuery->get(['hol_date', 'hol_end_date']);
        $holidayDates = [];
        foreach ($holidayRows as $holiday) {
            $hStart = Carbon::parse($holiday->hol_date)->startOfDay();
            $hEnd = Carbon::parse($holiday->hol_end_date ?: $holiday->hol_date)->startOfDay();
            if ($hEnd->lt($hStart)) $hEnd = $hStart->copy();
            foreach (CarbonPeriod::create($hStart, $hEnd) as $day) $holidayDates[$day->toDateString()] = true;
        }
        $count = 0;
        foreach (CarbonPeriod::create($start, $end) as $day) {
            if ($day->dayOfWeek === Carbon::SUNDAY) continue;
            if (isset($holidayDates[$day->toDateString()])) continue;
            $count++;
        }
        return $count;
    }

    public function employmentTypeForStaff(int $staffId): int
    {
        $staff = DB::table('ryans_staff')->where('sno', $staffId)->first(['employment_type']);
        if (!$staff) abort(404, 'Staff profile not found.');
        $employment = (int) ($staff->employment_type ?? 0);
        if (!in_array($employment, [1, 2], true)) {
            $linkedTypes = DB::table('users')->where('user_id', $staffId)->whereIn('staff_type', [1, 2])->distinct()->pluck('staff_type')->map(fn ($value) => (int) $value)->all();
            if (count($linkedTypes) === 1) $employment = $linkedTypes[0];
        }
        if (!in_array($employment, [1, 2], true)) {
            throw ValidationException::withMessages(['staff_id' => 'Employment category is not verified; classify this staff record first.']);
        }
        return $employment;
    }

    /** Creates the current cycle from its policy or a previous verified cycle, and logs all initialization. */
    public function ensureCycle(int $staffId, int $actor = 0, ?string $asOf = null): array
    {
        return DB::transaction(function () use ($staffId, $actor, $asOf) {
            $staff = DB::table('ryans_staff')->where('sno', $staffId)->lockForUpdate()->first(['sno', 'date_of_joining', 'employment_type', 'status', 'hr_status']);
            if (!$staff) abort(404, 'Staff profile not found.');
            $hrStatus = $staff->hr_status ?? match ((int) $staff->status) { 0 => 0, 1, 4 => -1, 2 => 2, 5, 6, 7 => -3, default => -3 };
            if ((int) $hrStatus === 2) abort(404, 'Staff profile not found.');
            $employment = $this->employmentTypeForStaff($staffId);
            $cycle = $this->cycleFromJoiningDate($staff->date_of_joining, $asOf);
            $policyRows = LeavePolicyModel::query()->where('employment_type', $employment)->where('status', 0)->orderBy('sno')->get();
            $policyMap = [];
            foreach ($policyRows as $policy) $policyMap[$this->canonicalType($policy->leave_type)] = $policy;
            foreach (self::TYPES as $leaveType) {
                $policy = $policyMap[$leaveType] ?? $this->defaultPolicy($employment, $leaveType);
                $existing = $this->findCycleEntitlement($staffId, $leaveType, $cycle['start_date']);
                if ($existing) continue;

                // The staff modal wrote calendar-year rows before the anniversary cycle existed.
                // Bind the current-cycle row in place (no data copy or deletion) and preserve its quota.
                $legacy = DB::table('ryans_leave_entitlements')->where('staff_id', $staffId)->where('status', 0)
                    ->whereNull('cycle_start_date')->whereIn('leave_type', $this->typeAliases($leaveType))
                    ->where('year', (int) $cycle['cycle_year'])->orderByDesc('sno')->first();
                if (!$legacy) {
                    $legacy = DB::table('ryans_leave_entitlements')->where('staff_id', $staffId)->where('status', 0)
                        ->whereNull('cycle_start_date')->whereIn('leave_type', $this->typeAliases($leaveType))
                        ->where('year', Carbon::parse($asOf ?: now()->toDateString())->year)->orderByDesc('sno')->first();
                }

                $annualDays = $legacy ? (float) $legacy->annual_days : (float) $policy->annual_days;
                $carryForward = $this->computedCarryForward($staffId, $leaveType, $cycle, $policy);
                $now = now();
                if ($legacy) {
                    DB::table('ryans_leave_entitlements')->where('sno', $legacy->sno)->update([
                        'year' => (int) $cycle['cycle_year'], 'cycle_start_date' => $cycle['start_date'],
                        'cycle_end_date' => $cycle['end_date'], 'carry_forward_days' => $carryForward,
                        'updated_by' => $actor, 'updated_at' => $now,
                    ]);
                    $rowId = (int) $legacy->sno;
                    $this->writeLedger($staffId, $leaveType, $cycle, 'LEGACY_CYCLE_BOUND', 0, $annualDays + $carryForward, 'ryans_leave_entitlements', $rowId,
                        ['legacy_year' => (int) $legacy->year, 'legacy_leave_type' => $legacy->leave_type, 'annual_days' => $annualDays, 'carry_forward_days' => $carryForward], $actor);
                } else {
                    $rowId = (int) DB::table('ryans_leave_entitlements')->insertGetId([
                        'staff_id' => $staffId, 'leave_type' => $leaveType, 'annual_days' => $annualDays,
                        'carry_forward_days' => $carryForward, 'year' => (int) $cycle['cycle_year'],
                        'cycle_start_date' => $cycle['start_date'], 'cycle_end_date' => $cycle['end_date'],
                        'created_by' => $actor, 'updated_by' => $actor, 'created_at' => $now, 'updated_at' => $now, 'status' => 0,
                    ]);
                    $this->writeLedger($staffId, $leaveType, $cycle, 'ANNUAL_ALLOCATION', $annualDays, $annualDays + $carryForward, 'ryans_leave_entitlements', $rowId,
                        ['annual_days' => $annualDays, 'employment_type' => $employment, 'policy_id' => $policy->id ?? null, 'cycle_basis' => $cycle['cycle_basis']], $actor);
                }
                if ($carryForward > 0) {
                    $this->writeLedger($staffId, $leaveType, $cycle, 'CARRY_FORWARD', $carryForward, $annualDays + $carryForward,
                        'ryans_leave_entitlements', $rowId, ['source_cycle_end_date' => Carbon::parse($cycle['start_date'])->subDay()->toDateString(), 'carry_forward_cap' => (float) $policy->max_carry_forward_days], $actor);
                }
            }
            $rows = $this->cycleEntitlementRows($staffId, $cycle['start_date']);
            return ['cycle' => $cycle, 'employment_type' => $employment, 'entitlements' => $rows];
        }, 3);
    }

    public function saveStaffModalAllocations(int $staffId, array $data, int $actor): void
    {
        DB::transaction(function () use ($staffId, $data, $actor) {
            $cycleResult = $this->ensureCycle($staffId, $actor);
            $cycle = $cycleResult['cycle'];
            $map = ['casual_leave' => 'Casual Leave', 'paid_leave' => 'Paid Leave', 'sick_leave' => 'Sick Leave'];
            foreach ($map as $field => $leaveType) {
                if (!array_key_exists($field, $data)) continue;
                $this->saveAllocation($staffId, $leaveType, (float) $data[$field], null, $actor, $cycle);
            }
        }, 3);
    }

    public function saveAllocation(int $staffId, string $leaveType, float $annualDays, ?float $carryForwardDays, int $actor, ?array $cycle = null): void
    {
        if ($annualDays < 0 || $annualDays > 366) throw ValidationException::withMessages(['annual_days' => 'Annual leave allocation must be between 0 and 366 days.']);
        $leaveType = $this->canonicalType($leaveType);
        $cycleResult = $cycle ? ['cycle' => $cycle, 'entitlements' => $this->cycleEntitlementRows($staffId, $cycle['start_date'])] : $this->ensureCycle($staffId, $actor);
        $cycle = $cycleResult['cycle'];
        $rows = $this->cycleEntitlementRows($staffId, $cycle['start_date']);
        $row = $this->findCycleEntitlement($staffId, $leaveType, $cycle['start_date']);
        if (!$row) {
            $this->ensureCycle($staffId, $actor, $cycle['start_date']);
            $row = $this->findCycleEntitlement($staffId, $leaveType, $cycle['start_date']);
        }
        if (!$row) throw new \RuntimeException('Could not initialize the leave cycle for this staff member.');
        $policy = $this->policyFor($this->employmentTypeForStaff($staffId), $leaveType);
        $newCarry = $carryForwardDays === null ? (float) $row->carry_forward_days : max(0, min($carryForwardDays, (float) $policy->max_carry_forward_days));
        if ($leaveType !== 'Paid Leave') $newCarry = 0;
        $adjustments = (float) ($row->adjustment_days ?? 0);
        $previousTotal = (float) $row->annual_days + (float) $row->carry_forward_days + $adjustments;
        $nextTotal = $annualDays + $newCarry + $adjustments;
        $now = now();
        DB::table('ryans_leave_entitlements')->where('sno', $row->sno)->update([
            'annual_days' => $annualDays, 'carry_forward_days' => $newCarry,
            'updated_by' => $actor, 'updated_at' => $now, 'status' => 0,
        ]);
        $balance = max(0, $nextTotal - $this->usedDays($staffId, $leaveType, $cycle['start_date'], $cycle['end_date']));
        $this->writeLedger($staffId, $leaveType, $cycle, 'ALLOCATION_ADJUSTMENT', $nextTotal - $previousTotal, $balance,
            'ryans_leave_entitlements', (int) $row->sno, ['old_annual_days' => (float) $row->annual_days, 'new_annual_days' => $annualDays,
                'old_carry_forward_days' => (float) $row->carry_forward_days, 'new_carry_forward_days' => $newCarry, 'adjustment_days' => $adjustments], $actor);
    }

    public function currentBalance(int $staffId, string $leaveType, ?string $asOf = null, int $actor = 0): array
    {
        $cycleResult = $this->ensureCycle($staffId, $actor, $asOf);
        $cycle = $cycleResult['cycle'];
        $row = $this->findCycleEntitlement($staffId, $leaveType, $cycle['start_date']);
        if (!$row) return ['annual_days' => 0.0, 'carry_forward_days' => 0.0, 'entitled' => 0.0, 'used' => 0.0, 'balance' => 0.0, 'cycle' => $cycle];
        $used = $this->usedDays($staffId, $leaveType, $cycle['start_date'], $cycle['end_date']);
        $entitled = (float) $row->annual_days + (float) $row->carry_forward_days + (float) ($row->adjustment_days ?? 0);
        return ['annual_days' => (float) $row->annual_days, 'carry_forward_days' => (float) $row->carry_forward_days,
            'adjustment_days' => (float) ($row->adjustment_days ?? 0), 'entitled' => $entitled, 'used' => $used, 'balance' => max(0, $entitled - $used), 'cycle' => $cycle, 'row_id' => (int) $row->sno];
    }

    /** Validates approved leave against each anniversary cycle it spans. */
    public function validateLeaveAvailability(int $staffId, string $leaveType, string $from, string $to, int $actor = 0): void
    {
        $leaveType = $this->canonicalType($leaveType);
        $start = Carbon::parse($from)->startOfDay();
        $end = Carbon::parse($to)->startOfDay();
        $cursor = $start->copy();
        while ($cursor->lte($end)) {
            $cycle = $this->cycleForStaff($staffId, $cursor->toDateString());
            $segmentEnd = Carbon::parse($cycle['end_date'])->lt($end) ? Carbon::parse($cycle['end_date']) : $end->copy();
            $this->ensureCycle($staffId, $actor, $cursor->toDateString());
            $requestedDays = $this->workingDaysBetween($cursor->toDateString(), $segmentEnd->toDateString());
            $balance = $this->currentBalance($staffId, $leaveType, $cursor->toDateString(), $actor);
            if ($requestedDays > (float) $balance['balance']) {
                throw ValidationException::withMessages(['approval_status' => sprintf(
                    'Insufficient %s balance for %s to %s: %.2f requested, %.2f available in cycle %s to %s.',
                    $leaveType, $cursor->toDateString(), $segmentEnd->toDateString(), (float) $requestedDays,
                    (float) $balance['balance'], $cycle['start_date'], $cycle['end_date']
                )]);
            }
            $cursor = $segmentEnd->copy()->addDay();
        }
    }

    public function logLeaveRequest(int $staffId, string $leaveType, string $from, string $to, int $requestId, float $workingDays, int $actor): void
    {
        $leaveType = $this->canonicalType($leaveType);
        $cursor = Carbon::parse($from)->startOfDay();
        $end = Carbon::parse($to)->startOfDay();
        while ($cursor->lte($end)) {
            $cycle = $this->cycleForStaff($staffId, $cursor->toDateString());
            $segmentEnd = Carbon::parse($cycle['end_date'])->lt($end) ? Carbon::parse($cycle['end_date']) : $end->copy();
            $segmentDays = $this->workingDaysBetween($cursor->toDateString(), $segmentEnd->toDateString());
            $this->writeLedger($staffId, $leaveType, $cycle, 'LEAVE_REQUESTED', 0, null,
                'ryans_leave_requests', $requestId,
                ['from_date' => $cursor->toDateString(), 'to_date' => $segmentEnd->toDateString(),
                    'working_days' => $segmentDays, 'request_working_days_total' => $workingDays, 'approval_status' => 'Pending'], $actor);
            $cursor = $segmentEnd->copy()->addDay();
        }
    }

    public function logLeaveRejection(int $staffId, string $leaveType, string $from, string $to, int $requestId, ?string $note, int $actor): void
    {
        $leaveType = $this->canonicalType($leaveType);
        $cursor = Carbon::parse($from)->startOfDay();
        $end = Carbon::parse($to)->startOfDay();
        while ($cursor->lte($end)) {
            $cycle = $this->cycleForStaff($staffId, $cursor->toDateString());
            $cycleEnd = Carbon::parse($cycle['end_date']);
            $segmentEnd = $cycleEnd->lt($end) ? $cycleEnd : $end->copy();
            $this->writeLedger($staffId, $leaveType, $cycle, 'LEAVE_REJECTED', 0, null,
                'ryans_leave_requests', $requestId,
                ['from_date' => $cursor->toDateString(), 'to_date' => $segmentEnd->toDateString(), 'review_note' => $note], $actor);
            $cursor = $segmentEnd->copy()->addDay();
        }
    }

    public function logLeaveApproval(int $staffId, string $leaveType, string $from, string $to, int $requestId, int $actor): void
    {
        $leaveType = $this->canonicalType($leaveType);
        $cursor = Carbon::parse($from)->startOfDay();
        $end = Carbon::parse($to)->startOfDay();
        while ($cursor->lte($end)) {
            $cycle = $this->cycleForStaff($staffId, $cursor->toDateString());
            $segmentEnd = Carbon::parse($cycle['end_date'])->lt($end) ? Carbon::parse($cycle['end_date']) : $end->copy();
            $days = $this->workingDaysBetween($cursor->toDateString(), $segmentEnd->toDateString());
            $balance = $this->currentBalance($staffId, $leaveType, $cursor->toDateString(), $actor);
            $this->writeLedger($staffId, $leaveType, $cycle, 'LEAVE_APPROVED', -1 * $days, (float) $balance['balance'],
                'ryans_leave_requests', $requestId, ['from_date' => $cursor->toDateString(), 'to_date' => $segmentEnd->toDateString(), 'working_days' => $days], $actor);
            $cursor = $segmentEnd->copy()->addDay();
        }
    }

    public function synchroniseApprovedLeaveToAttendance(int $staffId, string $leaveType, string $from, string $to, int $requestId, int $actor): void
    {
        $start = Carbon::parse($from)->startOfDay();
        $end = Carbon::parse($to)->startOfDay();
        $holidays = $this->holidayDateSet($start->toDateString(), $end->toDateString());
        foreach (CarbonPeriod::create($start, $end) as $day) {
            if ($day->dayOfWeek === Carbon::SUNDAY || isset($holidays[$day->toDateString()])) continue;
            $date = $day->toDateString();
            $attendanceRows = DB::table('ryans_staff_attendance')->where('staff_id', $staffId)->whereDate('date', $date)->where('status', 0)->orderByDesc('sno')->lockForUpdate()->get();
            if ($attendanceRows->contains(static fn ($row) => !empty($row->in_time))) {
                throw ValidationException::withMessages(['approval_status' => 'Cannot approve leave on ' . $date . ': an attendance check-in already exists. Reconcile attendance first.']);
            }
            $attendance = $attendanceRows->first();
            $expectedReason = 'Leave request #' . $requestId . ' — ' . $this->canonicalType($leaveType);

            // Idempotency: existing approved requests may be reconciled by the maintenance
            // command more than once. Do not update the same attendance row or duplicate
            // ATTENDANCE_SYNC ledger entries when it already matches this request.
            if ($attendance
                && strtoupper((string) $attendance->attendance) === 'L'
                && (string) $attendance->type === 'Leave Management'
                && (string) $attendance->reason === $expectedReason
                && empty($attendance->in_time)
                && empty($attendance->out_time)) {
                continue;
            }

            $before = $attendance ? ['attendance_id' => (int) $attendance->sno, 'attendance' => $attendance->attendance, 'in_time' => $attendance->in_time, 'out_time' => $attendance->out_time, 'type' => $attendance->type, 'reason' => $attendance->reason] : null;
            if ($attendance) {
                DB::table('ryans_staff_attendance')->where('sno', $attendance->sno)->update([
                    'attendance' => 'L', 'in_time' => null, 'out_time' => null, 'type' => 'Leave Management',
                    'reason' => 'Leave request #' . $requestId . ' — ' . $this->canonicalType($leaveType), 'updated_by' => $actor, 'updated_at' => now(),
                ]);
                $attendanceId = (int) $attendance->sno;
            } else {
                $attendanceId = (int) DB::table('ryans_staff_attendance')->insertGetId([
                    'staff_attendance_id' => 'LV-' . $requestId . '-' . str_replace('-', '', $date),
                    'date' => $date, 'staff_id' => $staffId, 'attendance' => 'L', 'in_time' => null, 'out_time' => null,
                    'type' => 'Leave Management', 'reason' => 'Leave request #' . $requestId . ' — ' . $this->canonicalType($leaveType),
                    'created_by' => $actor, 'updated_by' => $actor, 'created_at' => now(), 'updated_at' => now(), 'status' => 0,
                ]);
            }
            $cycle = $this->cycleForStaff($staffId, $date);
            $this->writeLedger($staffId, $leaveType, $cycle, 'ATTENDANCE_SYNC', 0, null, 'ryans_staff_attendance', $attendanceId,
                ['leave_request_id' => $requestId, 'date' => $date, 'before' => $before, 'after' => ['attendance' => 'L', 'type' => 'Leave Management']], $actor);
        }
    }

    public function listHistory(string $type, array $filters)
    {
        $query = DB::table('ryans_leave_cycle_ledger as h')->join('ryans_staff as s', 's.sno', '=', 'h.staff_id')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id');
        $employment = $type === 'permanent' ? 1 : 2;
        $query->where(function ($q) use ($employment) {
            $q->where('s.employment_type', $employment)->orWhere(function ($legacy) use ($employment) {
                $legacy->whereNull('s.employment_type')->whereExists(function ($users) use ($employment) {
                    $users->selectRaw('1')->from('users')->whereColumn('users.user_id', 's.sno')->where('users.staff_type', $employment);
                });
            });
        });
        if (!empty($filters['staff_id'])) $query->where('h.staff_id', (int) $filters['staff_id']);
        if (!empty($filters['event_type'])) $query->where('h.event_type', (string) $filters['event_type']);
        if (($filters['search'] ?? '') !== '') {
            $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim((string) $filters['search'])) . '%';
            $query->where(fn ($q) => $q->where('s.staff_name', 'like', $like)->orWhere('s.staff_id', 'like', $like)->orWhere('h.leave_type', 'like', $like));
        }
        return $query->orderByDesc('h.created_at')->orderByDesc('h.sno')->select([
            'h.sno', 'h.staff_id', 's.staff_name', 's.staff_id as staff_code', 'd.department_name', 'h.leave_type',
            'h.cycle_start_date', 'h.cycle_end_date', 'h.event_type', 'h.days_delta', 'h.balance_after',
            'h.reference_type', 'h.reference_id', 'h.details_json', 'h.created_by', 'h.created_at',
        ])->paginate((int) ($filters['per_page'] ?? 20))->withQueryString();
    }

    public function policies(int $employmentType)
    {
        return LeavePolicyModel::query()->where('employment_type', $employmentType)->where('status', 0)->orderBy('sno')->get();
    }

    public function savePolicies(int $employmentType, array $items, int $actor): void
    {
        DB::transaction(function () use ($employmentType, $items, $actor) {
            foreach ($items as $item) {
                $leaveType = $this->canonicalType((string) $item['leave_type']);
                if (!in_array($leaveType, self::TYPES, true)) throw ValidationException::withMessages(['policies' => 'Unknown leave category.']);
                $carryEnabled = $leaveType === 'Paid Leave' ? (int) ($item['carry_forward_enabled'] ?? 1) : 0;
                $carryCap = $carryEnabled ? (float) ($item['max_carry_forward_days'] ?? 30) : 0;
                $existingPolicy = DB::table('ryans_leave_policies')->where('employment_type', $employmentType)->where('leave_type', $leaveType)->first();
                $values = [
                    'annual_days' => (float) $item['annual_days'], 'carry_forward_enabled' => $carryEnabled,
                    'max_carry_forward_days' => $carryCap, 'accrual_method' => $item['accrual_method'] ?? 'annual',
                    'updated_by' => $actor, 'updated_at' => now(), 'status' => 0,
                ];
                if ($existingPolicy) {
                    DB::table('ryans_leave_policies')->where('sno', $existingPolicy->id)->update($values);
                } else {
                    DB::table('ryans_leave_policies')->insert($values + [
                        'employment_type' => $employmentType, 'leave_type' => $leaveType,
                        'created_by' => $actor, 'created_at' => now(),
                    ]);
                }
                $this->writeLedger(0, $leaveType, ['start_date' => null, 'end_date' => null], 'POLICY_UPDATED', 0, null,
                    'ryans_leave_policies', null, ['employment_type' => $employmentType, 'policy' => $item], $actor);
            }
        }, 3);
    }

    public function saveEntitlementsBulk(string $type, int $staffId, array $entitlements, int $actor, ?string $asOf = null): void
    {
        $employment = $type === 'permanent' ? 1 : 2;
        $this->assertCategory($staffId, $employment);
        DB::transaction(function () use ($staffId, $employment, $entitlements, $actor, $asOf) {
            $cycleResult = $this->ensureCycle($staffId, $actor, $asOf);
            foreach ($entitlements as $item) {
                $this->saveAllocation($staffId, (string) $item['leave_type'], (float) $item['annual_days'],
                    array_key_exists('carry_forward_days', $item) ? (float) $item['carry_forward_days'] : null, $actor, $cycleResult['cycle']);
            }
        }, 3);
    }

    public function creditEntitlementForCategory(string $type, string $leaveType, float $days, int $actor): int
    {
        $employment = $type === 'permanent' ? 1 : 2;
        $staff = DB::table('ryans_staff as s')->where(function ($q) use ($employment) {
            $q->where('s.employment_type', $employment)->orWhere(function ($inner) use ($employment) {
                $inner->whereNull('s.employment_type')->whereExists(function ($users) use ($employment) {
                    $users->selectRaw('1')->from('users')->whereColumn('users.user_id', 's.sno')->where('users.staff_type', $employment);
                });
            });
        })->whereRaw("COALESCE(s.hr_status, CASE WHEN s.status = 0 THEN 0 WHEN s.status IN (1,4) THEN -1 WHEN s.status = 2 THEN 2 WHEN s.status IN (5,6,7) THEN -3 ELSE -3 END) = 0")
            ->orderBy('s.sno')->pluck('s.sno');
        $count = 0;
        $leaveType = $this->canonicalType($leaveType);
        if (!in_array($leaveType, self::TYPES, true)) {
            throw ValidationException::withMessages(['leave_type' => 'Unknown leave category.']);
        }
        DB::transaction(function () use ($staff, $leaveType, $days, $actor, &$count) {
            foreach ($staff as $staffId) {
                $cycleResult = $this->ensureCycle((int) $staffId, $actor);
                $row = $this->findCycleEntitlement((int) $staffId, $leaveType, $cycleResult['cycle']['start_date']);
                if (!$row) continue;
                $oldAdjustment = (float) ($row->adjustment_days ?? 0);
                $newAdjustment = $oldAdjustment + $days;
                $used = $this->usedDays((int) $staffId, $leaveType, $cycleResult['cycle']['start_date'], $cycleResult['cycle']['end_date']);
                $balance = max(0, (float) $row->annual_days + (float) ($row->carry_forward_days ?? 0) + $newAdjustment - $used);
                DB::table('ryans_leave_entitlements')->where('sno', $row->sno)->update([
                    'adjustment_days' => $newAdjustment, 'updated_by' => $actor, 'updated_at' => now(),
                ]);
                $this->writeLedger((int) $staffId, $leaveType, $cycleResult['cycle'], 'BATCH_CREDIT', $days, $balance,
                    'ryans_leave_entitlements', (int) $row->sno,
                    ['previous_adjustment_days' => $oldAdjustment, 'new_adjustment_days' => $newAdjustment], $actor);
                $count++;
            }
        }, 3);
        return $count;
    }

    public function usedDays(int $staffId, string $leaveType, string $cycleStart, string $cycleEnd, ?int $excludeRequestId = null): float
    {
        $aliases = $this->typeAliases($leaveType);
        $query = DB::table('ryans_leave_requests')->where('staff_id', $staffId)->where('status', 0)
            ->where('approval_status', 'Approved')->whereIn('leave_type', $aliases)
            ->whereDate('from_date', '<=', $cycleEnd)->whereDate('to_date', '>=', $cycleStart);
        if ($excludeRequestId) $query->where('sno', '<>', $excludeRequestId);
        $requests = $query->get(['sno', 'from_date', 'to_date']);
        $used = 0;
        foreach ($requests as $request) {
            $from = Carbon::parse($request->from_date)->greaterThan(Carbon::parse($cycleStart)) ? Carbon::parse($request->from_date) : Carbon::parse($cycleStart);
            $to = Carbon::parse($request->to_date)->lessThan(Carbon::parse($cycleEnd)) ? Carbon::parse($request->to_date) : Carbon::parse($cycleEnd);
            if ($to->gte($from)) $used += $this->workingDaysBetween($from->toDateString(), $to->toDateString());
        }
        return (float) $used;
    }

    public function writeLedger(int $staffId, string $leaveType, array $cycle, string $eventType, float $delta, ?float $balanceAfter, ?string $referenceType, ?int $referenceId, array $details, int $actor): void
    {
        LeaveCycleLedgerModel::query()->create([
            'staff_id' => $staffId, 'leave_type' => $this->canonicalType($leaveType),
            'cycle_start_date' => $cycle['start_date'] ?? null, 'cycle_end_date' => $cycle['end_date'] ?? null,
            'event_type' => $eventType, 'days_delta' => $delta, 'balance_after' => $balanceAfter,
            'reference_type' => $referenceType, 'reference_id' => $referenceId,
            'details_json' => json_encode($details, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
            'created_by' => $actor, 'created_at' => now(),
        ]);
    }

    private function findCycleEntitlement(int $staffId, string $leaveType, string $cycleStart)
    {
        return DB::table('ryans_leave_entitlements')->where('staff_id', $staffId)->where('status', 0)
            ->whereIn('leave_type', $this->typeAliases($leaveType))->where('cycle_start_date', $cycleStart)->orderByDesc('sno')->first();
    }

    private function cycleEntitlementRows(int $staffId, string $cycleStart)
    {
        return DB::table('ryans_leave_entitlements')->where('staff_id', $staffId)->where('status', 0)
            ->where('cycle_start_date', $cycleStart)->orderBy('sno')->get();
    }

    private function previousAnnualQuota(int $staffId, string $leaveType, array $cycle, float $fallback): float
    {
        $prevStart = Carbon::parse($cycle['start_date'])->subYear()->toDateString();
        $row = $this->findCycleEntitlement($staffId, $leaveType, $prevStart);
        if (!$row) {
            $row = DB::table('ryans_leave_entitlements')->where('staff_id', $staffId)->where('status', 0)
                ->whereIn('leave_type', $this->typeAliases($leaveType))->whereNull('cycle_start_date')
                ->where('year', (int) Carbon::parse($prevStart)->year)->orderByDesc('sno')->first();
        }
        return $row ? (float) $row->annual_days : $fallback;
    }

    private function computedCarryForward(int $staffId, string $leaveType, array $cycle, $policy): float
    {
        if ($this->canonicalType($leaveType) !== 'Paid Leave' || (int) ($policy->carry_forward_enabled ?? 0) !== 1) return 0.0;

        // Resolve the actual preceding cycle from the joining date. Subtracting one year
        // directly fails for leap-day joiners whose anniversaries move to February 28.
        $staff = DB::table('ryans_staff')->where('sno', $staffId)->first(['date_of_joining']);
        if (!$staff) return 0.0;
        $previousReference = Carbon::parse($cycle['start_date'])->subDay()->toDateString();
        $previousCycle = $this->cycleFromJoiningDate($staff->date_of_joining, $previousReference);
        $prevStart = $previousCycle['start_date'];
        $prevEnd = $previousCycle['end_date'];

        $previous = $this->findCycleEntitlement($staffId, $leaveType, $prevStart);
        if (!$previous) {
            $previous = DB::table('ryans_leave_entitlements')->where('staff_id', $staffId)->where('status', 0)
                ->whereIn('leave_type', $this->typeAliases($leaveType))->whereNull('cycle_start_date')
                ->where('year', (int) Carbon::parse($prevStart)->year)->orderByDesc('sno')->first();
        }
        if (!$previous) return 0.0;
        $previousTotal = (float) $previous->annual_days + (float) ($previous->carry_forward_days ?? 0) + (float) ($previous->adjustment_days ?? 0);
        $used = $this->usedDays($staffId, $leaveType, $prevStart, $prevEnd);
        return max(0.0, min((float) ($policy->max_carry_forward_days ?? 30), $previousTotal - $used));
    }

    private function policyFor(int $employmentType, string $leaveType)
    {
        $policy = DB::table('ryans_leave_policies')->where('employment_type', $employmentType)->whereIn('leave_type', $this->typeAliases($leaveType))->where('status', 0)->first();
        return $policy ?: $this->defaultPolicy($employmentType, $leaveType);
    }

    private function defaultPolicy(int $employmentType, string $leaveType): object
    {
        $defaults = [1 => ['Casual Leave' => 12, 'Paid Leave' => 15, 'Sick Leave' => 12], 2 => ['Casual Leave' => 7, 'Paid Leave' => 10, 'Sick Leave' => 7]];
        return (object) ['sno' => null, 'employment_type' => $employmentType, 'leave_type' => $leaveType,
            'annual_days' => $defaults[$employmentType][$this->canonicalType($leaveType)] ?? 0,
            'carry_forward_enabled' => $this->canonicalType($leaveType) === 'Paid Leave' ? 1 : 0,
            'max_carry_forward_days' => $this->canonicalType($leaveType) === 'Paid Leave' ? 30 : 0, 'accrual_method' => 'annual'];
    }

    private function holidayDateSet(string $from, string $to): array
    {
        $rows = DB::table('ryans_holiday')->where('status', 0)->whereDate('hol_date', '<=', $to)
            ->whereRaw('COALESCE(hol_end_date, hol_date) >= ?', [$from])->get(['hol_date', 'hol_end_date']);
        $dates = [];
        foreach ($rows as $row) {
            $start = Carbon::parse($row->hol_date)->startOfDay();
            $end = Carbon::parse($row->hol_end_date ?: $row->hol_date)->startOfDay();
            if ($end->lt($start)) $end = $start->copy();
            foreach (CarbonPeriod::create($start, $end) as $date) $dates[$date->toDateString()] = true;
        }
        return $dates;
    }

    private function assertCategory(int $staffId, int $employmentType): void
    {
        $staff = DB::table('ryans_staff as s')->where('s.sno', $staffId)->where(function ($query) use ($employmentType) {
            $query->where('s.employment_type', $employmentType)->orWhere(function ($legacy) use ($employmentType) {
                $legacy->whereNull('s.employment_type')->whereExists(function ($users) use ($employmentType) {
                    $users->selectRaw('1')->from('users')->whereColumn('users.user_id', 's.sno')->where('users.staff_type', $employmentType);
                });
            });
        })->exists();
        if (!$staff) throw ValidationException::withMessages(['staff_id' => 'Staff does not belong to this employment category.']);
    }
}
