HR / STAFF MODULE PRODUCTION PATCH
==================================

Scope
-----
This patch keeps the existing Blade UI structure and updates the production source for:
- Permanent/contract staff emergency-contact relationship lookups from active ryans_relationship rows.
- Attendance matrix modal initialization, empty-date cell editing, status selection, and shared skeleton/pagination behavior.
- Attendance list/calendar mini-dashboard values from live API summary data.
- Leave list summary/filter/pagination loading and entitlement quota cards from active leave-policy rows.
- Salary/wage KPI values from staff remuneration and current-day attendance; monthly cost projection uses gross/earnings (A) plus employer contributions (C), excluding employee deductions (B).
- Staff mobile API JWT bearer authentication, response handling, GPS attendance metadata, and OpenAPI annotations.
- A guarded reconciliation command for approved leave requests that predate attendance synchronization.

Overlay deployment
------------------
1. Back up the application files and database.
2. Overlay the files in this archive at the root of the complete Laravel application. The patch ZIP contains only changed/new files.
3. Clear cached application data in your complete application:
     php artisan optimize:clear
4. Review existing approved leave requests before changing any attendance:
     php artisan hr:sync-approved-leave-attendance
5. If the dry-run list is expected, take a fresh database backup and apply the reconciliation:
     php artisan hr:sync-approved-leave-attendance --apply
   The command synchronizes only missing/non-matching attendance records, skips rows already synchronized for the same leave request, and reports conflicts where attendance has a check-in. It does not bypass those conflicts.
6. If L5-Swagger is installed in the full application, regenerate and review the API specification:
     php artisan l5-swagger:generate

Database changes
----------------
No ALTER TABLE or CREATE TABLE statement is required for this patch. The supplied database dump already contains the relationship lookup table, leave request/policy/ledger tables, and the GPS attendance columns referenced by the mobile API. The reconciliation command repairs old approved leave/attendance inconsistencies without adding schema.

Validation performed in this workspace
--------------------------------------
- PHP syntax check: 150 PHP files, 0 syntax errors.
- Inline JavaScript syntax check: 20 scripts passed. Two staff Blade script blocks contain Blade template expressions and need to be compiled in the full Laravel runtime.
- The provided source ZIP contains app/, resources/, and routes/ only; it does not contain composer.json, vendor/, or a runnable Laravel test environment. Therefore Laravel feature tests, database transactions, and OpenAPI generation were not executed here.

Scope limitation
----------------
The supplied schema has no loan or promotion transaction tables and the source bundle has no API/controller implementation for those pages. Their existing page UI was left untouched rather than fabricating production dashboard metrics or inventing financial/business rules. The dynamic dashboard fixes in this patch cover attendance, leave, leave entitlements, and salary/wage structure.
