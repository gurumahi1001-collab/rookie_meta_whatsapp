@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

<!-- Navigation Tab Bar -->
<div class="card border-0 shadow-sm rounded-4 mb-4">
    <div class="card-body p-2">
        <div class="nav-scroll-wrapper">

            {{-- Scrollable Tabs Container --}}
            <div class="nav-scroll-container gap-2">

                {{-- Salary Structure & Wages Rate Link --}}
                @php
                $isSalaryActive = request()->is('/admin-hr/wages/contractstaff');
                @endphp
                <a href="{{ url('/admin-hr/wages/contractstaff') }}"
                    class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isSalaryActive ? 'btn-primary text-white' : 'btn-light text-secondary' }}">
                    <i class="mdi mdi-calendar-check-outline me-1"></i>
                    Salary Structure & Wages Rate
                </a>

                {{-- Promotion & Appraisal Link --}}
                @php
                $isPromotionActive = request()->is('/admin-hr/wages/contractstaff/promotion&appraisal');
                @endphp
                <a href="{{ url('/admin-hr/wages/contractstaff/promotion&appraisal') }}"
                    class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isPromotionActive ? 'btn-primary text-white' : 'btn-light text-secondary' }}">
                    <i class="mdi mdi-trending-up me-1"></i>
                    Promotion & Appraisal
                </a>

                {{-- Loan Disbursement & Recovery Link (Active -> Blue) --}}
                @php
                $isLoanActive = true; // Set to true or keep
                request()->is('/admin-hr/wages/contractstaff/LoanDisbursement')
                @endphp
                <a href="{{ url('/admin-hr/payroll/permanent_payslip') }}"
                    class="btn btn-sm rounded-3 text-decoration-none d-inline-flex align-items-center {{ $isLoanActive ? 'btn-primary text-white' : 'btn-light text-secondary' }}">
                    <i class="mdi mdi-cash-refund me-1"></i>
                    Loan Disbursement & Recovery
                </a>
            </div>
        </div>
    </div>
</div>

<div class="appraisal-kpi-grid appraisal-kpi-mobile-scroll row g-3">

    <!-- KPI 1 - DAILY PERSONNEL WAGE OUTPUT -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">
            <div class="stat-icon-wrapper bg-orange-subtle text-orange rounded-3
                        d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-currency-rupee fs-8"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Daily Personnel Wage Output
                </span>
                <span class="stat-value text-primary-dark font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹{{ is_numeric($totalWagesToday ?? null) ? number_format($totalWagesToday) : ($totalWagesToday ?? '0') }}
                </span>

                <span class="stat-description text-muted d-block">
                    Summed from present workforce checks
                </span>
            </div>
        </div>
    </div>


    <!--KPI 2 - AVG DAILY WAGE BASE RATE -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">

        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                d-flex align-items-center gap-3 h-100">

            <!-- Icon -->
            <div class="stat-icon-wrapper bg-blue-subtle text-blue
                    rounded-3 d-flex align-items-center justify-content-center flex-shrink-0">

                <i class="mdi mdi-cash-clock fs-5"></i>

            </div>

            <!-- Content -->
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">

                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Avg Daily Wage Base Rate
                </span>

                <span class="stat-value text-blue font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹850 / Day
                </span>

                <span class="stat-description text-muted d-block">
                    Standard workforce daily rate cadence
                </span>

            </div>

        </div>

    </div>



    <!-- KPI 3 - OVERTIME RATE MULTIPLIER -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">
            <div class="stat-icon-wrapper bg-purple-subtle text-purple rounded-3
            d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-clock-fast fs-4 "></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Overtime Rate Multiplier
                </span>

                <span class="stat-value text-purple font-monospace fw-bolder d-block fs-5 mb-1">
                    1.5x / 2.0x
                </span>

                <span class="stat-description text-muted d-block">
                    Compliant OT rate as per Labour Code
                </span>

            </div>

        </div>

    </div>


    <!-- KPI 4 - MONTHLY TOTAL COST PROJECTION -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">
            <div class="stat-icon-wrapper bg-emerald-subtle text-emerald rounded-3
            d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-chart-line fs-4"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Monthly Total Cost Projection
                </span>
                <span class="stat-value text-emerald font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹{{ is_numeric($totalCostProjection ?? null) ? number_format($totalCostProjection) : ($totalCostProjection ?? '0') }}
                </span>
                <span class="stat-description text-muted d-block">
                    Component A + Component C
                </span>
            </div>
        </div>
    </div>


    <!-- KPI 5 - AVERAGE SALARY HIKE -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">
        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">
            <div class="stat-icon-wrapper bg-blue-subtle text-blue rounded-3
    d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-cash-check fs-4"></i>
            </div>
            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Total Recovered Amount
                </span>
                <span class="stat-value text-blue font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹66,000
                </span>
                <span class="stat-description text-muted d-block">
                    Recovered via payroll & direct installments
                </span>
            </div>
        </div>
    </div>


    <!-- KPI 6 - ANNUAL PAYROLL BUDGET HIKE -->
    <div class="stat-card-item col-6 col-md-4 col-xl-2">

        <div class="stat-card bg-white border border-light-subtle p-3 rounded-4 shadow-sm
                    d-flex align-items-center gap-3 h-100">

            <div class="stat-icon-wrapper bg-indigo-subtle text-indigo rounded-3
            d-flex align-items-center justify-content-center flex-shrink-0">
                <i class="mdi mdi-clock fs-5"></i>
            </div>

            <div class="d-flex flex-column justify-content-center flex-grow-1 min-w-0">
                <span class="stat-label text-uppercase fw-bold text-muted d-block mb-1">
                    Total Pending Balance
                </span>
                <span class="stat-value text-indigo font-monospace fw-bolder d-block fs-5 mb-1">
                    ₹64,000
                </span>
                <span class="stat-description text-muted d-block">
                    Outstanding loan recovery balance
                </span>
            </div>
        </div>
    </div>

</div>

<div
    class="loan-toolbar-card bg-white border border-light-subtle p-3 p-md-4 rounded-4 shadow-sm d-flex flex-column flex-md-row align-items-stretch align-items-md-center justify-content-between gap-3">

    <!-- Left Container: Search & Filter Inputs -->
    <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-2.5 flex-grow-1">

        <!-- Search Bar -->
        <div class="loan-search-wrapper position-relative flex-grow-1">
            <i class="mdi mdi-magnify loan-search-icon position-absolute top-50 translate-middle-y text-secondary"></i>
            <input type="text" id="loanSearchTerm" class="form-control loan-search-input font-semibold"
                placeholder="Search employee, ID or purpose..." />
        </div>

        <!-- Status Filter Select -->
        <div class="loan-filter-wrapper d-flex align-items-center gap-2">
            <i class="mdi mdi-filter-outline text-secondary fs-5"></i>
            <select id="loanStatusFilter" class=" select3 form-select loan-filter-select fw-bold">
                <option value="ALL">All Statuses</option>
                <option value="Active">Active Loans</option>
                <option value="Completed">Completed Loans</option>
                <option value="Pending Approval">Pending Approval</option>
            </select>
        </div>

    </div>

    <!-- Right Container: Action Buttons -->
    <div class="d-flex align-items-center justify-content-end gap-2 loan-action-group">

        <!-- Export CSV Button -->
        <button type="button" id="btnExportLoanCSV"
            class="btn btn-loan-export fw-bold d-inline-flex align-items-center justify-content-center gap-1.5">
            <i class="mdi mdi-download fs-6"></i>
            <span>Export CSV</span>
        </button>

        <!-- Disburse New Loan Button -->
        <button type="button" id="btnDisburseLoan"
            class="btn btn-loan-primary fw-black d-inline-flex align-items-center justify-content-center gap-1.5"
            data-bs-toggle="modal" data-bs-target="#newLoanModal">
            <i class="mdi mdi-plus fs-6"></i>
            <span>Disburse New Loan</span>
        </button>

    </div>

</div>

<div class="loan-table-card">
    <div class="loan-table-responsive">
        <table class="loan-table">
            <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                <tr class="loan-table-header-row">
                    <th class="loan-th loan-th-id min-w-100px ">Loan ID & Date</th>
                    <th class="loan-th loan-th-employee min-w-100px ">Employee Details</th>
                    <th class="loan-th loan-th-amount min-w-100px ">Loan Amount</th>
                    <th class="loan-th loan-th-recovery min-w-100px ">Monthly Recovery</th>
                    <th class="loan-th loan-th-duration min-w-100px ">Duration</th>
                    <th class="loan-th loan-th-collected min-w-100px ">Collected</th>
                    <th class="loan-th loan-th-pending min-w-100px ">Pending</th>
                    <th class="loan-th loan-th-start min-w-100px ">Start Month</th>
                    <th class="loan-th loan-th-status min-w-100px ">Status</th>
                    <th class="loan-th loan-th-actions min-w-100px  ">Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Active Loan Row -->
                <tr class="loan-row">
                    <!-- Loan ID & Date -->
                    <td class="loan-td loan-td-id">
                        <span class="loan-id-text">LN-2026-001</span>
                        <span class="loan-date-text">15 Jan 2026</span>
                    </td>

                    <!-- Employee Details -->
                    <td class="loan-td loan-td-employee">
                        <span class="employee-name-text">John Doe</span>
                        <div class="employee-meta-wrapper">
                            <span class="employee-code-badge">EMP-104</span>
                            <span class="employee-meta-divider">•</span>
                            <span class="employee-dept-text">Engineering</span>
                        </div>
                    </td>
                    <!-- Loan Amount -->
                    <td class="loan-td loan-td-amount">
                        ₹50,000
                    </td>
                    <!-- Monthly Recovery -->
                    <td class="loan-td loan-td-recovery d-flex">
                        <span class="recovery-amount-text">₹5,000</span>
                        <span class="recovery-unit-text ps-3 pt-0">/ month</span>
                    </td>
                    <!-- Duration -->
                    <td class="loan-td loan-td-duration">
                        <span class="duration-badge">
                            10 Mos
                        </span>
                    </td>
                    <!-- Collected -->
                    <td class="loan-td loan-td-collected">
                        ₹20,000
                    </td>
                    <!-- Pending & Progress -->
                    <td class="loan-td loan-td-pending">
                        <span class="pending-amount-text">₹30,000</span>
                        <div class="loan-progress-track">
                            <div class="loan-progress-bar" style="width: 40%;"></div>
                        </div>
                    </td>
                    <!-- Start Month -->
                    <td class="loan-td loan-td-start">
                        Feb 2026
                    </td>
                    <!-- Status Badge -->
                    <td class="loan-td loan-td-status">
                        <span class="loan-status-badge badge-active">
                            <span>Active</span>
                        </span>
                    </td>
                    <!-- Actions -->
                    <td class="loan-td loan-td-actions">
                        <div class="action-buttons-wrapper">
                            <button type="button" class="btn-loan-action btn-recover-action" data-bs-toggle="modal"
                                data-bs-target="#recordLoanRecoveryModal" data-employee="John Doe">
                                <i class="mdi mdi-currency-usd"></i>
                                <span>Recover</span>
                            </button>
                            <button type="button" class="btn-loan-action btn-ledger-action"
                                title="View Loan Repayment Statement" data-bs-toggle="modal"
                                data-bs-target="#ledgerModal">
                                <i class="mdi mdi-file-document-outline"></i>
                                <span>Ledger</span>
                            </button>
                        </div>
                    </td>
                </tr>
                <!-- Completed Loan Row -->
                <tr class="loan-row">
                    <td class="loan-td loan-td-id">
                        <span class="loan-id-text">LN-2025-089</span>
                        <span class="loan-date-text">10 Aug 2025</span>
                    </td>
                    <td class="loan-td loan-td-employee">
                        <span class="employee-name-text">Sarah Smith</span>
                        <div class="employee-meta-wrapper">
                            <span class="employee-code-badge">EMP-208</span>
                            <span class="employee-meta-divider">•</span>
                            <span class="employee-dept-text">Human Resources</span>
                        </div>
                    </td>
                    <td class="loan-td loan-td-amount">₹25,000</td>
                    <td class="loan-td loan-td-recovery d-flex">
                        <span class="recovery-amount-text">₹5,000</span>
                        <span class="recovery-unit-text ps-3 pt-1">/ month</span>
                    </td>
                    <td class="loan-td loan-td-duration">
                        <span class="duration-badge">5 Mos</span>
                    </td>
                    <td class="loan-td loan-td-collected">₹25,000</td>
                    <td class="loan-td loan-td-pending">
                        <span class="pending-amount-text">₹0</span>
                        <div class="loan-progress-track">
                            <div class="loan-progress-bar" style="width: 100%;"></div>
                        </div>
                    </td>
                    <td class="loan-td loan-td-start">Sep 2025</td>
                    <td class="loan-td loan-td-status">
                        <span class="loan-status-badge badge-completed">
                            <span>Completed</span>
                        </span>
                    </td>
                    <td class="loan-td loan-td-actions">
                        <div class="action-buttons-wrapper">
                            <button type="button" class="btn-loan-action btn-recover-action"
                                title="Record Loan Recovery Installment" data-bs-toggle="modal"
                                data-bs-target="#recordLoanRecoveryModal" data-employee="Sarah Smith">
                                <i class="mdi mdi-currency-usd"></i>
                                <span>Recover</span>
                            </button>
                            <button type="button" class="btn-loan-action btn-ledger-action"
                                title="View Loan Repayment Statement" data-bs-toggle="modal"
                                data-bs-target="#ledgerModal">
                                <i class="mdi mdi-file-document-outline"></i>
                                <span>Ledger</span>
                            </button>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Disburse New Loan Modal -->
<div class="modal fade" id="newLoanModal" tabindex="-1" aria-labelledby="newLoanModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content disburse-modal-card ">
            <!-- Modal Header Wrapper -->
            <div class="disburse-modal-header bg-primary ">
                <!-- Title Group -->
                <div class="disburse-modal-title-wrapper pt-2 ps-2">
                    <div class="disburse-modal-icon-box">
                        <i class="mdi mdi-credit-card-outline"></i>
                    </div>
                    <div class="disburse-modal-text-group">
                        <h3 class="disburse-modal-heading text-white" id="newLoanModalLabel">Disburse New Employee Loan
                            /
                            Advance
                        </h3>
                        <p class="disburse-modal-subheading">Provide staff loan and configure monthly salary recovery
                            schedule</p>
                    </div>
                </div>
                <!-- Close Button -->
                <button type="button" class="disburse-modal-close-btn" data-bs-dismiss="modal" aria-label="Close">
                    <i class="mdi mdi-close"></i>
                </button>
            </div>
            <!-- Modal Body -->
            <div class="modal-body disburse-modal-body">
                <form id="disburseLoanForm">
                    <div class="row g-3">

                        <!-- Employee Select -->
                        <div class="col-12 col-md-6">
                            <label for="employeeSelect" class="disburse-form-label">Select Employee</label>
                            <select id="employeeSelect" class="disburse-form-select select3" required>
                                <option value="" selected disabled>Choose employee...</option>
                                <option value="EMP-104">John Doe (EMP-104)</option>
                                <option value="EMP-208">Sarah Smith (EMP-208)</option>
                            </select>
                        </div>

                        <!-- Loan Amount -->
                        <div class="col-12 col-md-6">
                            <label for="loanAmountInput" class="disburse-form-label">Loan Amount (₹)</label>
                            <input type="number" id="loanAmountInput" class="disburse-form-input"
                                placeholder="e.g. 50000" required />
                        </div>

                        <!-- Recovery Duration -->
                        <div class="col-12 col-md-6">
                            <label for="recoveryDurationInput" class="disburse-form-label">Recovery Duration
                                (Months)</label>
                            <input type="number" id="recoveryDurationInput" class="disburse-form-input"
                                placeholder="e.g. 10" required />
                        </div>

                        <!-- Start Month -->
                        <div class="col-12 col-md-6">
                            <label for="startMonthInput" class="disburse-form-label">Start Recovery Month</label>
                            <input type="month" id="startMonthInput" class="disburse-form-input" required />
                        </div>

                        <!-- Loan Purpose / Remarks -->
                        <div class="col-12">
                            <label for="loanPurposeInput" class="disburse-form-label">Purpose / Remarks</label>
                            <textarea id="loanPurposeInput" class="disburse-form-textarea" rows="2"
                                placeholder="Enter loan reason or administrative remarks..."></textarea>
                        </div>

                    </div>
                </form>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer disburse-modal-footer">
                <button type="button" class="btn-disburse-cancel" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="disburseLoanForm" class="btn-disburse-submit">
                    <i class="mdi mdi-check"></i>
                    <span>Confirm & Disburse Loan</span>
                </button>
            </div>

        </div>
    </div>
</div>

<!-- Record Loan Recovery Modal -->
<div class="modal fade" id="recordLoanRecoveryModal" tabindex="-1" aria-labelledby="recordLoanRecoveryModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-body p-3 p-md-4">

                <!-- Modal Header -->
                <div
                    class="salary-recovery-header bg-primary text-white d-flex align-items-center justify-content-between p-3 mb-3 rounded-top">
                    <div class="d-flex align-items-center gap-3">
                        <div class="salary-recovery-icon-box bg-success-subtle text-success p-2 rounded-3 d-flex align-items-center justify-content-center shadow-sm"
                            style="width: 42px; height: 42px;">
                            <i class="mdi mdi-currency-usd fs-4"></i>
                        </div>
                        <div>
                            <h5 class="salary-recovery-title fw-bold text-white mb-0 fs-6"
                                id="recordLoanRecoveryModalLabel">
                                Record Loan Recovery
                            </h5>
                            <p class="salary-recovery-subtitle data-employee text-white-50 mb-0 small"
                                id="modalEmployeeMeta">
                                John Doe
                            </p>
                        </div>
                    </div>

                    <button type="button" class="btn-close btn-close-white shadow-none salary-recovery-close-btn"
                        data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!-- Recovery Form -->
                <form id="formRecordLoanRepayment" class="salary-recovery-form">

                    <!-- Loan Overview Summary Box -->
                    <div
                        class="salary-loan-summary-box bg-emerald-light border border-success-subtle rounded-3 p-3 mb-3">
                        <div class="row text-center font-monospace g-2">
                            <div class="col-4 border-end border-success-subtle">
                                <span
                                    class="salary-summary-label d-block text-muted text-uppercase fw-bold">Principal</span>
                                <span class="salary-summary-value text-dark fw-bold" id="modalPrincipal">₹60,000</span>
                            </div>
                            <div class="col-4 border-end border-success-subtle">
                                <span
                                    class="salary-summary-label d-block text-muted text-uppercase fw-bold">Collected</span>
                                <span class="salary-summary-value text-success fw-bold"
                                    id="modalCollected">₹20,000</span>
                            </div>
                            <div class="col-4">
                                <span
                                    class="salary-summary-label d-block text-muted text-uppercase fw-bold">Pending</span>
                                <span class="salary-summary-value text-warning fw-bold" id="modalPending">₹40,000</span>
                            </div>
                        </div>
                    </div>

                    <!-- Recovery Installment Amount Field -->
                    <div class="mb-3">
                        <label for="recoveryInstallmentAmount"
                            class="form-label salary-input-label text-uppercase fw-bold text-secondary mb-1">
                            Recovery Installment Amount (₹) <span class="text-danger">*</span>
                        </label>
                        <input type="number" min="1"
                            class="form-control salary-input-field font-monospace fw-bold text-success fs-6 py-2 px-3 rounded-3"
                            id="recoveryInstallmentAmount" placeholder="e.g. 5000" required />
                    </div>

                    <!-- Grid Row: Recovery Month & Recovery Mode -->
                    <div class="row g-3 mb-3">
                        <div class="col-12 col-md-6">
                            <label for="recoveryMonth"
                                class="form-label salary-input-label text-uppercase fw-bold text-secondary mb-1">
                                Recovery Month <span class="text-danger">*</span>
                            </label>
                            <select class=" select3 form-select salary-input-select fw-semibold py-2 px-3 rounded-3"
                                id="recoveryMonth" required>
                                <option value="AUG_2026" selected>August 2026</option>
                                <option value="SEP_2026">September 2026</option>
                                <option value="JUL_2026">July 2026</option>
                            </select>
                        </div>

                        <div class="col-12 col-md-6">
                            <label for="recoveryMode"
                                class="form-label salary-input-label text-uppercase fw-bold text-secondary mb-1">
                                Recovery Mode <span class="text-danger">*</span>
                            </label>
                            <select class="select3 form-select salary-input-select fw-semibold py-2 px-3 rounded-3"
                                id="recoveryMode" required>
                                <option value="Payroll Deduction" selected>Payroll Deduction</option>
                                <option value="Direct Cash/Bank Repayment">Direct Bank/Cash</option>
                            </select>
                        </div>
                    </div>

                    <!-- Voucher / Receipt Reference No -->
                    <div class="mb-4">
                        <label for="recoveryVoucher"
                            class="form-label salary-input-label text-uppercase fw-bold text-secondary mb-1">
                            Voucher / Reference Receipt No.
                        </label>
                        <input type="text" class="form-control salary-input-field font-monospace py-2 px-3 rounded-3"
                            id="recoveryVoucher" placeholder="e.g. PAY-REC-705" />
                    </div>

                    <!-- Action Buttons Footer -->
                    <div
                        class="salary-recovery-footer pt-3 border-top d-flex justify-content-end align-items-center gap-2">
                        <button type="button"
                            class="btn btn-light border salary-btn-cancel fw-bold text-secondary py-2 px-4 rounded-3"
                            data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit"
                            class="btn btn-primary salary-btn-confirm fw-bold py-2 px-4 rounded-3 d-inline-flex align-items-center gap-2 shadow-sm">
                            <i class="mdi mdi-check-circle"></i>
                            <span>Confirm Recovery</span>
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>
</div>

<!-- Loan Ledger Modal -->
<div class="modal fade" id="ledgerModal" tabindex="-1" aria-labelledby="ledgerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-body p-4">

                <!-- Ledger Content Starts Here -->
                <div class="ledger-modal-wrapper container-fluid p-0">

                    <!-- Header Section -->
                    <div
                        class="ledger-header bg-primary d-flex align-items-center justify-content-between border-bottom p-3 mb-3 rounded-top">
                        <div class="d-flex align-items-center gap-3">
                            <div class="ledger-header-icon p-2 rounded-3  text-white">
                                <i class="mdi mdi-file-document-outline fs-2"></i>
                            </div>
                            <div>
                                <h5 class="ledger-title fw-bold text-white mb-0 fs-5" id="ledgerModalLabel">Loan
                                    Repayment Ledger Statement</h5>
                                <p class="ledger-subtitle text-muted mb-0 small">
                                    <span class="employee-name">John Doe</span> •
                                    <span class="loan-id">LN-2024-089</span>
                                </p>
                            </div>
                        </div>
                        <!-- Close Button triggers Bootstrap Modal Dismissal -->
                        <button type="button" class="btn-close btn-close-white ledger-close-btn fs-4"
                            data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <!-- Summary Cards Grid -->
                    <div class="ledger-summary-card bg-light border rounded-3 p-3 mb-3">
                        <div class="row row-cols-2 row-cols-md-4 g-2 text-center font-monospace">
                            <div class="col ledger-summary-item">
                                <span
                                    class="ledger-summary-label d-block text-uppercase text-muted font-sans small mb-1">Loan
                                    Principal</span>
                                <span class="ledger-summary-value fw-bold text-dark">₹1,00,000</span>
                            </div>
                            <div class="col ledger-summary-item">
                                <span
                                    class="ledger-summary-label d-block text-uppercase text-muted font-sans small mb-1">Monthly
                                    EMI</span>
                                <span class="ledger-summary-value fw-bold text-primary">₹10,000</span>
                            </div>
                            <div class="col ledger-summary-item">
                                <span
                                    class="ledger-summary-label d-block text-uppercase text-muted font-sans small mb-1">Total
                                    Recovered</span>
                                <span class="ledger-summary-value fw-bold text-success">₹30,000</span>
                            </div>
                            <div class="col ledger-summary-item">
                                <span
                                    class="ledger-summary-label d-block text-uppercase text-muted font-sans small mb-1">Pending
                                    Balance</span>
                                <span class="ledger-summary-value fw-bold text-warning">₹70,000</span>
                            </div>
                        </div>
                    </div>

                    <!-- Purpose & Schedule Details -->
                    <div
                        class="ledger-details-card bg-light border rounded-3 p-3 mb-3 d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-2">
                        <div>
                            <span class="ledger-purpose fw-bold d-block text-dark small">Purpose: Home Renovation</span>
                            <small class="ledger-dates text-muted">Disbursed on 15 Jan 2024 • Starts Feb 2024</small>
                        </div>
                        <div>
                            <span
                                class="badge rounded-pill ledger-status-badge bg-primary-subtle text-primary px-3 py-1">Active</span>
                        </div>
                    </div>

                    <!-- Repayment History Table -->
                    <div class="ledger-table-container border rounded-3 overflow-auto mb-3" style="max-height: 240px;">
                        <table class="table table-hover align-middle mb-0 text-nowrap ledger-table">
                            <thead class="table-light sticky-top">
                                <tr class="ledger-table-header">
                                    <th scope="col" class="text-uppercase text-muted small fw-bold">Date & Month</th>
                                    <th scope="col" class="text-uppercase text-muted small fw-bold">Voucher / Ref No
                                    </th>
                                    <th scope="col" class="text-uppercase text-muted small fw-bold">Recovery Mode</th>
                                    <th scope="col" class="text-uppercase text-muted small fw-bold text-end">Amount (₹)
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="ledger-table-body">
                                <tr class="ledger-table-row">
                                    <td class="ledger-cell-date">
                                        <span class="fw-bold text-dark d-block small">Feb 2024</span>
                                        <small class="text-muted font-monospace">2024-02-01</small>
                                    </td>
                                    <td class="ledger-cell-voucher font-monospace fw-bold text-secondary small">
                                        VCH-88201</td>
                                    <td class="ledger-cell-mode text-secondary small">Salary Deduction</td>
                                    <td class="ledger-cell-amount text-end font-monospace fw-bold text-success small">
                                        +₹10,000</td>
                                </tr>
                                <tr class="ledger-table-row">
                                    <td class="ledger-cell-date">
                                        <span class="fw-bold text-dark d-block small">Mar 2024</span>
                                        <small class="text-muted font-monospace">2024-03-01</small>
                                    </td>
                                    <td class="ledger-cell-voucher font-monospace fw-bold text-secondary small">
                                        VCH-88412</td>
                                    <td class="ledger-cell-mode text-secondary small">Salary Deduction</td>
                                    <td class="ledger-cell-amount text-end font-monospace fw-bold text-success small">
                                        +₹10,000</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Footer Actions -->
                    <div class="ledger-footer pt-2 border-top d-flex justify-content-between align-items-center">
                        <span class="ledger-count-label text-muted fw-bold small">
                            Total Installments Recorded: <span class="ledger-count-value text-dark">2</span>
                        </span>
                        <button type="button" class="btn btn-primary ledger-btn-close px-4 fw-bold"
                            data-bs-dismiss="modal">
                            Close Ledger
                        </button>
                    </div>

                </div>
                <!-- Ledger Content Ends Here -->

            </div>
        </div>
    </div>
</div>
<style>
/* Horizontal Scroll Layout for Navigation Wrapper */
.nav-scroll-wrapper {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    flex-wrap: wrap;
}

.nav-scroll-container {
    display: flex;
    flex-wrap: nowrap;
    overflow-x: auto;
    white-space: nowrap;
    -webkit-overflow-scrolling: touch;
    padding-bottom: 2px;
    flex: 1 1 auto;
    min-width: 0;
}

/* Hide scrollbar for cleaner tab navigation */
.nav-scroll-container::-webkit-scrollbar {
    display: none;
}

.nav-scroll-container {
    -ms-overflow-style: none;
    scrollbar-width: none;
}

.nav-scroll-container .btn {
    flex-shrink: 0;
}

@media (max-width: 575.98px) {
    .nav-action-btn {
        width: 100%;
    }
}

/* search bar and filters */
/* Card Container */
.loan-toolbar-card {
    transition: box-shadow 0.2s ease-in-out;
    margin-top: 15px;
}

/* Search Input Styling */
.loan-search-wrapper {
    min-width: 220px;
}

.loan-search-wrapper .loan-search-icon {
    left: 12px;
    font-size: 1.1rem;
    pointer-events: none;
}

.loan-search-input {
    padding-left: 2.3rem !important;
    font-size: 0.75rem;
    background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 0.75rem;
    height: 38px;
}

.loan-search-input:focus {
    background-color: #ffffff;
    border-color: #16659e;
    box-shadow: 0 0 0 0.2rem rgba(22, 101, 158, 0.15);
}

/* Status Filter Dropdown */
.loan-filter-select {
    font-size: 0.75rem;
    background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 0.75rem;
    height: 38px;
    color: #334155;
    cursor: pointer;
}

.loan-filter-select:focus {
    border-color: #16659e;
    box-shadow: 0 0 0 0.2rem rgba(22, 101, 158, 0.15);
}

/* Buttons Styling */
.btn-loan-export {
    background-color: #ffffff;
    border: 1px solid #e2e8f0;
    color: #334155;
    border-radius: 0.75rem;
    font-size: 0.75rem;
    height: 38px;
    padding: 0 0.85rem;
    transition: all 0.2s ease;
}

.btn-loan-export:hover {
    background-color: #f8fafc;
    border-color: #cbd5e1;
    color: #0f172a;
}

.btn-loan-primary {
    background-color: #16659e;
    border: none;
    color: #ffffff;
    border-radius: 0.75rem;
    font-size: 0.75rem;
    height: 38px;
    padding: 0 1rem;
    box-shadow: 0 1px 2px rgba(22, 101, 158, 0.2);
    transition: all 0.2s ease;
}

.btn-loan-primary:hover {
    background-color: #0c3c62;
    color: #ffffff;
}

/* Responsive Behaviors */
@media (min-width: 768px) {
    .loan-search-wrapper {
        max-width: 256px;
    }
}

@media (max-width: 575.98px) {
    .loan-filter-wrapper {
        width: 100%;
    }

    .loan-filter-select {
        width: 100%;
    }

    .loan-action-group {
        width: 100%;
    }

    .loan-action-group .btn {
        flex: 1;
    }
}

/* table content  */
/* Container & Table Card Base */
.loan-table-card {
    background-color: #ffffff;
    border: 1px solid #e2e8f0;
    margin-top: 10px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    overflow: hidden;
}

.loan-table-responsive {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}

.loan-table {
    width: 100%;
    border-collapse: collapse;
    text-align: start;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 0.8125rem;
}

/* Header Styling */
.loan-table-header-row {
    background-color: #f8fafc;
    border-bottom: 1px solid #e2e8f0;
}

.loan-th {
    padding: 0.875rem 1rem;
    font-size: 0.6875rem;
    font-weight: 800;
    color: #475569;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    white-space: nowrap;
    vertical-align: middle;
}

/* Specific Header Column Alignments */
.loan-th-duration,
.loan-th-start,
.loan-th-status,
.loan-th-actions {
    text-align: start;
}

.loan-th-actions {
    text-align: center;
}

/* Body Row & Cell Base Styling */
.loan-row {
    border-bottom: 1px solid #f1f5f9;
    transition: background-color 0.15s ease-in-out;
}

.loan-row:hover {
    background-color: #f8fafc;
}

.loan-td {
    padding: 0.9rem;
    vertical-align: middle;
}

/* Specific Data Cell Alignments */




/* Column 1: Loan ID & Date */
.loan-id-text {
    display: block;
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 800;
    font-size: 15px;
    color: #16659e;
}

.loan-date-text {
    display: block;
    font-size: 0.81rem;
    color: #94a3b8;
    margin-top: 0.125rem;
}

/* Column 2: Employee Details */
.employee-name-text {
    display: block;
    font-weight: 600;
    color: #1e293b;
    font-size: 0.95rem;
}

.employee-meta-wrapper {
    display: flex;
    align-items: center;
    gap: 0.375rem;
    margin-top: 0.25rem;
    font-size: 0.6875rem;
    color: #64748b;
}

.employee-code-badge {
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    background-color: #f1f5f9;
    border: 1px solid #e2e8f0;
    color: #334155;
    padding: 2px;
    width: 60px;
    border-radius: 0.25rem;
    font-weight: 600;
    font-size: 12px;
}

.employee-dept-text {
    font-size: 11px;
}

.employee-meta-divider {
    color: #cbd5e1;
}

/* Column 3: Loan Amount */
.loan-td-amount {
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 400;
    color: #0f172a;
    font-size: 0.96rem;
}

/* Column 4: Monthly Recovery */
.loan-td-recovery {
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
}

.recovery-amount-text {
    display: block;
    font-weight: 700;
    color: #334155;
    font-size: 0.96rem;
    margin-top: 10px;
}

.recovery-unit-text {
    display: block;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 0.625rem;
    color: #94a3b8;
    font-weight: 400;
    font-size: 0.96rem;
    margin-top: 9px;
}

/* Column 5: Duration */
.duration-badge {
    display: inline-block;
    background-color: #f1f5f9;
    color: #334155;
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 800;
    font-size: 0.90rem;
    padding: 0.25rem 0.5rem;
    border-radius: 0.375rem;
}

/* Column 6: Collected */
.loan-td-collected {
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-weight: 700;
    font-size: 0.94rem;
    background-color: rgba(236, 253, 245, 0.3);
}

/* Column 7: Pending & Progress */
.loan-td-pending {
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 0.94rem;
}

.pending-amount-text {
    display: block;
    font-weight: 800;
    color: #b45309;
}

.loan-progress-track {
    width: 100%;
    height: 4px;
    background-color: #e2e8f0;
    border-radius: 10px;
    margin-top: 0.25rem;
    overflow: hidden;
}

.loan-progress-bar {
    height: 100%;
    background-color: #10b981;
    border-radius: 10px;
}

/* Column 8: Start Month */
.loan-td-start {
    font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 0.94rem;
    font-weight: 700;
    color: #475569;
}

/* Column 9: Status Badge */
.loan-status-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.25rem 0.62rem;
    border-radius: 50rem;
    font-size: 0.625rem;
    font-weight: 800;
    text-transform: uppercase;
}

.badge-active {
    background-color: #dbeafe;
    color: #1e40af;
    border: 1px solid #bfdbfe;
}

.badge-completed {
    background-color: #d1fae5;
    color: #065f46;
    border: 1px solid #a7f3d0;
}

/* Column 10: Action Buttons */
.action-buttons-wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.375rem;
}

.btn-loan-action {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    padding: 0.25rem 0.5rem;
    border-radius: 0.5rem;
    font-size: 0.6875rem;
    font-weight: 700;
    cursor: pointer;
    border: 1px solid transparent;
    transition: all 0.15s ease-in-out;
}

.btn-recover-action {
    background-color: #ecfdf5;
    color: #047857;
    border-color: #a7f3d0;
}

.btn-recover-action:hover {
    background-color: #d1fae5;
    color: #065f46;
}

.btn-ledger-action {
    background-color: #f1f5f9;
    color: #334155;
    border-color: #e2e8f0;
}

.btn-ledger-action:hover {
    background-color: #e2e8f0;
    color: #0f172a;
}

/* Disburse loan modal */
/* Modal Card Shell */
.disburse-modal-card {
    border: none;
    border-radius: 1.25rem;
    padding: 1.25rem;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
    background-color: #ffffff;
}

/* Header Container */
.disburse-modal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #f1f5f9;
    padding-bottom: 1rem;
    margin-bottom: 1rem;
    width: 100%;
}

.disburse-modal-title-wrapper {
    display: flex;
    align-items: center;
    gap: 0.625rem;
}

/* Icon Shell */
.disburse-modal-icon-box {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0.625rem;
    background-color: #eff6ff;
    color: #16659e;
    border-radius: 0.75rem;
    flex-shrink: 0;
}

.disburse-modal-icon-box i {
    font-size: 1.25rem;
    line-height: 1;
}

/* Header Typography */
.disburse-modal-text-group {
    display: flex;
    flex-direction: column;
}

.disburse-modal-heading {
    font-weight: 800;
    color: #1e293b;
    font-size: 0.875rem;
    margin: 0;
    line-height: 1.25;
}

.disburse-modal-subheading {
    font-size: 0.6875rem;
    color: #94a3b8;
    margin: 0.125rem 0 0 0;
    line-height: 1.3;
}

/* Close Icon Button */
.disburse-modal-close-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0.375rem;
    background: transparent;
    border: none;
    border-radius: 0.5rem;
    color: #94a3b8;
    cursor: pointer;
    transition: background-color 0.15s ease, color 0.15s ease;
}

.disburse-modal-close-btn:hover {
    background-color: #f1f5f9;
    color: #475569;
}

.disburse-modal-close-btn i {
    font-size: 1.125rem;
    line-height: 1;
}

/* Form Inputs Styling */
.disburse-modal-body {
    padding: 0.5rem 0;
}

.disburse-form-label {
    display: block;
    font-size: 0.75rem;
    font-weight: 700;
    color: #475569;
    margin-bottom: 0.375rem;
}

.disburse-form-input,
.disburse-form-select,
.disburse-form-textarea {
    width: 100%;
    padding: 0.5rem 0.75rem;
    font-size: 0.78rem;
    background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 0.75rem;
    color: #1e293b;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
}

.disburse-form-input:focus,
.disburse-form-select:focus,
.disburse-form-textarea:focus {
    outline: none;
    background-color: #ffffff;
    border-color: #16659e;
    box-shadow: 0 0 0 0.2rem rgba(22, 101, 158, 0.15);
}

/* Footer Buttons */
.disburse-modal-footer {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 0.5rem;
    border-top: 1px solid #f1f5f9;
    padding-top: 1rem;
    margin-top: 1rem;
}

.btn-disburse-cancel {
    background-color: #f1f5f9;
    color: #475569;
    border: 1px solid #e2e8f0;
    font-size: 0.75rem;
    font-weight: 700;
    padding: 0.5rem 1rem;
    border-radius: 0.75rem;
    cursor: pointer;
    transition: all 0.15s ease;
}

.btn-disburse-cancel:hover {
    background-color: #e2e8f0;
    color: #0f172a;
}

.btn-disburse-submit {
    display: inline-flex;
    align-items: center;
    gap: 0.375rem;
    background-color: #16659e;
    color: #ffffff;
    border: none;
    font-size: 0.75rem;
    font-weight: 800;
    padding: 0.5rem 1.25rem;
    border-radius: 0.75rem;
    cursor: pointer;
    transition: all 0.15s ease;
}

.btn-disburse-submit:hover {
    background-color: #0c3c62;
}

/* Responsive Scaling */
@media (max-width: 575.98px) {
    .disburse-modal-card {
        padding: 1rem;
    }

    .disburse-modal-heading {
        font-size: 0.8125rem;
    }

    .disburse-modal-subheading {
        font-size: 0.625rem;
    }

    .disburse-modal-footer {
        flex-direction: column-reverse;
    }

    .btn-disburse-cancel,
    .btn-disburse-submit {
        width: 100%;
        justify-content: center;
    }
}

/* KPI Cards start */
/* ==========================================
   APPRAISAL / WAGE KPI GRID - BASE STYLES
========================================== */

.appraisal-kpi-grid {
    width: 100%;
    margin-left: 0;
    margin-right: 0;
}

/* Stat Card Shell */
.stat-card {
    width: 100%;
    min-height: 110px;
    overflow: hidden;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(15, 23, 42, 0.08) !important;
}

/* Icon Wrapper Alignment */
.stat-icon-wrapper {
    width: 42px;
    height: 42px;
    min-width: 42px;
    flex: 0 0 42px;
}

.stat-icon-wrapper i {
    line-height: 1;
}

/* Typography Base Defaults */
.stat-card>div:last-child {
    min-width: 0;
}

.stat-label {
    font-size: 10px;
    line-height: 1.25;
    letter-spacing: 0.04em;
    white-space: normal;
}

.stat-value {
    font-size: 15px !important;
    line-height: 1.2;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.stat-description {
    font-size: 8.5px;
    line-height: 1.3;
    color: #94a3b8;
    white-space: normal;
}

/* Color Palette Utility Classes */
.bg-orange-subtle {
    background-color: #fff7ed;
}

.text-orange {
    color: #ea580c;
}

.bg-blue-subtle {
    background-color: #eff6ff;
}

.text-blue {
    color: #2563eb;
}

.bg-purple-subtle {
    background-color: #faf5ff;
}

.text-purple {
    color: #9333ea;
}

.bg-emerald-subtle {
    background-color: #ecfdf5;
}

.text-emerald {
    color: #059669;
}

.bg-indigo-subtle {
    background-color: #eef2ff;
}

.text-indigo {
    color: #4f46e5;
}

.text-primary-dark {
    color: #0c3c62;
}


/* ==========================================
   RESPONSIVE BREAKPOINT ALIGNMENTS
========================================== */

/* 1. Mobile Horizontal Scroll View (max-width: 575.98px) */
@media (max-width: 575.98px) {
    .nav-action-btn {
        width: 100%;
    }

    .appraisal-kpi-mobile-scroll {
        display: flex !important;
        flex-wrap: nowrap !important;
        overflow-x: auto;
        overflow-y: hidden;
        scroll-behavior: smooth;
        -webkit-overflow-scrolling: touch;
        scroll-snap-type: x mandatory;
        padding-bottom: 4px;
        scrollbar-width: none;
        /* Hide standard scrollbar */
    }

    .appraisal-kpi-mobile-scroll::-webkit-scrollbar {
        display: none;
    }

    /* Fixed 2-Card Visible Width Ratio */
    .appraisal-kpi-mobile-scroll .stat-card-item {
        flex: 0 0 calc(50% - 0.375rem) !important;
        width: calc(50% - 0.375rem) !important;
        max-width: calc(50% - 0.375rem) !important;
        padding-left: 3px;
        padding-right: 3px;
        scroll-snap-align: start;
    }

    .appraisal-kpi-mobile-scroll .stat-card {
        min-height: 105px;
        padding: 10px !important;
        gap: 8px !important;
        border-radius: 14px !important;
    }

    .appraisal-kpi-mobile-scroll .stat-icon-wrapper {
        width: 36px;
        height: 36px;
        min-width: 36px;
        flex: 0 0 36px;
    }

    .appraisal-kpi-mobile-scroll .stat-label {
        font-size: 8.5px;
    }

    .appraisal-kpi-mobile-scroll .stat-value {
        font-size: 13.5px !important;
    }

    .appraisal-kpi-mobile-scroll .stat-description {
        font-size: 7.5px;
    }
}

/* 2. Tablet / Small Screens (576px - 991.98px) */
@media (min-width: 576px) and (max-width: 991.98px) {
    .stat-card {
        min-height: 115px;
        padding: 12px !important;

    }

    .stat-label {
        font-size: 9.5px;

    }

    .stat-value {
        font-size: 15px !important;
    }
}

/* 3. Laptops (992px - 1199.98px) */
@media (min-width: 992px) and (max-width: 1199.98px) {
    .stat-card {
        min-height: 118px;
    }

    .stat-label {
        font-size: 10px;
    }

    .stat-value {
        font-size: 16px !important;
    }
}

/* 4. Large Desktop - 6 Cards side-by-side in 1 Row (min-width: 1200px) */
@media (min-width: 1200px) {
    .appraisal-kpi-grid .stat-card-item {
        flex: 0 0 16.666667%;
        max-width: 16.666667%;


    }

    .stat-card {
        min-height: 120px;
        padding: 14px !important;
        border-radius: 15px;
    }

    .stat-label {
        font-size: 10.5px;
    }

    .stat-value {
        font-size: 16.5px !important;
    }

    .stat-description {
        font-size: 8.5px;
    }

    .stat-icon-wrapper {
        width: 40px;
        height: 40px;
        min-width: 40px;
        flex: 0 0 40px;
    }

    .appraisal-toolbar {
        margin-top: 13px;
    }
}

/* KPI Cards end */
</style>

<script>
// recover modal script
document.addEventListener('DOMContentLoaded', () => {
    const recoveryModal = document.getElementById('recordLoanRecoveryModal');

    if (recoveryModal) {
        recoveryModal.addEventListener('show.bs.modal', (event) => {
            // Button that triggered the modal
            const button = event.relatedTarget;

            if (button) {
                // Extract info from data-* attributes
                const employee = button.getAttribute('data-employee') || 'N/A';
                // const principal = button.getAttribute('data-principal') || '₹0';
                // const collected = button.getAttribute('data-collected') || '₹0';
                // const pending = button.getAttribute('data-pending') || '₹0';
                // const monthly = button.getAttribute('data-monthly') || '';

                // Update the modal's content
                document.getElementById('modalEmployeeMeta').textContent = employee;
                document.getElementById('modalPrincipal').textContent = principal;
                document.getElementById('modalCollected').textContent = collected;
                document.getElementById('modalPending').textContent = pending;
                document.getElementById('recoveryInstallmentAmount').value = monthly;
            }
        });
    }
});
</script>
@endsection
