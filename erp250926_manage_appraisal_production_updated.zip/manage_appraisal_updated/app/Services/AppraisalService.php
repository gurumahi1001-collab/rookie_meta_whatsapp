<?php

namespace App\Services;

use Carbon\Carbon;
use App\Models\StaffModel;
use App\Models\StaffSalaryAppraisalHistoryModel;
use App\Models\StaffSalaryAccountModel;
use App\Models\PayrollStaffStructureModel;
use App\Models\PayrollStaffStructureDetailModel;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AppraisalService
{
    public function list(Request $request)
    {

        $year = $request->year ?? now()->year;

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $company_fill = $request->company_fill ?? '';
        $entity_fill = $request->entity_fill ?? '';
        $department_fill = $request->department_fill ?? '';
        $division_fill = $request->division_fill ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->to_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';

        $query = StaffModel::query()
            ->select(
                'egc_staff.*',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name',
                'egc_company.company_name',
                'egc_company.company_base_color',
                'egc_entity.entity_name'
            )

            ->leftJoin('egc_department','egc_department.sno','=','egc_staff.department_id')
            ->leftJoin('egc_division','egc_division.sno','=','egc_staff.division_id')
            ->leftJoin('egc_job_role','egc_job_role.sno','=','egc_staff.job_role_id')
            ->leftJoin('egc_company','egc_company.sno','=','egc_staff.company_id')
            ->leftJoin('egc_entity','egc_entity.sno','=','egc_staff.entity_id')
            ->where('egc_staff.status','!=',2);

            if($request->filled('search_filter')){
                $search=$request->search_filter;
                $query->where(function($q) use($search){
                    $q->where('egc_staff.staff_name','like',"%{$search}%")
                    ->orWhere('egc_staff.staff_id','like',"%{$search}%")
                    ->orWhere('egc_staff.mobile_no','like',"%{$search}%");
                });
            }
            if($request->company_fill){
                $query->where('egc_staff.company_id',$request->company_fill);
            }

            if($request->entity_fill){
                $query->where('egc_staff.entity_id',$request->entity_fill);
            }

            if($request->department_fill){
                $query->where('egc_staff.department_id',$request->department_fill);
            }
            if($request->division_fill){
                $query->where('egc_staff.division_id',$request->division_fill);
            }

            if($request->job_role_fill){
                $query->where('egc_staff.job_role_id',$request->job_role_fill);
            }

            $dashboardQuery = clone $query;
            $dashboardStaffIds = $dashboardQuery->pluck('egc_staff.sno');
            $totalStaff = $dashboardStaffIds->count();
            $totalSalary = StaffModel::whereIn('sno',$dashboardStaffIds)
            ->sum('basic_salary');
            $highestSalary = StaffModel::whereIn('sno',$dashboardStaffIds)
                    ->max('basic_salary');
                    $lowestSalary = StaffModel::whereIn('sno',$dashboardStaffIds)
                    ->min('basic_salary');
            $averageSalary = StaffModel::whereIn('sno',$dashboardStaffIds)
                    ->avg('basic_salary');
            $thisYearAppraisal = StaffSalaryAppraisalHistoryModel::active()
            // ->processed()
            ->where('status',0)
            ->whereNot('appraisal_type',0)
            ->whereYear('effective_from',now()->year)
            ->whereIn('employee_sno',$dashboardStaffIds)
            ->count();

            $thisMonthAppraisal = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->whereNot('appraisal_type',0)
                ->whereYear('effective_from',now()->year)
                ->whereMonth('effective_from',now()->month)
                ->whereIn('employee_sno',$dashboardStaffIds)
                ->count();

            $appraisedStaff = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->whereNot('appraisal_type',0)
                ->whereIn('employee_sno',$dashboardStaffIds)
                ->distinct('employee_sno')
                ->count('employee_sno');

            $appraisalTypes = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->whereNot('appraisal_type',0)
                ->whereIn('employee_sno',$dashboardStaffIds)
                ->selectRaw('appraisal_type,COUNT(*) total')
                ->groupBy('appraisal_type')
                ->pluck('total','appraisal_type');
            $avgIncrement = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->whereNot('appraisal_type',0)
                ->whereIn('employee_sno',$dashboardStaffIds)
                ->selectRaw('AVG(appraisal_value) avg_increment')
                ->value('avg_increment');

            $staffs=$query
                ->orderBy('egc_staff.date_of_joining','asc')
                ->paginate($perpage);

            $staffIds=$staffs->pluck('sno');

            $histories=StaffSalaryAppraisalHistoryModel::active()
                        // ->processed()
                        ->where('status',0)
                        ->whereIn('employee_sno',$staffIds)
                        ->orderBy('effective_from')
                        ->get()
                        ->groupBy('employee_sno');
            $headers = [];

            $firstJoining = StaffModel::where('status', '!=', 2)
                            ->whereIn('sno',$staffIds)
                            ->min('date_of_joining');
            $startHeader = Carbon::parse($firstJoining)->startOfMonth();
            $endHeader = now()->startOfMonth();
            $temp = $startHeader->copy();

            while ($temp <= $endHeader) {
                $headers[] = [
                    'key' => $temp->format('Y-m'),
                    'label' => $temp->format('M-y'),
                    'year' => $temp->year,
                    'month' => $temp->month
                ];
                $temp->addMonth();
            }

            $staffs->getCollection()->transform(function ($staff) use ($histories, $headers) {

                $joiningDate = Carbon::parse($staff->date_of_joining)->startOfMonth();
                $exitDate = null;

                switch ((int)$staff->status) {
                    case 4: // Notice
                        if (!empty($staff->notice_end_date)) {
                            $exitDate = Carbon::parse($staff->notice_end_date)->startOfMonth();
                        }
                    break;
                    case 5: // Relieved
                        if (!empty($staff->staff_last_date)) {
                            $exitDate = Carbon::parse($staff->staff_last_date)->startOfMonth();
                        }
                    case 6: // Abscond
                         if (!empty($staff->staff_last_date)) {
                            $exitDate = Carbon::parse($staff->staff_last_date)->startOfMonth();
                        }
                    case 7: // Terminated
                        if (!empty($staff->staff_last_date)) {
                            $exitDate = Carbon::parse($staff->staff_last_date)->startOfMonth();
                        }

                    break;
                }
                $salaryHistory = $histories[$staff->sno] ?? collect();
                $timeline = [];
                $latestSalary = $staff->basic_salary;

                foreach ($headers as $header) {
                    $current = Carbon::create( $header['year'],$header['month'],1);

                    if ($exitDate && $current->gt($exitDate)) {
                        $timeline[] = [
                            'month' => $header['label'],
                            'salary' => null,
                            'status' => 'exited',
                            'effective_from' => null,
                            'type' => null
                        ];
                        continue;
                    }

                    if ($current->lt($joiningDate)) {
                        $timeline[] = [
                            'month' => $header['label'],
                            'salary' => null,
                            'status' => 'before_join',
                            'effective_from' => null,
                            'type' => null
                        ];
                        continue;
                    }

                    $record = $salaryHistory
                        ->filter(function ($item) use ($current) {
                            return Carbon::parse($item->effective_from)
                                ->startOfMonth()
                                ->lte($current);

                        })
                        ->last();

                    
                    if ($record) {
                        $latestSalaryPrevious = $record->gross_salary;
                        $latestSalary = $record->gross_salary;
                        $hikeValue =0 ;

                        if ($record->appraisal_unit == '%') {
                            $hikeValue =  ($record->appraisal_value / 100) * $latestSalaryPrevious ;
                        } else {
                            $hikeValue =  $record->appraisal_value ?? 0;
                        }

                        $latestSalary = $latestSalaryPrevious + round($hikeValue);

                    }

                    

                    $status = "normal";

                    if ($current->equalTo($joiningDate)) {
                        $status = "joining";
                    }

                    if ($record && Carbon::parse($record->effective_from)->format('Y-m') == $current->format('Y-m')) {

                        if($record->appraisal_type == 0){
                            $status = "joining";
                        }else{
                            $status = "appraisal";
                        } 
                    }

                    if ($current->isCurrentMonth()) {
                        $status = "current";
                    }

                    $timeline[] = [
                        'month' => $header['label'],
                        'salary' => $latestSalary,
                        'status' => $status,
                        'effective_from' => $record ? $record->effective_from->format('Y-m-d') : null,
                        'type' => $record? $record->appraisal_type_name : null
                    ];
                }

                 $total_appraisal_staff =StaffSalaryAppraisalHistoryModel::active()
                    ->where('status',0)
                    ->where('employee_sno',$staff->sno)
                    ->whereNot('appraisal_type',0)
                    ->orderBy('effective_from','asc')
                    ->count();

                $helper = new \App\Helpers\Helpers();
                $general_setting=$helper->general_setting_data();

                if ($staff->company_type == 1) {
                    $staff->company_name = $general_setting->title;
                    $staff->company_base_color = '#ab2b22';
                    $staff->company_logo = $general_setting->logo;
                }

                $staff->total_appraisal = $total_appraisal_staff;
                $staff->current_salary = $latestSalary;
                $staff->timeline = $timeline;
                return $staff;
            });

        return [
            'status' => 200,
            'dashboard'=>[

                'total_staff'=>$totalStaff,

                'appraised_staff'=>$appraisedStaff,

                'average_salary'=>round($averageSalary),

                'highest_salary'=>$highestSalary,

                'lowest_salary'=>$lowestSalary,

                'salary_cost'=>$totalSalary,

                'this_month'=>$thisMonthAppraisal,

                'this_year'=>$thisYearAppraisal,

                'avg_increment'=>round($avgIncrement,2),

                'types'=>[

                    'joining'=>$appraisalTypes[0] ?? 0,

                    'yearly'=>$appraisalTypes[1] ?? 0,

                    'special'=>$appraisalTypes[2] ?? 0,

                    'project'=>$appraisalTypes[3] ?? 0,

                    'warrior'=>$appraisalTypes[5] ?? 0

                ]

            ],

            'headers' => $headers,
            'current_page' => $staffs->currentPage(),
            'last_page' => $staffs->lastPage(),
            'total' => $staffs->total(),
            'data' => $staffs->values()
        ];

    }
    public function details($staffId)
    {
        $staff = StaffModel::query()
            ->leftJoin('egc_department','egc_department.sno','=','egc_staff.department_id')
            ->leftJoin('egc_division','egc_division.sno','=','egc_staff.division_id')
            ->leftJoin('egc_job_role','egc_job_role.sno','=','egc_staff.job_role_id')
            ->select(
                'egc_staff.*',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name'
            )
            ->findOrFail($staffId);

        $history = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->where('employee_sno',$staffId)
                ->orderBy('effective_from')
                ->get();

        $historyWithoutJoining = StaffSalaryAppraisalHistoryModel::active()
                // ->processed()
                ->where('status',0)
                ->where('employee_sno',$staffId)
                 ->whereNot('appraisal_type',0)
                ->orderBy('effective_from')
                ->get();
        $lastData =StaffSalaryAppraisalHistoryModel::active()
                    // ->processed()
                    ->where('status',0)
                    ->where('employee_sno',$staffId)
                    ->where('appraisal_type',0)
                    ->orderBy('effective_from','asc')
                    ->first();

            $lastDataHisrtry =StaffSalaryAppraisalHistoryModel::active()
                    // ->processed()
                    ->where('status',0)
                    ->where('employee_sno',$staffId)
                    ->orderBy('effective_from','asc')
                    ->first();

        $joiningSalary = $lastData ? $lastData->gross_salary : ($lastDataHisrtry ? $lastDataHisrtry->gross_salary : $staff->basic_salary);

        $currentSalary = $staff->basic_salary ??( $history->count()
            ? $history->last()->gross_salary
            : $joiningSalary);

        $totalIncrement = $currentSalary - $joiningSalary;

        $experience = Carbon::parse($staff->date_of_joining)
            ->diff(now());

        $summary = [
            'joining_salary'   => $joiningSalary,
            'current_salary'   => $currentSalary,
            'highest_salary'   => max($history->pluck('gross_salary')->push($joiningSalary)->toArray()),
            'total_increment'  => $totalIncrement,
            'total_appraisals' => $historyWithoutJoining->count(),
            'salary_growth'    => $joiningSalary > 0
                ? round(($totalIncrement / $joiningSalary) * 100, 1)
                : 0,
            'experience'       => $experience->y . 'Y ' . $experience->m . 'M'
        ];

        $increments = [];

        $highestIncrement = 0;

        $lastSalary = $joiningSalary;

        foreach($history as $row){

            $inc = $row->gross_salary - $lastSalary;

            $increments[] = $inc;

            if($inc > $highestIncrement){
                $highestIncrement = $inc;
            }
            $lastSalary = $row->gross_salary;
        }

        $averageIncrement = count($increments)
            ? round(array_sum($increments)/count($increments),2)
            : 0;

        $summary['highest_increment'] = $highestIncrement;

        $summary['average_increment'] = $averageIncrement;

        return [
            'status'=>200,
            'staff'=>$staff,
            'history'=>$history,
            'summary' => $summary
        ];

    }

    /**
     * Data required to initialise the Add Appraisal modal.
     * Kept separate from index() so the Manage Appraisal page does not
     * load payroll/template metadata until HR actually opens the modal.
     */
    public function appraisalFormData(): array
    {
        $mainCompanyTitle = DB::table('egc_general_settings')
            ->where('sno', 1)
            ->value('title');

        $entities = DB::table('egc_entity')
            ->where('status', 0)
            ->orderBy('entity_name')
            ->get(['sno', 'entity_name', 'entity_short_name', 'entity_base_color']);

        $templates = DB::table('egc_payroll_salary_templates')
            ->where('status', 0)
            ->orderBy('template_name')
            ->get([
                'sno',
                'template_name',
                'template_code',
                'gross_salary',
                'monthly_ctc',
                'effective_from',
                'template_type'
            ]);

        $variableComponents = DB::table('egc_payroll_components')
            ->where('status', 0)
            ->where(function ($q) {
                $q->where('component_type', 'earning')
                  ->orWhereNull('component_type');
            })
            ->orderBy('component_name')
            ->get([
                'sno',
                'component_name',
                'component_code',
                'component_type',
                'is_taxable',
                'is_statutory'
            ]);

        return [
            'status' => true,
            'main_company' => [
                'id' => 0,
                'title' => $mainCompanyTitle ?: 'Main Company'
            ],
            'entities' => $entities,
            'templates' => $templates,
            'variable_components' => $variableComponents,
            'default_variable_months' => 3,
            'current_month' => now()->format('Y-m'),
        ];
    }

    /**
     * Staff selector data for the Add Appraisal modal.
     * Entity 0 is the main company. For entities > 0 the branch filter is applied
     * when a branch is selected. Department remains mandatory for the staff list.
     */
    public function appraisalStaffOptions(Request $request): array
    {
        $entityId = (int) ($request->input('entity_id', 0));
        $branchId = (int) ($request->input('branch_id', 0));
        $departmentId = (int) ($request->input('department_id', 0));

        if ($departmentId <= 0) {
            return ['status' => true, 'data' => []];
        }

        $query = StaffModel::query()
            ->leftJoin('egc_company', 'egc_company.sno', '=', 'egc_staff.company_id')
            ->leftJoin('egc_entity', 'egc_entity.sno', '=', 'egc_staff.entity_id')
            ->leftJoin('egc_branch', 'egc_branch.sno', '=', 'egc_staff.branch_id')
            ->leftJoin('egc_department', 'egc_department.sno', '=', 'egc_staff.department_id')
            ->leftJoin('egc_division', 'egc_division.sno', '=', 'egc_staff.division_id')
            ->leftJoin('egc_job_role', 'egc_job_role.sno', '=', 'egc_staff.job_role_id')
            ->where('egc_staff.status', 0)
            ->where('egc_staff.sno', '>', 1)
            ->where('egc_staff.department_id', $departmentId)
            ->where('egc_staff.entity_id', $entityId);

        if ($entityId > 0 && $branchId > 0) {
            $query->where('egc_staff.branch_id', $branchId);
        }

        $staff = $query
            ->orderBy('egc_staff.staff_name')
            ->get([
                'egc_staff.sno',
                'egc_staff.staff_id',
                'egc_staff.staff_name',
                'egc_staff.nick_name',
                'egc_staff.mobile_no',
                'egc_staff.email_id',
                'egc_staff.date_of_joining',
                'egc_staff.basic_salary',
                'egc_staff.profile_image_url',
                'egc_staff.company_id',
                'egc_staff.entity_id',
                'egc_staff.branch_id',
                'egc_staff.department_id',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name',
                'egc_company.company_name',
                'egc_entity.entity_name',
                'egc_branch.branch_name'
            ]);

        return [
            'status' => true,
            'data' => $staff,
        ];
    }

    /**
     * Full staff + current payroll + last appraisal payload for the right side
     * of the Add Appraisal modal.
     */
    public function appraisalStaffProfile(int $staffId): array
    {
        $staff = StaffModel::query()
            ->leftJoin('egc_company', 'egc_company.sno', '=', 'egc_staff.company_id')
            ->leftJoin('egc_entity', 'egc_entity.sno', '=', 'egc_staff.entity_id')
            ->leftJoin('egc_branch', 'egc_branch.sno', '=', 'egc_staff.branch_id')
            ->leftJoin('egc_department', 'egc_department.sno', '=', 'egc_staff.department_id')
            ->leftJoin('egc_division', 'egc_division.sno', '=', 'egc_staff.division_id')
            ->leftJoin('egc_job_role', 'egc_job_role.sno', '=', 'egc_staff.job_role_id')
            ->where('egc_staff.sno', $staffId)
            ->select(
                'egc_staff.*',
                'egc_company.company_name',
                'egc_entity.entity_name',
                'egc_branch.branch_name',
                'egc_department.department_name',
                'egc_division.division_name',
                'egc_job_role.job_position_name as job_role_name'
            )
            ->first();

        if (!$staff) {
            throw ValidationException::withMessages([
                'employee_sno' => 'Employee not found.'
            ]);
        }

        $accounts = StaffSalaryAccountModel::query()
            ->leftJoin('egc_company', 'egc_company.sno', '=', 'egc_staff_salary_accounts.salary_company_id')
            ->where('egc_staff_salary_accounts.staff_id', $staffId)
            ->where('egc_staff_salary_accounts.status', 0)
            ->orderByDesc('egc_staff_salary_accounts.is_primary')
            ->orderBy('egc_staff_salary_accounts.sno')
            ->get([
                'egc_staff_salary_accounts.sno',
                'egc_staff_salary_accounts.salary_company_id',
                'egc_staff_salary_accounts.salary_bank_id',
                'egc_staff_salary_accounts.gross_salary',
                'egc_staff_salary_accounts.per_day_salary',
                'egc_staff_salary_accounts.per_hour_cost',
                'egc_staff_salary_accounts.salary_type',
                'egc_staff_salary_accounts.effective_from',
                'egc_staff_salary_accounts.effective_to',
                'egc_staff_salary_accounts.is_primary',
                'egc_staff_salary_accounts.is_payslip',
                'egc_company.company_name'
            ]);

        $primaryAccount = $accounts->first();

        $currentStructure = null;
        $structureDetails = collect();
        if ($primaryAccount) {
            $currentStructure = PayrollStaffStructureModel::query()
                ->leftJoin('egc_payroll_salary_templates as t', 't.sno', '=', 'egc_payroll_employee_structures.payroll_template_sno')
                ->where('egc_payroll_employee_structures.employee_sno', $staffId)
                ->where('egc_payroll_employee_structures.salary_account_id', $primaryAccount->sno)
                ->where('egc_payroll_employee_structures.is_current', 1)
                ->where('egc_payroll_employee_structures.status', 0)
                ->orderByDesc('egc_payroll_employee_structures.effective_from')
                ->select(
                    'egc_payroll_employee_structures.*',
                    't.template_name',
                    't.template_code'
                )
                ->first();

            if ($currentStructure) {
                $structureDetails = $this->getStructureDetails($currentStructure->sno);
            }
        }

        $lastAppraisal = StaffSalaryAppraisalHistoryModel::query()
            ->leftJoin('egc_payroll_salary_templates as t', 't.sno', '=', 'egc_staff_salary_appraisal_history.payroll_template_sno')
            ->where('egc_staff_salary_appraisal_history.employee_sno', $staffId)
            ->where('egc_staff_salary_appraisal_history.status', 0)
            ->where('egc_staff_salary_appraisal_history.appraisal_type', '!=', 0)
            ->orderByDesc('egc_staff_salary_appraisal_history.effective_from')
            ->select(
                'egc_staff_salary_appraisal_history.*',
                't.template_name'
            )
            ->first();

        $recentHistory = StaffSalaryAppraisalHistoryModel::query()
            ->where('employee_sno', $staffId)
            ->where('status', 0)
            ->orderByDesc('effective_from')
            ->limit(5)
            ->get();

        return [
            'status' => true,
            'staff' => $staff,
            'accounts' => $accounts,
            'current_structure' => $currentStructure,
            'structure_details' => $structureDetails,
            'last_appraisal' => $lastAppraisal,
            'recent_history' => $recentHistory,
            'current_salary' => (float) ($currentStructure->gross_salary ?? ($primaryAccount?->gross_salary ?? $staff->basic_salary ?? 0)),
        ];
    }

    /**
     * Save an appraisal and the matching payroll structure in one transaction.
     * Variable pay remains outside gross salary and is stored separately for 3 months.
     */
    public function saveAppraisal(Request $request): array
    {
        $validated = $request->validate([
            'entity_id' => 'required|integer|min:0',
            'branch_id' => 'nullable|integer|min:0',
            'department_id' => 'required|integer|min:1',
            'employee_sno' => 'required|integer|min:1',
            'salary_account_id' => 'required|integer|min:1',
            'payroll_template_sno' => 'required|integer|min:1',
            'effective_from' => ['required', 'date_format:Y-m'],
            'gross_salary' => 'required|numeric|min:1',
            'appraisal_type' => 'required|integer|in:1,2,3,5',
            'appraisal_unit' => 'required|in:%,Rs',
            'appraisal_value' => 'nullable|numeric|min:0',
            'appraisal_reason' => 'nullable|string|max:1000',
            'variable_check' => 'nullable|boolean',
            'variable_component' => 'nullable|integer|min:1',
            'variable_amount' => 'nullable|numeric|min:0',
            'variable_from' => 'nullable|date_format:Y-m',
            'variable_months' => 'nullable|integer|min:3|max:3',
            'details' => 'required|array|min:1',
        ]);

        return DB::transaction(function () use ($validated, $request) {
            $userId = $this->actingUserId();
            $employee = StaffModel::query()->lockForUpdate()->find($validated['employee_sno']);
            if (!$employee || (int) $employee->status === 2) {
                throw ValidationException::withMessages([
                    'employee_sno' => 'Active employee not found.'
                ]);
            }

            $entityId = (int) $validated['entity_id'];
            if ((int) ($employee->entity_id ?? 0) !== $entityId) {
                throw ValidationException::withMessages([
                    'employee_sno' => 'Selected employee does not belong to the selected entity.'
                ]);
            }

            if ((int) $validated['department_id'] !== (int) $employee->department_id) {
                throw ValidationException::withMessages([
                    'employee_sno' => 'Selected employee does not belong to the selected department.'
                ]);
            }

            if ($entityId > 0) {
                $branchId = (int) ($validated['branch_id'] ?? 0);
                if ($branchId <= 0 || (int) ($employee->branch_id ?? 0) !== $branchId) {
                    throw ValidationException::withMessages([
                        'branch_id' => 'Selected employee does not belong to the selected branch.'
                    ]);
                }
            }

            $salaryAccount = StaffSalaryAccountModel::query()
                ->where('sno', $validated['salary_account_id'])
                ->where('staff_id', $employee->sno)
                ->where('status', 0)
                ->lockForUpdate()
                ->first();

            if (!$salaryAccount) {
                throw ValidationException::withMessages([
                    'salary_account_id' => 'Valid salary account not found for this employee.'
                ]);
            }

            $template = DB::table('egc_payroll_salary_templates')
                ->where('sno', $validated['payroll_template_sno'])
                ->where('status', 0)
                ->first();

            if (!$template) {
                throw ValidationException::withMessages([
                    'payroll_template_sno' => 'Selected payroll template is not available.'
                ]);
            }

            $effectiveFrom = Carbon::createFromFormat('Y-m', $validated['effective_from'])->startOfMonth();

            $duplicate = StaffSalaryAppraisalHistoryModel::query()
                ->where('employee_sno', $employee->sno)
                ->where('status', 0)
                ->whereDate('effective_from', $effectiveFrom->toDateString())
                ->exists();

            if ($duplicate) {
                throw ValidationException::withMessages([
                    'effective_from' => 'An appraisal already exists for ' . $effectiveFrom->format('M-Y') . '.'
                ]);
            }

            $postedDetails = collect($validated['details'])
                ->filter(fn ($detail) => !empty($detail['payroll_component_sno']))
                ->keyBy(fn ($detail) => (int) $detail['payroll_component_sno']);

            [$preparedDetails, $totals] = $this->buildTemplateDetails(
                (int) $template->sno,
                (float) $validated['gross_salary'],
                $postedDetails
            );

            if (empty($preparedDetails)) {
                throw ValidationException::withMessages([
                    'details' => 'The selected payroll template has no usable salary components.'
                ]);
            }

            $currentStructure = PayrollStaffStructureModel::query()
                ->where('employee_sno', $employee->sno)
                ->where('salary_account_id', $salaryAccount->sno)
                ->where('is_current', 1)
                ->where('status', 0)
                ->orderByDesc('effective_from')
                ->lockForUpdate()
                ->first();

            if ($currentStructure && Carbon::parse($currentStructure->effective_from)->startOfMonth()->eq($effectiveFrom)) {
                $structure = $currentStructure;
                $structure->update([
                    'payroll_template_sno' => $template->sno,
                    'structure_name' => 'Salary Appraisal Structure',
                    'gross_salary' => $validated['gross_salary'],
                    'per_day_salary' => $this->perDaySalary($validated['gross_salary']),
                    'per_hour_cost' => $this->perHourCost($validated['gross_salary']),
                    'total_earnings' => $totals['earnings'],
                    'total_deductions' => $totals['deductions'],
                    'net_salary' => $totals['net_salary'],
                    'employer_contribution' => $totals['employer_contribution'],
                    'ctc_amount' => $totals['ctc'],
                    'revision_no' => ((int) ($currentStructure->revision_no ?? 0)) + 1,
                    'revision_reason' => $validated['appraisal_reason'] ?? null,
                    'updated_by' => $userId,
                ]);

                PayrollStaffStructureDetailModel::where('payroll_employee_structure_sno', $structure->sno)
                    ->where('status', 0)
                    ->update(['status' => 2, 'updated_by' => $userId]);
            } else {
                if ($currentStructure) {
                    $currentStructure->update([
                        'is_current' => 0,
                        'effective_to' => $effectiveFrom->copy()->subDay()->toDateString(),
                        'updated_by' => $userId,
                    ]);
                }

                $structure = PayrollStaffStructureModel::create([
                    'employee_sno' => $employee->sno,
                    'salary_account_id' => $salaryAccount->sno,
                    'payroll_template_sno' => $template->sno,
                    'structure_code' => 'APR-' . now()->format('YmdHis') . random_int(100, 999),
                    'structure_name' => 'Salary Appraisal Structure',
                    'gross_salary' => $validated['gross_salary'],
                    'per_day_salary' => $this->perDaySalary($validated['gross_salary']),
                    'per_hour_cost' => $this->perHourCost($validated['gross_salary']),
                    'total_earnings' => $totals['earnings'],
                    'total_deductions' => $totals['deductions'],
                    'net_salary' => $totals['net_salary'],
                    'employer_contribution' => $totals['employer_contribution'],
                    'ctc_amount' => $totals['ctc'],
                    'revision_no' => $currentStructure ? ((int) ($currentStructure->revision_no ?? 0) + 1) : 1,
                    'revision_reason' => $validated['appraisal_reason'] ?? null,
                    'effective_from' => $effectiveFrom->toDateString(),
                    'effective_to' => null,
                    'is_current' => 1,
                    'status' => 0,
                    'created_by' => $userId,
                    'updated_by' => $userId,
                ]);
            }

            foreach ($preparedDetails as $detail) {
                PayrollStaffStructureDetailModel::create([
                    'payroll_employee_structure_sno' => $structure->sno,
                    'payroll_component_sno' => $detail['payroll_component_sno'],
                    'payroll_rule_sno' => $detail['payroll_rule_sno'],
                    'component_type' => $detail['component_type'],
                    'calculation_type' => $detail['calculation_type'],
                    'calculated_on' => $detail['calculated_on'],
                    'percentage_value' => $detail['percentage_value'],
                    'fixed_amount' => $detail['fixed_amount'],
                    'calculated_amount' => $detail['calculated_amount'],
                    'monthly_variable' => $detail['monthly_variable'],
                    'include_in_gross' => $detail['include_in_gross'],
                    'include_in_ctc' => $detail['include_in_ctc'],
                    'include_in_payslip' => $detail['include_in_payslip'],
                    'display_order' => $detail['display_order'],
                    'remarks' => $detail['remarks'],
                    'status' => 0,
                    'created_by' => $userId,
                    'updated_by' => $userId,
                ]);
            }

            $grossSalary = (float) $validated['gross_salary'];
            $salaryAccount->update([
                'gross_salary' => $grossSalary,
                'per_day_salary' => $this->perDaySalary($grossSalary),
                'per_hour_cost' => $this->perHourCost($grossSalary),
                'updated_by' => $userId,
                'updated_at' => now(),
            ]);

            $salaryTotalGross = StaffSalaryAccountModel::query()
                ->where('staff_id', $employee->sno)
                ->where('status', 0)
                ->sum('gross_salary');
            $salaryTotalPerDay = StaffSalaryAccountModel::query()
                ->where('staff_id', $employee->sno)
                ->where('status', 0)
                ->sum('per_day_salary');
            $salaryTotalPerHour = StaffSalaryAccountModel::query()
                ->where('staff_id', $employee->sno)
                ->where('status', 0)
                ->sum('per_hour_cost');

            $employee->update([
                'basic_salary' => $salaryTotalGross,
                'per_day_salary' => $salaryTotalPerDay,
                'per_hour_cost' => $salaryTotalPerHour,
                'updated_by' => $userId,
            ]);

            $variableCheck = (int) ($validated['variable_check'] ?? 0) === 1;
            $variableAmount = $variableCheck ? (float) ($validated['variable_amount'] ?? 0) : 0;
            $variableMonths = $variableCheck ? 3 : 0;
            $variableFrom = null;
            $variableEnd = null;

            if ($variableCheck) {
                if ($variableAmount <= 0) {
                    throw ValidationException::withMessages([
                        'variable_amount' => 'Variable amount must be greater than zero.'
                    ]);
                }

                $variableComponent = DB::table('egc_payroll_components')
                    ->where('sno', (int) $validated['variable_component'])
                    ->where('status', 0)
                    ->where(function ($q) {
                        $q->whereNull('component_type')->orWhere('component_type', 'earning');
                    })
                    ->first();

                if (!$variableComponent) {
                    throw ValidationException::withMessages([
                        'variable_component' => 'Select a valid variable payroll component.'
                    ]);
                }

                $variableFrom = Carbon::createFromFormat('Y-m', $validated['variable_from'] ?? $validated['effective_from'])->startOfMonth();
                $variableEnd = $variableFrom->copy()->addMonths(2)->endOfMonth();

                $overlap = DB::table('egc_payroll_variable_amounts')
                    ->where('employee_sno', $employee->sno)
                    ->where('payroll_component_sno', $variableComponent->sno)
                    ->where('status', 0)
                    ->whereDate('end_month', '>=', $variableFrom->toDateString())
                    ->exists();

                if ($overlap) {
                    throw ValidationException::withMessages([
                        'variable_component' => 'An active variable amount already exists for this employee and component.'
                    ]);
                }
            }

            $history = StaffSalaryAppraisalHistoryModel::create([
                'employee_sno' => $employee->sno,
                'salary_account_id' => $salaryAccount->sno,
                'payroll_template_sno' => $template->sno,
                'effective_from' => $effectiveFrom,
                'gross_salary' => $grossSalary,
                'appraisal_type' => (int) $validated['appraisal_type'],
                'appraisal_unit' => $validated['appraisal_unit'],
                'appraisal_value' => $validated['appraisal_value'] ?? null,
                'variable_from' => $variableFrom,
                'variable_end_month' => $variableEnd,
                'appraisal_reason' => $validated['appraisal_reason'] ?? null,
                'variable_component' => $variableCheck ? (int) $validated['variable_component'] : null,
                'variable_amount' => $variableAmount,
                'variable_months' => $variableMonths,
                'processed' => 1,
                'processed_at' => now(),
                'processed_by' => $userId,
                'status' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            if ($variableCheck) {
                DB::table('egc_payroll_variable_amounts')->insert([
                    'employee_sno' => $employee->sno,
                    'payroll_component_sno' => (int) $validated['variable_component'],
                    'amount' => $variableAmount,
                    'start_month' => $variableFrom->toDateString(),
                    'end_month' => $variableEnd->toDateString(),
                    'remarks' => 'Appraisal #' . $history->sno . ' - Variable Pay',
                    'status' => 0,
                    'created_by' => $userId,
                    'updated_by' => $userId,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }

            return [
                'status' => true,
                'message' => $variableCheck
                    ? 'Appraisal and 3-month variable pay saved successfully.'
                    : 'Appraisal and salary structure saved successfully.',
                'data' => [
                    'history_sno' => $history->sno,
                    'structure_sno' => $structure->sno,
                    'gross_salary' => $grossSalary,
                    'variable_check' => $variableCheck,
                    'variable_end_month' => $variableEnd?->format('Y-m'),
                ],
            ];
        });
    }

    /** Pending variable rows that have completed their 3-month window. */
    public function expiredVariableAppraisals(): array
    {
        $monthStart = now()->startOfMonth();

        $rows = DB::table('egc_payroll_variable_amounts as v')
            ->join('egc_staff as s', 's.sno', '=', 'v.employee_sno')
            ->leftJoin('egc_payroll_components as c', 'c.sno', '=', 'v.payroll_component_sno')
            ->leftJoin('egc_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('egc_entity as e', 'e.sno', '=', 's.entity_id')
            ->leftJoin('egc_branch as b', 'b.sno', '=', 's.branch_id')
            ->where('v.status', 0)
            ->where('s.status', 0)
            ->whereDate('v.end_month', '<', $monthStart->toDateString())
            ->orderBy('v.end_month')
            ->orderBy('s.staff_name')
            ->select([
                'v.sno',
                'v.employee_sno',
                'v.payroll_component_sno',
                'v.amount',
                'v.start_month',
                'v.end_month',
                'v.remarks',
                's.staff_name',
                's.staff_id',
                's.profile_image_url',
                's.basic_salary',
                's.entity_id',
                's.branch_id',
                's.department_id',
                'd.department_name',
                'e.entity_name',
                'b.branch_name',
                'c.component_name',
                'c.component_code',
            ])
            ->get();

        return [
            'status' => true,
            'count' => $rows->count(),
            'data' => $rows,
        ];
    }

    /**
     * Move one expired variable payment into gross salary and rebuild the
     * current payroll structure using the existing payroll template. No salary
     * history row is created here; the original appraisal history already holds it.
     */
    public function applyExpiredVariableAppraisal(int $variableId): array
    {
        return DB::transaction(function () use ($variableId) {
            $userId = $this->actingUserId();

            $variable = DB::table('egc_payroll_variable_amounts')
                ->where('sno', $variableId)
                ->where('status', 0)
                ->whereDate('end_month', '<', now()->startOfMonth()->toDateString())
                ->lockForUpdate()
                ->first();

            if (!$variable) {
                throw ValidationException::withMessages([
                    'variable_id' => 'This variable amount is not pending for gross salary update.'
                ]);
            }

            $employee = StaffModel::query()->lockForUpdate()->find($variable->employee_sno);
            if (!$employee || (int) $employee->status === 2) {
                throw ValidationException::withMessages([
                    'variable_id' => 'Active employee not found for this variable amount.'
                ]);
            }

            $account = StaffSalaryAccountModel::query()
                ->where('staff_id', $employee->sno)
                ->where('status', 0)
                ->orderByDesc('is_primary')
                ->orderBy('sno')
                ->lockForUpdate()
                ->first();

            if (!$account) {
                throw ValidationException::withMessages([
                    'variable_id' => 'No active salary account is available for this employee.'
                ]);
            }

            $currentStructure = PayrollStaffStructureModel::query()
                ->where('employee_sno', $employee->sno)
                ->where('salary_account_id', $account->sno)
                ->where('is_current', 1)
                ->where('status', 0)
                ->orderByDesc('effective_from')
                ->lockForUpdate()
                ->first();

            $templateId = $currentStructure?->payroll_template_sno;
            if (!$templateId) {
                $templateId = DB::table('egc_payroll_employee_structures')
                    ->where('employee_sno', $employee->sno)
                    ->where('salary_account_id', $account->sno)
                    ->where('status', 0)
                    ->orderByDesc('effective_from')
                    ->value('payroll_template_sno');
            }

            if (!$templateId) {
                throw ValidationException::withMessages([
                    'variable_id' => 'No payroll template is available to rebuild the salary structure.'
                ]);
            }

            $newGross = round((float) $account->gross_salary + (float) $variable->amount, 2);
            $effectiveFrom = now()->startOfMonth();

            [$preparedDetails, $totals] = $this->buildTemplateDetails((int) $templateId, $newGross, collect());

            if (empty($preparedDetails)) {
                throw ValidationException::withMessages([
                    'variable_id' => 'The existing payroll template has no usable salary components.'
                ]);
            }

            if ($currentStructure) {
                $currentStructure->update([
                    'is_current' => 0,
                    'effective_to' => $effectiveFrom->copy()->subDay()->toDateString(),
                    'updated_by' => $userId,
                ]);
            }

            $newStructure = PayrollStaffStructureModel::create([
                'employee_sno' => $employee->sno,
                'salary_account_id' => $account->sno,
                'payroll_template_sno' => $templateId,
                'structure_code' => 'VAR-' . now()->format('YmdHis') . random_int(100, 999),
                'structure_name' => 'Variable Pay Gross Merge',
                'gross_salary' => $newGross,
                'per_day_salary' => $this->perDaySalary($newGross),
                'per_hour_cost' => $this->perHourCost($newGross),
                'total_earnings' => $totals['earnings'],
                'total_deductions' => $totals['deductions'],
                'net_salary' => $totals['net_salary'],
                'employer_contribution' => $totals['employer_contribution'],
                'ctc_amount' => $totals['ctc'],
                'revision_no' => $currentStructure ? ((int) ($currentStructure->revision_no ?? 0) + 1) : 1,
                'revision_reason' => 'Expired 3-month variable pay merged into gross salary',
                'effective_from' => $effectiveFrom->toDateString(),
                'effective_to' => null,
                'is_current' => 1,
                'status' => 0,
                'created_by' => $userId,
                'updated_by' => $userId,
            ]);

            foreach ($preparedDetails as $detail) {
                PayrollStaffStructureDetailModel::create([
                    'payroll_employee_structure_sno' => $newStructure->sno,
                    'payroll_component_sno' => $detail['payroll_component_sno'],
                    'payroll_rule_sno' => $detail['payroll_rule_sno'],
                    'component_type' => $detail['component_type'],
                    'calculation_type' => $detail['calculation_type'],
                    'calculated_on' => $detail['calculated_on'],
                    'percentage_value' => $detail['percentage_value'],
                    'fixed_amount' => $detail['fixed_amount'],
                    'calculated_amount' => $detail['calculated_amount'],
                    'monthly_variable' => $detail['monthly_variable'],
                    'include_in_gross' => $detail['include_in_gross'],
                    'include_in_ctc' => $detail['include_in_ctc'],
                    'include_in_payslip' => $detail['include_in_payslip'],
                    'display_order' => $detail['display_order'],
                    'remarks' => $detail['remarks'],
                    'status' => 0,
                    'created_by' => $userId,
                    'updated_by' => $userId,
                ]);
            }

            $account->update([
                'gross_salary' => $newGross,
                'per_day_salary' => $this->perDaySalary($newGross),
                'per_hour_cost' => $this->perHourCost($newGross),
                'updated_by' => $userId,
                'updated_at' => now(),
            ]);

            $salaryTotalGross = StaffSalaryAccountModel::query()
                ->where('staff_id', $employee->sno)
                ->where('status', 0)
                ->sum('gross_salary');
            $salaryTotalPerDay = StaffSalaryAccountModel::query()
                ->where('staff_id', $employee->sno)
                ->where('status', 0)
                ->sum('per_day_salary');
            $salaryTotalPerHour = StaffSalaryAccountModel::query()
                ->where('staff_id', $employee->sno)
                ->where('status', 0)
                ->sum('per_hour_cost');

            $employee->update([
                'basic_salary' => $salaryTotalGross,
                'per_day_salary' => $salaryTotalPerDay,
                'per_hour_cost' => $salaryTotalPerHour,
                'updated_by' => $userId,
            ]);

            DB::table('egc_payroll_variable_amounts')
                ->where('sno', $variable->sno)
                ->update([
                    'status' => 1,
                    'remarks' => trim(($variable->remarks ?? 'Variable Pay') . ' | Merged into gross on ' . now()->format('d-M-Y')),
                    'updated_by' => $userId,
                    'updated_at' => now(),
                ]);

            return [
                'status' => true,
                'message' => 'Expired variable amount merged into gross salary and payroll structure updated successfully.',
                'data' => [
                    'variable_id' => $variable->sno,
                    'employee_sno' => $employee->sno,
                    'old_gross_salary' => (float) $account->gross_salary - (float) $variable->amount,
                    'variable_amount' => (float) $variable->amount,
                    'new_gross_salary' => $newGross,
                    'structure_sno' => $newStructure->sno,
                ],
            ];
        });
    }

    /** Pending active staff whose 6-month joining milestone has passed and leave count is still zero. */
    public function pendingCasualLeaveUpdates(): array
    {
        $eligibleOnOrBefore = now()->subMonthsNoOverflow(6)->toDateString();

        $rows = StaffModel::query()
            ->leftJoin('egc_company', 'egc_company.sno', '=', 'egc_staff.company_id')
            ->leftJoin('egc_entity', 'egc_entity.sno', '=', 'egc_staff.entity_id')
            ->leftJoin('egc_branch', 'egc_branch.sno', '=', 'egc_staff.branch_id')
            ->leftJoin('egc_department', 'egc_department.sno', '=', 'egc_staff.department_id')
            ->where('egc_staff.status', 0)
            ->whereNotNull('egc_staff.date_of_joining')
            ->whereDate('egc_staff.date_of_joining', '<=', $eligibleOnOrBefore)
            ->where(function ($q) {
                $q->whereNull('egc_staff.casual_leave_count_per_month')
                  ->orWhere('egc_staff.casual_leave_count_per_month', '<=', 0);
            })
            ->orderBy('egc_staff.date_of_joining')
            ->select([
                'egc_staff.sno',
                'egc_staff.staff_id',
                'egc_staff.staff_name',
                'egc_staff.profile_image_url',
                'egc_staff.date_of_joining',
                'egc_staff.casual_leave_count_per_month',
                'egc_staff.entity_id',
                'egc_staff.branch_id',
                'egc_staff.department_id',
                'egc_company.company_name',
                'egc_entity.entity_name',
                'egc_branch.branch_name',
                'egc_department.department_name',
            ])
            ->get()
            ->map(function ($row) {
                $joining = Carbon::parse($row->date_of_joining);
                $row->completed_six_months_on = $joining->copy()->addMonthsNoOverflow(6)->format('Y-m-d');
                $row->completed_months = $joining->diffInMonths(now());
                return $row;
            });

        return [
            'status' => true,
            'count' => $rows->count(),
            'data' => $rows,
        ];
    }

    public function updateCasualLeaves(Request $request): array
    {
        $validated = $request->validate([
            'staff' => 'required|array|min:1',
            'staff.*.employee_sno' => 'required|integer|min:1',
            'staff.*.casual_leave_count_per_month' => 'required|integer|min:1|max:31',
        ]);

        $userId = $this->actingUserId();

        return DB::transaction(function () use ($validated, $userId) {
            $updated = 0;
            foreach ($validated['staff'] as $row) {
                $employee = StaffModel::query()
                    ->where('sno', $row['employee_sno'])
                    ->where('status', 0)
                    ->lockForUpdate()
                    ->first();

                if (!$employee || empty($employee->date_of_joining)) {
                    continue;
                }

                $eligibleOn = Carbon::parse($employee->date_of_joining)->addMonthsNoOverflow(6);
                if (now()->lt($eligibleOn)) {
                    continue;
                }

                $employee->update([
                    'casual_leave_count_per_month' => (int) $row['casual_leave_count_per_month'],
                    'updated_by' => $userId,
                ]);
                $updated++;
            }

            return [
                'status' => true,
                'message' => $updated . ' staff casual leave record(s) updated successfully.',
                'updated' => $updated,
            ];
        });
    }

    private function getStructureDetails(int $structureId)
    {
        return DB::table('egc_payroll_employee_structure_details as d')
            ->join('egc_payroll_components as c', 'c.sno', '=', 'd.payroll_component_sno')
            ->leftJoin('egc_payroll_rules as r', 'r.id', '=', 'd.payroll_rule_sno')
            ->where('d.payroll_employee_structure_sno', $structureId)
            ->where('d.status', 0)
            ->orderBy('d.display_order')
            ->select([
                'd.sno',
                'd.payroll_component_sno',
                'd.payroll_rule_sno',
                'd.component_type',
                'd.calculation_type',
                'd.calculated_on',
                'd.percentage_value',
                'd.fixed_amount',
                'd.calculated_amount',
                'd.monthly_variable',
                'd.include_in_gross',
                'd.include_in_ctc',
                'd.include_in_payslip',
                'd.display_order',
                'd.remarks',
                'c.component_name',
                'c.component_code',
                'r.rule_name',
                'r.rule_expression',
            ])
            ->get();
    }

    /**
     * Build payroll employee structure details from a payroll template.
     * Browser-submitted values are only used for manual-input/formula components;
     * percentage and statutory calculations are always recomputed server-side.
     */
    private function buildTemplateDetails(int $templateId, float $grossSalary, $postedDetails): array
    {
        $templateRows = DB::table('egc_payroll_salary_template_details as d')
            ->join('egc_payroll_components as c', 'c.sno', '=', 'd.component_sno')
            ->leftJoin('egc_payroll_rules as r', 'r.id', '=', 'd.payroll_rule_sno')
            ->where('d.template_sno', $templateId)
            ->orderBy('c.display_order')
            ->select([
                'd.sno as template_detail_sno',
                'd.component_sno',
                'd.component_type',
                'd.calculation_type',
                'd.percentage',
                'd.amount',
                'd.payroll_rule_sno',
                'c.component_name',
                'c.component_code',
            ])
            ->get();

        $prepared = [];
        $earnings = 0.0;
        $deductions = 0.0;
        $employer = 0.0;
        $basic = 0.0;
        $da = 0.0;

        // Pass 1: earnings + BASIC/DA base.
        foreach ($templateRows as $row) {
            if ($row->component_type !== 'earning') {
                continue;
            }

            $amount = $this->componentAmount($row, $grossSalary, $postedDetails);
            if (strtoupper((string) $row->component_code) === 'BASIC') {
                $basic = $amount;
            }
            if (strtoupper((string) $row->component_code) === 'DA') {
                $da = $amount;
            }
            $earnings += $amount;
        }

        foreach ($templateRows as $index => $row) {
            $amount = $this->componentAmount($row, $grossSalary, $postedDetails, $basic, $da);

            if ($row->component_type === 'earning') {
                // Already included during pass 1.
            } elseif ($row->component_type === 'deduction') {
                $deductions += $amount;
            } elseif ($row->component_type === 'employer_contribution') {
                $employer += $amount;
            }

            $prepared[] = [
                'payroll_component_sno' => (int) $row->component_sno,
                'payroll_rule_sno' => $row->payroll_rule_sno ?: null,
                'component_type' => $row->component_type,
                'calculation_type' => $row->calculation_type ?: 'fixed',
                'calculated_on' => null,
                'percentage_value' => (float) ($row->percentage ?? 0),
                'fixed_amount' => round($amount, 2),
                'calculated_amount' => round($amount, 2),
                'monthly_variable' => 0,
                'include_in_gross' => $row->component_type === 'earning' ? 1 : 0,
                'include_in_ctc' => 1,
                'include_in_payslip' => 1,
                'display_order' => $index + 1,
                'remarks' => null,
                'component_name' => $row->component_name,
                'component_code' => $row->component_code,
            ];
        }

        $net = $earnings - $deductions;
        $ctc = $earnings + $employer;

        return [
            $prepared,
            [
                'earnings' => round($earnings, 2),
                'deductions' => round($deductions, 2),
                'employer_contribution' => round($employer, 2),
                'net_salary' => round($net, 2),
                'ctc' => round($ctc, 2),
            ],
        ];
    }

    private function componentAmount($row, float $grossSalary, $postedDetails, float $basic = 0.0, float $da = 0.0): float
    {
        $type = strtolower((string) ($row->calculation_type ?? 'fixed'));
        $code = strtoupper((string) ($row->component_code ?? ''));
        $percentage = (float) ($row->percentage ?? 0);
        $templateAmount = (float) ($row->amount ?? 0);
        $posted = $postedDetails[(int) $row->component_sno] ?? null;
        $postedAmount = $posted ? (float) ($posted['calculated_amount'] ?? $posted['fixed_amount'] ?? 0) : null;

        if ($row->component_type === 'earning') {
            if ($type === 'percentage') {
                return round(($grossSalary * $percentage) / 100, 2);
            }
            if (in_array($type, ['manual_input', 'formula'], true) && $postedAmount !== null) {
                return round($postedAmount, 2);
            }
            return round($templateAmount, 2);
        }

        if ($code === 'PF' && $type !== 'fixed') {
            $pfBase = $basic + $da;
            return round($pfBase > 15000 ? 1800 : ($pfBase * 0.12), 2);
        }

        if ($code === 'EMPLOYER_PF' && $type !== 'fixed') {
            $pfBase = $basic + $da;
            return round($pfBase > 15000 ? 1800 : ($pfBase * 0.12), 2);
        }

        if ($code === 'ESI') {
            $esiBase = $basic + $da;
            if ($type === 'fixed') {
                return round($templateAmount, 2);
            }
            return round($esiBase > 21000 ? 0 : ($esiBase * 0.0075), 2);
        }

        if ($code === 'EMPLOYER_ESI') {
            $esiBase = $basic + $da;
            if ($type === 'fixed') {
                return round($templateAmount, 2);
            }
            return round($esiBase > 21000 ? 0 : ($esiBase * 0.0325), 2);
        }

        if ($code === 'PT') {
            if ($type === 'fixed') {
                return $grossSalary <= 10000 ? 140.0 : 208.0;
            }
        }

        if ($type === 'percentage') {
            return round(($grossSalary * $percentage) / 100, 2);
        }

        if (in_array($type, ['manual_input', 'formula'], true) && $postedAmount !== null) {
            return round($postedAmount, 2);
        }

        return round($templateAmount, 2);
    }

    private function actingUserId(): int
    {
        return (int) (auth()->user()->user_id ?? auth()->id() ?? session('sno') ?? 0);
    }

    private function perDaySalary(float $gross): float
    {
        return round($gross / 30, 2);
    }

    private function perHourCost(float $gross): float
    {
        return round($gross / 240, 2);
    }

}