<?php

namespace App\Http\Controllers\hr_management\hr_sib;

use App\Http\Controllers\Controller;
use App\Models\CompanyTypeModel;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use App\Models\HolidayModel;
use App\Models\SocialMediaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Imports\TargetImport;
use App\Imports\TargetSheetImport;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\TargetAchievementModel;
use App\Models\StaffModel;
use App\Models\YearlyTargetModel;
use App\Models\QuarterTargetModel;
use App\Models\MonthTargetModel;
use App\Models\WeekTargetModel;
use App\Models\TargetWeekSettingModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Models\WebhookDispatchAttemptModel;
use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\Cache;
use App\Services\AppraisalService;


class ManageAppraisal extends Controller
{
    protected $service;

    public function __construct(AppraisalService $service)
    {
        $this->service = $service;
    }

    public function index(Request $request)
    {

        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $company_fill = $request->company_fill ?? '';
        $entity_fill = $request->entity_fill ?? '';
        $department_fill = $request->department_fill ?? '';
        $division_fill = $request->division_fill ?? '';
        $job_role_fill = $request->job_role_fill ?? '';
        $date_filter = $request->dt_fill_issue_rpt ?? '';
        $from_date_filter = $request->to_dt_iss_rpt ?? '';
        $to_date_filter = $request->to_date_fillter_textbox ?? '';

        
        $helper = new \App\Helpers\Helpers();
        $general_setting=$helper->general_setting_data();
        $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        $entity_list  = ManageEntityModel::where('status', 0)->orderBy('sno', 'ASC')->get();
        return view('content.hr_management.hr_sib.manage_appraisal.staff_salary_appraisal',[
            'company_list' => $company_list,
            'entity_list' => $entity_list ,
            'perpage' => $perpage,

        ]);
    }

    public function list(Request $request)
    {
        return response()->json(
            $this->service->list($request)
        );
    }

    public function details($staff)
    {
        return response()->json(
            $this->service->details($staff)
        );
    }

    public function history($staff)
    {
        return response()->json(
            $this->service->history($staff)
        );
    }

    public function appraisalFormData()
    {
        return response()->json(
            $this->service->appraisalFormData()
        );
    }

    public function appraisalStaffOptions(Request $request)
    {
        return response()->json(
            $this->service->appraisalStaffOptions($request)
        );
    }

    public function appraisalStaffProfile($staff)
    {
        try {
            return response()->json(
                $this->service->appraisalStaffProfile((int) $staff)
            );
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
                'errors' => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            Log::error('Manage Appraisal staff profile load failed', [
                'staff' => $staff,
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to load employee appraisal profile.',
            ], 500);
        }
    }

    public function saveAppraisal(Request $request)
    {
        try {
            return response()->json(
                $this->service->saveAppraisal($request)
            );
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => 'Please correct the highlighted appraisal fields.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            Log::error('Manage Appraisal save failed', [
                'employee_sno' => $request->input('employee_sno'),
                'salary_account_id' => $request->input('salary_account_id'),
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to save appraisal. Please try again.',
            ], 500);
        }
    }

    public function expiredVariableAppraisals()
    {
        try {
            return response()->json(
                $this->service->expiredVariableAppraisals()
            );
        } catch (\Throwable $e) {
            Log::error('Manage Appraisal expired variable check failed', [
                'message' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to load expired variable appraisal records.',
            ], 500);
        }
    }

    public function applyExpiredVariableAppraisal($variable)
    {
        try {
            return response()->json(
                $this->service->applyExpiredVariableAppraisal((int) $variable)
            );
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => 'This variable appraisal can no longer be updated.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            Log::error('Manage Appraisal expired variable merge failed', [
                'variable_id' => $variable,
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to update the expired variable amount.',
            ], 500);
        }
    }

    public function pendingCasualLeaveUpdates()
    {
        try {
            return response()->json(
                $this->service->pendingCasualLeaveUpdates()
            );
        } catch (\Throwable $e) {
            Log::error('Manage Appraisal casual leave pending check failed', [
                'message' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to load pending casual leave records.',
            ], 500);
        }
    }

    public function updateCasualLeaves(Request $request)
    {
        try {
            return response()->json(
                $this->service->updateCasualLeaves($request)
            );
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => 'Please enter a valid casual leave count for the selected staff.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            Log::error('Manage Appraisal casual leave update failed', [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'status' => false,
                'message' => 'Unable to update casual leave records.',
            ], 500);
        }
    }

}
