@extends('layouts/layoutMaster')

@section('title', 'Manage Appraisal')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms-pickers.js']),
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

@php

$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id ;
$auth_id = auth()->user()->id ;
@endphp
<style>
    .salary-box.exited{
        background:#F5F5F5;
        color:#BDBDBD;
        border:1px dashed #D6D6D6;
        cursor:not-allowed;
    }
    .employee-exit{
        margin-top:8px;
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:10px;
    }

    .exit-date{
        color:#6B7280;
        font-size:11px;
        font-weight:600;
    }

    /* Notice */
    .chip-notice{
        background:#FFF3CD;
        color:#B26A00;
    }

    /* Relieved */
    .chip-relieved{
        background:#DCFCE7;
        color:#15803D;
    }
    /* Abscond */
    .chip-abscond{
        background:#FEF3C7;
        color:#B45309;
    }
    /* Terminated */

    .chip-terminated{
        background:#FEE2E2;
        color:#DC2626;
    }
</style>

<style>
    .employee-card{

        display:flex;
        align-items:center;
        position:relative;
        min-width:320px;

    }

.company-strip{

    width:5px;
    align-self:stretch;
    border-radius:10px;
    margin-right:12px;

}

.staff-avatar{

    width:52px;
    height:52px;
    border-radius:50%;
    object-fit:fill;
    border:2px solid #ECECEC;
    flex-shrink:0;

}

.employee-info{

    flex:1;
    overflow:hidden;

}

.employee-name{

    font-size:15px;
    font-weight:700;
    color:#222;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;

}

.employee-department{

    font-size:12px;
    color:#777;
    margin-top:2px;

}

.employee-footer{

    display:flex;
    flex-wrap:wrap;
    gap:6px;
    margin-top:7px;

}

.employee-chip{

    display:inline-flex;
    align-items:center;
    gap:4px;
    padding:2px 8px;
    border-radius:20px;
    font-size:11px;
    font-weight:600;

}

.chip-company{

    background:#fff;
    border:1px solid;

}

.chip-id{

    background:#F5F5F5;
    color:#555;

}

/* .chip-success{

    background:#DFF7E8;
    color:#0E8F48;

} */
</style>

<style>
    #loadingSkeleton{

        display:none;

    }

    #appraisalTable{

        display:block;

    }
   .appraisal-wrapper{
        overflow:auto;
        max-height:78vh;
    }

    .appraisal-table{
        min-width:max-content;
        border-collapse:separate;
        border-spacing:0;
    }

    .employee-col{
        min-width:300px;
    }

    .month-col{
        min-width:110px;
        text-align:center;
    }

    .current-col{
        min-width:140px;
        text-align:center;
    }

    .action-col{
        width:90px;
        text-align:center;
    }

    .sticky-left{
        position:sticky;
        left:0;
        background:#fff;
        z-index:100;
        box-shadow:5px 0 15px rgba(0,0,0,.05);
    }

    .sticky-right{
        position:sticky;
        right:0;
        background:#fff;
        z-index:100;
        box-shadow:-5px 0 15px rgba(0,0,0,.05);
    }

    /* .staff-avatar{
        width:48px;
        height:48px;
        border-radius:50%;
        object-fit:fill;
        border:2px solid #e5e7eb;
    } */

    .salary-box{
        padding:12px;
        border-radius:10px;
        text-align:center;
        font-weight:700;
        transition:.25s;
    }

    .before{
        background:#ECEFF1;
        color:#9E9E9E;
        pointer-events:none;
        opacity:.7;
    }

    .joining{
        background:#1565C0;
        color:#fff;
    }

    .normal{
        background:#fff;
        border:1px solid #E5E7EB;
    }

    .appraisal{
        background:#2ECC71;
        color:#fff;
    }

    .current{
        background:#FFF8E1;
        border:2px solid #FF9800;
        font-weight:700;
        color:#E65100;
    }

    .salary-box:hover{
        transform:translateY(-2px);
        box-shadow:0 10px 20px rgba(0,0,0,.12);
    }
</style>
<style>
    .salary-timeline{

    position:relative;

    margin-top:35px;

    padding-left:40px;

}

.salary-timeline::before{

    content:"";

    position:absolute;

    left:22px;

    top:0;

    bottom:0;

    width:4px;

    background:#E5E7EB;

}

.salary-timeline-item{

    position:relative;

    margin-bottom:30px;

}

.salary-timeline-dot{

    position:absolute;

    left:-30px;

    top:28px;

    width:18px;

    height:18px;

    border-radius:50%;

    border:4px solid #fff;

    /* box-shadow:0 0 0 4px #1565C0;
    background:#1565C0; */

    box-shadow:0 0 0 4px #AB2B22;
    background:#AB2B22;

}

.salary-timeline-card{

    background:#fff;

    border-radius:18px;

    padding:22px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);

    transition:.3s;

}

.salary-timeline-card:hover{

    transform:translateY(-3px);

}

.salary-new{

    font-size:30px;

    font-weight:700;

    color:#198754;

}

.salary-old{

    text-decoration:line-through;

    color:#9CA3AF;

}

.salary-timeline-badge{

    border-radius:30px;

    padding:5px 12px;

    font-size:12px;

    font-weight:600;

}
.analytics-card{

    background:#fff;

    border-radius:18px;

    padding:25px;

    box-shadow:0 10px 30px rgba(0,0,0,.08);

    height:100%;

}

.analytics-title{

    color:#6B7280;

    font-size:14px;

}

.analytics-value{

    font-size:34px;

    font-weight:700;

}

.salary-progress{

    height:18px;

    border-radius:20px;

    overflow:hidden;

    background:#E5E7EB;

}

.salary-progress .progress-bar{

    font-weight:700;

}

.stat-item{

    display:flex;

    justify-content:space-between;

    padding:12px 0;

    border-bottom:1px dashed #EEE;

}
</style>
<style>
    .dashboard-card{
        border:none;
        border-radius:18px;
        overflow:hidden;
        transition:.3s;
        cursor:pointer;
        color:#fff;

        min-height:135px;      /* Same height */
        height:100%;

        display:flex;
    }
   

    .dashboard-card:hover{
        transform:translateY(-6px);
        box-shadow:0 18px 40px rgba(0,0,0,.18);

    }

    .dashboard-icon{
        width:30px;
        height:30px;
        border-radius:8px;
        display:flex;
        align-items:center;
        justify-content:center;
        background:rgba(255,255,255,.18);
    }

    .dashboard-value{
        font-size:34px;
        font-weight:700;
    }

    .dashboard-title{
        font-size:15px;
        font-weight:600;
        white-space:nowrap;
    }

    

    .bg-blue{
        background:linear-gradient(135deg,#4F8EF7,#2455D6);
    }

    .bg-green{
        background:linear-gradient(135deg,#38C172,#1E824C);
    }

    .bg-orange{
        background:linear-gradient(135deg,#FF9F43,#FF6B00);
    }

    .bg-red{
        background:linear-gradient(135deg,#FF5E7E,#E63757);
    }

    .bg-purple{
        background:linear-gradient(135deg,#7367F0,#5E50EE);
    }

    .progress{
        height:10px;
        border-radius:10px;
    }

    .progress-bar{
        border-radius:10px;
    }
</style>
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Manage Appraisal</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-trophy"></i> HR Management
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            HR SIB
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="d-flex align-items-center justify-content-end gap-2 flex-wrap">
                <button type="button" class="btn btn-sm fw-bold btn-primary text-white" id="addAppraisalBtn" onclick="openAddAppraisalModal()">
                    <i class="mdi mdi-plus-circle-outline me-1"></i> Add Appraisal
                </button>
                <button type="button" class="btn btn-sm fw-bold btn-outline-primary" id="pendingCasualLeaveBtn" onclick="openCasualLeaveModal()">
                    <i class="mdi mdi-calendar-account-outline me-1"></i> Casual Leave
                    <span class="badge bg-danger ms-1 d-none" id="pendingCasualLeaveBadge">0</span>
                </button>
                <button type="button" class="btn btn-sm fw-bold btn-outline-warning d-none" id="expiredVariableBtn" onclick="openExpiredVariableModal()">
                    <i class="mdi mdi-cash-sync me-1"></i> Variable Pending
                    <span class="badge bg-warning text-dark ms-1" id="expiredVariableBadge">0</span>
                </button>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="filter">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">

        <div class="filter_tbox" style="display: none;">
            <input type="hidden" name="page" value="{{ request('page', 1) }}">
            <input type="hidden" name="filter_on" value="1">
            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />

            <div class="row mb-3 border rounded py-1">
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                    <select id="company_fill" name="company_fill" class="select3 form-select">
                        <option value="">Select Company Name</option>
                        <option value="egc">Elysium Groups</option>
                        @if(isset($company_list))
                        @foreach($company_list as $clist)
                        <option value="{{$clist->sno}}" >{{$clist->company_name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                    <select id="entity_fill" name="entity_fill" class="select3 form-select">
                        <option value="">Select Entity Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Department Name<span class="text-danger">*</span></label>
                    <select id="department_fill" name="department_fill" class="select3 form-select">
                        <option value="">Select Department Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Division Name<span class="text-danger">*</span></label>
                    <select id="division_fill" name="division_fill" class="select3 form-select">
                        <option value="">Select Division Name</option>
                    </select>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                    <select id="job_role_fill" name="job_role_fill" class="select3 form-select">
                        <option value="">Select Job Role Name</option>
                    </select>
                </div>
                <!-- <div class="col-lg-4 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Month</option>
                    </select>
                </div>
                 -->
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3 mb-3">
                <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-secondary btn-sm me-3">Reset</a>
                <a href="javascript:;" class="filterSubmit" id="filterSubmit">
                    <span class="btn btn-primary btn-sm"> Go</span>
                </a>
            </div>
        </div>
        <div class="row g-4 align-items-stretch" id="dashboardCards"></div>
        
        <div class="">

            <div class="">
                <div class="d-flex align-items-center justify-content-between mb-4 ">
                    <div>
                        <span>Show</span>
                        <select id="perpage" class="form-select form-select-sm w-75px"
                            onchange="loadEmployees(1)">
                            @php $options = [5,10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                            <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                {{ $option }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input type="text" id="search_filter" class="searchQueryInput"
                                placeholder="Search Staff Name/mobile..."
                                value="" />

                            <div class="searchAction">
                                <div class="d-flex align-items-center">
                                    <a href="javascript:;" class="searchSubmit" id="searchSubmit">
                                        <span class="mdi mdi-magnify fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                    <a href="javascript:;" class="refreshBar" id="refreshSearch">
                                        <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="appraisalTableContainer">
                    <div id="loadingSkeleton" style="display:none">
                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                @for($i=0;$i<3;$i++)
                                    <tr>
                                        @for($j=0;$j<6;$j++)
                                        <td>
                                            <div class="placeholder-glow">
                                                <span class="placeholder col-12 rounded" style="height:38px;"></span>
                                            </div>
                                        </td>
                                        @endfor
                                    </tr>
                                @endfor
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div id="appraisalTable"></div>
                    <div class="text-center my-3" id="pagination-container">
                        <!-- Pagination buttons will appear here -->
                    </div>
                </div>

            </div>

        </div>
    </div>

</div>

<style>
    .appraisal-action-alert {
        border: 0;
        border-radius: 16px;
        box-shadow: 0 8px 24px rgba(31, 41, 55, 0.08);
    }
    .appraisal-xl-modal .modal-dialog {
        max-width: 1500px;
        width: calc(100% - 24px);
    }
    .appraisal-modal-shell {
        border: 0;
        overflow: hidden;
        border-radius: 22px;
        box-shadow: 0 24px 70px rgba(15, 23, 42, 0.24);
    }
    .appraisal-modal-header {
        background: linear-gradient(135deg, #5e50ee 0%, #7367f0 48%, #8b7ff7 100%);
        color: #fff;
        padding: 20px 24px;
    }
    .appraisal-section-card {
        border: 1px solid #edf0f6;
        border-radius: 18px;
        box-shadow: 0 8px 22px rgba(31, 41, 55, 0.05);
        background: #fff;
    }
    .appraisal-section-title {
        font-size: 14px;
        font-weight: 800;
        color: #1f2937;
        letter-spacing: .01em;
    }
    .appraisal-label {
        font-size: 12px;
        font-weight: 700;
        color: #4b5563;
        margin-bottom: 6px;
    }
    .appraisal-required::after {
        content: ' *';
        color: #dc3545;
    }
    .appraisal-profile-card {
        background: linear-gradient(145deg, #fff, #f8f9ff);
        border: 1px solid #eef0f7;
        border-radius: 18px;
    }
    .appraisal-profile-avatar {
        width: 74px;
        height: 74px;
        object-fit: cover;
        border-radius: 50%;
        border: 3px solid #fff;
        box-shadow: 0 6px 18px rgba(15, 23, 42, .12);
    }
    .appraisal-profile-name {
        font-size: 18px;
        font-weight: 800;
        color: #111827;
    }
    .appraisal-profile-meta {
        font-size: 12px;
        color: #6b7280;
    }
    .appraisal-info-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
    }
    .appraisal-info-box {
        border: 1px solid #edf0f6;
        background: #fff;
        border-radius: 12px;
        padding: 10px 12px;
    }
    .appraisal-info-box .title {
        font-size: 10px;
        text-transform: uppercase;
        color: #9ca3af;
        font-weight: 700;
        letter-spacing: .04em;
    }
    .appraisal-info-box .value {
        font-size: 12px;
        font-weight: 700;
        color: #1f2937;
        margin-top: 2px;
        word-break: break-word;
    }
    .appraisal-salary-highlight {
        border-radius: 15px;
        padding: 14px;
        background: linear-gradient(135deg, #f7f5ff, #fff);
        border: 1px solid #e8e4ff;
    }
    .appraisal-salary-highlight .amount {
        font-size: 26px;
        line-height: 1.1;
        font-weight: 900;
        color: #5e50ee;
    }
    .appraisal-mini-kpis {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 8px;
    }
    .appraisal-mini-kpi {
        border-radius: 12px;
        background: #fff;
        border: 1px solid #edf0f6;
        padding: 9px 10px;
    }
    .appraisal-mini-kpi .kpi-title {
        font-size: 10px;
        color: #9ca3af;
        font-weight: 700;
    }
    .appraisal-mini-kpi .kpi-value {
        font-size: 13px;
        font-weight: 800;
        color: #111827;
        margin-top: 2px;
    }
    .appraisal-component-row {
        border: 1px solid #edf0f6;
        background: linear-gradient(180deg, #fff, #fafbff);
        border-radius: 14px;
        padding: 12px;
        margin-bottom: 10px;
    }
    .appraisal-component-row:last-child {
        margin-bottom: 0;
    }
    .appraisal-component-row .component-name {
        font-weight: 800;
        font-size: 12px;
        color: #1f2937;
    }
    .appraisal-component-row .component-code {
        font-size: 10px;
        color: #9ca3af;
    }
    .appraisal-component-row .form-control {
        min-height: 38px;
    }
    .appraisal-summary-card {
        position: sticky;
        top: 14px;
        border-radius: 18px;
        background: linear-gradient(145deg, #161a2d, #25294a);
        color: #fff;
        box-shadow: 0 16px 40px rgba(17, 24, 39, .18);
    }
    .appraisal-summary-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 9px 0;
        border-bottom: 1px solid rgba(255,255,255,.08);
        font-size: 12px;
    }
    .appraisal-summary-item:last-child {
        border-bottom: 0;
    }
    .appraisal-summary-item strong {
        font-size: 13px;
    }
    .appraisal-loading {
        min-height: 180px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6b7280;
    }
    .appraisal-empty {
        border: 1px dashed #d9dce8;
        border-radius: 14px;
        padding: 24px;
        text-align: center;
        color: #6b7280;
        background: #fbfbfe;
    }
    .appraisal-variable-card {
        border: 1px dashed #f3b33d;
        border-radius: 14px;
        background: #fffaf0;
    }
    .appraisal-table-wrap {
        max-height: 55vh;
        overflow: auto;
    }
    .appraisal-table-wrap thead th {
        position: sticky;
        top: 0;
        z-index: 2;
        background: #f8f9fb;
    }
    @media (max-width: 991.98px) {
        .appraisal-summary-card {
            position: static;
        }
        .appraisal-mini-kpis {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }
</style>

<div id="appraisalPendingActionAlert" class="alert alert-warning appraisal-action-alert d-none mb-4">
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
        <div class="d-flex align-items-center gap-3">
            <div class="rounded-circle d-flex align-items-center justify-content-center bg-warning text-dark" style="width:42px;height:42px;flex:0 0 42px;">
                <i class="mdi mdi-bell-alert-outline fs-4"></i>
            </div>
            <div>
                <div class="fw-bold text-dark" id="appraisalPendingActionTitle">Action required</div>
                <div class="small text-dark" id="appraisalPendingActionText">There are pending HR updates.</div>
            </div>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <button type="button" class="btn btn-sm btn-warning fw-bold d-none" id="openExpiredVariableFromAlert" onclick="openExpiredVariableModal()">
                <i class="mdi mdi-cash-sync me-1"></i>Review Variable Pay
            </button>
            <button type="button" class="btn btn-sm btn-outline-dark fw-bold d-none" id="openCasualLeaveFromAlert" onclick="openCasualLeaveModal()">
                <i class="mdi mdi-calendar-account-outline me-1"></i>Update Casual Leave
            </button>
        </div>
    </div>
</div>

<!-- Add Appraisal -->
<div class="modal fade appraisal-xl-modal" id="addAppraisalModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content appraisal-modal-shell">
            <div class="appraisal-modal-header">
                <div class="d-flex align-items-center justify-content-between gap-3">
                    <div>
                        <div class="fw-bold fs-4"><i class="mdi mdi-trophy-award me-2"></i>Add Salary Appraisal</div>
                        <div class="small opacity-75 mt-1">Create the appraisal, payroll structure and variable-pay record in one controlled HR flow.</div>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
            </div>
            <div class="modal-body bg-light p-3 p-lg-4">
                <form id="addAppraisalForm" autocomplete="off">
                    <div class="row g-4">
                        <div class="col-xl-7">
                            <div class="appraisal-section-card p-3 p-lg-4 mb-4">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <div>
                                        <div class="appraisal-section-title"><i class="mdi mdi-account-search-outline me-1 text-primary"></i> Employee Selection</div>
                                        <small class="text-muted">Choose entity, department and staff before entering the revision.</small>
                                    </div>
                                    <span class="badge bg-light text-primary" id="appraisalSelectionStatus">Step 1</span>
                                </div>
                                <div class="row g-3">
                                    <div class="col-lg-6">
                                        <label class="appraisal-label appraisal-required">Entity</label>
                                        <select id="appraisal_entity_id" class="form-select select3">
                                            <option value="">Select Entity</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-6 d-none" id="appraisalBranchWrap">
                                        <label class="appraisal-label appraisal-required">Branch</label>
                                        <select id="appraisal_branch_id" class="form-select select3">
                                            <option value="">Select Branch</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-6">
                                        <label class="appraisal-label appraisal-required">Department</label>
                                        <select id="appraisal_department_id" class="form-select select3" disabled>
                                            <option value="">Select Department</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-6">
                                        <label class="appraisal-label appraisal-required">Staff</label>
                                        <select id="appraisal_employee_sno" class="form-select select3" disabled>
                                            <option value="">Select Staff</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="appraisal-section-card p-3 p-lg-4 mb-4">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <div>
                                        <div class="appraisal-section-title"><i class="mdi mdi-file-document-edit-outline me-1 text-primary"></i> Appraisal Details</div>
                                        <small class="text-muted">Use the same appraisal fields used by Salary History.</small>
                                    </div>
                                </div>
                                <div class="row g-3">
                                    <div class="col-lg-6">
                                        <label class="appraisal-label appraisal-required">Salary Account</label>
                                        <select id="appraisal_salary_account_id" class="form-select select3" disabled>
                                            <option value="">Select Salary Account</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-6">
                                        <label class="appraisal-label appraisal-required">Effective Month</label>
                                        <input type="text" id="appraisal_effective_from" class="form-control" placeholder="Select Month" readonly>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="appraisal-label appraisal-required">Appraisal Type</label>
                                        <select id="appraisal_type" class="form-select select3">
                                            <option value="1">Yearly Appraisal</option>
                                            <option value="2">Special Appraisal</option>
                                            <option value="3">Promotion</option>
                                            <option value="5">10X Warrior</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="appraisal-label appraisal-required">Unit</label>
                                        <select id="appraisal_unit" class="form-select select3">
                                            <option value="%">%</option>
                                            <option value="Rs">Rs</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="appraisal-label">Appraisal Value</label>
                                        <input type="text" id="appraisal_value" class="form-control" placeholder="Enter value" inputmode="decimal" oninput="this.value=this.value.replace(/[^0-9.]/g,'').replace(/(\..*)\./g,'$1');">
                                    </div>
                                    <div class="col-12">
                                        <label class="appraisal-label">Reason / Remarks</label>
                                        <textarea id="appraisal_reason" class="form-control" rows="3" maxlength="1000" placeholder="Reason for appraisal"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="appraisal-section-card p-3 p-lg-4 mb-4">
                                <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
                                    <div>
                                        <div class="appraisal-section-title"><i class="mdi mdi-cash-multiple me-1 text-primary"></i> New Payroll Structure</div>
                                        <small class="text-muted">Changing gross salary recalculates the selected template components.</small>
                                    </div>
                                    <span class="badge bg-success-subtle text-success" id="appraisalCurrentGrossBadge">Current ₹0.00</span>
                                </div>
                                <div class="row g-3 mb-3">
                                    <div class="col-lg-6">
                                        <label class="appraisal-label appraisal-required">Payroll Template</label>
                                        <select id="appraisal_payroll_template_sno" class="form-select select3" disabled>
                                            <option value="">Select Payroll Template</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-6">
                                        <label class="appraisal-label appraisal-required">Gross Salary</label>
                                        <div class="input-group">
                                            <span class="input-group-text">₹</span>
                                            <input type="text" id="appraisal_gross_salary" class="form-control fw-bold" placeholder="Enter revised gross salary" inputmode="decimal" disabled oninput="this.value=this.value.replace(/[^0-9.]/g,'').replace(/(\..*)\./g,'$1');">
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <div class="fw-bold text-dark small">Salary Components</div>
                                    <div class="small text-muted" id="appraisalTemplateStatus">Select a template</div>
                                </div>
                                <div id="appraisal_salary_components">
                                    <div class="appraisal-empty">Select a staff and payroll template to load the salary structure.</div>
                                </div>
                            </div>

                            <div class="appraisal-variable-card p-3 p-lg-4 d-none" id="appraisalVariableSection">
                                <div class="d-flex align-items-start gap-3 mb-3">
                                    <div class="form-check form-switch mt-1">
                                        <input class="form-check-input" type="checkbox" id="appraisal_variable_check">
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark">3-Month Variable Pay</div>
                                        <div class="small text-muted">Variable pay is kept outside gross salary for exactly 3 months and is stored separately.</div>
                                    </div>
                                </div>
                                <div id="appraisalVariableFields" class="d-none">
                                    <div class="row g-3">
                                        <div class="col-lg-6">
                                            <label class="appraisal-label appraisal-required">Variable Component</label>
                                            <select id="appraisal_variable_component" class="form-select select3">
                                                <option value="">Select Variable Component</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3">
                                            <label class="appraisal-label appraisal-required">Variable Amount</label>
                                            <div class="input-group">
                                                <span class="input-group-text">₹</span>
                                                <input type="text" id="appraisal_variable_amount" class="form-control" placeholder="0.00" inputmode="decimal" oninput="this.value=this.value.replace(/[^0-9.]/g,'').replace(/(\..*)\./g,'$1');">
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <label class="appraisal-label appraisal-required">Months</label>
                                            <input type="text" id="appraisal_variable_months" class="form-control bg-light" value="3" readonly>
                                        </div>
                                        <div class="col-lg-6">
                                            <label class="appraisal-label appraisal-required">Start Month</label>
                                            <input type="text" id="appraisal_variable_from" class="form-control" placeholder="Select Month" readonly>
                                        </div>
                                        <div class="col-lg-6">
                                            <label class="appraisal-label">Ends After 3 Months</label>
                                            <input type="text" id="appraisal_variable_end" class="form-control bg-light" readonly placeholder="Auto calculated">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-5">
                            <div class="appraisal-profile-card p-3 p-lg-4 mb-4" id="appraisalStaffProfilePanel">
                                <div class="appraisal-empty">
                                    <i class="mdi mdi-account-circle-outline fs-1 text-primary"></i>
                                    <div class="fw-bold mt-2">Staff profile</div>
                                    <div class="small">Select a staff member to see profile, current salary and last appraisal.</div>
                                </div>
                            </div>

                            <div class="appraisal-section-card p-3 p-lg-4 mb-4">
                                <div class="appraisal-section-title mb-3"><i class="mdi mdi-history me-1 text-primary"></i> Current Salary Detail</div>
                                <div id="appraisalCurrentSalaryPanel">
                                    <div class="appraisal-empty">Current salary details will appear after staff selection.</div>
                                </div>
                            </div>

                            <div class="appraisal-section-card p-3 p-lg-4 mb-4">
                                <div class="appraisal-section-title mb-3"><i class="mdi mdi-clipboard-text-clock-outline me-1 text-primary"></i> Last Appraisal Detail</div>
                                <div id="appraisalLastAppraisalPanel">
                                    <div class="appraisal-empty">No employee selected.</div>
                                </div>
                            </div>

                            <div class="appraisal-summary-card p-3 p-lg-4">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <div>
                                        <div class="fw-bold fs-5">Revised Payroll Preview</div>
                                        <div class="small opacity-75">Template based calculation</div>
                                    </div>
                                    <i class="mdi mdi-calculator-variant-outline fs-2 opacity-75"></i>
                                </div>
                                <div class="appraisal-summary-item"><span>Total Earnings</span><strong id="appraisal_total_earnings">₹ 0.00</strong></div>
                                <div class="appraisal-summary-item"><span>Total Deductions</span><strong id="appraisal_total_deductions">₹ 0.00</strong></div>
                                <div class="appraisal-summary-item"><span>Net Salary</span><strong id="appraisal_net_salary">₹ 0.00</strong></div>
                                <div class="appraisal-summary-item"><span>Employer Contribution</span><strong id="appraisal_employer_contribution">₹ 0.00</strong></div>
                                <div class="appraisal-summary-item"><span>Monthly CTC</span><strong id="appraisal_ctc">₹ 0.00</strong></div>
                                <button type="button" class="btn btn-primary w-100 mt-4 fw-bold" id="saveAppraisalBtn" onclick="saveManageAppraisal()">
                                    <i class="mdi mdi-content-save-check-outline me-1"></i> Save Appraisal
                                </button>
                                <div class="small text-center opacity-75 mt-2">Salary history and payroll structure are saved together.</div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Expired Variable Pay -->
<div class="modal fade" id="expiredVariableModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content appraisal-modal-shell">
            <div class="modal-header bg-warning">
                <div>
                    <h5 class="modal-title text-dark fw-bold mb-1"><i class="mdi mdi-cash-sync me-2"></i>Expired Variable Pay</h5>
                    <div class="small text-dark">These 3-month variable records are ready to be moved into gross salary. No new salary-history record will be created.</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body bg-light">
                <div id="expiredVariableSummary" class="alert alert-light border mb-3"></div>
                <div id="expiredVariableRows" class="appraisal-table-wrap"></div>
            </div>
        </div>
    </div>
</div>

<!-- Pending 6-Month Casual Leave -->
<div class="modal fade" id="casualLeaveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content appraisal-modal-shell">
            <div class="modal-header bg-primary text-white">
                <div>
                    <h5 class="modal-title fw-bold mb-1"><i class="mdi mdi-calendar-account-outline me-2"></i>Pending 6-Month Casual Leave</h5>
                    <div class="small opacity-75">Active staff who completed 6 months from joining and still have no casual-leave allowance configured.</div>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body bg-light">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
                    <div class="input-group" style="max-width:420px;">
                        <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                        <input type="text" class="form-control" id="casualLeaveSearch" placeholder="Search staff / department...">
                    </div>
                    <span class="badge bg-danger fs-6" id="casualLeavePendingCount">0 Pending</span>
                </div>
                <div id="casualLeaveRows" class="appraisal-table-wrap"></div>
            </div>
            <div class="modal-footer bg-white">
                <div class="small text-muted me-auto">Enter the monthly casual-leave allowance approved by HR.</div>
                <button type="button" class="btn btn-primary fw-bold" id="saveCasualLeaveBtn" onclick="saveCasualLeaveUpdates()">
                    <i class="mdi mdi-content-save-outline me-1"></i> Save Leave Updates
                </button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="salaryModal">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary pb-4 text-white">
                <span class="mb-0 text-white fs-4 fw-bold">
                    <i class="mdi mdi-cash-multiple me-2 fs-4"></i>
                    Salary Appraisal Profile
                </span>
                <button
                    class="btn-close btn-close-white"
                    data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body bg-light">
                <div id="salaryContent"></div>
            </div>
        </div>
    </div>
</div>

<style>
    .hero-card{
        /* background:linear-gradient(135deg,#2F80ED,#56CCF2); */
        /* background: linear-gradient(135deg, #B52A1F 0%, #D64532 100%); */
        background:linear-gradient(
        135deg,
        #AB2B22 0%,
        #B52A1F 40%,
        #D64532 75%,
        #FDB72C 100%
        );
        border-radius:18px;
        padding:30px;
        color:#fff;
        overflow:hidden;
        position:relative;
    }
    .hero-card::after{
        content:"";
        position:absolute;
        right:-50px;
        top:-40px;
        width:220px;
        height:220px;
        background:rgba(255,255,255,.08);
        border-radius:50%;
    }

    .hero-avatar{
        width:110px;
        height:110px;
        border-radius:50%;
        border:5px solid rgba(255,255,255,.25);
        object-fit:fill;

    }
    .hero-title{
        font-size:28px;
        font-weight:700;
    }
    .hero-sub{
        opacity:.9;
    }
    .hero-chip{
        display:inline-block;
        padding:5px 14px;
        border-radius:30px;
        background:rgba(255,255,255,.18);
        margin-right:8px;
        font-size:12px;
    }
    .kpi-card{
        background:#fff;
        border-radius:14px;
        padding:20px;
        box-shadow:0 8px 25px rgba(0,0,0,.08);
        text-align:center;
        height:100%;

    }
    .kpi-number{
        font-size:28px;
        font-weight:700;
        /* color:#1565C0; */
        color:#AB2B22;
    }
    .kpi-title{
        color:#666;
        font-size:13px;
    }
</style>


<script>
    function changeEntity() {
        var entity_id = $('#entitySelect').val();
        var branchDropdown = $('#branchSelect');
        branchDropdown.empty().append('');
        // branchDropdown.empty().append('<option value="" >Select Branch</option>');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });


                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }
</script>

<script>
    $('#global_year_picker').datepicker({
        format: 'yyyy',
        viewMode: 'years',
        minViewMode: 'years',
        todayHighlight: true,
        autoclose: true,
        endDate: new Date(),
        orientation: 'bottom'
    })
</script>


<script>
   
    
    function currencyFormat(value) {
        value = Number(value || 0);
        if (value >= 10000000) {
            return (Math.floor((value / 10000000) * 100) / 100).toFixed(2) + ' Cr';
        }
        if (value >= 100000) {
            return (Math.floor((value / 100000) * 100) / 100).toFixed(2) + ' L';
        }
        return new Intl.NumberFormat('en-IN', {
            maximumFractionDigits: 0
        }).format(value);
    }

    function getMonthName(monthNo, year) {

        const monthNames = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        };

        let displayYear = year;

        if ([1, 2, 3].includes(parseInt(monthNo))) {
            displayYear = parseInt(year) + 1;
        }

        return `${monthNames[monthNo]} ${displayYear}`;
    }

    function getMonthNameOnly(monthNo) {

        const monthNames = {
            1: 'January',
            2: 'February',
            3: 'March',
            4: 'April',
            5: 'May',
            6: 'June',
            7: 'July',
            8: 'August',
            9: 'September',
            10: 'October',
            11: 'November',
            12: 'December'
        };


        return `${monthNames[monthNo]}`;
    }


    function noDataCard() {

        return `
            <div class="metrics-state-wrapper">
                <img
                     src="/assets/egc_images/no_data_found.png"
                    class="no-data-image">
                <div class="no-data-title">
                    Failed to load incentive data
                </div>
                <div class="no-data-subtitle">
                    Try changing filters or Please Try Again Later
                </div>
            </div>
        `;
    }

   

  
</script>
<script>
     function changeIncetiveEntity() {
        var entity_id = $('#entityIncentive').val();
        var branchDropdown = $('#branchIncentive');
        // branchDropdown.empty().append('<option value="" >Select Branch</option>');
        branchDropdown.empty().append('');
        if (entity_id) {
            $.ajax({
                url: "{{ route('entity_branch_dropdown_list') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erpbranchid', state.erp_branch_id)
                                .text(state.branch_name));
                        });
                        if($('#entityIncentive').val() != ''){
                            changeIncetiveBranch()
                        }
                        
                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }

    function changeIncetiveBranch() {
        var entity_id = $('#entityIncentive').val();
        var branchDropdown = $('#roleIncentive');
        // branchDropdown.empty().append('<option value="" >Select Role</option>');
        branchDropdown.empty().append('');
        if (entity_id) {
            $.ajax({
                url: "{{ route('incentive_role_by_entity') }}",
                type: "GET",
                data: {
                    entity_id: entity_id
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        response.data.forEach(function(state) {
                            branchDropdown.append($('<option></option>').attr(
                                    'value', state.sno)
                                .attr('data-erproleid', state.erp_role_id)
                                .text(state.role_name));
                        });

                        changeIncetiveRole()

                    }
                },
                error: function(error) {
                    console.error('Error fetching Department:', error);
                }
            });
        }
    }
</script>

<script>
    let abortIncentiveController = new AbortController();
    let loaderInterval = null;

    function updateLoader(percent) {

        const circle = document.querySelector('.loader-progress');

        const radius = 60;
        const circumference = 2 * Math.PI * radius;

        const offset = circumference - ((percent / 100) * circumference);

        circle.style.strokeDashoffset = offset;

        $('#loaderPercent').text(percent + '%');




    }
    
</script>
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();
    let auth_user_id = @json($user_id);

    let tableState = {
        currentPage: 1
    };
   

</script>

<script>
    
    function loadEmployees(page = 1){

        tableState.currentPage = page;
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const company_fill = document.getElementById('company_fill').value;
        // const to_dt_iss_rpt = document.getElementById('cus_custom_to_dt_fill').value;
        // const from_dt_iss_rpt = document.getElementById('cus_custom_from_dt_fill').value;
        // const dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        const job_role_fill = document.getElementById('job_role_fill').value;
        const division_fill = document.getElementById('division_fill').value;
        const department_fill = document.getElementById('department_fill').value;
        const entity_fill = document.getElementById('entity_fill').value;

        const url = `/hr_sib/appraisal/list?page=${page}&sorting_filter=${perpage}&search_filter=${search}&company_fill=${company_fill}&entity_fill=${entity_fill}&department_fill=${department_fill}&division_fill=${division_fill}&job_role_fill=${job_role_fill}`;

        showSkeleton();

            fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: abortController.signal
            })
            .then(res => res.json())
            .then(res => {
                renderDashboard(res.dashboard);
                renderTable(res);
                renderPagination(res.current_page, res.last_page, res.total, perpage);
                // Hide skeleton loader after data is fetched
                isLoading = false;
                hideSkeleton();
                $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                 hideSkeleton();
                isLoading = false;
            });
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadEmployees(1); // Trigger the search when the user presses enter
        }
    }

    // Debounce function to handle input changes
    let debounceTimeout;

    function debounce(fn, delay) {
        return function() {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(fn, delay);
        };
    };



    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block'; // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none'; // Hide the refresh button
        }
    });

    // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadEmployees(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = ''; // Clear the search input
        loadEmployees(1); // Reload the table data without the search filter
    });

    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadEmployees(1); // Reload the table data without the search filter
    });

    document.getElementById('filterSubmit').addEventListener('click', function() {
        loadEmployees(1); // Reload the table data without the search filter
    });
</script>
<script>
    function showSkeleton(){
        $("#loadingSkeleton").removeClass("d-none").show();
        $("#appraisalTable").hide();
        $("#pagination-container").hide();
    }
    function hideSkeleton(){
        $("#loadingSkeleton").hide();
        $("#appraisalTable").fadeIn(200);
        $("#pagination-container").show();
    }
</script>
<script>
    function renderTable(response){
        let html=`
            <div class="table-responsive appraisal-wrapper">
                <table class="table appraisal-table align-middle">
                    ${renderHeader(response.headers)}
                    ${renderBody(response.data)}
                </table>
            </div>
        `;
        $("#appraisalTable").html(html);
        

        setTimeout(function(){

            scrollToCurrentMonth();

        },150);
    }

   
    // function scrollToCurrentMonth(){

    //     const wrapper=document.querySelector(".appraisal-wrapper");

    //     const current=document.querySelector(".current-month-column");

    //     if(!wrapper || !current)
    //         return;

    //     wrapper.scrollTo({

    //         left: current.offsetLeft - 250,

    //         behavior:"smooth"

    //     });

    // }

    function scrollToCurrentMonth(){

        const wrapper=document.querySelector(".appraisal-wrapper");

        const current=document.querySelector(".current-month-column");

        if(!wrapper || !current)
            return;

        const left =
            current.offsetLeft
            - (wrapper.clientWidth/2)
            + (current.clientWidth/2);

        wrapper.scrollTo({

            left:left,

            behavior:"smooth"

        });

    }
</script>
<script>
    function renderDashboard(d){

        let cards="";

        cards+=dashboardCard("bg-blue",
            "mdi-account-group",
            "Total Staff",
            d.total_staff);

        cards+=dashboardCard("bg-purple",
            "mdi-chart-line",
            "Appraised",
            d.appraised_staff);

        // cards+=dashboardCard("bg-orange",
        //     "mdi-clock-outline",
        //     "Pending",
        //     d.pending_staff);

        // cards+=dashboardCard("bg-purple",
        //     "mdi-currency-inr",
        //     "Average Salary",
        //     money(d.average_salary));

        // cards+=dashboardCard("bg-red",
        //     "mdi-bank",
        //     "Salary Cost",
        //     money(d.salary_cost));

        cards+=dashboardCard("bg-orange",
            "mdi-calendar-month",
            "This Month",
            d.this_month);

        cards+=dashboardCard("bg-green",
            "mdi-calendar",
            "This Year",
            d.this_year);

        // cards+=dashboardCard("bg-orange",
        //     "mdi-finance",
        //     "Avg Hike %",
        //     d.avg_increment+" %");

        // cards+=dashboardCard("bg-purple",
        //     "mdi-arrow-up-bold",
        //     "Highest Salary",
        //     money(d.highest_salary));

        // cards+=dashboardCard("bg-red",
        //     "mdi-arrow-down-bold",
        //     "Lowest Salary",
        //     money(d.lowest_salary));

        $("#dashboardCards").html(cards);

        // renderDistribution(d.types);

    }

function dashboardCard(bg,icon,title,value){

    return `
    <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 d-flex">
        <div class="card dashboard-card ${bg} w-100">
            <div class="card-body">
                <div class="d-flex justify-content-between gap-1 w-100">
                    <div>
                        <div class="dashboard-title">${title}</div>
                        <div class="dashboard-value">${value}</div>
                    </div>
                    <div class="dashboard-icon">
                        <i class="mdi ${icon} fs-5"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `;

}

function renderDistribution(t){
    let total=t.joining+t.yearly+t.special+t.project+t.warrior;

    let html="";
    html+=progress("Joining",t.joining,total,"primary");
    html+=progress("Yearly",t.yearly,total,"success");
    html+=progress("Special",t.special,total,"warning");
    html+=progress("Project",t.project,total,"info");
    html+=progress("10X Warrior",t.warrior,total,"danger");
    // $("#appraisalDistribution").html(html);
}

function progress(title,value,total,color){

    let p=0;
    if(total>0){
        p=((value/total)*100).toFixed(1);
    }

    return `
        <div class="mb-4">
            <div class="d-flex justify-content-between mb-1">
                <b>${title}</b>
                <span>${value}</span>
            </div>
            <div class="progress">
                <div class="progress-bar bg-${color}" style="width:${p}%">
                </div>
            </div>
        </div>
    `;

}
</script>
<script>
    function renderHeader(headers){
        let html="";
        html+=`
            <thead>
                <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary sticky-top">
                    <th class="sticky-left employee-col bg-primary">
                        Employee
                    </th>
                    <th class="current-col">
                        Current Salary
                    </th>
            `;
            headers.forEach(function(month){
                html+=`
                    <th class="month-col">
                        ${month.label}
                    </th>
                `;
            });
            html+=`
                <th class="sticky-right action-col bg-primary">
                    Action
                </th>
                </tr>
            </thead>
        `;

        return html;
    }
</script>
<script>
    function renderBody(rows){

        let html="<tbody>";
        rows.forEach(function(emp){
            html+=renderEmployee(emp);
        });
        html+="</tbody>";
        return html;
    }
</script>
<script>
    function renderEmployee(emp){

        let row="";
        row+="<tr>";
        row+=employeeColumn(emp);
        row+=`
            <td class="current-salary">
                ${money(emp.current_salary)}
            </td>
        `;
        emp.timeline.forEach(function(month){
            row+=monthCell(month);
        });
        row+=actionColumn(emp);
        row+="</tr>";
        
        return row;
    }
</script>
<script>
    function monthCell(month){

        let cls = month.status;

        if(month.current){
            cls += " current";
        }

        return `
            <td class="${cls == 'current' ? 'current-month-column' : ''}">
                <div
                    class="salary-box ${cls}" data-bs-toggle="tooltip" data-bs-placement="top" title="${month.type ?? ''}"
                    data-effective="${month.effective_from ?? ''}">
                    ${month.salary==null ? "-" : money(month.salary)}
                </div>
            </td>
        `;
    }
</script>
<script>
    function money(amount){
        if(amount==null)
        return "-";
        return "₹"+Number(amount).toLocaleString();
    }
</script>
<script>
    // function employeeColumn(emp){
    //     return`
    //         <td class="sticky-left employee-cell bg-white">
    //             <div class="d-flex align-items-center">
    //                 <img src="${emp.profile_image_url}" class="staff-avatar" loading="lazy">
    //                 <div class="ms-3">
    //                     <div class="fw-bold">${emp.staff_name}</div>
    //                     <div class="text-muted small">${emp.department_name}</div>
    //                     <div class="badge bg-light text-dark mt-1">${emp.staff_id}</div>
    //                 </div>
    //             </div>
    //         </td>
    //     `;
    // }
    function employeeColumn(emp){

        const companyColor = emp.company_base_color || "#B52A1F";

        let appraisalBadge = "";

        if(parseInt(emp.total_appraisal) >= 1){
            appraisalBadge = `
                <span class="employee-chip chip-success badge bg-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Total Appraisal Count">
                    ${emp.total_appraisal}
                </span>
            `;
        }

         // Exit Status
        let exitHtml = "";

        if(parseInt(emp.status) >= 4){

            let exitStatus = "";
            let exitClass = "";
            let exitDate = "";

            switch(parseInt(emp.status)){

                case 4:
                    exitStatus = "Notice Period";
                    exitClass = "chip-notice";
                    exitDate = emp.notice_end_date;
                break;

                case 5:
                    exitStatus = "Relieved";
                    exitClass = "chip-relieved";
                    exitDate = emp.staff_last_date;
                break;

                case 6:
                    exitStatus = "Abscond";
                    exitClass = "chip-abscond";
                    exitDate = emp.staff_last_date;
                break;

                case 7:
                    exitStatus = "Terminated";
                    exitClass = "chip-terminated";
                    exitDate = emp.staff_last_date;
                break;
            }

            exitHtml = `
                <div class="employee-exit">

                    <span class="employee-chip ${exitClass}">
                        <i class="mdi mdi-account-off"></i>
                        ${exitStatus}
                    </span>

                    <small class="employee-chip ${exitClass}">
                        <i class="mdi mdi-calendar"></i>
                        ${formatDateCommon(exitDate)}
                    </small>

                </div>
            `;
        }

        return `
        <td class="sticky-left employee-cell bg-white">

            <div class="employee-card">

                <div class="company-strip"
                    style="background:${companyColor};">
                </div>

                <img
                    src="${emp.profile_image_url}"
                    class="staff-avatar"
                    loading="lazy">

                <div class="employee-info">

                    <div class="d-flex gap-1">
                        <div class="employee-name">
                            ${emp.staff_name}
                        </div>
                        <span class="employee-chip chip-id">
                            ${emp.staff_id}
                        </span>
                         ${appraisalBadge}
                    </div>

                    <div class="employee-department">
                        ${emp.department_name ?? "-"}
                    </div>

                    <div class="employee-footer">

                        <span class="employee-chip chip-company"
                            style="
                            border-color:${companyColor};
                            color:${companyColor};">

                            <i class="mdi mdi-office-building"></i>

                            ${emp.company_name ?? "-"}

                        </span>

                    </div>
                    ${exitHtml}

                </div>

            </div>

        </td>
        `;
    }
</script>
<script>
    function actionColumn(emp){
        return`
            <td class="sticky-right bg-white">
                <button class="btn btn-sm btn-primary" onclick="viewSalary(${emp.sno})">
                    <i class="mdi mdi-eye"></i>
                </button>
            </td>
        `;
    }
</script>
<script>
   
</script>
<script>
    loadEmployees();
    
</script>
<script>
    function renderPagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        if (total == 0) {
            start = 0;
        } else {
            start = start;
        }
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadEmployees(1)" >«</button> </li>`;

        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadEmployees(${currentPage - 1})" >‹</button> </li>`;

        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadEmployees(${currentPage + 1})" >›</button> </li>`;

        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadEmployees(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadEmployees(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }
</script>
<script>
    function viewSalary(id){
        $.get(
            "/hr_sib/appraisal/details/"+id,
            function(res){
                renderSalaryModal(res);
                $("#salaryModal").modal("show");
            }
        );
    }

    function renderSalaryModal(res){
        let html="";
        html+=renderHero(res.staff,res.summary);
        html+=renderKPICards(res.summary);
        html+=renderAnalytics(res.summary);     // NEW
        html+=renderSalaryJourney(res);
        $("#salaryContent").html(html);

    }

    function renderHero(emp,summary){
        return `
            <div class="hero-card mb-4">
                <div class="row align-items-center">
                    <div class="col-lg-2 text-center">
                        <img src="${emp.profile_image_url}" class="hero-avatar">
                    </div>
                    <div class="col-lg-6">
                        <div class="hero-title">
                            ${emp.staff_name}
                         </div>
                        <div class="hero-sub">
                            ${emp.job_position_name}
                        </div>

                        <div class="mt-3">
                            <span class="hero-chip">
                                Employee ID :
                                ${emp.staff_id}
                            </span>
                            <span class="hero-chip">
                                ${emp.department_name}
                            </span>
                            <span class="hero-chip">
                                ${emp.division_name}
                            </span>
                        </div>

                        <div class="mt-3">
                            <i class="mdi mdi-calendar"></i>
                            Joining :
                            ${emp.date_of_joining}
                        </div>
                    </div>
                    <div class="col-lg-4 text-end">
                        <div style="font-size:14px">
                            Current Salary
                        </div>
                        <div style="font-size:40px;font-weight:700">
                            ₹${Number(summary.current_salary).toLocaleString()}
                        </div>

                        <div class="mt-2">
                            Growth
                            <span class="badge bg-success">
                                ${summary.salary_growth}%
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function renderKPICards(summary){
        return `
            <div class="row g-3">
                <div class="col-lg-3">
                    <div class="kpi-card">
                        <div class="kpi-number">
                            ₹${Number(summary.current_salary).toLocaleString()}
                        </div>
                        <div class="kpi-title">
                            Current Salary
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="kpi-card">
                        <div class="kpi-number">
                            ${summary.total_appraisals}
                        </div>
                        <div class="kpi-title">
                            Appraisals
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="kpi-card">
                        <div class="kpi-number">
                            ₹${Number(summary.total_increment).toLocaleString()}
                        </div>
                        <div class="kpi-title">
                            Total Increment
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="kpi-card">
                        <div class="kpi-number">
                            ${summary.experience}
                        </div>
                        <div class="kpi-title">
                            Experience
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function renderSalaryJourney(res){

        let html="";

        html+=`
        <div class="card shadow-sm border-0 mt-4">

            <div class="card-header bg-white">

                <h4>

                    <i class="mdi mdi-chart-line text-success"></i>

                    Salary Journey

                </h4>

            </div>

            <div class="card-body">

                <div class="salary-timeline">
        `;

        html+=joiningCard(res);

        res.history.forEach(function(item,index){
            if(item.appraisal_type !=0){
                html+=timelineCard(item,index,res);
            }
        });

        html+=currentSalaryCard(res.summary);

        html+=`

                </div>

            </div>

        </div>`;

        return html;

    }

function joiningCard(res){

return `

<div class="salary-timeline-item">

<div class="salary-timeline-dot bg-blue"></div>

<div class="salary-timeline-card">

<span class="badge bg-primary">

Joining

</span>

<h3 class="mt-2">

₹${Number(res.summary.joining_salary).toLocaleString()}

</h3>

<div>

Joining Date

${res.staff.date_of_joining}

</div>

</div>

</div>

`;

}

// function timelineCard(item,index,res){

//     let previous=index===0 ? res.summary.joining_salary :res.history[index-1].gross_salary;
//     let increment=item.gross_salary-previous;
//     let percent=((increment/previous)*100).toFixed(1);
//     let custom_appraisal_type = '';

//     switch (item.appraisal_type) {
//         case 0:
//             custom_appraisal_type = 'Joining';
//             break;
//         case 1: 
//             custom_appraisal_type = 'Yearly';
//             break;
//         case 3: 
//             custom_appraisal_type = 'Project';
//             break;
//         case 5: 
//             custom_appraisal_type = '10X Warrior';
//             break;
//     }

//     let appraisal_type_name = item.appraisal_type_name ? item.appraisal_type_name : custom_appraisal_type;
    

//     return `
//         <div class="salary-timeline-item">
//             <div class="salary-timeline-dot bg-success"></div>
//                 <div class="salary-timeline-card">
//                     <div class="d-flex justify-content-between">
//                         <div>
//                             <h5>${appraisal_type_name}</h5>
//                             <small>${item.effective_from ? formatDateCommon(item.effective_from) : '-'}</small>
//                         </div>
//                         <span class="salary-timeline-badge bg-success">+${percent}%</span>
//                     </div>

//                     <hr>

//                 <div class="row">
//                     <div class="col-md-4">
//                         <div class="salary-old">
//                         ₹${Number(previous).toLocaleString()}
//                         </div>
//                     </div>
//                     <div class="col-md-4 text-center">
//                         <i class="mdi mdi-arrow-right fs-2"></i>
//                     </div>
//                     <div class="col-md-4 text-end">
//                         <div class="salary-new">
//                         ₹${Number(item.gross_salary).toLocaleString()}
//                         </div>
//                     </div>
//                 </div>
//                 <div class="mt-3">
//                     ${item.appraisal_reason??"-"}
//                 </div>
//             </div>
//         </div>

//     `;
// }

function timelineCard(item, index, res) {

    let previous = index === 0
        ? res.summary.joining_salary
        : res.history[index - 1].gross_salary;

    let custom_appraisal_type = '';

    switch (parseInt(item.appraisal_type)) {
        case 0:
            custom_appraisal_type = 'Joining';
            break;
        case 1:
            custom_appraisal_type = 'Yearly';
            break;
        case 3:
            custom_appraisal_type = 'Project';
            break;
        case 5:
            custom_appraisal_type = '10X Warrior';
            break;
        default:
            custom_appraisal_type = 'Appraisal';
    }

    let appraisal_type_name = item.appraisal_type_name || custom_appraisal_type;

    // Badge Value
    let badgeValue = '';
    let hike_amount = 0
    let originalSalaryOld = Number(item.gross_salary);

    if (item.appraisal_unit == '%') {
        // Percentage
        badgeValue = `+${Number(item.appraisal_value).toFixed(2)}%`;
        hike_amount =  (Number(item.appraisal_value) / 100) * originalSalaryOld ;
    } else {
        // Rupees
        badgeValue = `+₹${Number(item.appraisal_value).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })}`;
        hike_amount =  Number(item.appraisal_value);
    }

     let originalSalaryHike = originalSalaryOld + Math.round(hike_amount);

    return `
        <div class="salary-timeline-item">

            <div class="salary-timeline-dot bg-success"></div>

            <div class="salary-timeline-card">

                <div class="d-flex justify-content-between align-items-center">

                    <div>
                        <h5 class="mb-1">${appraisal_type_name}</h5>
                        <small class="text-muted">
                            ${item.effective_from ? formatDateCommon(item.effective_from) : '-'}
                        </small>
                    </div>

                    <span class="salary-timeline-badge bg-success text-white">
                        ${badgeValue}
                    </span>

                </div>

                <hr>

                <div class="row align-items-center">

                    <div class="col-md-4">
                        <div class="salary-old">
                            ₹${Number(item.gross_salary).toLocaleString('en-IN')}
                        </div>
                    </div>

                    <div class="col-md-4 text-center">
                        <i class="mdi mdi-arrow-right fs-2 text-primary"></i>
                    </div>

                    <div class="col-md-4 text-end">
                        <div class="salary-new">
                            ₹${Number(originalSalaryHike).toLocaleString('en-IN')}
                        </div>
                    </div>

                </div>

                <div class="mt-3 text-muted">
                    ${item.appraisal_reason || "-"}
                </div>

            </div>

        </div>
    `;
}

function currentSalaryCard(summary){

return `

<div class="salary-timeline-item">

<div class="salary-timeline-dot bg-warning"></div>

<div class="salary-timeline-card border border-warning">

<div class="d-flex justify-content-between">

<div>

<h4>

Current Salary

</h4>

</div>

<div class="salary-new">

₹${Number(summary.current_salary).toLocaleString()}

</div>

</div>

</div>

</div>

`;

}

function renderAnalytics(summary){

return`

<div class="card border-0 shadow mt-4">

<div class="card-header bg-white">

<h4>

<i class="mdi mdi-chart-areaspline text-success"></i>

Salary Analytics

</h4>

</div>

<div class="card-body">

<div class="row">

${growthCard(summary)}

${progressCard(summary)}

</div>

</div>

</div>

`;

}

function growthCard(summary){

return`

<div class="col-lg-6">

<div class="analytics-card">

<div class="analytics-title">

Salary Growth

</div>

<div class="analytics-value text-success">

${summary.salary_growth}%

</div>

<div class="mt-3">

Joining Salary

<strong>

₹${Number(summary.joining_salary).toLocaleString()}

</strong>

</div>

<div>

Current Salary

<strong>

₹${Number(summary.current_salary).toLocaleString()}

</strong>

</div>

<div class="mt-3">

Total Growth

<strong class="text-primary">

₹${Number(summary.total_increment).toLocaleString()}

</strong>

</div>

</div>

</div>

`;

}


function progressCard(summary){

return`

<div class="col-lg-6">

<div class="analytics-card">

<h5>

Salary Progress

</h5>

<div class="salary-progress mt-4">

<div

class="progress-bar bg-success"

style="width:${summary.salary_growth>100?100:summary.salary_growth}%">

${summary.salary_growth}%

</div>

</div>

<div class="mt-4">

<div class="stat-item">

<span>Total Appraisals</span>

<strong>

${summary.total_appraisals}

</strong>

</div>

<div class="stat-item">

<span>Highest Salary</span>

<strong>

₹${Number(summary.highest_salary).toLocaleString()}

</strong>

</div>

<div class="stat-item">

<span>Total Increment</span>

<strong>

₹${Number(summary.total_increment).toLocaleString()}

</strong>

</div>

<div class="stat-item">

<span>Experience</span>

<strong>

${summary.experience}

</strong>

</div>

</div>

</div>

</div>

`;

}

    function employeeCard(emp){

        return `
            <div class="row">
                <div class="col-lg-4">
                    <img src="${emp.profile_image_url}" class="rounded-circle avatar-xl">
                </div>
                <div class="col-lg-8">
                    <h4>${emp.staff_name}</h4>
                    <div>${emp.job_position_name}</div>
                    <div>${emp.department_name}</div>
                    <div>
                        Joining
                        ${emp.date_of_joining}
                    </div>
                </div>
            </div>
        `;

    }
    // function timeline(history){
    //     let html="";
    //     html+='<div class="timeline mt-4">';
    //     history.forEach(function(h){
    //         html+=timelineCard(h);
    //     });
    //     html+='</div>';

    //     return html;
    // }

    // function timelineCard(h){
    //     return `
    //         <div class="salary-history-card">
    //             <div>
    //                 <h5>₹${Number(h.gross_salary).toLocaleString()}</h5>
    //             </div>
    //             <div>
    //                 Effective
    //                 ${h.effective_from}
    //             </div>
    //             <div>${h.appraisal_type_name}</div>
    //             <div>
    //                 ${h.appraisal_reason}
    //             </div>
    //         </div>
    //     `;
    // }
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
   
</script>
<script>
    $(document).ready(function() {
        // Business dropdown
        $('#company_fill').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('#entity_fill');
             var departDropdown = $('#department_fill');

            departDropdown.empty().append('<option value="">Select Department</option>');

            stateDropdown.empty().append('<option value="">Select Entity</option>');

            if (countryId) {
                if(countryId == 'egc'){
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: 0
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    departDropdown.append($('<option></option>').attr(
                                            'value', state.sno)
                                        .attr('data-erpdepartmentid', state.erp_department_id)
                                        .text(state.department_name));
                                });

                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });
                }else{
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });

                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            }
        });

        // depart list
        $('#entity_fill').on('change', function() {
            var entity_id = $(this).val();
            var stateDropdown = $('#department_fill');

            stateDropdown.empty().append('<option value="">Select Department</option>');

            if (entity_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    data: {
                        entity_id: entity_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdepartmentid', state.erp_department_id)
                                    .text(state.department_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Department:', error);
                    }
                });
            }


        });
        // division dropdown
        $('#department_fill').on('change', function() {
            var department_id = $(this).val();
            var stateDropdown = $('#division_fill');
            stateDropdown.empty().append('<option value="">Select Division</option>');

          

            if (department_id) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('get_division') }}",
                    type: "GET",
                    data: {
                        department_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpdivisionid', state.erp_division_id)
                                    .text(state.division_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Division:', error);
                    }
                });

            }
        });

        $('#division_fill').on('change', function() {
            var department_id = $(this).val();

            var jobRoleDropdown = $('#job_role_fill');

            jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

            let erp_depert = $(this).find(':selected').data('erpdivisionid');
            $('#erp_division_id').val(erp_depert);

            if (department_id) {
                // Fetch and populate states based on selected country
                // Job role dropdown
                $.ajax({
                    url: "{{ route('get_job_role') }}",
                    type: "GET",
                    data: {
                        division_id: department_id
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                    .attr('data-erpjobroleid', state.erp_job_role_id)
                                    .text(state.job_position_name));
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching Job Role:', error);
                    }
                });
            }
        });

    })
</script>

<script>
/* ============================================================================
 | Manage Appraisal - production AJAX workflow
 | ========================================================================== */
const appraisalDefaultAvatar = @json(asset('assets/egc_images/auth/user_2.png'));
const appraisalState = {
    formDataLoaded: false,
    formData: null,
    staffProfile: null,
    currentStructure: null,
    currentStructureDetails: [],
    expiredVariables: [],
    pendingCasualLeave: [],
};

function appraisalEscape(value) {
    return $('<div>').text(value ?? '-').html();
}

function appraisalCurrency(value) {
    const number = Number(value || 0);
    return '₹ ' + number.toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function appraisalDate(value) {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return appraisalEscape(value);
    return date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    }).replace(/ /g, '-');
}

function appraisalMonth(value) {
    if (!value) return '-';
    if (/^\d{4}-\d{2}$/.test(String(value))) return value;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return appraisalEscape(value);
    return date.toLocaleDateString('en-GB', {
        month: 'short',
        year: 'numeric'
    });
}

function initAppraisalSelect($select, dropdownParent = '#addAppraisalModal') {
    if (!$.fn.select2) return;
    if ($select.hasClass('select2-hidden-accessible')) return;
    $select.select2({
        width: '100%',
        dropdownParent: $(dropdownParent),
        allowClear: true,
        placeholder: $select.find('option:first').text() || 'Select'
    });
}

function initAppraisalMonthPicker(selector) {
    const $input = $(selector);
    if (!$input.length || !$.fn.datepicker) return;
    try {
        if ($input.data('datepicker')) {
            $input.datepicker('destroy');
        }
    } catch (e) {}
    $input.datepicker({
        format: 'yyyy-mm',
        minViewMode: 'months',
        autoclose: true,
        endDate: new Date()
    });
}

function initAppraisalModalPlugins() {
    $('#addAppraisalModal .select3').each(function () {
        initAppraisalSelect($(this));
    });
    initAppraisalMonthPicker('#appraisal_effective_from');
    initAppraisalMonthPicker('#appraisal_variable_from');
}

function resetAppraisalSelect($select, placeholder = 'Select') {
    $select.empty().append(`<option value="">${appraisalEscape(placeholder)}</option>`);
    $select.val('').trigger('change');
}

function resetAddAppraisalModal() {
    appraisalState.staffProfile = null;
    appraisalState.currentStructure = null;
    appraisalState.currentStructureDetails = [];

    $('#addAppraisalForm')[0]?.reset();
    $('#appraisal_entity_id').val('').trigger('change');
    resetAppraisalSelect($('#appraisal_branch_id'), 'Select Branch');
    resetAppraisalSelect($('#appraisal_department_id'), 'Select Department');
    resetAppraisalSelect($('#appraisal_employee_sno'), 'Select Staff');
    resetAppraisalSelect($('#appraisal_salary_account_id'), 'Select Salary Account');
    $('#appraisal_department_id, #appraisal_employee_sno, #appraisal_salary_account_id, #appraisal_payroll_template_sno, #appraisal_gross_salary').prop('disabled', true);
    $('#appraisalBranchWrap').addClass('d-none');
    $('#appraisal_variable_check').prop('checked', false);
    $('#appraisalVariableSection').addClass('d-none');
    $('#appraisalVariableFields').addClass('d-none');
    $('#appraisal_variable_amount, #appraisal_variable_from, #appraisal_variable_end').val('');
    $('#appraisal_variable_months').val('3');
    $('#appraisal_entity_id, #appraisal_branch_id, #appraisal_department_id, #appraisal_employee_sno, #appraisal_salary_account_id, #appraisal_payroll_template_sno, #appraisal_type, #appraisal_unit, #appraisal_variable_component').val('').trigger('change.select2');
    $('#appraisal_type').val('1').trigger('change');
    $('#appraisal_unit').val('%').trigger('change');
    $('#appraisal_value, #appraisal_reason').val('');
    $('#appraisal_gross_salary').val('');
    $('#appraisalCurrentGrossBadge').text('Current ₹0.00');
    $('#appraisalTemplateStatus').text('Select a template');
    $('#appraisal_salary_components').html('<div class="appraisal-empty">Select a staff and payroll template to load the salary structure.</div>');
    $('#appraisalStaffProfilePanel').html('<div class="appraisal-empty"><i class="mdi mdi-account-circle-outline fs-1 text-primary"></i><div class="fw-bold mt-2">Staff profile</div><div class="small">Select a staff member to see profile, current salary and last appraisal.</div></div>');
    $('#appraisalCurrentSalaryPanel').html('<div class="appraisal-empty">Current salary details will appear after staff selection.</div>');
    $('#appraisalLastAppraisalPanel').html('<div class="appraisal-empty">No employee selected.</div>');
    resetAppraisalSummary();
    $('#appraisalSelectionStatus').text('Step 1');

    if ($.fn.datepicker) {
        try { $('#appraisal_effective_from').datepicker('setDate', new Date()); } catch (e) {}
    }
    $('#appraisal_effective_from').val(new Date().toISOString().slice(0, 7));
    resetAppraisalSelect($('#appraisal_variable_component'), 'Select Variable Component');
}

function populateAppraisalFormData(data) {
    appraisalState.formData = data;

    let entityHtml = '<option value="">Select Entity</option>';
    const mainCompanyTitle = data?.main_company?.title || 'Main Company';
    entityHtml += `<option value="0">${appraisalEscape(mainCompanyTitle)} <span></span></option>`;
    (data.entities || []).forEach(function (entity) {
        if (Number(entity.sno) === 0) return;
        entityHtml += `<option value="${Number(entity.sno)}">${appraisalEscape(entity.entity_name)}</option>`;
    });
    $('#appraisal_entity_id').html(entityHtml).val('').trigger('change');

    let templateHtml = '<option value="">Select Payroll Template</option>';
    (data.templates || []).forEach(function (template) {
        const referenceGross = template.gross_salary ? ` · ${appraisalCurrency(template.gross_salary)}` : '';
        templateHtml += `<option value="${Number(template.sno)}">${appraisalEscape(template.template_name)}${appraisalEscape(referenceGross)}</option>`;
    });
    $('#appraisal_payroll_template_sno').html(templateHtml).prop('disabled', true).trigger('change');

    let componentHtml = '<option value="">Select Variable Component</option>';
    (data.variable_components || []).forEach(function (component) {
        componentHtml += `<option value="${Number(component.sno)}">${appraisalEscape(component.component_name)}${component.component_code ? ` · ${appraisalEscape(component.component_code)}` : ''}</option>`;
    });
    $('#appraisal_variable_component').html(componentHtml).trigger('change');
    initAppraisalModalPlugins();
}

function loadAppraisalFormData(callback) {
    if (appraisalState.formDataLoaded && appraisalState.formData) {
        if (typeof callback === 'function') callback(appraisalState.formData);
        return;
    }

    $.ajax({
        url: '/hr_sib/appraisal/form-data',
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (!response.status) {
                toastr.error(response.message || 'Unable to initialise appraisal form.');
                return;
            }
            appraisalState.formDataLoaded = true;
            populateAppraisalFormData(response);
            if (typeof callback === 'function') callback(response);
        },
        error: function (xhr) {
            toastr.error(xhr.responseJSON?.message || 'Unable to load appraisal form data.');
        }
    });
}

function openAddAppraisalModal() {
    resetAddAppraisalModal();
    initAppraisalModalPlugins();
    $('#addAppraisalModal').modal('show');
    $('#appraisalSelectionStatus').text('Loading...');
    loadAppraisalFormData(function () {
        $('#appraisalSelectionStatus').text('Step 1');
        initAppraisalModalPlugins();
    });
}

function loadAppraisalBranches(entityId) {
    const $branch = $('#appraisal_branch_id');
    resetAppraisalSelect($branch, 'Select Branch');
    if (Number(entityId) <= 0) {
        $('#appraisalBranchWrap').addClass('d-none');
        return;
    }

    $('#appraisalBranchWrap').removeClass('d-none');
    $branch.prop('disabled', true);
    $branch.append('<option value="">Loading...</option>');

    $.ajax({
        url: '/entity_branch_dropdown_list',
        type: 'GET',
        data: { entity_id: entityId },
        success: function (response) {
            resetAppraisalSelect($branch, 'Select Branch');
            (response.data || []).forEach(function (branch) {
                const branchName = branch.branch_name || branch.franchise_name || `Branch #${branch.sno}`;
                $branch.append(`<option value="${Number(branch.sno)}">${appraisalEscape(branchName)}</option>`);
            });
            $branch.prop('disabled', false).trigger('change');
        },
        error: function (xhr) {
            resetAppraisalSelect($branch, 'Unable to load branch');
            toastr.error(xhr.responseJSON?.message || 'Unable to load branches.');
        }
    });
}

function loadAppraisalDepartments(entityId) {
    const $department = $('#appraisal_department_id');
    resetAppraisalSelect($department, 'Select Department');
    $('#appraisal_employee_sno').prop('disabled', true);
    resetAppraisalSelect($('#appraisal_employee_sno'), 'Select Staff');
    if (entityId === '' || entityId === null || Number(entityId) < 0) return;

    $department.prop('disabled', true);
    $department.append('<option value="">Loading...</option>');

    $.ajax({
        url: '/department',
        type: 'GET',
        data: { entity_id: Number(entityId) },
        success: function (response) {
            resetAppraisalSelect($department, 'Select Department');
            (response.data || []).forEach(function (department) {
                $department.append(`<option value="${Number(department.sno)}">${appraisalEscape(department.department_name)}</option>`);
            });
            $department.prop('disabled', false).trigger('change');
        },
        error: function (xhr) {
            resetAppraisalSelect($department, 'Unable to load department');
            toastr.error(xhr.responseJSON?.message || 'Unable to load departments.');
        }
    });
}

function loadAppraisalStaffOptions() {
    const entityId = $('#appraisal_entity_id').val();
    const branchId = $('#appraisal_branch_id').val();
    const departmentId = $('#appraisal_department_id').val();
    const $staff = $('#appraisal_employee_sno');

    resetAppraisalSelect($staff, 'Select Staff');
    $staff.prop('disabled', true);

    if (!departmentId) return;
    if (Number(entityId) > 0 && !branchId) return;

    $staff.append('<option value="">Loading staff...</option>');
    $.ajax({
        url: '/hr_sib/appraisal/staff-options',
        type: 'GET',
        data: {
            entity_id: Number(entityId || 0),
            branch_id: Number(branchId || 0),
            department_id: Number(departmentId)
        },
        success: function (response) {
            resetAppraisalSelect($staff, 'Select Staff');
            const rows = response.data || [];
            rows.forEach(function (staff) {
                const label = `${staff.staff_name || '-'} · ${staff.staff_id || 'No ID'}`;
                const meta = staff.job_role_name ? ` · ${staff.job_role_name}` : '';
                $staff.append(`<option value="${Number(staff.sno)}">${appraisalEscape(label + meta)}</option>`);
            });
            $staff.prop('disabled', rows.length === 0).trigger('change');
            if (!rows.length) {
                toastr.info('No active staff found for the selected filters.');
            }
        },
        error: function (xhr) {
            resetAppraisalSelect($staff, 'Unable to load staff');
            toastr.error(xhr.responseJSON?.message || 'Unable to load staff.');
        }
    });
}

function renderAppraisalProfile(profile) {
    const staff = profile.staff || {};
    const image = staff.profile_image_url || appraisalDefaultAvatar;
    const fullName = staff.staff_name || '-';
    const designation = staff.job_role_name || '-';

    $('#appraisalStaffProfilePanel').html(`
        <div class="d-flex align-items-center gap-3 mb-3">
            <img src="${appraisalEscape(image)}" class="appraisal-profile-avatar" onerror="this.src='${appraisalDefaultAvatar}'" alt="staff">
            <div class="min-w-0">
                <div class="appraisal-profile-name">${appraisalEscape(fullName)}</div>
                <div class="appraisal-profile-meta mt-1">${appraisalEscape(designation)}</div>
                <div class="mt-2">
                    <span class="badge bg-primary-subtle text-primary me-1">${appraisalEscape(staff.staff_id || 'No ID')}</span>
                    <span class="badge bg-light text-dark">${appraisalEscape(staff.nick_name || 'Staff')}</span>
                </div>
            </div>
        </div>
        <div class="appraisal-info-grid">
            <div class="appraisal-info-box"><div class="title">Mobile</div><div class="value">${appraisalEscape(staff.mobile_no)}</div></div>
            <div class="appraisal-info-box"><div class="title">Email</div><div class="value">${appraisalEscape(staff.email_id)}</div></div>
            <div class="appraisal-info-box"><div class="title">Company</div><div class="value">${appraisalEscape(staff.company_name)}</div></div>
            <div class="appraisal-info-box"><div class="title">Entity</div><div class="value">${appraisalEscape(Number(staff.entity_id || 0) === 0 ? (appraisalState.formData?.main_company?.title || 'Main Company') : staff.entity_name)}</div></div>
            <div class="appraisal-info-box"><div class="title">Branch</div><div class="value">${appraisalEscape(staff.branch_name || 'Not Applicable')}</div></div>
            <div class="appraisal-info-box"><div class="title">Department</div><div class="value">${appraisalEscape(staff.department_name)}</div></div>
            <div class="appraisal-info-box"><div class="title">Division</div><div class="value">${appraisalEscape(staff.division_name)}</div></div>
            <div class="appraisal-info-box"><div class="title">Joining Date</div><div class="value">${appraisalDate(staff.date_of_joining)}</div></div>
        </div>
    `);

    $('#appraisalLastAppraisalPanel').html(renderLastAppraisal(profile.last_appraisal));
    const current = profile.current_structure;
    const account = (profile.accounts || [])[0] || null;
    $('#appraisalCurrentGrossBadge').text('Current ' + appraisalCurrency(current?.gross_salary ?? account?.gross_salary ?? profile.current_salary ?? 0));
    renderCurrentSalaryPanel(current, profile.structure_details || [], account, profile.current_salary);
}

function renderLastAppraisal(last) {
    if (!last) {
        return '<div class="appraisal-empty"><i class="mdi mdi-information-outline fs-3"></i><div class="fw-bold mt-2">No previous appraisal</div><div class="small">This will be the first recorded appraisal for this employee.</div></div>';
    }

    const typeNames = {
        1: 'Yearly Appraisal',
        2: 'Special Appraisal',
        3: 'Promotion',
        5: '10X Warrior'
    };
    const typeName = typeNames[Number(last.appraisal_type)] || last.appraisal_type_name || 'Appraisal';

    return `
        <div class="appraisal-salary-highlight mb-3">
            <div class="small text-muted">Last effective month</div>
            <div class="fw-bold mt-1">${appraisalMonth(last.effective_from)}</div>
            <div class="amount mt-2">${appraisalCurrency(last.gross_salary)}</div>
        </div>
        <div class="appraisal-info-grid">
            <div class="appraisal-info-box"><div class="title">Type</div><div class="value">${appraisalEscape(typeName)}</div></div>
            <div class="appraisal-info-box"><div class="title">Unit</div><div class="value">${appraisalEscape(last.appraisal_unit)}</div></div>
            <div class="appraisal-info-box"><div class="title">Value</div><div class="value">${appraisalEscape(last.appraisal_value ?? '-')}</div></div>
            <div class="appraisal-info-box"><div class="title">Payroll Template</div><div class="value">${appraisalEscape(last.template_name)}</div></div>
        </div>
        <div class="mt-3 p-3 rounded-3 bg-light border">
            <div class="small text-muted mb-1">Reason</div>
            <div class="small fw-semibold text-dark">${appraisalEscape(last.appraisal_reason || 'No reason recorded')}</div>
        </div>
    `;
}

function renderCurrentSalaryPanel(structure, details, account, fallbackGross) {
    const gross = structure?.gross_salary ?? account?.gross_salary ?? fallbackGross ?? 0;
    if (!account && !structure) {
        $('#appraisalCurrentSalaryPanel').html('<div class="appraisal-empty">No active salary account was found.</div>');
        return;
    }

    const rows = (details || []).map(function (detail) {
        return `
            <tr>
                <td class="small fw-semibold">${appraisalEscape(detail.component_name)}</td>
                <td class="small">${appraisalEscape(detail.component_type)}</td>
                <td class="small text-end fw-bold">${appraisalCurrency(detail.calculated_amount)}</td>
            </tr>
        `;
    }).join('');

    $('#appraisalCurrentSalaryPanel').html(`
        <div class="appraisal-salary-highlight mb-3">
            <div class="d-flex align-items-center justify-content-between gap-2">
                <div>
                    <div class="small text-muted">Current Gross Salary</div>
                    <div class="amount mt-1">${appraisalCurrency(gross)}</div>
                </div>
                <div class="text-end small text-muted">
                    <div>Effective</div>
                    <strong class="text-dark">${appraisalMonth(structure?.effective_from ?? account?.effective_from)}</strong>
                </div>
            </div>
        </div>
        <div class="appraisal-info-grid mb-3">
            <div class="appraisal-info-box"><div class="title">Salary Account</div><div class="value">${appraisalEscape(account?.company_name || 'Primary Account')}</div></div>
            <div class="appraisal-info-box"><div class="title">Template</div><div class="value">${appraisalEscape(structure?.template_name || 'Not configured')}</div></div>
            <div class="appraisal-info-box"><div class="title">Per Day</div><div class="value">${appraisalCurrency(account?.per_day_salary)}</div></div>
            <div class="appraisal-info-box"><div class="title">Per Hour</div><div class="value">${appraisalCurrency(account?.per_hour_cost)}</div></div>
        </div>
        ${structure ? `
            <div class="appraisal-mini-kpis mb-3">
                <div class="appraisal-mini-kpi"><div class="kpi-title">EARNINGS</div><div class="kpi-value">${appraisalCurrency(structure.total_earnings)}</div></div>
                <div class="appraisal-mini-kpi"><div class="kpi-title">DEDUCTIONS</div><div class="kpi-value">${appraisalCurrency(structure.total_deductions)}</div></div>
                <div class="appraisal-mini-kpi"><div class="kpi-title">NET</div><div class="kpi-value">${appraisalCurrency(structure.net_salary)}</div></div>
                <div class="appraisal-mini-kpi"><div class="kpi-title">CTC</div><div class="kpi-value">${appraisalCurrency(structure.ctc_amount)}</div></div>
            </div>
            <div class="table-responsive border rounded-3">
                <table class="table table-sm align-middle mb-0">
                    <thead><tr><th>Component</th><th>Type</th><th class="text-end">Amount</th></tr></thead>
                    <tbody>${rows || '<tr><td colspan="3" class="text-center text-muted py-3">No structure details.</td></tr>'}</tbody>
                </table>
            </div>
        ` : '<div class="alert alert-light border small mb-0">No current payroll structure is configured for this salary account. Select a payroll template below to create the revised structure.</div>'}
    `);
}

function loadAppraisalStaffProfile(staffId) {
    if (!staffId) return;
    $('#appraisalSelectionStatus').text('Loading staff...');
    $('#appraisalStaffProfilePanel').html('<div class="appraisal-loading"><div class="text-center"><div class="spinner-border text-primary"></div><div class="small mt-2">Loading employee profile...</div></div></div>');
    $('#appraisalCurrentSalaryPanel').html('<div class="appraisal-loading"><div class="spinner-border text-primary"></div></div>');
    $('#appraisalLastAppraisalPanel').html('<div class="appraisal-loading"><div class="spinner-border text-primary"></div></div>');

    $.ajax({
        url: '/hr_sib/appraisal/staff-profile/' + encodeURIComponent(staffId),
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (!response.status) {
                toastr.error(response.message || 'Unable to load staff profile.');
                return;
            }
            appraisalState.staffProfile = response;
            renderAppraisalProfile(response);
            populateAppraisalSalaryAccounts(response.accounts || []);
            $('#appraisal_salary_account_id').prop('disabled', !(response.accounts || []).length);
            $('#appraisal_payroll_template_sno').prop('disabled', !(response.accounts || []).length);
            $('#appraisal_gross_salary').prop('disabled', !(response.accounts || []).length);
            $('#appraisalVariableSection').removeClass('d-none');
            $('#appraisalSelectionStatus').text('Step 2');

            const primary = (response.accounts || [])[0];
            if (primary) {
                $('#appraisal_salary_account_id').val(primary.sno).trigger('change.select2');
                loadAppraisalAccountStructure(staffId, primary.sno);
            } else {
                $('#appraisal_salary_components').html('<div class="appraisal-empty">No active salary account exists for this employee.</div>');
            }
        },
        error: function (xhr) {
            toastr.error(xhr.responseJSON?.message || 'Unable to load staff profile.');
            $('#appraisalStaffProfilePanel').html('<div class="appraisal-empty text-danger">Unable to load staff profile.</div>');
        }
    });
}

function populateAppraisalSalaryAccounts(accounts) {
    let html = '<option value="">Select Salary Account</option>';
    (accounts || []).forEach(function (account) {
        const primary = Number(account.is_primary) === 1 ? ' · Primary' : '';
        html += `<option value="${Number(account.sno)}">${appraisalEscape(account.company_name || 'Salary Account')}${appraisalEscape(primary)} · ${appraisalCurrency(account.gross_salary)}</option>`;
    });
    $('#appraisal_salary_account_id').html(html).trigger('change.select2');
}

function loadAppraisalAccountStructure(employeeId, accountId) {
    if (!employeeId || !accountId) return;
    $('#appraisalTemplateStatus').text('Loading current salary structure...');

    $.ajax({
        url: '/payroll/employee-structure/get/' + encodeURIComponent(employeeId) + '/' + encodeURIComponent(accountId),
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            const data = response.data || {};
            const account = (appraisalState.staffProfile?.accounts || []).find(a => Number(a.sno) === Number(accountId)) || {};

            appraisalState.currentStructure = data.structure || null;
            appraisalState.currentStructureDetails = data.details || [];

            if (data.structure) {
                $('#appraisal_gross_salary').val(Number(data.structure.gross_salary || 0).toFixed(2));
                $('#appraisal_payroll_template_sno').val(data.structure.payroll_template_sno).trigger('change.select2');
                $('#appraisalTemplateStatus').text(data.structure.template_name ? 'Current template loaded' : 'Template loaded');
                renderAppraisalComponents(data.details || []);
                renderCurrentSalaryPanel(data.structure, data.details || [], account, account.gross_salary);
            } else {
                $('#appraisal_gross_salary').val(Number(account.gross_salary || data.employee?.gross_salary || appraisalState.staffProfile?.current_salary || 0).toFixed(2));
                $('#appraisal_payroll_template_sno').val('').trigger('change.select2');
                $('#appraisalTemplateStatus').text('Select a payroll template');
                $('#appraisal_salary_components').html('<div class="appraisal-empty">No current payroll structure found. Select a payroll template to build the revised structure.</div>');
                renderCurrentSalaryPanel(null, [], account, account.gross_salary || data.employee?.gross_salary);
                resetAppraisalSummary();
            }
            recalculateAppraisalComponents();
        },
        error: function (xhr) {
            toastr.error(xhr.responseJSON?.message || 'Unable to load current salary structure.');
            $('#appraisal_salary_components').html('<div class="appraisal-empty text-danger">Unable to load current salary structure.</div>');
        }
    });
}

function resetAppraisalSummary() {
    $('#appraisal_total_earnings').text('₹ 0.00');
    $('#appraisal_total_deductions').text('₹ 0.00');
    $('#appraisal_net_salary').text('₹ 0.00');
    $('#appraisal_employer_contribution').text('₹ 0.00');
    $('#appraisal_ctc').text('₹ 0.00');
}

function renderAppraisalComponents(details) {
    const $container = $('#appraisal_salary_components');
    if (!details || !details.length) {
        $container.html('<div class="appraisal-empty">The selected payroll template has no salary components.</div>');
        resetAppraisalSummary();
        return;
    }

    let html = '';
    details.forEach(function (detail, index) {
        const calculationType = detail.calculation_type || 'fixed';
        const percentage = Number(detail.percentage_value ?? detail.percentage ?? 0);
        const fixedAmount = Number(detail.fixed_amount ?? detail.amount ?? detail.calculated_amount ?? 0);
        const calculatedAmount = Number(detail.calculated_amount ?? fixedAmount);
        const componentType = detail.component_type || 'earning';
        const badgeClass = componentType === 'earning' ? 'bg-success-subtle text-success' : (componentType === 'deduction' ? 'bg-danger-subtle text-danger' : 'bg-primary-subtle text-primary');
        const editable = ['manual_input', 'formula'].includes(calculationType) ? '' : 'readonly';

        html += `
            <div class="appraisal-component-row" data-calculation-type="${appraisalEscape(calculationType)}">
                <input type="hidden" class="appraisal_component_id" value="${Number(detail.payroll_component_sno ?? detail.component_sno ?? 0)}">
                <input type="hidden" class="appraisal_rule_id" value="${Number(detail.payroll_rule_sno || 0)}">
                <input type="hidden" class="appraisal_component_type" value="${appraisalEscape(componentType)}">
                <input type="hidden" class="appraisal_component_code" value="${appraisalEscape(detail.component_code || '')}">
                <input type="hidden" class="appraisal_percentage" value="${percentage}">
                <div class="row align-items-end g-2">
                    <div class="col-lg-4">
                        <div class="component-name">${appraisalEscape(detail.component_name || 'Salary Component')}</div>
                        <div class="component-code">${appraisalEscape(detail.component_code || '-')}</div>
                    </div>
                    <div class="col-lg-2">
                        <span class="badge ${badgeClass}">${appraisalEscape(componentType.replace('_', ' '))}</span>
                    </div>
                    <div class="col-lg-2">
                        <label class="appraisal-label mb-1">Calculation</label>
                        <input type="text" class="form-control form-control-sm" value="${appraisalEscape(calculationType)}" readonly>
                    </div>
                    <div class="col-lg-1">
                        <label class="appraisal-label mb-1">%</label>
                        <input type="text" class="form-control form-control-sm appraisal_percentage_display" value="${percentage}" readonly>
                    </div>
                    <div class="col-lg-3">
                        <label class="appraisal-label mb-1">Amount</label>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text">₹</span>
                            <input type="text" class="form-control appraisal_component_amount" value="${calculatedAmount.toFixed(2)}" ${editable} inputmode="decimal">
                        </div>
                    </div>
                </div>
            </div>
        `;
    });

    $container.html(html);
    recalculateAppraisalComponents();
}

function calculateAppraisalRowAmount($row, grossSalary, basic, da) {
    const type = $row.find('.appraisal_component_type').val();
    const code = String($row.find('.appraisal_component_code').val() || '').toUpperCase();
    const calculationType = String($row.data('calculation-type') || 'fixed');
    const percentage = Number($row.find('.appraisal_percentage').val() || 0);
    let amount = Number($row.find('.appraisal_component_amount').val() || 0);

    if (type === 'earning') {
        if (calculationType === 'percentage') {
            return (grossSalary * percentage) / 100;
        }
        return amount;
    }

    if (code === 'PF' && calculationType !== 'fixed') {
        const pfBase = basic + da;
        return pfBase > 15000 ? 1800 : (pfBase * 0.12);
    }

    if (code === 'EMPLOYER_PF' && calculationType !== 'fixed') {
        const pfBase = basic + da;
        return pfBase > 15000 ? 1800 : (pfBase * 0.12);
    }

    if (code === 'ESI') {
        const esiBase = basic + da;
        if (calculationType === 'fixed') return amount;
        return esiBase > 21000 ? 0 : (esiBase * 0.0075);
    }

    if (code === 'EMPLOYER_ESI') {
        const esiBase = basic + da;
        if (calculationType === 'fixed') return amount;
        return esiBase > 21000 ? 0 : (esiBase * 0.0325);
    }

    if (code === 'PT' && calculationType === 'fixed') {
        return grossSalary <= 10000 ? 140 : 208;
    }

    if (calculationType === 'percentage') {
        return (grossSalary * percentage) / 100;
    }

    return amount;
}

function recalculateAppraisalComponents() {
    const grossSalary = Number($('#appraisal_gross_salary').val() || 0);
    let earnings = 0;
    let deductions = 0;
    let employer = 0;
    let basic = 0;
    let da = 0;

    $('#appraisal_salary_components .appraisal-component-row').each(function () {
        const $row = $(this);
        const type = $row.find('.appraisal_component_type').val();
        if (type !== 'earning') return;

        const amount = calculateAppraisalRowAmount($row, grossSalary, basic, da);
        const code = String($row.find('.appraisal_component_code').val() || '').toUpperCase();
        $row.find('.appraisal_component_amount').val(Number(amount || 0).toFixed(2));
        if (code === 'BASIC') basic = Number(amount || 0);
        if (code === 'DA') da = Number(amount || 0);
        earnings += Number(amount || 0);
    });

    $('#appraisal_salary_components .appraisal-component-row').each(function () {
        const $row = $(this);
        const type = $row.find('.appraisal_component_type').val();
        if (type === 'earning') return;
        const amount = calculateAppraisalRowAmount($row, grossSalary, basic, da);
        $row.find('.appraisal_component_amount').val(Number(amount || 0).toFixed(2));
        if (type === 'deduction') deductions += Number(amount || 0);
        if (type === 'employer_contribution') employer += Number(amount || 0);
    });

    const net = earnings - deductions;
    const ctc = earnings + employer;
    $('#appraisal_total_earnings').text(appraisalCurrency(earnings));
    $('#appraisal_total_deductions').text(appraisalCurrency(deductions));
    $('#appraisal_net_salary').text(appraisalCurrency(net));
    $('#appraisal_employer_contribution').text(appraisalCurrency(employer));
    $('#appraisal_ctc').text(appraisalCurrency(ctc));
}

function loadAppraisalTemplate(templateId) {
    if (!templateId) {
        $('#appraisalTemplateStatus').text('Select a template');
        $('#appraisal_salary_components').html('<div class="appraisal-empty">Select a payroll template to load components.</div>');
        resetAppraisalSummary();
        return;
    }

    $('#appraisalTemplateStatus').html('<span class="spinner-border spinner-border-sm me-1"></span>Loading template...');
    $.ajax({
        url: '/payroll/template/components/' + encodeURIComponent(templateId),
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (!response.status) {
                toastr.error(response.message || 'Unable to load payroll template.');
                return;
            }
            const details = response.data?.details || [];
            $('#appraisalTemplateStatus').text(`${details.length} component(s) loaded`);
            renderAppraisalComponents(details);
            recalculateAppraisalComponents();
        },
        error: function (xhr) {
            $('#appraisalTemplateStatus').text('Template load failed');
            $('#appraisal_salary_components').html('<div class="appraisal-empty text-danger">Unable to load payroll template components.</div>');
            toastr.error(xhr.responseJSON?.message || 'Unable to load payroll template components.');
        }
    });
}

function calculateVariableEndMonth() {
    const start = $('#appraisal_variable_from').val();
    if (!start) {
        $('#appraisal_variable_end').val('');
        return;
    }
    const date = new Date(start + '-01T00:00:00');
    if (Number.isNaN(date.getTime())) {
        $('#appraisal_variable_end').val('');
        return;
    }
    date.setMonth(date.getMonth() + 2);
    $('#appraisal_variable_end').val(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`);
}

function saveManageAppraisal() {
    const entityId = $('#appraisal_entity_id').val();
    const branchId = $('#appraisal_branch_id').val();
    const departmentId = $('#appraisal_department_id').val();
    const employeeId = $('#appraisal_employee_sno').val();
    const salaryAccountId = $('#appraisal_salary_account_id').val();
    const templateId = $('#appraisal_payroll_template_sno').val();
    const effectiveFrom = $('#appraisal_effective_from').val();
    const grossSalary = Number($('#appraisal_gross_salary').val() || 0);
    const variableCheck = $('#appraisal_variable_check').is(':checked') ? 1 : 0;

    $('.is-invalid').removeClass('is-invalid');
    let valid = true;
    const invalid = function (selector) {
        $(selector).addClass('is-invalid');
        valid = false;
    };

    if (entityId === '') invalid('#appraisal_entity_id');
    if (Number(entityId) > 0 && !branchId) invalid('#appraisal_branch_id');
    if (!departmentId) invalid('#appraisal_department_id');
    if (!employeeId) invalid('#appraisal_employee_sno');
    if (!salaryAccountId) invalid('#appraisal_salary_account_id');
    if (!templateId) invalid('#appraisal_payroll_template_sno');
    if (!effectiveFrom) invalid('#appraisal_effective_from');
    if (!(grossSalary > 0)) invalid('#appraisal_gross_salary');
    if (!$('#appraisal_salary_components .appraisal-component-row').length) {
        valid = false;
        toastr.error('Please select a payroll template with salary components.');
    }

    if (variableCheck) {
        if (!$('#appraisal_variable_component').val()) invalid('#appraisal_variable_component');
        if (!(Number($('#appraisal_variable_amount').val() || 0) > 0)) invalid('#appraisal_variable_amount');
        if (!$('#appraisal_variable_from').val()) invalid('#appraisal_variable_from');
    }

    if (!valid) {
        toastr.error('Please complete all required appraisal fields.');
        return;
    }

    const details = [];
    $('#appraisal_salary_components .appraisal-component-row').each(function (index) {
        const $row = $(this);
        details.push({
            payroll_component_sno: Number($row.find('.appraisal_component_id').val() || 0),
            payroll_rule_sno: Number($row.find('.appraisal_rule_id').val() || 0) || null,
            component_type: $row.find('.appraisal_component_type').val(),
            calculation_type: $row.data('calculation-type') || 'fixed',
            percentage_value: Number($row.find('.appraisal_percentage').val() || 0),
            fixed_amount: Number($row.find('.appraisal_component_amount').val() || 0),
            calculated_amount: Number($row.find('.appraisal_component_amount').val() || 0),
            include_in_gross: $row.find('.appraisal_component_type').val() === 'earning' ? 1 : 0,
            include_in_ctc: 1,
            include_in_payslip: 1,
            display_order: index + 1
        });
    });

    const payload = {
        entity_id: Number(entityId),
        branch_id: branchId ? Number(branchId) : null,
        department_id: Number(departmentId),
        employee_sno: Number(employeeId),
        salary_account_id: Number(salaryAccountId),
        payroll_template_sno: Number(templateId),
        effective_from: effectiveFrom,
        gross_salary: grossSalary,
        appraisal_type: Number($('#appraisal_type').val() || 1),
        appraisal_unit: $('#appraisal_unit').val() || '%',
        appraisal_value: $('#appraisal_value').val() || null,
        appraisal_reason: $('#appraisal_reason').val() || null,
        variable_check: variableCheck,
        variable_component: variableCheck ? Number($('#appraisal_variable_component').val()) : null,
        variable_amount: variableCheck ? Number($('#appraisal_variable_amount').val()) : 0,
        variable_from: variableCheck ? $('#appraisal_variable_from').val() : null,
        variable_months: variableCheck ? 3 : 0,
        variable_end_month: variableCheck ? $('#appraisal_variable_end').val() : null,
        details: details
    };

    const $btn = $('#saveAppraisalBtn');
    $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Saving Appraisal...');

    $.ajax({
        url: '/hr_sib/appraisal/save',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(payload),
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            'Accept': 'application/json'
        },
        success: function (response) {
            toastr.success(response.message || 'Appraisal saved successfully.');
            $('#addAppraisalModal').modal('hide');
            if (typeof loadEmployees === 'function') loadEmployees(1);
            refreshAppraisalPendingActions();
        },
        error: function (xhr) {
            if (xhr.status === 422 && xhr.responseJSON?.errors) {
                Object.values(xhr.responseJSON.errors).forEach(function (messages) {
                    (Array.isArray(messages) ? messages : [messages]).forEach(function (message) {
                        toastr.error(message);
                    });
                });
            } else {
                toastr.error(xhr.responseJSON?.message || 'Unable to save appraisal.');
            }
        },
        complete: function () {
            $btn.prop('disabled', false).html('<i class="mdi mdi-content-save-check-outline me-1"></i> Save Appraisal');
        }
    });
}

function renderExpiredVariableRows(rows) {
    if (!rows || !rows.length) {
        $('#expiredVariableSummary').removeClass('alert-warning').addClass('alert-light').html('<i class="mdi mdi-check-circle-outline text-success me-1"></i><strong>No expired variable pay is pending.</strong>');
        $('#expiredVariableRows').html('<div class="appraisal-empty"><i class="mdi mdi-check-decagram-outline fs-1 text-success"></i><div class="fw-bold mt-2">All variable pay is up to date</div></div>');
        return;
    }

    $('#expiredVariableSummary').removeClass('alert-light').addClass('alert-warning').html(`<strong>${rows.length} variable pay record(s)</strong> completed their 3-month window and can now be moved into gross salary. The existing appraisal history is retained; no second salary-history row is created.`);

    const html = `
        <div class="table-responsive">
            <table class="table align-middle table-hover mb-0 bg-white">
                <thead>
                    <tr>
                        <th>Staff</th>
                        <th>Component</th>
                        <th>Variable Period</th>
                        <th class="text-end">Variable Amount</th>
                        <th class="text-end">Current Gross</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(function (row) {
                        return `
                            <tr id="expiredVariableRow_${Number(row.sno)}">
                                <td>
                                    <div class="fw-bold">${appraisalEscape(row.staff_name)}</div>
                                    <div class="small text-muted">${appraisalEscape(row.staff_id)} · ${appraisalEscape(row.department_name)}</div>
                                </td>
                                <td><span class="badge bg-primary-subtle text-primary">${appraisalEscape(row.component_name || 'Variable Pay')}</span><div class="small text-muted mt-1">${appraisalEscape(row.component_code || '')}</div></td>
                                <td><div class="fw-semibold">${appraisalMonth(row.start_month)} → ${appraisalMonth(row.end_month)}</div><div class="small text-muted">Ended</div></td>
                                <td class="text-end fw-bold text-warning">${appraisalCurrency(row.amount)}</td>
                                <td class="text-end">${appraisalCurrency(row.basic_salary)}</td>
                                <td class="text-end">
                                    <button type="button" class="btn btn-sm btn-warning fw-bold apply-expired-variable" data-id="${Number(row.sno)}">
                                        <i class="mdi mdi-arrow-up-bold-circle-outline me-1"></i> Add to Gross
                                    </button>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
    $('#expiredVariableRows').html(html);
}

function loadExpiredVariableRows() {
    $('#expiredVariableRows').html('<div class="appraisal-loading"><div class="text-center"><div class="spinner-border text-warning"></div><div class="small mt-2">Checking variable pay...</div></div></div>');
    $.ajax({
        url: '/hr_sib/appraisal/expired-variable',
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (!response.status) {
                toastr.error(response.message || 'Unable to load expired variable pay.');
                return;
            }
            appraisalState.expiredVariables = response.data || [];
            renderExpiredVariableRows(appraisalState.expiredVariables);
            updateExpiredVariableUi(response.count || appraisalState.expiredVariables.length);
        },
        error: function (xhr) {
            $('#expiredVariableRows').html('<div class="appraisal-empty text-danger">Unable to load expired variable pay records.</div>');
            toastr.error(xhr.responseJSON?.message || 'Unable to load expired variable pay records.');
        }
    });
}

function openExpiredVariableModal() {
    $('#expiredVariableModal').modal('show');
    loadExpiredVariableRows();
}

function updateExpiredVariableUi(count) {
    const $button = $('#expiredVariableBtn');
    const $alertButton = $('#openExpiredVariableFromAlert');
    if (Number(count) > 0) {
        $('#expiredVariableBadge').text(count);
        $button.removeClass('d-none');
        $alertButton.removeClass('d-none');
    } else {
        $button.addClass('d-none');
        $alertButton.addClass('d-none');
    }
}

function renderCasualLeaveRows(rows) {
    if (!rows || !rows.length) {
        $('#casualLeaveRows').html('<div class="appraisal-empty"><i class="mdi mdi-check-decagram-outline fs-1 text-success"></i><div class="fw-bold mt-2">No pending casual-leave updates</div><div class="small">All eligible active staff have a monthly casual-leave allowance.</div></div>');
        $('#saveCasualLeaveBtn').prop('disabled', true);
        return;
    }

    $('#saveCasualLeaveBtn').prop('disabled', false);
    const html = `
        <div class="table-responsive">
            <table class="table align-middle table-hover mb-0 bg-white" id="casualLeavePendingTable">
                <thead>
                    <tr>
                        <th>Staff</th>
                        <th>Entity / Branch</th>
                        <th>Department</th>
                        <th>Joining Date</th>
                        <th>6-Month Completed</th>
                        <th style="width:180px;">Casual Leave / Month</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(function (row) {
                        return `
                            <tr data-search="${appraisalEscape(`${row.staff_name || ''} ${row.staff_id || ''} ${row.department_name || ''} ${row.entity_name || ''} ${row.branch_name || ''}`).toLowerCase()}">
                                <td>
                                    <div class="fw-bold">${appraisalEscape(row.staff_name)}</div>
                                    <div class="small text-muted">${appraisalEscape(row.staff_id)}</div>
                                </td>
                                <td>
                                    <div class="small fw-semibold">${Number(row.entity_id || 0) === 0 ? appraisalEscape(appraisalState.formData?.main_company?.title || 'Main Company') : appraisalEscape(row.entity_name)}</div>
                                    <div class="small text-muted">${appraisalEscape(row.branch_name || 'Not Applicable')}</div>
                                </td>
                                <td>${appraisalEscape(row.department_name)}</td>
                                <td>${appraisalDate(row.date_of_joining)}</td>
                                <td><span class="badge bg-success-subtle text-success">${appraisalDate(row.completed_six_months_on)}</span></td>
                                <td>
                                    <div class="input-group input-group-sm">
                                        <input type="number" min="1" max="31" class="form-control casual-leave-value" data-employee-id="${Number(row.sno)}" value="${Number(row.casual_leave_count_per_month || 0) || ''}" placeholder="Enter days">
                                        <span class="input-group-text">days</span>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
    $('#casualLeaveRows').html(html);
    $('#casualLeavePendingCount').text(`${rows.length} Pending`);
}

function loadPendingCasualLeaveRows() {
    $('#casualLeaveRows').html('<div class="appraisal-loading"><div class="text-center"><div class="spinner-border text-primary"></div><div class="small mt-2">Loading eligible staff...</div></div></div>');
    $.ajax({
        url: '/hr_sib/appraisal/pending-casual-leave',
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (!response.status) {
                toastr.error(response.message || 'Unable to load pending casual leave.');
                return;
            }
            appraisalState.pendingCasualLeave = response.data || [];
            $('#casualLeavePendingCount').text(`${Number(response.count || 0)} Pending`);
            renderCasualLeaveRows(appraisalState.pendingCasualLeave);
            updateCasualLeaveUi(response.count || appraisalState.pendingCasualLeave.length);
        },
        error: function (xhr) {
            $('#casualLeaveRows').html('<div class="appraisal-empty text-danger">Unable to load pending casual-leave records.</div>');
            toastr.error(xhr.responseJSON?.message || 'Unable to load pending casual leave.');
        }
    });
}

function openCasualLeaveModal() {
    $('#casualLeaveModal').modal('show');
    $('#casualLeaveSearch').val('');
    loadPendingCasualLeaveRows();
}

function updateCasualLeaveUi(count) {
    const badge = $('#pendingCasualLeaveBadge');
    const alertButton = $('#openCasualLeaveFromAlert');
    if (Number(count) > 0) {
        badge.text(count).removeClass('d-none');
        alertButton.removeClass('d-none');
    } else {
        badge.addClass('d-none');
        alertButton.addClass('d-none');
    }
}

function saveCasualLeaveUpdates() {
    const payload = { staff: [] };
    let invalidRow = null;

    $('#casualLeavePendingTable tbody tr:visible').each(function () {
        const $input = $(this).find('.casual-leave-value');
        const raw = $input.val();
        if (raw === '' || raw === null) return;
        const value = Number(raw);
        if (!Number.isInteger(value) || value < 1 || value > 31) {
            $input.addClass('is-invalid');
            invalidRow = $input;
            return;
        }
        $input.removeClass('is-invalid');
        payload.staff.push({
            employee_sno: Number($input.data('employee-id')),
            casual_leave_count_per_month: value
        });
    });

    if (invalidRow) {
        toastr.error('Casual leave must be a whole number between 1 and 31 days.');
        invalidRow.focus();
        return;
    }
    if (!payload.staff.length) {
        toastr.error('Enter casual-leave days for at least one staff member.');
        return;
    }

    const $btn = $('#saveCasualLeaveBtn');
    $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Saving...');

    $.ajax({
        url: '/hr_sib/appraisal/pending-casual-leave/update',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(payload),
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            'Accept': 'application/json'
        },
        success: function (response) {
            toastr.success(response.message || 'Casual leave updated successfully.');
            loadPendingCasualLeaveRows();
            refreshAppraisalPendingActions();
        },
        error: function (xhr) {
            toastr.error(xhr.responseJSON?.message || 'Unable to update casual leave.');
        },
        complete: function () {
            $btn.prop('disabled', false).html('<i class="mdi mdi-content-save-outline me-1"></i> Save Leave Updates');
        }
    });
}

function refreshPendingAlertText(expiredCount, casualCount) {
    const total = Number(expiredCount || 0) + Number(casualCount || 0);
    if (!total) {
        $('#appraisalPendingActionAlert').addClass('d-none');
        return;
    }

    $('#appraisalPendingActionAlert').removeClass('d-none');
    const pieces = [];
    if (Number(expiredCount) > 0) pieces.push(`${expiredCount} expired variable-pay record${Number(expiredCount) === 1 ? '' : 's'}`);
    if (Number(casualCount) > 0) pieces.push(`${casualCount} pending 6-month casual-leave update${Number(casualCount) === 1 ? '' : 's'}`);
    $('#appraisalPendingActionTitle').text(`${total} HR action${total === 1 ? '' : 's'} require attention`);
    $('#appraisalPendingActionText').text(pieces.join(' and ') + '.');
}

function refreshAppraisalPendingActions() {
    let expiredCount = 0;
    let casualCount = 0;
    let completed = 0;

    const done = function () {
        completed++;
        if (completed === 2) refreshPendingAlertText(expiredCount, casualCount);
    };

    $.ajax({
        url: '/hr_sib/appraisal/expired-variable',
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (response?.status) {
                expiredCount = Number(response.count || 0);
                appraisalState.expiredVariables = response.data || [];
                updateExpiredVariableUi(expiredCount);
            }
        },
        complete: done
    });

    $.ajax({
        url: '/hr_sib/appraisal/pending-casual-leave',
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (response?.status) {
                casualCount = Number(response.count || 0);
                appraisalState.pendingCasualLeave = response.data || [];
                updateCasualLeaveUi(casualCount);
                $('#casualLeavePendingCount').text(`${casualCount} Pending`);
            }
        },
        complete: done
    });
}

$(document).on('change', '#appraisal_entity_id', function () {
    const entityId = $(this).val();
    resetAppraisalSelect($('#appraisal_department_id'), 'Select Department');
    resetAppraisalSelect($('#appraisal_employee_sno'), 'Select Staff');
    $('#appraisal_department_id, #appraisal_employee_sno').prop('disabled', true);
    $('#appraisal_salary_account_id, #appraisal_payroll_template_sno, #appraisal_gross_salary').prop('disabled', true);
    $('#appraisalStaffProfilePanel').html('<div class="appraisal-empty">Select a staff member to see profile, current salary and last appraisal.</div>');
    $('#appraisalCurrentSalaryPanel').html('<div class="appraisal-empty">Current salary details will appear after staff selection.</div>');
    $('#appraisalLastAppraisalPanel').html('<div class="appraisal-empty">No employee selected.</div>');
    $('#appraisal_salary_components').html('<div class="appraisal-empty">Select a staff and payroll template to load the salary structure.</div>');
    resetAppraisalSummary();

    if (entityId === '') {
        $('#appraisalBranchWrap').addClass('d-none');
        return;
    }
    loadAppraisalBranches(entityId);
    loadAppraisalDepartments(entityId);
});

$(document).on('change', '#appraisal_branch_id', function () {
    if (Number($('#appraisal_entity_id').val() || 0) > 0) {
        loadAppraisalStaffOptions();
    }
});

$(document).on('change', '#appraisal_department_id', function () {
    loadAppraisalStaffOptions();
});

$(document).on('change', '#appraisal_employee_sno', function () {
    const staffId = $(this).val();
    if (!staffId) return;
    loadAppraisalStaffProfile(staffId);
});

$(document).on('change', '#appraisal_salary_account_id', function () {
    const employeeId = $('#appraisal_employee_sno').val();
    const accountId = $(this).val();
    if (employeeId && accountId) {
        loadAppraisalAccountStructure(employeeId, accountId);
    }
});

$(document).on('change', '#appraisal_payroll_template_sno', function () {
    const templateId = $(this).val();
    if (templateId) loadAppraisalTemplate(templateId);
});

$(document).on('keyup change', '#appraisal_gross_salary', function () {
    recalculateAppraisalComponents();
});

$(document).on('change', '#appraisal_variable_check', function () {
    const checked = $(this).is(':checked');
    if (checked) {
        $('#appraisalVariableFields').removeClass('d-none').hide().slideDown(180);
        const effective = $('#appraisal_effective_from').val() || new Date().toISOString().slice(0, 7);
        if (!$('#appraisal_variable_from').val()) {
            $('#appraisal_variable_from').val(effective);
        }
        if ($.fn.datepicker) {
            try { $('#appraisal_variable_from').datepicker('setDate', new Date($('#appraisal_variable_from').val() + '-01T00:00:00')); } catch (e) {}
        }
        calculateVariableEndMonth();
    } else {
        $('#appraisalVariableFields').slideUp(180, function () { $(this).addClass('d-none'); });
        $('#appraisal_variable_component, #appraisal_variable_amount, #appraisal_variable_from, #appraisal_variable_end').val('').trigger('change.select2');
        $('#appraisal_variable_months').val('3');
    }
});

$(document).on('change', '#appraisal_effective_from', function () {
    if ($('#appraisal_variable_check').is(':checked') && !$('#appraisal_variable_from').val()) {
        $('#appraisal_variable_from').val($(this).val());
        calculateVariableEndMonth();
    }
});

$(document).on('change', '#appraisal_variable_from', function () {
    calculateVariableEndMonth();
});

$(document).on('input', '.appraisal_component_amount', function () {
    this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
    recalculateAppraisalComponents();
});

$(document).on('click', '.apply-expired-variable', function () {
    const $btn = $(this);
    const variableId = Number($btn.data('id'));
    if (!variableId) return;

    const record = appraisalState.expiredVariables.find(item => Number(item.sno) === variableId);
    const staffName = record?.staff_name || 'this employee';
    const amount = appraisalCurrency(record?.amount || 0);
    if (!window.confirm(`Move ${amount} variable pay into ${staffName}'s gross salary and rebuild the payroll structure?\n\nNo additional salary-history record will be created.`)) {
        return;
    }

    $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span>Updating...');
    $.ajax({
        url: '/hr_sib/appraisal/expired-variable/' + encodeURIComponent(variableId) + '/apply',
        type: 'POST',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            'Accept': 'application/json'
        },
        success: function (response) {
            toastr.success(response.message || 'Variable pay moved into gross salary.');
            loadExpiredVariableRows();
            refreshAppraisalPendingActions();
            if (typeof loadEmployees === 'function') loadEmployees(1);
        },
        error: function (xhr) {
            toastr.error(xhr.responseJSON?.message || 'Unable to update expired variable pay.');
            $btn.prop('disabled', false).html('<i class="mdi mdi-arrow-up-bold-circle-outline me-1"></i> Add to Gross');
        }
    });
});

$(document).on('input', '#casualLeaveSearch', function () {
    const query = String($(this).val() || '').trim().toLowerCase();
    $('#casualLeavePendingTable tbody tr').each(function () {
        const haystack = String($(this).data('search') || '').toLowerCase();
        $(this).toggle(!query || haystack.includes(query));
    });
});

$('#addAppraisalModal').on('shown.bs.modal', function () {
    initAppraisalModalPlugins();
});

$('#addAppraisalModal').on('hidden.bs.modal', function () {
    // Keep cached form metadata, but clear employee-specific data on next open.
    appraisalState.staffProfile = null;
    appraisalState.currentStructure = null;
    appraisalState.currentStructureDetails = [];
});

// Surface pending HR actions when the Manage Appraisal page opens.
$(document).ready(function () {
    setTimeout(refreshAppraisalPendingActions, 500);
});
</script>
<script>
    function formatDateCommon(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0'); // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', {
            month: 'short'
        }); // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
</script>

@endsection