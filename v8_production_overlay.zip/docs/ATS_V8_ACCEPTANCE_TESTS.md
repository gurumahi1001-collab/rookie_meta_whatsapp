# ATS v8 Acceptance Checklist

## Candidate modal
- [ ] Resume upload begins parsing without closing the modal.
- [ ] Candidate name is filled from resume identity evidence and uses display capitalization.
- [ ] Indian 10-digit mobile is normalized correctly.
- [ ] Existing active applicant mobile immediately shows duplicate error via toastr/UI state.
- [ ] Duplicate insert is rejected server-side even if the browser check is bypassed.
- [ ] Email is correctly normalized.
- [ ] Explicit gender is populated; absent gender remains unselected.
- [ ] Qualification is selected from `egc_qualification_level`.
- [ ] Major is selected from `egc_major` within the correct qualification context.
- [ ] Unknown qualification uses Other Qualification.
- [ ] Unknown major uses Other Major.
- [ ] Experience count is consistent with date evidence and does not double count overlaps.
- [ ] Resume preview is visible inside the Add Candidate modal.
- [ ] Resume can be hidden/shown without leaving the modal.
- [ ] View Resume button remains at the bottom of the modal.

## ATS individual
- [ ] Complete active role catalogue is evaluated.
- [ ] Score components render without NaN/undefined values.
- [ ] Evidence and gaps are readable.
- [ ] Role result remains available even when semantic retrieval top-N changes.

## ATS bulk
- [ ] Stats endpoint returns a valid JSON payload.
- [ ] Run creation persists a run record and item records.
- [ ] Progress changes as items complete.
- [ ] Cancel works for queued/running runs.
- [ ] Final result summary loads without browser exceptions.
