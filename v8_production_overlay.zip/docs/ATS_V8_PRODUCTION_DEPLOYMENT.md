# ARGUS ATS v8 — Production Deployment

## Scope
This release is an ATS/recruitment overlay only. It does not redesign unrelated ERP modules.

## Core behavior
- Resume processing is field-by-field, evidence-first and master-data-backed.
- Candidate name is normalized to display capitalization, but the stored value is derived from resume identity/header evidence rather than an arbitrary model guess.
- Mobile is accepted only as an Indian 10-digit number after normalization and is checked live against `egc_applicant.status = 0`.
- The browser duplicate check is advisory; the backend repeats the check immediately before insert and under a database advisory lock to prevent race-condition duplicates.
- Qualification is resolved from the live `egc_qualification_level` master.
- Major is resolved from the live `egc_major` master, constrained to the resolved qualification where the schema provides that relationship.
- If no qualification master match exists, the candidate is stored in `Others`/`other_qualification` semantics. If no major match exists, the candidate is stored with `other_major` while preserving the raw extracted text.
- Gender is accepted only when explicitly stated in the source resume. It is not inferred from a person's name, religion, photograph or other indirect signals.
- Experience is calculated from evidence-bearing employment periods, supports current roles, normalizes date formats and merges overlapping periods to prevent double counting.
- Role matching evaluates deterministic coverage across the complete active role catalogue; semantic retrieval is an accelerator, not a hard catalogue limit.
- Bulk matching is asynchronous and uses persisted run/run-item tables for progress and statistics.

## 1. Backup
Take a database backup before applying any migration or code deployment.

## 2. Database migration
Run:

`database/recruitment_ats/ATS_V8.sql`

The migration is additive and includes the ATS tables/columns required by the code. Existing recruitment masters and IDs are preserved.

## 3. Environment
Copy the ATS environment values from `docs/.env.recruitment_ats.example` into the production environment. Set a valid Hugging Face token for your approved inference endpoint/model.

Recommended production values are:
- `RECRUITMENT_ATS_ENABLED=true`
- `RECRUITMENT_ATS_ASYNC_ENABLED=true`
- `HF_TIMEOUT=180`
- `RECRUITMENT_ATS_ROLE_CATALOG_LIMIT=24`
- `RECRUITMENT_ATS_EMBEDDING_MODEL=BAAI/bge-m3`

The model names remain environment-configurable. Do not place provider secrets in source control.

## 4. Application cache
After deployment:

`php artisan optimize:clear`

Then rebuild production caches using your normal deployment process.

## 5. Queue worker
Bulk ATS uses the queued job `ProcessRecruitmentAtsRoleMatchingRunJob`.
Run the normal production queue worker/supervisor configuration used by the ERP. The worker must be running before users start bulk matching.

## 6. Web server / upload requirements
The resume upload path must allow the same document MIME types and maximum request/upload size already configured for the HR recruiter module. Keep file storage on the existing application storage mechanism; this release does not require AWS/S3.

## 7. Realtime duplicate mobile check
The candidate modal calls `POST /candidate/mobile-check` after a normalized 10-digit Indian number is formed. The endpoint checks active applicants only (`status = 0`). A 409 response produces the duplicate-number error state in the modal. The final candidate insert repeats the rule server-side.

## 8. Clean-install verification
Verify that these ATS tables exist:
- `egc_applicant_resume_extractions`
- `egc_applicant_resume_extraction_fields`
- `egc_applicant_ats_role_analyses`
- `egc_applicant_ats_role_matches`
- `egc_recruitment_ai_runs`
- `egc_recruitment_ai_run_items`
- `egc_recruitment_role_requirements`
- `egc_recruitment_role_aliases`
- `egc_recruitment_major_aliases`
- `egc_recruitment_qualification_aliases`
- `egc_recruitment_skill_aliases`

Verify `egc_applicant.other_major` exists.

## 9. Acceptance tests
Before production rollout, test at least:
1. A resume with a conventional header name.
2. A resume where the name appears only in a labeled `Name:` line.
3. `+91 9876543210`, `98765-43210`, and formatted Indian numbers.
4. Existing active applicant mobile → modal blocks with duplicate error and final insert also rejects it.
5. `Bachelor of Science in Computer Science` → the correct table-backed qualification and major.
6. An unmatched qualification → Other Qualification.
7. A known qualification with an unmatched major → Other Major; never reuse the qualification field.
8. Explicit `Gender: Female` / `Gender: Male`.
9. A resume with no explicit gender → gender remains unselected/reviewable.
10. Overlapping employment periods → no double-counting.
11. `2021 – Present` employment → current end date is handled correctly.
12. Individual ATS matching returns advanced score/evidence/gaps.
13. Bulk ATS statistics loads before a run starts.
14. Bulk ATS run starts, progresses and finishes through the persisted run tables.
15. A role outside semantic top-N can still be persisted as a full match when deterministic/semantic scoring supports it.

## Important accuracy expectation
No general AI system can guarantee literal 100% extraction accuracy for arbitrary resumes. This release reduces silent errors by requiring evidence, deterministic validation, live master resolution, independent verification and manual-review states for ambiguous fields.
