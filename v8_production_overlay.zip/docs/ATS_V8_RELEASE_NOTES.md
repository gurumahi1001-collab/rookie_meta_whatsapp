# ARGUS ATS v8 — Release Notes

## Main fixes

### Candidate extraction
- Reworked extraction into separate contact, identity, education and experience stages.
- Added evidence-backed AI arbitration instead of trusting a single whole-candidate model output.
- Candidate name is resolved from identity/header evidence and normalized for display.
- Indian mobile validation is strict and reused by browser + backend.
- Email is normalized and validated before persistence.
- Qualification/major are resolved against the live masters, not generic free-text similarity.
- Education variants such as `Bachelor of Science in Computer Science` are normalized to canonical master text before resolution.
- Unknown qualification and unknown major are stored separately using Other fields.
- Removed the stale 15-minute education-master cache so current master edits are visible to resume parsing immediately.
- Experience resolver supports current jobs, common date formats, explicit totals and overlapping periods without double counting.

### Gender
- Explicit resume statements are accepted.
- Name-based or indirect gender inference is deliberately not used because it is unreliable.

### Duplicate mobile
- Added `/candidate/mobile-check` realtime endpoint.
- Checks active applicants (`status = 0`).
- UI checks on keyup/input/paste once a valid 10-digit Indian number exists.
- Server repeats the check during creation and protects the final insert with a database advisory lock.

### Add Candidate UX
- Inline resume preview inside Add Candidate modal.
- Hide/show resume viewer.
- Bottom `View Resume` control.
- Extraction intelligence/status indicators.
- Separate `Other Qualification` and `Other Major` controls.
- Submit remains blocked during resume processing and duplicate-number verification.

### ATS matching
- Full active role catalogue is deterministically evaluated.
- Semantic retrieval is only an optimization layer.
- Individual matching has detailed score components, evidence, gaps and ATS quality signals.
- Bulk matching is asynchronous with persisted run + item state.
- Bulk statistics have safe error handling and no raw production exception leakage.

## Database
`database/recruitment_ats/ATS_V8.sql` is additive and creates the tables required by the v8 code path. Existing recruitment master IDs are preserved.
