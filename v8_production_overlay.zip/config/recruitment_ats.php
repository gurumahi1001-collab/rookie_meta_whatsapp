<?php

declare(strict_types=1);

return [
    /*
    |--------------------------------------------------------------------------
    | Canonical recruitment ATS configuration
    |--------------------------------------------------------------------------
    | Recruitment uses its own config namespace so existing ERP AI features
    | remain untouched.
    */

    'enabled' => env('RECRUITMENT_ATS_ENABLED', true),
    'resume_ai_enabled' => env('RECRUITMENT_RESUME_AI_ENABLED', true),
    'resume_verification_enabled' => env('RECRUITMENT_RESUME_VERIFICATION_ENABLED', true),

    'engine' => env('RECRUITMENT_ATS_ENGINE', 'egc_ats_hybrid_evidence_v8'),
    'schema_version' => env('RECRUITMENT_ATS_SCHEMA_VERSION', 'ats_role_matching.v8'),
    'resume_parser_version' => env('RECRUITMENT_RESUME_PARSER_VERSION', 'resume_parser.v8'),

    'hf_chat_url' => env('RECRUITMENT_HF_CHAT_URL', 'https://router.huggingface.co/v1/chat/completions'),
    'hf_url' => env('RECRUITMENT_HF_CHAT_URL', 'https://router.huggingface.co/v1/chat/completions'),
    // Optional dedicated endpoint. Leave blank to use the HF Inference provider
    // router path for feature extraction.
    'hf_embedding_url' => env('RECRUITMENT_HF_EMBEDDING_URL', ''),

    'model' => env('RECRUITMENT_ATS_MODEL', 'openai/gpt-oss-120b:fastest'),
    'resume_primary_model' => env('RECRUITMENT_RESUME_PRIMARY_MODEL', 'openai/gpt-oss-120b:fastest'),
    'resume_verifier_model' => env('RECRUITMENT_RESUME_VERIFIER_MODEL', 'openai/gpt-oss-120b:fastest'),
    'embedding_model' => env('RECRUITMENT_EMBEDDING_MODEL', 'BAAI/bge-m3'),

    'ai_timeout' => (int) env('RECRUITMENT_ATS_AI_TIMEOUT', 90),
    'resume_primary_timeout' => (int) env('RECRUITMENT_RESUME_PRIMARY_TIMEOUT', 90),
    'resume_verify_timeout' => (int) env('RECRUITMENT_RESUME_VERIFY_TIMEOUT', 75),
    'embedding_timeout' => (int) env('RECRUITMENT_EMBEDDING_TIMEOUT', 45),
    'ai_max_tokens' => (int) env('RECRUITMENT_ATS_AI_MAX_TOKENS', 4000),

    'max_resume_file_kb' => (int) env('RECRUITMENT_MAX_RESUME_FILE_KB', 10240),
    'max_resume_chars' => (int) env('RECRUITMENT_MAX_RESUME_CHARS', 150000),
    'resume_model_max_chars' => (int) env('RECRUITMENT_RESUME_MODEL_MAX_CHARS', 70000),
    'resume_source_max_chars' => (int) env('RECRUITMENT_RESUME_SOURCE_MAX_CHARS', 150000),
    'embedding_resume_max_chars' => (int) env('RECRUITMENT_EMBEDDING_RESUME_MAX_CHARS', 12000),
    'max_prompt_resume_chars' => (int) env('RECRUITMENT_MAX_PROMPT_RESUME_CHARS', 50000),
    'bulk_model_max_resume_chars' => (int) env('RECRUITMENT_BULK_MODEL_MAX_RESUME_CHARS', 30000),

    'allowed_resume_extensions' => [
        'pdf','doc','docx','docm','odt','rtf','txt','text','md','markdown','html','htm',
        'jpg','jpeg','png','webp','bmp','gif','tif','tiff',
    ],
    'ocr_lang' => env('RECRUITMENT_OCR_LANG', 'eng'),
    'ocr_dpi' => (int) env('RECRUITMENT_OCR_DPI', 180),
    'ocr_max_pages' => (int) env('RECRUITMENT_OCR_MAX_PAGES', 25),
    'pdf_ocr_text_threshold' => (int) env('RECRUITMENT_PDF_OCR_TEXT_THRESHOLD', 250),

    // Role catalogue is source of truth. No role may be invented outside the DB.
    'role_retrieval_limit' => (int) env('RECRUITMENT_ROLE_RETRIEVAL_LIMIT', 24),
    'role_semantic_candidate_limit' => (int) env('RECRUITMENT_ROLE_SEMANTIC_CANDIDATE_LIMIT', 24),
    'role_catalog_cache_minutes' => (int) env('RECRUITMENT_ROLE_CATALOG_CACHE_MINUTES', 5),
    'role_embedding_cache_minutes' => (int) env('RECRUITMENT_ROLE_EMBEDDING_CACHE_MINUTES', 60),
    'role_embedding_enabled' => env('RECRUITMENT_ROLE_EMBEDDING_ENABLED', true),

    'minimum_match_score' => (float) env('RECRUITMENT_ATS_MINIMUM_MATCH_SCORE', 70),
    'strong_match_score' => (float) env('RECRUITMENT_ATS_STRONG_MATCH_SCORE', 85),
    'near_match_min_score' => (float) env('RECRUITMENT_ATS_NEAR_MATCH_MIN_SCORE', 45),
    'near_match_max_items' => (int) env('RECRUITMENT_ATS_NEAR_MATCH_MAX_ITEMS', 8),
    'mandatory_skill_fail_cap' => (float) env('RECRUITMENT_ATS_MANDATORY_SKILL_FAIL_CAP', 59),
    'experience_requirement_fail_cap' => (float) env('RECRUITMENT_ATS_EXPERIENCE_REQUIREMENT_FAIL_CAP', 59),
    'education_requirement_fail_cap' => (float) env('RECRUITMENT_ATS_EDUCATION_REQUIREMENT_FAIL_CAP', 59),
    'scoring_version' => env('RECRUITMENT_ATS_SCORING_VERSION', 'ats_scoring.v4'),
    'sparse_role_score_cap' => (float) env('RECRUITMENT_ATS_SPARSE_ROLE_SCORE_CAP', 82),

    // Education resolution thresholds. Ambiguous values become manual-review
    // instead of silently assigning the wrong egc_major ID.
    'education_min_major_score' => (float) env('RECRUITMENT_EDUCATION_MIN_MAJOR_SCORE', 0.88),
    'education_ambiguity_margin' => (float) env('RECRUITMENT_EDUCATION_AMBIGUITY_MARGIN', 0.08),

    // Production bulk controls.
    'queue' => env('RECRUITMENT_ATS_QUEUE', 'ats-role-matching'),
    'job_timeout' => (int) env('RECRUITMENT_ATS_JOB_TIMEOUT', 900),
    'default_batch_size' => (int) env('RECRUITMENT_ATS_DEFAULT_BATCH_SIZE', 2),
    'default_workers' => (int) env('RECRUITMENT_ATS_DEFAULT_WORKERS', 3),
    'max_batch_size' => (int) env('RECRUITMENT_ATS_MAX_BATCH_SIZE', 3),
    'max_workers' => (int) env('RECRUITMENT_ATS_MAX_WORKERS', 8),
    'max_bulk_limit' => (int) env('RECRUITMENT_ATS_MAX_BULK_LIMIT', 50000),
    'stale_run_minutes' => (int) env('RECRUITMENT_ATS_STALE_RUN_MINUTES', 15),

    // Optional role scoping retained for compatibility with the current UI.
    'allowed_role_ids' => [],
    'force_reprocess_role_ids' => [],

    // Safety: the system should prefer review over an unverified candidate fact.
    'manual_review_score_cap' => (float) env('RECRUITMENT_ATS_MANUAL_REVIEW_SCORE_CAP', 79),
];
