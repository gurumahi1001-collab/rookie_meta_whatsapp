<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

class RecruitmentAtsResponseValidator
{
    public function __construct(protected RecruitmentAtsScoringService $scorer) {}

    public function validateBatch(array $response,array $requestedApplicantIds,array $roles,array $resumeTexts=[]): array
    {
        if(!isset($response['results'])||!is_array($response['results']))return ['status'=>false,'message'=>'AI response does not contain a valid results array.'];
        $allowed=array_fill_keys(array_map('strval',$requestedApplicantIds),true);$roleIndex=[];
        foreach($roles as $r)$roleIndex[(string)($r['sno']??$r['role_id']??0)]=$r;
        $validated=[];
        foreach($response['results'] as $item){
            if(!is_array($item))continue;$id=(string)($item['applicant_id']??'');if($id===''||!isset($allowed[$id]))continue;
            $resume=(string)($resumeTexts[$id]??'');$analysis=$this->normalizeAnalysis($item['analysis']??[]);$matches=$this->normalizeMatches($item['matches']??[],$roleIndex,$resume,true);$near=$this->normalizeMatches($item['near_matches']??[],$roleIndex,$resume,false);
            $analysis['overall_match_score']=!empty($matches)?max(array_map(fn($x)=>(float)$x['match_score'],$matches)):0;
            $validated[$id]=['applicant_id'=>$id,'analysis'=>$analysis,'matches'=>$matches,'near_matches'=>$near];
        }
        return ['status'=>true,'results'=>$validated];
    }

    private function normalizeMatches(mixed $matches,array $roleIndex,string $resume,bool $accepted): array
    {
        if(!is_array($matches))return[];$out=[];$min=(float)config('recruitment_ats.minimum_match_score',70);$near=(float)config('recruitment_ats.near_match_min_score',45);
        foreach($matches as $m){if(!is_array($m))continue;$id=(string)($m['role_id']??'');if($id===''||!isset($roleIndex[$id]))continue;$role=$roleIndex[$id];
            $raw=[
                'semantic_fit_score'=>$this->score($m['semantic_fit_score']??0),'title_alignment_score'=>$this->score($m['title_alignment_score']??0),
                'skill_alignment_score'=>$this->score($m['skill_alignment_score']??0),'experience_alignment_score'=>$this->score($m['experience_alignment_score']??0),
                'responsibility_alignment_score'=>$this->score($m['responsibility_alignment_score']??0),'seniority_alignment_score'=>$this->score($m['seniority_alignment_score']??0),
                'evidence'=>$this->strings($m['evidence']??[]),'gaps'=>$this->strings($m['gaps']??[]),'reason'=>$this->string($m['reason']??''),
            ];
            $scored=$this->scorer->score($raw,$role,$resume);$score=(float)$scored['match_score'];
            if($accepted&&$score<$min)continue;if(!$accepted&&($score<$near||$score>=$min))continue;$out[]=$scored;
        }
        $out=collect($out)->unique('role_id')->sortByDesc('match_score')->values()->all();
        return $accepted?$out:array_slice($out,0,max(1,(int)config('recruitment_ats.near_match_max_items',8)));
    }
    private function normalizeAnalysis(mixed $a): array
    {
        $a=is_array($a)?$a:[];
        return [
            'overall_match_score'=>$this->score($a['overall_match_score']??0),
            'resume_quality_score'=>$this->score($a['resume_quality_score']??0),
            'ats_keyword_match_score'=>$this->score($a['ats_keyword_match_score']??0),
            'skills_alignment_score'=>$this->score($a['skills_alignment_score']??0),
            'experience_relevance_score'=>$this->score($a['experience_relevance_score']??0),
            'impact_metrics_score'=>$this->score($a['impact_metrics_score']??0),
            'role_responsibility_match_score'=>$this->score($a['role_responsibility_match_score']??0),
            'candidate_summary'=>$this->string($a['candidate_summary']??''),
            'current_designation'=>$this->string($a['current_designation']??''),
            'previous_designations'=>$this->strings($a['previous_designations']??[]),
            'experience_summary'=>$this->string($a['experience_summary']??''),
            'education_summary'=>$this->string($a['education_summary']??''),
            'seniority_assessment'=>$this->string($a['seniority_assessment']??''),
            'data_quality_notes'=>$this->strings($a['data_quality_notes']??[]),
            'strengths'=>$this->strings($a['strengths']??[]),
            'weaknesses'=>$this->strings($a['weaknesses']??[]),
        ];
    }
    private function score(mixed $v):float{return max(0,min(100,round((float)$v,2)));}
    private function string(mixed $v):string{return mb_substr(trim((string)($v??'')),0,5000);}
    private function strings(mixed $v):array{if(!is_array($v))return[];return collect($v)->map(fn($x)=>mb_substr(trim((string)$x),0,1200))->filter()->unique()->values()->all();}
}
