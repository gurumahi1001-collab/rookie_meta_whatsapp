<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use Carbon\CarbonImmutable;

/**
 * Evidence-first professional experience reconstruction.
 *
 * Rules:
 * - AI may locate employment rows, but dates are accepted only when evidenced.
 * - Professional experience is calculated as a union of calendar months, so
 *   concurrent roles are never double-counted.
 * - Education, projects, internships, training and academic dates are excluded.
 * - An explicit total is used only when the resume labels it as experience.
 */
class RecruitmentExperienceResolver
{
    private const MONTHS = [
        'jan' => 1, 'january' => 1, 'feb' => 2, 'february' => 2,
        'mar' => 3, 'march' => 3, 'apr' => 4, 'april' => 4,
        'may' => 5, 'jun' => 6, 'june' => 6, 'jul' => 7, 'july' => 7,
        'aug' => 8, 'august' => 8, 'sep' => 9, 'sept' => 9, 'september' => 9,
        'oct' => 10, 'october' => 10, 'nov' => 11, 'november' => 11,
        'dec' => 12, 'december' => 12,
    ];

    private const EXCLUDED = '/\b(?:intern(?:ship)?|trainee|apprentice|volunteer|student|academic|coursework|training)\b/i';
    private const PROFESSIONAL_ROLE = '/\b(?:developer|engineer|manager|analyst|designer|consultant|executive|administrator|lead|director|specialist|officer|associate|architect|accountant|auditor|recruiter|sales|marketing|finance|operations|hr|human\s+resources|software|network|devops|qa|quality|support|technician|programmer|scientist|product|project\s+manager|team\s+lead|business\s+analyst|teacher|professor|lecturer|doctor|physician|nurse|lawyer|legal|pharmacist|chemist|cashier|clerk|operator|coordinator|assistant|representative|advisor|supervisor|founder|entrepreneur|owner|self[- ]employed)\b/i';

    public function resolve(string $resumeText, array $aiEmployment = [], mixed $aiExplicitTotal = null, string $aiExplicitEvidence = ''): array
    {
        $resumeText = $this->normalize($resumeText);
        $ranges = [];
        $entries = [];
        $review = [];

        foreach ($aiEmployment as $entry) {
            if (!is_array($entry)) continue;

            $evidence = $this->clean($entry['evidence'] ?? '');
            $title = $this->clean($entry['title'] ?? '');
            $company = $this->clean($entry['company'] ?? '');
            $employmentType = $this->clean($entry['employment_type'] ?? '');
            $professional = filter_var($entry['is_professional'] ?? false, FILTER_VALIDATE_BOOLEAN);
            $block = trim($title . ' ' . $company . ' ' . $employmentType . ' ' . $evidence);

            if ($evidence === '' || !$this->evidenceSupported($evidence, $resumeText)) continue;
            if (!$professional || preg_match(self::EXCLUDED, $block)) continue;

            $parsed = $this->parseRangeFromTokens(
                $this->clean($entry['start_date'] ?? ''),
                $this->clean($entry['end_date'] ?? '')
            );
            if (!$parsed) $parsed = $this->findDateRanges($evidence);

            foreach ($parsed as $range) {
                if (!$this->rangeAppearsInEvidence($range, $evidence)) continue;
                if (!$this->rangeLooksProfessional($evidence)) continue;

                $ranges[] = $range;
                $entries[] = [
                    'title' => $title,
                    'company' => $company,
                    'start_date' => $range['source_start'],
                    'end_date' => $range['source_end'],
                    'employment_type' => $employmentType !== '' ? $employmentType : 'professional',
                    'evidence' => $evidence,
                ];
            }
        }

        // Independent section scan. This catches model omissions without
        // scanning education/projects as employment.
        foreach ($this->extractRangesFromExperienceSection($resumeText) as $range) {
            $ranges[] = $range;
            $entries[] = [
                'title' => $range['title'] ?? '',
                'company' => $range['company'] ?? '',
                'start_date' => $range['source_start'],
                'end_date' => $range['source_end'],
                'employment_type' => 'professional',
                'evidence' => $range['evidence'],
            ];
        }

        $ranges = $this->deduplicateRanges($ranges);
        $months = $this->unionMonths($ranges);
        $calculatedYears = round(count($months) / 12, 1);

        $explicit = $this->normalizeExplicitTotal($aiExplicitTotal, $aiExplicitEvidence, $resumeText);
        if ($explicit['years'] <= 0) $explicit = $this->extractExplicitTotal($resumeText);

        if ($calculatedYears > 0) {
            $years = $calculatedYears;
            $source = 'employment_ranges';
            if ($explicit['years'] > 0 && abs($explicit['years'] - $calculatedYears) >= 1.1) {
                $review[] = 'experience_total_conflict';
            }
        } elseif ($explicit['years'] > 0) {
            $years = $explicit['years'];
            $source = 'explicit_total';
        } else {
            $years = 0.0;
            $source = 'none';
            if ($this->looksLikeExperiencedCandidate($resumeText)) {
                $review[] = 'experience_dates_not_resolved';
            }
        }

        $years = round(min(60.0, max(0.0, $years)), 1);
        $professionalEvidence = count($ranges) > 0 || $this->hasProfessionalEmploymentText($resumeText);
        $isFresher = $years <= 0.0 && !$professionalEvidence;

        return [
            'years' => $years,
            'type' => $isFresher ? 1 : 2,
            'entries' => $this->deduplicateEntries($entries),
            'evidence' => array_values(array_unique(array_filter(array_map(
                static fn (array $entry): string => trim((string) ($entry['evidence'] ?? '')),
                $entries
            )))),
            'months' => count($months),
            'source' => $source,
            'explicit_total_years' => $explicit['years'],
            'explicit_total_evidence' => $explicit['evidence'],
            'review_fields' => array_values(array_unique($review)),
        ];
    }

    private function extractRangesFromExperienceSection(string $text): array
    {
        $section = $this->experienceSection($text);
        if ($section === null) return $this->extractRangesFromStrongEmploymentLines($text);

        $lines = preg_split('/\R+/u', $section) ?: [];
        $out = [];
        for ($i = 0, $count = count($lines); $i < $count; $i++) {
            $line = $this->clean($lines[$i]);
            if ($line === '' || preg_match(self::EXCLUDED, $line)) continue;
            foreach ($this->findDateRanges($line) as $range) {
                $contextLines = [$line];
                if ($i > 0) $contextLines[] = $this->clean($lines[$i - 1]);
                if ($i + 1 < $count) $contextLines[] = $this->clean($lines[$i + 1]);
                if ($i + 2 < $count) $contextLines[] = $this->clean($lines[$i + 2]);
                $context = trim(implode(' | ', array_filter($contextLines)));
                if (!$this->rangeLooksProfessional($context)) continue;
                $range['evidence'] = $context;
                $range['title'] = $this->guessTitle($context, $range['source_start'], $range['source_end']);
                $range['company'] = $this->guessCompany($context, $range['source_start'], $range['source_end']);
                $out[] = $range;
            }
        }
        return $out;
    }

    private function extractRangesFromStrongEmploymentLines(string $text): array
    {
        $lines = preg_split('/\R+/u', $text) ?: [];
        $out = [];
        foreach ($lines as $i => $rawLine) {
            $line = $this->clean($rawLine);
            if ($line === '' || preg_match(self::EXCLUDED, $line)) continue;
            if (!$this->rangeLooksProfessional($line)) continue;
            foreach ($this->findDateRanges($line) as $range) {
                $range['evidence'] = $line;
                $range['title'] = $this->guessTitle($line, $range['source_start'], $range['source_end']);
                $range['company'] = $this->guessCompany($line, $range['source_start'], $range['source_end']);
                $out[] = $range;
            }
        }
        return $out;
    }

    private function experienceSection(string $text): ?string
    {
        $headers = '(?:WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY|WORK\s+HISTORY|EMPLOYMENT|EXPERIENCE)';
        $stop = '(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS|PROJECTS?|CERTIFICATIONS?|SKILLS|TECHNICAL\s+SKILLS|PERSONAL\s+DETAILS|REFERENCES|ACHIEVEMENTS?|INTERNSHIPS?|TRAINING|LANGUAGES)';
        if (preg_match('/(?:^|\n)\s*' . $headers . '\s*[:\-]?\s*(.*?)(?=\n\s*' . $stop . '\b|$)/is', $text, $m)) {
            return trim((string) $m[1]);
        }
        return null;
    }

    private function findDateRanges(string $text): array
    {
        $month = '(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)';
        $date = '(?:' . $month . "[\\s,.']+\\d{2,4}|(?:19|20)\\d{2}[\\/-]\\d{1,2}|(?:19|20)\\d{2}|(?:0?[1-9]|1[0-2])[\\/-](?:19|20)?\\d{2}|(?:0?[1-9]|[12]\\d|3[01])[\\/-](?:0?[1-9]|1[0-2])[\\/-](?:19|20)\\d{2})";
        $end = '(?:Present|Current|Now|Till\\s+Date|Till\\s+Now|' . $date . ')';
        $pattern = '/(?<start>' . $date . ')\s*(?:-|–|—|to|until|through)\s*(?<end>' . $end . ')/i';
        $out = [];
        if (preg_match_all($pattern, $text, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                foreach ($this->parseRangeFromTokens((string) ($match['start'] ?? ''), (string) ($match['end'] ?? '')) as $range) {
                    $out[] = $range;
                }
            }
        }
        return $this->deduplicateRanges($out);
    }

    private function parseRangeFromTokens(string $startToken, string $endToken): array
    {
        $start = $this->parseMonthIndex($startToken, false);
        $end = $this->parseMonthIndex($endToken, true);
        if ($start === null || $end === null || $end < $start) return [];
        return [[
            'start' => $start,
            'end' => $end,
            'source_start' => trim($startToken),
            'source_end' => trim($endToken),
            'evidence' => trim($startToken . ' - ' . $endToken),
        ]];
    }

    private function parseMonthIndex(string $value, bool $isEnd): ?int
    {
        $value = trim($value);
        if ($value === '') return null;
        if (preg_match('/\b(?:present|current|now|till\s+date|till\s+now)\b/i', $value)) {
            return $this->monthIndex(CarbonImmutable::now());
        }

        $normalized = trim(preg_replace('/\s+/u', ' ', str_replace([',', '.', "'"], ' ', $value)) ?? $value);
        if (preg_match('/\b(' . implode('|', array_keys(self::MONTHS)) . ')\s+(\d{2,4})\b/i', $normalized, $m)) {
            $month = self::MONTHS[strtolower($m[1])] ?? null;
            $year = $this->normalizeYear((int) $m[2]);
            return $month && $year ? $year * 12 + $month : null;
        }
        // DD Month YYYY, e.g. 15 January 2020. The day is irrelevant for the
        // candidate's year-level experience count, so normalize to that month.
        if (preg_match('/\b(?:0?[1-9]|[12]\d|3[01])\s+(' . implode('|', array_keys(self::MONTHS)) . ')\s+(\d{2,4})\b/i', $normalized, $m)) {
            $month = self::MONTHS[strtolower($m[1])] ?? null;
            $year = $this->normalizeYear((int) $m[2]);
            return $month && $year ? $year * 12 + $month : null;
        }
        // YYYY-MM-DD / YYYY/MM/DD.
        if (preg_match('/\b((?:19|20)\d{2})[\/-](\d{1,2})[\/-](\d{1,2})\b/', $value, $m)) {
            return ((int) $m[1]) * 12 + max(1, min(12, (int) $m[2]));
        }
        // YYYY-MM / YYYY/MM.
        if (preg_match('/\b((?:19|20)\d{2})[\/-](\d{1,2})\b/', $value, $m)) {
            return ((int) $m[1]) * 12 + max(1, min(12, (int) $m[2]));
        }
        // MM/YYYY or MM-YYYY.
        if (preg_match('/\b(\d{1,2})[\/-]((?:19|20)\d{2})\b/', $value, $m)) {
            return ((int) $m[2]) * 12 + max(1, min(12, (int) $m[1]));
        }
        // DD/MM/YYYY or DD-MM-YYYY. Only the month/year are used.
        if (preg_match('/\b(?:0?[1-9]|[12]\d|3[01])[\/-](0?[1-9]|1[0-2])[\/-]((?:19|20)\d{2})\b/', $value, $m)) {
            return ((int) $m[2]) * 12 + max(1, min(12, (int) $m[1]));
        }
        if (preg_match('/\b((?:19|20)\d{2})\b/', $value, $m)) {
            return ((int) $m[1]) * 12 + ($isEnd ? 12 : 1);
        }
        return null;
    }

    private function normalizeYear(int $year): int
    {
        if ($year >= 100) return $year;
        $current = (int) CarbonImmutable::now()->format('Y');
        $full = intdiv($current, 100) * 100 + $year;
        return $full > $current + 5 ? $full - 100 : $full;
    }

    private function monthIndex(CarbonImmutable $date): int
    {
        return ((int) $date->format('Y')) * 12 + (int) $date->format('n');
    }

    private function rangeAppearsInEvidence(array $range, string $evidence): bool
    {
        foreach ([$range['source_start'], $range['source_end']] as $token) {
            $year = $this->extractYear((string) $token);
            if ($year !== null && !preg_match('/\b' . preg_quote((string) $year, '/') . '\b/', $evidence)) return false;
        }
        if (preg_match('/\b(?:present|current|now|till\s+date|till\s+now)\b/i', (string) $range['source_end'])) {
            return (bool) preg_match('/\b(?:present|current|now|till\s+date|till\s+now)\b/i', $evidence);
        }
        return true;
    }

    private function extractYear(string $value): ?int
    {
        return preg_match('/\b((?:19|20)\d{2})\b/', $value, $m) ? (int) $m[1] : null;
    }

    private function unionMonths(array $ranges): array
    {
        $months = [];
        foreach ($ranges as $range) {
            $start = (int) ($range['start'] ?? 0);
            $end = (int) ($range['end'] ?? 0);
            if ($start <= 0 || $end < $start) continue;
            // Both endpoints are real resume months; therefore both count.
            for ($month = $start; $month <= $end; $month++) $months[$month] = true;
        }
        return $months;
    }

    private function deduplicateRanges(array $ranges): array
    {
        $seen = [];
        $out = [];
        foreach ($ranges as $range) {
            if (!isset($range['start'], $range['end'])) continue;
            $key = (int) $range['start'] . ':' . (int) $range['end'];
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $out[] = $range;
        }
        return $out;
    }

    private function deduplicateEntries(array $entries): array
    {
        $seen = [];
        $out = [];
        foreach ($entries as $entry) {
            $key = strtolower(trim(
                ($entry['title'] ?? '') . '|' .
                ($entry['company'] ?? '') . '|' .
                ($entry['start_date'] ?? '') . '|' .
                ($entry['end_date'] ?? '')
            ));
            if ($key === '|||') continue;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $out[] = $entry;
        }
        return $out;
    }

    private function evidenceSupported(string $evidence, string $text): bool
    {
        $needle = $this->canonical($evidence);
        $haystack = $this->canonical($text);
        if ($needle !== '' && str_contains($haystack, $needle)) return true;
        $tokens = $this->tokens($needle);
        if (count($tokens) < 3) return false;
        $available = array_flip($this->tokens($haystack));
        $hits = 0;
        foreach ($tokens as $token) if (isset($available[$token])) $hits++;
        return $hits >= max(3, (int) ceil(count($tokens) * 0.75));
    }

    private function rangeLooksProfessional(string $context): bool
    {
        if (preg_match(self::EXCLUDED, $context)) return false;
        return (bool) preg_match(self::PROFESSIONAL_ROLE, $context);
    }

    private function guessTitle(string $context, string $start, string $end): string
    {
        $value = preg_replace('/' . preg_quote($start, '/') . '\s*(?:-|–|—|to|until|through)\s*' . preg_quote($end, '/') . '/i', ' ', $context) ?? $context;
        $value = trim(preg_replace('/\s*\|\s*/', ' ', $value) ?? $value);
        if (preg_match(self::PROFESSIONAL_ROLE, $value, $m, PREG_OFFSET_CAPTURE)) {
            $startPos = max(0, (int) $m[0][1] - 45);
            return trim(mb_substr($value, $startPos, 150));
        }
        return trim(mb_substr($value, 0, 150));
    }

    private function guessCompany(string $context, string $start, string $end): string
    {
        $value = preg_replace('/' . preg_quote($start, '/') . '\s*(?:-|–|—|to|until|through)\s*' . preg_quote($end, '/') . '/i', ' ', $context) ?? $context;
        $parts = array_values(array_filter(array_map('trim', preg_split('/\|/', $value) ?: [])));
        return count($parts) >= 2 ? mb_substr((string) end($parts), 0, 180) : '';
    }

    private function normalizeExplicitTotal(mixed $years, string $evidence, string $text): array
    {
        $numeric = is_numeric($years) ? (float) $years : 0.0;
        $numeric = max(0.0, min(60.0, $numeric));
        $evidence = $this->clean($evidence);
        if ($numeric <= 0 || $evidence === '' || !$this->evidenceSupported($evidence, $text)) {
            return ['years' => 0.0, 'evidence' => ''];
        }
        if (!preg_match('/\b(?:experience|work|industry|professional|relevant)\b/i', $evidence)) {
            return ['years' => 0.0, 'evidence' => ''];
        }
        return ['years' => round($numeric, 1), 'evidence' => $evidence];
    }

    private function extractExplicitTotal(string $text): array
    {
        $patterns = [
            '/\b(?:total|overall|professional|relevant)\s+(?:work\s+)?experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\b/i',
            '/\b(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\s+of\s+(?:professional|work|industry|relevant|corporate)\s+experience\b/i',
            '/\bexperience\s*[:\-]\s*(\d+(?:\.\d+)?)\s*(?:years?|yrs?)\b/i',
            '/\bexperience\s*[:\-]\s*(\d+(?:\.\d+)?)\s*(?:years?|yrs?)\s*(?:and|&)\s*(\d+)\s*(?:months?|mos?)\b/i',
            '/\b(\d+(?:\.\d+)?)\s*(?:years?|yrs?)\s*(?:of\s+)?experience\b/i',
        ];
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $text, $m)) {
                $value = (float) $m[1];
                if ($value > 0 && $value <= 60) return ['years' => round($value, 1), 'evidence' => $m[0]];
            }
        }
        if (preg_match('/\b(\d+(?:\.\d+)?)\s*(?:years?|yrs?)\s*(?:and|&)\s*(\d+)\s*(?:months?|mos?)\s+(?:of\s+)?(?:professional\s+|work\s+|industry\s+|corporate\s+|relevant\s+)?experience\b/i', $text, $m)) {
            return ['years' => round((float) $m[1] + ((int) $m[2] / 12), 1), 'evidence' => $m[0]];
        }
        if (preg_match('/\b(\d+)\s*(?:months?|mos?)\s+(?:of\s+)?(?:professional\s+|work\s+|industry\s+|corporate\s+|relevant\s+)?experience\b/i', $text, $m)) {
            return ['years' => round(((int) $m[1]) / 12, 1), 'evidence' => $m[0]];
        }
        return ['years' => 0.0, 'evidence' => ''];
    }

    private function hasProfessionalEmploymentText(string $text): bool
    {
        $section = $this->experienceSection($text);
        if ($section !== null) {
            $section = preg_replace(self::EXCLUDED, ' ', $section) ?? $section;
            return (bool) preg_match(self::PROFESSIONAL_ROLE, $section);
        }
        // Without an explicit Experience heading, require a strong role marker
        // plus an employment verb. This prevents project/education dates from
        // turning a fresher into an experienced candidate.
        return (bool) preg_match('/\b(?:worked|working|employed|joined|promoted|responsible\s+for|managed|developed|served\s+as)\b.{0,100}' . self::PROFESSIONAL_ROLE . '/is', $text);
    }

    private function looksLikeExperiencedCandidate(string $text): bool
    {
        return $this->hasProfessionalEmploymentText($text) || (bool) preg_match('/\b(?:currently|presently)\s+(?:working|employed)\b/i', $text);
    }

    private function normalize(string $text): string
    {
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', ' ', $text) ?? $text;
        $text = preg_replace('/[ \t]+/u', ' ', $text) ?? $text;
        return trim(preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text);
    }

    private function clean(mixed $value): string
    {
        return trim(preg_replace('/\s+/u', ' ', (string) ($value ?? '')) ?? '');
    }

    private function canonical(string $text): string
    {
        $text = mb_strtoupper($text, 'UTF-8');
        $text = str_replace(['&', '/', '\\', '-', '–', '—', '.', ',', '(', ')', ':', '|', '_'], ' ', $text);
        return trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
    }

    private function tokens(string $text): array
    {
        preg_match_all('/[\p{L}\p{N}]+/u', $text, $m);
        return array_values(array_unique(array_filter($m[0] ?? [], static fn ($v) => mb_strlen($v) >= 3)));
    }
}
