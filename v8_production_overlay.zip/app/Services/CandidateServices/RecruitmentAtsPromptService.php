<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

class RecruitmentAtsPromptService
{
    public function systemInstruction(): string
    {
        return <<<'PROMPT'
You are the semantic evidence stage of a production enterprise ATS.
The backend is the source of truth for applicant identity, education master IDs, employment duration, role IDs, hard requirements and final scoring.
Your job is to compare a supplied candidate resume against ONLY the supplied company role records.

STRICT RULES
1. Never invent a role_id, candidate fact, skill, qualification, employer, date or score evidence.
2. Candidate facts must come from the resume text. Role requirements must come from the supplied role object.
3. Every positive evidence item must be a short verbatim snippet from the candidate resume.
4. Never infer gender, religion, marital status, caste, ethnicity, disability, age, health, or other sensitive attributes from a name, language, photo, location or cultural context.
5. Do not treat projects, coursework, internships, academic work, volunteer work, job advertisements or generic technology lists as professional employment unless the resume clearly states professional employment.
6. Treat missing evidence as unknown, not as present.
7. Do not inflate a match because the role title is similar. Skills, responsibilities, seniority, education and actual employment evidence matter.
8. Return only role IDs present in the supplied role list.
9. The backend recomputes the final ATS score and hard gates. Your numeric component scores are advisory evidence, not the final decision.
10. For a role with sparse requirements, be conservative and explicitly call out that the role master data is incomplete.

COMPONENT SCORES (0-100)
- semantic_fit_score: broad semantic fit of actual candidate evidence to the supplied role.
- title_alignment_score: similarity between actual candidate job titles/designations and role title/aliases.
- skill_alignment_score: supported candidate skills versus supplied mandatory/preferred skills.
- experience_alignment_score: actual professional experience relevance and duration.
- responsibility_alignment_score: overlap between actual work performed and supplied responsibilities.
- seniority_alignment_score: actual scope/leadership/seniority fit.

EVIDENCE
Keep evidence short, exact and directly traceable to the resume. Gaps must state missing or conflicting evidence without guessing.
PROMPT;
    }

    public function buildInput(array $applicants): string
    {
        $compactApplicants = array_map(static fn (array $a): array => [
            'applicant_id' => (string) ($a['sno'] ?? $a['applicant_id'] ?? ''),
            'resume' => (string) ($a['resume'] ?? ''),
            'roles' => array_values($a['roles'] ?? []),
        ], $applicants);

        return "Evaluate every supplied applicant against only the supplied roles. Return one result per applicant.\n\nINPUT_JSON:\n"
            . json_encode($compactApplicants, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    // Kept as a compatibility wrapper for older callers.
    public function buildBatchPrompt(array $applicants, array $roleSets = []): string
    {
        if ($roleSets !== []) {
            foreach ($applicants as $index => $applicant) {
                if (!isset($applicants[$index]['roles'])) {
                    $applicants[$index]['roles'] = $roleSets[$index] ?? [];
                }
            }
        }

        return $this->buildInput($applicants);
    }

    public function schema(): array
    {
        $match = [
            'type' => 'object',
            'properties' => [
                'role_id' => ['type' => 'integer'],
                'semantic_fit_score' => ['type' => 'number'],
                'title_alignment_score' => ['type' => 'number'],
                'skill_alignment_score' => ['type' => 'number'],
                'experience_alignment_score' => ['type' => 'number'],
                'responsibility_alignment_score' => ['type' => 'number'],
                'seniority_alignment_score' => ['type' => 'number'],
                'reason' => ['type' => 'string'],
                'evidence' => ['type' => 'array', 'items' => ['type' => 'string']],
                'gaps' => ['type' => 'array', 'items' => ['type' => 'string']],
            ],
            'required' => [
                'role_id','semantic_fit_score','title_alignment_score','skill_alignment_score',
                'experience_alignment_score','responsibility_alignment_score','seniority_alignment_score',
                'reason','evidence','gaps',
            ],
            'additionalProperties' => false,
        ];

        return [
            'type' => 'object',
            'properties' => [
                'results' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'applicant_id' => ['type' => 'string'],
                            'analysis' => [
                                'type' => 'object',
                                'properties' => [
                                    'candidate_summary' => ['type' => 'string'],
                                    'current_designation' => ['type' => 'string'],
                                    'previous_designations' => ['type' => 'array', 'items' => ['type' => 'string']],
                                    'experience_summary' => ['type' => 'string'],
                                    'education_summary' => ['type' => 'string'],
                                    'seniority_assessment' => ['type' => 'string'],
                                    'data_quality_notes' => ['type' => 'array', 'items' => ['type' => 'string']],
                                    'strengths' => ['type' => 'array', 'items' => ['type' => 'string']],
                                    'weaknesses' => ['type' => 'array', 'items' => ['type' => 'string']],
                                ],
                                'required' => [
                                    'candidate_summary','current_designation','previous_designations','experience_summary',
                                    'education_summary','seniority_assessment','data_quality_notes','strengths','weaknesses',
                                ],
                                'additionalProperties' => false,
                            ],
                            'matches' => ['type' => 'array', 'items' => $match],
                            'near_matches' => ['type' => 'array', 'items' => $match],
                        ],
                        'required' => ['applicant_id','analysis','matches','near_matches'],
                        'additionalProperties' => false,
                    ],
                ],
            ],
            'required' => ['results'],
            'additionalProperties' => false,
        ];
    }
}
