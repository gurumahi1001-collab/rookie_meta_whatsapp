<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

class RecruitmentAtsRoleCatalogService
{
    public function getActiveRoles(): array
    {
        $query = DB::table('egc_recruitment_roles')
            ->where('status', 0)
            ->where('match_enabled', 1);

        // The current role dump has no ai_matching_enabled column. Older
        // deployments may have it, so the filter is applied only when present.
        if (Schema::hasColumn('egc_recruitment_roles', 'ai_matching_enabled')) {
            $query->where(function ($q): void {
                $q->where('ai_matching_enabled', 1)->orWhereNull('ai_matching_enabled');
            });
        }

        $rows = $query->orderBy('sno')->get();
        if ($rows->isEmpty()) return [];

        $ids = $rows->pluck('sno')->map(fn ($v) => (int) $v)->values()->all();
        $aliases = $this->loadRoleAliases($ids);
        $requirements = $this->loadRoleRequirements($ids);
        $legacyRoleDetails = $this->loadLegacyRoleDetails();

        return $rows->map(function ($r) use ($aliases, $requirements, $legacyRoleDetails): array {
            $roleId = (int) $r->sno;
            $profile = $requirements[$roleId] ?? [];
            $legacy = $legacyRoleDetails[$this->canonical((string) ($r->role_name ?? ''))] ?? null;

            $description = $this->clean(
                $profile['description']
                    ?? $profile['role_description']
                    ?? ($r->role_description ?? null)
                    ?? ($r->description ?? null)
            );

            if (($description === '' || $description === $this->clean($r->role_name ?? ''))
                && $legacy
                && !empty($legacy->job_position_desc)
            ) {
                $description = $this->clean($legacy->job_position_desc);
            }

            $mandatory = $profile['mandatory_skills'] ?? $r->mandatory_skills ?? [];
            $preferred = $profile['preferred_skills'] ?? $r->preferred_skills ?? [];
            $responsibilities = $profile['responsibilities'] ?? $r->responsibilities ?? [];
            $education = $profile['education_requirements'] ?? $r->education_requirements ?? [];
            $minimumExperience = trim((string) ($profile['minimum_experience'] ?? $r->minimum_experience ?? ''));
            $seniority = trim((string) ($profile['seniority'] ?? $r->seniority ?? ''));

            return [
                'sno' => $roleId,
                'role_id' => $roleId,
                'role_code' => trim((string) ($r->role_code ?? '')),
                'role_name' => trim((string) ($r->role_name ?? '')),
                'role_family' => trim((string) ($r->role_family ?? '')),
                'seniority_level' => (int) ($r->seniority_level ?? 1),
                'seniority_label' => $this->seniorityLabel((int) ($r->seniority_level ?? 1)),
                'description' => $description ?: $this->clean($r->role_name ?? ''),
                'mandatory_skills' => $this->list($mandatory),
                'preferred_skills' => $this->list($preferred),
                'responsibilities' => $this->list($responsibilities),
                'minimum_experience' => $minimumExperience,
                'education_requirements' => $this->list($education),
                'seniority' => $seniority,
                'aliases' => array_values($aliases[$roleId] ?? []),
                'ai_profile_version' => (int) ($profile['profile_version'] ?? $r->ai_profile_version ?? 1),
                'ai_profile_hash' => trim((string) ($profile['profile_hash'] ?? $r->ai_profile_hash ?? '')),
                'profile_source' => $profile ? 'egc_recruitment_role_requirements' : 'egc_recruitment_roles',
            ];
        })->values()->all();
    }

    public function getCatalogHash(?array $roles = null): string
    {
        $roles ??= $this->getActiveRoles();
        $fingerprint = array_map(static function (array $r): array {
            return [
                'sno' => (int) ($r['sno'] ?? 0),
                'role_code' => (string) ($r['role_code'] ?? ''),
                'role_name' => (string) ($r['role_name'] ?? ''),
                'role_family' => (string) ($r['role_family'] ?? ''),
                'seniority_level' => (int) ($r['seniority_level'] ?? 0),
                'description' => (string) ($r['description'] ?? ''),
                'mandatory_skills' => array_values($r['mandatory_skills'] ?? []),
                'preferred_skills' => array_values($r['preferred_skills'] ?? []),
                'responsibilities' => array_values($r['responsibilities'] ?? []),
                'minimum_experience' => (string) ($r['minimum_experience'] ?? ''),
                'education_requirements' => array_values($r['education_requirements'] ?? []),
                'seniority' => (string) ($r['seniority'] ?? ''),
                'aliases' => array_values($r['aliases'] ?? []),
                'ai_profile_version' => (int) ($r['ai_profile_version'] ?? 1),
            ];
        }, $roles);

        return hash('sha256', json_encode($fingerprint, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]');
    }

    public function toCompactPromptPayload(array $roles): array
    {
        return array_map(static function (array $r): array {
            return [
                'role_id' => (int) $r['sno'],
                'role_code' => $r['role_code'],
                'role_name' => $r['role_name'],
                'family' => $r['role_family'],
                'seniority' => $r['seniority_label'],
                'description' => mb_substr((string) $r['description'], 0, 1800),
                'mandatory_skills' => array_slice($r['mandatory_skills'] ?? [], 0, 40),
                'preferred_skills' => array_slice($r['preferred_skills'] ?? [], 0, 40),
                'responsibilities' => array_slice($r['responsibilities'] ?? [], 0, 25),
                'minimum_experience' => $r['minimum_experience'],
                'education_requirements' => array_slice($r['education_requirements'] ?? [], 0, 15),
                'aliases' => array_slice($r['aliases'] ?? [], 0, 30),
            ];
        }, $roles);
    }

    private function loadRoleAliases(array $ids): array
    {
        $aliases = [];
        if (!$ids || !Schema::hasTable('egc_recruitment_role_aliases')) return $aliases;

        try {
            $rows = DB::table('egc_recruitment_role_aliases')
                ->whereIn('role_sno', $ids)
                ->where('status', 0)
                ->where('match_enabled', 1)
                ->orderBy('sno')
                ->get(['role_sno', 'alias_name']);

            foreach ($rows as $row) {
                $alias = $this->clean($row->alias_name ?? '');
                if ($alias !== '') $aliases[(int) $row->role_sno][] = $alias;
            }
        } catch (Throwable) {
            // Alias data is enrichment; the core role catalogue remains usable.
        }

        return $aliases;
    }

    private function loadRoleRequirements(array $ids): array
    {
        if (!$ids || !Schema::hasTable('egc_recruitment_role_requirements')) return [];

        try {
            $rows = DB::table('egc_recruitment_role_requirements')
                ->whereIn('role_sno', $ids)
                ->where('status', 0)
                ->orderBy('role_sno')
                ->orderByDesc('version_no')
                ->orderByDesc('sno')
                ->get();

            $profiles = [];
            foreach ($rows as $row) {
                $id = (int) ($row->role_sno ?? 0);
                if ($id <= 0 || isset($profiles[$id])) continue;
                $profiles[$id] = [
                    'description' => $this->clean($row->description ?? ''),
                    'mandatory_skills' => $this->list($row->mandatory_skills_json ?? []),
                    'preferred_skills' => $this->list($row->preferred_skills_json ?? []),
                    'responsibilities' => $this->list($row->responsibilities_json ?? []),
                    'minimum_experience' => $this->minimumExperienceLabel($row->minimum_experience_years ?? 0),
                    'education_requirements' => $this->list($row->education_requirements_json ?? []),
                    'seniority' => trim((string) ($row->seniority_level ?? '')),
                    'profile_version' => (int) ($row->version_no ?? 1),
                    'profile_hash' => hash('sha256', json_encode([
                        $row->role_sno ?? null,
                        $row->version_no ?? null,
                        $row->description ?? null,
                        $row->mandatory_skills_json ?? null,
                        $row->preferred_skills_json ?? null,
                        $row->responsibilities_json ?? null,
                        $row->education_requirements_json ?? null,
                        $row->minimum_experience_years ?? null,
                        $row->seniority_level ?? null,
                    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: ''),
                ];
            }
            return $profiles;
        } catch (Throwable) {
            return [];
        }
    }

    private function loadLegacyRoleDetails(): array
    {
        $legacy = [];
        if (!Schema::hasTable('egc_job_role')) return $legacy;

        try {
            return DB::table('egc_job_role')
                ->where('status', '!=', 2)
                ->get(['job_position_name', 'job_position_desc'])
                ->mapWithKeys(function ($r): array {
                    $key = $this->canonical((string) ($r->job_position_name ?? ''));
                    return $key !== '' ? [$key => $r] : [];
                })
                ->all();
        } catch (Throwable) {
            return $legacy;
        }
    }

    private function minimumExperienceLabel(mixed $value): string
    {
        $years = max(0.0, (float) ($value ?? 0));
        return $years > 0 ? rtrim(rtrim(number_format($years, 2, '.', ''), '0'), '.') . '+ years' : '';
    }

    private function list(mixed $value): array
    {
        if (is_array($value)) {
            return array_values(array_filter(array_map(fn ($v) => $this->clean($v), $value)));
        }

        $value = trim((string) ($value ?? ''));
        if ($value === '') return [];

        $decoded = json_decode($value, true);
        if (is_array($decoded)) {
            return array_values(array_filter(array_map(fn ($v) => $this->clean($v), $decoded)));
        }

        return array_values(array_filter(array_map(
            fn ($v) => $this->clean($v),
            preg_split('/[,;\n]+/', $value) ?: []
        )));
    }

    private function clean(mixed $v): string
    {
        $v = strip_tags((string) ($v ?? ''));
        return trim(preg_replace('/\s+/u', ' ', $v) ?? $v);
    }

    private function canonical(string $value): string
    {
        $value = mb_strtolower(trim($value), 'UTF-8');
        $value = str_replace(['&', '/', '-', '_', '.', '(', ')', ',', ':'], ' ', $value);
        return trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
    }

    private function seniorityLabel(int $value): string
    {
        return match ($value) {
            1 => 'Entry',
            2 => 'Senior',
            3 => 'Team Lead',
            4 => 'Manager',
            5 => 'Head',
            default => 'Entry',
        };
    }
}
