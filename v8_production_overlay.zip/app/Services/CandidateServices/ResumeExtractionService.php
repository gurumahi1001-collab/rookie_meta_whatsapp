<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

/**
 * Production resume extraction orchestrator.
 *
 * Design goal: never let a plausible LLM guess become source-of-truth data.
 * Every populated field is either deterministic source extraction or AI output
 * corroborated by text/evidence from the actual resume.
 */
class ResumeExtractionService
{
    public function __construct(
        protected RecruitmentDocumentTextExtractor $documents,
        protected RecruitmentHuggingFaceService $huggingFace,
        protected RecruitmentEducationCatalogService $educationCatalog,
        protected RecruitmentExperienceResolver $experienceResolver
    ) {
    }

    public function extract(UploadedFile $file, bool $includeText = false): array
    {
        $started = microtime(true);
        $document = $this->documents->extractUploadedFile($file);
        return $this->extractText(
            $document['text'],
            [
                'extension' => $document['extension'],
                'ocr_used' => (bool) $document['ocr_used'],
                'original_name' => $file->getClientOriginalName(),
                'bytes' => $document['bytes'],
            ],
            $includeText,
            $started
        );
    }

    public function extractFromPath(string $path, ?string $originalName = null, bool $includeText = false): array
    {
        $started = microtime(true);
        $document = $this->documents->extractFile($path, $originalName ?: $path);
        return $this->extractText(
            $document['text'],
            [
                'extension' => $document['extension'],
                'ocr_used' => (bool) $document['ocr_used'],
                'original_name' => $originalName ?: basename($path),
                'bytes' => $document['bytes'],
            ],
            $includeText,
            $started
        );
    }

    /**
     * Parse already-extracted resume text. Used by ATS and by stored resume
     * records, so every pipeline has exactly the same extraction semantics.
     */
    public function extractText(string $text, array $documentMeta = [], bool $includeText = false, ?float $started = null): array
    {
        $started ??= microtime(true);
        $text = $this->documents->normalize($text);
        if (mb_strlen($text) < 20) {
            throw new RuntimeException('The resume contains insufficient readable text.');
        }

        $local = $this->localExtract($text);
        $ai = [];
        $aiAttempted = false;
        $aiVerified = false;
        $aiErrors = [];
        $token = $this->huggingFace->token();

        if ($token && filter_var(config('recruitment_ats.resume_ai_enabled', true), FILTER_VALIDATE_BOOLEAN)) {
            $aiAttempted = true;
            $primary = $this->extractWithAI($text, $this->primarySchema(), (string) config('recruitment_ats.resume_primary_model'));
            if ($primary['status']) {
                $ai = $primary['data'];

                // A second independent model pass is deliberately used for Add
                // Candidate extraction. It is cheaper to review one record now
                // than to create a wrong candidate that contaminates ATS results.
                if (filter_var(config('recruitment_ats.resume_verification_enabled', true), FILTER_VALIDATE_BOOLEAN)) {
                    $verification = $this->verifyWithAI(
                        $text,
                        $ai,
                        $this->primarySchema(),
                        (string) config('recruitment_ats.resume_verifier_model')
                    );
                    if ($verification['status']) {
                        $ai = $verification['data'];
                        $aiVerified = true;
                    } else {
                        $aiErrors[] = $verification['message'] ?? 'AI verification failed.';
                    }
                }
            } else {
                $aiErrors[] = $primary['message'] ?? 'Primary AI extraction failed.';
            }
        }

        $data = $this->buildCandidateData($text, $local, $ai);
        $meta = $this->buildMeta($documentMeta, $data, $aiAttempted, $aiVerified, $aiErrors, $started, $ai);
        $meta['text_length'] = mb_strlen($text);
        $data['confidence'] = $this->overallConfidence($data);
        $data['extraction_meta'] = $meta;
        if ($includeText) $data['resume_text'] = $text;

        return $data;
    }

    private function buildCandidateData(string $text, array $local, array $ai): array
    {
        $identity = is_array($ai['identity'] ?? null) ? $ai['identity'] : [];

        $name = $local['candidate_name'] ?: null;
        if (!$name) {
            $aiName = $this->cleanName((string) ($identity['name'] ?? ''));
            $evidence = (string) ($identity['name_evidence'] ?? '');
            if ($aiName && $evidence !== '' && $this->evidenceSupports($aiName, $evidence, $text, 'name')) {
                $name = $aiName;
            }
        }

        $email = $local['candidate_email'];
        if (!$email) {
            $aiEmail = strtolower(trim((string) ($identity['email'] ?? '')));
            $evidence = (string) ($identity['email_evidence'] ?? '');
            if ($aiEmail && filter_var($aiEmail, FILTER_VALIDATE_EMAIL) && $evidence !== '' && $this->evidenceSupports($aiEmail, $evidence, $text, 'email')) {
                $email = $aiEmail;
            }
        }

        $mobile = $local['candidate_mobile'];
        if (!$mobile) {
            $mobile = $this->cleanPhone((string) ($identity['phone'] ?? ''));
            $evidence = (string) ($identity['phone_evidence'] ?? '');
            if (!$mobile || $evidence === '' || !$this->evidenceSupports($mobile, $evidence, $text, 'mobile')) {
                $mobile = null;
            }
        }

        // Gender is intentionally never inferred from the candidate's name,
        // religion, photo, pronouns or cultural signals. Only an explicit
        // Gender/Sex field from the source is accepted.
        $gender = $local['candidate_gender'];
        if ($gender === null && $this->explicitAiFieldSupported($ai, 'gender', $text)) {
            $gender = $this->explicitGenderFromText($text);
        }

        $marital = $local['candidate_marital_status'];
        if ($marital === null && $this->explicitAiFieldSupported($ai, 'marital_status', $text)) {
            $marital = $this->explicitMaritalFromText($text);
        }

        $localEducation = [
            'degree_full' => $local['degree_full'] ?? '',
            'major_text' => $local['candidate_major_text'] ?? '',
        ];
        $education = $this->educationCatalog->resolve(
            $text,
            is_array($ai['education'] ?? null) ? $ai['education'] : [],
            $localEducation
        );

        $experience = $this->experienceResolver->resolve(
            $text,
            is_array($ai['employment'] ?? null) ? $ai['employment'] : [],
            $ai['explicit_total_experience_years'] ?? null,
            (string) ($ai['explicit_total_experience_evidence'] ?? '')
        );

        $skills = $this->stringArray($ai['skills'] ?? []);
        $experienceYears = (float) ($experience['years'] ?? 0);
        $hasQualification = !empty($education['qualification_sno']);
        $hasMajor = !empty($education['major_sno']);

        $data = [
            'candidate_name' => $name,
            'candidate_email' => $email,
            'candidate_mobile' => $mobile,
            'candidate_gender' => $gender,
            'candidate_marital_status' => $marital,
            'candidate_qualification' => $education['qualification_sno'] ?? null,
            'candidate_major' => $education['major_sno'] ?? null,
            'candidate_major_text' => $education['major_text'] ?? null,
            'candidate_other_major' => $hasMajor ? null : (($education['major_text'] ?? '') ?: null),
            'candidate_other_qualification' => $hasQualification ? null : (($education['degree_full'] ?? '') ?: null),
            'degree_full' => $education['degree_full'] ?? null,
            'education_entries' => $education['entries'] ?? [],
            'education_resolution_status' => $education['resolution_status'] ?? 'not_found',
            'education_candidates' => $education['candidates'] ?? [],
            'employment_entries' => $experience['entries'] ?? [],
            'candidate_exper_count' => $experienceYears,
            'candidate_exper_type' => (int) ($experience['type'] ?? ($experienceYears > 0 ? 2 : 1)),
            'experience_months' => (int) ($experience['months'] ?? 0),
            'experience_source' => (string) ($experience['source'] ?? 'none'),
            'experience_review_fields' => $experience['review_fields'] ?? [],
            'skills' => $skills,
            'experience_evidence' => $experience['evidence'] ?? [],
            'field_evidence' => [
                'candidate_name' => $this->fieldEvidence($name, (string) ($identity['name_evidence'] ?? ''), $text),
                'candidate_email' => $this->fieldEvidence($email, $email ?: (string) ($identity['email_evidence'] ?? ''), $text),
                'candidate_mobile' => $this->fieldEvidence($mobile, $mobile ?: (string) ($identity['phone_evidence'] ?? ''), $text),
                'candidate_gender' => $this->fieldEvidence($gender, $this->explicitLabelEvidence($text, ['gender', 'sex']), $text),
                'candidate_marital_status' => $this->fieldEvidence($marital, $this->explicitLabelEvidence($text, ['marital status', 'marital']), $text),
                'qualification' => $this->fieldEvidence((string) ($education['degree_full'] ?? ''), (string) ($education['evidence'] ?? ''), $text),
                'major' => $this->fieldEvidence((string) ($education['major_text'] ?? ''), (string) ($education['major_evidence'] ?? ''), $text),
                'experience' => $this->fieldEvidence((string) $experienceYears, implode(' | ', $experience['evidence'] ?? []), $text),
            ],
        ];

        $data['field_confidence'] = $this->fieldConfidence($data, $education, $text);
        $data['manual_review_fields'] = $this->manualReviewFields($data, $education);
        return $data;
    }

    private function primarySchema(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'identity' => [
                    'type' => 'object',
                    'properties' => [
                        'name' => ['type' => 'string'],
                        'name_evidence' => ['type' => 'string'],
                        'email' => ['type' => 'string'],
                        'email_evidence' => ['type' => 'string'],
                        'phone' => ['type' => 'string'],
                        'phone_evidence' => ['type' => 'string'],
                        'gender' => ['type' => 'string'],
                        'gender_evidence' => ['type' => 'string'],
                        'marital_status' => ['type' => 'string'],
                        'marital_status_evidence' => ['type' => 'string'],
                    ],
                    'required' => ['name','name_evidence','email','email_evidence','phone','phone_evidence','gender','gender_evidence','marital_status','marital_status_evidence'],
                    'additionalProperties' => false,
                ],
                'education' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'degree_title' => ['type' => 'string'],
                            'qualification_level' => ['type' => 'string'],
                            'major' => ['type' => 'string'],
                            'institution' => ['type' => 'string'],
                            'year' => ['type' => 'string'],
                            'evidence' => ['type' => 'string'],
                        ],
                        'required' => ['degree_title','qualification_level','major','institution','year','evidence'],
                        'additionalProperties' => false,
                    ],
                ],
                'employment' => [
                    'type' => 'array',
                    'items' => [
                        'type' => 'object',
                        'properties' => [
                            'title' => ['type' => 'string'],
                            'company' => ['type' => 'string'],
                            'start_date' => ['type' => 'string'],
                            'end_date' => ['type' => 'string'],
                            'employment_type' => ['type' => 'string'],
                            'is_professional' => ['type' => 'boolean'],
                            'evidence' => ['type' => 'string'],
                        ],
                        'required' => ['title','company','start_date','end_date','employment_type','is_professional','evidence'],
                        'additionalProperties' => false,
                    ],
                ],
                'explicit_total_experience_years' => ['type' => 'number'],
                'explicit_total_experience_evidence' => ['type' => 'string'],
                'skills' => [
                    'type' => 'array',
                    'items' => ['type' => 'string'],
                ],
                'notes' => ['type' => 'string'],
            ],
            'required' => ['identity','education','employment','explicit_total_experience_years','explicit_total_experience_evidence','skills','notes'],
            'additionalProperties' => false,
        ];
    }

    private function extractionSystemPrompt(): string
    {
        return <<<'PROMPT'
You are a production-grade HR resume extraction and verification engine.
The supplied text is the source of truth. Extract only facts actually supported by it.
Never guess, infer, complete, or hallucinate a missing field.

IDENTITY
- name: candidate's own name from the header/contact identity area. Never use a company, recruiter, reference, emergency contact, author or job title.
- email/phone: candidate contact only. Never invent or copy a recruiter/reference/emergency contact.
- gender/marital_status: only when explicitly labelled in the source. Do not infer from name, pronouns, photo or culture.
- Every non-empty identity value needs a short VERBATIM evidence snippet from the resume.

EDUCATION
- Extract every clearly stated education entry that belongs to the candidate.
- qualification_level must be one of UG, PG, Doctorate, HSC, SSLC, Below SSLC, Diploma, or empty when unclear.
- major must be the explicit specialization, not a job title.
- Evidence must be verbatim.

EMPLOYMENT
- Extract only the candidate's own employment history.
- Do not treat job-ad text, required-experience statements, education, projects, coursework, volunteer work, or training as employment.
- Mark is_professional=false for internships/trainee/apprentice/volunteer/student/academic roles unless the resume explicitly presents them as professional paid employment.
- Preserve each date exactly enough to reconstruct duration; use Present/Current when explicitly shown.
- Preserve evidence verbatim.

EXPERIENCE
- explicit_total_experience_years is valid only when the resume explicitly states a total/overall/professional/relevant experience value.
- Never use arbitrary numbers from the resume.
- The backend will calculate overlapping employment periods itself.

SKILLS
- Extract explicit technologies, tools, platforms, methodologies and functional skills stated by the candidate.
- Do not copy skills from job descriptions or advertisements unrelated to candidate experience.

Return ONLY the requested JSON object.
PROMPT;
    }

    private function extractWithAI(string $text, array $schema, string $model): array
    {
        $context = $this->buildModelContext($text);
        return $this->huggingFace->structured([
            ['role' => 'system', 'content' => $this->extractionSystemPrompt()],
            ['role' => 'user', 'content' => "RESUME SOURCE TEXT:\n" . $context],
        ], $schema, $model, (int) config('recruitment_ats.resume_primary_timeout', 80));
    }

    private function verifyWithAI(string $text, array $initial, array $schema, string $model): array
    {
        $verificationPrompt = <<<'PROMPT'
You are the second-pass verifier for HR resume extraction.
Review the proposed extraction against the resume text.
Correct only fields that are directly supported by the source. Remove unsupported guesses.
For every non-empty name/contact/education/employment field, evidence must be a verbatim snippet from the source.
Gender and marital status remain empty unless the source explicitly labels them.
Do not calculate experience from education/projects. Keep only defensible professional employment entries.
Return the corrected object in the exact requested JSON schema and nothing else.
PROMPT;

        return $this->huggingFace->structured([
            ['role' => 'system', 'content' => $verificationPrompt],
            ['role' => 'user', 'content' => "SOURCE RESUME:\n" . $this->buildModelContext($text) . "\n\nPRIMARY EXTRACTION:\n" . json_encode($initial, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)],
        ], $schema, $model, (int) config('recruitment_ats.resume_verify_timeout', 55));
    }

    private function buildModelContext(string $text): string
    {
        $max = max(12000, (int) config('recruitment_ats.resume_model_max_chars', 60000));
        if (mb_strlen($text) <= $max) return $text;

        $sections = [
            'SUMMARY|PROFILE|OBJECTIVE',
            'WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY|EXPERIENCE',
            'EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS',
            'SKILLS|TECHNICAL\s+SKILLS|CORE\s+SKILLS|KEY\s+SKILLS',
            'PROJECTS|KEY\s+PROJECTS',
            'CERTIFICATIONS?|CERTIFICATES',
            'PERSONAL\s+DETAILS|CONTACT',
        ];

        $chunks = [mb_substr($text, 0, 12000)];
        foreach ($sections as $sectionPattern) {
            $pattern = '/\b(?:' . $sectionPattern . ')\b.*?(?=\n\s*\n|\b(?:WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|EDUCATION|ACADEMIC\s+QUALIFICATIONS?|SKILLS|TECHNICAL\s+SKILLS|PROJECTS|CERTIFICATIONS?|PERSONAL\s+DETAILS|REFERENCES)\b|$)/is';
            if (preg_match($pattern, $text, $m)) $chunks[] = mb_substr(trim($m[0]), 0, 14000);
        }
        $chunks[] = mb_substr($text, -6000);

        $unique=[];
        foreach ($chunks as $chunk) {
            $chunk=trim($chunk);
            if ($chunk!=='') $unique[$chunk]=true;
        }
        $out=implode("\n\n--- RESUME SECTION ---\n\n", array_keys($unique));
        return mb_strlen($out) > $max ? mb_substr($out, 0, $max) : $out;
    }

    private function localExtract(string $text): array
    {
        $email = $this->extractEmail($text);
        $phone = $this->extractPhone($text);
        $name = $this->extractName($text, $email, $phone);
        $education = $this->extractEducationText($text);
        return [
            'candidate_name' => $name,
            'candidate_email' => $email,
            'candidate_mobile' => $phone,
            'candidate_gender' => $this->explicitGenderFromText($text),
            'candidate_marital_status' => $this->explicitMaritalFromText($text),
            'candidate_major_text' => $education['major_text'],
            'degree_full' => $education['degree_full'],
            'candidate_exper_count' => $this->extractExplicitOrDateExperience($text),
        ];
    }

    private function extractName(string $text, ?string $email, ?string $phone): ?string
    {
        $header = mb_substr($text, 0, 5000);
        $lines = preg_split('/\R+/u', $header) ?: [];
        $blocked = '/\b(?:resume|curriculum\s+vitae|cv|profile|summary|objective|experience|education|skills|projects?|certifications?|linkedin|github|email|phone|mobile|contact|address|developer|engineer|manager|executive|recruiter|human\s+resources|hr|director|consultant|analyst|specialist|architect|administrator|designer|stack|software|technical|company|inc|ltd|limited|private|pvt|gender|sex|dob|date\s+of\s+birth|nationality|marital|father|mother|reference|references)\b/i';

        for ($i = 0, $count = count($lines); $i < min(45, $count); $i++) {
            $line = trim(preg_replace('/\s+/u', ' ', (string) $lines[$i]) ?? '');
            if ($line === '') continue;

            // Strongest source: an explicit Name / Full Name field.
            if (preg_match('/^(?:full\s+name|candidate\s+name|candidate|applicant\s+name|name)\s*(?:[:\-]|\s+is\s+)\s*(.+)$/iu', $line, $m)) {
                $candidate = $this->cleanName($this->stripNameSuffix((string) $m[1]));
                if ($candidate) return $candidate;
            }
            if (preg_match('/^(?:full\s+name|candidate\s+name|candidate|applicant\s+name|name)\s*$/iu', $line) && isset($lines[$i + 1])) {
                $candidate = $this->cleanName((string) $lines[$i + 1]);
                if ($candidate) return $candidate;
            }
        }

        // Common visual-header variants: "Resume of John Doe" / "CV - John Doe".
        if (preg_match('/\b(?:resume|cv|curriculum\s+vitae)\s*(?:of|for)?\s*[:\-]\s*([\p{L}][\p{L}\.\'\-]*(?:\s+[\p{L}][\p{L}\.\'\-]*){1,5})\b/iu', $header, $m)) {
            $candidate = $this->cleanName($m[1]);
            if ($candidate) return $candidate;
        }

        // Common ATS-export variant: name followed by a job title on the same line.
        // Example: "John Doe | Senior Software Engineer". Keep only the identity part.
        foreach (array_slice($lines, 0, 18) as $rawLine) {
            $line = trim(preg_replace('/\s+/u', ' ', (string) $rawLine) ?? '');
            if ($line === '' || preg_match('/[@\d]|https?:\/\//iu', $line)) continue;
            // Strip a same-line role/designation before deciding whether the
            // remaining identity text is blocked. This fixes common headers such
            // as "ALAGU AKILAN - Full Stack Developer".
            $identityPart = trim($this->stripNameSuffix($line));
            if ($identityPart === '' || preg_match($blocked, $identityPart)) continue;
            $candidate = $this->cleanName($identityPart);
            if ($candidate && $this->looksLikeName($candidate)) return $candidate;
        }

        // Final deterministic header scan. The first matching line is not enough
        // by itself; reject contact/noise lines and prefer lines close to the top.
        $best = null;
        $bestScore = -INF;
        foreach (array_slice($lines, 0, 25) as $index => $rawLine) {
            $line = trim(preg_replace('/\s+/u', ' ', (string) $rawLine) ?? '');
            if ($line === '' || preg_match($blocked, $line) || preg_match('/[@\d]|https?:\/\//iu', $line)) continue;
            if ($email) $line = str_ireplace($email, ' ', $line);
            if ($phone) $line = preg_replace('/(?:\+?91[\s\-()]*)?[6-9](?:[\s\-()]?\d){9}\b/u', ' ', $line) ?? $line;
            $line = trim(preg_replace('/\s+/u', ' ', $line) ?? $line, "|,;:.- ");
            if (!$this->looksLikeName($line)) continue;

            $score = 50 - ($index * 2);
            if (preg_match('/^[\p{Lu}\s\.\'\-]+$/u', $line)) $score += 8;
            if (count(preg_split('/\s+/u', $line) ?: []) <= 4) $score += 4;
            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $line;
            }
        }
        return $best;
    }

    private function stripNameSuffix(string $value): string
    {
        $value = trim($value);
        $value = preg_split('/\s*(?:\||•)\s*/u', $value, 2)[0] ?? $value;
        $value = preg_replace('/\s+[\-–—]\s+(?:mr|mrs|ms|miss|dr|prof)?\s*(?:developer|engineer|software|full\s+stack|frontend|front\s*end|backend|back\s*end|manager|analyst|designer|consultant|executive|administrator|architect|recruiter|specialist|officer|associate|director|team\s+lead|project\s+manager|human\s+resources|hr)\b.*$/iu', '', $value) ?? $value;
        return trim($value, " |•,;:");
    }

    private function looksLikeName(string $value): bool
    {
        $words=preg_split('/\s+/u',trim($value))?:[];
        if (count($words)<1 || count($words)>6 || mb_strlen($value)<2 || mb_strlen($value)>100) return false;
        foreach ($words as $word) if (!preg_match('/^\p{L}[\p{L}.\'\-]*$/u',$word)) return false;
        if (preg_match('/\b(?:resume|cv|curriculum|profile|summary|objective|experience|education|skills|projects?|certifications?|contact|reference|references)\b/i', $value)) return false;
        return true;
    }

    private function extractEmail(string $text): ?string
    {
        preg_match_all('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i',$text,$m,PREG_OFFSET_CAPTURE);
        $best=null;$scoreBest=-INF;
        foreach ($m[0]??[] as $hit){
            $email=strtolower(trim((string)$hit[0]));
            if (!filter_var($email,FILTER_VALIDATE_EMAIL) || str_contains($email,'example.')) continue;
            $context=strtolower(substr($text,max(0,(int)$hit[1]-180),360));$score=0;
            if (preg_match('/\b(email|e-mail|mail|contact|personal)\b/',$context)) $score+=20;
            if (preg_match('/\b(recruiter|hr|reference|referee|emergency|manager|company|support|info|admin)\b/',$context)) $score-=25;
            if ((int)$hit[1]<1800) $score+=8;
            if ($score>$scoreBest){$scoreBest=$score;$best=$email;}
        }
        return $best;
    }

    private function extractPhone(string $text): ?string
    {
        preg_match_all('/(?:\+?91[\s\-()]*)?[6-9](?:[\s\-()]?\d){9}\b/',$text,$m,PREG_OFFSET_CAPTURE);
        $best=null;$scoreBest=-INF;
        foreach ($m[0]??[] as $hit){
            $raw=(string)$hit[0];$phone=$this->cleanPhone($raw); if (!$phone) continue;
            $context=strtolower(substr($text,max(0,(int)$hit[1]-200),400));$score=5;
            if (preg_match('/\b(mobile|phone|contact|tel|telephone|cell|whatsapp)\b/',$context)) $score+=20;
            if (preg_match('/\b(emergency|reference|referee|parent|father|mother|recruiter|hr|manager)\b/',$context)) $score-=35;
            if ((int)$hit[1]<1800) $score+=8;
            if ($score>$scoreBest){$scoreBest=$score;$best=$phone;}
        }
        return $best;
    }

    private function cleanPhone(?string $value): ?string
    {
        if (!$value) return null;
        $digits=preg_replace('/\D+/','',(string)$value);
        if (str_starts_with($digits,'0091')) $digits=substr($digits,4);
        if (strlen($digits)===12 && str_starts_with($digits,'91')) $digits=substr($digits,2);
        return preg_match('/^[6-9]\d{9}$/',$digits)?$digits:null;
    }

    private function extractExplicitGender(string $text): ?int
    {
        $patterns = [
            '/(?:^|[\n|;])\s*(?:gender|sex)\s*(?:[:\-=]|\s+is\s+)\s*(female|f)\b/i',
            '/(?:^|[\n|;])\s*(?:gender|sex)\s*(?:[:\-=]|\s+is\s+)\s*(male|m)\b/i',
        ];
        if (preg_match($patterns[0], $text)) return 2;
        if (preg_match($patterns[1], $text)) return 1;
        return null;
    }

    private function explicitGenderFromText(string $text): ?int
    {
        return $this->extractExplicitGender($text);
    }

    private function extractExplicitMarital(string $text): ?int
    {
        if (preg_match('/\b(?:marital\s+status|marital)\s*[:\-]\s*(married)\b/i',$text)) return 1;
        if (preg_match('/\b(?:marital\s+status|marital)\s*[:\-]\s*(single|unmarried|not\s+married)\b/i',$text)) return 2;
        return null;
    }

    private function explicitMaritalFromText(string $text): ?int
    {
        return $this->extractExplicitMarital($text);
    }

    private function extractEducationText(string $text): array
    {
        $section=$text;
        if (preg_match('/\b(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS?)\b(.*?)(?=\b(?:WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|PROJECTS?|CERTIFICATIONS?|SKILLS|TECHNICAL\s+SKILLS|PERSONAL\s+DETAILS|REFERENCES)\b|$)/is',$text,$m)) $section=$m[1];
        $degreeFull=null;$major=null;
        $patterns=[
            '/\b((?:Bachelor|Master|Doctor|Diploma|Higher\s+Secondary|Secondary|B\.?\s*(?:Tech|E|Sc|CA|Com|A|BA|BBA|BCA)|M\.?\s*(?:Tech|E|Sc|CA|Com|A|MA)|MBA|MCA|M\.?\s*Com|B\.?\s*Com|Ph\.?D)\b[^\n|]{0,140})/i',
            '/\b((?:B\.?\s*Tech|B\.?\s*E|M\.?\s*Tech|M\.?\s*E|B\.?\s*Sc|M\.?\s*Sc|B\.?\s*Com|M\.?\s*Com|BCA|MCA|MBA|BBA|Ph\.?D)[^\n|]{0,120})/i'
        ];
        foreach($patterns as $pattern){if(preg_match($pattern,$section,$m)){ $degreeFull=trim(preg_replace('/\s+/u',' ',$m[1])??$m[1]); break; }}
        if ($degreeFull) {
            if (preg_match('/\b(?:in|with|speciali[sz]ation\s+in|major\s+in)\s+([A-Za-z][A-Za-z &\/.-]{2,100})/i',$degreeFull,$m)) {
                $major=trim($m[1]);
            } else {
                $major=$degreeFull;
                $major=preg_replace('/^\s*(?:Bachelor|Master|Doctor|Diploma|B\.?\s*(?:Tech|E|Sc|CA|Com|A|BA|BBA|BCA)|M\.?\s*(?:Tech|E|Sc|CA|Com|A|MA)|MBA|MCA|B\.?\s*Com|M\.?\s*Com|Ph\.?D)\b\s*(?:of\s+)?(?:Science|Engineering|Technology|Commerce|Arts)?\s*/i','',$major) ?? $major;
                $major=preg_replace('/[,\-]?\s*\b(?:19|20)\d{2}\b\s*$/','',$major) ?? $major;
                $major=trim($major,' ,;-');
            }
        }
        return ['degree_full'=>$degreeFull,'major_text'=>$major];
    }

    private function resolveEducation(string $text, array $ai): array
    {
        try {
            $levels=DB::table('egc_qualification_level')->where('status',0)->get(['sno','qualification_level_name','description']);
            $majors=DB::table('egc_major')->where('status',0)->get(['sno','qualification_id','major_name','description']);
        } catch(Throwable $e){
            $levels=collect();$majors=collect();
        }

        $entries=is_array($ai['education']??null)?$ai['education']:[];
        $entries=array_values(array_filter($entries,function($e)use($text){
            return is_array($e) && trim((string)($e['evidence']??''))!=='' && $this->evidenceSupports('',(string)$e['evidence'],$text,'education');
        }));
        $local=$this->extractEducationText($text);
        if (!$entries && ($local['degree_full']||$local['major_text'])) {
            $entries=[['degree_title'=>$local['degree_full']??'','qualification_level'=>'','major'=>$local['major_text']??'','institution'=>'','year'=>'','evidence'=>$local['degree_full']??'']];
        }
        $chosen=null;
        usort($entries,function($a,$b){return $this->degreeRank((string)($b['qualification_level']??'').' '.(string)($b['degree_title']??'')) <=> $this->degreeRank((string)($a['qualification_level']??'').' '.(string)($a['degree_title']??''));});
        $chosen=$entries[0]??null;
        $degree=(string)($chosen['degree_title']??$local['degree_full']??'');
        $majorText=trim((string)($chosen['major']??$local['major_text']??''));
        $evidence=(string)($chosen['evidence']??$degree);

        $best=null;$bestScore=0.0;
        foreach($majors as $major){
            $name=$this->canonical((string)$major->major_name);$desc=$this->canonical((string)($major->description??''));$target=$this->canonical($majorText?:$degree);
            if($name===''||$target==='')continue;
            $score=$this->majorSimilarity($target,$name,$desc);
            if($score>$bestScore){$bestScore=$score;$best=$major;}
        }

        $qualificationId=null;
        $level=$this->qualificationBucket($degree.' '.($chosen['qualification_level']??''));
        if ($level !== null) {
            foreach($levels as $row){
                if(strtoupper(trim((string)$row->qualification_level_name))===strtoupper($level)){
                    $qualificationId=(int)$row->sno;
                    break;
                }
            }
        }
        if(!$qualificationId && $best && $bestScore>=0.90){ $qualificationId=(int)$best->qualification_id; }
        $mappedMajor=($best && $bestScore>=0.90)?(int)$best->sno:null;
        return [
            'qualification_sno'=>$qualificationId,
            'major_sno'=>$mappedMajor,
            'major_text'=>$majorText ?: null,
            'degree_full'=>$degree ?: null,
            'major_score'=>round($bestScore*100),
            'evidence'=>$evidence,
            'major_evidence'=>$chosen['evidence']??$majorText,
            'entries'=>$entries,
        ];
    }

    private function degreeRank(string $value): int
    {
        $u=$this->canonical($value);
        return match(true){
            preg_match('/\bPHD\b|DOCTORATE|DOCTOR OF PHILOSOPHY/',$u)=>70,
            preg_match('/\bMASTER\b|M TECH|MTECH|M E|ME|M SC|MSC|MBA|MCA|M COM|M A/',$u)=>60,
            preg_match('/\bBACHELOR\b|B TECH|BTECH|B E|BE|B SC|BSC|BCA|BCOM|B COM|B A|BA|BBA|MBBS|B PHARM|B ARCH|B ED/',$u)=>50,
            str_contains($u,'DIPLOMA')=>40,
            str_contains($u,'HSC')=>20,
            str_contains($u,'SSLC')=>10,
            default=>0,
        };
    }

    private function qualificationBucket(string $value): ?string
    {
        $u=$this->canonical($value);
        if(preg_match('/\bPHD\b|DOCTORATE|DOCTOR OF PHILOSOPHY/',$u)) return 'Doctorate';
        if(preg_match('/\bMASTER\b|M TECH|MTECH|M E|ME|M SC|MSC|MBA|MCA|M COM|M A/',$u)) return 'PG';
        if(str_contains($u,'DIPLOMA')) return 'Diploma';
        if(preg_match('/\bBACHELOR\b|B TECH|BTECH|B E|BE|B SC|BSC|BCA|BCOM|B COM|B A|BA|BBA|MBBS|B PHARM|B ARCH|B ED/',$u)) return 'UG';
        if(str_contains($u,'HSC')) return 'HSC';
        if(str_contains($u,'SSLC')) return 'SSLC';
        return null;
    }

    private function majorSimilarity(string $target,string $name,string $description): float
    {
        if($target===''||$name==='')return 0;
        if($target===$name||str_contains($target,$name)||str_contains($name,$target))return 1.0;
        $tw=array_values(array_filter(explode(' ',$target)));$nw=array_values(array_filter(explode(' ',$name)));$dw=array_values(array_filter(explode(' ',$description)));
        $generic=['B','BE','BTECH','BACHELOR','M','ME','MTECH','MASTER','OF','IN','THE','ENGINEERING','TECHNOLOGY'];
        $tw=array_values(array_diff($tw,$generic));$nw=array_values(array_diff($nw,$generic));$dw=array_values(array_diff($dw,$generic));
        if(!$tw||!$nw)return 0;
        $common=count(array_intersect($tw,$nw));$nameCoverage=$common/count($nw);$targetCoverage=$common/count($tw);
        $descCommon=count(array_intersect($tw,$dw));$descCoverage=$descCommon/max(1,count($tw));
        return max(($nameCoverage*0.70)+($targetCoverage*0.30),$descCoverage*0.85);
    }

    private function validatedExperienceEntries(string $text,array $ai): array
    {
        $out=[];
        foreach((array)($ai['employment']??[]) as $entry){
            if(!is_array($entry))continue;
            $evidence=trim((string)($entry['evidence']??''));
            $title=trim((string)($entry['title']??''));$company=trim((string)($entry['company']??''));
            $type=strtolower(trim((string)($entry['employment_type']??'')));
            $professional=(bool)($entry['is_professional']??false);
            $block=$title.' '.$company.' '.$type;
            if($evidence===''||!$this->evidenceSupports('', $evidence,$text,'employment'))continue;
            if(!$professional || preg_match('/\b(intern(ship)?|trainee|apprentice|volunteer|student|academic|coursework|training)\b/i',$block)) continue;
            $out[]=[
                'title'=>$title,
                'company'=>$company,
                'start_date'=>trim((string)($entry['start_date']??'')),
                'end_date'=>trim((string)($entry['end_date']??'')),
                'employment_type'=>$type,
                'evidence'=>$evidence,
            ];
        }
        return $out;
    }

    private function calculateExperienceYears(string $text,array $entries,array $ai): float
    {
        $ranges=[];
        foreach($entries as $entry){
            $start=$this->parseMonth((string)$entry['start_date']);$end=$this->parseMonth((string)$entry['end_date']);
            if($start===null||$end===null||$end<$start)continue;
            if(!$this->dateAppearsInEvidence((string)$entry['start_date'],(string)$entry['evidence'],$text))continue;
            if(!$this->dateAppearsInEvidence((string)$entry['end_date'],(string)$entry['evidence'],$text))continue;
            $ranges[]=[$start,$end];
        }
        $months=[];
        foreach($ranges as [$start,$end])for($m=$start;$m<$end;$m++)$months[$m]=true;
        $calculated=$months?round(count($months)/12,1):0.0;
        if($calculated>0)return min(60,$calculated);

        $explicit=(float)($ai['explicit_total_experience_years']??0);
        $evidence=trim((string)($ai['explicit_total_experience_evidence']??''));
        if($explicit>0&&$explicit<=60&&$evidence!==''&&$this->evidenceSupports('', $evidence,$text,'experience_total')) return round($explicit,1);

        return min(60,$this->extractExplicitOrDateExperience($text));
    }

    private function extractExplicitOrDateExperience(string $text): float
    {
        $best=0.0;
        $summaryPatterns=[
            '/\b(?:total|overall|professional|relevant)\s+(?:work\s+)?experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\b/i',
            '/\b(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)\s+of\s+(?:professional|work|industry|relevant)\s+experience\b/i',
        ];
        foreach($summaryPatterns as $pattern){if(preg_match_all($pattern,$text,$m))foreach($m[1] as $value){$v=(float)$value;if($v>0&&$v<=60)$best=max($best,$v);}}
        $section=$text;
        if(preg_match('/\b(?:WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|CAREER\s+HISTORY|EXPERIENCE)\b(.*?)(?=\b(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS?|PROJECTS?|CERTIFICATIONS?|SKILLS|TECHNICAL\s+SKILLS|PERSONAL\s+DETAILS|REFERENCES)\b|$)/is',$text,$m))$section=$m[1];
        $monthMap=['jan'=>1,'january'=>1,'feb'=>2,'february'=>2,'mar'=>3,'march'=>3,'apr'=>4,'april'=>4,'may'=>5,'jun'=>6,'june'=>6,'jul'=>7,'july'=>7,'aug'=>8,'august'=>8,'sep'=>9,'sept'=>9,'september'=>9,'oct'=>10,'october'=>10,'nov'=>11,'november'=>11,'dec'=>12,'december'=>12];
        $mw=implode('|',array_keys($monthMap));$covered=[];
        foreach(preg_split('/\R+/u',$section)?:[] as $line){
            if(preg_match('/\b(intern(ship)?|trainee|apprentice|volunteer|student|academic|coursework|training)\b/i',$line))continue;
            if(!preg_match('/((?:'.$mw.')\s+\d{4})\s*(?:-|–|—|to)\s*(Present|Current|(?:'.$mw.')\s+\d{4})/i',$line,$m))continue;
            $start=$this->parseMonth($m[1]);$end=$this->parseMonth($m[2]);if($start===null||$end===null||$end<$start)continue;
            for($i=$start;$i<$end;$i++)$covered[$i]=true;
        }
        if($covered)$best=max($best,round(count($covered)/12,1));
        return round(min(60,$best),1);
    }

    private function parseMonth(string $value): ?int
    {
        $v=trim($value);if($v==='')return null;
        if(preg_match('/\b(?:present|current|now)\b/i',$v))return ((int)date('Y'))*12+(int)date('n');
        $map=['jan'=>1,'january'=>1,'feb'=>2,'february'=>2,'mar'=>3,'march'=>3,'apr'=>4,'april'=>4,'may'=>5,'jun'=>6,'june'=>6,'jul'=>7,'july'=>7,'aug'=>8,'august'=>8,'sep'=>9,'sept'=>9,'september'=>9,'oct'=>10,'october'=>10,'nov'=>11,'november'=>11,'dec'=>12,'december'=>12];
        if(preg_match('/\b([A-Za-z]+)\s+((?:19|20)\d{2})\b/',$v,$m)){ $mon=$map[strtolower($m[1])]??null; return $mon?((int)$m[2])*12+$mon:null; }
        if(preg_match('/\b((?:19|20)\d{2})[-\/](\d{1,2})\b/',$v,$m))return ((int)$m[1])*12+max(1,min(12,(int)$m[2]));
        if(preg_match('/\b((?:19|20)\d{2})\b/',$v,$m))return ((int)$m[1])*12+1;
        return null;
    }

    private function dateAppearsInEvidence(string $date,string $evidence,string $text): bool
    {
        $date=trim($date);$evidence=$this->canonical($evidence);if($date===''||$evidence==='')return false;
        $parsed=$this->parseMonth($date);
        if($parsed===null)return false;
        $year=(string)intdiv($parsed,12);
        if(!str_contains($evidence,$this->canonical($year))) return false;
        if(preg_match('/\b(?:present|current|now)\b/i',$date) && !preg_match('/\b(?:present|current|now)\b/i',$evidence)) return false;
        // For numeric month values the exact lexical form can vary, but the evidence
        // must contain the date year and enough surrounding source text to be a real
        // employment entry rather than an unrelated year mention.
        if($parsed % 12 !== 1 && preg_match('/\b(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\b/i',$date,$mm)) {
            if(!str_contains($evidence,$this->canonical($mm[0]))) return false;
        }
        return true;
    }

    private function fieldConfidence(array $data,array $education,string $text): array
    {
        return [
            'candidate_name'=>!empty($data['candidate_name'])?($data['field_evidence']['candidate_name']['verified']?99:80):0,
            'candidate_email'=>!empty($data['candidate_email'])?99:0,
            'candidate_mobile'=>!empty($data['candidate_mobile'])?99:0,
            'candidate_gender'=>$data['candidate_gender']!==null?99:0,
            'candidate_marital_status'=>$data['candidate_marital_status']!==null?99:0,
            'candidate_qualification'=>!empty($data['candidate_qualification'])?95:0,
            'candidate_major'=>!empty($data['candidate_major'])?95:(!empty($data['candidate_major_text'])?75:0),
            'candidate_exper_count'=>(float)$data['candidate_exper_count']>0?94:82,
        ];
    }

    private function manualReviewFields(array $data,array $education): array
    {
        $review=[];
        foreach(['candidate_name','candidate_email','candidate_mobile'] as $field)if(empty($data[$field]))$review[]=$field;
        if(empty($data['candidate_qualification'])&&empty($data['degree_full']))$review[]='candidate_qualification';
        if(empty($data['candidate_major'])&&empty($data['candidate_major_text']))$review[]='candidate_major';
        if((float)($data['candidate_exper_count']??0)<=0&&empty($data['experience_evidence']))$review[]='candidate_exper_count';
        return array_values(array_unique($review));
    }

    private function overallConfidence(array $data): int
    {
        $weights=['candidate_name'=>20,'candidate_email'=>15,'candidate_mobile'=>15,'candidate_qualification'=>15,'candidate_major'=>20,'candidate_exper_count'=>15];
        $score=0.0;$fields=$data['field_confidence']??[];
        foreach($weights as $field=>$weight)$score+=(($fields[$field]??0)/100)*$weight;
        if(!empty($data['manual_review_fields']))$score=min($score,84);
        return (int)round(max(0,min(100,$score)));
    }

    private function evidenceSupports(string $value,string $evidence,string $text,string $type='field'): bool
    {
        $evidence=$this->canonical($evidence);$textCanonical=$this->canonical($text);$valueCanonical=$this->canonical($value);
        if($evidence!==''&&str_contains($textCanonical,$evidence))return true;
        if($valueCanonical!==''&&str_contains($textCanonical,$valueCanonical))return true;
        if($evidence===''||$type==='name')return false;
        $tokens=array_values(array_filter(explode(' ',$evidence),fn($v)=>mb_strlen($v)>=3));$textTokens=array_flip(explode(' ',$textCanonical));$hits=0;
        foreach(array_unique($tokens) as $token)if(isset($textTokens[$token]))$hits++;
        return count($tokens)>=4&&($hits/max(1,count(array_unique($tokens))))>=0.75;
    }

    private function explicitAiFieldSupported(array $ai,string $field,string $text): bool
    {
        $value=trim((string)($ai['identity'][$field]??''));
        $evidence=trim((string)($ai['identity'][$field.'_evidence']??''));
        if($value===''||$evidence==='') return false;
        if(!$this->evidenceSupports($value,$evidence,$text,$field)) return false;
        // Sensitive identity values must be explicitly labelled in source evidence.
        // Never accept an AI guess such as a standalone name-derived "Male" token.
        if($field==='gender'){
            $normalizedValue=strtolower($value);
            if(in_array($normalizedValue,['male','m'],true)){
                return (bool)preg_match('/\b(?:gender|sex)\s*(?:[:=\-]|\s+is\s+)\s*(?:male|m)\b/i',$evidence);
            }
            if(in_array($normalizedValue,['female','f'],true)){
                return (bool)preg_match('/\b(?:gender|sex)\s*(?:[:=\-]|\s+is\s+)\s*(?:female|f)\b/i',$evidence);
            }
            return false;
        }
        return true;
    }

    private function fieldEvidence(?string $value,string $evidence,string $text): array
    {
        $value=trim((string)$value);$evidence=trim($evidence);$verified=$value!==''&&$this->evidenceSupports($value,$evidence,$text);
        return ['value'=>$value,'evidence'=>$evidence,'verified'=>$verified];
    }

    private function explicitLabelEvidence(string $text,array $labels): string
    {
        foreach($labels as $label){if(preg_match('/'.preg_quote($label,'/').'\s*[:\-]?\s*[^\n|]{0,80}/i',$text,$m))return trim($m[0]);}
        return '';
    }

    private function experienceEvidence(array $entries,string $text): array
    {
        return array_values(array_unique(array_map(fn($e)=>$e['evidence'],array_filter($entries,fn($e)=>!empty($e['evidence'])))));
    }

    private function stringArray(mixed $values): array
    {
        if(!is_array($values))return [];
        return array_values(array_unique(array_filter(array_map(fn($v)=>mb_substr(trim((string)$v),0,300),$values))));
    }

    private function cleanName(?string $name): ?string
    {
        $name=trim(preg_replace('/\s+/u',' ',(string)$name)??'');
        $name=trim($name,"|,;:.- ");
        if($name===''||!$this->looksLikeName($name)) return null;
        $parts=preg_split('/\s+/u',$name)?:[];
        $parts=array_map(function(string $part):string{
            if(preg_match('/^(?:[A-Za-z]\.){2,}$/',$part)) return strtoupper($part);
            if(preg_match('/^[A-Za-z]\.$/',$part)) return strtoupper($part);
            return mb_convert_case(mb_strtolower($part,'UTF-8'),MB_CASE_TITLE,'UTF-8');
        },$parts);
        return implode(' ',$parts);
    }

    private function canonical(string $text): string
    {
        $text=mb_strtoupper($text,'UTF-8');
        $text=str_replace(['&','/','-','–','—','.',',','(',')',':','|','_'],' ',$text);
        $text=preg_replace('/\s+/u',' ',$text)??$text;
        $aliases=[
            'ELECTRICAL AND ELECTRONICS ENGINEERING'=>'ELECTRICAL ELECTRONICS ENGINEERING',
            'ELECTRONICS AND COMMUNICATION ENGINEERING'=>'ELECTRONICS COMMUNICATION ENGINEERING',
            'COMPUTER SCIENCE AND ENGINEERING'=>'COMPUTER SCIENCE ENGINEERING',
            'ARTIFICIAL'=>'ARTIFICIAL',
        ];
        foreach($aliases as $from=>$to)$text=str_replace($from,$to,$text);
        return trim($text);
    }

    private function buildMeta(array $documentMeta,array $data,bool $aiAttempted,bool $aiVerified,array $errors,float $started,array $ai): array
    {
        return [
            'engine'=>'rules+source-evidence+hf-structured+verification',
            'extension'=>$documentMeta['extension']??null,
            'original_name'=>$documentMeta['original_name']??null,
            'bytes'=>(int)($documentMeta['bytes']??0),
            'text_length'=>null,
            'ocr_used'=>(bool)($documentMeta['ocr_used']??false),
            'ai_configured'=>$this->huggingFace->token()!==null,
            'ai_attempted'=>$aiAttempted,
            'ai_verified'=>$aiVerified,
            'ai_errors'=>$errors,
            'primary_model'=>$aiAttempted?config('recruitment_ats.resume_primary_model'):null,
            'verifier_model'=>$aiVerified?config('recruitment_ats.resume_verifier_model'):null,
            'parser_version'=>config('recruitment_ats.resume_parser_version','resume_parser.v8'),
            'processing_ms'=>(int)round((microtime(true)-$started)*1000),
            'experience_entry_count'=>count($data['employment_entries']??[]),
            'education_entry_count'=>count($data['education_entries']??[]),
        ];
    }
}
