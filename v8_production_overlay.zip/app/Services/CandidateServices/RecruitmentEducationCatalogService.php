<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * Table-first education entity resolver for recruitment.
 *
 * Never assigns a fuzzy egc_major record. A major is resolved only when the
 * normalized candidate programme exactly matches an active master row or an
 * approved alias. Otherwise the caller gets the real qualification level and
 * a null major, which the UI represents as "Others".
 */
class RecruitmentEducationCatalogService
{

    public function resolve(string $resumeText, array $aiEntries, array $localEducation): array
    {
        $catalog = $this->catalog();
        $entries = $this->normalizeEntries($aiEntries, $resumeText);
        $entries = array_merge($entries, $this->deterministicEntries($resumeText, $localEducation, $catalog));
        $entries = $this->deduplicateEntries($entries);

        if (!$entries) {
            return $this->emptyResult();
        }

        $resolvedEntries = [];
        foreach ($entries as $entry) {
            $resolved = $this->resolveEntry($entry, $catalog);
            $entry['resolved'] = $resolved;
            $resolvedEntries[] = $entry;
        }

        usort($resolvedEntries, function (array $a, array $b): int {
            $aResolved = (array) ($a['resolved'] ?? []);
            $bResolved = (array) ($b['resolved'] ?? []);

            $rankCompare = ((int) ($bResolved['level_rank'] ?? 0)) <=> ((int) ($aResolved['level_rank'] ?? 0));
            if ($rankCompare !== 0) return $rankCompare;

            $yearCompare = $this->completionYear((string) ($b['year'] ?? '')) <=> $this->completionYear((string) ($a['year'] ?? ''));
            if ($yearCompare !== 0) return $yearCompare;

            $scoreCompare = ((float) ($bResolved['final_score'] ?? 0)) <=> ((float) ($aResolved['final_score'] ?? 0));
            if ($scoreCompare !== 0) return $scoreCompare;

            // Prefer the most specific exact programme when generic and
            // programme-level master rows both match the same resume.
            $specificityCompare = ((int) ($bResolved['target_specificity'] ?? 0)) <=> ((int) ($aResolved['target_specificity'] ?? 0));
            if ($specificityCompare !== 0) return $specificityCompare;

            // Resolved exact evidence beats AI-only evidence when otherwise equal.
            $priority = ['resolved_exact' => 5, 'resolved_alias' => 4, 'qualification_only' => 2, 'manual_review' => 1, 'not_found' => 0];
            return ($priority[$bResolved['resolution_status'] ?? 'not_found'] ?? 0)
                <=> ($priority[$aResolved['resolution_status'] ?? 'not_found'] ?? 0);
        });

        $chosen = $resolvedEntries[0];
        $resolved = (array) ($chosen['resolved'] ?? []);
        $masterMajorName = trim((string) ($resolved['major_name'] ?? ''));
        $rawMajor = trim((string) ($chosen['major'] ?? ''));
        $rawDegree = trim((string) ($chosen['degree_title'] ?? ''));
        $majorText = $masterMajorName !== '' ? $masterMajorName : ($rawMajor !== '' ? $rawMajor : null);

        $outputEntries = array_map(static function (array $entry): array {
            unset($entry['resolved']);
            return $entry;
        }, $resolvedEntries);

        $review = [];
        if (empty($resolved['qualification_sno'])) $review[] = 'qualification';
        if (!empty($resolved['qualification_sno']) && empty($resolved['major_sno'])) $review[] = 'major';
        if (($resolved['resolution_status'] ?? '') === 'manual_review') $review[] = 'education_mapping';

        return [
            'qualification_sno' => $resolved['qualification_sno'] ?? null,
            'major_sno' => $resolved['major_sno'] ?? null,
            'major_text' => $majorText,
            'degree_full' => $rawDegree !== '' ? $rawDegree : null,
            'major_score' => (int) round(((float) ($resolved['major_score'] ?? 0)) * 100),
            'qualification_score' => (int) round(((float) ($resolved['qualification_score'] ?? 0)) * 100),
            'evidence' => trim((string) ($chosen['evidence'] ?? $rawDegree)),
            'major_evidence' => trim((string) ($chosen['evidence'] ?? $rawMajor ?: $rawDegree)),
            'entries' => $outputEntries,
            'resolution_status' => (string) ($resolved['resolution_status'] ?? 'manual_review'),
            'candidates' => (array) ($resolved['candidates'] ?? []),
            'review_fields' => array_values(array_unique($review)),
            'matched_master' => $resolved['matched_master'] ?? null,
        ];
    }

    private function emptyResult(): array
    {
        return [
            'qualification_sno' => null,
            'major_sno' => null,
            'major_text' => null,
            'degree_full' => null,
            'major_score' => 0,
            'qualification_score' => 0,
            'evidence' => '',
            'major_evidence' => '',
            'entries' => [],
            'resolution_status' => 'not_found',
            'candidates' => [],
            'review_fields' => ['qualification', 'major'],
            'matched_master' => null,
        ];
    }

    private function catalog(): array
    {
        // Recruitment master data is intentionally read live for every resume parse.
        // Candidate extraction must immediately see new/edited qualification and major
        // rows; stale cache data was a source of incorrect production mappings.
        try {
            $levels = DB::table('egc_qualification_level')
                ->where('status', 0)
                ->orderBy('sno')
                ->get(['sno', 'qualification_level_name', 'description']);

            $majors = DB::table('egc_major')
                ->where('status', 0)
                ->orderBy('sno')
                ->get(['sno', 'qualification_id', 'major_name', 'description', 'updated_at']);

            $aliases = [];
            $qualificationAliases = [];

            if (Schema::hasTable('egc_recruitment_major_aliases')) {
                try {
                    DB::table('egc_recruitment_major_aliases')
                        ->where('status', 0)
                        ->where('match_enabled', 1)
                        ->orderBy('sno')
                        ->get(['major_sno', 'qualification_id', 'alias_name', 'alias_type'])
                        ->each(function ($row) use (&$aliases): void {
                            $alias = trim((string) $row->alias_name);
                            $id = (int) $row->major_sno;
                            if ($id > 0 && $alias !== '') $aliases[$id][] = $alias;
                        });
                } catch (Throwable) {
                    // Optional alias enrichment must never block core master matching.
                }
            }

            if (Schema::hasTable('egc_recruitment_qualification_aliases')) {
                try {
                    DB::table('egc_recruitment_qualification_aliases')
                        ->where('status', 0)
                        ->where('match_enabled', 1)
                        ->orderBy('sno')
                        ->get(['qualification_sno', 'alias_name', 'alias_type'])
                        ->each(function ($row) use (&$qualificationAliases): void {
                            $alias = trim((string) $row->alias_name);
                            $id = (int) $row->qualification_sno;
                            if ($id > 0 && $alias !== '') $qualificationAliases[$id][] = $alias;
                        });
                } catch (Throwable) {
                    // Optional alias enrichment must never block core master matching.
                }
            }

            return [
                'levels' => $levels->map(fn ($row): array => [
                    'sno' => (int) $row->sno,
                    'name' => trim((string) $row->qualification_level_name),
                    'rank' => $this->levelRank((string) $row->qualification_level_name),
                    'aliases' => array_values($qualificationAliases[(int) $row->sno] ?? []),
                ])->values()->all(),
                'majors' => $majors->map(fn ($row): array => [
                    'sno' => (int) $row->sno,
                    'qualification_id' => (int) $row->qualification_id,
                    'name' => trim((string) $row->major_name),
                    'description' => trim((string) ($row->description ?? '')),
                    'updated_at' => (string) ($row->updated_at ?? ''),
                    'aliases' => array_values($aliases[(int) $row->sno] ?? []),
                ])->values()->all(),
            ];
        } catch (Throwable) {
            return ['levels' => [], 'majors' => []];
        }
    }

    private function normalizeEntries(array $entries, string $resumeText): array
    {
        $out = [];
        foreach ($entries as $entry) {
            if (!is_array($entry)) continue;

            $degree = $this->cleanText($entry['degree_title'] ?? '');
            $major = $this->cleanText($entry['major'] ?? '');
            $level = $this->cleanText($entry['qualification_level'] ?? '');
            $institution = $this->cleanText($entry['institution'] ?? '');
            $year = $this->cleanText($entry['year'] ?? '');
            $evidence = $this->cleanText($entry['evidence'] ?? '');

            if ($degree === '' && $major === '' && $level === '' && $evidence === '') continue;
            if ($evidence !== '' && !$this->evidenceExists($evidence, $resumeText)) continue;

            $out[] = [
                'degree_title' => $degree,
                'qualification_level' => $level,
                'major' => $major,
                'institution' => $institution,
                'year' => $year,
                'evidence' => $evidence !== '' ? $evidence : $this->findEducationEvidence($degree, $major, $resumeText),
            ];
        }
        return $out;
    }

    private function deterministicEntries(string $resumeText, array $localEducation, array $catalog): array
    {
        $entries = [];
        $degree = $this->cleanText($localEducation['degree_full'] ?? '');
        $major = $this->cleanText($localEducation['major_text'] ?? '');
        if ($degree !== '' || $major !== '') {
            $entries[] = [
                'degree_title' => $degree,
                'qualification_level' => $this->levelKey($degree),
                'major' => $major,
                'institution' => '',
                'year' => $this->findNearestYear($degree . ' ' . $major, $resumeText),
                'evidence' => $this->findEducationEvidence($degree, $major, $resumeText),
            ];
        }

        $section = $this->educationSection($resumeText);
        foreach (preg_split('/\R+/u', $section) ?: [] as $line) {
            $line = trim(preg_replace('/\s+/u', ' ', $line) ?? $line);
            if ($line === '') continue;
            if (!$this->containsDegreeMarker($line)) continue;

            $parts = $this->splitEducationLine($line);
            $entries[] = [
                'degree_title' => $parts['degree'],
                'qualification_level' => $parts['level'],
                'major' => $parts['major'],
                'institution' => $parts['institution'],
                'year' => $parts['year'],
                'evidence' => $line,
            ];
        }

        // Strongest table-first signal: if an active master programme itself appears
        // in the resume education text, create an exact candidate. This eliminates
        // generic similarity errors such as mapping "Computer Science" to MCA.
        $canonicalResume = $this->canonicalProgram($resumeText);
        foreach ($catalog['majors'] as $row) {
            $canonicalName = $this->canonicalProgram((string) $row['name']);
            if ($canonicalName === '' || mb_strlen($canonicalName) < 5) continue;
            if (!$this->containsCanonicalPhrase($canonicalResume, $canonicalName)) continue;

            $entries[] = [
                'degree_title' => (string) $row['name'],
                'qualification_level' => $this->qualificationNameForId((int) $row['qualification_id'], $catalog),
                'major' => (string) $row['name'],
                'institution' => '',
                'year' => $this->findNearestYear((string) $row['name'], $resumeText),
                'evidence' => $this->findEducationEvidence((string) $row['name'], '', $resumeText),
                '_master_hint' => (int) $row['sno'],
            ];
        }

        return $entries;
    }

    private function resolveEntry(array $entry, array $catalog): array
    {
        $degree = $this->cleanText($entry['degree_title'] ?? '');
        $major = $this->cleanText($entry['major'] ?? '');
        $levelText = $this->cleanText($entry['qualification_level'] ?? '');
        $target = $this->canonicalProgram(trim($degree . ' ' . $major));
        $levelKey = $this->levelKey($levelText . ' ' . $degree . ' ' . $major);

        $qualificationId = $this->resolveQualificationId($levelKey, $degree, $major, $catalog);
        $qualificationScore = $qualificationId ? 1.0 : 0.0;
        $best = null;
        $bestStatus = 'qualification_only';
        $candidates = [];

        foreach ($catalog['majors'] as $row) {
            if ($qualificationId && (int) $row['qualification_id'] !== (int) $qualificationId) continue;

            $masterNorm = $this->canonicalProgram((string) $row['name']);
            $descriptionNorm = $this->canonicalProgram((string) ($row['description'] ?? ''));
            if ($masterNorm === '') continue;

            $score = 0.0;
            $status = 'none';

            if ($target !== '' && $target === $masterNorm) {
                $score = 1.0;
                $status = 'resolved_exact';
            } elseif ($target !== '' && $target === $descriptionNorm) {
                $score = 0.995;
                $status = 'resolved_alias';
            }

            foreach ((array) ($row['aliases'] ?? []) as $alias) {
                if ($target !== '' && $target === $this->canonicalProgram((string) $alias)) {
                    if ($score < 1.0) {
                        $score = 0.995;
                        $status = 'resolved_alias';
                    }
                }
            }

            // A very common representation is a degree in a separately provided major.
            // The combined canonical program is still exact; this branch only handles
            // aliases where punctuation/"in" wording leaves a specialization fragment.
            if ($score === 0.0 && $major !== '') {
                $majorNorm = $this->canonicalSpecialization($major);
                $masterSpec = $this->canonicalSpecialization((string) $row['name']);
                if ($majorNorm !== '' && $majorNorm === $masterSpec && $this->sameQualification($row, $qualificationId, $degree, $catalog)) {
                    $score = 0.995;
                    $status = 'resolved_alias';
                }
            }

            if ($score <= 0) continue;
            $candidates[] = [
                'sno' => (int) $row['sno'],
                'name' => (string) $row['name'],
                'qualification_id' => (int) $row['qualification_id'],
                'score' => $score,
                'status' => $status,
                'updated_at' => (string) ($row['updated_at'] ?? ''),
            ];
        }

        usort($candidates, function (array $a, array $b): int {
            $score = ((float) $b['score']) <=> ((float) $a['score']);
            if ($score !== 0) return $score;
            // Preserve the oldest active master ID for duplicate canonical records.
            return ((int) $a['sno']) <=> ((int) $b['sno']);
        });

        if ($candidates) {
            $best = $candidates[0];
            $bestStatus = (string) ($best['status'] ?? 'resolved_exact');
            $qualificationId = (int) $best['qualification_id'];
            $qualificationScore = 1.0;
        }

        if (!$qualificationId && $levelKey === '') {
            $bestStatus = 'not_found';
        }

        return [
            'qualification_sno' => $qualificationId ?: null,
            'qualification_score' => $qualificationScore,
            'major_sno' => $best ? (int) $best['sno'] : null,
            'major_name' => $best['name'] ?? null,
            'major_score' => (float) ($best['score'] ?? 0),
            'final_score' => max($qualificationScore, (float) ($best['score'] ?? 0)),
            'target_specificity' => count($this->tokens($target)),
            'level_rank' => $qualificationId ? $this->qualificationRankById($qualificationId, $catalog) : $this->levelRank($levelKey),
            'resolution_status' => $bestStatus,
            'candidates' => array_slice($candidates, 0, 5),
            'matched_master' => $best ? [
                'sno' => (int) $best['sno'],
                'name' => (string) $best['name'],
                'qualification_id' => (int) $best['qualification_id'],
                'status' => $best['status'],
            ] : null,
        ];
    }

    private function resolveQualificationId(string $levelKey, string $degree, string $major, array $catalog): ?int
    {
        if ($levelKey !== '') {
            foreach ($catalog['levels'] as $level) {
                if ($this->levelKey((string) $level['name']) === $levelKey) return (int) $level['sno'];
            }
        }

        $degreeNorm = $this->canonicalProgram($degree);
        foreach ($catalog['majors'] as $row) {
            $masterNorm = $this->canonicalProgram((string) $row['name']);
            $descriptionNorm = $this->canonicalProgram((string) ($row['description'] ?? ''));
            if ($degreeNorm !== '' && ($degreeNorm === $masterNorm || $degreeNorm === $descriptionNorm)) return (int) $row['qualification_id'];
            foreach ((array) ($row['aliases'] ?? []) as $alias) {
                if ($degreeNorm !== '' && $degreeNorm === $this->canonicalProgram((string) $alias)) return (int) $row['qualification_id'];
            }
        }

        return null;
    }

    private function sameQualification(array $row, ?int $qualificationId, string $degree, array $catalog): bool
    {
        if ($qualificationId) return (int) $row['qualification_id'] === $qualificationId;
        $key = $this->levelKey($degree);
        if ($key === '') return true;
        return $this->qualificationRankById((int) $row['qualification_id'], $catalog) === $this->levelRank($key);
    }

    private function educationSection(string $text): string
    {
        $pattern = '/(?:^|\n)\s*(?:EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS?|EDUCATIONAL\s+BACKGROUND|ACADEMICS?)\s*[:\-]?\s*(.*?)(?=\n\s*(?:WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|EXPERIENCE|PROJECTS?|CERTIFICATIONS?|SKILLS|TECHNICAL\s+SKILLS|PERSONAL\s+DETAILS|REFERENCES)\b|$)/is';
        return preg_match($pattern, $text, $m) ? trim((string) $m[1]) : $text;
    }

    private function containsDegreeMarker(string $line): bool
    {
        return (bool) preg_match('/\b(?:B\.?\s*SC|BSC|B\.?\s*TECH|BTECH|B\.?\s*E|BE|BCA|BCOM|B\.?\s*COM|BBA|B\.?\s*A|BA|MBA|MCA|M\.?\s*SC|MSC|M\.?\s*TECH|MTECH|M\.?\s*E|ME|M\.?\s*COM|M\.?\s*A|LL\.?B|LL\.?M|MBBS|B\.?PHARM|M\.?PHARM|B\.?ARCH|M\.?ARCH|B\.?ED|M\.?ED|PH\.?D|PHD|DIPLOMA|12TH|10TH|HSC|SSLC|BACHELOR|MASTER|DOCTORATE)\b/i', $line);
    }

    private function splitEducationLine(string $line): array
    {
        $year = '';
        if (preg_match('/\b(?:19|20)\d{2}\b(?:\s*[-/]\s*(?:19|20)\d{2})?/', $line, $m)) $year = $m[0];

        $clean = preg_replace('/\b(?:19|20)\d{2}\b(?:\s*[-/]\s*(?:19|20)\d{2})?/', ' ', $line) ?? $line;
        $clean = preg_replace('/\b(?:CGPA|GPA|PERCENTAGE|SCORE|MARKS?)\s*[:\-]?\s*[0-9.]+(?:\s*\/\s*[0-9.]+)?\s*%?/i', ' ', $clean) ?? $clean;
        $clean = trim(preg_replace('/\s+/u', ' ', $clean) ?? $clean, " |,;:-");

        $major = '';
        if (preg_match('/\b(?:in|with|speciali[sz]ation\s+in|major\s+in)\s+([^|;]+?)(?=\s+(?:from|at|@)\s+|$)/i', $clean, $m)) {
            $major = trim((string) $m[1]);
        } else {
            $major = $this->inferSpecialization($clean);
        }

        $institution = '';
        if (preg_match('/\b(?:from|at|@)\s+(.+)$/i', $clean, $m)) $institution = trim((string) $m[1]);

        return [
            'degree' => $clean,
            'major' => $major,
            'level' => $this->levelKey($clean),
            'institution' => $institution,
            'year' => $year,
        ];
    }

    private function inferSpecialization(string $degree): string
    {
        $value = $degree;
        $value = preg_replace('/^\s*(?:BACHELOR|MASTER|DOCTORATE|DOCTOR\s+OF\s+PHILOSOPHY|DIPLOMA)\s+(?:OF\s+)?/i', '', $value) ?? $value;
        $value = preg_replace('/^\s*(?:B\.?\s*(?:SC|TECH|E|CA|COM|A)|M\.?\s*(?:SC|TECH|E|CA|COM|A)|MBA|MCA|BBA|BCA|BCOM|BA|MA|LL\.?B|LL\.?M|PHD)\s*/i', '', $value) ?? $value;
        $value = trim($value, " ,;:-");
        return $value;
    }

    private function findEducationEvidence(string $degree, string $major, string $text): string
    {
        $needle = trim($degree . ' ' . $major);
        if ($needle === '') return '';
        $canonicalNeedle = $this->canonicalProgram($needle);
        foreach (preg_split('/\R+/u', $this->educationSection($text)) ?: [] as $line) {
            $line = trim($line);
            if ($line === '') continue;
            if ($canonicalNeedle !== '' && $this->containsCanonicalPhrase($this->canonicalProgram($line), $canonicalNeedle)) return $line;
            if (mb_strtolower($degree) !== '' && stripos($line, $degree) !== false) return $line;
        }
        return $needle;
    }

    private function findNearestYear(string $needle, string $text): string
    {
        if ($needle === '') return '';
        $best = '';
        foreach (preg_split('/\R+/u', $this->educationSection($text)) ?: [] as $line) {
            if (!$this->containsDegreeMarker($line)) continue;
            if ($this->containsCanonicalPhrase($this->canonicalProgram($line), $this->canonicalProgram($needle)) && preg_match('/\b(?:19|20)\d{2}\b(?:\s*[-/]\s*(?:19|20)\d{2})?/', $line, $m)) {
                $best = $m[0];
                break;
            }
        }
        return $best;
    }

    private function containsCanonicalPhrase(string $haystack, string $needle): bool
    {
        if ($haystack === '' || $needle === '') return false;
        if ($haystack === $needle) return true;
        return str_contains(' ' . $haystack . ' ', ' ' . $needle . ' ');
    }

    private function evidenceExists(string $evidence, string $text): bool
    {
        $evidenceCanonical = $this->canonicalProgram($evidence);
        $textCanonical = $this->canonicalProgram($text);
        if ($evidenceCanonical !== '' && str_contains($textCanonical, $evidenceCanonical)) return true;

        $tokens = $this->tokens($evidenceCanonical);
        if (count($tokens) < 3) return false;
        $textTokens = array_flip($this->tokens($textCanonical));
        $hits = 0;
        foreach ($tokens as $token) if (isset($textTokens[$token])) $hits++;
        return $hits >= max(3, (int) ceil(count($tokens) * 0.70));
    }

    private function canonicalProgram(string $text): string
    {
        $text = mb_strtoupper(strip_tags($text), 'UTF-8');
        $text = str_replace(['&', '/', '\\', '-', '–', '—', '.', ',', '(', ')', '[', ']', '{', '}', ':', ';', '|', '_', "'", '"'], ' ', $text);
        $text = preg_replace('/\b(?:19|20)\d{2}\b/', ' ', $text) ?? $text;
        $text = preg_replace('/\b(?:CGPA|GPA|PERCENTAGE|PERCENT|SCORE|MARKS?)\s*\d*(?:\.\d+)?\b/', ' ', $text) ?? $text;
        $text = preg_replace('/\b(?:REGULAR|FULL TIME|FULLTIME|PART TIME|DISTANCE|ONLINE|OFFLINE|HONOURS|HONORS|HONS|WITH DISTINCTION)\b/', ' ', $text) ?? $text;
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        // Degree master records frequently omit grammatical connector words
        // while resumes include them ("Bachelor of Science in Computer Science").
        // Removing these connectors makes the normalized programme comparable
        // without introducing fuzzy IDs.
        $text = preg_replace('/\b(?:OF|IN)\b/u', ' ', $text) ?? $text;
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;

        $replacements = [
            '/\bB\s*SC\b|\bBSC\b/' => ' BACHELOR SCIENCE ',
            '/\bM\s*SC\b|\bMSC\b/' => ' MASTER SCIENCE ',
            '/\bB\s*TECH\b|\bBTECH\b/' => ' BACHELOR TECHNOLOGY ',
            '/\bM\s*TECH\b|\bMTECH\b/' => ' MASTER TECHNOLOGY ',
            '/\bB\s*E\b|\bBE\b/' => ' BACHELOR ENGINEERING ',
            '/\bM\s*E\b|\bME\b/' => ' MASTER ENGINEERING ',
            '/\bB\s*COM\b|\bBCOM\b/' => ' BACHELOR COMMERCE ',
            '/\bM\s*COM\b|\bMCOM\b/' => ' MASTER COMMERCE ',
            '/\bB\s*CA\b|\bBCA\b/' => ' BACHELOR COMPUTER APPLICATIONS ',
            '/\bM\s*CA\b|\bMCA\b/' => ' MASTER COMPUTER APPLICATIONS ',
            '/\bB\s*BA\b|\bBBA\b/' => ' BACHELOR BUSINESS ADMINISTRATION ',
            '/\bM\s*BA\b|\bMBA\b/' => ' MASTER BUSINESS ADMINISTRATION ',
            '/\bB\s*A\b|\bBA\b/' => ' BACHELOR ARTS ',
            '/\bM\s*A\b|\bMA\b/' => ' MASTER ARTS ',
            '/\bL\s*L\s*B\b|\bLLB\b/' => ' BACHELOR LAW ',
            '/\bL\s*L\s*M\b|\bLLM\b/' => ' MASTER LAW ',
            '/\bB\s*PHARM\b|\bBPHARM\b/' => ' BACHELOR PHARMACY ',
            '/\bM\s*PHARM\b|\bMPHARM\b/' => ' MASTER PHARMACY ',
            '/\bB\s*ARCH\b|\bBARCH\b/' => ' BACHELOR ARCHITECTURE ',
            '/\bM\s*ARCH\b|\bMARCH\b/' => ' MASTER ARCHITECTURE ',
            '/\bB\s*ED\b|\bBED\b/' => ' BACHELOR EDUCATION ',
            '/\bM\s*ED\b|\bMED\b/' => ' MASTER EDUCATION ',
            '/\bMBBS\b/' => ' BACHELOR MEDICINE ',
            '/\bPH\s*D\b|\bPHD\b/' => ' DOCTORATE ',
            '/\bCSE\b/' => ' COMPUTER SCIENCE ENGINEERING ',
            '/\bCS\b/' => ' COMPUTER SCIENCE ',
            '/\bECE\b/' => ' ELECTRONICS COMMUNICATION ENGINEERING ',
            '/\bEEE\b/' => ' ELECTRICAL ELECTRONICS ENGINEERING ',
            '/\bIT\b/' => ' INFORMATION TECHNOLOGY ',
        ];
        foreach ($replacements as $pattern => $replace) $text = preg_replace($pattern, $replace, $text) ?? $text;

        $text = preg_replace('/\b(?:OF|IN|THE|AND)\b/', ' ', $text) ?? $text;
        $text = str_replace('COMPUTER SCIENCE AND ENGINEERING', 'COMPUTER SCIENCE ENGINEERING', $text);
        $text = str_replace('ELECTRONICS AND COMMUNICATION ENGINEERING', 'ELECTRONICS COMMUNICATION ENGINEERING', $text);
        $text = str_replace('ELECTRICAL AND ELECTRONICS ENGINEERING', 'ELECTRICAL ELECTRONICS ENGINEERING', $text);
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        return trim($text);
    }

    private function canonicalSpecialization(string $text): string
    {
        $canonical = $this->canonicalProgram($text);
        $canonical = preg_replace('/\b(?:BACHELOR|MASTER|DOCTORATE|SCIENCE|TECHNOLOGY|ENGINEERING|COMMERCE|ARTS|BUSINESS ADMINISTRATION|COMPUTER APPLICATIONS|LAW|PHARMACY|ARCHITECTURE|EDUCATION|MEDICINE)\b/', ' ', $canonical) ?? $canonical;
        return trim(preg_replace('/\s+/u', ' ', $canonical) ?? $canonical);
    }

    private function levelKey(string $value): string
    {
        $u = $this->canonicalProgram($value);
        if ($u === '') return '';
        if (str_contains($u, 'DOCTORATE') || preg_match('/\bPHD\b/', $u)) return 'Doctorate';
        if (str_contains($u, 'MASTER') || preg_match('/\b(?:PG|MBA|MCA|MSC|MTECH|ME|MCOM|MA|LLM|MPHARM|MARCH|MED)\b/', $u)) return 'PG';
        if (str_contains($u, 'DIPLOMA')) return 'Diploma';
        if (str_contains($u, 'BACHELOR') || preg_match('/\b(?:UG|MBBS)\b/', $u)) return 'UG';
        if (str_contains($u, 'HSC') || str_contains($u, 'HIGHER SECONDARY') || str_contains($u, 'PLUS TWO') || str_contains($u, '12TH')) return 'HSC';
        if (str_contains($u, 'SSLC') || str_contains($u, 'SECONDARY') || str_contains($u, '10TH')) return 'SSLC';
        return '';
    }

    private function levelRank(string $value): int
    {
        return match ($this->levelKey($value)) {
            'Doctorate' => 70,
            'PG' => 60,
            'UG' => 50,
            'Diploma' => 40,
            'HSC' => 20,
            'SSLC' => 10,
            default => 0,
        };
    }

    private function qualificationRankById(int $id, array $catalog): int
    {
        foreach ($catalog['levels'] as $level) if ((int) $level['sno'] === $id) return (int) $level['rank'];
        return 0;
    }

    private function qualificationNameForId(int $id, array $catalog): string
    {
        foreach ($catalog['levels'] as $level) if ((int) $level['sno'] === $id) return (string) $level['name'];
        return '';
    }

    private function completionYear(string $value): int
    {
        preg_match_all('/\b(?:19|20)\d{2}\b/', $value, $m);
        return $m[0] ? max(array_map('intval', $m[0])) : 0;
    }

    private function deduplicateEntries(array $entries): array
    {
        $seen = [];
        $out = [];
        foreach ($entries as $entry) {
            $key = $this->canonicalProgram(
                (string) ($entry['degree_title'] ?? '') . '|' .
                (string) ($entry['major'] ?? '') . '|' .
                (string) ($entry['qualification_level'] ?? '') . '|' .
                (string) ($entry['year'] ?? '') . '|' .
                (string) ($entry['_master_hint'] ?? '')
            );
            if ($key === '' || isset($seen[$key])) continue;
            $seen[$key] = true;
            $out[] = $entry;
        }
        return $out;
    }

    private function tokens(string $text): array
    {
        preg_match_all('/[\p{L}\p{N}]+/u', $this->canonicalProgram($text), $m);
        $stop = ['AND','THE','FOR','WITH','FROM','IN','TO','A','AN','OF','IS','AT','BY','MY','DEGREE','UNIVERSITY','COLLEGE','SCHOOL'];
        return array_values(array_unique(array_filter($m[0] ?? [], fn ($v) => mb_strlen($v) >= 2 && !in_array($v, $stop, true))));
    }

    private function cleanText(mixed $value): string
    {
        $value = trim((string) ($value ?? ''));
        return trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
    }
}
