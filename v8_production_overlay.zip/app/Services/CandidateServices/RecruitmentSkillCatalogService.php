<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * Skill normalization for deterministic ATS gates.
 * Dynamic aliases are managed in egc_recruitment_skill_aliases so HR/TA teams
 * can extend vocabulary without modifying PHP code.
 */
class RecruitmentSkillCatalogService
{
    private const CACHE_KEY = 'egc:recruitment:skill-aliases:v1';

    public function normalize(string $text): string
    {
        $value = $this->canonical($text);
        if ($value === '') return '';

        $aliases = $this->aliases();
        foreach ($aliases as $alias => $canonical) {
            $pattern = '/(?<![a-z0-9])' . preg_quote($alias, '/') . '(?![a-z0-9])/i';
            $value = preg_replace($pattern, ' ' . $canonical . ' ', $value) ?? $value;
        }

        return trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
    }

    public function coverage(string $resume, array|string $requirements): float
    {
        if (is_string($requirements)) $requirements = [$requirements];
        $requirements = array_values(array_unique(array_filter(array_map(
            fn ($value) => $this->normalize((string) $value),
            $requirements
        ))));

        if (!$requirements) return 0.0;
        $normalizedResume = $this->normalize($resume);
        if ($normalizedResume === '') return 0.0;

        $score = 0;
        foreach ($requirements as $requirement) {
            if (str_contains($normalizedResume, $requirement) || $this->tokenCoverage($requirement, $normalizedResume) >= 0.72) {
                $score++;
            }
        }

        return $score / count($requirements);
    }

    private function aliases(): array
    {
        return Cache::remember(self::CACHE_KEY, now()->addMinutes(30), function (): array {
            // Safe built-ins cover common CV spellings before the dynamic table
            // is populated; the table remains the extension point for company vocabulary.
            $aliases = [
                'react js' => 'react',
                'reactjs' => 'react',
                'node js' => 'node',
                'nodejs' => 'node',
                'next js' => 'nextjs',
                'nextjs' => 'nextjs',
                'vue js' => 'vue',
                'vuejs' => 'vue',
                'angular js' => 'angular',
                'angularjs' => 'angular',
                'postgre sql' => 'postgresql',
                'postgresql' => 'postgresql',
                'postgres' => 'postgresql',
                'mongo db' => 'mongodb',
                'mongo' => 'mongodb',
                'ms sql' => 'sql server',
                'microsoft sql server' => 'sql server',
                'c sharp' => 'csharp',
                'c#' => 'csharp',
                'c plus plus' => 'cpp',
                'c++' => 'cpp',
                'typescript js' => 'typescript',
                'javascript es6' => 'javascript',
                'ecma script' => 'javascript',
                'rest api' => 'rest',
                'restful api' => 'rest',
                'llm' => 'large language model',
                'gen ai' => 'generative ai',
                'artificial intelligence' => 'ai',
                'machine learning' => 'ml',
            ];

            if (!Schema::hasTable('egc_recruitment_skill_aliases')) return $this->sortAliases($aliases);

            try {
                $rows = DB::table('egc_recruitment_skill_aliases')
                    ->where('status', 0)
                    ->where('match_enabled', 1)
                    ->orderByDesc('priority')
                    ->orderBy('sno')
                    ->get(['alias_name', 'canonical_skill']);

                foreach ($rows as $row) {
                    $alias = $this->canonical((string) ($row->alias_name ?? ''));
                    $canonical = $this->canonical((string) ($row->canonical_skill ?? ''));
                    if ($alias !== '' && $canonical !== '') $aliases[$alias] = $canonical;
                }
            } catch (Throwable) {
                // Built-in aliases remain active if the optional table is unavailable.
            }

            return $this->sortAliases($aliases);
        });
    }

    private function sortAliases(array $aliases): array
    {
        uksort($aliases, static fn (string $a, string $b): int => strlen($b) <=> strlen($a));
        return $aliases;
    }

    private function tokenCoverage(string $needle, string $haystack): float
    {
        $needleTokens = $this->tokens($needle);
        $haystackTokens = $this->tokens($haystack);
        if (!$needleTokens) return 0.0;
        return count(array_intersect($needleTokens, $haystackTokens)) / max(1, count($needleTokens));
    }

    private function tokens(string $text): array
    {
        preg_match_all('/[a-z0-9]+/i', $this->normalizeBasic($text), $m);
        $stop = ['and','the','for','with','from','into','this','that','of','in','to','a','an','on','at','as','or','is','be','by','our','your'];
        return array_values(array_unique(array_filter(
            $m[0] ?? [],
            fn ($token) => strlen($token) >= 2 && !in_array($token, $stop, true)
        )));
    }

    private function normalizeBasic(string $text): string
    {
        $text = mb_strtolower(strip_tags($text), 'UTF-8');
        $text = str_replace(['&','/','\\','-','_','.', '(', ')', ',', ':', '|', ';'], ' ', $text);
        return trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
    }

    private function canonical(string $text): string
    {
        return $this->normalizeBasic($text);
    }
}
