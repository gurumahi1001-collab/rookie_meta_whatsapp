<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Broad hybrid role retrieval.
 *
 * Every active role in egc_recruitment_roles is considered. Retrieval is only
 * an efficiency layer for the semantic LLM; it is never allowed to invent a
 * role or change the role source-of-truth.
 *
 * Signals:
 *   1. lexical title/family/alias/requirements overlap;
 *   2. Hugging Face sentence embeddings (when configured);
 *   3. exact title/alias boosts.
 *
 * When embedding inference is unavailable the service degrades to lexical
 * retrieval without breaking candidate creation or ATS persistence.
 */
class RecruitmentRoleRetrievalService
{
    public function __construct(
        protected RecruitmentAtsRoleCatalogService $catalog,
        protected RecruitmentHuggingFaceService $huggingFace
    ) {
    }

    public function retrieve(string $resume, ?int $limit = null): array
    {
        $ranked = $this->rankAll($resume);
        $limit = max(4, (int) ($limit ?? config('recruitment_ats.role_retrieval_limit', 24)));

        $selected = [];
        foreach ($ranked as $item) {
            if (count($selected) < $limit || !empty($item['exact'])) {
                $selected[] = $item['role'];
            }
        }

        return $this->deduplicate($selected);
    }

    /**
     * Return every active ATS role with hybrid retrieval metadata.
     */
    public function rankAll(string $resume): array
    {
        $roles = $this->catalog->getActiveRoles();
        if (!$roles) return [];

        $resumeText = $this->canonical($resume);
        $resumeTokens = $this->tokens($resumeText);
        $lexical = [];

        foreach ($roles as $role) {
            $roleText = $this->roleText($role);
            $roleTokens = $this->tokens($roleText);
            $titleTokens = $this->tokens(
                ($role['role_name'] ?? '') . ' ' .
                ($role['role_family'] ?? '') . ' ' .
                implode(' ', $role['aliases'] ?? [])
            );

            $requiredTokens = $this->tokens(implode(' ', array_merge(
                $role['mandatory_skills'] ?? [],
                $role['preferred_skills'] ?? [],
                $role['responsibilities'] ?? [],
                $role['education_requirements'] ?? [],
                [(string) ($role['minimum_experience'] ?? '')],
                [(string) ($role['description'] ?? '')]
            )));

            $titleOverlap = $this->overlap($titleTokens, $resumeTokens);
            $requiredOverlap = $this->overlap($requiredTokens, $resumeTokens);
            $bodyOverlap = $this->overlap($roleTokens, $resumeTokens);

            $exactPhrase = 0.0;
            if ($this->phraseMatch($resumeText, (string) ($role['role_name'] ?? ''))) {
                $exactPhrase = 100.0;
            }

            foreach ((array) ($role['aliases'] ?? []) as $alias) {
                if ($this->phraseMatch($resumeText, (string) $alias)) {
                    $exactPhrase = max($exactPhrase, 95.0);
                }
            }

            $lexicalScore = ($exactPhrase * 0.50)
                + ($titleOverlap * 0.25)
                + ($requiredOverlap * 0.15)
                + ($bodyOverlap * 0.10);

            $lexical[] = [
                'role' => array_merge($role, [
                    '_retrieval_score' => round(min(100, $lexicalScore), 2),
                    '_embedding_score' => 0,
                ]),
                'lexical_score' => round(min(100, $lexicalScore), 2),
                'exact' => $exactPhrase > 0,
            ];
        }

        // Sort once before deciding whether embeddings are needed. This also
        // provides a deterministic fallback if HF is not reachable.
        usort($lexical, fn ($a, $b) => $b['lexical_score'] <=> $a['lexical_score']);

        if (!filter_var(config('recruitment_ats.role_embedding_enabled', true), FILTER_VALIDATE_BOOLEAN)) {
            return $lexical;
        }

        try {
            $ranked = $this->applyEmbeddings($resume, $lexical);
            if ($ranked) return $ranked;
        } catch (Throwable $e) {
            Log::warning('ATS semantic role retrieval degraded to lexical mode.', [
                'message' => $e->getMessage(),
            ]);
        }

        return $lexical;
    }

    private function applyEmbeddings(string $resume, array $lexical): array
    {
        $model = (string) config('recruitment_ats.embedding_model', 'BAAI/bge-m3');
        $catalogHash = $this->catalog->getCatalogHash(array_map(fn ($item) => $item['role'], $lexical));
        $resumeProfile = $this->buildResumeProfile($resume);

        $candidateEmbedding = $this->huggingFace->embed(
            [$resumeProfile],
            $model,
            (int) config('recruitment_ats.embedding_timeout', 45)
        );

        if (!$candidateEmbedding['status'] || empty($candidateEmbedding['vectors'][0])) {
            return $lexical;
        }

        $candidateVector = $candidateEmbedding['vectors'][0];
        $roleVectors = $this->loadRoleEmbeddings($lexical, $model, $catalogHash);

        if (!$roleVectors) return $lexical;

        foreach ($lexical as $index => &$item) {
            $id = (int) ($item['role']['sno'] ?? 0);
            $vector = $roleVectors[$id] ?? null;
            if (!is_array($vector)) continue;

            $cosine = $this->cosine($candidateVector, $vector);
            $semantic = max(0, min(100, ($cosine + 1.0) * 50.0));
            $item['embedding_score'] = round($semantic, 2);

            // Exact title/alias remains a strong signal, but embeddings provide
            // the semantic bridge for titles such as "Software Engineer" vs
            // "Full Stack Developer".
            $item['retrieval_score'] = round(
                $item['lexical_score'] * 0.40 + $semantic * 0.60,
                2
            );
            $item['role']['_retrieval_score'] = $item['retrieval_score'];
            $item['role']['_embedding_score'] = $item['embedding_score'];
        }
        unset($item);

        usort($lexical, function ($a, $b) {
            $as = (float) ($a['retrieval_score'] ?? $a['lexical_score']);
            $bs = (float) ($b['retrieval_score'] ?? $b['lexical_score']);
            return $bs <=> $as;
        });

        return $lexical;
    }

    private function loadRoleEmbeddings(array $items, string $model, string $catalogHash): array
    {
        $cacheKey = 'egc:ats:role-embeddings:' . sha1($model . '|' . $catalogHash);
        $cached = Cache::get($cacheKey);
        if (is_array($cached) && $cached) return $cached;

        $vectors = [];
        foreach (array_chunk($items, 20) as $chunk) {
            $texts = array_map(
                fn ($item) => mb_substr($this->buildRoleEmbeddingText($item['role']), 0, 6000),
                $chunk
            );

            $response = $this->huggingFace->embed(
                $texts,
                $model,
                (int) config('recruitment_ats.embedding_timeout', 45)
            );

            if (!$response['status']) return [];

            foreach ($chunk as $offset => $item) {
                $id = (int) ($item['role']['sno'] ?? 0);
                $vector = $response['vectors'][$offset] ?? null;
                if ($id > 0 && is_array($vector)) $vectors[$id] = $vector;
            }
        }

        if ($vectors) {
            Cache::put(
                $cacheKey,
                $vectors,
                now()->addMinutes((int) config('recruitment_ats.role_embedding_cache_minutes', 60))
            );
        }

        return $vectors;
    }

    private function buildResumeProfile(string $resume): string
    {
        $resume = trim($resume);
        $max = max(5000, (int) config('recruitment_ats.embedding_resume_max_chars', 12000));

        if (mb_strlen($resume) <= $max) return $resume;

        $sections = [];
        foreach ([
            'WORK\s+EXPERIENCE|PROFESSIONAL\s+EXPERIENCE|EMPLOYMENT\s+HISTORY|EXPERIENCE',
            'SKILLS|TECHNICAL\s+SKILLS|CORE\s+SKILLS',
            'EDUCATION|ACADEMIC\s+QUALIFICATIONS?|QUALIFICATIONS',
            'PROJECTS?|KEY\s+PROJECTS',
            'SUMMARY|PROFILE|OBJECTIVE',
        ] as $pattern) {
            if (preg_match('/\b(?:' . $pattern . ')\b.*?(?=\n\s*\n|\b(?:WORK\s+EXPERIENCE|EDUCATION|SKILLS|PROJECTS?|CERTIFICATIONS?|REFERENCES)\b|$)/is', $resume, $m)) {
                $sections[] = trim($m[0]);
            }
        }

        $result = implode("\n\n", array_values(array_unique($sections)));
        return mb_substr($result !== '' ? $result : $resume, 0, $max);
    }

    private function buildRoleEmbeddingText(array $role): string
    {
        return trim(implode("\n", [
            'Role: ' . ($role['role_name'] ?? ''),
            'Family: ' . ($role['role_family'] ?? ''),
            'Seniority: ' . ($role['seniority_label'] ?? ''),
            'Description: ' . ($role['description'] ?? ''),
            'Mandatory skills: ' . implode(', ', $role['mandatory_skills'] ?? []),
            'Preferred skills: ' . implode(', ', $role['preferred_skills'] ?? []),
            'Responsibilities: ' . implode('; ', $role['responsibilities'] ?? []),
            'Minimum experience: ' . ($role['minimum_experience'] ?? ''),
            'Education: ' . implode(', ', $role['education_requirements'] ?? []),
            'Aliases: ' . implode(', ', $role['aliases'] ?? []),
        ]));
    }

    private function cosine(array $a, array $b): float
    {
        $size = min(count($a), count($b));
        if ($size === 0) return 0;

        $dot = 0.0;
        $an = 0.0;
        $bn = 0.0;

        for ($i = 0; $i < $size; $i++) {
            $x = (float) $a[$i];
            $y = (float) $b[$i];
            $dot += $x * $y;
            $an += $x * $x;
            $bn += $y * $y;
        }

        if ($an <= 0.0 || $bn <= 0.0) return 0;
        return $dot / (sqrt($an) * sqrt($bn));
    }

    private function roleText(array $role): string
    {
        return implode(' ', array_merge(
            [
                $role['role_name'] ?? '',
                $role['role_family'] ?? '',
                $role['description'] ?? '',
                $role['minimum_experience'] ?? '',
            ],
            $role['mandatory_skills'] ?? [],
            $role['preferred_skills'] ?? [],
            $role['responsibilities'] ?? [],
            $role['education_requirements'] ?? [],
            $role['aliases'] ?? []
        ));
    }

    private function overlap(array $required, array $resume): float
    {
        if (!$required || !$resume) return 0.0;
        return (count(array_intersect($required, $resume)) / max(1, count(array_unique($required)))) * 100;
    }

    private function phraseMatch(string $text, string $phrase): bool
    {
        $phrase = trim($phrase);
        return $phrase !== '' && str_contains(
            $this->canonical($text),
            $this->canonical($phrase)
        );
    }

    private function tokens(string $text): array
    {
        preg_match_all('/[a-z0-9]+/i', $this->canonical($text), $m);

        $stop = [
            'and','the','for','with','from','into','this','that','role','job','position',
            'candidate','years','year','of','in','to','a','an','on','at','as','or','is',
            'be','by','our','your','company','work','working','experience','responsibility',
            'responsibilities','required','preferred','skills',
        ];

        return array_values(array_unique(array_filter(
            $m[0] ?? [],
            fn ($x) => strlen($x) >= 2 && !in_array($x, $stop, true)
        )));
    }

    private function canonical(string $text): string
    {
        $text = mb_strtolower(strip_tags($text), 'UTF-8');
        $text = str_replace(['&','/','\\','-','_','.','(',')',',',':','|',';'], ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        $text = str_replace(
            ['node js','nodejs','react js','reactjs','next js','nextjs','dot net','c sharp','c++'],
            ['node','node','react','react','nextjs','nextjs','dotnet','csharp','cpp'],
            $text
        );
        return trim($text);
    }

    private function deduplicate(array $roles): array
    {
        $byId = [];
        foreach ($roles as $role) {
            $id = (int) ($role['sno'] ?? $role['role_id'] ?? 0);
            if ($id > 0) $byId[$id] = $role;
        }
        return array_values($byId);
    }
}
