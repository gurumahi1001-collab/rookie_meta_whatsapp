<?php

declare(strict_types=1);

namespace App\Services\CandidateServices;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Recruitment-only Hugging Face client. It intentionally does not change the
 * application's existing global AI client so unrelated ERP features keep
 * their current model configuration.
 */
class RecruitmentHuggingFaceService
{
    public function structured(array $messages, array $schema, ?string $model = null, ?int $timeout = null): array
    {
        $token = $this->token();
        if (!$token) {
            return ['status' => false, 'message' => 'Hugging Face token is not configured.'];
        }

        $model = trim((string) ($model ?: config('recruitment_ats.resume_primary_model')));
        $timeout = max(20, (int) ($timeout ?: config('recruitment_ats.ai_timeout', 70)));
        $baseUrl = rtrim((string) config('recruitment_ats.hf_chat_url', config('recruitment_ats.hf_url', 'https://router.huggingface.co/v1/chat/completions')), '/');

        $payload = [
            'model' => $model,
            'messages' => $messages,
            'temperature' => 0.0,
            'top_p' => 1.0,
            'max_tokens' => (int) config('recruitment_ats.ai_max_tokens', 3200),
            'stream' => false,
            'response_format' => [
                'type' => 'json_schema',
                'json_schema' => [
                    'name' => 'egc_recruitment_structured_result',
                    'schema' => $schema,
                    'strict' => true,
                ],
            ],
        ];

        $response = $this->post($baseUrl, $token, $payload, $timeout);
        if (!$response['status']) return $response;

        $parsed = $this->parseContent($response['response']);
        if (is_array($parsed)) {
            return ['status' => true, 'data' => $parsed, 'model' => $model];
        }

        // Some providers/models support JSON object but reject JSON schema.
        $fallbackPayload = $payload;
        $fallbackPayload['response_format'] = ['type' => 'json_object'];
        $fallback = $this->post($baseUrl, $token, $fallbackPayload, $timeout);

        if ($fallback['status']) {
            $parsed = $this->parseContent($fallback['response']);
            if (is_array($parsed)) {
                return ['status' => true, 'data' => $parsed, 'model' => $model];
            }
        }

        return [
            'status' => false,
            'message' => 'Hugging Face returned an unusable structured response.',
            'http_status' => $response['http_status'] ?? null,
        ];
    }

    /**
     * Return one normalized sentence embedding per input.
     *
     * Hugging Face feature-extraction providers may return:
     *  - [dimension] per sentence;
     *  - [tokens][dimension] when token pooling is exposed.
     * We mean-pool token vectors and L2-normalize so the caller can use cosine
     * similarity without caring which provider representation was returned.
     */
    public function embed(array $texts, ?string $model = null, ?int $timeout = null): array
    {
        $texts = array_values(array_filter(array_map(
            fn ($value) => trim((string) $value),
            $texts
        )));

        if (!$texts) return ['status' => true, 'vectors' => [], 'model' => null];

        $token = $this->token();
        if (!$token) return ['status' => false, 'message' => 'Hugging Face token is not configured.'];

        $model = trim((string) ($model ?: config('recruitment_ats.embedding_model', 'BAAI/bge-m3')));
        $timeout = max(15, (int) ($timeout ?: config('recruitment_ats.embedding_timeout', 45)));

        $configuredUrl = trim((string) config('recruitment_ats.hf_embedding_url', ''));
        $url = $configuredUrl !== ''
            ? $configuredUrl
            : 'https://router.huggingface.co/hf-inference/models/' . str_replace(' ', '%20', $model) . '/pipeline/feature-extraction';

        try {
            $response = Http::connectTimeout(8)
                ->timeout($timeout)
                ->retry(2, 1200, null, false)
                ->withToken($token)
                ->acceptJson()
                ->asJson()
                ->post($url, [
                    'inputs' => $texts,
                    'normalize' => true,
                    'truncate' => true,
                    'truncation_direction' => 'right',
                ]);

            if (!$response->successful()) {
                Log::warning('Recruitment Hugging Face embedding request failed.', [
                    'status' => $response->status(),
                    'model' => $model,
                    'body' => mb_substr($response->body(), 0, 1600),
                ]);

                return [
                    'status' => false,
                    'message' => 'Hugging Face embedding request failed.',
                    'http_status' => $response->status(),
                ];
            }

            $raw = $response->json();
            $vectors = $this->normalizeEmbeddingPayload($raw, count($texts));

            if (!$vectors) {
                return ['status' => false, 'message' => 'Hugging Face returned no usable embeddings.'];
            }

            return ['status' => true, 'vectors' => $vectors, 'model' => $model];
        } catch (Throwable $e) {
            Log::error('Recruitment Hugging Face embedding exception.', [
                'model' => $model,
                'message' => $e->getMessage(),
            ]);

            return ['status' => false, 'message' => 'Unable to contact Hugging Face embedding service.'];
        }
    }


    private function normalizeEmbeddingPayload(mixed $payload, int $expectedCount): array
    {
        if (!is_array($payload)) return [];

        // Provider errors can be JSON objects.
        if (isset($payload['error'])) return [];

        $items = $payload;

        if ($expectedCount === 1) {
            // One sentence may be returned as [dimension], [1][dimension],
            // or [tokens][dimension]. Normalize all three to one item.
            if ($this->isNumericVector($items)) {
                $items = [$items];
            } elseif (isset($items[0]) && is_array($items[0]) && $this->isNumericVector($items[0])) {
                $items = [$items];
            }
        }

        $out = [];
        foreach ($items as $item) {
            if (!is_array($item)) continue;

            if ($this->isNumericVector($item)) {
                $out[] = $this->l2Normalize(array_map('floatval', $item));
                continue;
            }

            // Token-level output: mean-pool numeric vectors.
            $tokenVectors = [];
            foreach ($item as $tokenVector) {
                if (is_array($tokenVector) && $this->isNumericVector($tokenVector)) {
                    $tokenVectors[] = array_map('floatval', $tokenVector);
                }
            }

            if ($tokenVectors) {
                $dimension = count($tokenVectors[0]);
                $mean = array_fill(0, $dimension, 0.0);
                foreach ($tokenVectors as $vector) {
                    for ($i = 0; $i < $dimension; $i++) {
                        $mean[$i] += $vector[$i];
                    }
                }

                $count = count($tokenVectors);
                for ($i = 0; $i < $dimension; $i++) $mean[$i] /= $count;
                $out[] = $this->l2Normalize($mean);
            }
        }

        return count($out) === $expectedCount ? $out : [];
    }

    private function isNumericVector(array $value): bool
    {
        if (!$value) return false;
        foreach ($value as $number) {
            if (!is_int($number) && !is_float($number) && !is_numeric($number)) return false;
        }
        return true;
    }

    private function l2Normalize(array $vector): array
    {
        $norm = 0.0;
        foreach ($vector as $value) $norm += ((float) $value * (float) $value);
        $norm = sqrt($norm);

        if ($norm <= 0.0) return $vector;
        return array_map(fn ($value) => (float) $value / $norm, $vector);
    }

    public function token(): ?string
    {
        $envToken = trim((string) (env('HF_TOKEN') ?: env('HUGGINGFACE_API_TOKEN')));
        if ($envToken !== '') return $envToken;

        return Cache::remember('egc_recruitment_hf_token', now()->addMinutes(5), function () {
            try {
                $row = DB::table('egc_api_integration')
                    ->where('api_key', 'egc_huggingface_api_1')
                    ->where('status', 0)
                    ->latest('sno')
                    ->first();

                $fields = json_decode((string) ($row->api_fields ?? ''), true);
                foreach ((array) $fields as $field) {
                    if (($field['key'] ?? '') === 'api_key' && trim((string) ($field['value'] ?? '')) !== '') {
                        return trim((string) $field['value']);
                    }
                }
            } catch (Throwable $e) {
                Log::warning('Recruitment Hugging Face token lookup failed.', ['message' => $e->getMessage()]);
            }
            return null;
        });
    }

    public function clearTokenCache(): void
    {
        Cache::forget('egc_recruitment_hf_token');
    }

    private function post(string $url, string $token, array $payload, int $timeout): array
    {
        try {
            $response = Http::connectTimeout(10)
                ->timeout($timeout)
                ->retry(2, 1500, null, false)
                ->withToken($token)
                ->acceptJson()
                ->asJson()
                ->post($url, $payload);

            if ($response->successful()) {
                return ['status' => true, 'response' => $response];
            }

            Log::warning('Recruitment Hugging Face request failed.', [
                'status' => $response->status(),
                'model' => $payload['model'] ?? null,
                'body' => mb_substr($response->body(), 0, 2000),
            ]);

            return ['status' => false, 'message' => 'Hugging Face request failed.', 'http_status' => $response->status(), 'response' => $response];
        } catch (Throwable $e) {
            Log::error('Recruitment Hugging Face exception.', ['message' => $e->getMessage()]);
            return ['status' => false, 'message' => 'Unable to contact Hugging Face.', 'exception' => $e->getMessage()];
        }
    }

    private function parseContent(object $response): ?array
    {
        $content = data_get($response->json(), 'choices.0.message.content');
        if (is_array($content)) return $content;

        $raw = trim((string) $content);
        if ($raw === '') return null;
        $raw = preg_replace('/^```(?:json)?\s*/i', '', $raw);
        $raw = preg_replace('/\s*```$/', '', $raw);
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) return $decoded;

        return null;
    }
}
