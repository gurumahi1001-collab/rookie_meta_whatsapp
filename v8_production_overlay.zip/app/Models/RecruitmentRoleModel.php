<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Schema;

class RecruitmentRoleModel extends Model
{
    protected $table = 'egc_recruitment_roles';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';

    public const STATUS_ACTIVE = 0;
    public const STATUS_INACTIVE = 1;
    public const STATUS_DELETED = 2;

    public const SENIORITY_ENTRY = 1;
    public const SENIORITY_SENIOR = 2;
    public const SENIORITY_TEAM_LEAD = 3;
    public const SENIORITY_MANAGER = 4;
    public const SENIORITY_HEAD = 5;

    protected $fillable = [
        'role_code','role_name','normalized_role_name','role_family','seniority_level','description',
        'role_description','mandatory_skills','preferred_skills','responsibilities','minimum_experience',
        'education_requirements','seniority','ai_matching_enabled','ai_profile_version','ai_profile_hash',
        'ai_profile_updated_at','ai_profile_source','ai_profile_updated_by','created_by','updated_by','status','match_enabled',
    ];

    protected $casts = [
        'sno'=>'integer','seniority_level'=>'integer','created_by'=>'integer','updated_by'=>'integer',
        'status'=>'integer','match_enabled'=>'boolean','ai_matching_enabled'=>'boolean','ai_profile_version'=>'integer',
        'ai_profile_updated_by'=>'integer','ai_profile_updated_at'=>'datetime','created_at'=>'datetime','updated_at'=>'datetime',
    ];

    public function scopeNotDeleted(Builder $query): Builder { return $query->where('status','!=',self::STATUS_DELETED); }
    public function scopeActive(Builder $query): Builder { return $query->where('status',self::STATUS_ACTIVE); }
    public function scopeAtsEnabled(Builder $query): Builder
    {
        $query->where('match_enabled', true);

        // Current production role master does not require a separate
        // ai_matching_enabled flag. Preserve legacy compatibility when the
        // column exists, but never query a column that is absent.
        if (Schema::hasColumn($this->getTable(), 'ai_matching_enabled')) {
            $query->where(function (Builder $inner): void {
                $inner->where('ai_matching_enabled', true)
                    ->orWhereNull('ai_matching_enabled');
            });
        }

        return $query;
    }
    public function isDeleted(): bool { return $this->status === self::STATUS_DELETED; }

    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) { self::STATUS_ACTIVE=>'Active', self::STATUS_INACTIVE=>'Inactive', self::STATUS_DELETED=>'Deleted', default=>'Unknown' };
    }

    public function getSeniorityLabelAttribute(): string
    {
        return match ($this->seniority_level) { self::SENIORITY_ENTRY=>'Entry', self::SENIORITY_SENIOR=>'Senior', self::SENIORITY_TEAM_LEAD=>'Team Lead', self::SENIORITY_MANAGER=>'Manager', self::SENIORITY_HEAD=>'Head', default=>'Entry' };
    }
}
