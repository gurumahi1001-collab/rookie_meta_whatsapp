<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApplicantResumeExtractionFieldModel extends Model
{
    protected $table = 'egc_applicant_resume_extraction_fields';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'extraction_sno',
        'applicant_sno',
        'field_name',
        'field_value',
        'normalized_value',
        'source_method',
        'confidence',
        'verification_status',
        'evidence_text',
        'model_name',
        'parser_version',
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'sno' => 'integer',
        'extraction_sno' => 'integer',
        'applicant_sno' => 'integer',
        'confidence' => 'decimal:2',
    ];
}
