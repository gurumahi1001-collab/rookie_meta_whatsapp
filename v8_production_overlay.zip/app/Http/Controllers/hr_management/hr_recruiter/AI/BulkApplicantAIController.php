<?php

namespace App\Http\Controllers\hr_management\hr_recruiter\AI;

use App\Http\Controllers\Controller;
use App\Services\CandidateServices\ApplicantBatchService;
use App\Services\CandidateServices\RecruitmentAtsRunService;
use App\Jobs\hr_management\hr_recruiter\ProcessRecruitmentAtsRoleMatchingRunJob;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Throwable;

class BulkApplicantAIController extends Controller
{
    protected ApplicantBatchService $batchService;
    protected RecruitmentAtsRunService $atsRuns;

    public function __construct(
        ApplicantBatchService $batchService,
        RecruitmentAtsRunService $atsRuns
    ) {
        $this->batchService = $batchService;
        $this->atsRuns = $atsRuns;
    }

    /**
     * Bulk AI Role Matching
     *
     * POST /api/ai/bulk-role-matching
     */
    // public function bulkRoleMatching(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'batch_size' => 'nullable|integer|min:1|max:10',
    //         'limit' => 'nullable|integer|min:1|max:500',
    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => false,
    //             'message' => 'Validation Failed.',
    //             'errors' => $validator->errors()
    //         ], 422);
    //     }

    //     $batchSize = (int) $request->input('batch_size', 5);

    //     $limit = (int) $request->input('limit', 100);
    //     $offset = (int)$request->input('offset', 0);

    //     try {

    //         $result = $this->batchService->process( $batchSize, $limit, $offset );

    //         return response()->json([
    //             'status' => true,
    //             'message' => 'AI Role Matching Completed.',
    //             'data' => $result

    //         ]);

    //     } catch (Throwable $e) {
    //         \Log::error(
    //             'Bulk AI Matching Error',
    //             [
    //                 'message' => $e->getMessage(),
    //                 'line' => $e->getLine(),
    //                 'file' => $e->getFile()
    //             ]
    //         );

    //         return response()->json([
    //             'status' => false,
    //             'message' => 'Bulk AI Matching Failed.',
    //             'error' => app()->environment('local')
    //                 ? $e->getMessage()
    //                 : null
    //         ], 500);
    //     }
    // }

    public function bulkRoleMatching(Request $request)
    {
        $data = $request->validate([
            'batch_size' => ['nullable','integer','min:1','max:' . (int) config('recruitment_ats.max_batch_size',3)],
            'limit' => ['nullable','integer','min:1','max:' . (int) config('recruitment_ats.max_bulk_limit',50000)],
            'force_reprocess' => ['nullable','boolean'],
            'force' => ['nullable','boolean'],
            'workers' => ['nullable','integer','min:1','max:' . (int) config('recruitment_ats.max_workers',8)],
        ]);
        if ((string) config('queue.default') === 'sync') return response()->json(['status'=>false,'message'=>'Bulk ATS matching requires an asynchronous queue connection.'],503);
        $force = (bool) ($data['force_reprocess'] ?? $data['force'] ?? false);
        $roleId=(int)($request->user()?->role_id??0);
        if($force && !in_array($roleId,array_map('intval',(array)config('recruitment_ats.force_reprocess_role_ids',[1])),true)){
            return response()->json(['status'=>false,'message'=>'You are not authorized to force a full reprocess.'],403);
        }
        try {
            $run=$this->atsRuns->start(
                (int)($request->user()?->getAuthIdentifier()??0),
                (int)($data['limit']??100),
                (int)($data['batch_size']??config('recruitment_ats.default_batch_size',2)),
                (int)($data['workers']??config('recruitment_ats.default_workers',3)),
                $force
            );
            for($i=0;$i<(int)$run->worker_count;$i++){ ProcessRecruitmentAtsRoleMatchingRunJob::dispatch((int)$run->sno)->onQueue(config('recruitment_ats.queue','ats-role-matching')); }
            return response()->json(['status'=>true,'message'=>'Bulk ATS role matching queued.','data'=>['run_uuid'=>$run->run_uuid,'target_count'=>(int)$run->target_count,'batch_size'=>(int)$run->batch_size,'workers'=>(int)$run->worker_count]],202);
        } catch(Throwable $e) {
            \Log::error('Bulk ATS compatibility endpoint failed',['message'=>$e->getMessage()]);
            return response()->json(['status'=>false,'message'=>'Bulk ATS matching failed.'],422);
        }
    }

    public function stats()
    {
        try {
            $statistics = $this->atsRuns->stats();

            return response()->json([
                'status' => true,
                'success' => true,
                'message' => 'Bulk AI statistics loaded successfully.',
                'data' => $statistics,
            ]);
        } catch (Throwable $e) {
            \Log::error('Bulk AI statistics failed', [
                'error' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);

            return response()->json([
                'status' => false,
                'success' => false,
                'code' => 'ATS_BULK_STATS_UNAVAILABLE',
                'message' => app()->environment('local', 'testing')
                    ? $e->getMessage()
                    : 'Unable to load bulk AI statistics. Verify the ATS v8 database migration and queue tables.',
                'data' => [],
            ], 503);
        }
    }
}