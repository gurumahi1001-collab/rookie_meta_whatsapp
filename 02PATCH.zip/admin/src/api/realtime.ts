import { getAccessTokenValue, getApiBaseUrl } from "./axios";

type RealtimeNotification = { id?: string; _id?: string; eventType?: string; title?: string; message?: string; createdAt?: string; [key: string]: unknown };
type Listener = (notification: RealtimeNotification) => void;
const listeners = new Set<Listener>();
let socket: WebSocket | null = null;
let retryTimer: number | null = null;
let retryAttempt = 0;
let stopped = false;

function makeSocketUrl(): string {
    const url = new URL(`${getApiBaseUrl().replace(/\/+$/, "")}/ws`);
    url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
    return url.toString();
}
function connect(): void {
    if (stopped || socket || typeof window === "undefined") return;
    const token = getAccessTokenValue();
    const protocols = token ? ["argus.v1", `argus-auth.${token}`] : ["argus.v1"];
    try {
        const current = new WebSocket(makeSocketUrl(), protocols);
        socket = current;
        current.onopen = () => { retryAttempt = 0; };
        current.onmessage = (event) => {
            try {
                const packet = JSON.parse(String(event.data));
                if (packet?.type !== "notification" || !packet.data) return;
                for (const listener of [...listeners]) listener(packet.data);
            } catch { /* Ignore malformed or unsupported server packets. */ }
        };
        current.onerror = () => { try { current.close(); } catch { /* no-op */ } };
        current.onclose = () => {
            if (socket === current) socket = null;
            scheduleReconnect();
        };
    } catch { scheduleReconnect(); }
}
function scheduleReconnect(): void {
    if (stopped || retryTimer !== null || listeners.size === 0) return;
    const delay = Math.min(30000, 1000 * (2 ** Math.min(retryAttempt, 5)));
    retryAttempt += 1;
    retryTimer = window.setTimeout(() => { retryTimer = null; connect(); }, delay);
}
export function subscribeToNotifications(listener: Listener): () => void {
    listeners.add(listener);
    stopped = false;
    connect();
    return () => {
        listeners.delete(listener);
        if (listeners.size) return;
        stopped = true;
        if (retryTimer !== null) { window.clearTimeout(retryTimer); retryTimer = null; }
        if (socket) { const current = socket; socket = null; current.close(); }
    };
}
