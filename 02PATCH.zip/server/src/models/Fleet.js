import mongoose from "mongoose";

const { Schema, model, models } = mongoose;

const fleetVehicleSchema = new Schema({
  fleetCode: { type: String, trim: true, uppercase: true, required: true, maxlength: 80 },
  vehicleName: { type: String, trim: true, required: true, maxlength: 200 },
  category: { type: String, trim: true, required: true, maxlength: 120 },
  registrationNo: { type: String, trim: true, uppercase: true, required: true, maxlength: 80 },
  chassisVinNo: { type: String, trim: true, maxlength: 120, default: "" },
  engineNo: { type: String, trim: true, maxlength: 120, default: "" },
  makeBrand: { type: String, trim: true, maxlength: 120, default: "" },
  modelVariant: { type: String, trim: true, maxlength: 120, default: "" },
  mfgYear: { type: String, trim: true, maxlength: 12, default: "" },
  siteLocation: { type: String, trim: true, maxlength: 500, default: "" },
  currentSiteLocation: { type: String, trim: true, maxlength: 500, default: "" },
  ownershipType: { type: String, trim: true, maxlength: 80, default: "Company Owned" },
  purchaseDate: { type: Date, default: null },
  purchaseCost: { type: Number, min: 0, default: 0 },
  vendorDealerName: { type: String, trim: true, maxlength: 200, default: "" },
  assignedOperator: { type: String, trim: true, maxlength: 180, default: "" },
  insurance_name: { type: String, trim: true, maxlength: 180, default: "" },
  insuranceProvider: { type: String, trim: true, maxlength: 180, default: "" },
  policyNumber: { type: String, trim: true, maxlength: 120, default: "" },
  annualPremium: { type: Number, min: 0, default: 0 },
  insuranceStatus: { type: String, enum: ["active", "expiring", "expired"], default: "active" },
  insuranceExpiryDate: { type: Date, default: null },
  financingBank: { type: String, trim: true, maxlength: 180, default: "" },
  monthlyEmi: { type: Number, min: 0, default: 0 },
  emiDueCycleDay: { type: Number, min: 1, max: 31, default: null },
  serviceStatus: { type: String, enum: ["ok", "due_soon", "overdue"], default: "ok" },
  lastServiceDate: { type: Date, default: null },
  nextServiceDueDate: { type: Date, default: null },
  serviceIntervalHours: { type: Number, min: 0, default: 0 },
  serviceInterval: { type: String, trim: true, maxlength: 120, default: "" },
  preferredWorkshop: { type: String, trim: true, maxlength: 200, default: "" },
  warrantyStatus: { type: String, trim: true, maxlength: 120, default: "" },
  status: { type: String, enum: ["active", "inactive"], default: "active", index: true },
  assignedVendorId: { type: Schema.Types.ObjectId, ref: "Vendor", default: null, index: true },
  assignedVendorName: { type: String, trim: true, maxlength: 200, default: "" },
  assignedAt: { type: Date, default: null },
  assignedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  bookedByRequisitionId: { type: Schema.Types.ObjectId, ref: "FleetRequisition", default: null, index: true },
  createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, { collection: "fleet_vehicles", timestamps: true, strict: "throw", versionKey: false });
fleetVehicleSchema.index({ fleetCode: 1 }, { unique: true, name: "fleet_code_unique" });
fleetVehicleSchema.index({ registrationNo: 1 }, { unique: true, name: "fleet_registration_unique" });
fleetVehicleSchema.index({ assignedVendorId: 1, status: 1 });
fleetVehicleSchema.methods.toSafeJSON = function () {
  const out = this.toObject({ depopulate: true });
  out.id = String(this._id);
  out.assignedVendorId = this.assignedVendorId ? String(this.assignedVendorId) : null;
  out.assignedBy = this.assignedBy ? String(this.assignedBy) : null;
  out.bookedByRequisitionId = this.bookedByRequisitionId ? String(this.bookedByRequisitionId) : null;
  delete out._id;
  return out;
};

const fleetTripDocumentSchema = new Schema({
  id: { type: String, required: true, maxlength: 80 },
  storageKey: { type: String, required: true, maxlength: 1000 },
  originalName: { type: String, trim: true, required: true, maxlength: 500 },
  mimeType: { type: String, trim: true, lowercase: true, maxlength: 150, default: "application/octet-stream" },
  size: { type: Number, min: 0, default: 0 },
  checksum: { type: String, trim: true, maxlength: 128, default: "" },
  uploadedAt: { type: Date, default: Date.now },
  uploadedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, { _id: false, versionKey: false, strict: "throw" });

const fleetRequisitionSchema = new Schema({
  requisitionNo: { type: String, trim: true, uppercase: true, required: true, unique: true, maxlength: 80 },
  vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", required: true, index: true },
  vendorName: { type: String, trim: true, required: true, maxlength: 200 },
  fleetId: { type: Schema.Types.ObjectId, ref: "FleetVehicle", default: null, index: true },
  fleetCode: { type: String, trim: true, maxlength: 80, default: "" },
  vehicleName: { type: String, trim: true, maxlength: 200, default: "" },
  category: { type: String, trim: true, maxlength: 120, default: "" },
  projectId: { type: Schema.Types.ObjectId, ref: "Project", default: null },
  projectName: { type: String, trim: true, maxlength: 255, default: "" },
  requestedAt: { type: Date, default: Date.now },
  requestedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  requestRemarks: { type: String, trim: true, maxlength: 3000, default: "" },
  preferredPickupDate: { type: Date, default: null },
  approvedAt: { type: Date, default: null },
  approvedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  pickupTime: { type: Date, default: null },
  startKm: { type: Number, min: 0, default: null },
  pickupLocation: { type: String, trim: true, maxlength: 500, default: "" },
  driverName: { type: String, trim: true, maxlength: 180, default: "" },
  pickupRemarks: { type: String, trim: true, maxlength: 3000, default: "" },
  returnTime: { type: Date, default: null },
  endKm: { type: Number, min: 0, default: null },
  totalKm: { type: Number, min: 0, default: null },
  returnDocuments: { type: [fleetTripDocumentSchema], default: [] },
  claimRequested: { type: Boolean, default: false },
  claimReference: { type: String, trim: true, maxlength: 160, default: "" },
  status: { type: String, enum: ["Requested", "Approved", "Picked", "Returned", "Completed", "Rejected"], default: "Requested", index: true },
  decisionRemarks: { type: String, trim: true, maxlength: 3000, default: "" },
  createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, { collection: "fleet_requisitions", timestamps: true, strict: "throw", versionKey: false });
fleetRequisitionSchema.index({ vendorId: 1, status: 1, requestedAt: -1 });
fleetRequisitionSchema.methods.toSafeJSON = function () {
  const out = this.toObject({ depopulate: true });
  out.id = String(this._id);
  out.vendorId = String(this.vendorId);
  out.fleetId = this.fleetId ? String(this.fleetId) : null;
  out.projectId = this.projectId ? String(this.projectId) : null;
  out.returnDocuments = (this.returnDocuments || []).map((doc) => ({
    id: doc.id,
    originalName: doc.originalName,
    mimeType: doc.mimeType,
    size: doc.size,
    uploadedAt: doc.uploadedAt,
    downloadUrl: `/fleet/requisitions/${String(this._id)}/documents/${encodeURIComponent(doc.id)}`,
  }));
  delete out._id;
  return out;
};

const fleetClaimBillSchema = new Schema({
  claimNo: { type: String, trim: true, uppercase: true, required: true, unique: true, maxlength: 80 },
  vendorId: { type: Schema.Types.ObjectId, ref: "Vendor", required: true, index: true },
  vendorName: { type: String, trim: true, required: true, maxlength: 200 },
  requisitionId: { type: Schema.Types.ObjectId, ref: "FleetRequisition", default: null },
  fleetId: { type: Schema.Types.ObjectId, ref: "FleetVehicle", default: null },
  fleetCode: { type: String, trim: true, maxlength: 80, default: "" },
  claimType: { type: String, trim: true, required: true, maxlength: 160 },
  claimReference: { type: String, trim: true, maxlength: 160, default: "" },
  claimDate: { type: Date, default: Date.now },
  amount: { type: Number, required: true, min: 0 },
  // Existing historical fleet claims without currency are treated as USD for display only.
  currency: { type: String, trim: true, uppercase: true, maxlength: 3, default: "USD", match: /^[A-Z]{3}$/ },
  description: { type: String, trim: true, required: true, maxlength: 3000 },
  attachmentName: { type: String, trim: true, maxlength: 500, default: "" },
  attachmentStorageKey: { type: String, trim: true, maxlength: 1000, default: "" },
  attachmentMimeType: { type: String, trim: true, lowercase: true, maxlength: 150, default: "" },
  attachmentSize: { type: Number, min: 0, default: 0 },
  attachmentChecksum: { type: String, trim: true, maxlength: 128, default: "" },
  attachmentUploadedAt: { type: Date, default: null },
  status: { type: String, enum: ["Pending", "Approved", "Rejected", "Settled"], default: "Pending", index: true },
  reviewRemarks: { type: String, trim: true, maxlength: 3000, default: "" },
  settledAmount: { type: Number, min: 0, default: null },
  settlementRemarks: { type: String, trim: true, maxlength: 3000, default: "" },
  reviewedAt: { type: Date, default: null },
  reviewedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  settledAt: { type: Date, default: null },
  settledBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
  updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, { collection: "fleet_claim_bills", timestamps: true, strict: "throw", versionKey: false });
fleetClaimBillSchema.index({ vendorId: 1, status: 1, claimDate: -1 });
fleetClaimBillSchema.methods.toSafeJSON = function () {
  const out = this.toObject({ depopulate: true });
  out.id = String(this._id);
  out.vendorId = String(this.vendorId);
  out.requisitionId = this.requisitionId ? String(this.requisitionId) : null;
  out.fleetId = this.fleetId ? String(this.fleetId) : null;
  out.hasAttachment = Boolean(this.attachmentStorageKey);
  out.attachmentUrl = this.attachmentStorageKey ? `/fleet/claims/${String(this._id)}/attachment` : null;
  delete out.attachmentStorageKey;
  delete out._id;
  return out;
};

const fleetSettingsSchema = new Schema({
  key: { type: String, unique: true, default: "fleet", immutable: true },
  vehicleCategories: { type: [{ name: { type: String, trim: true, required: true }, description: { type: String, trim: true, default: "" }, active: { type: Boolean, default: true } }], default: [] },
  claimTypes: { type: [{ name: { type: String, trim: true, required: true }, description: { type: String, trim: true, default: "" }, active: { type: Boolean, default: true } }], default: [] },
  updatedBy: { type: Schema.Types.ObjectId, ref: "User", default: null },
}, { collection: "fleet_settings", timestamps: true, strict: "throw", versionKey: false });

export const FleetVehicle = models.FleetVehicle || model("FleetVehicle", fleetVehicleSchema);
export const FleetRequisition = models.FleetRequisition || model("FleetRequisition", fleetRequisitionSchema);
export const FleetClaimBill = models.FleetClaimBill || model("FleetClaimBill", fleetClaimBillSchema);
export const FleetSettings = models.FleetSettings || model("FleetSettings", fleetSettingsSchema);
export default FleetVehicle;
