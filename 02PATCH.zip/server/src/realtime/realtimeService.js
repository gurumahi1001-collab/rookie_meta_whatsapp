import jwt from "jsonwebtoken";
import WebSocket, { WebSocketServer } from "ws";
import env from "../config/env.js";
import User from "../models/User.js";
import Role from "../models/Role.js";

const clientsByUser = new Map();
let socketServer = null;

function apiSocketPath() {
    try { return `${new URL(env.app.apiUrl).pathname.replace(/\/+$/, "")}/ws`; }
    catch { return "/api/v1/ws"; }
}
function requestToken(request) {
    const raw = String(request.headers["sec-websocket-protocol"] || "");
    const offered = raw.split(",").map((value) => value.trim());
    const authProtocol = offered.find((value) => value.startsWith("argus-auth."));
    if (authProtocol) return authProtocol.slice("argus-auth.".length);
    const cookies = String(request.headers.cookie || "").split(";").map((part) => part.trim());
    for (const name of ["argus_access_token", "accessToken", "token"]) {
        const item = cookies.find((part) => part.startsWith(`${name}=`));
        if (item) { try { return decodeURIComponent(item.slice(name.length + 1)); } catch { return ""; } }
    }
    return "";
}
async function resolveIdentity(token) {
    if (!token) return null;
    try {
        const payload = jwt.verify(token, env.jwt.access.secret, { algorithms: ["HS256"], issuer: env.jwt.issuer, audience: env.jwt.audience, clockTolerance: 5 });
        if (!payload || typeof payload !== "object" || payload.type !== "access" || !payload.sub || !payload.userType) return null;
        const user = await User.findOne({ _id: payload.sub, userType: payload.userType, status: "active" }).select("_id userType roleId").lean();
        if (!user?.roleId) return null;
        const role = await Role.findOne({ _id: user.roleId, active: true }).select("realm allowedUserTypes").lean();
        if (!role) return null;
        const userType = String(user.userType || "").trim().toLowerCase();
        const allowedUserTypes = Array.isArray(role.allowedUserTypes) ? role.allowedUserTypes : [];
        if (allowedUserTypes.length && !allowedUserTypes.includes(userType)) return null;
        const realm = userType === "vendor" ? env.auth.realms.vendor : env.auth.realms.admin;
        if (role.realm !== "both" && role.realm !== realm) return null;
        return { userId: String(user._id), userType: user.userType, expiresAt: Number.isFinite(Number(payload.exp)) ? Number(payload.exp) * 1000 : null };
    } catch { return null; }
}
function removeClient(userId, client) {
    const set = clientsByUser.get(userId);
    if (!set) return;
    set.delete(client);
    if (!set.size) clientsByUser.delete(userId);
}

export function publishToUser(recipientId, notification) {
    const userId = String(recipientId || "");
    const clients = clientsByUser.get(userId);
    if (!clients?.size) return 0;
    const packet = JSON.stringify({ type: "notification", data: notification });
    let delivered = 0;
    for (const client of clients) {
        if (client.readyState !== WebSocket.OPEN) continue;
        try { client.send(packet); delivered += 1; } catch { removeClient(userId, client); }
    }
    return delivered;
}

export function initializeRealtime(server) {
    if (socketServer) return socketServer;
    const allowedOrigins = new Set((env.cors?.allowedOrigins || []).map((value) => String(value).replace(/\/+$/, "")));
    const wss = new WebSocketServer({ noServer: true, handleProtocols: (protocols) => protocols.has("argus.v1") ? "argus.v1" : false, maxPayload: 16 * 1024 });
    server.on("upgrade", async (request, socket, head) => {
        let pathname = "";
        try { pathname = new URL(request.url || "/", "http://localhost").pathname; } catch { socket.destroy(); return; }
        if (pathname !== apiSocketPath()) return;
        const origin = String(request.headers.origin || "").replace(/\/+$/, "");
        if (origin && (!allowedOrigins.size || !allowedOrigins.has(origin))) { socket.write("HTTP/1.1 403 Forbidden\r\n\r\n"); socket.destroy(); return; }
        const identity = await resolveIdentity(requestToken(request));
        if (!identity) { socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n"); socket.destroy(); return; }
        wss.handleUpgrade(request, socket, head, (client) => {
            client.userId = identity.userId;
            const set = clientsByUser.get(identity.userId) || new Set();
            set.add(client); clientsByUser.set(identity.userId, set);
            let expiryTimer = null;
            if (identity.expiresAt) {
                const remainingMs = Math.max(0, identity.expiresAt - Date.now());
                expiryTimer = setTimeout(() => {
                    if (client.readyState === WebSocket.OPEN) client.close(4001, "Access token expired");
                }, remainingMs);
                expiryTimer.unref?.();
            }
            client.on("close", () => { if (expiryTimer) clearTimeout(expiryTimer); removeClient(identity.userId, client); });
            client.on("error", () => { if (expiryTimer) clearTimeout(expiryTimer); removeClient(identity.userId, client); });
            client.on("message", () => { /* Server-push only; client messages are intentionally ignored. */ });
            wss.emit("connection", client, request, identity);
        });
    });
    wss.on("close", () => clientsByUser.clear());
    socketServer = wss;
    return wss;
}

export function closeRealtime() {
    if (!socketServer) return Promise.resolve();
    const current = socketServer;
    socketServer = null;
    for (const clients of clientsByUser.values()) {
        for (const client of clients) {
            try { client.close(1001, "Server shutting down"); } catch { client.terminate(); }
        }
    }
    clientsByUser.clear();
    return new Promise((resolve) => {
        const fallback = setTimeout(() => { try { current.close(); } catch {} resolve(); }, 2000);
        current.close(() => { clearTimeout(fallback); resolve(); });
    });
}
