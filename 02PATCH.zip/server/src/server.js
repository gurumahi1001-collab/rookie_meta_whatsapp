import http from "node:http";
import app from "./app.js";
import env from "./config/env.js";
import { connectDatabase, shutdownDatabase } from "./config/database.js";
import { initializeRealtime, closeRealtime } from "./realtime/realtimeService.js";

const server = http.createServer(app);
let shuttingDown = false;

async function shutdown(signal) {
    if (shuttingDown) return;
    shuttingDown = true;
    console.info(`[ARGUS] ${signal} received; shutting down.`);
    const force = setTimeout(() => process.exit(1), 15000);
    force.unref();
    try {
        await closeRealtime();
        await new Promise((resolve) => server.close(resolve));
        await shutdownDatabase();
        clearTimeout(force);
        process.exit(0);
    } catch (error) {
        console.error("[ARGUS] graceful shutdown failed", error);
        process.exit(1);
    }
}

try {
    await connectDatabase();
    initializeRealtime(server);
    server.listen(env.app.port, env.app.host, () => {
        console.info(`[ARGUS] API and WebSocket listening on ${env.app.host}:${env.app.port}`);
    });
} catch (error) {
    console.error("[ARGUS] startup failed", error);
    await shutdownDatabase().catch(() => undefined);
    process.exit(1);
}

process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));
