import { mailer, emailConfig } from "../../config/email.js";
import CompanySetting, { COMPANY_SETTING_KEY } from "../../models/CompanySetting.js";
import Vendor from "../../models/Vendor.js";
import User from "../../models/User.js";

const clean = (value) => String(value ?? "").trim();
const html = (value) => clean(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");

function makeBody({ title, message, details = [] }) {
    const rows = (Array.isArray(details) ? details : []).filter((item) => item && clean(item.label)).map((item) =>
        `<tr><td style="padding:8px 12px;border-bottom:1px solid #e8edf3;color:#64748b;font-size:13px">${html(item.label)}</td><td style="padding:8px 12px;border-bottom:1px solid #e8edf3;color:#0f172a;font-size:13px;font-weight:600">${html(item.value || "—")}</td></tr>`,
    ).join("");
    const safeTitle = html(title || "ARGUS workflow update");
    const safeMessage = html(message || "A workflow item has been updated.");
    return {
        html: `<div style="margin:0;background:#f8fafc;padding:28px;font-family:Arial,Helvetica,sans-serif;color:#0f172a"><div style="max-width:640px;margin:0 auto;background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden"><div style="background:#991b1b;padding:20px 24px;color:#fff;font-size:18px;font-weight:700">ARGUS</div><div style="padding:24px"><h2 style="margin:0 0 12px;font-size:18px">${safeTitle}</h2><p style="margin:0 0 18px;line-height:1.6;color:#475569">${safeMessage}</p>${rows ? `<table style="width:100%;border-collapse:collapse">${rows}</table>` : ""}<p style="margin:22px 0 0;color:#94a3b8;font-size:11px">Automated message from ARGUS. Please do not reply to this notification.</p></div></div></div>`,
        text: `${clean(title)}\n\n${clean(message)}\n\n${(details || []).map((item) => `${clean(item.label)}: ${clean(item.value)}`).join("\n")}`,
    };
}

async function deliver({ to, subject, title, message, details }) {
    const recipients = [...new Set((Array.isArray(to) ? to : [to]).map((value) => clean(value).toLowerCase()).filter((value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)))];
    if (!recipients.length) return { sent: false, reason: "no_recipient" };
    if (!emailConfig.enabled || !mailer) {
        console.warn("[workflowEmail] delivery skipped: SMTP is not enabled or configured", { subject, recipientCount: recipients.length });
        return { sent: false, reason: "smtp_not_configured" };
    }
    try {
        const body = makeBody({ title, message, details });
        const from = emailConfig.from.email ? { name: emailConfig.from.name, address: emailConfig.from.email } : undefined;
        await mailer.sendMail({ from, to: recipients.join(", "), subject: clean(subject) || "ARGUS workflow update", ...body });
        return { sent: true, recipientCount: recipients.length };
    } catch (error) {
        console.error("[workflowEmail] delivery failed", error?.message || error);
        return { sent: false, reason: "delivery_failed" };
    }
}

export async function sendVendorWorkflowEmail({ vendorId, subject, title, message, details = [] } = {}) {
    try {
        if (!vendorId) return { sent: false, reason: "vendor_missing" };
        const [vendor, users] = await Promise.all([
            Vendor.findById(vendorId).select("companyName contact.email secondaryContact.email").lean(),
            User.find({ vendorId, userType: "vendor", status: "active" }).select("email").lean(),
        ]);
        if (!vendor) return { sent: false, reason: "vendor_not_found" };
        const recipients = [vendor.contact?.email, vendor.secondaryContact?.email, ...(users || []).map((user) => user.email)];
        return await deliver({ to: recipients, subject, title: title || subject, message: message || `An update is available for ${vendor.companyName}.`, details });
    } catch (error) {
        console.error("[workflowEmail] vendor email preparation failed", error?.message || error);
        return { sent: false, reason: "preparation_failed" };
    }
}

export async function sendCompanyWorkflowEmail({ subject, title, message, details = [] } = {}) {
    try {
        const company = await CompanySetting.findOne({ settingKey: COMPANY_SETTING_KEY, active: true }).select("contactEmail legalName").lean();
        if (!company?.contactEmail) {
            console.warn("[workflowEmail] company email skipped: configure Company Profile contact email", { subject });
            return { sent: false, reason: "company_email_missing" };
        }
        return await deliver({ to: company.contactEmail, subject, title: title || subject, message: message || "An ARGUS workflow item requires attention.", details: [{ label: "Company", value: company.legalName || "ARGUS" }, ...details] });
    } catch (error) {
        console.error("[workflowEmail] company email preparation failed", error?.message || error);
        return { sent: false, reason: "preparation_failed" };
    }
}
