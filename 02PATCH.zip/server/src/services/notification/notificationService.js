import mongoose from "mongoose";
import Notification from "../../models/Notification.js";
import Role from "../../models/Role.js";
import User from "../../models/User.js";
import Project from "../../models/Project.js";
import Task from "../../models/Task.js";
import { publishToUser } from "../../realtime/realtimeService.js";

export class NotificationServiceError extends Error {
    constructor(message, { code = "NOTIFICATION_ERROR", statusCode = 400, details = null } = {}) {
        super(message);
        this.name = "NotificationServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
        Error.captureStackTrace?.(this, NotificationServiceError);
    }
}

function objectId(id, field = "id") {
    const value = String(id ?? "").trim();
    if (!mongoose.Types.ObjectId.isValid(value)) {
        throw new NotificationServiceError(`Invalid ${field}.`, {
            code: "INVALID_IDENTIFIER",
            statusCode: 400,
            details: { field },
        });
    }
    return new mongoose.Types.ObjectId(value);
}

export async function createNotification({
    recipientId,
    eventType,
    title,
    message,
    payload = null,
}) {
    const row = await Notification.create({
        recipientId: objectId(recipientId, "recipientId"),
        eventType: String(eventType || "").trim(),
        title: String(title || "").trim(),
        message: String(message || "").trim(),
        payload,
    });

    const safe = row.toSafeJSON();
    publishToUser(String(row.recipientId), safe);
    return safe;
}

export async function notifyWorkspaceOwners({
    eventType,
    title,
    message,
    payload = null,
    excludeUserId = null,
}) {
    const ownerRoles = await Role.find({
        ownerRole: true,
        active: true,
    }).select("_id").lean();

    const roleIds = ownerRoles.map((role) => role._id);
    if (!roleIds.length) return [];

    const query = {
        roleId: { $in: roleIds },
        userType: { $in: ["admin", "internal"] },
        status: "active",
    };

    if (excludeUserId && mongoose.Types.ObjectId.isValid(String(excludeUserId))) {
        query._id = { $ne: objectId(excludeUserId, "excludeUserId") };
    }

    const owners = await User.find(query).select("_id").lean();

    if (!owners.length) return [];

    const rows = await Notification.insertMany(
        owners.map((owner) => ({
            recipientId: owner._id,
            eventType,
            title,
            message,
            payload,
        })),
    );

    return rows.map((row) => { const safe = row.toSafeJSON(); publishToUser(String(row.recipientId), safe); return safe; });
}

/** Deliver vendor workflow notifications only to active vendor_admin users linked to a vendor. */
export async function notifyVendorAdmins({ vendorId, eventType, title, message, payload = null } = {}) {
    const vendorObjectId = objectId(vendorId, "vendorId");
    const roles = await Role.find({ key: "vendor_admin", active: true }).select("_id").lean();
    const roleIds = roles.map((role) => role._id);
    if (!roleIds.length) return [];

    const recipients = await User.find({
        vendorId: vendorObjectId,
        roleId: { $in: roleIds },
        userType: "vendor",
        status: "active",
    }).select("_id").lean();
    if (!recipients.length) return [];

    const rows = await Notification.insertMany(recipients.map((recipient) => ({
        recipientId: recipient._id,
        eventType: String(eventType || "quotation_update").trim(),
        title: String(title || "Quotation update").trim(),
        message: String(message || "A quotation has been updated.").trim(),
        payload,
    })));
    return rows.map((row) => { const safe = row.toSafeJSON(); publishToUser(String(row.recipientId), safe); return safe; });
}

/**
 * Deliver project/task notifications to this vendor's active administrators and
 * the explicit vendor staff assignees. The tenant scope is enforced in the query.
 */
export async function notifyVendorTaskStakeholders({
    vendorId,
    assignedUserIds = [],
    excludeUserId = null,
    eventType,
    title,
    message,
    payload = null,
} = {}) {
    if (!vendorId || !mongoose.Types.ObjectId.isValid(String(vendorId))) return [];
    const vendorObjectId = objectId(vendorId, "vendorId");
    const roleRows = await Role.find({ key: "vendor_admin", active: true }).select("_id").lean();
    const roleIds = roleRows.map((role) => role._id);
    const assigneeIds = [...new Set((Array.isArray(assignedUserIds) ? assignedUserIds : [])
        .map((id) => String(id || ""))
        .filter((id) => mongoose.Types.ObjectId.isValid(id)))];
    const or = [];
    if (roleIds.length) or.push({ roleId: { $in: roleIds } });
    if (assigneeIds.length) or.push({ _id: { $in: assigneeIds.map((id) => objectId(id)) } });
    if (!or.length) return [];
    const query = { vendorId: vendorObjectId, userType: "vendor", status: "active", $or: or };
    if (excludeUserId && mongoose.Types.ObjectId.isValid(String(excludeUserId))) {
        query._id = { $ne: objectId(excludeUserId, "excludeUserId") };
    }
    const recipients = await User.find(query).select("_id").lean();
    if (!recipients.length) return [];
    const rows = await Notification.insertMany(recipients.map((recipient) => ({
        recipientId: recipient._id,
        eventType: String(eventType || "project_update").trim(),
        title: String(title || "Project update").trim(),
        message: String(message || "A project task has been updated.").trim(),
        payload,
    })));
    return rows.map((row) => { const safe = row.toSafeJSON(); publishToUser(String(row.recipientId), safe); return safe; });
}

/** Notify a project's vendor admins and staff assigned to any task in the project. */
export async function notifyVendorProjectStakeholders({
    projectId,
    excludeUserId = null,
    eventType,
    title,
    message,
    payload = null,
} = {}) {
    if (!projectId || !mongoose.Types.ObjectId.isValid(String(projectId))) return [];
    const project = await Project.findById(projectId).select("_id name vendorId").lean();
    if (!project?.vendorId) return [];
    const tasks = await Task.find({ projectId: project._id }).select("ownerIds assignedStaff").lean();
    const assignedUserIds = [];
    for (const task of tasks) {
        for (const id of task.ownerIds || []) assignedUserIds.push(String(id));
        for (const assignee of task.assignedStaff || []) if (assignee.userId) assignedUserIds.push(String(assignee.userId));
    }
    return notifyVendorTaskStakeholders({
        vendorId: project.vendorId,
        assignedUserIds,
        excludeUserId,
        eventType,
        title,
        message: message || `${project.name || "A project"} has been updated.`,
        payload: { projectId: String(project._id), projectName: project.name || "", ...(payload || {}) },
    });
}

export async function listNotifications({ recipientId, unreadOnly = false, limit = 20 } = {}) {
    const safeLimit = Math.min(100, Math.max(1, Number(limit) || 20));
    const query = { recipientId: objectId(recipientId, "recipientId") };

    if (unreadOnly) query.readAt = null;

    const [rows, unreadCount] = await Promise.all([
        Notification.find(query)
            .sort({ createdAt: -1, _id: -1 })
            .limit(safeLimit),
        Notification.countDocuments({
            recipientId: query.recipientId,
            readAt: null,
        }),
    ]);

    return {
        data: rows.map((row) => row.toSafeJSON()),
        unreadCount,
    };
}

export async function markNotificationRead({ id, recipientId }) {
    const row = await Notification.findOneAndUpdate(
        {
            _id: objectId(id),
            recipientId: objectId(recipientId, "recipientId"),
        },
        {
            $set: { readAt: new Date() },
        },
        { new: true },
    );

    if (!row) {
        throw new NotificationServiceError("Notification not found.", {
            code: "NOTIFICATION_NOT_FOUND",
            statusCode: 404,
        });
    }

    return row.toSafeJSON();
}

export async function markAllNotificationsRead({ recipientId }) {
    const result = await Notification.updateMany(
        {
            recipientId: objectId(recipientId, "recipientId"),
            readAt: null,
        },
        {
            $set: { readAt: new Date() },
        },
    );

    return {
        modifiedCount: Number(result.modifiedCount || 0),
    };
}
