import mongoose from "mongoose";
import { randomUUID } from "node:crypto";
import * as storageService from "../storage/storageService.js";
import { FleetVehicle, FleetRequisition, FleetClaimBill, FleetSettings } from "../../models/Fleet.js";
import Vendor from "../../models/Vendor.js";
import Project from "../../models/Project.js";
import auditService from "../audit/auditService.js";
import { notifyWorkspaceOwners, notifyVendorAdmins } from "../notification/notificationService.js";
import { sendCompanyWorkflowEmail, sendVendorWorkflowEmail } from "../email/workflowEmailService.js";

const INTERNAL = new Set(["admin", "internal"]);
const text = (v) => String(v ?? "").trim();
const num = (v, d = 0) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const oid = (v, field = "id") => {
  if (!mongoose.isValidObjectId(v)) throw new FleetServiceError(`Invalid ${field}.`, { code: `INVALID_${field.toUpperCase()}`, statusCode: 422 });
  return new mongoose.Types.ObjectId(v);
};
const actorId = (actor) => mongoose.isValidObjectId(actor?.userId) ? new mongoose.Types.ObjectId(actor.userId) : null;
const isInternal = (actor) => INTERNAL.has(text(actor?.userType).toLowerCase());
const isVendor = (actor) => text(actor?.userType).toLowerCase() === "vendor";

export class FleetServiceError extends Error {
  constructor(message, { code = "FLEET_ERROR", statusCode = 400, details = undefined } = {}) {
    super(message); this.name = "FleetServiceError"; this.code = code; this.statusCode = statusCode; this.details = details;
  }
}

function assertActor(actor) {
  if (!actor?.userId || !mongoose.isValidObjectId(actor.userId)) throw new FleetServiceError("Authentication is required.", { code: "AUTHENTICATION_REQUIRED", statusCode: 401 });
  if (!isInternal(actor) && !isVendor(actor)) throw new FleetServiceError("This account cannot access fleet management.", { code: "FLEET_ACCESS_FORBIDDEN", statusCode: 403 });
  if (isVendor(actor) && !mongoose.isValidObjectId(actor.vendorId)) throw new FleetServiceError("Your account is not linked to a vendor.", { code: "VENDOR_SCOPE_MISSING", statusCode: 403 });
}
function assertInternal(actor) { assertActor(actor); if (!isInternal(actor)) throw new FleetServiceError("Only internal users can perform this action.", { code: "FLEET_ACTION_FORBIDDEN", statusCode: 403 }); }
function serialize(row) { return row?.toSafeJSON ? row.toSafeJSON() : row; }
function cleanDate(value, label) { if (value === undefined || value === null || value === "") return null; const d = new Date(value); if (Number.isNaN(d.getTime())) throw new FleetServiceError(`Invalid ${label}.`, { code: `INVALID_${label.toUpperCase().replace(/\s/g, "_")}`, statusCode: 422 }); return d; }
function actorAudit(actor) { return { userId: actor?.userId, userType: actor?.userType, role: actor?.role, vendorId: actor?.vendorId, actor }; }
async function writeAudit(action, module, row, actor, request) {
  try { await auditService.recordAudit({ action, module, title: `${module} ${action.replace(/_/g, " ")}`, description: row?.fleetCode || row?.requisitionNo || row?.claimNo || row?.vehicleName || "", actor: actor?.actor || actor, request, entityType: module, entityId: row?._id ? String(row._id) : "", entityName: row?.fleetCode || row?.requisitionNo || row?.claimNo || row?.vehicleName || "", vendorId: actor?.vendorId || null }); }
  catch (error) { console.error("[fleetService] audit write failed", error); }
}
function listQuery(actor, query = {}) {
  const filter = {};
  if (isVendor(actor)) filter.status = "active";
  const search = text(query.search);
  if (search) {
    const searchFields = isVendor(actor) ? ["fleetCode", "vehicleName", "registrationNo", "category"] : ["fleetCode", "vehicleName", "registrationNo", "category", "assignedVendorName"];
    filter.$or = searchFields.map((key) => ({ [key]: { $regex: search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), $options: "i" } }));
  }
  if (text(query.status) && !isVendor(actor)) filter.status = text(query.status);
  if (text(query.category)) filter.category = text(query.category);
  return filter;
}

const VEHICLE_FIELDS = ["fleetCode", "vehicleName", "category", "registrationNo", "chassisVinNo", "engineNo", "makeBrand", "modelVariant", "mfgYear", "siteLocation", "currentSiteLocation", "ownershipType", "purchaseDate", "purchaseCost", "vendorDealerName", "assignedOperator", "insurance_name", "insuranceProvider", "policyNumber", "annualPremium", "insuranceStatus", "insuranceExpiryDate", "financingBank", "monthlyEmi", "emiDueCycleDay", "serviceStatus", "lastServiceDate", "nextServiceDueDate", "serviceIntervalHours", "serviceInterval", "preferredWorkshop", "warrantyStatus", "status"];
function vehiclePatch(body, isCreate = false) {
  const out = {};
  for (const field of VEHICLE_FIELDS) if (body?.[field] !== undefined) out[field] = body[field];
  for (const field of ["purchaseDate", "insuranceExpiryDate", "lastServiceDate", "nextServiceDueDate"]) if (out[field] !== undefined) out[field] = cleanDate(out[field], field);
  for (const field of ["purchaseCost", "annualPremium", "monthlyEmi", "serviceIntervalHours"]) if (out[field] !== undefined) { out[field] = num(out[field], NaN); if (!Number.isFinite(out[field]) || out[field] < 0) throw new FleetServiceError(`${field} must be a non-negative number.`, { code: "INVALID_FLEET_VALUE", statusCode: 422 }); }
  // A vehicle without a monthly EMI has no EMI cycle day. Treat blank/zero EMI as non-financed.
  if (out.monthlyEmi !== undefined && out.monthlyEmi <= 0) {
    out.emiDueCycleDay = null;
  } else if (out.emiDueCycleDay !== undefined) {
    const rawDueDay = out.emiDueCycleDay;
    if (rawDueDay === "" || rawDueDay === null) {
      out.emiDueCycleDay = null;
    } else {
      out.emiDueCycleDay = num(rawDueDay, NaN);
      if (!Number.isInteger(out.emiDueCycleDay) || out.emiDueCycleDay < 1 || out.emiDueCycleDay > 31) {
        throw new FleetServiceError("EMI due cycle day must be between 1 and 31.", { code: "INVALID_EMI_DUE_DAY", statusCode: 422 });
      }
    }
  }
  if (isCreate) { out.fleetCode = text(out.fleetCode).toUpperCase(); out.registrationNo = text(out.registrationNo).toUpperCase(); out.vehicleName = text(out.vehicleName); out.category = text(out.category); if (!out.fleetCode || !out.registrationNo || !out.vehicleName || !out.category) throw new FleetServiceError("Fleet code, vehicle name, category and registration number are required.", { code: "FLEET_REQUIRED_FIELDS", statusCode: 422 }); }
  if (out.fleetCode !== undefined) out.fleetCode = text(out.fleetCode).toUpperCase();
  if (out.registrationNo !== undefined) out.registrationNo = text(out.registrationNo).toUpperCase();
  return out;
}

export async function listVehicles({ actor, ...query }) {
  assertActor(actor);
  const filter = listQuery(actor, query);
  const page = Math.max(1, Math.floor(num(query.page, 1)));
  const limit = Math.min(100, Math.max(1, Math.floor(num(query.limit, 50))));
  const [rows, total] = await Promise.all([FleetVehicle.find(filter).sort({ updatedAt: -1 }).skip((page - 1) * limit).limit(limit), FleetVehicle.countDocuments(filter)]);
  const rowIds = rows.map((row) => row._id);
  const lockIds = rows.map((row) => row.bookedByRequisitionId).filter(Boolean);
  const activeRequests = rowIds.length ? await FleetRequisition.find({
    $or: [
      { fleetId: { $in: rowIds }, status: { $in: ["Approved", "Picked", "Returned"] } },
      ...(lockIds.length ? [{ _id: { $in: lockIds } }] : []),
    ],
  }).select("fleetId vendorId vendorName status requisitionNo").lean() : [];
  const requestByFleet = new Map(activeRequests.filter((item) => ["Approved", "Picked", "Returned"].includes(item.status)).map((item) => [String(item.fleetId), item]));
  const requestById = new Map(activeRequests.map((item) => [String(item._id), item]));
  const data = rows.map((row) => {
    const lockId = row.bookedByRequisitionId ? String(row.bookedByRequisitionId) : null;
    const request = (lockId ? requestById.get(lockId) : null) || requestByFleet.get(String(row._id)) || null;
    const isBooked = Boolean(lockId || request);
    const safe = serialize(row);
    const availability = { availabilityStatus: isBooked ? "Booked" : "Available", assignedVendorName: request?.vendorName || row.assignedVendorName || "", assignedVendorId: request?.vendorId ? String(request.vendorId) : (row.assignedVendorId ? String(row.assignedVendorId) : null), bookedByRequisitionId: lockId || (request ? String(request._id) : null) };
    if (isVendor(actor)) return { id: safe.id, fleetCode: safe.fleetCode, vehicleName: safe.vehicleName, category: safe.category, registrationNo: safe.registrationNo, makeBrand: safe.makeBrand, modelVariant: safe.modelVariant, mfgYear: safe.mfgYear, siteLocation: safe.siteLocation, currentSiteLocation: safe.currentSiteLocation, status: safe.status, availabilityStatus: availability.availabilityStatus };
    return { ...safe, ...availability };
  });
  return { data, pagination: { page, limit, total, pages: Math.ceil(total / limit) } };
}
export async function createVehicle(payload, actor, request) {
  assertInternal(actor);
  const patch = vehiclePatch(payload, true);
  const row = await FleetVehicle.create({ ...patch, assignedVendorId: null, assignedVendorName: "", assignedAt: null, assignedBy: null, bookedByRequisitionId: null, createdBy: actorId(actor), updatedBy: actorId(actor) });
  await writeAudit("created", "fleet_vehicle", row, actor, request);
  return serialize(row);
}
export async function updateVehicle(id, payload, actor, request) {
  assertInternal(actor);
  const row = await FleetVehicle.findById(oid(id, "fleetId"));
  if (!row) throw new FleetServiceError("Fleet vehicle was not found.", { code: "FLEET_NOT_FOUND", statusCode: 404 });
  if (payload?.assignedVendorId !== undefined || payload?.assignedVendorName !== undefined) {
    throw new FleetServiceError("Vendor assignment is controlled by an approved fleet requisition. Submit a vendor request and approve it from Fleet Requisitions.", { code: "FLEET_ASSIGNMENT_VIA_REQUEST_ONLY", statusCode: 409 });
  }
  const patch = vehiclePatch(payload);
  if (patch.status === "inactive") {
    const openRequest = await FleetRequisition.exists({ fleetId: row._id, status: { $in: ["Requested", "Approved", "Picked", "Returned"] } });
    if (openRequest || row.bookedByRequisitionId) throw new FleetServiceError("A vehicle with an open request or booking cannot be deactivated until the fleet workflow is complete.", { code: "FLEET_ALREADY_BOOKED", statusCode: 409 });
  }
  Object.assign(row, patch, { updatedBy: actorId(actor) });
  await row.save(); await writeAudit("updated", "fleet_vehicle", row, actor, request); return serialize(row);
}
export async function deleteVehicle(id, actor, request) {
  assertInternal(actor);
  const row = await FleetVehicle.findById(oid(id, "fleetId"));
  if (!row) throw new FleetServiceError("Fleet vehicle was not found.", { code: "FLEET_NOT_FOUND", statusCode: 404 });
  const active = await FleetRequisition.exists({ fleetId: row._id, status: { $in: ["Requested", "Approved", "Picked", "Returned"] } });
  if (active || row.bookedByRequisitionId) throw new FleetServiceError("This fleet has an open requisition or booking lock. Complete or reconcile it before deactivating the fleet.", { code: "FLEET_HAS_ACTIVE_REQUISITION", statusCode: 409 });
  row.status = "inactive"; row.updatedBy = actorId(actor); await row.save(); await writeAudit("deactivated", "fleet_vehicle", row, actor, request); return serialize(row);
}

async function nextCode(Model, field, prefix) {
  const latest = await Model.findOne({}).sort({ createdAt: -1, _id: -1 }).select(field).lean();
  const n = Number(String(latest?.[field] || "").match(/(\d+)$/)?.[1] || 0) + 1;
  return `${prefix}-${String(n).padStart(5, "0")}`;
}
export async function listRequisitions({ actor, ...query }) {
  assertActor(actor); const filter = {};
  if (isVendor(actor)) filter.vendorId = oid(actor.vendorId, "vendorId");
  if (text(query.status)) filter.status = text(query.status);
  if (text(query.search)) { const re = new RegExp(text(query.search).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"); filter.$or = [{ requisitionNo: re }, { vendorName: re }, { fleetCode: re }, { projectName: re }]; }
  const rows = await FleetRequisition.find(filter).sort({ requestedAt: -1, createdAt: -1 }).limit(Math.min(500, Math.max(1, num(query.limit, 250))));
  return { data: rows.map(serialize) };
}
export async function createRequisition(payload, actor, request) {
  assertActor(actor);
  const vendorId = isVendor(actor) ? oid(actor.vendorId, "vendorId") : oid(payload?.vendorId, "vendorId");
  const vendor = await Vendor.findById(vendorId);
  if (!vendor || vendor.accountStatus !== "APPROVED") throw new FleetServiceError("Only approved vendors can request fleet.", { code: "VENDOR_NOT_APPROVED", statusCode: 403 });
  const preferredPickupDate = cleanDate(payload?.preferredPickupDate, "preferred pickup date");
  if (isVendor(actor) && !preferredPickupDate) throw new FleetServiceError("Preferred pickup date is required.", { code: "PICKUP_DATE_REQUIRED", statusCode: 422 });
  let fleet = null;
  if (payload?.fleetId) {
    fleet = await FleetVehicle.findById(oid(payload.fleetId, "fleetId"));
    if (!fleet || fleet.status !== "active") throw new FleetServiceError("The selected fleet is not available.", { code: "FLEET_UNAVAILABLE", statusCode: 409 });
    if (fleet.bookedByRequisitionId) throw new FleetServiceError("This vehicle has already been booked by another approved vendor request.", { code: "FLEET_ALREADY_BOOKED", statusCode: 409 });
    const busy = await FleetRequisition.exists({ fleetId: fleet._id, status: { $in: ["Approved", "Picked", "Returned"] } });
    if (busy) throw new FleetServiceError("This vehicle already has an active booking.", { code: "FLEET_ALREADY_BOOKED", statusCode: 409 });
    const duplicate = await FleetRequisition.exists({ fleetId: fleet._id, vendorId, status: "Requested" });
    if (duplicate) throw new FleetServiceError("Your vendor already has a pending request for this vehicle.", { code: "FLEET_REQUEST_ALREADY_EXISTS", statusCode: 409 });
  }
  let project = null;
  if (payload?.projectId) {
    project = await Project.findById(oid(payload.projectId, "projectId"));
    if (!project) throw new FleetServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 });
    if (project.vendorId && String(project.vendorId) !== String(vendorId)) throw new FleetServiceError("The selected project is assigned to a different vendor.", { code: "PROJECT_SCOPE_FORBIDDEN", statusCode: 403 });
  }
  const row = await FleetRequisition.create({ requisitionNo: await nextCode(FleetRequisition, "requisitionNo", "FRQ"), vendorId, vendorName: vendor.companyName, fleetId: fleet?._id || null, fleetCode: fleet?.fleetCode || "", vehicleName: fleet?.vehicleName || text(payload?.vehicleName), category: fleet?.category || text(payload?.category), projectId: project?._id || null, projectName: project?.name || text(payload?.projectName), requestedBy: actorId(actor), requestRemarks: text(payload?.requestRemarks), preferredPickupDate, status: "Requested", approvedAt: null, approvedBy: null, createdBy: actorId(actor), updatedBy: actorId(actor) });
  // Close the race where another admin request booked the vehicle between our initial read and insert.
  if (fleet) {
    const latestFleet = await FleetVehicle.findById(fleet._id).select("bookedByRequisitionId").lean();
    if (latestFleet?.bookedByRequisitionId && String(latestFleet.bookedByRequisitionId) !== String(row._id)) {
      await FleetRequisition.deleteOne({ _id: row._id, status: "Requested" });
      throw new FleetServiceError("This vehicle was booked while your request was being submitted. Refresh the fleet list and choose another vehicle.", { code: "FLEET_ALREADY_BOOKED", statusCode: 409 });
    }
  }
  await writeAudit("created", "fleet_requisition", row, actor, request);
  await Promise.all([
    sendCompanyWorkflowEmail({ subject: `Fleet request received — ${row.requisitionNo}`, title: "Fleet request received", message: `${row.vendorName} submitted a fleet booking request that requires admin review.`, details: [{ label: "Request", value: row.requisitionNo }, { label: "Vendor", value: row.vendorName }, { label: "Fleet", value: row.fleetCode || row.vehicleName || "Admin to select" }, { label: "Preferred pickup", value: row.preferredPickupDate?.toISOString?.() || "—" }] }),
    notifyWorkspaceOwners({ eventType: "fleet_request_submitted", title: "New fleet request", message: `${row.vendorName} submitted a fleet request.`, payload: { requisitionId: String(row._id), fleetId: row.fleetId ? String(row.fleetId) : null, vendorId: String(row.vendorId) } }).catch((error) => console.error("[fleetService] fleet request notification failed", error?.message || error)),
  ]);
  return serialize(row);
}
async function storeTripDocuments(files, requisitionId, actor) {
  const stored = [];
  try {
    for (const file of files) {
      if (!Buffer.isBuffer(file?.buffer) || !file.buffer.length) throw new FleetServiceError("One of the uploaded trip documents is empty.", { code: "FLEET_DOCUMENT_EMPTY", statusCode: 422 });
      if (Number(file.size || file.buffer.length) > 10 * 1024 * 1024) throw new FleetServiceError("Each trip document must be 10 MB or smaller.", { code: "FLEET_DOCUMENT_TOO_LARGE", statusCode: 413 });
      const originalName = text(file.originalname).replace(/[\\/]+/g, "_").slice(0, 240) || "trip-document";
      const extension = originalName.includes(".") ? originalName.split(".").pop().toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 10) : "bin";
      const saved = await storageService.saveBuffer({ buffer: file.buffer, context: "project", filename: `fleet_return_${String(requisitionId)}_${randomUUID()}.${extension || "bin"}` });
      try {
        const metadata = await storageService.buildFileMetadata({ storageKey: saved.storageKey, originalName, mimeType: file.mimetype || "application/octet-stream", extension, uploadedBy: actorId(actor) });
        stored.push({ id: randomUUID(), storageKey: metadata.storageKey, originalName: metadata.originalName, mimeType: metadata.mimeType, size: metadata.size, checksum: metadata.checksum, uploadedAt: metadata.uploadedAt || new Date(), uploadedBy: actorId(actor) });
      } catch (error) {
        await storageService.deleteFile(saved.storageKey).catch(() => undefined);
        throw error;
      }
    }
    return stored;
  } catch (error) {
    await Promise.all(stored.map((doc) => storageService.deleteFile(doc.storageKey).catch(() => undefined)));
    throw error;
  }
}

export async function updateRequisitionAction(id, payload, actor, request, evidenceFiles = []) {
  assertActor(actor);
  let row = await FleetRequisition.findById(oid(id, "requisitionId"));
  if (!row) throw new FleetServiceError("Fleet requisition was not found.", { code: "FLEET_REQUISITION_NOT_FOUND", statusCode: 404 });
  if (isVendor(actor) && String(row.vendorId) !== String(actor.vendorId)) throw new FleetServiceError("You can only access your own fleet requisitions.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
  const action = text(payload?.action).toLowerCase();
  const remarks = text(payload?.remarks);
  let uploadedDocuments = [];
  let generatedClaim = null;
  let rowPersisted = false;

  if (isInternal(actor)) {
    if (evidenceFiles.length) throw new FleetServiceError("Internal requisition actions do not accept trip documents.", { code: "FLEET_DOCUMENT_ACTION_INVALID", statusCode: 422 });
    if (action === "approve" && row.status === "Requested") {
      if (!payload?.fleetId && !row.fleetId) throw new FleetServiceError("Select a fleet vehicle before approving this requisition.", { code: "FLEET_SELECTION_REQUIRED", statusCode: 422 });
      const fleet = await FleetVehicle.findById(oid(payload?.fleetId || row.fleetId, "fleetId"));
      if (!fleet || fleet.status !== "active") throw new FleetServiceError("Selected fleet is unavailable.", { code: "FLEET_UNAVAILABLE", statusCode: 409 });
      const busy = await FleetRequisition.exists({ _id: { $ne: row._id }, fleetId: fleet._id, status: { $in: ["Approved", "Picked", "Returned"] } });
      if (busy) throw new FleetServiceError("This vehicle already has an active booking.", { code: "FLEET_ALREADY_BOOKED", statusCode: 409 });
      const booking = await FleetVehicle.findOneAndUpdate(
        { _id: fleet._id, status: "active", bookedByRequisitionId: null },
        { $set: { bookedByRequisitionId: row._id, assignedVendorId: row.vendorId, assignedVendorName: row.vendorName, assignedAt: new Date(), assignedBy: actorId(actor) } },
        { new: true },
      );
      if (!booking) throw new FleetServiceError("Another admin has already booked this vehicle. Refresh and choose an available vehicle.", { code: "FLEET_ALREADY_BOOKED", statusCode: 409 });
      const approvedAt = new Date();
      let committed;
      try {
        committed = await FleetRequisition.findOneAndUpdate(
          { _id: row._id, status: "Requested" },
          { $set: { fleetId: booking._id, fleetCode: booking.fleetCode, vehicleName: booking.vehicleName, category: booking.category, status: "Approved", approvedAt, approvedBy: actorId(actor), decisionRemarks: remarks, updatedBy: actorId(actor) } },
          { new: true, runValidators: true },
        );
      } catch (error) {
        await FleetVehicle.updateOne({ _id: booking._id, bookedByRequisitionId: row._id }, { $set: { bookedByRequisitionId: null, assignedVendorId: null, assignedVendorName: "", assignedAt: null, assignedBy: null } }).catch(() => undefined);
        throw error;
      }
      if (!committed) {
        await FleetVehicle.updateOne({ _id: booking._id, bookedByRequisitionId: row._id }, { $set: { bookedByRequisitionId: null, assignedVendorId: null, assignedVendorName: "", assignedAt: null, assignedBy: null } }).catch(() => undefined);
        throw new FleetServiceError("This requisition was already processed by another administrator. Refresh the request list.", { code: "FLEET_REQUEST_ALREADY_DECIDED", statusCode: 409 });
      }
      row = committed;
      rowPersisted = true;
    } else if (action === "reject" && row.status === "Requested") {
      if (!remarks) throw new FleetServiceError("A rejection reason is required.", { code: "REQUISITION_REJECTION_REMARKS_REQUIRED", statusCode: 422 });
      const rejected = await FleetRequisition.findOneAndUpdate(
        { _id: row._id, status: "Requested" },
        { $set: { status: "Rejected", decisionRemarks: remarks, updatedBy: actorId(actor) } },
        { new: true, runValidators: true },
      );
      if (!rejected) throw new FleetServiceError("This requisition was already processed by another administrator. Refresh the request list.", { code: "FLEET_REQUEST_ALREADY_DECIDED", statusCode: 409 });
      row = rejected;
      rowPersisted = true;
    } else if (action === "complete" && row.status === "Returned") {
      const openClaim = await FleetClaimBill.exists({ requisitionId: row._id, status: { $in: ["Pending", "Approved"] } });
      if (openClaim) throw new FleetServiceError("This vehicle remains booked while its fleet claim is pending. Settle or reject the claim before completing the requisition.", { code: "FLEET_CLAIM_STILL_OPEN", statusCode: 409 });
      row.status = "Completed"; row.decisionRemarks = remarks;
    } else throw new FleetServiceError(`Action cannot be performed while requisition is ${row.status}.`, { code: "INVALID_FLEET_TRANSITION", statusCode: 409 });
  } else {
    if (action === "pickup" && row.status === "Approved") {
      const startKm = num(payload?.startKm, NaN);
      if (!Number.isFinite(startKm) || startKm < 0) throw new FleetServiceError("Enter a valid pickup odometer reading.", { code: "INVALID_START_KM", statusCode: 422 });
      const pickupLocation = text(payload?.pickupLocation);
      if (!pickupLocation) throw new FleetServiceError("Pickup location is required.", { code: "PICKUP_LOCATION_REQUIRED", statusCode: 422 });
      row.status = "Picked"; row.startKm = startKm; row.pickupTime = cleanDate(payload?.pickupTime, "pickup time") || new Date(); row.pickupLocation = pickupLocation; row.driverName = text(payload?.driverName); row.pickupRemarks = remarks;
      if (evidenceFiles.length) throw new FleetServiceError("Trip documents can only be uploaded when a trip is returned.", { code: "FLEET_DOCUMENT_ACTION_INVALID", statusCode: 422 });
    } else if (action === "return" && row.status === "Picked") {
      const endKm = num(payload?.endKm, NaN);
      if (!Number.isFinite(endKm) || endKm < num(row.startKm)) throw new FleetServiceError("Return odometer must be greater than or equal to pickup odometer.", { code: "INVALID_END_KM", statusCode: 422 });
      if (!Array.isArray(evidenceFiles) || evidenceFiles.length < 1) throw new FleetServiceError("Upload at least one trip sheet, receipt, or delivery proof before completing the trip.", { code: "FLEET_RETURN_DOCUMENTS_REQUIRED", statusCode: 422 });
      if (evidenceFiles.length > 10) throw new FleetServiceError("A maximum of 10 trip documents can be uploaded.", { code: "FLEET_RETURN_DOCUMENT_LIMIT", statusCode: 422 });
      const claimRequested = [true, 1, "1", "true", "yes", "on"].includes(typeof payload?.claimRequested === "string" ? payload.claimRequested.toLowerCase() : payload?.claimRequested);
      let claimAmount = 0;
      const claimType = text(payload?.claimType);
      const claimDescription = text(payload?.claimDescription);
      if (claimRequested) {
        claimAmount = num(payload?.claimAmount, NaN);
        if (!claimType || !Number.isFinite(claimAmount) || claimAmount <= 0 || !claimDescription) throw new FleetServiceError("Claim type, a positive claim amount, and a claim description are required.", { code: "CLAIM_REQUIRED_FIELDS", statusCode: 422 });
        const fleetSettings = await FleetSettings.findOne({ key: "fleet" }).lean();
        const configuredClaimTypes = Array.isArray(fleetSettings?.claimTypes)
          ? fleetSettings.claimTypes.filter((item) => item?.active !== false)
          : DEFAULT_CLAIM_TYPES.filter((item) => item.active);
        const activeClaimTypeNames = configuredClaimTypes.map((item) => text(item?.name).toLowerCase()).filter(Boolean);
        if (!activeClaimTypeNames.includes(claimType.toLowerCase())) {
          throw new FleetServiceError("Select an active claim type configured in Fleet Settings.", { code: "CLAIM_TYPE_NOT_ACTIVE", statusCode: 422 });
        }
      }
      uploadedDocuments = await storeTripDocuments(evidenceFiles, row._id, actor);
      row.status = claimRequested ? "Returned" : "Completed";
      row.endKm = endKm; row.totalKm = endKm - num(row.startKm); row.returnTime = cleanDate(payload?.returnTime, "return time") || new Date(); row.decisionRemarks = remarks; row.returnDocuments = uploadedDocuments; row.claimRequested = claimRequested; row.claimReference = text(payload?.claimReference);
      if (claimRequested) {
        try {
          const first = uploadedDocuments[0];
          generatedClaim = await FleetClaimBill.create({
            claimNo: await nextCode(FleetClaimBill, "claimNo", "FCB"), vendorId: row.vendorId, vendorName: row.vendorName,
            requisitionId: row._id, fleetId: row.fleetId, fleetCode: row.fleetCode, claimType,
            claimReference: text(payload?.claimReference), claimDate: row.returnTime || new Date(), amount: claimAmount, currency: "USD",
            description: claimDescription, attachmentName: first?.originalName || "", attachmentStorageKey: first?.storageKey || "",
            attachmentMimeType: first?.mimeType || "", attachmentSize: first?.size || 0, attachmentChecksum: first?.checksum || "",
            attachmentUploadedAt: first?.uploadedAt || new Date(), status: "Pending", createdBy: actorId(actor), updatedBy: actorId(actor),
          });
        } catch (error) {
          await Promise.all(uploadedDocuments.map((doc) => storageService.deleteFile(doc.storageKey).catch(() => undefined)));
          throw error;
        }
      }
    } else throw new FleetServiceError("Vendor action is not valid for the current requisition status.", { code: "INVALID_FLEET_TRANSITION", statusCode: 409 });
  }

  try {
    if (!rowPersisted) {
      row.updatedBy = actorId(actor);
      await row.save();
    }
  } catch (error) {
    if (action === "approve" && row.fleetId) await FleetVehicle.updateOne({ _id: row.fleetId, bookedByRequisitionId: row._id }, { $set: { bookedByRequisitionId: null, assignedVendorId: null, assignedVendorName: "", assignedAt: null, assignedBy: null } }).catch(() => undefined);
    if (generatedClaim) await FleetClaimBill.deleteOne({ _id: generatedClaim._id }).catch(() => undefined);
    await Promise.all(uploadedDocuments.map((doc) => storageService.deleteFile(doc.storageKey).catch(() => undefined)));
    throw error;
  }
  await writeAudit(`status_${row.status.toLowerCase()}`, "fleet_requisition", row, actor, request);
  if (action === "approve" && row.fleetId) {
    const competitors = await FleetRequisition.find({ _id: { $ne: row._id }, fleetId: row.fleetId, status: "Requested" }).select("_id vendorId vendorName requisitionNo fleetCode").lean();
    if (competitors.length) {
      await FleetRequisition.updateMany({ _id: { $in: competitors.map((item) => item._id) }, status: "Requested" }, { $set: { status: "Rejected", decisionRemarks: "Vehicle has been booked for another vendor.", updatedBy: actorId(actor) } });
      await Promise.all(competitors.map(async (item) => {
        await Promise.all([
          sendVendorWorkflowEmail({ vendorId: item.vendorId, subject: `Fleet request not accepted — ${item.requisitionNo}`, title: "Fleet request not accepted", message: `Vehicle ${item.fleetCode || "requested fleet"} has been booked for another vendor. Please submit a new request for another available vehicle.`, details: [{ label: "Request", value: item.requisitionNo }, { label: "Vehicle", value: item.fleetCode || "—" }, { label: "Status", value: "Rejected" }] }),
          notifyVendorAdmins({ vendorId: item.vendorId, eventType: "fleet_request_rejected", title: "Fleet request not accepted", message: `Vehicle ${item.fleetCode || "requested fleet"} has been booked for another vendor.`, payload: { requisitionId: String(item._id), status: "Rejected" } }).catch((error) => console.error("[fleetService] competitor notification failed", error?.message || error)),
        ]);
      }));
    }
  }
  if (action === "complete" && row.fleetId) {
    await FleetVehicle.updateOne({ _id: row.fleetId, bookedByRequisitionId: row._id }, { $set: { bookedByRequisitionId: null, assignedVendorId: null, assignedVendorName: "", assignedAt: null, assignedBy: null } });
  }
  if (action === "return" && row.status === "Completed" && row.fleetId) {
    await FleetVehicle.updateOne({ _id: row.fleetId, bookedByRequisitionId: row._id }, { $set: { bookedByRequisitionId: null, assignedVendorId: null, assignedVendorName: "", assignedAt: null, assignedBy: null } });
  }
  if (action === "approve" || action === "reject") {
    await sendVendorWorkflowEmail({ vendorId: row.vendorId, subject: `Fleet request ${row.status.toLowerCase()} — ${row.requisitionNo}`, title: `Fleet request ${row.status.toLowerCase()}`, message: `Your fleet request ${row.requisitionNo} has been ${row.status.toLowerCase()}.${remarks ? ` Admin note: ${remarks}` : ""}`, details: [{ label: "Request", value: row.requisitionNo }, { label: "Vehicle", value: row.fleetCode || row.vehicleName }, { label: "Status", value: row.status }] });
    await notifyVendorAdmins({ vendorId: row.vendorId, eventType: `fleet_request_${row.status.toLowerCase()}`, title: `Fleet request ${row.status.toLowerCase()}`, message: `Fleet request ${row.requisitionNo} has been ${row.status.toLowerCase()}.`, payload: { requisitionId: String(row._id), status: row.status } }).catch((error) => console.error("[fleetService] vendor notification failed", error?.message || error));
  }
  if (generatedClaim) {
    await writeAudit("created_from_trip_return", "fleet_claim_bill", generatedClaim, actor, request);
    await sendCompanyWorkflowEmail({ subject: `Fleet claim submitted — ${generatedClaim.claimNo}`, title: "Fleet claim request", message: `${generatedClaim.vendorName} submitted a fleet claim for review.`, details: [{ label: "Claim", value: generatedClaim.claimNo }, { label: "Vendor", value: generatedClaim.vendorName }, { label: "Amount", value: `${generatedClaim.currency} ${generatedClaim.amount}` }, { label: "Fleet", value: generatedClaim.fleetCode }] });
    await notifyWorkspaceOwners({ eventType: "fleet_claim_submitted", title: "Fleet claim submitted", message: `${generatedClaim.vendorName} submitted claim ${generatedClaim.claimNo}.`, payload: { claimId: String(generatedClaim._id), vendorId: String(generatedClaim.vendorId) } }).catch(() => undefined);
  }
  return serialize(row);
}

export async function getRequisitionDocument(id, documentId, actor) {
  assertActor(actor);
  const row = await FleetRequisition.findById(oid(id, "requisitionId"));
  if (!row) throw new FleetServiceError("Fleet requisition was not found.", { code: "FLEET_REQUISITION_NOT_FOUND", statusCode: 404 });
  if (isVendor(actor) && String(row.vendorId) !== String(actor.vendorId)) throw new FleetServiceError("You can only access documents from your own fleet requisitions.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
  const document = (row.returnDocuments || []).find((item) => String(item.id) === String(documentId));
  if (!document) throw new FleetServiceError("Trip document was not found.", { code: "FLEET_DOCUMENT_NOT_FOUND", statusCode: 404 });
  const stream = await storageService.createReadStream(document.storageKey);
  return { attachment: { originalName: document.originalName, mimeType: document.mimeType || "application/octet-stream" }, stream };
}

export async function listClaims({ actor, ...query }) {
  assertActor(actor);
  const filter = {};
  if (isVendor(actor)) filter.vendorId = oid(actor.vendorId, "vendorId");
  if (text(query.status)) filter.status = text(query.status);
  const claims = await FleetClaimBill.find(filter)
    .sort({ claimDate: -1, createdAt: -1 })
    .limit(Math.min(500, Math.max(1, num(query.limit, 250))));
  const requisitionIds = [...new Set(claims.map((item) => item.requisitionId ? String(item.requisitionId) : "").filter(Boolean))];
  const fleetIds = [...new Set(claims.map((item) => item.fleetId ? String(item.fleetId) : "").filter(Boolean))];
  const [requisitions, vehicles] = await Promise.all([
    requisitionIds.length ? FleetRequisition.find({ _id: { $in: requisitionIds } }) : [],
    fleetIds.length ? FleetVehicle.find({ _id: { $in: fleetIds } }) : [],
  ]);
  const requisitionById = new Map(requisitions.map((item) => [String(item._id), serialize(item)]));
  const vehicleById = new Map(vehicles.map((item) => [String(item._id), serialize(item)]));
  return {
    data: claims.map((claimDoc) => {
      const claim = serialize(claimDoc);
      const trip = claim.requisitionId ? requisitionById.get(String(claim.requisitionId)) : null;
      const vehicle = claim.fleetId ? vehicleById.get(String(claim.fleetId)) : null;
      return {
        ...claim,
        vehicleName: trip?.vehicleName || vehicle?.vehicleName || "",
        category: trip?.category || vehicle?.category || "",
        registrationNo: vehicle?.registrationNo || "",
        tripStatus: trip?.status || "",
        tripId: trip?.tripId || "",
        requestId: trip?.requisitionNo || claim.claimNo,
        requestedAt: trip?.requestedAt || claim.claimDate,
        requestRemarks: trip?.requestRemarks || "",
        approvalNote: ["Approved", "Picked"].includes(trip?.status) ? trip?.decisionRemarks || "" : "",
        rejectionReason: trip?.status === "Rejected" ? trip?.decisionRemarks || "" : "",
        approvedAt: trip?.approvedAt || null,
        pickupTime: trip?.pickupTime || null,
        pickupLocation: trip?.pickupLocation || "",
        driverName: trip?.driverName || "",
        startKm: trip?.startKm ?? null,
        returnTime: trip?.returnTime || null,
        endKm: trip?.endKm ?? null,
        totalKm: trip?.totalKm ?? null,
        returnDocuments: trip?.returnDocuments || [],
        activityLog: [],
        claim: {
          type: claim.claimType,
          amount: claim.amount,
          currency: claim.currency || "USD",
          reference: claim.claimReference || claim.claimNo,
          remarks: claim.description,
          settledAmount: claim.settledAmount,
          settledAt: claim.settledAt,
          settlementRemarks: claim.settlementRemarks,
        },
      };
    }),
  };
}
export async function createClaim(payload, actor, request, evidenceFile = null) {
  assertActor(actor);
  const vendorId = isVendor(actor) ? oid(actor.vendorId, "vendorId") : oid(payload?.vendorId, "vendorId");
  const vendor = await Vendor.findById(vendorId); if (!vendor || vendor.accountStatus !== "APPROVED") throw new FleetServiceError("Only approved vendors can submit fleet claims.", { code: "VENDOR_NOT_APPROVED", statusCode: 403 });
  const amount = num(payload?.amount, NaN); if (!Number.isFinite(amount) || amount <= 0) throw new FleetServiceError("Claim amount must be greater than zero.", { code: "INVALID_CLAIM_AMOUNT", statusCode: 422 });
  if (!text(payload?.claimType) || !text(payload?.description)) throw new FleetServiceError("Claim type and description are required.", { code: "CLAIM_REQUIRED_FIELDS", statusCode: 422 });
  let requisition = null;
  if (payload?.requisitionId) {
    requisition = await FleetRequisition.findById(oid(payload.requisitionId, "requisitionId"));
    if (!requisition || String(requisition.vendorId) !== String(vendorId)) throw new FleetServiceError("The selected requisition does not belong to your vendor account.", { code: "FLEET_SCOPE_FORBIDDEN", statusCode: 403 });
    if (!["Returned", "Completed"].includes(requisition.status)) throw new FleetServiceError("A fleet claim can only be linked after the fleet has been returned.", { code: "FLEET_REQUISITION_NOT_RETURNED", statusCode: 409 });
  }
  const fleetId = payload?.fleetId || requisition?.fleetId;
  const fleet = fleetId ? await FleetVehicle.findById(oid(fleetId, "fleetId")) : null;
  if (fleetId && !fleet) throw new FleetServiceError("The selected fleet vehicle was not found.", { code: "FLEET_NOT_FOUND", statusCode: 404 });
  if (isVendor(actor) && (!requisition || String(requisition.vendorId) !== String(vendorId))) throw new FleetServiceError("A fleet claim must belong to your own fleet requisition.", { code: "FLEET_SCOPE_FORBIDDEN", statusCode: 403 });
  const row = await FleetClaimBill.create({ claimNo: await nextCode(FleetClaimBill, "claimNo", "FCB"), vendorId, vendorName: vendor.companyName, requisitionId: requisition?._id || null, fleetId: fleet?._id || null, fleetCode: fleet?.fleetCode || "", claimType: text(payload.claimType), claimDate: cleanDate(payload.claimDate, "claim date") || new Date(), amount, currency: "USD", description: text(payload.description), attachmentName: "", status: "Pending", createdBy: actorId(actor), updatedBy: actorId(actor) });
  let savedStorageKey = "";
  try {
    if (evidenceFile) {
      if (!Buffer.isBuffer(evidenceFile.buffer) || !evidenceFile.buffer.length || evidenceFile.size > 10 * 1024 * 1024) throw new FleetServiceError("Evidence must be a non-empty file no larger than 10 MB.", { code: "FLEET_EVIDENCE_INVALID_SIZE", statusCode: 422 });
      const originalName = text(evidenceFile.originalname).replace(/[\\/]+/g, "_").slice(0, 240) || "claim-evidence";
      const extension = originalName.includes(".") ? originalName.split(".").pop().toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 10) : "bin";
      const storage = await storageService.saveBuffer({ buffer: evidenceFile.buffer, context: "project", filename: `fleet_claim_${String(row._id)}_${randomUUID()}.${extension || "bin"}` });
      savedStorageKey = storage.storageKey;
      const metadata = await storageService.buildFileMetadata({ storageKey: storage.storageKey, originalName, mimeType: evidenceFile.mimetype || "application/octet-stream", extension, uploadedBy: actorId(actor) });
      row.attachmentName = metadata.originalName;
      row.attachmentStorageKey = metadata.storageKey;
      row.attachmentMimeType = metadata.mimeType;
      row.attachmentSize = metadata.size;
      row.attachmentChecksum = metadata.checksum;
      row.attachmentUploadedAt = metadata.uploadedAt;
      await row.save();
    }
  } catch (error) {
    if (savedStorageKey) { try { await storageService.deleteFile(savedStorageKey); } catch {} }
    try { await FleetClaimBill.deleteOne({ _id: row._id }); } catch {}
    throw error;
  }
  await writeAudit("created", "fleet_claim_bill", row, actor, request);
  await Promise.all([
    sendCompanyWorkflowEmail({ subject: `Fleet claim submitted — ${row.claimNo}`, title: "Fleet claim request", message: `${row.vendorName} submitted a fleet claim for review.`, details: [{ label: "Claim", value: row.claimNo }, { label: "Vendor", value: row.vendorName }, { label: "Amount", value: `${row.currency} ${row.amount}` }, { label: "Fleet", value: row.fleetCode }] }),
    notifyWorkspaceOwners({ eventType: "fleet_claim_submitted", title: "Fleet claim submitted", message: `${row.vendorName} submitted claim ${row.claimNo}.`, payload: { claimId: String(row._id), vendorId: String(row.vendorId) } }).catch(() => undefined),
  ]);
  return serialize(row);
}
export async function getClaimAttachment(id, actor) {
  assertActor(actor);
  const row = await FleetClaimBill.findById(oid(id, "claimId"));
  if (!row) throw new FleetServiceError("Fleet claim bill was not found.", { code: "FLEET_CLAIM_NOT_FOUND", statusCode: 404 });
  if (isVendor(actor) && String(row.vendorId) !== String(actor.vendorId)) throw new FleetServiceError("You can only access evidence from your own claim bills.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
  if (!row.attachmentStorageKey) throw new FleetServiceError("No evidence file is attached to this claim bill.", { code: "FLEET_EVIDENCE_NOT_FOUND", statusCode: 404 });
  const stream = await storageService.createReadStream(row.attachmentStorageKey);
  return { attachment: { originalName: row.attachmentName, mimeType: row.attachmentMimeType || "application/octet-stream" }, stream };
}
export async function updateClaimStatus(id, payload, actor, request) {
  assertInternal(actor);
  const row = await FleetClaimBill.findById(oid(id, "claimId"));
  if (!row) throw new FleetServiceError("Fleet claim bill was not found.", { code: "FLEET_CLAIM_NOT_FOUND", statusCode: 404 });
  const action = text(payload?.action).toLowerCase();
  const remarks = text(payload?.remarks);
  let linkedTripForCompletion = null;
  if (action === "approve" && row.status === "Pending") {
    row.status = "Approved"; row.reviewedAt = new Date(); row.reviewedBy = actorId(actor); row.reviewRemarks = remarks;
  } else if (action === "reject" && row.status === "Pending") {
    if (!remarks) throw new FleetServiceError("Rejection remarks are required.", { code: "CLAIM_REMARKS_REQUIRED", statusCode: 422 });
    row.status = "Rejected"; row.reviewedAt = new Date(); row.reviewedBy = actorId(actor); row.reviewRemarks = remarks;
  } else if (action === "settle" && ["Pending", "Approved"].includes(row.status)) {
    const settledAmount = num(payload?.settledAmount ?? payload?.approvedExpenseAmount ?? row.amount, NaN);
    if (!Number.isFinite(settledAmount) || settledAmount <= 0) throw new FleetServiceError("Approved expense amount must be greater than zero.", { code: "INVALID_SETTLEMENT_AMOUNT", statusCode: 422 });
    if (row.requisitionId) {
      const trip = await FleetRequisition.findById(row.requisitionId);
      if (!trip || !["Returned", "Completed"].includes(trip.status)) throw new FleetServiceError("This claim can only be settled after the related trip has been returned.", { code: "FLEET_TRIP_NOT_RETURNED", statusCode: 409 });
      if (trip.status === "Returned") linkedTripForCompletion = trip;
    }
    row.status = "Settled";
    row.settledAmount = settledAmount;
    row.settlementRemarks = remarks;
    row.settledAt = new Date();
    row.settledBy = actorId(actor);
    row.reviewRemarks = remarks;
  } else {
    throw new FleetServiceError(`Claim action cannot be performed while status is ${row.status}.`, { code: "INVALID_CLAIM_TRANSITION", statusCode: 409 });
  }
  row.updatedBy = actorId(actor);
  await row.save();
  if (action === "settle" && linkedTripForCompletion) {
    linkedTripForCompletion.status = "Completed";
    linkedTripForCompletion.updatedBy = actorId(actor);
    if (remarks) linkedTripForCompletion.decisionRemarks = remarks;
    await linkedTripForCompletion.save();
    if (linkedTripForCompletion.fleetId) {
      await FleetVehicle.updateOne({ _id: linkedTripForCompletion.fleetId, bookedByRequisitionId: linkedTripForCompletion._id }, { $set: { bookedByRequisitionId: null, assignedVendorId: null, assignedVendorName: "", assignedAt: null, assignedBy: null } });
    }
    await writeAudit("status_completed", "fleet_requisition", linkedTripForCompletion, actor, request);
  }
  await writeAudit(`status_${row.status.toLowerCase()}`, "fleet_claim_bill", row, actor, request);
  if (["settle", "reject"].includes(action)) {
    const paid = action === "settle";
    await sendVendorWorkflowEmail({ vendorId: row.vendorId, subject: paid ? `Fleet claim paid — ${row.claimNo}` : `Fleet claim not paid — ${row.claimNo}`, title: paid ? "Fleet claim paid" : "Fleet claim rejected / not paid", message: paid ? `Your fleet claim ${row.claimNo} has been settled for ${row.currency} ${row.settledAmount}.` : `Your fleet claim ${row.claimNo} was rejected and will not be paid.${remarks ? ` Reason: ${remarks}` : ""}`, details: [{ label: "Claim", value: row.claimNo }, { label: "Status", value: row.status }, { label: "Amount", value: `${row.currency} ${paid ? row.settledAmount : row.amount}` }] });
    await notifyVendorAdmins({ vendorId: row.vendorId, eventType: paid ? "fleet_claim_paid" : "fleet_claim_not_paid", title: paid ? "Fleet claim paid" : "Fleet claim not paid", message: paid ? `Claim ${row.claimNo} has been settled.` : `Claim ${row.claimNo} was rejected.`, payload: { claimId: String(row._id), status: row.status } }).catch(() => undefined);
  }
  return serialize(row);
}

const DEFAULT_CATEGORIES = [
  { name: "Bucket Truck", description: "Aerial work platform truck for elevated field work.", active: true },
  { name: "Splicer Van", description: "Van equipped for fiber splicing and field service.", active: true },
  { name: "Cable Reel Truck", description: "Vehicle designed to move cable reels.", active: true },
  { name: "Field Service Pickup", description: "Pickup used for routine technician site visits.", active: true },
];
const DEFAULT_CLAIM_TYPES = [
  { name: "Fuel / Diesel", description: "Fuel consumed during an approved fleet trip.", active: true },
  { name: "Toll & Parking", description: "Toll and parking costs for fleet usage.", active: true },
  { name: "Repair / Damage", description: "Repair costs incurred during fleet use.", active: true },
  { name: "Tyre / Puncture", description: "Tyre or puncture repair costs.", active: true },
];
export async function getFleetSettings(actor) {
  assertActor(actor); let row = await FleetSettings.findOne({ key: "fleet" });
  if (!row && isInternal(actor)) row = await FleetSettings.create({ key: "fleet", vehicleCategories: DEFAULT_CATEGORIES, claimTypes: DEFAULT_CLAIM_TYPES });
  return row ? { vehicleCategories: row.vehicleCategories, claimTypes: row.claimTypes, updatedAt: row.updatedAt } : { vehicleCategories: DEFAULT_CATEGORIES.filter((x) => x.active), claimTypes: DEFAULT_CLAIM_TYPES.filter((x) => x.active), updatedAt: null };
}
export async function updateFleetSettings(payload, actor, request) {
  assertInternal(actor);
  const normalize = (rows, field) => {
    if (!Array.isArray(rows)) throw new FleetServiceError(`${field} must be a list.`, { code: "INVALID_FLEET_SETTINGS", statusCode: 422 });
    const names = new Set();
    return rows.map((row) => {
      const name = text(row?.name); if (!name) throw new FleetServiceError(`${field} entries require a name.`, { code: "INVALID_FLEET_SETTINGS", statusCode: 422 });
      const key = name.toLowerCase(); if (names.has(key)) throw new FleetServiceError(`${field} names must be unique.`, { code: "DUPLICATE_FLEET_SETTING", statusCode: 422 }); names.add(key);
      return { name, description: text(row?.description), active: row?.active !== false };
    });
  };
  const doc = await FleetSettings.findOneAndUpdate({ key: "fleet" }, { $set: { vehicleCategories: normalize(payload?.vehicleCategories, "Vehicle categories"), claimTypes: normalize(payload?.claimTypes, "Claim types"), updatedBy: actorId(actor) } }, { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true });
  await writeAudit("updated", "fleet_settings", doc, actor, request); return { vehicleCategories: doc.vehicleCategories, claimTypes: doc.claimTypes, updatedAt: doc.updatedAt };
}
