import mongoose from "mongoose";
import Quotation, { QUOTATION_STATUSES } from "../../models/Quotation.js";
import BOQ from "../../models/BOQ.js";
import Vendor from "../../models/Vendor.js";
import SurveyTemplate from "../../models/SurveyTemplate.js";
import SurveyResponse from "../../models/SurveyResponse.js";
import MasterRateItem from "../../models/MarketRateItem.js";
import MasterRateSequence from "../../models/MasterRateSequence.js";
import ValidityPeriod from "../../models/ValidityPeriod.js";
import RateCategory from "../../models/RateCategory.js";
import Unit from "../../models/Unit.js";
import auditService from "../audit/auditService.js";
import { notifyWorkspaceOwners, notifyVendorAdmins } from "../notification/notificationService.js";
import { sendCompanyWorkflowEmail, sendVendorWorkflowEmail } from "../email/workflowEmailService.js";

export class QuotationServiceError extends Error {
    constructor(message, { code = "QUOTATION_ERROR", statusCode = 400, details } = {}) {
        super(message);
        this.name = "QuotationServiceError";
        this.code = code;
        this.statusCode = statusCode;
        this.details = details;
    }
}

function text(value) { return typeof value === "string" ? value.trim() : ""; }
function oid(value, name = "id") {
    if (!value) return null;
    if (!mongoose.isValidObjectId(value)) {
        throw new QuotationServiceError(`Invalid ${name}.`, { code: `INVALID_${String(name).toUpperCase()}`, statusCode: 422 });
    }
    return new mongoose.Types.ObjectId(value);
}
function number(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}
function date(value) {
    if (value == null || text(value) === "") return null;
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) throw new QuotationServiceError("Invalid date value.", { code: "INVALID_DATE", statusCode: 422 });
    return d;
}
function actorId(actor) { return actor?.userId && mongoose.isValidObjectId(actor.userId) ? new mongoose.Types.ObjectId(actor.userId) : null; }
function actorVendorId(actor) { return actor?.vendorId && mongoose.isValidObjectId(actor.vendorId) ? new mongoose.Types.ObjectId(actor.vendorId) : null; }
function isVendor(actor) { return String(actor?.userType || "").toLowerCase() === "vendor"; }
function isInternal(actor) { return ["admin", "internal"].includes(String(actor?.userType || "").toLowerCase()); }

async function nextNumber(key, prefix) {
    const row = await MasterRateSequence.findOneAndUpdate(
        { _id: key },
        { $inc: { value: 1 } },
        { new: true, upsert: true, setDefaultsOnInsert: true },
    ).lean();
    const value = number(row?.value, 0);
    if (!Number.isInteger(value) || value < 1) throw new QuotationServiceError("Unable to generate a business reference.", { code: "REFERENCE_GENERATION_FAILED", statusCode: 500 });
    return `${prefix}-${new Date().getFullYear()}-${String(value).padStart(3, "0")}`;
}

function serialize(doc) { return doc?.toSafeJSON ? doc.toSafeJSON() : doc?.toJSON ? doc.toJSON() : doc; }

const BOQ_PRICING_STATUSES = new Set([
    "Draft",
    "Form Issued",
    "Form Submitted",
    "Form Approved",
    "Form Rejected",
    "Not Responded",
]);

function applyBOQFinancialSource(result, boq) {
    if (!result) return result;

    // Preserve the stored quotation total as the vendor's commercial total.
    // Admin's BOQ baseline is exposed separately and must never overwrite it.
    const vendorGrandTotal = Math.max(0, number(result.grandTotal, 0));
    const vendorCurrency = text(result.currency) || "USD";

    if (!boq) {
        return {
            ...result,
            adminGrandTotal: vendorGrandTotal,
            vendorGrandTotal,
            adminGrandTotalCurrency: vendorCurrency,
            vendorGrandTotalCurrency: vendorCurrency,
        };
    }

    const boqGrandTotal = Math.max(0, number(boq.grandTotal, 0));
    const boqSubtotal = Math.max(0, number(boq.subtotal, 0));
    const boqContingency = Math.max(0, number(boq.contingency, 0));
    const boqCurrency = text(boq.currency) || vendorCurrency;

    return {
        ...result,
        boqNo: text(boq.boqNo) || text(result.boqNo) || text(result.boqReference),
        boqReference: text(boq.boqNo) || text(result.boqReference) || text(result.boqNo),
        boqGrandTotal,
        boqSubtotal,
        boqContingency,
        boqCurrency,
        // The Admin list always displays the source BOQ amount; the Vendor
        // list always displays the saved edited quotation amount. The raw
        // grandTotal is deliberately left untouched for existing consumers.
        adminGrandTotal: boqGrandTotal > 0 ? boqGrandTotal : vendorGrandTotal,
        vendorGrandTotal,
        adminGrandTotalCurrency: boqCurrency,
        vendorGrandTotalCurrency: vendorCurrency,
    };
}

async function hydrateQuotationCategoryTypes(result, boq = null) {
    if (!result) return result;

    const collections = [
        Array.isArray(result.lines) ? result.lines : [],
        Array.isArray(result.manualAdditions) ? result.manualAdditions : [],
    ];
    const allLines = collections.flat();
    const missingMasterIds = [
        ...new Set(
            allLines
                .filter((line) => !text(line?.categoryType))
                .map((line) => text(line?.masterRateItemId))
                .filter((id) => mongoose.isValidObjectId(id)),
        ),
    ];

    const masterRows = missingMasterIds.length
        ? await MasterRateItem.find({
            _id: { $in: missingMasterIds.map((id) => new mongoose.Types.ObjectId(id)) },
        }).select("_id categoryType category").lean()
        : [];

    const masterById = new Map(
        masterRows.map((row) => [String(row._id), row]),
    );

    const boqLineById = new Map();
    const boqLineByMasterId = new Map();
    if (boq) {
        for (const line of [
            ...(Array.isArray(boq.lines) ? boq.lines : []),
            ...(Array.isArray(boq.manualAdditions) ? boq.manualAdditions : []),
        ]) {
            const categoryType = text(line?.categoryType);
            if (!categoryType) continue;

            if (line?._id) boqLineById.set(String(line._id), categoryType);
            if (line?.marketRateItemId) boqLineByMasterId.set(String(line.marketRateItemId), categoryType);
        }
    }

    const hydrateLine = (line) => {
        if (text(line?.categoryType)) return line;

        const byBoqLine = text(line?.boqLineId)
            ? boqLineById.get(text(line.boqLineId))
            : "";
        const byMasterId = text(line?.masterRateItemId)
            ? boqLineByMasterId.get(text(line.masterRateItemId)) ||
                text(masterById.get(text(line.masterRateItemId))?.categoryType)
            : "";
        const type = byBoqLine || byMasterId;

        return type
            ? { ...line, categoryType: type }
            : line;
    };

    const hydrated = {
        ...result,
        lines: collections[0].map(hydrateLine),
        manualAdditions: collections[1].map(hydrateLine),
    };

    return hydrated;
}

async function serializeWithBOQ(doc, actor = null) {
    let result = serialize(doc);
    if (!result) return result;

    const boq = result.boqId
        ? await BOQ.findById(result.boqId)
            .select("boqNo grandTotal subtotal contingency currency lines manualAdditions")
            .lean()
        : null;

    result = await hydrateQuotationCategoryTypes(result, boq);
    // Return both values explicitly so each panel can choose its own total.
    // Do not role-condition or overwrite grandTotal during serialization.
    return applyBOQFinancialSource(result, boq);
}

async function serializeManyWithBOQ(docs = [], actor = null) {
    const results = docs.map(serialize);
    const ids = [...new Set(results
        .filter((row) => row && row.boqId)
        .map((row) => String(row.boqId))
        .filter(Boolean))];

    if (!ids.length) return results.map((row) => applyBOQFinancialSource(row, null));

    const boqs = await BOQ.find({ _id: { $in: ids } })
        .select("boqNo grandTotal subtotal contingency currency")
        .lean();
    const byId = new Map(boqs.map((boq) => [String(boq._id), boq]));

    return results.map((row) => applyBOQFinancialSource(row, byId.get(String(row?.boqId)) || null));
}

function normalizePaymentInstallment(item) {
    const modules = Array.isArray(item?.modules)
        ? [...new Set(item.modules.map((value) => text(value)).filter(Boolean))]
        : [];
    const days = Array.isArray(item?.days)
        ? item.days.map((value) => number(value)).filter((value) => Number.isFinite(value) && value > 0)
        : [];
    return {
        name: text(item?.name ?? item?.installmentName) || "Installment",
        amount: Math.max(0, number(item?.amount)),
        type: ["advance", "balance", "custom"].includes(String(item?.type)) ? String(item.type) : "custom",
        dueDate: date(item?.dueDate),
        modules,
        days,
    };
}

function normalizeLine(input, { allowVendorRate = false, baseline = null, vendorEdit = false } = {}) {
    const quantity = number(input?.quantity, 0);
    if (quantity <= 0) throw new QuotationServiceError("Quantity must be greater than zero.", { code: "INVALID_QUANTITY", statusCode: 422 });
    const masterRate = number(input?.masterRate ?? input?.rate, 0);
    const vendorRate = allowVendorRate ? number(input?.vendorRate ?? input?.salesPrice ?? input?.rate, 0) : 0;
    const taxPercent = number(input?.taxPercent ?? input?.gct, 15);
    if (masterRate < 0 || vendorRate < 0) throw new QuotationServiceError("Rates cannot be negative.", { code: "INVALID_RATE", statusCode: 422 });
    if (taxPercent < 0 || taxPercent > 100) throw new QuotationServiceError("Tax percent must be between 0 and 100.", { code: "INVALID_TAX_PERCENT", statusCode: 422 });
    const module = text(input?.module);
    const category = text(input?.category);
    const description = text(input?.description);
    const unit = text(input?.unit) || "Unit";
    if (!description) throw new QuotationServiceError("Item description is required.", { code: "DESCRIPTION_REQUIRED", statusCode: 422 });

    const hasAdminSource = Boolean(input?.boqLineId || input?.masterRateItemId || input?.marketRateItemId) || !input?.isCustom;
    const baselineAdminQuantity = baseline
        ? (baseline.adminQuantity != null ? number(baseline.adminQuantity, quantity) : (hasAdminSource ? number(baseline.quantity, quantity) : null))
        : (hasAdminSource ? number(input?.adminQuantity, quantity) : null);
    const baselineAdminTaxPercent = baseline
        ? (baseline.adminTaxPercent != null ? number(baseline.adminTaxPercent, taxPercent) : (hasAdminSource ? number(baseline.taxPercent, taxPercent) : null))
        : (hasAdminSource ? number(input?.adminTaxPercent, taxPercent) : null);

    return {
        boqLineId: oid(input?.boqLineId, "boqLineId"),
        masterRateItemId: oid(input?.masterRateItemId ?? input?.marketRateItemId, "masterRateItemId"),
        module,
        categoryType: text(input?.categoryType),
        category,
        description,
        unit,
        quantity,
        adminQuantity: baselineAdminQuantity,
        adminTaxPercent: baselineAdminTaxPercent,
        vendorQuantity: vendorEdit ? quantity : (input?.vendorQuantity == null ? null : number(input.vendorQuantity, quantity)),
        vendorTaxPercent: vendorEdit ? taxPercent : (input?.vendorTaxPercent == null ? null : number(input.vendorTaxPercent, taxPercent)),
        masterRate,
        vendorRate,
        taxPercent,
        lineTotal: quantity * (allowVendorRate ? vendorRate : masterRate),
        isCustom: Boolean(input?.isCustom),
    };
}

function quotationLineKey(line) {
    const idText = (value) => value == null ? "" : String(value?._id ?? value).trim();
    const boqId = idText(line?.boqLineId);
    if (boqId) return `boq:${boqId}`;
    const masterId = idText(line?.masterRateItemId ?? line?.marketRateItemId);
    if (masterId) return `master:${masterId}`;
    const descriptionKey = [line?.module, line?.category, line?.description]
        .map((value) => text(value).toLowerCase())
        .join("|");
    return descriptionKey.replace(/\|/g, "").trim() ? `text:${descriptionKey}` : "";
}

function findExistingLine(input, existingLines = []) {
    const key = quotationLineKey(input);
    if (!key) return null;
    return existingLines.find((line) => quotationLineKey(line) === key) || null;
}

function vendorQuantityTaxChanges(previousLines = [], nextLines = []) {
    const previousByKey = new Map(previousLines.map((line) => [quotationLineKey(line), line]));
    return nextLines.flatMap((line) => {
        const key = quotationLineKey(line);
        const previous = key ? previousByKey.get(key) : null;
        const previousQuantity = previous ? number(previous.vendorQuantity ?? previous.quantity, 0) : null;
        const previousTaxPercent = previous ? number(previous.vendorTaxPercent ?? previous.taxPercent, 15) : null;
        const vendorQuantity = number(line.vendorQuantity ?? line.quantity, 0);
        const vendorTaxPercent = number(line.vendorTaxPercent ?? line.taxPercent, 15);
        const changed = !previous || previousQuantity !== vendorQuantity || previousTaxPercent !== vendorTaxPercent;
        if (!changed) return [];
        return [{
            lineKey: key || "",
            description: text(line.description),
            changeType: previous ? "updated" : "added",
            adminQuantity: line.adminQuantity == null ? null : number(line.adminQuantity),
            previousQuantity,
            vendorQuantity,
            adminTaxPercent: line.adminTaxPercent == null ? null : number(line.adminTaxPercent),
            previousTaxPercent,
            vendorTaxPercent,
        }];
    });
}

function recompute(quotation) {
    const allLines = [
        ...(Array.isArray(quotation.lines) ? quotation.lines : []),
        ...(Array.isArray(quotation.manualAdditions) ? quotation.manualAdditions : []),
    ];
    const subtotal = allLines.reduce((sum, line) => sum + number(line.vendorRate || 0) * number(line.quantity || 0), 0);
    const taxTotal = allLines.reduce((sum, line) => {
        const rate = number(line.vendorRate || 0) * number(line.quantity || 0);
        return sum + rate * (number(line.taxPercent, 15) / 100);
    }, 0);
    quotation.subtotal = subtotal;
    quotation.taxTotal = taxTotal;
    quotation.grandTotal = subtotal + taxTotal + number(quotation.otherCharges);
    return quotation;
}

async function notifyQuotationSafely(label, task) {
    try { await task(); }
    catch (error) { console.error(`[quotationService] ${label} notification failed`, error?.message || error); }
}

async function ensureVendor(vendorId) {
    const vendor = await Vendor.findOne({ _id: vendorId, accountStatus: "APPROVED" }).lean();
    if (!vendor) throw new QuotationServiceError("Only approved vendors can receive quotations.", { code: "VENDOR_NOT_APPROVED", statusCode: 422 });
    return vendor;
}

function assertVendorScope(quotation, actor) {
    if (isVendor(actor)) {
        const vendorId = actorVendorId(actor);
        if (!vendorId || String(quotation.vendorId) !== String(vendorId)) {
            throw new QuotationServiceError("You can only access quotations assigned to your vendor account.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
        }
    }
}

async function audit(action, quotation, actor, request, metadata = {}, changes = null) {
    try {
        await auditService.recordAudit({
            action,
            module: "quotation",
            title: `Quotation ${action.replace(/_/g, " ")}`,
            description: quotation?.quotationNo || "",
            actor: actor?.actor || actor || null,
            request,
            entityType: "quotation",
            entityId: String(quotation?._id || quotation?.id || ""),
            entityName: quotation?.quotationNo || quotation?.projectTitle || "",
            vendorId: quotation?.vendorId || null,
            metadata,
            changes,
        });
    } catch (error) {
        console.error("[quotationService] audit write failed", error);
    }
}


export async function listQuotationValidityPeriods({ actor } = {}) {
    if (!isVendor(actor) && !isInternal(actor)) {
        throw new QuotationServiceError("Authenticated account cannot read quotation validity settings.", { code: "VALIDITY_SETTINGS_FORBIDDEN", statusCode: 403 });
    }

    const rows = typeof ValidityPeriod.findActive === "function"
        ? await ValidityPeriod.findActive()
        : await ValidityPeriod.find({ status: true }).sort({ sortOrder: 1, name: 1 });

    return rows
        .map((row) => {
            const name = text(row.name);
            const match = name.match(/\d+/);
            const days = match ? Number(match[0]) : 0;
            return {
                id: String(row._id),
                name,
                description: text(row.description),
                days,
                status: row.status === true,
                sortOrder: number(row.sortOrder, 0),
            };
        })
        .filter((row) => row.days > 0);
}

export async function listActiveUnits({ actor } = {}) {
    if (!isVendor(actor) && !isInternal(actor)) {
        throw new QuotationServiceError("Authenticated account cannot read unit settings.", {
            code: "UNIT_SETTINGS_FORBIDDEN",
            statusCode: 403,
        });
    }

    const rows = await Unit.find({ status: true })
        .select("name status sortOrder")
        .sort({ sortOrder: 1, name: 1 })
        .lean();

    return rows.map((row) => ({
        id: String(row._id),
        name: text(row.name),
        status: row.status === true,
        sortOrder: number(row.sortOrder, 0),
    })).filter((row) => row.name);
}

export async function listActiveBOQCategories({ actor } = {}) {
    if (!isVendor(actor) && !isInternal(actor)) {
        throw new QuotationServiceError("Authenticated account cannot read BOQ category settings.", {
            code: "BOQ_CATEGORY_SETTINGS_FORBIDDEN",
            statusCode: 403,
        });
    }

    const rows = await RateCategory.find({ status: true })
        .select("categoryType category status sortOrder")
        .sort({ sortOrder: 1, categoryType: 1, category: 1 })
        .lean();

    return rows.map((row) => ({
        id: String(row._id),
        categoryType: text(row.categoryType),
        category: text(row.category),
        status: row.status === true,
        sortOrder: number(row.sortOrder, 0),
    }));
}

export async function listQuotations({ actor, page = 1, limit = 50, search = "", status = "", vendorId = "" } = {}) {
    const safePage = Math.max(1, Number.parseInt(String(page), 10) || 1);
    const safeLimit = Math.min(200, Math.max(1, Number.parseInt(String(limit), 10) || 50));
    const filter = {};
    if (isVendor(actor)) filter.vendorId = actorVendorId(actor);
    else if (vendorId) filter.vendorId = oid(vendorId, "vendorId");
    if (status) {
        const normalizedStatus = QUOTATION_STATUSES.find(
            (candidate) => candidate.toLowerCase() === String(status).trim().toLowerCase(),
        );
        if (normalizedStatus) filter.status = normalizedStatus;
    }
    const term = text(search);
    if (term) {
        const regex = new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
        filter.$or = [{ quotationNo: regex }, { vendorName: regex }, { projectTitle: regex }, { clientName: regex }];
    }
    const [rows, total] = await Promise.all([
        Quotation.find(filter).sort({ updatedAt: -1, _id: -1 }).skip((safePage - 1) * safeLimit).limit(safeLimit),
        Quotation.countDocuments(filter),
    ]);
    return { data: await serializeManyWithBOQ(rows, actor), pagination: { page: safePage, limit: safeLimit, total, totalPages: Math.ceil(total / safeLimit) } };
}

export async function getQuotation(id, { actor } = {}) {
    const row = await Quotation.findById(oid(id, "quotationId"));
    if (!row) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(row, actor);
    return serializeWithBOQ(row, actor);
}

export async function createQuotation(payload, { actor, request = null } = {}) {
    if (!isInternal(actor) && !isVendor(actor)) throw new QuotationServiceError("Authenticated account cannot create quotations.", { code: "QUOTATION_CREATE_FORBIDDEN", statusCode: 403 });
    const vendorId = oid(payload?.vendorId ?? actor?.vendorId, "vendorId");
    if (!vendorId) throw new QuotationServiceError("Vendor is required.", { code: "VENDOR_ID_REQUIRED", statusCode: 422 });
    if (isVendor(actor) && String(vendorId) !== String(actorVendorId(actor))) throw new QuotationServiceError("Vendor scope is invalid.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
    const vendor = await ensureVendor(vendorId);
    const quotationNo = text(payload?.quotationNo) || await nextNumber("quotation", "QT");
    const lines = Array.isArray(payload?.lines) ? payload.lines.map((line) => normalizeLine(line, { allowVendorRate: Boolean(payload?.vendorEntry), vendorEdit: isVendor(actor) })) : [];
    const q = new Quotation({
        quotationNo,
        boqId: oid(payload?.boqId, "boqId"),
        vendorId,
        vendorName: vendor.companyName || vendor.name || vendor.vendorName || "Vendor",
        vendorEmail: vendor.email || vendor.primaryEmail || "",
        projectTitle: text(payload?.projectTitle),
        projectSiteLocation: text(payload?.projectSiteLocation ?? payload?.projectLocation),
        clientName: text(payload?.clientName),
        siteSurveyReference: text(payload?.siteSurveyReference),
        category: text(payload?.category),
        formTemplateId: oid(payload?.formTemplateId, "formTemplateId"),
        formTemplateName: text(payload?.formTemplateName ?? payload?.formTemplate),
        currency: text(payload?.currency) || "USD",
        quotationDate: date(payload?.quotationDate) || new Date(),
        dueDate: date(payload?.dueDate ?? payload?.responseDueDate),
        validUntil: date(payload?.validUntil),
        validityDays: payload?.validityDays == null ? null : number(payload.validityDays),
        scopeSummary: text(payload?.scopeSummary),
        terms: text(payload?.terms),
        status: text(payload?.status) || "Draft",
        lines,
        manualAdditions: Array.isArray(payload?.manualAdditions) ? payload.manualAdditions.map((line) => normalizeLine(line, { allowVendorRate: Boolean(payload?.vendorEntry), vendorEdit: isVendor(actor) })) : [],
        paymentSchedule: Array.isArray(payload?.paymentSchedule) ? payload.paymentSchedule.map(normalizePaymentInstallment) : [],
        taxTotal: Math.max(0, number(payload?.taxTotal)),
        otherCharges: Math.max(0, number(payload?.otherCharges)),
        createdBy: actorId(actor),
        updatedBy: actorId(actor),
    });
    recompute(q);
    q.workflowHistory.push({ action: "created", status: q.status, actorUserId: actorId(actor), actorType: actor?.userType || "system" });
    await q.save();
    await audit("created", q, actor, request);
    if (isInternal(actor)) await notifyQuotationSafely("quotation generated email", () => sendVendorWorkflowEmail({ vendorId: q.vendorId, subject: `New quotation generated — ${q.quotationNo}`, title: "New quotation generated", message: `A new quotation has been generated for ${q.projectTitle || q.quotationNo}. Please sign in to the vendor portal to review it.`, details: [{ label: "Quotation", value: q.quotationNo }, { label: "Project", value: q.projectTitle }, { label: "Status", value: q.status }] }));
    return serializeWithBOQ(q, actor);
}

export async function updateQuotation(id, payload, { actor, request = null } = {}) {
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(q, actor);

    const previousStatus = q.status;
    if (isVendor(actor) && !["Form Approved", "Form Rejected", "Draft"].includes(q.status)) {
        throw new QuotationServiceError("This quotation is not editable from the vendor portal.", { code: "QUOTATION_NOT_EDITABLE", statusCode: 409 });
    }

    if (payload?.projectTitle !== undefined) q.projectTitle = text(payload.projectTitle);
    if (payload?.projectSiteLocation !== undefined || payload?.projectLocation !== undefined) q.projectSiteLocation = text(payload.projectSiteLocation ?? payload.projectLocation);
    if (payload?.scopeSummary !== undefined) q.scopeSummary = text(payload.scopeSummary);
    if (payload?.terms !== undefined) q.terms = text(payload.terms);
    if (payload?.validityDays !== undefined) q.validityDays = number(payload.validityDays, q.validityDays || 0);
    if (payload?.validUntil !== undefined) q.validUntil = date(payload.validUntil);
    if (payload?.currency !== undefined) q.currency = text(payload.currency) || q.currency;
    if (payload?.taxTotal !== undefined) q.taxTotal = Math.max(0, number(payload.taxTotal));
    if (payload?.otherCharges !== undefined) q.otherCharges = Math.max(0, number(payload.otherCharges));

    // Retain the original Admin quantities/tax values before replacing lines.
    // Current quantity/taxPercent remain the live Vendor values used in totals.
    const previousLines = (q.lines || []).map((line) => line?.toObject ? line.toObject() : { ...line });
    const previousManualAdditions = (q.manualAdditions || []).map((line) => line?.toObject ? line.toObject() : { ...line });
    if (Array.isArray(payload?.lines)) {
        q.lines = payload.lines.map((line) => {
            if (!isVendor(actor)) return normalizeLine(line, { allowVendorRate: payload?.vendorEntry === true });
            const baseline = findExistingLine(line, previousLines);
            return normalizeLine(line, { allowVendorRate: true, baseline, vendorEdit: true });
        });
    }
    if (Array.isArray(payload?.manualAdditions)) {
        q.manualAdditions = payload.manualAdditions.map((line) => {
            if (!isVendor(actor)) return normalizeLine(line, { allowVendorRate: payload?.vendorEntry === true });
            const baseline = findExistingLine(line, previousManualAdditions);
            return normalizeLine(line, { allowVendorRate: true, baseline, vendorEdit: true });
        });
    }
    if (isVendor(actor) && (Array.isArray(payload?.lines) || Array.isArray(payload?.manualAdditions))) {
        const changes = [
            ...vendorQuantityTaxChanges(previousLines, q.lines || []),
            ...vendorQuantityTaxChanges(previousManualAdditions, q.manualAdditions || []),
        ];
        if (changes.length) {
            if (!Array.isArray(q.vendorEditHistory)) q.vendorEditHistory = [];
            q.vendorEditHistory.push({
                revision: number(q.revision, 1) + 1,
                updatedBy: actorId(actor),
                updatedAt: new Date(),
                changes,
            });
        }
    }
    if (Array.isArray(payload?.paymentSchedule)) q.paymentSchedule = payload.paymentSchedule.map(normalizePaymentInstallment);

    if (payload?.status) {
        const requested = String(payload.status).trim();
        if (!QUOTATION_STATUSES.includes(requested)) throw new QuotationServiceError("Invalid quotation status.", { code: "INVALID_QUOTATION_STATUS", statusCode: 422 });
        if (isVendor(actor)) {
            if (!["Draft", "Submitted"].includes(requested)) {
                throw new QuotationServiceError("Vendors can only save a quotation as Draft or submit it for approval.", { code: "VENDOR_STATUS_CHANGE_FORBIDDEN", statusCode: 403 });
            }
            if (requested === "Submitted") {
                if (!["Form Approved", "Draft", "Form Rejected"].includes(q.status)) throw new QuotationServiceError("Survey approval is required before quotation submission.", { code: "SURVEY_APPROVAL_REQUIRED", statusCode: 409 });
                if ((!Array.isArray(q.lines) || q.lines.length === 0) && (!Array.isArray(q.manualAdditions) || q.manualAdditions.length === 0)) throw new QuotationServiceError("Add at least one BOQ line or manual item before submitting the quotation.", { code: "QUOTATION_LINES_REQUIRED", statusCode: 422 });
            }
        }
        q.status = requested;
    }

    q.updatedBy = actorId(actor);
    q.revision = number(q.revision, 1) + 1;
    recompute(q);
    q.workflowHistory.push({ action: q.status === "Submitted" ? "submitted" : "updated", status: q.status, actorUserId: actorId(actor), actorType: actor?.userType || "system", remarks: text(payload?.remarks) });
    await q.save();
    if (q.boqId && q.status === "Submitted") {
        await BOQ.findByIdAndUpdate(
            q.boqId,
            { $set: { status: "Pending Approval", updatedBy: actorId(actor) } },
        );
    }
    await audit(q.status === "Submitted" ? "submitted" : "updated", q, actor, request, {}, { beforeStatus: previousStatus, afterStatus: q.status });
    if (previousStatus !== q.status && isVendor(actor) && q.status === "Submitted") {
        await notifyQuotationSafely("vendor submission", () => notifyWorkspaceOwners({
            eventType: "quotation_submitted",
            title: "Vendor submitted quotation",
            message: `${text(q.vendorName) || "A vendor"} submitted ${text(q.quotationNo) || "a quotation"} for ${text(q.projectTitle) || "a project"}.`,
            payload: { quotationId: String(q._id), boqId: q.boqId ? String(q.boqId) : null, quotationNo: q.quotationNo, projectTitle: q.projectTitle, vendorId: String(q.vendorId), status: q.status },
            excludeUserId: actorId(actor) ? String(actorId(actor)) : null,
        }));
    }
    if (previousStatus !== q.status && isVendor(actor) && q.status === "Submitted") {
        await notifyQuotationSafely("quotation edited submitted email", () => sendCompanyWorkflowEmail({ subject: `Quotation edited and submitted — ${q.quotationNo}`, title: "Quotation edited and submitted", message: `${q.vendorName} submitted an updated quotation for review.`, details: [{ label: "Quotation", value: q.quotationNo }, { label: "Vendor", value: q.vendorName }, { label: "Project", value: q.projectTitle }, { label: "Revision", value: q.revision }] }));
    }
    if (previousStatus !== q.status && isInternal(actor) && ["Awarded", "Rejected", "Not Awarded"].includes(q.status)) {
        await notifyQuotationSafely("vendor decision", () => notifyVendorAdmins({
            vendorId: q.vendorId,
            eventType: q.status === "Awarded" ? "quotation_awarded" : q.status === "Rejected" ? "quotation_rejected" : "quotation_not_awarded",
            title: q.status === "Awarded" ? "Quotation awarded" : q.status === "Rejected" ? "Quotation needs revision" : "Quotation not awarded",
            message: `${text(q.quotationNo) || "Your quotation"} for ${text(q.projectTitle) || "the project"} was ${q.status === "Awarded" ? "awarded" : q.status === "Rejected" ? "rejected" : "not selected"}.${text(payload?.remarks) ? ` Remarks: ${text(payload.remarks)}` : ""}`,
            payload: { quotationId: String(q._id), boqId: q.boqId ? String(q.boqId) : null, quotationNo: q.quotationNo, projectTitle: q.projectTitle, status: q.status },
        }));
        await notifyQuotationSafely("quotation decision email", () => sendVendorWorkflowEmail({ vendorId: q.vendorId, subject: `Quotation ${q.status.toLowerCase()} — ${q.quotationNo}`, title: q.status === "Awarded" ? "Quotation awarded" : q.status === "Rejected" ? "Quotation rejected" : "Quotation not awarded", message: `Your quotation ${q.quotationNo} for ${q.projectTitle || "the project"} was ${q.status.toLowerCase()}.${text(payload?.remarks) ? ` Remarks: ${text(payload.remarks)}` : ""}`, details: [{ label: "Quotation", value: q.quotationNo }, { label: "Project", value: q.projectTitle }, { label: "Status", value: q.status }] }));
    }
    return serializeWithBOQ(q, actor);
}

export async function deleteQuotation(id, { actor, request = null } = {}) {
    if (!isInternal(actor)) throw new QuotationServiceError("Only internal users can delete quotations.", { code: "QUOTATION_DELETE_FORBIDDEN", statusCode: 403 });
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    await Quotation.deleteOne({ _id: q._id });
    await audit("deleted", q, actor, request);
    return { id: String(q._id), quotationNo: q.quotationNo };
}

export async function submitSurvey(id, payload, { actor, request = null } = {}) {
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(q, actor);
    if (isInternal(actor)) throw new QuotationServiceError("Internal users cannot submit the vendor survey.", { code: "SURVEY_SUBMIT_FORBIDDEN", statusCode: 403 });
    if (!["Form Issued", "Form Rejected"].includes(q.status)) throw new QuotationServiceError("This survey is not open for submission.", { code: "SURVEY_NOT_OPEN", statusCode: 409 });
    const templateId = q.formTemplateId || oid(payload?.templateId, "templateId");
    if (!templateId) throw new QuotationServiceError("Survey template is required.", { code: "SURVEY_TEMPLATE_REQUIRED", statusCode: 422 });
    const template = await SurveyTemplate.findOne({ _id: templateId, status: { $ne: "archived" } }).lean();
    if (!template) throw new QuotationServiceError("Survey template was not found.", { code: "SURVEY_TEMPLATE_NOT_FOUND", statusCode: 404 });
    const response = payload?.response && typeof payload.response === "object" && !Array.isArray(payload.response) ? payload.response : {};
    let surveyResponse = q.survey.responseId ? await SurveyResponse.findById(q.survey.responseId) : null;
    if (!surveyResponse) {
        surveyResponse = new SurveyResponse({ templateId, projectId: null, respondentId: actorId(actor), response, status: "submitted", revision: 1, surveyDate: date(payload?.surveyDate), submittedAt: new Date(), createdBy: actorId(actor), updatedBy: actorId(actor) });
    } else {
        surveyResponse.response = response;
        surveyResponse.status = "submitted";
        surveyResponse.submittedAt = new Date();
        surveyResponse.updatedBy = actorId(actor);
        surveyResponse.revision = number(surveyResponse.revision, 1) + 1;
    }
    await surveyResponse.save();
    q.formTemplateId = template._id;
    q.formTemplateName = template.name;
    q.survey = { ...(q.survey?.toObject?.() || q.survey || {}), templateId: template._id, responseId: surveyResponse._id, status: "submitted", response, revision: surveyResponse.revision, submittedAt: surveyResponse.submittedAt, rejectedAt: null, rejectedBy: null, rejectionReason: "" };
    q.status = "Form Submitted";
    q.updatedBy = actorId(actor);
    q.revision = number(q.revision, 1) + 1;
    q.workflowHistory.push({ action: "survey_submitted", status: q.status, actorUserId: actorId(actor), actorType: actor?.userType || "vendor" });
    await q.save();
    await audit("survey_submitted", q, actor, request, { surveyResponseId: String(surveyResponse._id) });
    await notifyQuotationSafely("survey submitted", () => notifyWorkspaceOwners({
        eventType: "quotation_form_submitted",
        title: "Vendor quotation form submitted",
        message: `${text(q.vendorName) || "A vendor"} submitted the form for ${text(q.projectTitle) || text(q.quotationNo) || "a quotation"}.`,
        payload: { quotationId: String(q._id), boqId: q.boqId ? String(q.boqId) : null, quotationNo: q.quotationNo, projectTitle: q.projectTitle, vendorId: String(q.vendorId), status: q.status },
        excludeUserId: actorId(actor) ? String(actorId(actor)) : null,
    }));
    await notifyQuotationSafely("survey submitted company email", () => sendCompanyWorkflowEmail({ subject: `Survey form submitted — ${q.quotationNo}`, title: "Survey form submitted", message: `${q.vendorName} submitted the survey form for review.`, details: [{ label: "Quotation", value: q.quotationNo }, { label: "Vendor", value: q.vendorName }, { label: "Project", value: q.projectTitle }] }));
    return serialize(q);
}

export async function reviewSurvey(id, { decision, remarks = "" }, { actor, request = null } = {}) {
    if (!isInternal(actor)) throw new QuotationServiceError("Only internal users can review vendor surveys.", { code: "SURVEY_REVIEW_FORBIDDEN", statusCode: 403 });
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    if (q.status !== "Form Submitted") throw new QuotationServiceError("Only submitted surveys can be approved or rejected.", { code: "SURVEY_REVIEW_INVALID_STATE", statusCode: 409 });
    const normalized = String(decision || "").trim().toLowerCase();
    if (!['approve', 'reject'].includes(normalized)) throw new QuotationServiceError("Survey decision must be approve or reject.", { code: "INVALID_SURVEY_DECISION", statusCode: 422 });
    if (normalized === "reject" && !text(remarks)) throw new QuotationServiceError("Rejection remarks are required.", { code: "SURVEY_REJECTION_REMARKS_REQUIRED", statusCode: 422 });

    const now = new Date();
    q.status = normalized === "approve" ? "Form Approved" : "Form Rejected";
    q.survey.status = normalized === "approve" ? "approved" : "rejected";
    q.survey.approvedAt = normalized === "approve" ? now : null;
    q.survey.approvedBy = normalized === "approve" ? actorId(actor) : null;
    q.survey.rejectedAt = normalized === "reject" ? now : null;
    q.survey.rejectedBy = normalized === "reject" ? actorId(actor) : null;
    q.survey.rejectionReason = normalized === "reject" ? text(remarks) : "";
    q.updatedBy = actorId(actor);
    q.revision = number(q.revision, 1) + 1;
    q.workflowHistory.push({ action: normalized === "approve" ? "survey_approved" : "survey_rejected", status: q.status, actorUserId: actorId(actor), actorType: actor?.userType || "internal", remarks: text(remarks) });
    await q.save();

    if (q.survey.responseId) {
        await SurveyResponse.findByIdAndUpdate(q.survey.responseId, normalized === "approve"
            ? { $set: { status: "approved", reviewedAt: now, reviewedBy: actorId(actor), updatedBy: actorId(actor) } }
            : { $set: { status: "rejected", rejectedAt: now, rejectedBy: actorId(actor), rejectionReason: text(remarks), updatedBy: actorId(actor) } },
        );
    }
    await audit(normalized === "approve" ? "survey_approved" : "survey_rejected", q, actor, request, { remarks: text(remarks) });
    await notifyQuotationSafely("survey review", () => notifyVendorAdmins({
        vendorId: q.vendorId,
        eventType: normalized === "approve" ? "quotation_form_approved" : "quotation_form_rejected",
        title: normalized === "approve" ? "Quotation form approved" : "Quotation form needs changes",
        message: `${text(q.quotationNo) || "Your quotation form"} for ${text(q.projectTitle) || "the project"} was ${normalized === "approve" ? "approved" : "rejected"}.${normalized === "reject" && text(remarks) ? ` Remarks: ${text(remarks)}` : ""}`,
        payload: { quotationId: String(q._id), boqId: q.boqId ? String(q.boqId) : null, quotationNo: q.quotationNo, projectTitle: q.projectTitle, status: q.status },
    }));
    await notifyQuotationSafely("survey review email", () => sendVendorWorkflowEmail({ vendorId: q.vendorId, subject: `Survey form ${normalized === "approve" ? "approved" : "rejected"} — ${q.quotationNo}`, title: normalized === "approve" ? "Survey form accepted" : "Survey form rejected", message: `Your survey form for ${q.quotationNo} was ${normalized === "approve" ? "accepted" : "rejected"}.${normalized === "reject" && text(remarks) ? ` Remarks: ${text(remarks)}` : ""}`, details: [{ label: "Quotation", value: q.quotationNo }, { label: "Project", value: q.projectTitle }, { label: "Status", value: q.status }] }));
    return serializeWithBOQ(q, actor);
}

export async function getQuotationSurvey(id, { actor } = {}) {
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(q, actor);
    let response = q.survey?.response || {};
    if (q.survey?.responseId) {
        const row = await SurveyResponse.findById(q.survey.responseId).lean();
        if (row?.response) response = row.response;
    }
    const template = q.formTemplateId ? await SurveyTemplate.findById(q.formTemplateId).lean() : null;
    return { quotation: await serializeWithBOQ(q, actor), template: template ? { id: String(template._id), name: template.name, schema: template.schema, status: template.status, version: template.version } : null, response };
}

export async function buildQuotationComparison(id, { actor } = {}) {
    const q = await Quotation.findById(oid(id, "quotationId"));
    if (!q) throw new QuotationServiceError("Quotation was not found.", { code: "QUOTATION_NOT_FOUND", statusCode: 404 });
    assertVendorScope(q, actor);
    const sourceLines = [
        ...(Array.isArray(q.lines) ? q.lines : []),
        ...(Array.isArray(q.manualAdditions) ? q.manualAdditions : []),
    ];
    const ids = sourceLines.map((line) => line.masterRateItemId).filter(Boolean);
    const rates = ids.length ? await MasterRateItem.find({ _id: { $in: ids } }).lean() : [];
    const map = new Map(rates.map((rate) => [String(rate._id), rate]));
    return sourceLines.map((line) => {
        const master = map.get(String(line.masterRateItemId));
        const benchmark = number(master?.standardRate ?? line.masterRate, 0);
        const vendorRate = number(line.vendorRate, 0);
        const variance = benchmark > 0 ? ((vendorRate - benchmark) / benchmark) * 100 : 0;
        return { ...line.toObject?.() || line, masterRate: benchmark, vendorRate, variance };
    });
}
