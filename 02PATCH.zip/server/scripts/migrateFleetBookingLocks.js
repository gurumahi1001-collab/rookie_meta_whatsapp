import { connectDatabase, shutdownDatabase } from "../src/config/database.js";
import { FleetVehicle, FleetRequisition } from "../src/models/Fleet.js";

const applyChanges = process.argv.includes("--apply");
const ACTIVE_STATUSES = ["Approved", "Picked", "Returned"];

async function main() {
    await connectDatabase();

    const requisitions = await FleetRequisition.find({ status: { $in: ACTIVE_STATUSES } })
        .sort({ approvedAt: 1, createdAt: 1, _id: 1 })
        .select("_id fleetId vendorId vendorName status approvedAt approvedBy")
        .lean();

    const groups = new Map();
    const issues = [];
    let alreadyLocked = 0;
    let prepared = 0;
    let applied = 0;

    for (const requisition of requisitions) {
        if (!requisition.fleetId) {
            issues.push({ requisitionId: String(requisition._id), reason: "Active requisition has no fleetId." });
            continue;
        }
        const fleetId = String(requisition.fleetId);
        const group = groups.get(fleetId) || [];
        group.push(requisition);
        groups.set(fleetId, group);
    }

    for (const [fleetId, group] of groups) {
        if (group.length > 1) {
            issues.push({ fleetId, requisitionIds: group.map((item) => String(item._id)), reason: "Multiple active requisitions reference the same vehicle. Resolve the correct vendor/trip manually; no lock was changed." });
            continue;
        }

        const requisition = group[0];
        const vehicle = await FleetVehicle.findById(fleetId)
            .select("_id fleetCode status bookedByRequisitionId assignedVendorId assignedVendorName")
            .lean();

        if (!vehicle) {
            issues.push({ fleetId, requisitionId: String(requisition._id), reason: "Referenced fleet vehicle does not exist." });
            continue;
        }
        if (vehicle.bookedByRequisitionId && String(vehicle.bookedByRequisitionId) !== String(requisition._id)) {
            issues.push({ fleetId, requisitionId: String(requisition._id), existingLock: String(vehicle.bookedByRequisitionId), reason: "Vehicle is already locked by a different requisition." });
            continue;
        }
        if (vehicle.bookedByRequisitionId && String(vehicle.bookedByRequisitionId) === String(requisition._id)) {
            alreadyLocked += 1;
            continue;
        }
        if (vehicle.status !== "active") {
            issues.push({ fleetId, requisitionId: String(requisition._id), reason: "Vehicle is inactive while the requisition remains active." });
            continue;
        }

        prepared += 1;
        if (!applyChanges) continue;

        const result = await FleetVehicle.updateOne(
            { _id: vehicle._id, status: "active", bookedByRequisitionId: null },
            { $set: {
                bookedByRequisitionId: requisition._id,
                assignedVendorId: requisition.vendorId,
                assignedVendorName: requisition.vendorName || "",
                assignedAt: requisition.approvedAt || new Date(),
                assignedBy: requisition.approvedBy || null,
            } },
        );

        if (Number(result.modifiedCount || 0) === 1) applied += 1;
        else issues.push({ fleetId, requisitionId: String(requisition._id), reason: "Vehicle lock changed during migration. Re-run the dry-run and review this record." });
    }

    console.log(JSON.stringify({
        mode: applyChanges ? "apply" : "dry-run",
        activeRequisitions: requisitions.length,
        prepared,
        alreadyLocked,
        applied,
        issues,
        nextStep: applyChanges ? "Review issues and re-run without --apply to verify remaining lock state." : "Run with --apply only after reviewing the report and taking a database backup.",
    }, null, 2));
}

try {
    await main();
} catch (error) {
    console.error("[fleet-lock-migration] failed", error);
    process.exitCode = 1;
} finally {
    await shutdownDatabase().catch((error) => console.error("[fleet-lock-migration] database shutdown failed", error));
}
