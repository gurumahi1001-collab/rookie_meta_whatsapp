# ARGUS production patch — Fleet booking, workflow email and real-time notifications

## What changed

### Fleet booking workflow
1. Admin creates a fleet vehicle without assigning it to a vendor.
2. Vendor fleet list displays all active fleet vehicles and an availability status (`Available` / `Booked`), without exposing the other vendor's identity or booking reference.
3. A vendor can request an available vehicle. Requests remain `Requested` until an administrator reviews them.
4. Admin approves one request and selects an available vehicle when the request did not already specify one. The backend atomically locks the vehicle to that requisition and vendor.
5. Competing pending requests for that same vehicle are rejected after the first successful booking. Vendors cannot change assignment fields through the vehicle edit endpoint.
6. Vehicle remains booked through `Approved`, `Picked`, and `Returned`. If a claim is raised at trip return, the vehicle remains booked while the claim is `Pending` or `Approved`. Claim settlement automatically completes the linked trip; a rejected claim requires admin to complete the trip. The vehicle becomes available only after the requisition reaches `Completed`.

The existing `assignedVendor*` fields are retained for compatibility/reporting. The authoritative lock is `bookedByRequisitionId`; availability is calculated from active requisitions and this lock.

### Workflow emails
- Vendor: new quotation generated; survey accepted/rejected; quotation awarded/rejected/not awarded; fleet request approved/rejected; fleet claim paid/not paid; invoice accepted/rejected/paid.
- Company contact email from Company Profile: survey submitted; vendor-edited quotation submitted; project completed; invoice awaiting review; fleet request received; fleet claim submitted.
- Vendor recipient resolution deduplicates the vendor contact, secondary contact, and active vendor user email addresses. The company recipient comes from `CompanySetting.contactEmail`.
- Email delivery is best-effort: missing SMTP/company email or SMTP errors are logged and do not roll back a business transaction. Workflow calls await the mail helper, so configure SMTP connection/greeting/socket timeouts. Existing invitation email behavior is not changed.

### Real-time notification delivery
- Existing MongoDB notification records remain the source of truth.
- `src/realtime/realtimeService.js` adds an authenticated WebSocket hub. It validates the access JWT, active user, active role, realm and allowed user type. A socket is closed when its access token expires. Persisted notifications are pushed to all active sessions for the recipient user.
- Admin and vendor portals subscribe through one reusable client module each. The existing 30-second polling remains as a fallback.
- WebSocket URL is `${VITE_API_URL}/ws`, e.g. `wss://api.example.com/api/v1/ws`.

## Files included

Only changed/new source files are included in this patch archive, not full application packages. The patch contains the server workflow changes, the two frontend fleet/header changes, the new email and realtime services, and this README.

## Apply / deploy

1. Back up the current admin frontend, vendor frontend, backend source, and MongoDB database.
2. Merge the included files into the corresponding source directories. Do not replace unrelated files.
3. In the backend project root, install and save the WebSocket dependency with your existing package manager, e.g. `npm install ws`. Keep the resulting `package.json` and lockfile changes in your deployment repository. The uploaded source archive did not contain package manifests or lockfiles, so no dependency version or lockfile could be patched here.
4. Confirm the backend package uses ESM (`"type": "module"`) and has a supported Node.js version. The new `src/server.js` is the listener/bootstrap entrypoint; configure your production process manager to run `node src/server.js` (or point the existing script to it). If your project already has a production listener, merge `initializeRealtime(httpServer)` into that listener instead of running two listeners.
5. Verify `MONGO_URI`, JWT access secret/issuer/audience, SMTP settings, and `CORS_ALLOWED_ORIGINS` are configured in production.
6. Configure the Company Profile contact email. Configure SMTP `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`/`SMTP_PASSWORD` (as applicable), `SMTP_FROM_EMAIL`, `SMTP_FROM_NAME`, and enable email notifications according to the existing `env.js` configuration.
7. Ensure reverse proxy/load balancer supports WebSocket upgrades (`Upgrade` / `Connection`) on `${API_PREFIX}/${API_VERSION}/ws` and forwards the request to the Node process. Use `wss` behind HTTPS.
8. Deploy backend first, then both frontends. Rebuild admin and vendor frontends with the correct `VITE_API_URL`.
9. Verify with two vendor accounts requesting the same vehicle at the same time: only one admin approval may win; the other request must be rejected. Verify returned-with-claim stays booked until settlement.
10. Check the admin and vendor notification bell, company email, and vendor email using test accounts before production traffic.

## Production notes and remaining issues to verify

- **Source-package limitation:** the uploaded archive included only nested `src` trees. It did not include `package.json`, lockfiles, `.env.example`, deployment scripts, tests, or existing PM2/systemd/Docker configuration. Dependency and process-manager integration therefore need to be merged into the full repository as described above.
- **Existing data migration:** old fleet rows may already contain `assignedVendorId` values without a matching active requisition. Review these legacy assignments before rollout; do not automatically clear an old vendor value until you confirm there is no in-progress trip.
- **Existing in-progress records:** a dry-run migration utility is included at `server/scripts/migrateFleetBookingLocks.js`. From the backend root, run `node scripts/migrateFleetBookingLocks.js` and review all conflicts. Back up MongoDB, then run `node scripts/migrateFleetBookingLocks.js --apply` to backfill locks for unambiguous `Approved`/`Picked`/`Returned` requisitions. The script deliberately skips multiple active requisitions for one vehicle, missing fleet references, inactive vehicles, and conflicting existing locks; resolve those records manually. The vendor fleet list treats any non-null booking lock as booked, even when a matching requisition cannot be found.
- **Multi-instance deployments:** this WebSocket hub is process-local. If ARGUS runs multiple backend instances, socket delivery must be backed by a shared pub/sub adapter (e.g. Redis) or sticky routing plus notification polling. The MongoDB inbox remains durable; only the instant push can be missed between instances.
- **Socket token transport:** browsers pass the current access token as a WebSocket subprotocol because the native browser WebSocket API cannot set an Authorization header. The server selects only the non-secret `argus.v1` subprotocol and closes the connection when the JWT expires. Configure reverse-proxy/access logs to redact `Sec-WebSocket-Protocol` values. Prefer a short-lived, single-use socket ticket endpoint for stricter token handling in a future security hardening pass.
- **Concurrent requisition decisions:** approval and rejection now commit only while the requisition is still `Requested`. Vehicle locking is atomic, and the requisition status update is conditional, preventing two admins from assigning different vehicles to the same request. Run the competing-approval test on staging before release.
- **No automated integration suite was supplied.** Run the fleet race test, vendor data-isolation checks, mail recipient checks, JWT expiry/revocation checks, and regression test the quotation/survey/invoice/payment/project screens on staging.
- **Existing SMTP configuration is reused.** The code does not introduce an outbound mail queue or retries. For production-scale reliable delivery, use a durable job queue/outbox and monitor failed delivery logs.
- **Project status completion trigger:** notification is sent when the persisted project status changes to `completed` (case-insensitive). Confirm the full app uses that status value in the deployed workflow.
- **Fleet claim policy:** a vehicle returned with a claim remains booked while the claim is `Pending` or `Approved`. Settlement automatically completes the linked trip and releases the lock. Rejection does not automatically close the trip; after rejection, admin must use the existing requisition completion action. The backend blocks manual completion while a linked claim remains `Pending` or `Approved`.
- **TLS and origins:** ensure the WebSocket origin allow-list matches the deployed admin/vendor domains exactly. Do not expose an unrestricted wildcard CORS origin in production.

## Files changed

- Backend: `src/app.js`, `src/server.js`, `scripts/migrateFleetBookingLocks.js`, `src/realtime/realtimeService.js`, `src/models/Fleet.js`, `src/services/fleet/fleetService.js`, `src/services/notification/notificationService.js`, `src/services/email/workflowEmailService.js`, `src/services/quotation/quotationService.js`, `src/services/invoice/invoiceService.js`, `src/services/payment/paymentService.js`, `src/services/project/projectService.js`.
- Admin frontend: `src/api/realtime.ts`, `src/components/Layouts/Header.tsx`, `src/components/fleet/FleetManagement.tsx`.
- Vendor frontend: `src/api/realtime.ts`, `src/components/Layouts/VendorHeader.tsx`, `src/components/fleet/VendorFleet.tsx`.
