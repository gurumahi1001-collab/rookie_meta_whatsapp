<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('egc_applicant_followups')) {
            Schema::create('egc_applicant_followups', function (Blueprint $table) {
                $table->bigIncrements('sno');
                $table->unsignedBigInteger('applicant_id')->index();
                $table->string('title', 160);
                $table->string('contact_method', 24);
                $table->dateTime('follow_up_at')->index();
                $table->string('status', 20)->default('scheduled')->index();
                $table->text('notes')->nullable();
                $table->text('outcome')->nullable();
                $table->unsignedBigInteger('assigned_to')->nullable()->index();
                $table->dateTime('completed_at')->nullable();
                $table->unsignedBigInteger('created_by')->default(0);
                $table->unsignedBigInteger('updated_by')->default(0);
                $table->timestamps();
                $table->index(['applicant_id', 'status', 'follow_up_at'], 'egc_applicant_followups_candidate_status_date_idx');
            });
        }

        if (!Schema::hasTable('egc_applicant_interviews')) {
            Schema::create('egc_applicant_interviews', function (Blueprint $table) {
                $table->bigIncrements('sno');
                $table->unsignedBigInteger('applicant_id')->index();
                $table->string('interview_title', 160);
                $table->string('interview_round', 120);
                $table->dateTime('interview_at')->index();
                $table->unsignedSmallInteger('duration_minutes')->default(30);
                $table->string('interview_category', 120)->nullable();
                $table->string('interview_mode', 80);
                $table->string('interviewer_name', 160)->nullable();
                $table->string('interviewer_email', 190)->nullable();
                $table->string('meeting_link', 2048)->nullable();
                $table->string('location', 500)->nullable();
                $table->string('status', 24)->default('scheduled')->index();
                $table->text('notes')->nullable();
                $table->text('feedback')->nullable();
                $table->unsignedBigInteger('created_by')->default(0);
                $table->unsignedBigInteger('updated_by')->default(0);
                $table->timestamps();
                $table->index(['applicant_id', 'status', 'interview_at'], 'egc_applicant_interviews_candidate_status_date_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('egc_applicant_interviews');
        Schema::dropIfExists('egc_applicant_followups');
    }
};
