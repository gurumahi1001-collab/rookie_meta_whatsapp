# HR Recruiter — Candidate Follow-ups & Interview Schedule

## What changed

The existing Candidate Profile modal now has two tabs **after Application Answers**:

- **Follow-ups** — create and edit recruiter follow-up tasks; track call/email/WhatsApp/SMS/meeting method, date and time, status, plan, outcome, overdue items, and cancellation history.
- **Interview Schedule** — schedule candidate-specific HR/technical/managerial/final-round appointments; record date/time, duration, configured interview category/mode, interviewer details, meeting link or physical location, notes, feedback, and appointment status.

Existing Overview, AI Analysis, Resume, Application Answers, recruitment-history modal, and job-request assessment-stage scheduler are not intentionally changed. Candidate profile appointments use dedicated tables so they do not overwrite online assessment stages or answer/session records. Cancelling an item changes its status and retains the row rather than physically deleting the history.

## Files in this patch

- `resources/views/content/hr_management/hr_recruiter/manage_candidate/candidate_list.blade.php` — profile tabs, forms, history lists, save/edit/status/cancel handling.
- `routes/web.php` — authenticated candidate engagement endpoints.
- `app/Http/Controllers/hr_management/hr_recruiter/CandidateEngagementController.php` — validation and CRUD/status transitions.
- `app/Models/ApplicantFollowUpModel.php`
- `app/Models/ApplicantInterviewModel.php`
- `database/migrations/2026_10_12_000001_create_applicant_engagement_tables.php` — creates the two new tables.

## Deployment

1. Back up the production database and copy the files into the same relative paths in the **full** Laravel application. Merge the `routes/web.php` additions rather than replacing the full route file with a partial version.
2. Confirm the full application has its usual `composer.json`, `.env`, dependencies, and database migrations. The supplied archive did not include those environment/runtime files.
3. Run the migration in staging first, then production:

   ```bash
   php artisan migrate --force
   php artisan route:clear
   php artisan view:clear
   ```

4. Open HR Management → Manage Candidate → View Applicant. The Follow-ups and Interview Schedule tabs appear after Application Answers. Try create, edit, complete, cancel, and reopen a candidate profile to confirm rows persist.

The routes are inside the application's existing `auth:web` and `timezone` middleware group. The list/create/update operations validate candidate ownership of each record and validate user-entered values server-side. Interview meeting links are restricted to HTTP/HTTPS.

## Verification and boundaries

PHP syntax checks passed for the new controller, both models, migration, and modified route file; the new JavaScript block was syntax-checked with Node.js. Full Laravel route boot, database migration execution, and end-to-end browser tests could not be run from the uploaded archive because it does not include `composer.json`, `vendor/`, `.env`, a database snapshot, or the application's test harness.

This is an internal recruiter appointment tracker. It saves the meeting URL/location and contact details, but it does **not** send candidate/interviewer email invitations, WhatsApp messages, calendar invites, or background reminder notifications. Those should only be added after the production mail/notification templates and delivery rules are defined.
