<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApplicantFollowUpModel extends Model
{
    use HasFactory;

    protected $table = 'egc_applicant_followups';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'applicant_id',
        'title',
        'contact_method',
        'follow_up_at',
        'status',
        'notes',
        'outcome',
        'assigned_to',
        'completed_at',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'follow_up_at' => 'datetime',
        'completed_at' => 'datetime',
    ];
}
