<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApplicantInterviewModel extends Model
{
    use HasFactory;

    protected $table = 'egc_applicant_interviews';
    protected $primaryKey = 'sno';

    protected $fillable = [
        'applicant_id',
        'interview_title',
        'interview_round',
        'interview_at',
        'duration_minutes',
        'interview_category',
        'interview_mode',
        'interviewer_name',
        'interviewer_email',
        'meeting_link',
        'location',
        'status',
        'notes',
        'feedback',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'interview_at' => 'datetime',
        'duration_minutes' => 'integer',
    ];
}
