<?php

namespace App\Http\Controllers\hr_management\hr_recruiter;

use App\Http\Controllers\Controller;
use App\Models\ApplicantFollowUpModel;
use App\Models\ApplicantInterviewModel;
use App\Models\ApplicantModel;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

/**
 * Candidate-specific recruiter follow-ups and interview appointments.
 *
 * These records intentionally live separately from the assessment/interview
 * stages used by the existing job-request scheduler. This keeps profile-level
 * HR screening appointments from changing a candidate's online assessment.
 */
class CandidateEngagementController extends Controller
{
    private const FOLLOW_UP_STATUSES = ['scheduled', 'completed', 'missed', 'cancelled'];
    private const CONTACT_METHODS = ['call', 'email', 'whatsapp', 'sms', 'meeting', 'other'];
    private const INTERVIEW_STATUSES = ['scheduled', 'completed', 'rescheduled', 'cancelled', 'no_show'];

    private function actorId(Request $request): int
    {
        $user = $request->user();
        if (!$user) {
            return 0;
        }
        return (int) ($user->user_id ?? $user->getAuthIdentifier() ?? 0);
    }

    private function applicant(int $applicantId): ?ApplicantModel
    {
        return ApplicantModel::query()
            ->where('sno', $applicantId)
            ->where('status', '!=', 2)
            ->first();
    }

    private function applicantNotFound(): JsonResponse
    {
        return response()->json([
            'status' => false,
            'message' => 'Candidate was not found or is no longer active.',
        ], 404);
    }

    private function normalizeDateTime(string $value): string
    {
        return Carbon::parse($value, config('app.timezone', 'Asia/Kolkata'))
            ->format('Y-m-d H:i:s');
    }

    private function serializeFollowUp(ApplicantFollowUpModel $record): array
    {
        $data = $record->toArray();
        $timezone = config('app.timezone', 'Asia/Kolkata');
        $data['follow_up_at'] = $record->follow_up_at
            ? $record->follow_up_at->copy()->timezone($timezone)->format('Y-m-d H:i:s')
            : null;
        $data['completed_at'] = $record->completed_at
            ? $record->completed_at->copy()->timezone($timezone)->format('Y-m-d H:i:s')
            : null;
        return $data;
    }

    private function serializeInterview(ApplicantInterviewModel $record): array
    {
        $data = $record->toArray();
        $timezone = config('app.timezone', 'Asia/Kolkata');
        $data['interview_at'] = $record->interview_at
            ? $record->interview_at->copy()->timezone($timezone)->format('Y-m-d H:i:s')
            : null;
        return $data;
    }

    /** List profile-level follow-ups for one active candidate. */
    public function indexFollowUps(Request $request, int $applicant): JsonResponse
    {
        if (!$this->applicant($applicant)) {
            return $this->applicantNotFound();
        }

        $nowTimestamp = now()->timestamp;
        $items = ApplicantFollowUpModel::query()
            ->where('applicant_id', $applicant)
            ->get()
            ->sort(function (ApplicantFollowUpModel $left, ApplicantFollowUpModel $right) use ($nowTimestamp) {
                $leftTime = $left->follow_up_at ? $left->follow_up_at->timestamp : 0;
                $rightTime = $right->follow_up_at ? $right->follow_up_at->timestamp : 0;
                $leftPriority = $left->status === 'scheduled' && $leftTime >= $nowTimestamp ? 0 : ($left->status === 'scheduled' ? 1 : 2);
                $rightPriority = $right->status === 'scheduled' && $rightTime >= $nowTimestamp ? 0 : ($right->status === 'scheduled' ? 1 : 2);
                if ($leftPriority !== $rightPriority) return $leftPriority <=> $rightPriority;
                return $leftPriority === 0
                    ? ($leftTime <=> $rightTime)
                    : ($rightTime <=> $leftTime);
            })
            ->map(fn (ApplicantFollowUpModel $item) => $this->serializeFollowUp($item))
            ->values();

        return response()->json(['status' => true, 'data' => $items]);
    }

    /** Create a recruiter follow-up. */
    public function storeFollowUp(Request $request, int $applicant): JsonResponse
    {
        if (!$this->applicant($applicant)) {
            return $this->applicantNotFound();
        }

        $data = $request->validate([
            'title' => ['required', 'string', 'max:160'],
            'contact_method' => ['required', Rule::in(self::CONTACT_METHODS)],
            'follow_up_at' => ['required', 'date'],
            'status' => ['nullable', Rule::in(self::FOLLOW_UP_STATUSES)],
            'notes' => ['nullable', 'string', 'max:5000'],
            'outcome' => ['nullable', 'string', 'max:3000'],
        ]);

        $now = now();
        $status = $data['status'] ?? 'scheduled';
        $record = ApplicantFollowUpModel::create([
            'applicant_id' => $applicant,
            'title' => trim($data['title']),
            'contact_method' => $data['contact_method'],
            'follow_up_at' => $this->normalizeDateTime($data['follow_up_at']),
            'status' => $status,
            'notes' => $data['notes'] ?? null,
            'outcome' => $data['outcome'] ?? null,
            'assigned_to' => $this->actorId($request),
            'completed_at' => $status === 'completed' ? $now : null,
            'created_by' => $this->actorId($request),
            'updated_by' => $this->actorId($request),
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Follow-up saved successfully.',
            'data' => $this->serializeFollowUp($record),
        ], 201);
    }

    /** Edit a follow-up or perform a status-only transition. */
    public function updateFollowUp(Request $request, int $applicant, int $followUp): JsonResponse
    {
        if (!$this->applicant($applicant)) {
            return $this->applicantNotFound();
        }

        $record = ApplicantFollowUpModel::query()
            ->where('applicant_id', $applicant)
            ->where('sno', $followUp)
            ->first();

        if (!$record) {
            return response()->json(['status' => false, 'message' => 'Follow-up not found.'], 404);
        }

        $data = $request->validate([
            'title' => ['sometimes', 'required', 'string', 'max:160'],
            'contact_method' => ['sometimes', 'required', Rule::in(self::CONTACT_METHODS)],
            'follow_up_at' => ['sometimes', 'required', 'date'],
            'status' => ['sometimes', 'required', Rule::in(self::FOLLOW_UP_STATUSES)],
            'notes' => ['sometimes', 'nullable', 'string', 'max:5000'],
            'outcome' => ['sometimes', 'nullable', 'string', 'max:3000'],
        ]);

        if (array_key_exists('follow_up_at', $data)) {
            $data['follow_up_at'] = $this->normalizeDateTime($data['follow_up_at']);
        }

        if (array_key_exists('status', $data)) {
            $data['completed_at'] = $data['status'] === 'completed' ? now() : null;
        }

        $data['updated_by'] = $this->actorId($request);
        $record->fill($data)->save();

        return response()->json([
            'status' => true,
            'message' => 'Follow-up updated successfully.',
            'data' => $this->serializeFollowUp($record->fresh()),
        ]);
    }

    /** Cancel a follow-up but retain it for recruitment audit/history. */
    public function cancelFollowUp(Request $request, int $applicant, int $followUp): JsonResponse
    {
        if (!$this->applicant($applicant)) {
            return $this->applicantNotFound();
        }

        $record = ApplicantFollowUpModel::query()
            ->where('applicant_id', $applicant)
            ->where('sno', $followUp)
            ->first();

        if (!$record) {
            return response()->json(['status' => false, 'message' => 'Follow-up not found.'], 404);
        }

        $record->status = 'cancelled';
        $record->updated_by = $this->actorId($request);
        $record->completed_at = null;
        $record->save();

        return response()->json(['status' => true, 'message' => 'Follow-up cancelled.']);
    }

    /** List profile-level interviews plus available labels from existing HR settings. */
    public function indexInterviews(Request $request, int $applicant): JsonResponse
    {
        if (!$this->applicant($applicant)) {
            return $this->applicantNotFound();
        }

        $nowTimestamp = now()->timestamp;
        $items = ApplicantInterviewModel::query()
            ->where('applicant_id', $applicant)
            ->get()
            ->sort(function (ApplicantInterviewModel $left, ApplicantInterviewModel $right) use ($nowTimestamp) {
                $leftTime = $left->interview_at ? $left->interview_at->timestamp : 0;
                $rightTime = $right->interview_at ? $right->interview_at->timestamp : 0;
                $leftActive = in_array($left->status, ['scheduled', 'rescheduled'], true);
                $rightActive = in_array($right->status, ['scheduled', 'rescheduled'], true);
                $leftPriority = $leftActive && $leftTime >= $nowTimestamp ? 0 : ($leftActive ? 1 : 2);
                $rightPriority = $rightActive && $rightTime >= $nowTimestamp ? 0 : ($rightActive ? 1 : 2);
                if ($leftPriority !== $rightPriority) return $leftPriority <=> $rightPriority;
                return $leftPriority === 0
                    ? ($leftTime <=> $rightTime)
                    : ($rightTime <=> $leftTime);
            })
            ->map(fn (ApplicantInterviewModel $item) => $this->serializeInterview($item))
            ->values();

        $categories = [];
        $modes = [];
        try {
            $categories = DB::table('egc_interview_category')
                ->where('status', '!=', 2)
                ->orderBy('sno')
                ->get(['sno as id', 'interview_category_name as name']);
        } catch (\Throwable $e) {
            // The page has built-in fallbacks if interview settings are absent.
        }

        try {
            $modes = DB::table('egc_interview_mode')
                ->where('status', '!=', 2)
                ->orderBy('sno')
                ->get(['sno as id', 'interview_mode_name as name']);
        } catch (\Throwable $e) {
            // The page has built-in fallbacks if interview settings are absent.
        }

        return response()->json([
            'status' => true,
            'data' => $items,
            'options' => [
                'categories' => $categories,
                'modes' => $modes,
            ],
        ]);
    }

    /** Create an interview appointment for a candidate from the profile. */
    public function storeInterview(Request $request, int $applicant): JsonResponse
    {
        if (!$this->applicant($applicant)) {
            return $this->applicantNotFound();
        }

        $data = $request->validate([
            'interview_title' => ['required', 'string', 'max:160'],
            'interview_round' => ['required', 'string', 'max:120'],
            'interview_at' => ['required', 'date'],
            'duration_minutes' => ['required', 'integer', 'min:5', 'max:1440'],
            'interview_category' => ['nullable', 'string', 'max:120'],
            'interview_mode' => ['required', 'string', 'max:80'],
            'interviewer_name' => ['nullable', 'string', 'max:160'],
            'interviewer_email' => ['nullable', 'email', 'max:190'],
            'meeting_link' => ['nullable', 'url', 'max:2048', function ($attribute, $value, $fail) {
                if ($value !== null && $value !== '') {
                    $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
                    if (!in_array($scheme, ['http', 'https'], true)) {
                        $fail('The meeting link must use http or https.');
                    }
                }
            }],
            'location' => ['nullable', 'string', 'max:500'],
            'status' => ['nullable', Rule::in(self::INTERVIEW_STATUSES)],
            'notes' => ['nullable', 'string', 'max:5000'],
            'feedback' => ['nullable', 'string', 'max:5000'],
        ]);

        $actorId = $this->actorId($request);
        $status = $data['status'] ?? 'scheduled';
        $record = ApplicantInterviewModel::create([
            'applicant_id' => $applicant,
            'interview_title' => trim($data['interview_title']),
            'interview_round' => trim($data['interview_round']),
            'interview_at' => $this->normalizeDateTime($data['interview_at']),
            'duration_minutes' => (int) $data['duration_minutes'],
            'interview_category' => $data['interview_category'] ?? null,
            'interview_mode' => trim($data['interview_mode']),
            'interviewer_name' => $data['interviewer_name'] ?? null,
            'interviewer_email' => $data['interviewer_email'] ?? null,
            'meeting_link' => $data['meeting_link'] ?? null,
            'location' => $data['location'] ?? null,
            'status' => $status,
            'notes' => $data['notes'] ?? null,
            'feedback' => $data['feedback'] ?? null,
            'created_by' => $actorId,
            'updated_by' => $actorId,
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Interview scheduled successfully.',
            'data' => $this->serializeInterview($record),
        ], 201);
    }

    /** Edit interview details or apply a status-only transition. */
    public function updateInterview(Request $request, int $applicant, int $interview): JsonResponse
    {
        if (!$this->applicant($applicant)) {
            return $this->applicantNotFound();
        }

        $record = ApplicantInterviewModel::query()
            ->where('applicant_id', $applicant)
            ->where('sno', $interview)
            ->first();

        if (!$record) {
            return response()->json(['status' => false, 'message' => 'Interview appointment not found.'], 404);
        }

        $data = $request->validate([
            'interview_title' => ['sometimes', 'required', 'string', 'max:160'],
            'interview_round' => ['sometimes', 'required', 'string', 'max:120'],
            'interview_at' => ['sometimes', 'required', 'date'],
            'duration_minutes' => ['sometimes', 'required', 'integer', 'min:5', 'max:1440'],
            'interview_category' => ['sometimes', 'nullable', 'string', 'max:120'],
            'interview_mode' => ['sometimes', 'required', 'string', 'max:80'],
            'interviewer_name' => ['sometimes', 'nullable', 'string', 'max:160'],
            'interviewer_email' => ['sometimes', 'nullable', 'email', 'max:190'],
            'meeting_link' => ['sometimes', 'nullable', 'url', 'max:2048', function ($attribute, $value, $fail) {
                if ($value !== null && $value !== '') {
                    $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
                    if (!in_array($scheme, ['http', 'https'], true)) {
                        $fail('The meeting link must use http or https.');
                    }
                }
            }],
            'location' => ['sometimes', 'nullable', 'string', 'max:500'],
            'status' => ['sometimes', 'required', Rule::in(self::INTERVIEW_STATUSES)],
            'notes' => ['sometimes', 'nullable', 'string', 'max:5000'],
            'feedback' => ['sometimes', 'nullable', 'string', 'max:5000'],
        ]);

        if (array_key_exists('interview_at', $data)) {
            $data['interview_at'] = $this->normalizeDateTime($data['interview_at']);
        }

        $data['updated_by'] = $this->actorId($request);
        $record->fill($data)->save();

        return response()->json([
            'status' => true,
            'message' => 'Interview appointment updated successfully.',
            'data' => $this->serializeInterview($record->fresh()),
        ]);
    }

    /** Cancel an interview while preserving the appointment history. */
    public function cancelInterview(Request $request, int $applicant, int $interview): JsonResponse
    {
        if (!$this->applicant($applicant)) {
            return $this->applicantNotFound();
        }

        $record = ApplicantInterviewModel::query()
            ->where('applicant_id', $applicant)
            ->where('sno', $interview)
            ->first();

        if (!$record) {
            return response()->json(['status' => false, 'message' => 'Interview appointment not found.'], 404);
        }

        $record->status = 'cancelled';
        $record->updated_by = $this->actorId($request);
        $record->save();

        return response()->json(['status' => true, 'message' => 'Interview cancelled.']);
    }
}
