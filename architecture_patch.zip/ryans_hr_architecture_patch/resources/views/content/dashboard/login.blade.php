@extends('layouts/blankLayout')

@section('title', 'Login')

@section('page-style')
@vite([
'resources/assets/vendor/scss/pages/page-auth.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
'resources/assets/vendor/libs/@form-validation/auto-focus.js'
])
@endsection

@section('content')
<style>
  :root {
    --srk-primary: #16659E;
    --srk-primary-light: #3E8FC7;
    --srk-secondary: #0F172B;
    --srk-secondary-soft: #16233F;
    --srk-ink: #0B1220;
    --srk-mist: #8FA6BE;
  }

  .srk-auth {
    min-height: 100vh;
    width: 100%;
    background: var(--srk-secondary);
    display: flex;
    flex-direction: row;
    align-items: stretch;
    overflow: hidden;
    font-family: "Public Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }

  /* ---------- LEFT: brand / atmosphere panel (always visible, dark) ---------- */
  .srk-stage {
    position: relative;
    flex: 1.15;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 4rem 4rem 4rem 4.5rem;
    background:
      radial-gradient(circle at 14% 82%, rgba(22, 101, 158, 0.55), transparent 55%),
      radial-gradient(circle at 90% 8%, rgba(62, 143, 199, 0.35), transparent 50%),
      linear-gradient(160deg, var(--srk-secondary) 0%, #0B1425 55%, var(--srk-ink) 100%);
    color: #EAF1F8;
    overflow: hidden;
  }

  /* below 768px: stack dark panel on top instead of hiding it */
  @media (max-width: 768px) {
    .srk-auth { flex-direction: column; }
    .srk-stage { padding: 2.5rem 1.75rem; min-height: 300px; flex: none; }
    .srk-stage-copy h1 { font-size: 1.75rem; }
    .srk-stat-row { gap: 1.5rem; margin-top: 1.5rem; }
    .srk-orbit--1 { width: 420px; height: 420px; }
    .srk-orbit--2 { width: 320px; height: 320px; }
    .srk-orbit--3 { width: 220px; height: 220px; }
  }

  /* concentric circular motif — the signature element */
  .srk-orbit {
    position: absolute;
    border-radius: 50%;
    border: 1px solid rgba(255, 255, 255, 0.08);
    pointer-events: none;
  }
  .srk-orbit--1 { width: 620px;  height: 620px;  right: -220px; bottom: -260px; }
  .srk-orbit--2 { width: 460px;  height: 460px;  right: -140px; bottom: -180px; border-color: rgba(62,143,199,0.18); }
  .srk-orbit--3 { width: 300px;  height: 300px;  right: -60px;  bottom: -100px; border-color: rgba(62,143,199,0.28); }
  .srk-glow {
    position: absolute;
    width: 380px; height: 380px;
    right: -80px; bottom: -140px;
    background: radial-gradient(circle, rgba(22,101,158,0.65) 0%, rgba(22,101,158,0) 70%);
    filter: blur(10px);
    border-radius: 50%;
  }
  .srk-dot {
    position: absolute;
    width: 8px; height: 8px;
    border-radius: 50%;
    background: var(--srk-primary-light);
    box-shadow: 0 0 16px 4px rgba(62,143,199,0.7);
  }

  .srk-brandmark { position: relative; z-index: 2; display: flex; align-items: start; gap: .75rem; }
  .srk-brandmark img { width: 42px; height: 42px; border-radius: 10px; background: #fff; padding: 10px; }
  .srk-brandmark .name { font-weight: 700; letter-spacing: .04em; font-size: 1.02rem; color: #fff; text-transform: uppercase; }
  .srk-brandmark .sub  { font-size: .72rem; color: var(--srk-mist); letter-spacing: .12em; text-transform: uppercase; }

  .srk-stage-copy { position: relative; z-index: 2; max-width: 460px; }
  .srk-eyebrow {
    display: inline-flex; align-items: center; gap: .5rem;
    font-size: .68rem; letter-spacing: .16em; text-transform: uppercase;
    color: var(--srk-primary-light);
    border: 1px solid rgba(62,143,199,0.4);
    background: rgba(22,101,158,0.12);
    padding: .4rem .85rem; border-radius: 999px; margin-bottom: 1.5rem;
  }
  .srk-eyebrow::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: var(--srk-primary-light); }
  .srk-stage-copy h1 { font-size: 2.35rem; font-weight: 800; line-height: 1.15; color: #fff; margin-bottom: .9rem; letter-spacing: -.01em; }
  .srk-stage-copy h1 span { color: var(--srk-primary-light); }
  .srk-stage-copy p { color: var(--srk-mist); font-size: .98rem; line-height: 1.6; }

  .srk-stat-row { position: relative; z-index: 2; display: flex; gap: 2.5rem; margin-top: 2.5rem; }
  .srk-stat b { display: block; font-size: 1.5rem; font-weight: 800; color: #fff; }
  .srk-stat span { font-size: .74rem; color: var(--srk-mist); letter-spacing: .06em; text-transform: uppercase; }

  /* ---------- RIGHT: form panel ---------- */
  .srk-panel {
    flex: 1;
    background: #F7FAFC;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2.5rem 1.75rem;
    position: relative;
  }
  .srk-panel::before {
    content: "";
    position: absolute; inset: 0;
    background: radial-gradient(circle at 85% 12%, rgba(22,101,158,0.06), transparent 45%);
    pointer-events: none;
  }

  .srk-card { width: 100%; max-width: 400px; position: relative; z-index: 1; }

  .srk-ring {
    width: 54px; height: 54px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    background: linear-gradient(135deg, var(--srk-primary), var(--srk-secondary));
    box-shadow: 0 8px 22px -6px rgba(22,101,158,0.55);
    margin-bottom: 1.5rem;
  }
  .srk-ring i { color: #fff; font-size: 1.35rem; }

  .srk-card h2 { font-size: 1.55rem; font-weight: 800; color: var(--srk-secondary); margin-bottom: .35rem; }
  .srk-card .lede { color: #64748B; font-size: .92rem; margin-bottom: 2rem; }
  .srk-btn { cursor: pointer; font: inherit; text-align: center; }

  .srk-field { margin-bottom: 1.15rem; }
  .srk-field label { display: block; font-size: .8rem; font-weight: 600; color: var(--srk-secondary); margin-bottom: .4rem; }
  .srk-field label .req { color: var(--srk-primary); }

  .srk-input-wrap { position: relative; }
  .srk-input-wrap i.field-icon {
    position: absolute; left: 14px; top: 50%; transform: translateY(-50%);
    color: #94A3B8; font-size: 1.05rem;
  }
  .srk-input-wrap .form-control {
    padding-left: 42px;
    height: 48px;
    border-radius: 10px;
    border: 1.5px solid #E2E8F0;
    background: #fff;
    font-size: .92rem;
    transition: border-color .15s ease, box-shadow .15s ease;
  }
  .srk-input-wrap .form-control:focus {
    border-color: var(--srk-primary);
    box-shadow: 0 0 0 4px rgba(22,101,158,0.12);
  }
  .srk-input-wrap .toggle-eye {
    position: absolute; right: 14px; top: 50%; transform: translateY(-50%);
    color: #94A3B8; cursor: pointer;
  }

  .srk-row-between { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }
  .srk-row-between .form-check-input:checked { background-color: var(--srk-primary); border-color: var(--srk-primary); }
  .srk-row-between label { font-size: .85rem; color: #475569; }
  .srk-forgot { font-size: .85rem; font-weight: 600; color: var(--srk-primary); text-decoration: none; }
  .srk-forgot:hover { color: var(--srk-secondary); }

  .srk-btn {
    width: 100%; height: 48px; border: none; border-radius: 10px;
    background: linear-gradient(135deg, var(--srk-primary) 0%, var(--srk-secondary) 130%);
    color: #fff; font-weight: 700; font-size: .95rem; letter-spacing: .02em;
    display: flex; align-items: center; justify-content: center; gap: .55rem;
    text-decoration: none;
    transition: transform .15s ease, box-shadow .15s ease, filter .15s ease;
    box-shadow: 0 10px 24px -8px rgba(22,101,158,0.55);
  }
  .srk-btn:hover { transform: translateY(-1px); filter: brightness(1.06); color: #fff; }
  .srk-btn:active { transform: translateY(0); }

  .srk-footnote { text-align: center; font-size: .78rem; color: #94A3B8; margin-top: 1.75rem; }
</style>

<div class="srk-auth">

  <!-- Left atmosphere panel -->
  <div class="srk-stage">
    <div class="srk-orbit srk-orbit--1"></div>
    <div class="srk-orbit srk-orbit--2"></div>
    <div class="srk-orbit srk-orbit--3"></div>
    <div class="srk-glow"></div>
    <div class="srk-dot" style="top:18%; left:38%;"></div>
    <div class="srk-dot" style="top:62%; left:20%; width:5px; height:5px;"></div>

    <a href="{{url('/')}}" class="srk-brandmark d-flex flex-column">
      <img src="{{asset('assets/img/Ryans-Logo.png')}}" alt="Ryan Infra" class="w-100px h-70px" />
      <div>
        <div class="name">Ryan Infra</div>
        <div class="sub">ERP System Solution</div>
      </div>
    </a>

    <div class="srk-stage-copy">
      <span class="srk-eyebrow">Sovereign Infrastructure Portal</span>
      <h1>Elevating enterprise <span>ERP operations.</span></h1>
      <p>Manage complex operations, coordinate high-priority tasks, and fast-track
        compliance inside a single secure, unified platform built for Ryan Infra.</p>

      <div class="srk-stat-row">
        <div class="srk-stat"><b>24/7</b><span>Live Monitoring</span></div>
        <div class="srk-stat"><b>100%</b><span>Data Encrypted</span></div>
        <div class="srk-stat"><b>ISO</b><span>Compliant</span></div>
      </div>
    </div>
  </div>

  <!-- Right form panel -->
  <div class="srk-panel">
    <div class="srk-card">

      <div class="srk-ring"><i class="mdi mdi-shield-lock-outline"></i></div>

      <h2>Staff Authentication</h2>
      <p class="lede">Sign in with your registered credentials to access the application.</p>

      <form id="loginForm" method="POST" action="{{ url('/login') }}">
        @csrf
      <div class="srk-field">
        <label>Username <span class="req">*</span></label>
        <div class="srk-input-wrap">
          <i class="mdi mdi-account-outline field-icon"></i>
          <input type="text" class="form-control" id="email" name="identifier" value="{{ old('identifier') }}" placeholder="Enter username or email" autocomplete="username" required autofocus />
        </div>
      </div>

      <div class="srk-field">
        <label>Password <span class="req">*</span></label>
        <div class="srk-input-wrap">
          <i class="mdi mdi-lock-outline field-icon"></i>
          <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" autocomplete="current-password" required />
          <i class="mdi mdi-eye-off-outline toggle-eye" id="togglePassword"></i>
        </div>
      </div>

      <div class="srk-row-between">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="remember-me" name="remember" value="1">
          <label class="form-check-label" for="remember-me">Remember me</label>
        </div>
      </div>

      @if ($errors->any())
        <div class="alert alert-danger py-2" role="alert">{{ $errors->first() }}</div>
      @endif
      <button type="submit" class="srk-btn border-0 w-100">
        Sign in <i class="mdi mdi-arrow-right"></i>
      </button>
      </form>

      <p class="srk-footnote">Protected access · Ryan Infra ERP &copy; {{ date('Y') }}</p>
    </div>
  </div>

</div>

<script>
  (function () {
    var toggle = document.getElementById('togglePassword');
    var pwd = document.getElementById('password');
    if (toggle && pwd) {
      toggle.addEventListener('click', function () {
        var isHidden = pwd.type === 'password';
        pwd.type = isHidden ? 'text' : 'password';
        toggle.classList.toggle('mdi-eye-off-outline', !isHidden);
        toggle.classList.toggle('mdi-eye-outline', isHidden);
      });
    }
  })();
</script>
@endsection