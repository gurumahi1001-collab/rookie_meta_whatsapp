# Ryan Infra HR — layered MVC architecture patch

This is an **incremental staging patch** based on the supplied `srk.zip` Laravel source and `ryans_infra (7).sql`. It does not replace the project, its layout files, existing CSS, base database schema, or unrelated feature controllers.

## Architecture

- **Models** (`app/Models/HR`): core staff adapter and isolated profile, attendance, leave, remuneration, and remuneration history records.
- **Services** (`app/Services/HR` and `app/Services/Auth`): database queries, data validation beyond request shape, category mapping, transactions, settings-driven dropdown data, attendance safeguards, leave overlap checks, remuneration history, and login logic.
- **Controllers**: thin JSON controllers for staff CRUD, attendance, leave/entitlements, wages, session login/logout, and mobile API.
- **Routes**: existing page URLs and names are retained. New AJAX endpoints are under `/admin-hr/api/*`; mobile endpoints are under `/api/v1/staff/*`. HR page/AJAX routes added here require `auth:web`; mobile endpoints use Sanctum and token abilities.
- **Blade**: original staff, attendance, leave, entitlement, and wage layouts are retained. New JavaScript supplies data over AJAX. Existing login visual layout is retained while its sign-in control is connected to a session login action.
- **SQL**: `database/ryans_hr_additive_migration.sql` only adds columns/indexes and creates HR-specific tables; it deliberately does not rewrite the legacy shared staff status column.

## Important schema distinction

In the supplied database, `ryans_staff.staff_type` means management/business. `users.staff_type` means permanent/contract. They are not interchangeable. The migration adds `ryans_staff.employment_type` (1 permanent, 2 contract) and backfills it only where the linked `users` records agree. Staff with no verified category are shown in **Classify Legacy Staff** on both staff pages. Assign their category from authoritative HR records; do not infer it from `ryans_staff.staff_type`.

The migration adds `ryans_staff.hr_status` for HR-only status values:

- `0` active
- `-1` inactive
- `-3` exited
- `2` deleted (excluded from staff lists)

`ryans_staff.status` is intentionally unchanged because the old application uses it for its own status domain, including notice period/relieved/abscond/terminate.

## Installation

1. Back up the database and files. Use a staging copy first.
2. Select the intended `ryans_infra` database in phpMyAdmin or your database client. Review the SQL and its final diagnostic `SELECT` results before enabling the screens. The patch is written for MariaDB/MySQL and conditionally adds missing columns and indexes.
3. Copy the included files to the same relative paths in the application. Merge `routes/web.php` and `routes/api.php` additions with any routes added after this package was made; do not blindly replace newer production route files.
4. Confirm `config/auth.php` uses the Laravel `web` session guard with the existing `App\\Models\\User` model, and that the production login records store Laravel-compatible password hashes. The uploaded source's login control was only a link, so the included login patch makes the existing form submit to the new session endpoint.
5. Confirm `users.username` has no duplicate values before requiring username login. The SQL only creates a unique username index when there are no duplicate non-empty usernames; if it skips the index, clean duplicates and add the index after review.
6. Run `php artisan route:clear` and `php artisan view:clear`; then use `php artisan route:list` to confirm the added endpoints and middleware. Deploy only with a full application containing its normal `composer.json`, lock file, dependencies, `.env`, and storage configuration. Those runtime files are not part of this incremental patch.
7. Test in staging using accounts for permanent staff, contract staff, and an authenticated admin. Confirm that a user without an authenticated web session receives 401/redirect rather than staff JSON data. Confirm all existing non-HR modules remain unchanged.

## Web AJAX endpoints

- `GET /admin-hr/api/staff/options`
- `GET /admin-hr/api/staff/unclassified`
- `PATCH /admin-hr/api/staff/{id}/employment-type`
- `GET|POST /admin-hr/api/staff/{permanent|contract}`
- `GET|PATCH|DELETE /admin-hr/api/staff/{id}` and `PATCH /admin-hr/api/staff/{id}/status`
- `GET /admin-hr/api/attendance/{type}` (search/sort/page) and `GET /admin-hr/api/attendance/{type}/matrix`
- `POST /admin-hr/api/attendance/{type}`
- `GET|POST /admin-hr/api/leave/{type}`
- `GET /admin-hr/api/leave/{type}/entitlements`
- `POST /admin-hr/api/leave/{type}/entitlements`, `/bulk`, and `/batch-credit`
- `PATCH /admin-hr/api/leave/{type}/{id}/review`
- `GET /admin-hr/api/wages/{type}`, `GET /admin-hr/api/wages/{type}/{id}`, `PUT /admin-hr/api/wages/{type}/{id}`

`type` is `permanent` or `contract`. The list endpoints validate sort keys and page sizes; SQL values are parameter-bound, and user-controlled sort columns use allowlists.

## Mobile API

- `POST /api/v1/staff/login` — identifier/email + password, returns a Sanctum bearer token.
- `GET /api/v1/staff/profile` — authenticated staff profile (self only).
- `POST /api/v1/staff/leave-requests` — creates a leave request for the authenticated staff member.
- `POST /api/v1/staff/check-in` and `POST /api/v1/staff/check-out` — transactional same-day actions, reject duplicate operations, and require active employment.
- `GET /api/v1/staff/attendance-history?month=YYYY-MM` — paginated monthly history.

The API is implemented against the existing `users` and attendance tables; the additive SQL must be applied before using the username login, extended profile, remuneration, and leave endpoints.

## Data and safety behavior

- Settings values for relationship, blood group, department, designation, job role, user role, language, and remuneration type are loaded from the existing settings tables where `status = 0`.
- Staff list search, ordering, filtering, and pagination execute on the server.
- Existing status records are not migrated into new negative status values. `hr_status` controls the new HR list display; null values use an explicit mapping of legacy states.
- Leave entitlements retain separate yearly values; leave usage counts only the days that overlap the selected year. Leave requests that overlap another pending/approved request are rejected.
- Wage component updates are saved transactionally with previous/current JSON history. The amount calculation policy (tax, PF/ESI, rounding, statutory exclusions, and payroll rules) is not invented by this patch; verify it against the existing payroll policy before using the component total for payroll.
- Local profile uploads use the Laravel `local` disk, not a public or cloud disk. Configure web-server permissions and a secure authenticated download route before exposing private attachments.

## Verification status — read before deployment

- PHP syntax checks passed for the included PHP and Blade files.
- Node syntax checks passed for the added inline JavaScript blocks that do not contain Blade interpolations.
- This environment did **not** have the live application `.env`, `vendor/` dependencies, a running MariaDB instance, or the project's browser/feature-test harness. Therefore the SQL has not been executed here, and route boot, schema integration, auth/session flow, UI interaction, and end-to-end API tests have **not** been completed. Do not treat syntax checks as proof of production readiness.
- Role permission JSON is not yet enforced per action by a dedicated authorization middleware in this patch; current web HR routes require an authenticated web session. Before production, wire route/action checks to the existing `ryans_user_role_permission` permissions and verify branch-scoped access according to your actual branch context. Do not grant broad HR access solely because a user can sign in.
- Table/calendar pages have been connected to the matrix API, but must be visually/regression-tested with your real data, including staff counts above the per-page limit, legacy duplicate attendance rows, holidays/rest-day policies, and the exact modal interactions used by HR.

## Minimum staging acceptance checklist

1. Apply SQL to a database copy and inspect the unclassified-staff and duplicate-attendance diagnostics.
2. Sign in/out through the existing screen; test wrong password, throttling, session expiry, and direct AJAX requests without a session.
3. Verify settings dropdowns and create one permanent + one contract staff member with/without login access.
4. View/edit profile and confirm family, education, experience, languages, and remuneration survive a reload.
5. Test status values `0`, `-1`, `-3`, and `2`; ensure deleted staff are not listed and the original `status` values are unchanged.
6. Test attendance list/matrix/calendar for search, month navigation, pagination, in/out times, leaves, and duplicate check-in/out.
7. Test leave request overlap validation, approvals/rejections, year-boundary balances, bulk entitlement adjustments, and batch credit.
8. Test wages component editing/history and ensure payroll does not consume the component sum until the actual pay policy has been validated.
9. Test mobile login/profile/leave/check-in/check-out/history with valid and invalid bearer tokens.
10. Run feature tests and a full smoke test of non-HR modules before production deployment.
