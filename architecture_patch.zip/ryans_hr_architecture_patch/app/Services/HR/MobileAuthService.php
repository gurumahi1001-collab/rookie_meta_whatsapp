<?php

namespace App\Services\HR;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class MobileAuthService
{
    public function login(string $identifier, string $password): array
    {
        $identifier = strtolower(trim($identifier));
        $matches = User::query()->where(function ($query) use ($identifier) {
            $query->whereRaw('LOWER(email) = ?', [$identifier])
                ->orWhereRaw('LOWER(username) = ?', [$identifier]);
        })->limit(2)->get();
        $user = $matches->count() === 1 ? $matches->first() : null;
        if (!$user || !Hash::check($password, (string) $user->password)) {
            throw ValidationException::withMessages(['credentials' => 'Invalid email/username or password.']);
        }
        $staffType = (int) ($user->staff_type ?? 0);
        if (!in_array($staffType, [1, 2], true) || (int) $user->user_id < 1) {
            throw ValidationException::withMessages(['credentials' => 'This account is not linked to a permanent or contract staff profile.']);
        }
        $staff = \Illuminate\Support\Facades\DB::table('ryans_staff')->where('sno', $user->user_id)->first();
        if (!$staff || (int) ($staff->employment_type ?? $staffType) !== $staffType) {
            throw ValidationException::withMessages(['credentials' => 'The staff account requires HR employment-type verification.']);
        }
        $hrStatus = $staff->hr_status ?? match ((int) $staff->status) { 0 => 0, 1,4 => -1, 2 => 2, 5,6,7 => -3, default => -3 };
        if ((int) $hrStatus !== 0) throw ValidationException::withMessages(['credentials' => 'This staff account is not active.']);

        $user->forceFill(['last_activity' => now()->toIso8601String()])->save();
        $token = $user->createToken('ryans-infra-mobile', ['staff:profile', 'staff:attendance', 'staff:leave'])->plainTextToken;
        return [
            'token_type' => 'Bearer', 'access_token' => $token,
            'user' => ['id' => (int) $user->id, 'staff_id' => (int) $user->user_id, 'staff_type' => $staffType, 'name' => $user->name, 'email' => $user->email],
        ];
    }

    public function staffForUser(User $user): array
    {
        $staffId = (int) $user->user_id;
        $employment = (int) $user->staff_type;
        if ($staffId < 1 || !in_array($employment, [1, 2], true)) throw ValidationException::withMessages(['staff' => 'Staff mapping is invalid.']);
        $staff = \Illuminate\Support\Facades\DB::table('ryans_staff')->where('sno', $staffId)->first();
        if (!$staff || (int) ($staff->employment_type ?? $employment) !== $employment) throw ValidationException::withMessages(['staff' => 'Staff mapping is not verified.']);
        $status = $staff->hr_status ?? match ((int) $staff->status) { 0 => 0, 1,4 => -1, 2 => 2, 5,6,7 => -3, default => -3 };
        if ((int) $status !== 0) throw ValidationException::withMessages(['staff' => 'Staff account is not active.']);
        return ['staff_id' => $staffId, 'employment_type' => $employment, 'staff' => $staff];
    }
}
