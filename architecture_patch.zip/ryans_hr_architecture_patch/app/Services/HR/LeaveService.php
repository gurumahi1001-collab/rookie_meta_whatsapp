<?php

namespace App\Services\HR;

use App\Models\HR\LeaveEntitlementModel;
use App\Models\HR\LeaveRequestModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use Illuminate\Validation\ValidationException;

class LeaveService
{
    public function __construct(private StaffService $staffService) {}

    public function paginate(string $type, array $filters)
    {
        $query = LeaveRequestModel::query()->from('ryans_leave_requests as l')
            ->join('ryans_staff as s', 's.sno', '=', 'l.staff_id')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id');
        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        $query->where('l.status', 0);
        if (($filters['search'] ?? '') !== '') {
            $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim((string) $filters['search'])) . '%';
            $query->where(fn ($q) => $q->where('s.staff_name', 'like', $like)->orWhere('s.staff_id', 'like', $like)->orWhere('l.leave_type', 'like', $like));
        }
        if (!empty($filters['leave_status'])) $query->where('l.approval_status', $filters['leave_status']);
        $query->orderByDesc('l.created_at')->orderByDesc('l.id');
        return $query->select(['l.*', 's.staff_name', 's.staff_id as staff_code', 'd.department_name'])->paginate((int) ($filters['per_page'] ?? 10))->withQueryString();
    }

    /** Paginated per-staff balances, with entitlement and approved usage kept separate. */
    public function entitlements(string $type, array $filters)
    {
        $year = (int) ($filters['year'] ?? now()->year);
        $query = DB::table('ryans_staff as s')
            ->leftJoin('ryans_department as d', 'd.sno', '=', 's.department_id')
            ->leftJoin('rayans_designation as dg', 'dg.sno', '=', 's.designation_id');
        $this->staffService->applyCategoryScope($query, 's', $type);
        $this->staffService->applyNotDeletedScope($query, 's');
        if (($filters['search'] ?? '') !== '') {
            $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], trim((string) $filters['search'])) . '%';
            $query->where(fn ($q) => $q->where('s.staff_name', 'like', $like)
                ->orWhere('s.staff_id', 'like', $like)->orWhere('d.department_name', 'like', $like)
                ->orWhere('dg.designation', 'like', $like));
        }
        $page = $query->orderBy('s.staff_name')->select([
            's.sno as staff_pk', 's.staff_id as staff_code', 's.staff_name',
            's.department_id', 'd.department_name', 's.designation_id', 'dg.designation',
        ])->paginate((int) ($filters['per_page'] ?? 10))->withQueryString();

        $staffIds = $page->getCollection()->pluck('staff_pk')->map(fn ($id) => (int) $id)->all();
        $entitlements = $staffIds ? DB::table('ryans_leave_entitlements')->whereIn('staff_id', $staffIds)
            ->where('year', $year)->where('status', 0)->get() : collect();
        $approved = $staffIds ? DB::table('ryans_leave_requests')->whereIn('staff_id', $staffIds)
            ->where('status', 0)->where('approval_status', 'Approved')
            ->whereDate('from_date', '<=', $year . '-12-31')->whereDate('to_date', '>=', $year . '-01-01')->get() : collect();
        $byStaff = $entitlements->groupBy('staff_id');
        $usedByStaff = $approved->groupBy('staff_id');
        $balances = static function ($rows, $usedRows) use ($year): array {
            $aliases = ['casual' => 'Casual', 'cl' => 'Casual', 'casual leave' => 'Casual', 'privilege' => 'Privilege', 'privilege leave' => 'Privilege', 'privilege carry forward' => 'Privilege', 'prior-year pl carry forward' => 'Privilege', 'pl' => 'Privilege', 'sick' => 'Sick', 'sick leave' => 'Sick', 'sl' => 'Sick'];
            $out = ['Casual' => ['entitled' => 0.0, 'availed' => 0.0, 'balance' => 0.0], 'Privilege' => ['entitled' => 0.0, 'availed' => 0.0, 'balance' => 0.0], 'Sick' => ['entitled' => 0.0, 'availed' => 0.0, 'balance' => 0.0]];
            foreach ($rows as $row) {
                $key = strtolower(trim((string) $row->leave_type)); $name = $aliases[$key] ?? null;
                if ($name !== null) $out[$name]['entitled'] += (float) $row->annual_days;
            }
            foreach ($usedRows as $row) {
                $key = strtolower(trim((string) $row->leave_type)); $name = $aliases[$key] ?? null;
                if ($name !== null) {
                    $from = Carbon::parse($row->from_date)->startOfDay();
                    $to = Carbon::parse($row->to_date)->startOfDay();
                    $yearStart = Carbon::create($year, 1, 1)->startOfDay();
                    $yearEnd = Carbon::create($year, 12, 31)->startOfDay();
                    $overlapStart = $from->greaterThan($yearStart) ? $from : $yearStart;
                    $overlapEnd = $to->lessThan($yearEnd) ? $to : $yearEnd;
                    if ($overlapEnd->greaterThanOrEqualTo($overlapStart)) {
                        $out[$name]['availed'] += (float) ($overlapStart->diffInDays($overlapEnd) + 1);
                    }
                }
            }
            foreach ($out as &$v) $v['balance'] = max(0, $v['entitled'] - $v['availed']);
            unset($v);
            return $out;
        };
        $page->getCollection()->transform(function ($staff) use ($byStaff, $usedByStaff, $balances) {
            $map = $balances($byStaff->get($staff->staff_pk, collect()), $usedByStaff->get($staff->staff_pk, collect()));
            $staff->leave_balances = $map;
            $staff->leave_entitlement_values = [];
            foreach ($byStaff->get($staff->staff_pk, collect()) as $entitlement) {
                $staff->leave_entitlement_values[trim((string) $entitlement->leave_type)] = (float) $entitlement->annual_days;
            }
            $staff->total_entitled = array_sum(array_column($map, 'entitled'));
            $staff->total_availed = array_sum(array_column($map, 'availed'));
            $staff->total_balance = array_sum(array_column($map, 'balance'));
            $staff->balance_health = $staff->total_entitled > 0 ? round(($staff->total_balance / $staff->total_entitled) * 100) : 0;
            return $staff;
        });
        return $page;
    }

    public function createRequest(int $staffId, array $data, ?string $type = null): LeaveRequestModel
    {
        if ($type !== null) {
            $employment = $this->staffService->employmentValue($type);
            $belongs = DB::table('ryans_staff as s')->where('s.sno', $staffId)->where(function ($q) use ($employment) {
                $q->where('s.employment_type', $employment)->orWhere(function ($inner) use ($employment) {
                    $inner->whereNull('s.employment_type')->whereExists(function ($users) use ($employment) {
                        $users->selectRaw('1')->from('users')->whereColumn('users.user_id', 's.sno')->where('users.staff_type', $employment);
                    });
                });
            })->exists();
            if (!$belongs) throw ValidationException::withMessages(['staff_id' => 'Staff does not belong to this category.']);
        }
        $from = Carbon::parse($data['from_date'])->startOfDay();
        $to = Carbon::parse($data['to_date'])->startOfDay();
        if ($to->lt($from)) throw ValidationException::withMessages(['to_date' => 'The end date must be on or after the start date.']);
        $days = $from->diffInDays($to) + 1; // Calendar days: connect a working-day policy if your HR rules require it.
        return DB::transaction(function () use ($staffId, $data, $from, $to, $days) {
            $overlap = LeaveRequestModel::query()->where('staff_id', $staffId)->where('status', 0)
                ->whereIn('approval_status', ['Pending', 'Approved'])
                ->whereDate('from_date', '<=', $to->toDateString())->whereDate('to_date', '>=', $from->toDateString())->lockForUpdate()->exists();
            if ($overlap) throw ValidationException::withMessages(['from_date' => 'This leave overlaps an existing pending or approved request.']);
            return LeaveRequestModel::query()->create([
                'staff_id' => $staffId, 'leave_type' => trim($data['leave_type']),
                'from_date' => $from->toDateString(), 'to_date' => $to->toDateString(), 'days' => $days,
                'reason' => trim($data['reason']), 'approval_status' => 'Pending', 'status' => 0,
            ]);
        }, 3);
    }

    public function review(int $id, string $status, ?string $note, int $actor, ?string $type = null): void
    {
        DB::transaction(function () use ($id, $status, $note, $actor, $type) {
            $leave = LeaveRequestModel::query()->where('id', $id)->where('status', 0)->lockForUpdate()->first();
            if (!$leave) abort(404, 'Leave request not found.');
            if ($type !== null) {
                $scope = DB::table('ryans_staff as s')->where('s.sno', $leave->staff_id);
                $this->staffService->applyCategoryScope($scope, 's', $type);
                $this->staffService->applyNotDeletedScope($scope, 's');
                if (!$scope->exists()) abort(404, 'Leave request not found in this staff category.');
            }
            if ($leave->approval_status !== 'Pending') throw ValidationException::withMessages(['approval_status' => 'Only pending requests can be reviewed.']);
            $leave->approval_status = $status; $leave->review_note = $note;
            $leave->reviewed_by = $actor; $leave->reviewed_at = now(); $leave->save();
        }, 3);
    }

    public function saveEntitlementsBulk(string $type, int $staffId, int $year, array $entitlements, int $actor): void
    {
        DB::transaction(function () use ($type, $staffId, $year, $entitlements, $actor) {
            foreach ($entitlements as $item) {
                $this->saveEntitlement($type, [
                    'staff_id' => $staffId, 'year' => $year,
                    'leave_type' => $item['leave_type'], 'annual_days' => $item['annual_days'],
                ], $actor);
            }
        }, 3);
    }

    public function creditEntitlementForCategory(string $type, string $leaveType, int $year, float $days, int $actor): int
    {
        $employment = $this->staffService->employmentValue($type);
        $query = DB::table('ryans_staff as s')->where(function ($q) use ($employment) {
            $q->where('s.employment_type', $employment)->orWhere(function ($inner) use ($employment) {
                $inner->whereNull('s.employment_type')->whereExists(function ($users) use ($employment) {
                    $users->selectRaw('1')->from('users')->whereColumn('users.user_id', 's.sno')->where('users.staff_type', $employment);
                });
            });
        });
        $this->staffService->applyNotDeletedScope($query, 's');
        $count = 0;
        DB::transaction(function () use ($query, $leaveType, $year, $days, $actor, $type, &$count) {
            $query->select('s.sno')->orderBy('s.sno')->chunkById(200, function ($rows) use ($leaveType, $year, $days, $actor, $type, &$count) {
                foreach ($rows as $row) {
                    $this->saveEntitlement($type, [
                        'staff_id' => (int) $row->sno, 'year' => $year,
                        'leave_type' => $leaveType, 'annual_days' => $days,
                    ], $actor);
                    $count++;
                }
            }, 's.sno', 'sno');
        }, 3);
        return $count;
    }

    public function saveEntitlement(string $type, array $data, int $actor): void
    {
        $employment = $this->staffService->employmentValue($type);
        $staff = DB::table('ryans_staff as s')->where('s.sno', (int) $data['staff_id'])
            ->where(function ($q) use ($employment) {
                $q->where('s.employment_type', $employment)->orWhere(function ($inner) use ($employment) {
                    $inner->whereNull('s.employment_type')->whereExists(function ($users) use ($employment) {
                        $users->selectRaw('1')->from('users')->whereColumn('users.user_id', 's.sno')->where('users.staff_type', $employment);
                    });
                });
            })->exists();
        if (!$staff) throw ValidationException::withMessages(['staff_id' => 'Staff does not belong to this category.']);
        $now = now();
        $entitlement = LeaveEntitlementModel::query()->firstOrNew([
            'staff_id' => (int) $data['staff_id'],
            'leave_type' => trim($data['leave_type']),
            'year' => (int) $data['year'],
        ]);
        $isNew = !$entitlement->exists;
        $entitlement->annual_days = (float) $data['annual_days'];
        $entitlement->updated_by = $actor;
        $entitlement->updated_at = $now;
        $entitlement->status = 0;
        if ($isNew) {
            $entitlement->created_by = $actor;
            $entitlement->created_at = $now;
        }
        $entitlement->save();
    }
}
