<?php

namespace App\Services\Auth;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\ValidationException;

/** Session authentication for the existing login screen; no credential data is logged. */
class WebLoginService
{
    public function login(string $identifier, string $password, bool $remember = false): void
    {
        $identifier = trim($identifier);
        $normalised = mb_strtolower($identifier);
        $query = User::query()->where(function ($query) use ($normalised) {
            $query->whereRaw('LOWER(email) = ?', [$normalised]);
            if (Schema::hasColumn('users', 'username')) {
                $query->orWhereRaw('LOWER(username) = ?', [$normalised]);
            }
        });
        $matches = $query->limit(2)->get();
        if ($matches->count() !== 1 || !Hash::check($password, (string) $matches->first()->password)) {
            throw ValidationException::withMessages([
                'identifier' => 'The supplied credentials are invalid or ambiguous. Check the account details.',
            ]);
        }
        $user = $matches->first();

        Auth::guard('web')->login($user, $remember);
        request()->session()->regenerate();
        $user->forceFill(['last_activity' => now()->toIso8601String()])->save();
    }

    public function logout(): void
    {
        Auth::guard('web')->logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();
    }
}
