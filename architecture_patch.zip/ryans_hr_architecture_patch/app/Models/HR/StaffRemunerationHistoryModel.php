<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class StaffRemunerationHistoryModel extends Model
{
    protected $table = 'ryans_staff_remuneration_history';
    protected $primaryKey = 'id';
    protected $guarded = ['id'];
    public $timestamps = true;
    protected $casts = ['previous_json' => 'array', 'current_json' => 'array'];
}
