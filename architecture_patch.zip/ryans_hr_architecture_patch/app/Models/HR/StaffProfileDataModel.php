<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class StaffProfileDataModel extends Model
{
    protected $table = 'ryans_staff_profile_data';
    protected $primaryKey = 'id';
    protected $guarded = ['id'];
    public $timestamps = true;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $casts = ['profile_json' => 'array'];
}
