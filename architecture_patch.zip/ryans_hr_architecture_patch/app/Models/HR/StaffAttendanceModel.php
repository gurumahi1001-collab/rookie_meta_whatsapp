<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class StaffAttendanceModel extends Model
{
    protected $table = 'ryans_staff_attendance';
    protected $primaryKey = 'sno';
    protected $guarded = ['sno'];
    public $timestamps = true;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    protected $casts = ['date' => 'date:Y-m-d'];
}
