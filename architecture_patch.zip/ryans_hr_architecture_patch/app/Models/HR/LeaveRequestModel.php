<?php

namespace App\Models\HR;

use Illuminate\Database\Eloquent\Model;

class LeaveRequestModel extends Model
{
    protected $table = 'ryans_leave_requests';
    protected $primaryKey = 'id';
    protected $guarded = ['id'];
    public $timestamps = true;
    protected $casts = ['from_date' => 'date:Y-m-d', 'to_date' => 'date:Y-m-d', 'days' => 'decimal:2', 'reviewed_at' => 'datetime'];
}
