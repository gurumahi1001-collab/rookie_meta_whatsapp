-- Ryan Infra HR additive migration, reviewed against ryans_infra (7).sql.
-- Back up and test in staging first. Never execute against production without reviewing diagnostics.
-- The legacy ryans_staff.status column is deliberately NOT rewritten.
-- HR-only status: NULL = legacy mapping; 0 Active, -1 Inactive, -3 Exit, 2 Deleted.
-- Employment: 1 Permanent, 2 Contract. NULL means legacy staff category not yet verified.

SET @hr_db = DATABASE();

-- Existing users table has email but no username. Add an optional unique username so the
-- existing Add Staff UI and mobile login can use the same identity model. NULL is allowed
-- for all pre-existing users; no legacy username data is overwritten.
SET @hr_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@hr_db AND TABLE_NAME='users' AND COLUMN_NAME='username')=0,
  'ALTER TABLE `users` ADD COLUMN `username` VARCHAR(100) NULL AFTER `email`', 'SELECT 1');
PREPARE hr_stmt FROM @hr_ddl; EXECUTE hr_stmt; DEALLOCATE PREPARE hr_stmt;

SET @hr_username_duplicates = 0;
SET @hr_username_duplicates = IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@hr_db AND TABLE_NAME='users' AND COLUMN_NAME='username') > 0,
  (SELECT COUNT(*) FROM (SELECT `username` FROM `users` WHERE `username` IS NOT NULL AND `username` <> '' GROUP BY `username` HAVING COUNT(*) > 1) AS hr_dup_names),
  0
);
SET @hr_ddl = IF(
  (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@hr_db AND TABLE_NAME='users' AND INDEX_NAME='uq_users_username')=0 AND @hr_username_duplicates=0,
  'ALTER TABLE `users` ADD UNIQUE KEY `uq_users_username` (`username`)',
  'SELECT ''Username uniqueness index skipped: inspect duplicate username values or existing index.'' AS `hr_migration_note`'
);
PREPARE hr_stmt FROM @hr_ddl; EXECUTE hr_stmt; DEALLOCATE PREPARE hr_stmt;

-- Add only missing columns. These checks make the column additions safe to re-run on MariaDB/MySQL.
SET @hr_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@hr_db AND TABLE_NAME='ryans_staff' AND COLUMN_NAME='employment_type')=0,
  'ALTER TABLE `ryans_staff` ADD COLUMN `employment_type` TINYINT NULL COMMENT ''1 Permanent, 2 Contract; NULL requires verified mapping'' AFTER `staff_type`', 'SELECT 1');
PREPARE hr_stmt FROM @hr_ddl; EXECUTE hr_stmt; DEALLOCATE PREPARE hr_stmt;

SET @hr_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@hr_db AND TABLE_NAME='ryans_staff' AND COLUMN_NAME='hr_status')=0,
  'ALTER TABLE `ryans_staff` ADD COLUMN `hr_status` SMALLINT NULL COMMENT ''HR status: 0 Active, -1 Inactive, -3 Exit, 2 Deleted; NULL = legacy'' AFTER `status`', 'SELECT 1');
PREPARE hr_stmt FROM @hr_ddl; EXECUTE hr_stmt; DEALLOCATE PREPARE hr_stmt;

SET @hr_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@hr_db AND TABLE_NAME='ryans_staff' AND COLUMN_NAME='designation_id')=0,
  'ALTER TABLE `ryans_staff` ADD COLUMN `designation_id` INT NULL AFTER `job_role_id`', 'SELECT 1');
PREPARE hr_stmt FROM @hr_ddl; EXECUTE hr_stmt; DEALLOCATE PREPARE hr_stmt;

-- The existing education table has no grade/percentage field even though the UI has one.
SET @hr_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@hr_db AND TABLE_NAME='ryans_staff_education_info' AND COLUMN_NAME='grade')=0,
  'ALTER TABLE `ryans_staff_education_info` ADD COLUMN `grade` VARCHAR(80) NULL AFTER `year`', 'SELECT 1');
PREPARE hr_stmt FROM @hr_ddl; EXECUTE hr_stmt; DEALLOCATE PREPARE hr_stmt;

-- Existing work-history UI captures responsibilities. Preserve exit_reason semantics by adding a dedicated field.
SET @hr_ddl = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@hr_db AND TABLE_NAME='ryans_staff_work_info' AND COLUMN_NAME='responsibilities')=0,
  'ALTER TABLE `ryans_staff_work_info` ADD COLUMN `responsibilities` TEXT NULL AFTER `exit_reason`', 'SELECT 1');
PREPARE hr_stmt FROM @hr_ddl; EXECUTE hr_stmt; DEALLOCATE PREPARE hr_stmt;

-- Indexes are additive and conditional. Avoid creating duplicate index names on re-run.
SET @hr_ddl = IF((SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@hr_db AND TABLE_NAME='ryans_staff' AND INDEX_NAME='idx_hr_staff_employment_status')=0,
  'ALTER TABLE `ryans_staff` ADD INDEX `idx_hr_staff_employment_status` (`employment_type`,`hr_status`,`status`)', 'SELECT 1');
PREPARE hr_stmt FROM @hr_ddl; EXECUTE hr_stmt; DEALLOCATE PREPARE hr_stmt;

-- Only backfill an employment category from an explicitly linked users row.
-- Do NOT infer it from ryans_staff.staff_type: its current comment is management/business.
UPDATE `ryans_staff` AS s
INNER JOIN (
  SELECT `user_id`, MIN(`staff_type`) AS `staff_type`
  FROM `users` WHERE `staff_type` IN (1,2)
  GROUP BY `user_id` HAVING COUNT(DISTINCT `staff_type`) = 1
) AS u ON u.`user_id` = s.`sno`
SET s.`employment_type` = u.`staff_type`
WHERE s.`employment_type` IS NULL;

CREATE TABLE IF NOT EXISTS `ryans_staff_profile_data` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `staff_id` INT NOT NULL,
  `blood_group_id` BIGINT NULL,
  `relation_id` INT NULL,
  `profile_json` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`profile_json` IS NULL OR JSON_VALID(`profile_json`)),
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hr_profile_staff` (`staff_id`),
  KEY `idx_hr_profile_blood_group` (`blood_group_id`),
  KEY `idx_hr_profile_relation` (`relation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ryans_staff_remuneration` (
  `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `staff_id` INT NOT NULL,
  `remuneration_type_id` INT NOT NULL,
  `amount` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `created_by` BIGINT UNSIGNED NULL,
  `updated_by` BIGINT UNSIGNED NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  `status` INT NOT NULL DEFAULT 0 COMMENT '0 active, 2 historical/deleted',
  PRIMARY KEY (`sno`),
  KEY `idx_hr_remuneration_staff_status` (`staff_id`,`status`),
  KEY `idx_hr_remuneration_type` (`remuneration_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ryans_staff_remuneration_history` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `staff_id` INT NOT NULL,
  `previous_json` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`previous_json` IS NULL OR JSON_VALID(`previous_json`)),
  `current_json` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`current_json` IS NULL OR JSON_VALID(`current_json`)),
  `created_by` BIGINT UNSIGNED NULL,
  `updated_by` BIGINT UNSIGNED NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hr_wage_history_staff_created` (`staff_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ryans_leave_requests` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `staff_id` INT NOT NULL,
  `leave_type` VARCHAR(80) NOT NULL,
  `from_date` DATE NOT NULL,
  `to_date` DATE NOT NULL,
  `days` DECIMAL(6,2) NOT NULL DEFAULT 1.00,
  `reason` TEXT NOT NULL,
  `approval_status` ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `review_note` TEXT NULL,
  `reviewed_by` BIGINT UNSIGNED NULL,
  `reviewed_at` DATETIME NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  `status` INT NOT NULL DEFAULT 0 COMMENT '0 active, 2 deleted',
  PRIMARY KEY (`id`),
  KEY `idx_hr_leave_staff_dates` (`staff_id`,`from_date`,`to_date`),
  KEY `idx_hr_leave_status_dates` (`approval_status`,`status`,`from_date`,`to_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ryans_leave_entitlements` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `staff_id` INT NOT NULL,
  `leave_type` VARCHAR(80) NOT NULL,
  `annual_days` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `year` SMALLINT NOT NULL,
  `created_by` BIGINT UNSIGNED NULL,
  `updated_by` BIGINT UNSIGNED NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  `status` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hr_leave_entitlement_staff_type_year` (`staff_id`,`leave_type`,`year`),
  KEY `idx_hr_leave_entitlement_year` (`year`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Audit before enabling the HR screens. Staff without either a saved employment_type or a verified
-- users.staff_type mapping appear here and must be classified from HR records, not guessed.
SELECT s.`sno`, s.`staff_id`, s.`staff_name`, s.`staff_type` AS `legacy_management_business_type`, s.`status`, s.`employment_type`
FROM `ryans_staff` s
LEFT JOIN `users` u ON u.`user_id` = s.`sno`
WHERE s.`employment_type` IS NULL AND (u.`staff_type` IS NULL OR u.`staff_type` NOT IN (1,2)) AND s.`status` <> 2
ORDER BY s.`staff_name`;

-- Review before adding any unique daily attendance constraint. This patch deliberately does not add one
-- because the legacy application’s duplicate/day policy was not established from the source archive.
SELECT `staff_id`, `date`, COUNT(*) AS `active_rows`
FROM `ryans_staff_attendance` WHERE `status`=0
GROUP BY `staff_id`, `date` HAVING COUNT(*) > 1;
