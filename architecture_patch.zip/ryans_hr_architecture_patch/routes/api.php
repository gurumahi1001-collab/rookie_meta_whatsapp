<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\api\StaffMobileController;

// Existing endpoint retained.
Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('v1/staff')->name('api.staff.')->group(function () {
    Route::post('/login', [StaffMobileController::class, 'login'])->middleware('throttle:5,1')->name('login');
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/profile', [StaffMobileController::class, 'profile'])->middleware('abilities:staff:profile')->name('profile');
        Route::post('/leave-requests', [StaffMobileController::class, 'leaveRequest'])->middleware('abilities:staff:leave')->name('leave.request');
        Route::post('/check-in', [StaffMobileController::class, 'checkIn'])->middleware('abilities:staff:attendance')->name('attendance.checkin');
        Route::post('/check-out', [StaffMobileController::class, 'checkOut'])->middleware('abilities:staff:attendance')->name('attendance.checkout');
        Route::get('/attendance-history', [StaffMobileController::class, 'attendanceHistory'])->middleware('abilities:staff:attendance')->name('attendance.history');
    });
});
