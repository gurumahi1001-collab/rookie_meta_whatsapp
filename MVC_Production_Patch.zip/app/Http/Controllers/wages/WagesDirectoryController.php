<?php

namespace App\Http\Controllers\wages;

use App\Http\Controllers\Controller;
use App\Services\HR\WagesService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class WagesDirectoryController extends Controller
{
    public function __construct(private WagesService $wagesService) {}

    public function index(Request $request, string $type)
    {
        $filters = $request->validate(['search' => ['nullable', 'string', 'max:120'], 'page' => ['nullable', 'integer', 'min:1'], 'per_page' => ['nullable', 'integer', 'min:5', 'max:100']]);
        $p = $this->wagesService->paginate($type, array_merge(['per_page' => 10], $filters));
        $data = $this->wagesService->enrichPage($p->items());
        return response()->json(['success' => true, 'data' => $data, 'meta' => ['current_page' => $p->currentPage(), 'last_page' => $p->lastPage(), 'per_page' => $p->perPage(), 'total' => $p->total()], 'summary' => $this->wagesService->dashboardSummary($type)]);
    }

    public function show(string $type, int $id)
    {
        return response()->json(['success' => true, 'data' => $this->wagesService->details($id, $type)]);
    }

    public function payrollConfiguration()
    {
        return response()->json(['success' => true, 'data' => $this->wagesService->payrollConfiguration()]);
    }

    public function savePayrollConfiguration(Request $request)
    {
        $data = $request->validate([
            'rules' => ['required', 'array', 'min:1', 'max:500'],
            'rules.*.type_id' => ['required', 'integer', 'exists:ryans_renumeration_type,sno'],
            'rules.*.calculation_method' => ['required', Rule::in(['percentage_gross', 'percentage_basic', 'percentage_component', 'remainder', 'flat', 'pf', 'esi', 'tds', 'none'])],
            'rules.*.rate' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
            'rules.*.base_component_id' => ['nullable', 'integer', 'exists:ryans_renumeration_type,sno'],
            'rules.*.threshold_amount' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
            'rules.*.wage_ceiling' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
            'rules.*.cap_amount' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
            'rules.*.enabled' => ['required', 'boolean'],
            'rules.*.sort_order' => ['nullable', 'integer', 'min:0', 'max:999999'],
        ]);
        $actor = (int) (($request->user()->user_id ?? 0) ?: ($request->user()->id ?? session('user_id', 1)));
        $this->wagesService->savePayrollConfiguration($data['rules'], $actor);
        return response()->json(['success' => true, 'message' => 'Payroll component configuration saved.']);
    }

    public function calculatePayroll(Request $request)
    {
        $data = $request->validate(['gross_amount' => ['required', 'numeric', 'gt:0', 'max:999999999']]);
        return response()->json(['success' => true, 'data' => $this->wagesService->calculatePayrollPreview((float) $data['gross_amount'])]);
    }

    public function save(Request $request, string $type, int $id)
    {
        $data = $request->validate([
            'gross_amount' => ['required', 'numeric', 'gt:0', 'max:999999999'],
            'per_hour_cost' => ['nullable', 'numeric', 'min:0', 'max:999999999'],
        ]);
        $this->wagesService->save($id, $type, $data, (int) (($request->user()->user_id ?? 0) ?: ($request->user()->id ?? session('user_id', 1))));
        return response()->json(['success' => true, 'message' => 'Wage structure saved.']);
    }
}
