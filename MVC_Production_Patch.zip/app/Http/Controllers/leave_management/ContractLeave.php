<?php

namespace App\Http\Controllers\leave_management;

use App\Http\Controllers\Controller;
use Illuminate\View\View;

class ContractLeave extends Controller
{
    public function cleave(): View
    {
        return view('content.admin_hr.leave_manage.contract_lisst');
    }
}
