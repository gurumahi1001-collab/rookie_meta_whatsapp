<?php

namespace App\Http\Controllers\leave_management;

use App\Http\Controllers\Controller;
use Illuminate\View\View;

class Contract_Entitle extends Controller
{
    public function c_entitle(): View
    {
        return view('content.admin_hr.leave_manage.contract_entitle');
    }
}
