@extends('layouts.layoutMaster')

@section('title', 'Permanent Staff - Admin HR')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/select2/select2.scss'])

@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js'])

@endsection

@section('content')

{{-- STYLES   --}}
<style>
    /*          == SUMMARY CARDS          == */
    .summary-scroll-wrapper {
        width: 100%;
        overflow: hidden;
    }

    .custom-summary-scroll {
        width: 100%;
        flex-wrap: nowrap !important;
        overflow-x: auto;
        overflow-y: hidden;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: none;
        -ms-overflow-style: none;
    }

    .custom-summary-scroll::-webkit-scrollbar {
        display: none;
    }

    .summary-card-col {
        flex: 0 0 33.333333%;
        width: 33.333333%;
        max-width: 33.333333%;
    }

    .summary-label {
        font-size: 10px;
        letter-spacing: 0.5px;
        line-height: 1.4;
    }

    .summary-value {
        line-height: 1.35;
        margin-top: 2px;
    }

    .summary-description {
        font-size: 10px;
        line-height: 1.4;
    }

    .min-w-0 {
        min-width: 0;
    }


    /*          ==  FILTER SECTION  DESKTOP 100% VIEW          = */
    .filter-layout {
        display: grid;
        grid-template-columns:
            220px minmax(0, 1fr) 180px;
        align-items: center;
        gap: 10px;
        width: 100%;
        min-width: 0;
    }

    /*             FILTER SEARCH          == */

    .filter-search {
        width: 100%;
        min-width: 0;
    }

    .filter-search .position-relative {
        width: 100%;
        min-width: 0;
    }

    #hr-search-field {
        display: block;
        width: 100%;
        min-width: 0;
        height: 40px;
        font-size: 0.78rem;
        padding-top: 0.5rem;
        padding-bottom: 0.5rem;
        overflow: hidden;
        text-overflow: ellipsis;
    }


    /*   DEPARTMENT FILTER  */

    .filter-departments {
        width: 100%;
        min-width: 0;

        overflow: hidden;
    }

    .department-scroll {
        display: flex;
        align-items: center;
        gap: 6px;
        width: 100%;
        min-width: 0;
        overflow-x: auto;
        overflow-y: hidden;
        white-space: nowrap;
        padding: 1px 0 3px 0;
        scrollbar-width: none;
        -ms-overflow-style: none;
        -webkit-overflow-scrolling: touch;
    }

    .department-scroll::-webkit-scrollbar {
        display: none;
    }


    /*    DEPARTMENT BUTTONS  */

    .dept-filter-btn {
        flex: 0 0 auto;

        min-height: 36px;

        padding-left: 10px !important;
        padding-right: 10px !important;

        font-size: 0.72rem;

        background-color: #f8fafc;
        color: #475569;

        border: none;

        white-space: nowrap;

        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);

        transition:
            background-color 0.2s ease,
            color 0.2s ease,
            box-shadow 0.2s ease;
    }

    .dept-filter-btn:hover {
        background-color: #e2e8f0;
        color: #0f172a;
    }

    .dept-filter-btn.active {
        background-color: #16659E !important;
        color: #ffffff !important;

        box-shadow: 0 2px 5px rgba(22, 101, 158, 0.22);
    }



    /* Profile Photo Upload Styles */
    .avatar-upload-wrapper {
        position: relative;
        width: 64px;   /* Reduced size */
        height: 64px;
    }

    .avatar-preview {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background-color: #f8f9fa;
        border: 2px solid #fff;
        box-shadow: 0 0 0 1px #e9ecef;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .avatar-preview img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .avatar-upload-badge {
        position: absolute;
        bottom: -2px;
        right: -2px;
        width: 24px;   /* Reduced size */
        height: 24px;
        background-color: #fff;
        border: 1px solid #dee2e6;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        transition: all 0.2s ease;
    }

    .avatar-upload-badge:hover {
        background-color: #f8f9fa;
        transform: scale(1.05);
    }

    .avatar-upload-badge i {
        font-size: 13px;
        color: #6c757d;
    }
    /*  ADD STAFF */

    .filter-action {
        width: 100%;
        min-width: 0;
    }

    #hr-add-staff-btn {
        display: flex;

        align-items: center;
        justify-content: center;

        width: 100%;
        height: 40px;

        padding-left: 10px !important;
        padding-right: 10px !important;

        background-color: #16659E;

        font-size: 0.76rem;

        white-space: nowrap;

        overflow: hidden;
    }

    #hr-add-staff-btn span {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    #hr-add-staff-btn:hover {
        background-color: #0f5687;
    }


    /*  VERY LARGE DESKTOP  1400px+ */

    @media (min-width: 1400px) {

        .filter-layout {
            grid-template-columns:
                220px minmax(0, 1fr) 180px;
            gap: 12px;
        }

        .dept-filter-btn {
            padding-left: 11px !important;
            padding-right: 11px !important;

            font-size: 0.73rem;
        }

    }


    /* 1200px - 1399px */

    @media (min-width: 1200px) and (max-width: 1399.98px) {

        .filter-layout {
            grid-template-columns:
                210px minmax(0, 1fr) 175px;

            gap: 10px;
        }

        .dept-filter-btn {
            padding-left: 9px !important;
            padding-right: 9px !important;

            font-size: 0.70rem;
        }

        #hr-add-staff-btn {
            font-size: 0.74rem;
        }

    }


    /* TABLET 768px - 1199px */

    @media (min-width: 768px) and (max-width: 1199.98px) {

        .filter-layout {
            grid-template-columns:
                minmax(200px, 1fr) minmax(0, 1.5fr);

            gap: 12px;
        }

        .filter-search {
            grid-column: 1;
        }

        .filter-departments {
            grid-column: 2;
        }

        .filter-action {
            grid-column: 1 / -1;

            display: flex;

            justify-content: flex-end;

            width: 100%;
        }

        #hr-add-staff-btn {
            width: 180px;
            min-width: 180px;
        }


        /* Summary Cards */
        .custom-summary-scroll {
            scroll-snap-type: x mandatory;
        }

        .summary-card-col {
            flex: 0 0 48%;
            width: 48%;
            max-width: 48%;
            scroll-snap-align: start;
        }
    }


    /*  MOBILE Below 768px */

    @media (max-width: 767.98px) {

        /* Filter Layout */
        .filter-layout {
            display: flex;
            flex-direction: column;
            align-items: stretch;
            gap: 12px;
            width: 100%;
        }


        /* Search */
        .filter-search {
            width: 100%;
            min-width: 0;
        }

        .filter-search .position-relative {
            width: 100%;
        }

        #hr-search-field {
            width: 100%;
            min-width: 0;
        }


        /* Department */

        .filter-departments {
            width: 100%;
            min-width: 0;

            overflow: hidden;
        }

        .department-scroll {
            width: 100%;

            padding-bottom: 3px;

            scroll-behavior: smooth;
        }

        /* Add Staff */
        .filter-action {
            width: 100%;
        }

        #hr-add-staff-btn {
            width: 100%;
            min-width: 0;
        }


        /* Summary Cards */

        .custom-summary-scroll {
            scroll-snap-type: x mandatory;

            padding-left: 2px;
            padding-right: 2px;
            padding-bottom: 4px;
        }

        .summary-card-col {
            flex: 0 0 88%;
            width: 88%;
            max-width: 88%;

            scroll-snap-align: start;
        }

        .custom-summary-scroll .card {
            min-height: 100px;
        }


        /* Summary Text */

        .summary-value {
            font-size: 1.15rem !important;
        }

        .summary-label {
            font-size: 9px;
        }

        .summary-description {
            font-size: 9px;
        }


        /* Table */

        .table-responsive {
            overflow-x: auto;

            -webkit-overflow-scrolling: touch;
        }

        .table {
            min-width: 800px;
        }

    }


    /*  VERY SMALL MOBILE Below 400px */

    @media (max-width: 399.98px) {

        .summary-card-col {
            flex: 0 0 92%;
            width: 92%;
            max-width: 92%;
        }

        .summary-value {
            font-size: 1.05rem !important;
        }

        .card-body {
            padding: 12px !important;
        }

        .filter-layout {
            gap: 10px;
        }

        .dept-filter-btn {
            padding-left: 9px !important;
            padding-right: 9px !important;

            font-size: 0.70rem;
        }

        #hr-add-staff-btn {
            font-size: 0.74rem;
        }

    }


    /* TABLE */

    .table> :not(caption)>*>* {
        border-bottom-color: #f1f5f9;
    }

    .table thead th {
        white-space: nowrap;
    }

    .table tbody tr:last-child td {
        border-bottom: 0;
    }



    .employee-drawer {
        width: min(900px, 90vw) !important;
    }

    .employee-drawer-layout {
        min-height: calc(100vh - 80px);
    }

    /* Sidebar */
    .employee-tab {
        width: 100%;
        border: 0;
        background: transparent;
        padding: 11px 16px;
        display: flex;
        align-items: center;
        gap: 10px;
        text-align: left;
        color: #64748b;
        font-size: 12px;
        font-weight: 600;
        transition: all .2s ease;
        position: relative;
    }

    .employee-tab i {
        font-size: 17px;
        width: 20px;
        text-align: center;
    }

    .employee-tab:hover {
        background: #eef6ff;
        color: #16659E;
    }

    .employee-tab.active {
        background: #e8f2ff;
        color: #0C3C62;
    }

    .employee-tab.active::before {
        content: "";
        position: absolute;
        left: 0;
        top: 6px;
        bottom: 6px;
        width: 3px;
        border-radius: 0 4px 4px 0;
        background: #16659E;
    }

    /* Content */
    .employee-content {
        background: #ffffff;
        overflow-y: auto;
    }



    .employee-card {
        border: 1px solid #0f172a;
        border-radius: 10px;
        padding: 16px;
        margin-bottom: 15px;
        background: #fff;
    }

    .employee-label {
        display: block;
        color: #94a3b8;
        font-size: 10px;
        font-weight: 600;
        text-transform: uppercase;
        margin-bottom: 4px;
    }

    .employee-value {
        color: #334155;
        font-size: 13px;
        font-weight: 600;
    }

    .employee-row:hover {
        background-color: #f8fbff;
    }


    /* Editable input style */
    .employee-edit-input {
        width: 100%;
        border: 1px solid #d7dee8;
        border-radius: 6px;
        padding: 8px 10px;
        font-size: 13px;
        color: #334155;
        background: #ffffff;
        outline: none;
        transition: all .2s ease;
    }

    .employee-edit-input:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, .08);
    }

    textarea.employee-edit-input {
        min-height: 90px;
        resize: vertical;
    }

    .employee-editing .employee-card {
        background: #fbfdff;
    }

    .employee-editing .employee-label {
        margin-bottom: 6px;
    }

    /* Save button */
    #employeeEditBtn.is-saving {
        background: #059669 !important;
        color: #ffffff !important;
    }

    /* FAMILY MEMBERS */

    .family-member-card {
        border: 1px solid #0f172a;
        border-radius: 12px;
        padding: 17px 16px;
        background: #ffffff;
        transition: all 0.2s ease;
    }

    .family-member-card:hover {
        border-color: #16659E;
        box-shadow: 0 2px 8px rgba(15, 23, 42, 0.05);
    }


    /* Member Name */

    .family-member-name {
        font-size: 12px;
        font-weight: 700;
        color: #0f172a;
    }


    /* Relationship Badge */

    .family-relation-badge {
        display: inline-flex;
        align-items: center;
        padding: 3px 8px;
        border-radius: 6px;
        background: #eff6ff;
        color: #16659E;
        font-size: 9px;
        font-weight: 800;
        letter-spacing: 0.3px;
    }


    /* Member Details */

    .family-member-details {
        display: flex;
        align-items: center;
        gap: 12px;
        color: #16659E;
        font-size: 10px;
    }

    .family-member-details small {
        color: #94a3b8;
        font-size: 9px;
        margin-right: 4px;
    }


    /* Divider */

    .family-divider {
        width: 1px;
        height: 14px;
        background: #cbd5e1;
    }


    /* Delete Button */

    .family-delete-btn {
        border: 0;
        background: transparent;
        color: #f43f5e;
        font-size: 17px;
        padding: 2px;
        cursor: pointer;
        transition: color 0.2s ease;
    }

    .family-delete-btn:hover {
        color: #be123c;
    }


    /*             ===
    ADD FAMILY MEMBER BOX
                === */

    .family-add-box {
        border: 1px dashed #dbe3ec;
        border-radius: 12px;
        padding: 18px 16px;
        background: #fbfdff;
    }


    /* Add Box Title */

    .family-add-title {
        color: #476989;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0.5px;
    }


    /* Inputs */

    .family-input {
        height: 35px;
        border: 1px solid #dbe3ec;
        border-radius: 7px;
        background: #ffffff;
        color: #334155;
        font-size: 11px;
        padding: 7px 10px;
        box-shadow: none;
    }

    .family-input::placeholder {
        color: #94a3b8;
        opacity: 1;
    }

    .family-input:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, 0.08);
    }


    /* Add Button */

    .family-add-btn {
        background: #16659E;
        color: #ffffff;
        border: none;
        border-radius: 7px;
        font-size: 10px;
        font-weight: 700;
        padding: 8px 13px;
    }

    .family-add-btn:hover {
        background: #0C3C62;
        color: #ffffff;
    }


    /* DOCUMENT  */

    .documents-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 15px;
        width: 100%;
    }


    /*    DOCUMENT CARD*/

    .document-card {
        min-width: 0;
        min-height: 70px;

        display: flex;
        align-items: center;
        justify-content: space-between;

        gap: 12px;

        padding: 12px 14px;

        background: #ffffff;

        border: 1px solid #0f172a;
        border-radius: 12px;

        transition:
            border-color 0.2s ease,
            box-shadow 0.2s ease,
            background-color 0.2s ease;
    }

    .document-card:hover {
        border-color: #16659E;
        background: #fbfdff;
        box-shadow: 0 2px 8px rgba(15, 23, 42, 0.05);
    }


    /*  DOCUMENT INFO */

    .document-info {
        min-width: 0;

        display: flex;
        align-items: center;

        gap: 12px;

        flex: 1;
    }


    /* File Icon */

    .document-icon {
        flex: 0 0 38px;
        width: 38px;
        height: 38px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: #eff6ff;
        color: #16659E;
        font-size: 18px;
    }

    /*  DOCUMENT DETAILS */
    .document-details {
        min-width: 0;
        flex: 1;
    }

    .document-name {
        min-width: 0;
        color: #0f172a;

        font-size: 12px;
        font-weight: 700;
        line-height: 1.35;

        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .document-meta {
        margin-top: 3px;

        color: #7b94ad;

        font-size: 9px;
        font-weight: 500;

        line-height: 1.3;
    }

    .document-meta-divider {
        margin: 0 4px;
        color: #a8b6c4;
    }


    /*  DOCUMENT ACTIONS */

    .document-actions {
        flex: 0 0 auto;
        display: flex;
        align-items: center;
        gap: 10px;
    }


    /* Verified Badge */
    .document-status {
        display: inline-flex;
        align-items: center;
        padding: 4px 7px;
        border-radius: 4px;
        background: #f1f5f9;
        color: #476989;
        font-size: 9px;
        font-weight: 600;
        white-space: nowrap;
    }


    /* Delete */
    .document-delete-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        height: 24px;
        padding: 0;
        border: 0;
        background: transparent;
        color: #f43f5e;
        font-size: 15px;
        cursor: pointer;
        transition: color 0.2s ease;
    }

    .document-delete-btn:hover {
        color: #be123c;
    }

    /* UPLOAD BOX */

    .document-upload-box {
        width: 100%;
        margin-top: 24px;
        padding: 18px 16px;
        border: 1px dashed #dbe3ec;
        border-radius: 12px;
        background: #fbfdff;
    }

    /* Upload title */
    .document-upload-title {
        margin-bottom: 14px;
        color: #476989;
        font-size: 9px;
        font-weight: 800;
        letter-spacing: 0.6px;
    }


    /*  UPLOAD FORM */
    .document-upload-form {
        display: grid;
        grid-template-columns:
            minmax(0, 1fr) 176px 136px;
        gap: 12px;
        align-items: center;
        width: 100%;
    }


    /* Inputs */
    .document-input {
        width: 100%;
        height: 36px;
        border: 1px solid #dbe3ec;
        border-radius: 7px;
        background: #ffffff;
        color: #334155;
        font-size: 10px;
        box-shadow: none;
    }

    .document-input::placeholder {
        color: #94a3b8;
        opacity: 1;
    }

    .document-input:focus {
        border-color: #16659E;
        box-shadow:
            0 0 0 2px rgba(22, 101, 158, 0.08);
    }

    /*  UPLOAD BUTTON */
    .document-upload-btn {
        width: 100%;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 12px;
        border: 0;
        border-radius: 7px;
        background: #16659E;
        color: #ffffff;
        font-size: 10px;
        font-weight: 700;
        white-space: nowrap;
        transition: background-color 0.2s ease;
    }

    .document-upload-btn:hover {
        background: #0C3C62;
        color: #ffffff;
    }


    /* TABLET */

    @media (max-width: 767.98px) {

        .documents-grid {
            grid-template-columns: 1fr;
            gap: 12px;
        }

        .document-upload-form {
            grid-template-columns: 1fr;
        }

        .document-upload-action {
            width: 100%;
        }

        .document-upload-btn {
            width: 100%;
        }

    }


    /* VERY SMALL MOBILE*/

    @media (max-width: 399.98px) {
        .document-card {
            padding: 11px;
        }

        .document-info {
            gap: 9px;
        }

        .document-icon {
            flex-basis: 34px;
            width: 34px;
            height: 34px;
            font-size: 16px;
        }

        .document-name {
            font-size: 11px;
        }

        .document-meta {
            font-size: 8px;
        }

        .document-actions {
            gap: 6px;
        }

        .document-status {
            padding: 3px 5px;
            font-size: 8px;
        }

        .document-delete-btn {
            font-size: 14px;
        }
    }

    /*                                                                                                                               =
    EDUCATION
                                                                                                                                = */

    .education-card {
        position: relative;
    }

    .education-card>.d-flex {
        width: 100%;
    }

    .education-card .row {
        min-width: 0;
    }


    /* Delete button */

    .education-delete-btn {
        display: none;

        flex: 0 0 auto;

        border: 0;
        background: transparent;

        color: #f43f5e;

        font-size: 17px;

        padding: 2px 0 2px 12px;

        cursor: pointer;

        transition: color 0.2s ease;
    }

    .education-delete-btn:hover {
        color: #be123c;
    }


    /* Show delete icons only in Edit mode */

    .employee-editing .education-delete-btn {
        display: block;
    }


    /* ADD EDUCATION
                                                                                                                                = */

    .education-add-box {
        display: none;

        border: 1px dashed #dbe3ec;
        border-radius: 12px;
        padding: 18px 16px;
        background: #fbfdff;
    }

    /* Show only when Edit mode is active */
    .employee-editing .education-add-box {
        display: block;
    }

    .education-add-title {
        color: #476989;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0.5px;
    }

    .education-input {
        height: 35px;
        border: 1px solid #dbe3ec;
        border-radius: 7px;
        background: #ffffff;
        color: #334155;
        font-size: 11px;
        padding: 7px 10px;
        box-shadow: none;
    }

    .education-input::placeholder {
        color: #94a3b8;
        opacity: 1;
    }

    .education-input:focus {
        border-color: #16659E;
        box-shadow: 0 0 0 2px rgba(22, 101, 158, 0.08);
    }

    .education-add-btn {
        background: #16659E;
        color: #ffffff;
        border: none;
        border-radius: 7px;
        font-size: 10px;
        font-weight: 700;
        padding: 8px 13px;
    }

    .education-add-btn:hover {
        background: #0C3C62;
        color: #ffffff;
    }

    /* EMPLOYEE DRAWER RESPONSIVE ONLY FOR SMALL + MEDIUM DEVICES == */
    /*   MEDIUM DEVICES 768px - 991px */

    @media (min-width: 768px) and (max-width: 991.98px) {

        /* Drawer */
        .employee-drawer {
            width: 92vw !important;
            max-width: 92vw !important;
        }

        /* Main Layout */
        .employee-drawer-layout {
            display: flex;
            height: 100%;
        }

        /* Sidebar */
        .employee-sidebar {
            width: 190px !important;
            min-width: 190px !important;
            flex: 0 0 190px;
            overflow-y: auto;
        }

        .employee-tab {
            padding: 10px 12px !important;
            font-size: 11px !important;
            gap: 7px !important;
        }

        .employee-tab i {
            font-size: 16px !important;
            width: 18px;
            min-width: 18px;
        }

        /* Content */
        .employee-content {
            min-width: 0;
            overflow-x: hidden;
            overflow-y: auto;
        }

        .employee-panel {
            padding: 18px !important;
            width: 100%;
        }

        /* Header */
        .employee-drawer .offcanvas-header {
            padding: 12px 16px !important;
        }

        .employee-drawer .offcanvas-header h5 {
            font-size: 15px !important;
        }

        .employee-drawer .offcanvas-header .small {
            font-size: 10px !important;
        }

        /* Personal / KYC */
        .emp_personal {
            width: 50%;
        }

        /* Education */
        .emp_education {
            width: 50%;
        }

        /* Experience */
        .exp-edit-mode .emp_experience {
            width: 50%;
        }

        /* Training */
        .training-edit-mode .emp_traine,
        .training-edit-mode .emp_trainee {
            width: 50%;
        }

        /* References */
        .ref-edit-mode .emp_ref {
            width: 50%;
        }

        /* Interview */
        .interview-edit-mode .emp_interview {
            width: 50%;
        }

        /* Family */
        .family-edit-mode .emp_fam {
            width: 50%;
        }

        /* Remuneration Summary */
        .row.g-3.mb-4>.emp_remuneration {
            width: 50%;
        }

        /* Remuneration Components */
        .row.g-3>.emp_remuneration {
            width: 50%;
        }

        /* Last remuneration card full width */
        .row.g-3>..emp_remuneration {
            width: 100%;
        }

        /* Statutory / Banking */
        .col-md-6 {
            width: 50%;
        }

        /* Promotion History */
        .row.g-3 .col-md-4 {
            width: 50%;
        }

        /* Documents */
        .document-card {
            padding: 12px !important;
        }

        .document-name {
            font-size: 12px !important;
        }

    }


    /* SMALL DEVICES <= 767px  */

    @media (max-width: 767.98px) {

        /* DRAWER  */

        .employee-drawer {
            width: 100vw !important;
            max-width: 100vw !important;
        }

        /*   HEADER  */

        .employee-drawer .offcanvas-header {
            padding: 10px 12px !important;
        }

        .employee-drawer .offcanvas-header h5 {
            font-size: 13px !important;
        }

        .employee-drawer .offcanvas-header .small {
            font-size: 9px !important;
        }

        /* Avatar */
        .employee-drawer .offcanvas-header .rounded-circle {
            width: 38px !important;
            height: 38px !important;
        }

        /* Edit button */
        #employeeEditBtn {
            padding: 6px 9px !important;
            font-size: 10px !important;
        }

        /*                                                                                                                      ==
        MAIN LAYOUT
                                                                                                                                == */

        .employee-drawer-layout {
            display: flex !important;
            flex-direction: column !important;
            height: 100%;
        }

        /*                                                                                                                      ==
        SIDEBAR -> HORIZONTAL TABS
                                                                                                                                == */

        .employee-sidebar {
            width: 100% !important;
            min-width: 100% !important;
            flex: 0 0 auto !important;

            height: auto !important;
            overflow-x: auto !important;
            overflow-y: hidden !important;

            border-right: 0 !important;
            border-bottom: 1px solid #dee2e6;

            background: #f8fafc !important;
        }

        /* Hide "Employee Dossier" heading */
        .employee-sidebar>.p-3 {
            display: none;
        }

        /* Tab container */
        #employeeTabMenu {
            display: flex !important;
            flex-direction: row !important;

            width: max-content;
            min-width: 100%;

            padding: 5px !important;
            gap: 3px;
        }

        /* Individual tabs */
        .employee-tab {
            flex: 0 0 auto !important;
            width: auto !important;

            padding: 8px 11px !important;

            border: 0 !important;
            border-radius: 5px;

            font-size: 10px !important;
            gap: 5px !important;

            white-space: nowrap;
        }

        .employee-tab i {
            font-size: 14px !important;
            width: auto;
            min-width: auto;
        }

        .employee-tab.active {
            background: #16659E !important;
            color: #fff !important;
            border: 0 !important;
        }

        /*                                                                                                                      ==
        CONTENT
                                                                                                                                == */

        .employee-content {
            width: 100%;
            min-width: 0;

            overflow-x: hidden !important;
            overflow-y: auto !important;
        }

        .employee-panel {
            width: 100%;
            padding: 14px !important;
        }

        /* Section title */
        .employee-section-title {
            font-size: 13px !important;
            margin-bottom: 12px !important;
        }

        /*  PERSONAL / KYC  */

        [data-panel="personal"] .col-md-6,
        [data-panel="personal"] .col-12 {
            width: 100%;
        }

        .employee-card {
            padding: 13px;
        }

        .employee-label {
            font-size: 9px;
        }

        .employee-value {
            font-size: 12px;
            overflow-wrap: anywhere;
        }

        /*        EDUCATION  */

        .emp_education {
            width: 100%;
        }

        .education-card {
            padding: 12px;
        }

        .education-add-box {
            padding: 12px !important;
        }

        .education-add-box .col-md-6 {
            width: 100% !important;
        }

        .education-add-btn {
            width: 100%;
        }

        /*      EXPERIENCE  */

        .experience-item {
            padding: 12px !important;
        }

        .exp-view-mode .d-flex {
            align-items: flex-start !important;
        }

        .exp-view-designation {
            font-size: 13px !important;
        }

        .exp-view-duration {
            font-size: 9px !important;
            white-space: nowrap;
        }

        .exp-view-company {
            font-size: 11px !important;
        }

        .exp-view-roles {
            font-size: 11px !important;
            line-height: 1.5 !important;
        }

        .exp-edit-mode {
            padding-right: 0 !important;
        }

        .exp-edit-mode .col-md-6,
        .exp-edit-mode .col-md-12 {
            width: 100% !important;
        }

        /*        TRAINING  */

        .training-item {
            padding: 12px !important;
        }

        .training-view-title {
            font-size: 12px !important;
        }

        .training-view-date {
            font-size: 10px !important;
        }

        .training-view-status {
            font-size: 9px !important;
            white-space: nowrap;
        }

        .training-edit-mode {
            padding-right: 0 !important;
        }

        .training-edit-mode .col-md-6,
        .training-edit-mode .col-md-3 {
            width: 100% !important;
        }

        /*     REFERENCE CHECKS  */

        .reference-item {
            padding: 12px !important;
        }

        .ref-view-name {
            font-size: 12px !important;
        }

        .ref-view-status {
            font-size: 9px !important;
        }

        .ref-view-mode .gap-3 {
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 6px !important;
        }

        .ref-view-mode .gap-3>span {
            display: none;
        }

        .ref-edit-mode {
            padding-right: 0 !important;
        }

        .ref-edit-mode .col-md-6 {
            width: 100% !important;
        }

        /*                                                                                                                      ==
        INTERVIEW
                                                                                                                                == */

        .interview-item {
            padding: 12px !important;
        }

        .interview-view-mode .col-md-3 {
            width: 50% !important;
        }

        .interview-view-recruiter,
        .interview-view-date,
        .interview-view-rating {
            font-size: 11px !important;
        }

        .interview-view-comments {
            font-size: 11px !important;
        }

        .interview-edit-mode {
            padding-right: 0 !important;
        }

        .interview-edit-mode .col-md-3,
        .interview-edit-mode .col-12 {
            width: 100% !important;
        }

        /*   FAMILY  */

        .family-member-card {
            padding: 12px !important;
        }

        .family-edit-mode {
            padding-right: 0 !important;
        }

        .family-edit-mode .col-md-6 {
            width: 100%;
        }

        .family-add-box {
            padding: 12px;
        }

        .family-add-box .col-md-6 {
            width: 100% !important;
        }

        .family-add-btn {
            width: 100%;
        }

        .family-member-details {
            display: flex;
            flex-direction: column;
            gap: 5px;
            font-size: 11px;
        }

        .family-divider {
            display: none;
        }

        /*     REMUNERATION  */

        .emp_remuneration {
            padding: 12px !important;
        }

        /* Summary cards - 2 per row */
        .row.g-3.mb-4>.emp_remuneration,
        .row.g-3.mb-4>.emp_remuneration {
            width: 50% !important;
        }

        .row.g-3.mb-4>.emp_remuneration>div {
            padding: 10px !important;
        }

        /* Salary components - one per row */
        .row.g-3>.emp_remuneration {
            width: 100% !important;
        }

        /* Statutory / Banking */
        .emp_remuneration {
            width: 100% !important;
        }

        /* Promotion history */
        .row.g-3 .emp_remuneration {
            width: 100% !important;
        }

        /* Salary inputs */
        input[type="number"] {
            width: 75px !important;
        }

        /*   DOCUMENTS   */
        .document-card {
            padding: 10px !important;
            gap: 8px;
        }

        .document-info {
            min-width: 0;
            flex: 1;
        }

        .document-icon {
            font-size: 25px !important;
        }

        .document-name {
            font-size: 11px;
            overflow-wrap: anywhere;
        }

        .document-meta {
            font-size: 9px;
        }

        .document-status {
            font-size: 8px;
        }

        /* Upload section */
        .document-upload-box {
            padding: 12px;
        }

        .document-upload-box>.d-flex {
            flex-direction: column
        }

        .document-upload-box>.d-flex>div {
            width: 100%;
            min-width: 100%;
        }

        #triggerFileSelectBtn,
        #documentUploadBtn {
            width: 100%;
        }

        /* PREVENT HORIZONTAL OVERFLOW  */

        .employee-drawer * {
            max-width: 100%;
        }

        .employee-drawer .row {
            margin-left: 0;
            margin-right: 0;
        }

        .employee-drawer .font-monospace {
            overflow-wrap: anywhere;
        }
    }
</style>

<div class="container-fluid px-0">
    {{-- ==== SUMMARY CARDS =======--}}
    <div class="summary-scroll-wrapper mb-4">
        <div class="row g-3 flex-nowrap custom-summary-scroll">
            {{--   = WORKFORCE REGISTRY   = --}}
            <div class="summary-card-col">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            {{-- Icon --}}
                            <div class="summary-icon d-flex align-items-center justify-content-center flex-shrink-0"
                                style=" width: 48px; height: 48px; border-radius: 12px; background-color: #eff6ff;color: #16659E;">
                                <i class="mdi mdi-account-group fs-4"></i>
                            </div>
                            {{-- Content --}}
                            <div class="min-w-0">
                                <span class="d-block text-uppercase fw-bold text-secondary summary-label">
                                    SRK Workforce Registry
                                </span>
                                <span class="d-block fs-4 fw-extrabold font-monospace summary-value"
                                    style="color: #0C3C62;">
                                  <span id="total_employees_dash">0</span> Staff
                                </span>
                                <small class="text-muted summary-description">
                                    Mapped to current active infrastructures
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            {{--   = Monthly ACTIVE PRESENCE   = --}}
            <div class="summary-card-col">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            {{-- Icon --}}
                            <div class="summary-icon d-flex align-items-center justify-content-center flex-shrink-0"
                                style="width: 48px;height: 48px;border-radius: 12px;background-color: #ecfdf5;color: #059669;">
                                <i class="mdi mdi-account-check fs-4"></i>
                            </div>

                            {{-- Content --}}
                            <div class="min-w-0">
                                <span class="d-block text-uppercase fw-bold text-secondary summary-label">
                                    Monthly Active Presence
                                </span>
                                <span class="d-block fs-4 fw-extrabold font-monospace text-success summary-value">
                                    <span id="total_month_present_dash">0</span> Present
                                </span>
                                <span class="badge rounded-1 fw-semibold mt-1" style="
                                        font-size: 10px;
                                        background-color: #ecfdf5;
                                        color: #059669;
                                    ">
                                    <span id="total_attendance_rate_dash">0</span>% Attendance Rate Today
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {{--   = Monthly WAGE ALLOCATION   = --}}
            <div class="summary-card-col">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3">
                        <div class="d-flex align-items-center gap-3">
                            {{-- Icon --}}
                            <div class="summary-icon d-flex align-items-center justify-content-center flex-shrink-0"
                                style="
                                    width: 48px;
                                    height: 48px;
                                    border-radius: 12px;
                                    background-color: #fff7ed;
                                    color: #E86A33;
                                ">
                                <i class="mdi mdi-credit-card-outline fs-4"></i>
                            </div>
                            {{-- Content --}}
                            <div class="min-w-0">
                                <span class="d-block text-uppercase fw-bold text-secondary summary-label">
                                    Monthly Wage Allocation
                                </span>
                                <span class="d-block fs-4 fw-extrabold font-monospace summary-value"
                                    style="color: #0C3C62;">
                                    <span id="total_wages_today_dash">0</span>
                                </span>
                                <small class="text-muted d-block summary-description">
                                    Drawn from present workforce logs
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{--             ===
        FILTER / SEARCH SECTION
                ==== --}}
    <div class="card border-0 shadow-sm rounded-4 bg-white mb-4">
        <div class="card-body p-3">
            <div class="filter-layout">
                {{--   ======== SEARCH   ======== --}}
                <div class="filter-search ">
                    <div class="position-relative">
                        <span class="position-absolute top-50 start-0 translate-middle-y ps-2 text-muted"
                            style="pointer-events: none;">
                            <i class="mdi mdi-magnify fs-5"></i>
                        </span>

                        <input id="hr-search-field" type="text" placeholder="Search staff, designation or email"
                            class="form-control form-control-sm ps-7  bg-light border-0 rounded-3 text-secondary" />

                    </div>
                </div>
                {{--   ======== DEPARTMENT FILTER   ======== --}}
                <div class="filter-departments">
                    <div class="department-scroll">
                        
                    </div>
                </div>

                {{--   ======== ADD STAFF   ======== --}}
                <div class="filter-action">
                    <button type="button" id="hr-add-staff-btn"
                        class="btn text-white d-flex align-items-center justify-content-center gap-2 rounded-3 px-3 py-2 shadow-sm fw-bold border-0"
                        data-bs-toggle="offcanvas" data-bs-target="#staffDrawer">
                        <i class="mdi mdi-account-plus fs-6"></i>
                        <span>
                            Add Staff Member
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    {{-- ======  STAFF TABLE ====== --}}
    <div class="card border-0 shadow-sm rounded-4">
        {{-- Card Header --}}
        <div class="card-header bg-white border-0 px-4 py-3">
            <div class="d-flex align-items-center justify-content-between gap-3">
                <div>
                    <h5 class="mb-1 fw-bold" style="color: #0C3C62;">
                        Permanent Staff
                    </h5>
                    <small class="text-muted">
                        Manage and monitor permanent workforce members
                    </small>
                </div>
                <span class="badge rounded-3 px-3 py-2" style="
                        background-color: #eff6ff; color: #16659E; font-size: 11px;">
                    <span id="total_employees_table">0</span> Staff
                </span>
            </div>
        </div>
        {{-- Table --}}
        <div class="table-responsive">
            <table class="table table-hover mb-0" id="staff-table">
                <thead class="fw-semibold text-black fs-8 uppercase bg-light">
                    <tr>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Staff Member
                        </th>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Designation
                        </th>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Department
                        </th>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Wages
                        </th>
                        <th class="min-w-100px text-black" style="font-size: 13px;">
                            Status
                        </th>
                    </tr>
                </thead>
                <tbody id="list-table-body" class="table-border-bottom-0">
                    <tr class="skeleton-loader" id="skeleton-loader">
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                        <td class="skeleton-cell">
                            <div class="skeleton"></div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>


{{--   ======== EXIT EMPLOYEE MODAL   ======== --}}
<div class="modal fade" id="employeeExitModal" tabindex="-1" aria-labelledby="employeeExitModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow rounded-4">
            {{-- Modal Header --}}
            <div class="modal-header border-0 pb-2">
                <div>
                    <h6 class="modal-title fw-bold text-dark" id="employeeExitModalLabel">
                        <i class="mdi mdi-exit-run text-warning me-1"></i>
                        Employee Exit
                    </h6>
                    <small class="text-muted">
                        Enter employee exit details
                    </small>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>

            {{-- Modal Body --}}
            <div class="modal-body pt-2">
                <form id="employeeExitForm">
                    {{-- Employee ID --}}
                    <input type="hidden" id="exit_employee_id" name="employee_id">
                    {{-- Status --}}
                    <input type="hidden" name="status" value="Exit">
                    {{-- Date of Exit --}}
                    <div class="mb-3">
                        <label for="exit_date" class="form-label fw-semibold" style="font-size: 11px;">
                            Date of Exit
                            <span class="text-danger">*</span>
                        </label>
                        <input type="date" class="form-control form-control-sm rounded-3" id="exit_date"
                            name="exit_date" required>
                    </div>
                    {{-- Remark --}}
                    <div class="mb-3">
                        <label for="exit_remark" class="form-label fw-semibold" style="font-size: 11px;">
                            Remark
                            <span class="text-danger">*</span>
                        </label>
                        <textarea class="form-control form-control-sm rounded-3" id="exit_remark" name="exit_remark"
                            rows="3" placeholder="Enter exit reason / remark..." required></textarea>
                    </div>
                </form>
            </div>

            {{-- Modal Footer --}}
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-sm btn-light rounded-3" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="button" class="btn btn-sm btn-warning rounded-3 fw-semibold" id="confirmEmployeeExit">
                    <i class="mdi mdi-check me-1"></i>
                    Confirm Exit
                </button>
            </div>
        </div>
    </div>
</div>

{{-- ADD STAFF OFFCANVAS DRAWER --}}
<div class="offcanvas offcanvas-end staff-drawer" tabindex="-1" id="staffDrawer" aria-labelledby="staffDrawerLabel"
    style="width: 700px;">
    {{-- HEADER --}}
    <div class="offcanvas-header border-bottom bg-primary ">
        <div>
            <h5 class="offcanvas-title fw-bold text-white" id="staffDrawerLabel">
                Add Staff Member
            </h5>
            <small class="text-muted">
                Add permanent staff details
            </small>
        </div>
        <button type="button" class="btn-close text-white" data-bs-dismiss="offcanvas">
        </button>
    </div>
    {{-- BODY --}}
    <div class="offcanvas-body d-flex flex-column pl-4">
        <div class="flex-grow-1 overflow-auto p-3">
            <form id="staffForm">
                {{-- 1. PERSONAL INFORMATION --}}
                <div class="mb-4">
                    <h6 class="fw-bold mb-1" style="color:#0C3C62;">
                        1. Personal Information
                    </h6>
                    <small class="text-muted d-block mb-3">
                        Enter the basic personal details of the staff member.
                    </small>

                    {{-- PROFILE PHOTO UPLOAD (Compact Format) --}}
                    

                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="p-3">
                        
                                <h6 class="fw-bold mb-1" style="color: #212529; font-size: 14px;">Profile Photo</h6>
                                

                                <div class="d-flex flex-column flex-sm-row align-items-sm-center gap-3">
                                    {{-- Avatar with Upload Badge --}}
                                    <div class="avatar-upload-wrapper flex-shrink-0">
                                        <div class="avatar-preview" id="profilePreview">
                                            {{-- Default Placeholder --}}
                                            <img src="https://ui-avatars.com/api/?name=PAIGE&background=f8f9fa&color=0d6efd&size=100" alt="Profile" id="avatarImage">
                                        </div>
                                        <label for="profilePhoto" class="avatar-upload-badge" title="Upload Photo">
                                            <i class="mdi mdi-camera-outline"></i>
                                        </label>
                                        <input type="file" id="profilePhoto" name="profile_photo" accept="image/jpeg, image/png, image/webp" class="d-none">
                                    </div>

                                    {{-- Details & Buttons --}}
                                    <div class="flex-grow-1 min-w-0">
                                        <div class="d-flex align-items-center flex-wrap gap-2 mb-2">
                                            <button type="button" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center gap-1 px-2 py-1" style="font-size: 12px;" onclick="document.getElementById('profilePhoto').click();">
                                                <i class="mdi mdi-camera-outline"></i> Upload Photo
                                            </button>
                                            <button type="button" class="btn btn-sm btn-link text-danger text-decoration-none d-inline-flex align-items-center gap-1 d-none px-1 py-1" style="font-size: 12px;" id="removeProfilePhotoBtn">
                                                <i class="mdi mdi-trash-can-outline"></i> Remove
                                            </button>
                                        </div>

                                        <p class="text-muted mb-0" style="font-size: 10px;">
                                            JPG, PNG or WebP &middot; Maximum 2 MB
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 p-3">
                            <label class="form-label fw-semibold">Employee Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="employeeName" placeholder="Enter employee name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Date of Birth</label>
                            <input type="date" class="form-control" id="employeeDob">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Gender</label>
                            <select class="select3 form-select" id="employeeGender">
                                <option value="">Select gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Marital Status</label>
                            <select class="select3 form-select" id="employeeMaritalStatus">
                                <option value="">Select marital status</option><option value="1">Married</option><option value="0">Single</option><option value="2">Divorced</option><option value="3">Widowed</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Mobile</label>
                            <input type="tel" class="form-control" id="employeeMobile" placeholder="Enter mobile number" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="14" onkeyup="mobile_chk(this.value)">
                            <div class="text-danger text-small" id="employeeMobile_err"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Alternate Mobile Number</label>
                            <input type="tel" class="form-control" id="employeeAltMobile" placeholder="Enter alternate mobile number" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="14">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email ID</label>
                            <input type="email" class="form-control" id="employeeEmail" placeholder="example@email.com" oninput="this.value=this.value.toLowerCase();">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Date of Joining <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="dateOfJoining">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Date of Exit</label>
                            <input type="date" class="form-control" id="dateOfExit">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Address</label>
                            <textarea class="form-control" id="employeeAddress" rows="3" placeholder="Enter complete address"></textarea>
                        </div>
                    </div>

                    {{-- EMERGENCY CONTACT DETAILS --}}
                    <div class="mt-4">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <h6 class="fw-bold mb-0" style="color:#0C3C62;">
                                Emergency Contact Details
                            </h6>
                            {{-- Plus Icon Button --}}
                            <button type="button" class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center shadow-sm" 
                                    id="addEmergencyContactBtn" title="Add Emergency Contact" style="width: 32px; height: 32px; padding: 0;">
                                <i class="mdi mdi-plus" style="font-size: 18px;"></i>
                            </button>
                        </div>
                        <small class="text-muted d-block mb-3">
                            Provide details of the person to be contacted in case of an emergency.
                        </small>

                        {{-- Container for dynamically added contacts --}}
                        <div id="emergencyContactContainer">
                            
                            {{-- First Default Contact Row --}}
                            <div class="row g-3 emergency-contact-row mb-2 align-items-center">
                                <div class="col-md-5">
                                    <label class="form-label fw-semibold">Contact Name</label>
                                    <input type="text" class="form-control" name="emergency_contacts[0][name]" placeholder="Enter contact name">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Relation</label>
                                    <select class="select3 form-select" name="emergency_contacts[0][relation]">
                                        <option value="">Select relation</option>
                                        
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Contact Number</label>
                                    <input type="tel" class="form-control" name="emergency_contacts[0][number]" placeholder="Enter contact number">
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <hr>
               

                {{-- 2. GOVERNMENT / IDENTITY DETAILS --}}
                <div class="my-4">
                    <h6 class="fw-bold mb-1" style="color:#0C3C62;">
                        2. Government / Identity Details
                    </h6>
                    <small class="text-muted d-block mb-3">
                        Enter government identification and basic identity details.
                    </small>
                    <div class="row g-3">
                        <!-- Aadhaar -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Aadhaar No</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="aadhaarNumber" placeholder="Enter Aadhaar number" maxlength="12">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('aadhaarUpload').click()" title="Upload Aadhaar">
                                    <i class="mdi mdi-file-upload-outline text-white fs-4"></i>
                                </button>
                                <input type="file" id="aadhaarUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'aadhaarFileName')">
                            </div>
                            <small id="aadhaarFileName" class="text-success d-block mt-1"></small>
                        </div>

                        <!-- PAN -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">PAN Number</label>
                            <div class="input-group">
                                <input type="text" class="form-control " id="panNumber" placeholder="Enter PAN number" maxlength="10">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('panUpload').click()" title="Upload PAN">
                                    <i class="mdi mdi-file-upload-outline fs-4 text-white"></i>
                                </button>
                                <input type="file" id="panUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'panFileName')">
                            </div>
                            <small id="panFileName" class="text-success d-block mt-1"></small>
                        </div>

                        <!-- ESI (No upload) -->
                      
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">ESI No</label>
                            <div class="input-group">
                                <input type="text" class="form-control " id="esiNumber" placeholder="Enter ESI No" maxlength="10">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('esiUpload').click()" title="Upload ESI">
                                    <i class="mdi mdi-file-upload-outline text-white fs-4"></i>
                                </button>
                                <input type="file" id="esiUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'esiFileName')">
                            </div>
                            <small id="esiFileName" class="text-success d-block mt-1"></small>
                        </div>

                        <!-- Blood Group -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Blood Group</label>
                            <select class="select3 form-select" id="bloodGroup">
                                <option value="">Select blood group</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                            </select>
                        </div>

                        <!-- UAN -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">UAN Number</label>
                            <div class="input-group">
                                <input type="text" class="form-control " id="uanNumber" placeholder="Enter UAN number" maxlength="12">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('uanUpload').click()" title="Upload UAN">
                                    <i class="mdi mdi-file-upload-outline fs-4 text-white"></i>
                                </button>
                                <input type="file" id="uanUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'uanFileName')">
                            </div>
                            <small id="uanFileName" class="text-success d-block mt-1"></small>
                        </div>

                        <!-- Voter ID -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Voter ID</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="voterId" placeholder="Enter Voter ID" maxlength="10">
                                <button class="btn bg-primary" type="button" onclick="document.getElementById('voterUpload').click()" title="Upload Voter ID">
                                    <i class="mdi mdi-file-upload-outline text-white fs-4"></i>
                                </button>
                                <input type="file" id="voterUpload" class="d-none" accept="image/*,.pdf" onchange="showFileName(this, 'voterFileName')">
                            </div>
                            <small id="voterFileName" class="text-success d-block mt-1"></small>
                        </div>
                    </div>
                </div>
                <hr>

                {{-- 3. LOGIN CREDENTIAL --}}
                <div class="mt-4">
                    <div class="mb-3">
                        <h6 class="fw-bold mb-1" style="color:#0C3C62;">
                            3. Login Credential
                        </h6>
                        <p class="text-muted mb-0" style="font-size:11px;">
                            Configure system login access for this employee.
                        </p>
                    </div>
                    <div class="border rounded-3 p-3 bg-light">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="isLoginRequired" name="is_login_required" value="1">
                            <label class="form-check-label fw-semibold" for="isLoginRequired" style="color:#0C3C62;">
                                Is login required?
                            </label>
                        </div>
                        <div class="ms-4 mt-1">
                            <small class="text-muted">
                                Enabling login access generates secure user credentials
                                and triggers dynamic role authorizations in accordance
                                with standard ERP policies.
                            </small>
                        </div>
                        <div id="loginCredentialFields" class="row g-3 mt-2 d-none">
                            <div class="col-12 col-md-6">
                                <label for="loginUsername" class="form-label fw-semibold">
                                    Username <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white"><i class="mdi mdi-account-outline"></i></span>
                                    <input type="text" class="form-control" id="loginUsername" name="username" placeholder="Enter username" autocomplete="off">
                                </div>
                                <small class="text-muted">Username used to access the ERP system.</small>
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="loginPin" class="form-label fw-semibold">
                                    Login PIN <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white"><i class="mdi mdi-lock-outline"></i></span>
                                    <input type="password" class="form-control" id="loginPin" name="login_pin" placeholder="Enter Password"  autocomplete="new-password">
                                    <button type="button" class="btn btn-outline-secondary" id="toggleLoginPin">
                                        <i class="mdi mdi-eye-outline" id="loginPinIcon"></i>
                                    </button>
                                </div>
                                <!-- <small class="text-muted">Use a secure 4–6 digit PIN.</small> -->
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="user_role" class="form-label fw-semibold">
                                    User Role<span class="text-danger">*</span>
                                </label>
                                <select class="select3 form-select" id="user_role" name="user_role">
                                    <option value="">Select User Role</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <div class="alert alert-primary border-0 mb-0 py-2 px-3" style="font-size:11px;">
                                    <div class="d-flex align-items-start gap-2">
                                        <i class="mdi mdi-information-outline" style="font-size:18px;"></i>
                                        <div>
                                            <strong>Login Access Enabled</strong>
                                            <div class="mt-1">
                                                This employee will receive system login
                                                access based on the roles and permissions
                                                assigned by the administrator.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>

                {{-- 4. PROFESSIONAL DETAILS --}}
                <div class="my-4">
                    <h6 class="fw-bold mb-1" style="color:#0C3C62;">
                        4. Professional Details
                    </h6>
                    <small class="text-muted d-block mb-3">
                        Configure the staff member's role, department and project allocation.
                    </small>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="department" class="form-label fw-semibold">
                                Department / Unit <span class="text-danger">*</span>
                            </label>
                            <select class="select3 form-select" id="department">
                                <option value="">Select department</option>
                                <option value="Management">Management</option>
                                <option value="Accounts">Accounts</option>
                                <option value="Purchase">Purchase</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="role_designation" class="form-label fw-semibold">
                                Role Designation <span class="text-danger">*</span>
                            </label>
                            <select class="select3 form-select" id="role_designation"><option value="">Select designation</option></select>
                        </div>
                    
                        <div class="col-md-6">
                            <!-- Label stays on top -->
                            <label class="form-label fw-semibold" for="ctcInput">
                                CTC <span class="text-danger">*</span>
                            </label>
                            
                            <!-- Input and Button in the same row with proper padding -->
                            <div class="d-flex gap-2 align-items-center">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="ctcInput" 
                                    placeholder="Auto-calculated from Wages" 
                                    style="flex: 1;" 
                                    readonly
                                    aria-readonly="true"
                                    title="CTC is calculated from the gross salary and Payroll Configuration in Wages."
                                />
                                
                               <button 
                                    type="button" 
                                    class="btn bg-primary text-nowrap d-flex align-items-center justify-content-center gap-2 px-3" 
                                    id="monthlyWages" 
                                    style="height: 38px;"
                                    data-bs-toggle="modal" 
                                    data-bs-target="#wagesModal">
                                    <span class="text-white fw-semibold">Wages</span>
                                    <i class="mdi mdi-arrow-right text-white fs-5"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">
                                Grade <span class="text-danger">*</span>
                            </label>
                            <select class="select3 form-select" id="grade">
                                <option value="">Select Grade</option>
                                <option value="Grade A">Grade A</option>
                                <option value="Grade B">Grade B</option>
                                <option value="Grade C">Grade C</option>
                                <option value="Grade E">Grade E</option>
                            </select>
                        </div>

                       
                        <div class="col-md-6">
                            <label for="probationPeriod" class="form-label fw-semibold">
                                Probation Period
                            </label>
                            <select class="select3 form-select" id="probationPeriod" name="probation_period">
                                <option value="">Select probation period</option>
                                <option value="0">No Probation</option>
                                <option value="30">30 Days</option>
                                <option value="60">60 Days</option>
                                <option value="90">90 Days</option>
                                
                            </select>
                        </div>

                        {{-- Workplace Leave Balance Configuration: values come from Leave Management Configure Settings --}}
                        <div class="mt-4" id="workplaceLeaveBalanceConfiguration">
                            <div class="mb-3">
                                <h6 class="mb-1">Workplace Leave Balance Configuration</h6>
                                <p class="text-muted small mb-0">Effective leave allocations are calculated from Leave Management annual policy quotas and Date of Joining. The calculated values remain editable for this staff member; changing Date of Joining recalculates them.</p>
                            </div>
                            <div class="border rounded-3 p-3 bg-light">
                                <div class="row g-3">
                                    <div class="col-12 col-sm-6 col-md-4">
                                        <label for="casualLeave" class="form-label fw-semibold">Casual Leave (CL)</label>
                                        <input type="number" class="form-control" id="casualLeave" name="casual_leave" min="0" max="366" step="0.01" value="12" data-hr-policy-annual="12">
                                        <small class="text-muted" id="casualLeaveProrated">Initial-year allocation: —</small>
                                    </div>
                                    <div class="col-12 col-sm-6 col-md-4">
                                        <label for="paidLeave" class="form-label fw-semibold">Paid Leave (PL)</label>
                                        <input type="number" class="form-control" id="paidLeave" name="paid_leave" min="0" max="366" step="0.01" value="15" data-hr-policy-annual="15">
                                        <small class="text-muted" id="paidLeaveProrated">Initial-year allocation: —</small>
                                    </div>
                                    <div class="col-12 col-sm-6 col-md-4">
                                        <label for="sickLeave" class="form-label fw-semibold">Sick Leave (SL)</label>
                                        <input type="number" class="form-control" id="sickLeave" name="sick_leave" min="0" max="366" step="0.01" value="12" data-hr-policy-annual="12">
                                        <small class="text-muted" id="sickLeaveProrated">Initial-year allocation: —</small>
                                    </div>
                                </div>
                                <div class="small text-primary mt-3" id="leaveCyclePreview">Select Date of Joining to preview the leave cycle and initial-year allocation.</div>
                            </div>
                        </div>

                        {{-- 5. Language Skills --}}
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <label class="fw-bold mb-0" style="color:#0C3C62;">5. Language Skills</label>
                                    <small class="d-block text-muted mt-1">Add languages and specify the employee's reading, writing and speaking skills.</small>
                                </div>
                                <!-- <button type="button" class="btn btn-primary btn-sm" id="addLanguageBtn">
                                    <i class="mdi mdi-plus me-1"></i> Add Language
                                </button> -->
                            </div>
                            <div>
                                <select class="form-select select3" id="languages" name="languages" multiple>
                                    <option value="" >select Languages</option>
                                </select>
                            </div>
                            <!-- <div id="languageInputSection" class="border rounded-3 bg-light p-3 mb-3" style="display: none;">
                                <div class="row g-3 align-items-end">
                                    <div class="col-12 col-md-6">
                                        <label for="languageSkills" class="form-label fw-semibold mb-1">Language</label>
                                        <input type="text" class="form-control" id="languageSkills" placeholder="Enter language" autocomplete="off">
                                    </div>
                                    <div class="col-12 col-md-auto">
                                        <button type="button" class="btn btn-primary" id="saveLanguageBtn">
                                            <i class="mdi mdi-check me-1"></i> Add
                                        </button>
                                    </div>
                                </div>
                            </div> -->
                            <!-- <div class="table-responsive border rounded-3" id="languageTableWrapper" style="display: none;">
                                <table class="table table-hover align-middle mb-0" id="languageSkillsTable">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="fw-bold text-dark" style="min-width: 180px;">Language</th>
                                            <th class="fw-bold text-dark text-center" style="width: 120px;">Read</th>
                                            <th class="fw-bold text-dark text-center" style="width: 120px;">Write</th>
                                            <th class="fw-bold text-dark text-center" style="width: 120px;">Speak</th>
                                            <th class="fw-bold text-dark text-center" style="width: 80px;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="languageSkillsBody"></tbody>
                                </table>
                            </div> -->
                        </div>
                        

                        <style>
                            .hover-bg-light { transition: background-color 0.2s ease; }
                            .hover-bg-light:hover { background-color: #f1f5f9 !important; }
                        </style>
                    </div>
                </div>

            </form>
        </div>
    </div>
    {{-- FOOTER --}}
    <div class="border-top p-3 d-flex justify-content-end gap-2 bg-white" style="position:sticky;bottom:0;">
        <button type="button" class="btn btn-label-secondary" data-bs-dismiss="offcanvas">
            Cancel
        </button>
        <button type="button" class="btn btn-primary px-4" id="saveStaff">
            <i class="mdi mdi-content-save-outline me-1"></i>
            Save Staff
        </button>
    </div>
</div>

</div>


{{-- EMPLOYEE DETAILS DRAWER --}}
<div class="offcanvas offcanvas-end employee-drawer" tabindex="-1" id="employeeDrawer"
    aria-labelledby="employeeDrawerLabel" data-bs-backdrop="true" style="width:1500px; max-width:100%;">
    {{-- HEADER --}}
    <div class="offcanvas-header border-bottom px-4 py-3 bg-primary">

        <div class="d-flex align-items-center gap-3">

            {{-- Employee Avatar --}}
            <div class="" style="">
                <img src="https://ui-avatars.com/api/?name=PAIGE&background=f8f9fa&color=0d6efd&size=100" style="width:46px; height:46px; background:#eff6ff; object-fit:cover;" class="rounded-circle" alt="Profile" id="staffProfilePreview">
                <label for="employeeProfilePhoto" id="employeePhotoEditControl" class="btn btn-sm btn-light d-none mt-1" style="font-size:10px; padding:2px 6px;">
                    <i class="mdi mdi-camera-outline me-1"></i>Change photo
                </label>
                <input type="file" id="employeeProfilePhoto" class="d-none" accept="image/jpeg,image/png,image/webp">
            </div>

            {{-- Employee Information --}}
            <div class="d-flex flex-column">

                <h5 class="mb-1 fw-bold text-white">
                    Madhavan Krishnan
                </h5>

                <span class="small text-white-50">
                    Lead Site Engineer
                </span>

                <span class="small text-white-50">
                    Engineering
                </span>

            </div>

        </div>


        {{-- Header Actions --}}
        <div class="d-flex align-items-center gap-2">
            {{-- Edit / Save Button --}}
            <button type="button" class="btn btn-sm d-flex align-items-center gap-1 px-3 py-2" id="employeeEditBtn"
                style=" background:rgba(224, 0, 0, 0.12); border:1px solid rgba(255,255,255,0.25); border-radius:6px; font-size:12px;
                font-weight:600; color:#ffffff;">
                <i class="mdi mdi-pencil-outline" id="employeeEditIcon"></i>
                <span id="employeeEditText">
                    Edit
                </span>
            </button>

            {{-- Close --}}
            <button type="button" class="btn-close btn-close-white ms-1" data-bs-dismiss="offcanvas" aria-label="Close">
            </button>
        </div>

    </div>

    {{--   BODY --}}
    <div class="offcanvas-body p-0">
        <div class="d-flex h-100 employee-drawer-layout">
            {{--  LEFT SIDEBAR --}}
            <div class="employee-sidebar border-end" style="
                    width:220px;
                    min-width:220px;
                    background:#f8fafc;">
                <div class="p-3">
                    <small class="text-uppercase fw-bold text-muted" style="
                            font-size:10px;
                            letter-spacing:.5px;">
                        Employee Dossier
                    </small>
                </div>

                <div id="employeeTabMenu">
                    <button type="button" class="employee-tab active" data-tab="personal">
                        <i class="mdi mdi-account-outline"></i>
                        <span>
                            KYC & Personal
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="education">
                        <i class="mdi mdi-school-outline"></i>
                        <span>
                            Education Details
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="experience">
                        <i class="mdi mdi-briefcase-outline"></i>
                        <span>
                            Work Experience
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="training">
                        <i class="mdi mdi-certificate-outline"></i>
                        <span>
                            Training Induction
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="references">
                        <i class="mdi mdi-shield-check-outline"></i>
                        <span>
                            Ref Checks
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="interview">
                        <i class="mdi mdi-file-sign"></i>
                        <span>
                            Interview Notes
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="family"> <i
                            class="mdi mdi-account-group-outline"></i>
                        <span>
                            Family & Dependents
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="remuneration">
                        <i class="mdi mdi-credit-card-outline"></i>
                        <span>
                            Remuneration
                        </span>
                    </button>
                    <button type="button" class="employee-tab" data-tab="documents">
                        <i class="mdi mdi-file-document-outline"></i>
                        <span>
                            Employee Files
                        </span>
                    </button>
                </div>
            </div>

            {{--  RIGHT CONTENT --}}
            <div class="employee-content flex-grow-1" style="overflow-y:auto;">
                {{--  PERSONAL / KYC --}}
                <div class="employee-panel p-4" data-panel="personal">
                    <div class="employee-section-title">
                        <i class="mdi mdi-account-outline me-1"></i>
                        Personal Profile & KYC
                    </div>
                    <div class="employee-card">
                        <div class="row g-4">
                            {{-- Full Name --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Full Name
                                </span>
                                <span class="employee-value">
                                    Madhavan Krishnan
                                </span>
                            </div>
                            {{-- Email --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Email
                                </span>
                                <span class="employee-value">
                                    madhavan@example.com
                                </span>
                            </div>

                            {{-- Phone --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Phone
                                </span>
                                <span class="employee-value">
                                    +91 98765 43210
                                </span>
                            </div>
                            {{-- DOB --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Date of Birth
                                </span>
                                <span class="employee-value">
                                    15 Aug 1990
                                </span>
                            </div>
                            {{-- Gender --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Gender
                                </span>
                                <span class="employee-value">
                                    Male
                                </span>
                            </div>

                            {{-- Nationality --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Nationality
                                </span>
                                <span class="employee-value">
                                    Indian
                                </span>
                            </div>

                            {{-- Marital Status --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Marital Status
                                </span>
                                <span class="employee-value">
                                    Married
                                </span>
                            </div>
                            {{-- Aadhaar --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    Aadhaar
                                </span>
                                <span class="employee-value">
                                    XXXX XXXX 4521
                                </span>
                            </div>
                            {{-- PAN --}}
                            <div class="col-md-6">
                                <span class="employee-label">
                                    PAN
                                </span>
                                <span class="employee-value">
                                    ABCDE1234F
                                </span>
                            </div>
                            {{-- Address --}}
                            <div class="col-12">
                                <span class="employee-label">
                                    Address
                                </span>
                                <span class="employee-value">
                                    Chennai, Tamil Nadu
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- EDUCATION --}}
                <div class="employee-panel p-4 d-none" data-panel="education">
                    <div class="employee-section-title">
                        <i class="mdi mdi-school-outline me-1"></i>
                        Education Details
                    </div>
                    {{-- B.E --}}
                    <div class="employee-card education-card mb-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="row g-4 flex-grow-1">
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Qualification
                                    </span>
                                    <span class="employee-value">
                                        B.E. Civil Engineering
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Institution
                                    </span>
                                    <span class="employee-value">
                                        Anna University (CEG Campus), Chennai
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Passing Year
                                    </span>
                                    <span class="employee-value">
                                        2000
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Grade
                                    </span>
                                    <span class="employee-value">
                                        84%
                                    </span>
                                </div>
                            </div>
                            {{-- DELETE --}}
                            <button type="button" class="education-delete-btn" title="Delete Education">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>
                        </div>
                    </div>

                    {{-- M.Tech --}}
                    <div class="employee-card education-card mb-3">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="row g-4 flex-grow-1">
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Qualification
                                    </span>
                                    <span class="employee-value">
                                        M.Tech Construction Management
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Institution
                                    </span>
                                    <span class="employee-value">
                                        Indian Institute of Technology (IIT) Madras
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Passing Year
                                    </span>
                                    <span class="employee-value">
                                        2002
                                    </span>
                                </div>
                                <div class="col-md-6">
                                    <span class="employee-label">
                                        Grade
                                    </span>
                                    <span class="employee-value">
                                        9.2 CGPA
                                    </span>
                                </div>
                            </div>


                            {{-- DELETE --}}
                            <button type="button" class="education-delete-btn" title="Delete Education">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>
                        </div>
                    </div>


                    <div class="education-add-box">
                        <div class="education-add-title mb-3">
                            ADD EDUCATION
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control education-input" placeholder="Qualification">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control education-input" placeholder="Institution">
                            </div>
                            <div class="col-md-6">
                                <input type="number" class="form-control education-input" placeholder="Passing Year">
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control education-input"
                                    placeholder="Grade / Percentage / CGPA">
                            </div>
                            <div class="col-12">
                                <button type="button" class="btn education-add-btn">
                                    <i class="mdi mdi-plus me-1"></i>
                                    Append Education
                                </button>
                            </div>
                        </div>
                    </div>
                </div>


                {{-- WORK EXPERIENCE PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="experience">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-briefcase-outline me-2 fs-5"></i>
                        Work Experience
                    </div>

                    {{-- Container for All Experience Cards --}}
                    <div id="experienceContainer">

                        {{-- Experience Item 1 --}}
                        <div class="card mb-3 p-3 position-relative experience-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-exp-btn py-0 px-1"
                                title="Delete Experience" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="exp-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fw-bold exp-view-designation"
                                        style="font-size: 14px; color: #1e293b;">Site Engineer</span>
                                    <span class="badge rounded-1 exp-view-duration"
                                        style="background-color: #eff6ff; color: #2563eb; font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        2014 - 2018
                                    </span>
                                </div>
                                <div class="exp-view-company" style="font-size: 13px; color: #94a3b8; margin-top: 2px;">
                                    ABC Constructions
                                </div>
                                <div class="exp-view-roles mt-2"
                                    style="font-size: 13px; color: #64748b; line-height: 1.4;">
                                    Managed daily site operations, supervised workforce, and ensured quality control
                                    compliance.
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="exp-edit-mode d-none mt-2 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Designation</label>
                                        <input type="text" class="form-control form-control-sm exp-input-designation"
                                            style="font-size: 11px;" value="Site Engineer">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Company
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm exp-input-company"
                                            style="font-size: 11px;" value="ABC Constructions">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Duration</label>
                                        <input type="text" class="form-control form-control-sm exp-input-duration"
                                            style="font-size: 11px;" value="2014 - 2018" placeholder="e.g. 2014 - 2018">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Key Roles &
                                            Responsibilities</label>
                                        <textarea class="form-control form-control-sm exp-input-roles" rows="2"
                                            style="font-size: 11px;"
                                            placeholder="Describe key responsibilities...">Managed daily site operations, supervised workforce, and ensured quality control compliance.</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Experience Item 2 --}}
                        <div class="card mb-3 p-3 position-relative experience-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-exp-btn py-0 px-1"
                                title="Delete Experience" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            <div class="exp-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fw-bold exp-view-designation"
                                        style="font-size: 14px; color: #1e293b;">Senior Site Engineer</span>
                                    <span class="badge rounded-1 exp-view-duration"
                                        style="background-color: #eff6ff; color: #2563eb; font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        2018 - 2022
                                    </span>
                                </div>
                                <div class="exp-view-company" style="font-size: 13px; color: #94a3b8; margin-top: 2px;">
                                    XYZ Infrastructure
                                </div>
                                <div class="exp-view-roles mt-2"
                                    style="font-size: 13px; color: #64748b; line-height: 1.4;">
                                    Overseeing structural bridge construction and vendor management.
                                </div>
                            </div>

                            <div class="exp-edit-mode d-none mt-2 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Designation</label>
                                        <input type="text" class="form-control form-control-sm exp-input-designation"
                                            style="font-size: 11px;" value="Senior Site Engineer">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Company
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm exp-input-company"
                                            style="font-size: 11px;" value="XYZ Infrastructure">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Duration</label>
                                        <input type="text" class="form-control form-control-sm exp-input-duration"
                                            style="font-size: 11px;" value="2018 - 2022">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Key Roles &
                                            Responsibilities</label>
                                        <textarea class="form-control form-control-sm exp-input-roles" rows="2"
                                            style="font-size: 11px;">Overseeing structural bridge construction and vendor management.</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- TRAINING INDUCTION PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="training">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-certificate-outline me-2 fs-5"></i>
                        Training Induction
                    </div>

                    {{-- Container for All Training Cards --}}
                    <div id="trainingContainer">

                        {{-- Item 1 --}}
                        <div class="card mb-3 p-3 position-relative training-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-training-btn py-0 px-1"
                                title="Delete Training" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="training-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="fw-bold training-view-title"
                                            style="font-size: 14px; color: #1e293b;">Site Safety Induction</span>
                                        <small class="d-block text-muted mt-1 training-view-date"
                                            style="font-size: 12px; color: #94a3b8;">10 Jan 2024</small>
                                    </div>
                                    <span class="badge bg-success-subtle text-success training-view-status"
                                        style="font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        Completed
                                    </span>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="training-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Training
                                            Title</label>
                                        <input type="text" class="form-control form-control-sm training-input-title"
                                            style="font-size: 11px;" value="Site Safety Induction">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Completion
                                            Date</label>
                                        <input type="text" class="form-control form-control-sm training-input-date"
                                            style="font-size: 11px;" value="10 Jan 2024" placeholder="e.g. 10 Jan 2024">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Status</label>
                                        <select class="form-select form-select-sm training-input-status"
                                            style="font-size: 11px;">
                                            <option value="Completed" selected>Completed</option>
                                            <option value="Pending">Pending</option>
                                            <option value="In Progress">In Progress</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Item 2 --}}
                        <div class="card mb-3 p-3 position-relative training-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-training-btn py-0 px-1"
                                title="Delete Training" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            <div class="training-view-mode">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="fw-bold training-view-title"
                                            style="font-size: 14px; color: #1e293b;">Construction Safety</span>
                                        <small class="d-block text-muted mt-1 training-view-date"
                                            style="font-size: 12px; color: #94a3b8;">15 Mar 2024</small>
                                    </div>
                                    <span class="badge bg-success-subtle text-success training-view-status"
                                        style="font-weight: 500; font-size: 12px; padding: 4px 8px;">
                                        Completed
                                    </span>
                                </div>
                            </div>

                            <div class="training-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Training
                                            Title</label>
                                        <input type="text" class="form-control form-control-sm training-input-title"
                                            style="font-size: 11px;" value="Construction Safety">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Completion
                                            Date</label>
                                        <input type="text" class="form-control form-control-sm training-input-date"
                                            style="font-size: 11px;" value="15 Mar 2024">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Status</label>
                                        <select class="form-select form-select-sm training-input-status"
                                            style="font-size: 11px;">
                                            <option value="Completed" selected>Completed</option>
                                            <option value="Pending">Pending</option>
                                            <option value="In Progress">In Progress</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- REFERENCE CHECKS PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="references">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-shield-check-outline me-2 fs-5"></i>
                        Reference Checks
                    </div>

                    {{-- Container for All Reference Cards --}}
                    <div id="referenceContainer">

                        {{-- Reference Item 1 --}}
                        <div class="card mb-3 p-3 position-relative reference-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-ref-btn py-0 px-1"
                                title="Delete Reference" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="ref-view-mode">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fw-bold ref-view-name"
                                            style="font-size: 14px; color: #1e293b;">Rajesh Kumar</span>
                                        <span class="badge bg-success-subtle text-success ref-view-status"
                                            style="font-weight: 600; font-size: 10px; padding: 3px 6px;">
                                            VERIFIED
                                        </span>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center gap-3 text-secondary"
                                    style="font-size: 13px; color: #64748b;">
                                    <div>
                                        <small class="text-muted">Designation:</small>
                                        <span class="ref-view-designation fw-medium" style="color: #334155;">Project
                                            Manager</span>
                                    </div>
                                    <span style="border-right: 1px solid #cbd5e1; height: 12px;"></span>
                                    <div>
                                        <small class="text-muted">Phone:</small>
                                        <span class="ref-view-phone fw-medium" style="color: #334155;">+91 98765
                                            12345</span>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="ref-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm ref-input-name"
                                            style="font-size: 11px;" value="Rajesh Kumar">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Verification
                                            Status</label>
                                        <select class="form-select form-select-sm ref-input-status"
                                            style="font-size: 11px;">
                                            <option value="VERIFIED" selected>VERIFIED</option>
                                            <option value="PENDING">PENDING</option>
                                            <option value="UNVERIFIED">UNVERIFIED</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Designation</label>
                                        <input type="text" class="form-control form-control-sm ref-input-designation"
                                            style="font-size: 11px;" value="Project Manager">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Phone
                                            Number</label>
                                        <input type="text" class="form-control form-control-sm ref-input-phone"
                                            style="font-size: 11px;" value="+91 98765 12345">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- INTERVIEW LOGS & ASSESSMENT PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="interview">
                    {{-- Section Title --}}
                    <div class="d-flex align-items-center mb-3 text-secondary fw-semibold"
                        style="font-size: 15px; color: #475569;">
                        <i class="mdi mdi-file-sign me-2 fs-5"></i>
                        Recruiter Interview Logs & Assessment Comments
                    </div>

                    {{-- Container for All Interview Log Cards --}}
                    <div id="interviewContainer">

                        {{-- Interview Item 1 --}}
                        <div class="card mb-3 p-3 position-relative interview-item bg-white"
                            style="border: 1px solid #1e293b; border-radius: 8px;">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-interview-btn py-0 px-1"
                                title="Delete Interview Log" style="font-size: 11px;">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="interview-view-mode">
                                <div class="row g-3">
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">Screening
                                            Recruiter</small>
                                        <span class="fw-semibold interview-view-recruiter"
                                            style="font-size: 13px; color: #1e293b;">Suresh Kumar</span>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">Evaluation
                                            Date</small>
                                        <span class="fw-medium interview-view-date"
                                            style="font-size: 13px; color: #334155;">12 Dec 2023</span>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">Rating</small>
                                        <span class="fw-medium interview-view-rating"
                                            style="font-size: 13px; color: #334155;">4.5 / 5</span>
                                    </div>
                                    <div class="col-md-3">
                                        <small class="text-muted d-block" style="font-size: 11px;">HR Decision
                                            Verdict</small>
                                        <span class="badge bg-success-subtle text-success interview-view-verdict"
                                            style="font-weight: 600; font-size: 11px; padding: 4px 8px;">
                                            Selected
                                        </span>
                                    </div>
                                    <div class="col-12 mt-2">
                                        <small class="text-muted d-block" style="font-size: 11px;">Comments</small>
                                        <p class="mb-0 interview-view-comments"
                                            style="font-size: 13px; color: #64748b; line-height: 1.4;">
                                            Strong technical knowledge and excellent site management skills.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="interview-edit-mode d-none mt-1 pe-4" style="font-size: 11px;">
                                <div class="row g-2">
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Screening
                                            Recruiter</label>
                                        <input type="text"
                                            class="form-control form-control-sm interview-input-recruiter"
                                            style="font-size: 11px;" value="Suresh Kumar">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Evaluation
                                            Date</label>
                                        <input type="text" class="form-control form-control-sm interview-input-date"
                                            style="font-size: 11px;" value="12 Dec 2023" placeholder="e.g. 12 Dec 2023">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Rating</label>
                                        <input type="text" class="form-control form-control-sm interview-input-rating"
                                            style="font-size: 11px;" value="4.5 / 5" placeholder="e.g. 4.5 / 5">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">HR Decision
                                            Verdict</label>
                                        <select class="form-select form-select-sm interview-input-verdict"
                                            style="font-size: 11px;">
                                            <option value="Selected" selected>Selected</option>
                                            <option value="On Hold">On Hold</option>
                                            <option value="Rejected">Rejected</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Assessment
                                            Comments</label>
                                        <textarea class="form-control form-control-sm interview-input-comments" rows="2"
                                            style="font-size: 11px;"
                                            placeholder="Enter assessment comments...">Strong technical knowledge and excellent site management skills.</textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- FAMILY & EMERGENCY CONTACTS PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="family">
                    {{-- Section Header --}}
                    <div class="employee-section-title mb-3">
                        <i class="mdi mdi-account-group-outline me-1"></i>
                        Family Members & Emergency Contacts Info
                    </div>

                    {{-- Container for Existing Family Members --}}
                    <div id="familyContainer">

                        {{-- Family Member 1 --}}
                        <div class="family-member-card mb-3 family-item position-relative">
                            {{-- Delete Button (Edit Mode Only) --}}
                            <button type="button"
                                class="family-delete-btn d-none position-absolute top-0 end-0 m-3 delete-family-btn"
                                title="Remove Family Member">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="family-view-mode">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <span class="family-member-name family-view-name">Sundari Sivakumar</span>
                                            <span class="family-relation-badge family-view-relation">SPOUSE</span>
                                        </div>
                                        <div class="family-member-details">
                                            <span>
                                                <small>Age:</small>
                                                <span class="family-view-age">44</span> Years
                                            </span>
                                            <span class="family-divider"></span>
                                            <span>
                                                <small>Occupation:</small>
                                                <span class="family-view-occupation">Homemaker</span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="family-edit-mode d-none pe-4">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm family-input-name"
                                            style="font-size: 11px;" value="Sundari Sivakumar">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Relation</label>
                                        <input type="text" class="form-control form-control-sm family-input-relation"
                                            style="font-size: 11px;" value="SPOUSE">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Age</label>
                                        <input type="number" class="form-control form-control-sm family-input-age"
                                            style="font-size: 11px;" value="44">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Occupation</label>
                                        <input type="text" class="form-control form-control-sm family-input-occupation"
                                            style="font-size: 11px;" value="Homemaker">
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Family Member 2 --}}
                        <div class="family-member-card mb-4 family-item position-relative">
                            <button type="button"
                                class="family-delete-btn d-none position-absolute top-0 end-0 m-3 delete-family-btn"
                                title="Remove Family Member">
                                <i class="mdi mdi-trash-can-outline"></i>
                            </button>

                            {{-- VIEW MODE --}}
                            <div class="family-view-mode">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <span class="family-member-name family-view-name">Kavin Sivakumar</span>
                                            <span class="family-relation-badge family-view-relation">SON</span>
                                        </div>
                                        <div class="family-member-details">
                                            <span>
                                                <small>Age:</small>
                                                <span class="family-view-age">16</span> Years
                                            </span>
                                            <span class="family-divider"></span>
                                            <span>
                                                <small>Occupation:</small>
                                                <span class="family-view-occupation">Student</span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- EDIT MODE --}}
                            <div class="family-edit-mode d-none pe-4">
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full
                                            Name</label>
                                        <input type="text" class="form-control form-control-sm family-input-name"
                                            style="font-size: 11px;" value="Kavin Sivakumar">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Relation</label>
                                        <input type="text" class="form-control form-control-sm family-input-relation"
                                            style="font-size: 11px;" value="SON">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Age</label>
                                        <input type="number" class="form-control form-control-sm family-input-age"
                                            style="font-size: 11px;" value="16">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label text-muted mb-1"
                                            style="font-size: 11px;">Occupation</label>
                                        <input type="text" class="form-control form-control-sm family-input-occupation"
                                            style="font-size: 11px;" value="Student">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    {{-- ADD FAMILY MEMBER BOX (EDIT MODE ONLY) --}}
                    <div class="family-add-box d-none" id="familyAddBox">
                        <div class="family-add-title mb-3">
                            ADD FAMILY MEMBER / EMERGENCY CONTACT
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" id="newFamilyName" class="form-control family-input"
                                    placeholder="Full Name">
                            </div>
                            <div class="col-md-6">
                                <select id="newFamilyRelation" class="form-select family-input family-input-relation"><option value="">Select relation</option></select>
                            </div>
                            <div class="col-md-6">
                                <input type="number" id="newFamilyAge" class="form-control family-input"
                                    placeholder="Age">
                            </div>
                            <div class="col-md-6">
                                <input type="text" id="newFamilyOccupation" class="form-control family-input"
                                    placeholder="Occupation (e.g. Homemaker / Farmer)">
                            </div>
                            <div class="col-12">
                                <button type="button" class="btn family-add-btn" id="appendFamilyBtn">
                                    <i class="mdi mdi-plus me-1"></i>
                                    Append Family Member
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                {{--  REMUNERATION --}}
                <div class="employee-panel p-4 d-none" data-panel="remuneration">
                    <!-- Section Title -->
                    <div class="employee-section-title mb-4">
                        <i class="mdi mdi-credit-card-outline me-1"></i>
                        Compensation, Mapped Salary Structure & Statutory Remuneration
                    </div>
                    <!-- SUMMARY METRIC CARDS -->
                    <div class="row g-3 mb-4">
                        <!-- Net Monthly Take Home -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#ecfdf5; border:1px solid #d1fae5;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#047857;">
                                    Net Monthly Take-Home
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#047857;">
                                    Rs. 17,850
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#059669;">
                                    Component A - Component B
                                </small>

                            </div>
                        </div>


                        <!-- Gross Earnings -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#eff6ff; border:1px solid #dbeafe;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#16659E;">
                                    Gross Earnings (Comp A)
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#16659E;">
                                    Rs. 22,500
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#16659E;">
                                    Basic + HRA + Special
                                </small>

                            </div>
                        </div>


                        <!-- Deductions -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#fff1f2; border:1px solid #ffe4e6;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#be123c;">
                                    Deductions (Comp B)
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#be123c;">
                                    Rs. 4,650
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#e11d48;">
                                    PF + ESI + PT + TDS
                                </small>

                            </div>
                        </div>


                        <!-- Total CTC -->
                        <div class="col-6 col-md-3">
                            <div class="p-3 rounded-3 h-100" style="background:#eef2ff; border:1px solid #e0e7ff;">

                                <span class="d-block text-uppercase fw-bold"
                                    style="font-size:9px; letter-spacing:.6px; color:#0C3C62;">
                                    Total Monthly CTC
                                </span>

                                <div class="fw-bold font-monospace mt-1" style="font-size:15px; color:#0C3C62;">
                                    Rs. 25,850
                                </div>

                                <small class="d-block mt-1" style="font-size:8px; color:#4f46e5;">
                                    Comp A + Employer Share
                                </small>

                            </div>
                        </div>

                    </div>


                    <!-- MAPPED SALARY STRUCTURE LEDGER-->
                    <div class="p-3 p-md-4 rounded-3 mb-4" style="background:#f8fafc; border:1px solid #e2e8f0;">

                        <!-- Ledger Header -->
                        <div
                            class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-bottom pb-3 mb-3">

                            <div>
                                <h6 class="mb-1 fw-bold text-uppercase"
                                    style="font-size:11px; letter-spacing:.6px; color:#1e293b;">
                                    Mapped Salary Structure Ledger
                                </h6>

                                <small class="text-muted" style="font-size:10px;">
                                    Indian Labour Law 2026 Compliant Wage Component Breakdown
                                </small>
                            </div>

                            <span class="badge rounded-pill" style="font-size:9px; background:#dbeafe; color:#16659E;">
                                Staff Category
                            </span>

                        </div>


                        <div class="row g-3">

                            <!-- COMPONENT A - EARNINGS -->
                            <div class="col-12 col-md-4">
                                <div class="bg-white rounded-3 p-3 h-100" style="border:1px solid #e2e8f0;">

                                    <!-- Header -->
                                    <div
                                        class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">

                                        <span class="fw-bold text-uppercase" style="font-size:10px; color:#1e40af;">
                                            Component A • Earnings
                                        </span>

                                        <!-- Editable Total -->
                                        <div id="componentATotalView">
                                            <span class="fw-bold font-monospace text-nowrap"
                                                style="font-size:11px; color:#1e3a8a;">
                                                ₹ 22,500
                                            </span>
                                        </div>

                                        <div id="componentATotalEdit" class="d-none">
                                            <input type="number"
                                                class="form-control form-control-sm text-end fw-bold font-monospace p-0"
                                                value="22500" style="width:70px;font-size:11px;">
                                        </div>

                                    </div>

                                    <!-- Content -->
                                    <div class="small">

                                        <!-- Basic -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                Basic Pay + DA
                                            </span>

                                            <div id="basicView">
                                                <span class="fw-bold font-monospace text-dark text-nowrap">
                                                    ₹ 12,000
                                                </span>
                                            </div>

                                            <div id="basicEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="12000" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- HRA -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                HRA & Other Allowance
                                            </span>

                                            <div id="hraView">
                                                <span class="fw-bold font-monospace text-dark text-nowrap">
                                                    ₹ 6,000
                                                </span>
                                            </div>

                                            <div id="hraEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="6000" style="width:70px;font-size:10px;">
                                            </div>
                                        </div>
                                        <!-- Special Allowance -->
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="text-dark" style="font-size:10px;">
                                                Special Allowance
                                            </span>
                                            <div id="specialView">
                                                <span class="fw-bold font-monospace text-dark text-nowrap">
                                                    ₹ 4,500
                                                </span>
                                            </div>
                                            <div id="specialEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="4500" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>


                            <!-- COMPONENT B - DEDUCTIONS -->
                            <div class="col-12 col-md-4">
                                <div class="bg-white rounded-3 p-3 h-100" style="border:1px solid #e2e8f0;">
                                    <!-- Header -->
                                    <div
                                        class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">
                                        <span class="fw-bold text-uppercase" style="font-size:10px;color:#9f1239;">
                                            Component B • Deductions
                                        </span>
                                        <div id="componentBTotalView">
                                            <span class="fw-bold font-monospace text-nowrap"
                                                style="font-size:11px;color:#9f1239;">
                                                ₹ 4,650
                                            </span>
                                        </div>
                                        <div id="componentBTotalEdit" class="d-none">
                                            <input type="number"
                                                class="form-control form-control-sm text-end fw-bold font-monospace"
                                                value="4650" style="width:70px;font-size:11px;">
                                        </div>
                                    </div>

                                    <div class="small">

                                        <!-- EPF -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                EPF Employee (12%)
                                            </span>

                                            <div id="epfEmployeeView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 1,440
                                                </span>
                                            </div>

                                            <div id="epfEmployeeEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="1440" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- ESI -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-dark" style="font-size:10px;">
                                                ESI Employee (0.75%)
                                            </span>
                                            <div id="esiEmployeeView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 169
                                                </span>
                                            </div>
                                            <div id="esiEmployeeEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="169" style="width:70px;font-size:10px;">
                                            </div>
                                        </div>

                                        <!-- PT -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-dark" style="font-size:10px;">
                                                Professional Tax (PT)
                                            </span>
                                            <div id="ptView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 200
                                                </span>
                                            </div>
                                            <div id="ptEdit" class="d-none ">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace "
                                                    value="200" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- TDS -->
                                        <div class="d-flex justify-content-between align-items-center">

                                            <span class="text-dark" style="font-size:10px;">
                                                Income Tax / TDS
                                            </span>

                                            <div id="tdsView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#e11d48;">
                                                    ₹ 2,841
                                                </span>
                                            </div>

                                            <div id="tdsEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="2841" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>


                            <!-- COMPONENT C - EMPLOYER SHARE -->
                            <div class="col-12 col-md-4">
                                <div class="bg-white rounded-3 p-3 h-100" style="border:1px solid #e2e8f0;">

                                    <!-- Header -->
                                    <div
                                        class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">
                                        <span class="fw-bold text-uppercase" style="font-size:10px;color:#3730a3;">
                                            Component C • Employer Share
                                        </span>
                                        <div id="componentCTotalView">
                                            <span class="fw-bold font-monospace text-nowrap"
                                                style="font-size:11px;color:#312e81;">
                                                ₹ 3,350
                                            </span>
                                        </div>
                                        <div id="componentCTotalEdit" class="d-none">
                                            <input type="number"
                                                class="form-control form-control-sm text-end fw-bold font-monospace"
                                                value="3350" style="width:70px;font-size:11px;">
                                        </div>
                                    </div>

                                    <div class="small">
                                        <!-- EPF Employer -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="text-dark" style="font-size:10px;">
                                                EPF Employer (12%)
                                            </span>
                                            <div id="epfEmployerView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#4338ca;">
                                                    ₹ 1,440
                                                </span>
                                            </div>

                                            <div id="epfEmployerEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="1440" style="width:70px;;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- ESI Employer -->
                                        <div class="d-flex justify-content-between align-items-center mb-2">

                                            <span class="text-dark" style="font-size:10px;">
                                                ESI Employer (3.25%)
                                            </span>

                                            <div id="esiEmployerView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#4338ca;">
                                                    ₹ 731
                                                </span>
                                            </div>

                                            <div id="esiEmployerEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="731" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                        <!-- Gratuity -->
                                        <div class="d-flex justify-content-between align-items-center">

                                            <span class="text-dark" style="font-size:10px;">
                                                Gratuity & LWF
                                            </span>

                                            <div id="gratuityView">
                                                <span class="fw-bold font-monospace text-nowrap" style="color:#4338ca;">
                                                    ₹ 1,179
                                                </span>
                                            </div>

                                            <div id="gratuityEdit" class="d-none">
                                                <input type="number"
                                                    class="form-control form-control-sm text-end font-monospace"
                                                    value="1179" style="width:70px;font-size:10px;">
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>



                        <!--STATUTORY & BANKING DETAILS-->
                        <div class="border-top pt-4 mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <i class="mdi mdi-bank-outline me-2" style="font-size:18px; color:#16659E;"></i>
                                <h6 class="mb-0 fw-bold text-uppercase" style="font-size:11px; letter-spacing:.6px;">
                                    Statutory & Banking Registration Details
                                </h6>
                            </div>

                            <div class="row g-3">

                                <!-- Base Daily Wage -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Base Month Rate
                                    </label>
                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        Rs. 13,500/ month rate
                                    </div>

                                </div>
                                <!-- Special Allowance -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Special Monthly Allowance
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        Rs. 4,500 / month
                                    </div>

                                </div>


                                <!-- EPF / UAN -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        EPF / UAN Account Number
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        TN/MAS/87410/001
                                    </div>

                                </div>


                                <!-- ESI -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        ESI (State Insurance) Code
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        33-89745-12
                                    </div>

                                </div>


                                <!-- Bank -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Bank Partner Name
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2">
                                        State Bank of India
                                    </div>

                                </div>


                                <!-- Account / IFSC -->
                                <div class="col-12 col-md-6">

                                    <label class="employee-label">
                                        Bank Account Number / IFSC Code
                                    </label>

                                    <div class="employee-value bg-light rounded-2 border p-2 font-monospace">
                                        AC: 30456123456
                                        <span class="text-muted mx-1">•</span>
                                        SBIN0000845
                                    </div>

                                </div>

                            </div>

                        </div>


                        <!--   PROMOTION & APPRAISAL CAREER HISTORY  -->
                        <div class="p-3 p-md-4 rounded-3" style="background:#f8fafc; border:1px solid #e2e8f0;">
                            <!-- Header -->
                            <div
                                class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-bottom pb-3 mb-3">
                                <div>
                                    <h6 class="mb-1 fw-bold text-uppercase d-flex align-items-center"
                                        style="font-size:11px; letter-spacing:.6px; color:#1e293b;">
                                        <i class="mdi mdi-trending-up me-1" style="font-size:17px; color:#059669;"></i>
                                        Promotion & Appraisal Career History
                                    </h6>
                                    <small class="text-muted" style="font-size:10px;">
                                        Historical Wage Revisions, Designations, and Performance Appraisals Mapped to
                                        Profile
                                    </small>
                                </div>
                                <span class="badge rounded-pill d-flex align-items-center gap-1"
                                    style="font-size:9px; background:#d1fae5; color:#065f46;">
                                    <i class="mdi mdi-auto-fix"></i>
                                    3 Records Mapped
                                </span>
                            </div>


                            <!--  PROMOTION RECORD 1   -->
                            <div
                                class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-bottom pb-2 mb-3">

                                <div class="d-flex flex-wrap align-items-center gap-2">

                                    <span class="badge" style="font-size:9px; background:#f3e8ff; color:#7e22ce;">
                                        Promotion
                                    </span>

                                    <span class="text-muted font-monospace" style="font-size:10px;">
                                        Effective: 01 Jan 2025 (January)
                                    </span>

                                </div>


                                <div class="d-flex align-items-center gap-2">
                                    <span class="badge" style="font-size:9px; background:#fffbeb; color:#b45309;">
                                        <i class="mdi mdi-star me-1"></i>
                                        4.8 / 5
                                    </span>
                                    <span class="badge" style="font-size:9px; background:#eff6ff; color:#1d4ed8;">
                                        Approved
                                    </span>

                                </div>

                            </div>


                            <div class="row g-3">

                                <!-- Designation -->
                                <div class="col-12 col-md-4">

                                    <div class="p-2 rounded-2" style="background:#f8fafc; border:1px solid #e2e8f0;">

                                        <span class="d-block text-uppercase fw-bold text-muted mb-1"
                                            style="font-size:9px;">
                                            Designation / Role Shift
                                        </span>

                                        <div class="d-flex align-items-center gap-2">

                                            <span class="text-muted text-decoration-line-through"
                                                style="font-size:10px;">
                                                Site Engineer
                                            </span>

                                            <i class="mdi mdi-arrow-right" style="color:#059669;"></i>

                                            <span class="fw-bold" style="font-size:11px; color:#065f46;">
                                                Senior Site Engineer
                                            </span>

                                        </div>

                                    </div>

                                </div>


                                <!-- Basic Revision -->
                                <div class="col-12 col-md-4">

                                    <div class="p-2 rounded-2" style="background:#f8fafc; border:1px solid #e2e8f0;">

                                        <span class="d-block text-uppercase fw-bold text-muted mb-1"
                                            style="font-size:9px;">
                                            Base Pay Revision
                                        </span>

                                        <div class="d-flex align-items-center flex-wrap gap-2">

                                            <span class="text-muted text-decoration-line-through font-monospace"
                                                style="font-size:10px;">
                                                Rs. 10,000
                                            </span>

                                            <i class="mdi mdi-arrow-right" style="color:#059669;"></i>

                                            <span class="fw-bold font-monospace" style="font-size:11px; color:#047857;">
                                                Rs. 12,000
                                            </span>

                                            <span class="badge"
                                                style="font-size:8px; background:#d1fae5; color:#065f46;">
                                                +20%
                                            </span>

                                        </div>

                                    </div>

                                </div>


                                <!-- Gross Revision -->
                                <div class="col-12 col-md-4">

                                    <div class="p-2 rounded-2" style="background:#f8fafc; border:1px solid #e2e8f0;">

                                        <span class="d-block text-uppercase fw-bold text-muted mb-1"
                                            style="font-size:9px;">
                                            Gross Monthly Revision
                                        </span>

                                        <div class="d-flex align-items-center flex-wrap gap-2">

                                            <span class="text-muted text-decoration-line-through font-monospace"
                                                style="font-size:10px;">
                                                Rs. 19,000
                                            </span>

                                            <i class="mdi mdi-arrow-right" style="color:#059669;"></i>

                                            <span class="fw-bold font-monospace" style="font-size:11px; color:#065f46;">
                                                Rs. 22,500
                                            </span>

                                            <span class="text-success font-monospace fw-bold" style="font-size:10px;">
                                                (+Rs. 3,500)
                                            </span>

                                        </div>

                                    </div>

                                </div>

                            </div>


                            <!-- Remarks -->
                            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3 p-2 rounded-2"
                                style="background:#f8fafc; border:1px solid #e2e8f0;">

                                <div style="font-size:11px; color:#475569;">

                                    <span class="fw-bold text-dark">
                                        Remarks:
                                    </span>

                                    Promoted based on excellent project performance.

                                    <small class="d-block text-muted mt-1">
                                        Approved By: Suresh Kumar - Project Manager
                                    </small>

                                </div>


                                <div class="d-flex align-items-center gap-2">

                                    <span class="badge font-monospace"
                                        style="font-size:9px; background:#e2e8f0; color:#334155;">
                                        Ref: APP-2025-001
                                    </span>

                                    <button type="button" class="btn btn-sm text-white d-flex align-items-center gap-1"
                                        style="
                            background:#16659E;
                            font-size:10px;
                            font-weight:700;
                            border-radius:6px;
                        ">

                                        <i class="mdi mdi-download-outline"></i>
                                        Letter
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- COMPLIANCE & DOCUMENTS PANEL --}}
                <div class="employee-panel p-4 d-none" data-panel="documents">
                    {{-- Section Header --}}
                    <div class="employee-section-title mb-3">
                        <i class="mdi mdi-file-document-outline me-1"></i>
                        Compliance Folders & Verified Documents
                    </div>

                    {{-- Documents Grid --}}
                    <div class="documents-grid" id="documentsGrid">

                        {{-- Document Card 1: Aadhaar --}}
                        <div
                            class="document-card mb-3 p-3 border rounded d-flex align-items-center justify-content-between">
                            <div class="document-info d-flex align-items-center gap-3">
                                <div class="document-icon text-primary fs-3">
                                    <i class="mdi mdi-file-document-outline"></i>
                                </div>
                                <div class="document-details">
                                    <div class="document-name fw-semibold" style="font-size: 13px;">
                                        Aadhaar_Card_Sivakumar.pdf
                                    </div>
                                    <div class="document-meta text-muted" style="font-size: 11px;">
                                        Aadhaar
                                        <span class="document-meta-divider mx-1">•</span>
                                        1.2 MB
                                    </div>
                                </div>
                            </div>
                            <div class="document-actions d-flex align-items-center gap-2">
                                <span class="document-status badge bg-success-subtle text-success px-2 py-1"
                                    style="font-size: 10px;">
                                    Verified
                                </span>
                                {{-- Hidden by default; visible only in Edit mode --}}
                                <button type="button"
                                    class="btn btn-sm btn-link text-danger p-0 document-delete-btn d-none"
                                    title="Remove Document">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                            </div>
                        </div>

                        {{-- Document Card 2: PAN --}}
                        <div
                            class="document-card mb-3 p-3 border rounded d-flex align-items-center justify-content-between">
                            <div class="document-info d-flex align-items-center gap-3">
                                <div class="document-icon text-primary fs-3">
                                    <i class="mdi mdi-file-document-outline"></i>
                                </div>
                                <div class="document-details">
                                    <div class="document-name fw-semibold" style="font-size: 13px;">
                                        PAN_Card_Sivakumar.pdf
                                    </div>
                                    <div class="document-meta text-muted" style="font-size: 11px;">
                                        PAN
                                        <span class="document-meta-divider mx-1">•</span>
                                        980 KB
                                    </div>
                                </div>
                            </div>
                            <div class="document-actions d-flex align-items-center gap-2">
                                <span class="document-status badge bg-success-subtle text-success px-2 py-1"
                                    style="font-size: 10px;">
                                    Verified
                                </span>
                                <button type="button"
                                    class="btn btn-sm btn-link text-danger p-0 document-delete-btn d-none"
                                    title="Remove Document">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                            </div>
                        </div>

                        {{-- Document Card 3: Experience --}}
                        <div
                            class="document-card mb-4 p-3 border rounded d-flex align-items-center justify-content-between">
                            <div class="document-info d-flex align-items-center gap-3">
                                <div class="document-icon text-primary fs-3">
                                    <i class="mdi mdi-file-document-outline"></i>
                                </div>
                                <div class="document-details">
                                    <div class="document-name fw-semibold" style="font-size: 13px;">
                                        IT_Experience_Certificate.pdf
                                    </div>
                                    <div class="document-meta text-muted" style="font-size: 11px;">
                                        Experience
                                        <span class="document-meta-divider mx-1">•</span>
                                        1.8 MB
                                    </div>
                                </div>
                            </div>
                            <div class="document-actions d-flex align-items-center gap-2">
                                <span class="document-status badge bg-success-subtle text-success px-2 py-1"
                                    style="font-size: 10px;">
                                    Verified
                                </span>
                                <button type="button"
                                    class="btn btn-sm btn-link text-danger p-0 document-delete-btn d-none"
                                    title="Remove Document">
                                    <i class="mdi mdi-trash-can-outline fs-5"></i>
                                </button>
                            </div>
                        </div>

                    </div>

                    {{-- UPLOAD SUPPORTING DOCUMENT BOX --}}
                    <div class="document-upload-box p-3 border rounded bg-light d-none" id="documentUploadBox">
                        <div class="document-upload-title font-monospace text-uppercase fw-bold text-muted mb-3"
                            style="font-size: 11px; letter-spacing: 0.5px;">
                            UPLOAD SUPPORTING DOCUMENT
                        </div>

                        <div class="d-flex flex-column flex-md-row align-items-stretch align-items-md-center gap-2">
                            {{-- Document Type Dropdown --}}
                            <div style="flex: 1; min-width: 160px;">
                                <select id="documentType" class="form-select form-select-sm w-100"
                                    style="font-size: 12px; height: 38px;">
                                    <option value="KYC Document">KYC Document</option>
                                    <option value="Experience">Experience Certificate</option>
                                    <option value="Education">Education Certificate</option>
                                    <option value="Other Certificate" selected>Other Certificate</option>
                                </select>
                            </div>

                            {{-- Select File Button --}}
                            <div style="flex: 1.5; min-width: 150px;">
                                <input type="file" id="documentFileInput" class="d-none"
                                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                                <button type="button" id="triggerFileSelectBtn"
                                    class="btn btn-sm btn-outline-secondary w-100 d-flex align-items-center justify-content-center text-truncate px-3"
                                    style="font-size: 12px; height: 38px;">
                                    <i class="mdi mdi-paperclip me-1 fs-6"></i>
                                    <span class="text-truncate">Select File...</span>
                                </button>
                            </div>

                            {{-- Upload Action Button --}}
                            <div style="flex: 0 0 auto;">
                                <button type="button" id="documentUploadBtn"
                                    class="btn btn-sm btn-primary w-100 d-flex align-items-center justify-content-center text-nowrap px-3"
                                    style="font-size: 12px; height: 38px;">
                                    <i class="mdi mdi-cloud-upload-outline me-1 fs-6"></i> Upload Document
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


<!-- Wages Modal -->
<div class="modal fade modal-blur" id="wagesModal" tabindex="-1" aria-labelledby="wagesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content  m-1 ">
            
            <!-- Header -->
            <div class="modal-header bg-primary border-bottom p-3">
                <h5 class="modal-title fw-bold text-white d-flex align-items-center gap-2" id="wagesModalLabel">
                    <i class="mdi mdi-account-hard-hat text-white fs-3"></i> 
                    Salary Structure & Wages
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Body -->
            <div class="modal-body p-4">
                
                <!-- New staff profile context (all values come from the Add Staff form). -->
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center text-primary p-3 mb-3">
                    <div class="d-flex align-items-center gap-3">
                        <div id="wagesEmployeeInitials" class="bg-primary rounded-circle d-flex justify-content-center align-items-center text-white fw-bold fs-4" style="width: 50px; height: 50px;">NS</div>
                        <div>
                            <h5 id="wagesEmployeeName" class="mb-0 fw-bold">New staff member</h5>
                            <div id="wagesEmployeeMeta" class="small text-primary-100">Configure the structure before saving staff.</div>
                        </div>
                    </div>
                    <div class="text-md-end mt-3 mt-md-0">
                        <small class="text-primary-50 d-block">Total Cost to Company (CTC)</small>
                        <h4 id="wagesPreviewCtc" class="mb-0 fw-bold">₹0/month</h4>
                    </div>
                </div>

                <div id="wagesDraftNotice" class="alert alert-info py-2 small" role="status">
                    This is a draft for the new staff member. The structure is stored when you click Save Staff.
                </div>

                <!-- Employee Details Grid: only values available in the current Add Staff form. -->
                <div class="row g-3 mb-4 mx-1 p-4 pt-3 border rounded-3 bg-light small">
                    <div class="col-md-6"><strong>Department:</strong> <span id="wagesDepartment">Not selected</span></div>
                    <div class="col-md-6"><strong>Designation:</strong> <span id="wagesDesignation">Not selected</span></div>
                    <div class="col-md-6"><strong>Grade:</strong> <span id="wagesGrade">Not selected</span></div>
                    <div class="col-md-6"><strong>Date of Joining:</strong> <span id="wagesJoiningDate">Not selected</span></div>
                </div>

                <!-- Components are loaded from Settings > Remuneration Type. -->
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="fw-bold mb-0 text-dark"><i class="mdi mdi-calculator text-primary"></i> Salary Structure &amp; Wages Components</h6>
                    <span class="badge bg-secondary">Settings-driven</span>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold small text-muted" for="wagesTargetGross">Monthly Gross Salary (₹) <span class="text-danger">*</span></label>
                    <input id="wagesTargetGross" type="number" min="0" max="999999999" step="0.01" inputmode="decimal" class="form-control" value="" placeholder="Enter monthly gross salary" required>
                    <small class="text-muted">Enter gross salary only. Component A earnings, employee deductions and employer contributions are calculated from Payroll Configuration.</small>
                </div>

                <!-- Component A -->
                <div class="card mb-3 border-0 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                        <span class="fw-bold text-primary"><span class="badge bg-primary me-2">A</span> Component A - Employee Gross Earnings</span>
                        <span id="wagesTotalALabel" class="fw-bold text-success small">Total A: ₹0/month</span>
                    </div>
                    <div class="card-body p-3">
                        <div id="wagesComponentA" class="row g-3">
                            <div class="col-12"><div class="placeholder-glow"><span class="placeholder col-12"></span></div></div>
                        </div>
                    </div>
                </div>

                <!-- Component B (Deductions) -->
                <div class="card mb-3 border-0 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                        <span class="fw-bold text-danger"><span class="badge bg-danger me-2">B</span> Component B - Employee Share (Deductions)</span>
                        <span id="wagesTotalBLabel" class="fw-bold text-danger small">Total Deductions B: ₹0/month</span>
                    </div>
                    <div class="card-body p-3">
                        <div id="wagesComponentB" class="row g-3">
                            <div class="col-12"><div class="placeholder-glow"><span class="placeholder col-12"></span></div></div>
                        </div>
                    </div>
                </div>

                <!-- Net Take-Home -->
                <div class="bg-success bg-opacity-10 border border-success rounded-3 p-3 mb-3 d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="fw-bold text-success mb-0"><i class="mdi mdi-cash-multiple"></i> NET TAKE-HOME SALARY</h6>
                        <small class="text-muted">Component A - Component B</small>
                    </div>
                    <div class="text-end">
                        <h4 id="wagesNetTakeHome" class="fw-bold text-success mb-0">₹0/month</h4>
                        <small id="wagesNetDaily" class="text-muted">₹0/day (30-day estimate)</small>
                    </div>
                </div>

                <!-- Component C -->
                <div class="card mb-4 border-0 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center py-2">
                        <span class="fw-bold text-info"><span class="badge bg-info me-2">C</span> Component C - Employer Share (Contributions &amp; Benefits)</span>
                        <span id="wagesTotalCLabel" class="fw-bold text-info small">Total Employer Share C: ₹0/month</span>
                    </div>
                    <div class="card-body p-3">
                        <div id="wagesComponentC" class="row g-3">
                            <div class="col-12"><div class="placeholder-glow"><span class="placeholder col-12"></span></div></div>
                        </div>
                    </div>
                </div>

                <!-- Total CTC -->
                <div class="bg-primary text-white rounded-3 p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="fw-bold mb-0"><i class="mdi mdi-briefcase"></i> TOTAL COST TO COMPANY</h5>
                        <small class="text-white-50">CTC = Component A + Component C</small>
                    </div>
                    <h3 id="wagesTotalCtc" class="fw-bold mb-0">₹0/month</h3>
                </div>

            </div>

            <!-- Footer -->
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" id="wagesApplyStructureBtn" class="btn bg-primary text-white"><i class="mdi mdi-content-save me-1"></i> Apply Structure</button>
            </div>

        </div>
    </div>
</div>




<script>
document.addEventListener('DOMContentLoaded', function() {
    // Search and department filtering are handled server-side by the HR AJAX data source.
});

// Exit actions are handled by the delegated AJAX staff-table workflow below.

document.addEventListener('DOMContentLoaded', function () {
    const fileInput = document.getElementById('profilePhoto');
    const previewImg = document.getElementById('avatarImage');
    const removeBtn = document.getElementById('removeProfilePhotoBtn');
    const defaultImageSrc = "https://ui-avatars.com/api/?name=PAIGE&background=f8f9fa&color=0d6efd&size=100";

    if (fileInput) {
        fileInput.addEventListener('change', function (event) {
            const file = event.target.files[0];
            if (!file) return;

            if (file.size > 2 * 1024 * 1024) {
                toastr.error('File size exceeds 2 MB. Please upload a smaller image.');
                fileInput.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = function (e) {
                previewImg.src = e.target.result;
                removeBtn.classList.remove('d-none'); 
            };
            reader.readAsDataURL(file);
        });
    }

    if (removeBtn) {
        removeBtn.addEventListener('click', function () {
            fileInput.value = ''; 
            previewImg.src = defaultImageSrc; 
            removeBtn.classList.add('d-none'); 
        });
    }
});

// language selection
// document.addEventListener('DOMContentLoaded', function() {
//     const addLanguageBtn = document.getElementById('addLanguageBtn');
//     const saveLanguageBtn = document.getElementById('saveLanguageBtn');
//     const languageInputSection = document.getElementById('languageInputSection');
//     const languageInput = document.getElementById('languageSkills');
//     const languageTableWrapper = document.getElementById('languageTableWrapper');
//     const languageSkillsBody = document.getElementById('languageSkillsBody');
//     let languageIndex = 0;

//     // SHOW LANGUAGE INPUT
//     addLanguageBtn.addEventListener('click', function() {
//         languageInputSection.style.display = 'block';
//         languageInput.focus();
//     });

//     // ADD LANGUAGE
//     saveLanguageBtn.addEventListener('click', function() {

//         const language = languageInput.value.trim();
//         // Validation
//         if (!language) {
//             toastr.error('Please enter a language.');
//             languageInput.focus();
//             return;

//         }
//         // CHECK DUPLICATE LANGUAGE
//         const existingLanguages =
//             document.querySelectorAll('.language-row');
//         let alreadyExists = false;
//         existingLanguages.forEach(function(row) {
//             const existingLanguage =
//                 row.getAttribute('data-language');
//             if (
//                 existingLanguage &&
//                 existingLanguage.toLowerCase() === language.toLowerCase()
//             ) {
//                 alreadyExists = true;
//             }
//         });
//         if (alreadyExists) {
//             toastr.error(language + ' has already been added.');
//             languageInput.focus();
//             return;
//         }
//         // CREATE TABLE ROW
//         const row = document.createElement('tr');
//         row.classList.add('language-row');
//         row.setAttribute('data-language', language);

//         row.innerHTML = `
//             {{-- LANGUAGE --}}
//             <td>
//                 <span class="fw-semibold text-dark">
//                     ${language}
//                 </span>
//                 <input
//                     type="hidden"
//                     name="languages[${languageIndex}][language]"
//                     value="${language}"
//                 >
//             </td>
//             {{-- READ --}}
//             <td class="text-center">
//                 <div class="form-check d-flex justify-content-center mb-0">
//                     <input
//                         class="form-check-input"
//                         type="checkbox"
//                         name="languages[${languageIndex}][read]"
//                         value="1"
//                     >
//                 </div>
//             </td>
//             {{-- WRITE --}}
//             <td class="text-center">
//                 <div class="form-check d-flex justify-content-center mb-0">
//                     <input
//                         class="form-check-input"
//                         type="checkbox"
//                         name="languages[${languageIndex}][write]"
//                         value="1"
//                     >
//                 </div>
//             </td>
//             {{-- SPEAK --}}
//             <td class="text-center">
//                 <div class="form-check d-flex justify-content-center mb-0">
//                     <input
//                         class="form-check-input"
//                         type="checkbox"
//                         name="languages[${languageIndex}][speak]"
//                         value="1"
//                     >
//                 </div>
//             </td>

//             {{-- ACTION --}}
//             <td class="text-center">
//                 <button
//                     type="button"
//                     class="btn btn-sm btn-outline-danger remove-language"
//                     title="Remove Language"
//                 >
//                     <i class="mdi mdi-delete-outline"></i>
//                 </button>
//             </td>
//         `;

//         // Add row
//         languageSkillsBody.appendChild(row);
//         languageIndex++;

//         // Show table
//         languageTableWrapper.style.display = 'block';

//         // Clear input
//         languageInput.value = '';
//         languageInput.focus();
//     });

//     // REMOVE LANGUAGE
//     languageSkillsBody.addEventListener('click', function(e) {
//         const removeButton =
//             e.target.closest('.remove-language');
//         if (!removeButton) {
//             return;
//         }
//         const row =
//             removeButton.closest('.language-row');
//         if (row) {
//             row.remove();
//         }
//         // Hide table when no languages remain
//         const remainingRows =
//             languageSkillsBody.querySelectorAll('.language-row');
//         if (remainingRows.length === 0) {
//             languageTableWrapper.style.display = 'none';
//         }
//     });
// });

// Login checkbox
document.addEventListener('DOMContentLoaded', function() {

    const loginCheckbox = document.getElementById('isLoginRequired');
    const loginFields = document.getElementById('loginCredentialFields');

    const usernameInput = document.getElementById('loginUsername');
    const pinInput = document.getElementById('loginPin');

    const togglePinButton = document.getElementById('toggleLoginPin');
    const pinIcon = document.getElementById('loginPinIcon');


    // SHOW / HIDE LOGIN FIELDS
    loginCheckbox.addEventListener('change', function() {

        if (this.checked) {
            loginFields.classList.remove('d-none');
            usernameInput.required = true;
            pinInput.required = true;
        } else {
            loginFields.classList.add('d-none');
            usernameInput.required = false;
            pinInput.required = false;
            usernameInput.value = '';
            pinInput.value = '';
            // Reset PIN visibility
            pinInput.type = 'password';
            pinIcon.classList.remove('mdi-eye-off-outline');
            pinIcon.classList.add('mdi-eye-outline');
        }

    });

    // SHOW / HIDE PIN
    togglePinButton.addEventListener('click', function() {
        if (pinInput.type === 'password') {
            pinInput.type = 'text';
            pinIcon.classList.remove('mdi-eye-outline');
            pinIcon.classList.add('mdi-eye-off-outline');
        } else {
            pinInput.type = 'password';
            pinIcon.classList.remove('mdi-eye-off-outline');
            pinIcon.classList.add('mdi-eye-outline');
        }
    });
    // ALLOW ONLY NUMBERS IN PIN
    // pinInput.addEventListener('input', function() {

    //     this.value = this.value.replace(/\D/g, '');
    // });
});

document.addEventListener('DOMContentLoaded', function() {
    const drawerElement = document.getElementById('employeeDrawer');
    if (!drawerElement) {
        return;
    }
    const drawer = new bootstrap.Offcanvas(drawerElement);

    /* Employee Row Click */
    document.querySelectorAll('.employee-row .employee-click').forEach(cell => {
        cell.addEventListener('click', function(event) {
            // Prevent accidental drawer opening from dropdown/buttons
            if (
                event.target.closest('.dropdown') ||
                event.target.closest('button') ||
                event.target.closest('a')
            ) {
                return;
            }
            const row = this.closest('.employee-row');
            if (!row) {
                return;
            }

            /* Employee ID  */
            const employeeId = row.dataset.employeeId;
            console.log('Opening employee:', employeeId);
            /* Update drawer header from clicked row*/
            const name = row.querySelector('td:first-child .fw-semibold')?.textContent
                .trim();
            const designation = row.querySelector('td:nth-child(2) span')?.textContent
                .trim();
            const department = row.querySelector('td:nth-child(2) small')?.textContent
                .trim();
            document.getElementById('employeeDrawerName').textContent =
                name || '';
            document.getElementById('employeeDrawerDesignation').textContent =
                designation || '';
            document.getElementById('employeeDrawerDepartment').textContent =
                department || '';

            /* Always show Personal tab first */
            showEmployeeTab('personal');
            /* Open Drawer */
            drawer.show();
        });
    });


    /* Sidebar Tab Click  */
    document.querySelectorAll('.employee-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.dataset.tab;
            showEmployeeTab(tabName);
        });
    });

    /*  Show Employee Tab  */
    function showEmployeeTab(tabName) {
        // Remove active state
        document.querySelectorAll('.employee-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        // Add active state
        const activeTab = document.querySelector(
            `.employee-tab[data-tab="${tabName}"]`
        );
        if (activeTab) {
            activeTab.classList.add('active');
        }
        // Hide all panels
        document.querySelectorAll('.employee-panel').forEach(panel => {
            panel.classList.add('d-none');
        });
        // Show selected panel
        const selectedPanel = document.querySelector(
            `.employee-panel[data-panel="${tabName}"]`
        );
        if (selectedPanel) {
            selectedPanel.classList.remove('d-none');
        }
    }
});

// Drawer editable
document.addEventListener('DOMContentLoaded', function() {
    const drawer = document.getElementById('employeeDrawer');
    const editBtn = document.getElementById('employeeEditBtn');
    const editText = document.getElementById('employeeEditText');
    const editIcon = document.getElementById('employeeEditIcon');
    let isEditing = false;
    /* Start / Stop Editing  */
    editBtn.addEventListener('click', function() {
        if (!isEditing) {
            enableEmployeeEditing();
        } else {
            saveEmployeeEditing();
        }
    });
    /* ENABLE EDIT MODE  */
    function enableEmployeeEditing() {
        isEditing = true;
        drawer.classList.add('employee-editing');
        editText.textContent = 'Save';
        editIcon.classList.remove('mdi-pencil-outline');
        editIcon.classList.add('mdi-content-save-outline');
        editBtn.classList.add('is-saving');

        /*  Convert employee values to inputs */
        drawer.querySelectorAll('.employee-value').forEach(function(element) {
            // Prevent converting the same element twice
            if (element.dataset.editing === 'true') {
                return;
            }
            const value = element.textContent.trim();
            element.dataset.originalValue = value;
            element.dataset.editing = 'true';

            /*  Interview comments / long text */
            if (
                element.tagName.toLowerCase() === 'p' ||
                value.length > 100
            ) {
                const textarea = document.createElement('textarea');
                textarea.className = 'employee-edit-input';
                textarea.value = value;
                element.innerHTML = '';
                element.appendChild(textarea);
            }
            /*  Normal fields   */
            else {
                const input = document.createElement('input');
                input.type = 'text';
                input.className = 'employee-edit-input';
                input.value = value;
                element.innerHTML = '';
                element.appendChild(input);
            }
        });

        /* Convert header employee information to inputs    */
        convertHeaderFields();
    }
    /* SAVE / EXIT EDIT MODE  */
    function saveEmployeeEditing() {
        /* Employee fields */
        drawer.querySelectorAll('.employee-value').forEach(function(element) {
            const input = element.querySelector(
                '.employee-edit-input'
            );
            if (!input) {
                return;
            }
            const value = input.value.trim();
            element.textContent = value;
            element.dataset.editing = 'false';
        });

        /* Header fields    */
        const header = drawer.querySelector('.offcanvas-header');
        const nameElement = header.querySelector('h5');
        if (nameElement) {
            const input = nameElement.querySelector(
                '.employee-edit-input'
            );
            if (input) {
                nameElement.textContent = input.value.trim();
            }
            nameElement.dataset.editing = 'false';
        }

        header.querySelectorAll(
            '.d-flex.flex-column > span'
        ).forEach(function(span) {
            const input = span.querySelector(
                '.employee-edit-input'
            );
            if (input) {
                span.textContent = input.value.trim();
            }
            span.dataset.editing = 'false';
        });


        /* Change button back to Edit */
        isEditing = false;
        drawer.classList.remove('employee-editing');
        editText.textContent = 'Edit';
        editIcon.classList.remove('mdi-content-save-outline');
        editIcon.classList.add('mdi-pencil-outline');
        editBtn.classList.remove('is-saving');
    }

    /* Reset edit mode when drawer closes */

    drawer.addEventListener('hidden.bs.offcanvas', function() {
        if (isEditing) {
            cancelEditing();
        }
    });

    /* Cancel Editing  */
    function cancelEditing() {
        drawer.querySelectorAll('.employee-value').forEach(function(element) {
            const originalValue =
                element.dataset.originalValue;

            if (originalValue !== undefined) {
                element.textContent = originalValue;
            }
            element.dataset.editing = 'false';
        });
        const header = drawer.querySelector('.offcanvas-header');
        const nameElement = header.querySelector('h5');
        if (nameElement) {
            const originalValue =
                nameElement.dataset.originalValue;
            if (originalValue !== undefined) {
                nameElement.textContent = originalValue;
            }
            nameElement.dataset.editing = 'false';
        }

        header.querySelectorAll(
            '.d-flex.flex-column > span'
        ).forEach(function(span) {
            const originalValue =
                span.dataset.originalValue;
            if (originalValue !== undefined) {
                span.textContent = originalValue;
            }
            span.dataset.editing = 'false';
        });
        isEditing = false;
        drawer.classList.remove('employee-editing');
        editText.textContent = 'Edit';
        editIcon.classList.remove('mdi-content-save-outline');
        editIcon.classList.add('mdi-pencil-outline');
        editBtn.classList.remove('is-saving');
    }
});

// for work experience
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const container = document.getElementById('experienceContainer');

    let isEditing = false;

    // Template matching exact UI structure
    function createNewExperienceCard() {
        return `
            <div class="card mb-3 p-3 position-relative experience-item bg-white" style="border: 1px solid #1e293b; border-radius: 8px;">
                <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 delete-exp-btn py-0 px-1" title="Delete Experience" style="font-size: 11px;">
                    <i class="mdi mdi-trash-can-outline"></i>
                </button>

                <div class="exp-view-mode d-none">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fw-bold exp-view-designation" style="font-size: 14px; color: #1e293b;"></span>
                        <span class="badge rounded-1 exp-view-duration" style="background-color: #eff6ff; color: #2563eb; font-weight: 500; font-size: 12px; padding: 4px 8px;"></span>
                    </div>
                    <div class="exp-view-company" style="font-size: 13px; color: #94a3b8; margin-top: 2px;"></div>
                    <div class="exp-view-roles mt-2" style="font-size: 13px; color: #64748b; line-height: 1.4;"></div>
                </div>

                <div class="exp-edit-mode mt-2 pe-4" style="font-size: 11px;">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Designation</label>
                            <input type="text" class="form-control form-control-sm exp-input-designation" style="font-size: 11px;" placeholder="e.g. Lead Engineer">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Company Name</label>
                            <input type="text" class="form-control form-control-sm exp-input-company" style="font-size: 11px;" placeholder="e.g. SRK Infrastructure">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Duration</label>
                            <input type="text" class="form-control form-control-sm exp-input-duration" style="font-size: 11px;" placeholder="e.g. 2022 - Present">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Key Roles & Responsibilities</label>
                            <textarea class="form-control form-control-sm exp-input-roles" rows="2" style="font-size: 11px;" placeholder="Describe key roles..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Toggle Edit / Save State
    editBtn.addEventListener('click', function() {
        isEditing = !isEditing;

        if (isEditing) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Show Edit Mode for existing items
            document.querySelectorAll('.experience-item').forEach(item => {
                item.querySelector('.exp-view-mode').classList.add('d-none');
                item.querySelector('.exp-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-exp-btn').classList.remove('d-none');
            });

            // Automatically append new entry input block
            container.insertAdjacentHTML('beforeend', createNewExperienceCard());

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            document.querySelectorAll('.experience-item').forEach(item => {
                const designation = item.querySelector('.exp-input-designation').value.trim();
                const company = item.querySelector('.exp-input-company').value.trim();
                const duration = item.querySelector('.exp-input-duration').value.trim();
                const roles = item.querySelector('.exp-input-roles').value.trim();

                // If user left a newly generated card completely blank, remove it
                if (!designation && !company && !duration && !roles) {
                    item.remove();
                    return;
                }

                // Sync inputs back into View Mode format
                item.querySelector('.exp-view-designation').textContent = designation || 'N/A';
                item.querySelector('.exp-view-company').textContent = company || 'N/A';
                item.querySelector('.exp-view-duration').textContent = duration || 'N/A';
                item.querySelector('.exp-view-roles').textContent = roles;

                item.querySelector('.exp-edit-mode').classList.add('d-none');
                item.querySelector('.exp-view-mode').classList.remove('d-none');
                item.querySelector('.delete-exp-btn').classList.add('d-none');
            });
        }
    });

    // Delete item functionality
    container.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-exp-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.experience-item');
            card.remove();
        }
    });
});

// for training induction
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const trainingContainer = document.getElementById('trainingContainer');

    let isEditing = false;

    if (editBtn && trainingContainer) {
        editBtn.addEventListener('click', function() {
            isEditing = !isEditing;
            const trainingItems = trainingContainer.querySelectorAll('.training-item');

            if (isEditing) {
                // UI: Switch button to "Save" (Success state)
                editText.textContent = 'Save';
                editIcon.className = 'mdi mdi-check-bold';
                editBtn.style.background = '#198754';
                editBtn.style.borderColor = '#198754';

                // Reveal edit fields and trash icons
                trainingItems.forEach(item => {
                    item.querySelector('.training-view-mode').classList.add('d-none');
                    item.querySelector('.training-edit-mode').classList.remove('d-none');
                    item.querySelector('.delete-training-btn').classList.remove('d-none');
                });
            } else {
                // UI: Switch button back to "Edit" (Default state)
                editText.textContent = 'Edit';
                editIcon.className = 'mdi mdi-pencil-outline';
                editBtn.style.background = 'rgba(255,255,255,0.12)';
                editBtn.style.borderColor = 'rgba(255,255,255,0.25)';

                // Sync data and return to view mode
                trainingItems.forEach(item => {
                    // 1. Read updated values from inputs
                    const titleVal = item.querySelector('.training-input-title').value;
                    const dateVal = item.querySelector('.training-input-date').value;
                    const statusVal = item.querySelector('.training-input-status').value;

                    // 2. Inject updated values into the view text
                    item.querySelector('.training-view-title').textContent = titleVal;
                    item.querySelector('.training-view-date').textContent = dateVal;

                    const statusBadge = item.querySelector('.training-view-status');
                    statusBadge.textContent = statusVal;

                    // 3. Dynamically update badge styling based on dropdown selection
                    statusBadge.className = 'badge training-view-status ';
                    if (statusVal === 'Completed') {
                        statusBadge.className += 'bg-success-subtle text-success';
                    } else if (statusVal === 'Pending') {
                        statusBadge.className += 'bg-warning-subtle text-warning';
                    } else {
                        statusBadge.className +=
                            'bg-info-subtle text-info'; // For "In Progress"
                    }

                    // 4. Hide edit fields and trash icons
                    item.querySelector('.training-view-mode').classList.remove('d-none');
                    item.querySelector('.training-edit-mode').classList.add('d-none');
                    item.querySelector('.delete-training-btn').classList.add('d-none');
                });
            }
        });

        // Event delegation for dynamic deletion of training cards
        trainingContainer.addEventListener('click', function(e) {
            const deleteBtn = e.target.closest('.delete-training-btn');
            if (deleteBtn) {
                // Optional: add a confirmation dialogue here if needed
                deleteBtn.closest('.training-item').remove();
            }
        });
    }
});

// for Reference
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const referenceContainer = document.getElementById('referenceContainer');

    let isEditingReference = false;

    // Status badge formatting function
    function getRefStatusBadgeClass(status) {
        switch (status) {
            case 'VERIFIED':
                return 'bg-success-subtle text-success';
            case 'PENDING':
                return 'bg-warning-subtle text-warning';
            case 'UNVERIFIED':
                return 'bg-danger-subtle text-danger';
            default:
                return 'bg-secondary-subtle text-secondary';
        }
    }

    // Dynamic template for appending blank reference fields
    function createNewReferenceCard() {
        return `
            <div class="card mb-3 p-3 position-relative reference-item bg-white" style="border: 1px solid #1e293b; border-radius: 8px;">
                <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 delete-ref-btn py-0 px-1" title="Delete Reference" style="font-size: 11px;">
                    <i class="mdi mdi-trash-can-outline"></i>
                </button>

                <div class="ref-view-mode d-none">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="d-flex align-items-center gap-2">
                            <span class="fw-bold ref-view-name" style="font-size: 14px; color: #1e293b;"></span>
                            <span class="badge ref-view-status" style="font-weight: 600; font-size: 10px; padding: 3px 6px;"></span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-3 text-secondary" style="font-size: 13px; color: #64748b;">
                        <div>
                            <small class="text-muted">Designation:</small>
                            <span class="ref-view-designation fw-medium" style="color: #334155;"></span>
                        </div>
                        <span style="border-right: 1px solid #cbd5e1; height: 12px;"></span>
                        <div>
                            <small class="text-muted">Phone:</small>
                            <span class="ref-view-phone fw-medium" style="color: #334155;"></span>
                        </div>
                    </div>
                </div>

                <div class="ref-edit-mode mt-1 pe-4" style="font-size: 11px;">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Full Name</label>
                            <input type="text" class="form-control form-control-sm ref-input-name" style="font-size: 11px;" placeholder="e.g. Suresh Raina">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Verification Status</label>
                            <select class="form-select form-select-sm ref-input-status" style="font-size: 11px;">
                                <option value="PENDING" selected>PENDING</option>
                                <option value="VERIFIED">VERIFIED</option>
                                <option value="UNVERIFIED">UNVERIFIED</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Designation</label>
                            <input type="text" class="form-control form-control-sm ref-input-designation" style="font-size: 11px;" placeholder="e.g. Site Supervisor">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Phone Number</label>
                            <input type="text" class="form-control form-control-sm ref-input-phone" style="font-size: 11px;" placeholder="e.g. +91 98765 00000">
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Single Edit Button Listener (Handles Reference Panel Active State)
    editBtn.addEventListener('click', function() {
        const activePanel = document.querySelector('.employee-panel:not(.d-none)');

        if (!activePanel || activePanel.getAttribute('data-panel') !== 'references') return;

        isEditingReference = !isEditingReference;

        if (isEditingReference) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Switch existing cards to edit mode
            referenceContainer.querySelectorAll('.reference-item').forEach(item => {
                item.querySelector('.ref-view-mode').classList.add('d-none');
                item.querySelector('.ref-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-ref-btn').classList.remove('d-none');
            });

            // Automatically insert blank card inputs for fresh reference
            referenceContainer.insertAdjacentHTML('beforeend', createNewReferenceCard());

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            referenceContainer.querySelectorAll('.reference-item').forEach(item => {
                const name = item.querySelector('.ref-input-name').value.trim();
                const status = item.querySelector('.ref-input-status').value;
                const designation = item.querySelector('.ref-input-designation').value.trim();
                const phone = item.querySelector('.ref-input-phone').value.trim();

                // If new card is left empty, automatically clean it up
                if (!name && !designation && !phone) {
                    item.remove();
                    return;
                }

                // Update View UI Elements
                item.querySelector('.ref-view-name').textContent = name || 'N/A';
                item.querySelector('.ref-view-designation').textContent = designation || 'N/A';
                item.querySelector('.ref-view-phone').textContent = phone || 'N/A';

                const statusBadge = item.querySelector('.ref-view-status');
                statusBadge.textContent = status;
                statusBadge.className =
                    `badge ${getRefStatusBadgeClass(status)} ref-view-status`;

                item.querySelector('.ref-edit-mode').classList.add('d-none');
                item.querySelector('.ref-view-mode').classList.remove('d-none');
                item.querySelector('.delete-ref-btn').classList.add('d-none');
            });
        }
    });

    // Delete item listener
    referenceContainer.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-ref-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.reference-item');
            card.remove();
        }
    });
});

// for interview
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const interviewContainer = document.getElementById('interviewContainer');

    let isEditingInterview = false;

    // Helper badge styling function for HR Verdict
    function getVerdictBadgeClass(verdict) {
        switch (verdict) {
            case 'Selected':
                return 'bg-success-subtle text-success';
            case 'On Hold':
                return 'bg-warning-subtle text-warning';
            case 'Rejected':
                return 'bg-danger-subtle text-danger';
            default:
                return 'bg-secondary-subtle text-secondary';
        }
    }

    // Dynamic template for appending blank interview card inputs
    function createNewInterviewCard() {
        return `
            <div class="card mb-3 p-3 position-relative interview-item bg-white" style="border: 1px solid #1e293b; border-radius: 8px;">
                <button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 delete-interview-btn py-0 px-1" title="Delete Interview Log" style="font-size: 11px;">
                    <i class="mdi mdi-trash-can-outline"></i>
                </button>

                <div class="interview-view-mode d-none">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">Screening Recruiter</small>
                            <span class="fw-semibold interview-view-recruiter" style="font-size: 13px; color: #1e293b;"></span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">Evaluation Date</small>
                            <span class="fw-medium interview-view-date" style="font-size: 13px; color: #334155;"></span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">Rating</small>
                            <span class="fw-medium interview-view-rating" style="font-size: 13px; color: #334155;"></span>
                        </div>
                        <div class="col-md-3">
                            <small class="text-muted d-block" style="font-size: 11px;">HR Decision Verdict</small>
                            <span class="badge interview-view-verdict" style="font-weight: 600; font-size: 11px; padding: 4px 8px;"></span>
                        </div>
                        <div class="col-12 mt-2">
                            <small class="text-muted d-block" style="font-size: 11px;">Comments</small>
                            <p class="mb-0 interview-view-comments" style="font-size: 13px; color: #64748b; line-height: 1.4;"></p>
                        </div>
                    </div>
                </div>

                <div class="interview-edit-mode mt-1 pe-4" style="font-size: 11px;">
                    <div class="row g-2">
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Screening Recruiter</label>
                            <input type="text" class="form-control form-control-sm interview-input-recruiter" style="font-size: 11px;" placeholder="e.g. Ramesh Chandra">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Evaluation Date</label>
                            <input type="text" class="form-control form-control-sm interview-input-date" style="font-size: 11px;" placeholder="e.g. 15 Aug 2024">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Rating</label>
                            <input type="text" class="form-control form-control-sm interview-input-rating" style="font-size: 11px;" placeholder="e.g. 4.0 / 5">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">HR Decision Verdict</label>
                            <select class="form-select form-select-sm interview-input-verdict" style="font-size: 11px;">
                                <option value="Selected" selected>Selected</option>
                                <option value="On Hold">On Hold</option>
                                <option value="Rejected">Rejected</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label text-muted mb-1" style="font-size: 11px;">Assessment Comments</label>
                            <textarea class="form-control form-control-sm interview-input-comments" rows="2" style="font-size: 11px;" placeholder="Enter assessment comments..."></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Toggle Edit / Save State for Interview Panel
    editBtn.addEventListener('click', function() {
        const activePanel = document.querySelector('.employee-panel:not(.d-none)');

        if (!activePanel || activePanel.getAttribute('data-panel') !== 'interview') return;

        isEditingInterview = !isEditingInterview;

        if (isEditingInterview) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Show edit mode for all existing entries
            interviewContainer.querySelectorAll('.interview-item').forEach(item => {
                item.querySelector('.interview-view-mode').classList.add('d-none');
                item.querySelector('.interview-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-interview-btn').classList.remove('d-none');
            });

            // Automatically append new entry inputs
            interviewContainer.insertAdjacentHTML('beforeend', createNewInterviewCard());

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            interviewContainer.querySelectorAll('.interview-item').forEach(item => {
                const recruiter = item.querySelector('.interview-input-recruiter').value.trim();
                const date = item.querySelector('.interview-input-date').value.trim();
                const rating = item.querySelector('.interview-input-rating').value.trim();
                const verdict = item.querySelector('.interview-input-verdict').value;
                const comments = item.querySelector('.interview-input-comments').value.trim();

                // If user left a newly appended card completely empty, remove it
                if (!recruiter && !date && !rating && !comments) {
                    item.remove();
                    return;
                }

                // Sync view content with inputs
                item.querySelector('.interview-view-recruiter').textContent = recruiter ||
                    'N/A';
                item.querySelector('.interview-view-date').textContent = date || 'N/A';
                item.querySelector('.interview-view-rating').textContent = rating || 'N/A';
                item.querySelector('.interview-view-comments').textContent = comments ||
                    'No comments provided.';

                const verdictBadge = item.querySelector('.interview-view-verdict');
                verdictBadge.textContent = verdict;
                verdictBadge.className =
                    `badge ${getVerdictBadgeClass(verdict)} interview-view-verdict`;

                item.querySelector('.interview-edit-mode').classList.add('d-none');
                item.querySelector('.interview-view-mode').classList.remove('d-none');
                item.querySelector('.delete-interview-btn').classList.add('d-none');
            });
        }
    });

    // Delete item event listener
    interviewContainer.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-interview-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.interview-item');
            card.remove();
        }
    });
});
// for family
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');
    const familyContainer = document.getElementById('familyContainer');
    const familyAddBox = document.getElementById('familyAddBox');
    const appendFamilyBtn = document.getElementById('appendFamilyBtn');

    let isEditingFamily = false;

    // Build standard structure for dynamically added family members
    function createFamilyCardElement(name, relation, age, occupation) {
        const card = document.createElement('div');
        card.className = 'family-member-card mb-3 family-item position-relative';
        card.innerHTML = `
            <button type="button" class="family-delete-btn position-absolute top-0 end-0 m-3 delete-family-btn" title="Remove Family Member">
                <i class="mdi mdi-trash-can-outline"></i>
            </button>

            <div class="family-view-mode d-none">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <span class="family-member-name family-view-name">${name}</span>
                            <span class="family-relation-badge family-view-relation">${relation.toUpperCase()}</span>
                        </div>
                        <div class="family-member-details">
                            <span>
                                <small>Age:</small>
                                <span class="family-view-age">${age}</span> Years
                            </span>
                            <span class="family-divider"></span>
                            <span>
                                <small>Occupation:</small>
                                <span class="family-view-occupation">${occupation}</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="family-edit-mode pe-4">
                <div class="row g-2">
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Full Name</label>
                        <input type="text" class="form-control form-control-sm family-input-name" style="font-size: 11px;" value="${name}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Relation</label>
                        <input type="text" class="form-control form-control-sm family-input-relation" style="font-size: 11px;" value="${relation}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Age</label>
                        <input type="number" class="form-control form-control-sm family-input-age" style="font-size: 11px;" value="${age}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-muted mb-1" style="font-size: 11px;">Occupation</label>
                        <input type="text" class="form-control form-control-sm family-input-occupation" style="font-size: 11px;" value="${occupation}">
                    </div>
                </div>
            </div>
        `;
        return card;
    }

    // Single Edit Button Listener (Handles Family Panel Active State)
    editBtn.addEventListener('click', function() {
        const activePanel = document.querySelector('.employee-panel:not(.d-none)');

        if (!activePanel || activePanel.getAttribute('data-panel') !== 'family') return;

        isEditingFamily = !isEditingFamily;

        if (isEditingFamily) {
            editText.textContent = 'Save';
            editIcon.className = 'mdi mdi-check-bold';
            editBtn.classList.remove('btn-outline-light');
            editBtn.classList.add('btn-success');

            // Show edit modes & action panel
            familyContainer.querySelectorAll('.family-item').forEach(item => {
                item.querySelector('.family-view-mode').classList.add('d-none');
                item.querySelector('.family-edit-mode').classList.remove('d-none');
                item.querySelector('.delete-family-btn').classList.remove('d-none');
            });

            familyAddBox.classList.remove('d-none');

        } else {
            editText.textContent = 'Edit';
            editIcon.className = 'mdi mdi-pencil-outline';
            editBtn.classList.remove('btn-success');

            // Sync input values back to view mode elements
            familyContainer.querySelectorAll('.family-item').forEach(item => {
                const name = item.querySelector('.family-input-name').value.trim();
                const relation = item.querySelector('.family-input-relation').value.trim();
                const age = item.querySelector('.family-input-age').value.trim();
                const occupation = item.querySelector('.family-input-occupation').value.trim();

                // Clear blank entries
                if (!name && !relation && !age && !occupation) {
                    item.remove();
                    return;
                }

                item.querySelector('.family-view-name').textContent = name || 'N/A';
                item.querySelector('.family-view-relation').textContent = (relation || 'N/A')
                    .toUpperCase();
                item.querySelector('.family-view-age').textContent = age || 'N/A';
                item.querySelector('.family-view-occupation').textContent = occupation || 'N/A';

                item.querySelector('.family-edit-mode').classList.add('d-none');
                item.querySelector('.family-view-mode').classList.remove('d-none');
                item.querySelector('.delete-family-btn').classList.add('d-none');
            });

            familyAddBox.classList.add('d-none');
        }
    });

    // Handle "Append Family Member" action button
    appendFamilyBtn.addEventListener('click', function() {
        const nameInput = document.getElementById('newFamilyName');
        const relationInput = document.getElementById('newFamilyRelation');
        const ageInput = document.getElementById('newFamilyAge');
        const occupationInput = document.getElementById('newFamilyOccupation');

        const name = nameInput.value.trim();
        const relation = relationInput.value.trim();
        const age = ageInput.value.trim();
        const occupation = occupationInput.value.trim();

        if (!name && !relation) {
            toastr.error('Please enter at least a name and relation.');
            return;
        }

        const newCard = createFamilyCardElement(name, relation, age, occupation);
        familyContainer.appendChild(newCard);

        // Reset inputs
        nameInput.value = '';
        relationInput.value = '';
        ageInput.value = '';
        occupationInput.value = '';
    });

    // Delete item listener
    familyContainer.addEventListener('click', function(e) {
        const deleteBtn = e.target.closest('.delete-family-btn');
        if (deleteBtn) {
            const card = deleteBtn.closest('.family-item');
            card.remove();
        }
    });
});
// Remuneration
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    if (!editBtn) return;
    editBtn.addEventListener('click', function() {
        const isEditing = editBtn.dataset.editing === 'true';
        const fields = [
            'componentATotal',
            'basic',
            'hra',
            'special',
            'componentBTotal',
            'epfEmployee',
            'esiEmployee',
            'pt',
            'tds',
            'componentCTotal',
            'epfEmployer',
            'esiEmployer',
            'gratuity'
        ];
        fields.forEach(function(field) {
            const view = document.getElementById(field + 'View');
            const edit = document.getElementById(field + 'Edit');
            if (!view || !edit) return;
            if (!isEditing) {
                // View → Edit
                view.classList.add('d-none');
                edit.classList.remove('d-none');
            } else {
                // Edit → View
                const input = edit.querySelector('input');
                if (input) {
                    const value = Number(input.value || 0);
                    view.querySelector('span').textContent =
                        '₹ ' + value.toLocaleString('en-IN');
                }
                edit.classList.add('d-none');
                view.classList.remove('d-none');
            }
        });
        // Update button state
        editBtn.dataset.editing = (!isEditing).toString();
        const icon = document.getElementById('employeeEditIcon');
        const text = document.getElementById('employeeEditText');
        if (!isEditing) {
            // Edit mode
            icon.className = 'mdi mdi-content-save-outline';
            text.textContent = 'Save';
        } else {
            // View mode
            icon.className = 'mdi mdi-pencil-outline';
            text.textContent = 'Edit';
        }
    });
});

// document upload for employee files
document.addEventListener('DOMContentLoaded', function() {
    const editBtn = document.getElementById('employeeEditBtn');
    const editIcon = document.getElementById('employeeEditIcon');
    const editText = document.getElementById('employeeEditText');

    const documentsGrid = document.getElementById('documentsGrid');
    const documentUploadBox = document.getElementById('documentUploadBox');
    const fileInput = document.getElementById('documentFileInput');
    const triggerFileBtn = document.getElementById('triggerFileSelectBtn');
    const uploadBtn = document.getElementById('documentUploadBtn');
    const documentTypeSelect = document.getElementById('documentType');

    let isEditing = false;

    // Toggle Edit / Save Mode
    if (editBtn) {
        editBtn.addEventListener('click', function() {
            isEditing = !isEditing;

            if (isEditing) {
                // Update button state to Save
                editText.textContent = 'Save';
                editIcon.className = 'mdi mdi-check-bold';
                editBtn.style.background = '#198754';
                editBtn.style.borderColor = '#198754';

                // Reveal upload section and document deletion buttons
                if (documentUploadBox) documentUploadBox.classList.remove('d-none');
                if (documentsGrid) {
                    documentsGrid.querySelectorAll('.document-delete-btn').forEach(btn => btn.classList
                        .remove('d-none'));
                }
            } else {
                // Reset button state to Edit
                editText.textContent = 'Edit';
                editIcon.className = 'mdi mdi-pencil-outline';
                editBtn.style.background = 'rgba(255,255,255,0.12)';
                editBtn.style.borderColor = 'rgba(255,255,255,0.25)';

                // Hide upload section and document deletion buttons
                if (documentUploadBox) documentUploadBox.classList.add('d-none');
                if (documentsGrid) {
                    documentsGrid.querySelectorAll('.document-delete-btn').forEach(btn => btn.classList
                        .add('d-none'));
                }
            }
        });
    }

    // File selection trigger
    if (triggerFileBtn && fileInput) {
        triggerFileBtn.addEventListener('click', function() {
            fileInput.click();
        });

        fileInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                triggerFileBtn.textContent = this.files[0].name;
                triggerFileBtn.classList.remove('btn-outline-secondary');
                triggerFileBtn.classList.add('btn-outline-primary');
            } else {
                triggerFileBtn.innerHTML = '<i class="mdi mdi-paperclip me-1"></i> Select File...';
                triggerFileBtn.classList.remove('btn-outline-primary');
                triggerFileBtn.classList.add('btn-outline-secondary');
            }
        });
    }

    // Helper for formatting file size
    function formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    // Append new uploaded file card
    if (uploadBtn) {
        uploadBtn.addEventListener('click', function() {
            if (!fileInput.files || !fileInput.files[0]) {
                toastr.error('Please select a file to upload.');
                return;
            }

            const file = fileInput.files[0];
            const docName = file.name;
            const docSize = formatBytes(file.size);
            const docCategory = documentTypeSelect.options[documentTypeSelect.selectedIndex].text;
            const deleteBtnVisibility = isEditing ? '' : 'd-none';

            const card = document.createElement('div');
            card.className =
                'document-card mb-3 p-3 border rounded d-flex align-items-center justify-content-between';
            card.innerHTML = `
                <div class="document-info d-flex align-items-center gap-3">
                    <div class="document-icon text-primary fs-3">
                        <i class="mdi mdi-file-document-outline"></i>
                    </div>
                    <div class="document-details">
                        <div class="document-name fw-semibold" style="font-size: 13px;">${docName}</div>
                        <div class="document-meta text-muted" style="font-size: 11px;">
                            ${docCategory}
                            <span class="document-meta-divider mx-1">•</span>
                            ${docSize}
                        </div>
                    </div>
                </div>
                <div class="document-actions d-flex align-items-center gap-2">
                    <span class="document-status badge bg-warning-subtle text-warning px-2 py-1" style="font-size: 10px;">
                        Pending
                    </span>
                    <button type="button" class="btn btn-sm btn-link text-danger p-0 document-delete-btn ${deleteBtnVisibility}" title="Remove Document">
                        <i class="mdi mdi-trash-can-outline fs-5"></i>
                    </button>
                </div>
            `;

            documentsGrid.appendChild(card);

            // Reset inputs
            fileInput.value = '';
            triggerFileBtn.innerHTML = '<i class="mdi mdi-paperclip me-1"></i> Select File...';
            triggerFileBtn.classList.remove('btn-outline-primary');
            triggerFileBtn.classList.add('btn-outline-secondary');
        });
    }

    // Dynamic document deletion
    if (documentsGrid) {
        documentsGrid.addEventListener('click', function(e) {
            const deleteBtn = e.target.closest('.document-delete-btn');
            if (deleteBtn) {
                deleteBtn.closest('.document-card').remove();
            }
        });
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('emergencyContactContainer');
    const addBtn = document.getElementById('addEmergencyContactBtn');
    if (!container || !addBtn) return;
    let contactIndex = container.querySelectorAll('.emergency-contact-row').length;

    async function ensureRelations() {
        if (Array.isArray(window.hrStaffOptions?.relations)) return window.hrStaffOptions.relations;
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
        const response = await fetch('/admin-hr/api/staff/options', {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest', ...(csrfToken ? { 'X-CSRF-TOKEN': csrfToken } : {}) }
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok || payload.success === false) throw new Error(payload.message || 'Unable to load relation options.');
        window.hrStaffOptions = payload.data || {};
        return Array.isArray(window.hrStaffOptions.relations) ? window.hrStaffOptions.relations : [];
    }

    function escapeRelation(value) {
        return String(value ?? '').replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[character]));
    }

    async function hydrateRelationSelect(select) {
        select.innerHTML = '<option value="">Select relation</option>';
        try {
            const relations = await ensureRelations();
            select.insertAdjacentHTML('beforeend', relations.map(item => '<option value="' + escapeRelation(item.id) + '">' + escapeRelation(item.name || item.relationship_name || '') + '</option>').join(''));
            if (window.jQuery && jQuery.fn.select2) {
                const control = jQuery(select);
                if (!control.hasClass('select2-hidden-accessible')) {
                    control.select2({ placeholder: 'Select relation', allowClear: true, dropdownParent: jQuery('#staffDrawer') });
                } else {
                    control.trigger('change.select2');
                }
            }
        } catch (error) {
            console.error('Emergency relation options could not be loaded:', error);
            select.insertAdjacentHTML('beforeend', '<option value="" disabled>Relations unavailable — reload to retry</option>');
        }
    }

    addBtn.addEventListener('click', async function() {
        const newRow = document.createElement('div');
        newRow.className = 'row g-3 emergency-contact-row mb-2 align-items-center';
        newRow.innerHTML = `
            <div class="col-md-5">
                <label class="form-label fw-semibold">Contact Name</label>
                <input type="text" class="form-control" name="emergency_contacts[${contactIndex}][name]" placeholder="Enter contact name">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Relation</label>
                <select class="select3 form-select" name="emergency_contacts[${contactIndex}][relation]"><option value="">Loading relations…</option></select>
            </div>
            <div class="col-md-3 position-relative">
                <label class="form-label fw-semibold">Contact Number</label>
                <div class="d-flex align-items-center">
                    <input type="tel" class="form-control" name="emergency_contacts[${contactIndex}][number]" placeholder="Enter contact number">
                    <button type="button" class="btn btn-sm btn-link text-danger p-0 ms-2 remove-contact-btn" title="Remove Contact">
                        <i class="mdi mdi-trash-can-outline fs-5"></i>
                    </button>
                </div>
            </div>`;
        container.appendChild(newRow);
        const newSelect = newRow.querySelector('select[name*="[relation]"]');
        await hydrateRelationSelect(newSelect);
        contactIndex++;
    });

    container.addEventListener('click', function(event) {
        const removeBtn = event.target.closest('.remove-contact-btn');
        if (!removeBtn) return;
        const row = removeBtn.closest('.emergency-contact-row');
        const select = row?.querySelector('select.select2-hidden-accessible');
        if (select && window.jQuery) jQuery(select).select2('destroy');
        row?.remove();
    });
});

function showFileName(inputElement, targetId) {
    const file = inputElement.files[0];
    const target = document.getElementById(targetId);
    
    if (file) {
        // Add a checkmark icon and the file name
        target.innerHTML = `<i class="mdi mdi-check-circle me-1"></i> ${file.name}`;
    } else {
        // Clear if no file is selected
        target.innerHTML = '';
    }
}
</script>


<script>


    const type = 'permanent';
    const api = '/admin-hr/api';
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

    const state = { 
        page: 1, 
        per_page: 10, 
        search: '', 
        sort: 'name', 
        direction: 'asc', 
        department_id: '', 
        options: null, 
        current: null,
        leavePolicies: [],
        remunerationDraft: [],
        wagesDraftTouched: false,
        wagesCalculationVersion: 0,
        wagesModalReady: false
    };

    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));

    const safeLabel = value => String(value || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    
    async function request(url, options = {}) {
        const response = await fetch(url, { credentials: 'same-origin', ...options, headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-TOKEN': csrf, ...(options.headers || {}) } });
        let body = {}; try { body = await response.json(); } catch (_) {}
        if (!response.ok || body.success === false) throw new Error(body.message || Object.values(body.errors || {}).flat()[0] || 'Request failed.');
        return body;
    }
    function refreshSelect2(select) {
        if (window.jQuery && jQuery.fn.select2 && jQuery(select).hasClass('select3')) jQuery(select).trigger('change.select2');
    }
    function setOptions(select, items, placeholder, selected = '') {
        if (!select) return;
        const previous = selected !== '' && selected !== null ? String(selected) : String(select.value || '');
        select.innerHTML = `<option value="">${esc(placeholder)}</option>${(items || []).map(item => `<option value="${esc(item.id)}">${esc(item.name || item.relationship_name || item.blood_group)}</option>`).join('')}`;
        select.value = previous;
        refreshSelect2(select);
    }
    function normalizeLeavePolicyType(value) {
        return String(value || '').toLowerCase().replace(/[^a-z]/g, '');
    }

    function updateWorkplaceLeaveBalanceConfiguration(options = {}) {
        const joiningDate = document.getElementById('dateOfJoining')?.value || '';
        const preview = document.getElementById('leaveCyclePreview');
        const recalculate = options.recalculate === true;
        const rows = [
            ['casualLeave', 'casualLeaveProrated'],
            ['paidLeave', 'paidLeaveProrated'],
            ['sickLeave', 'sickLeaveProrated'],
        ];
        const formatDays = value => `${Number(value || 0).toFixed(2).replace(/\.00$/, '')} days`;
        const dateLabel = date => `${String(date.getFullYear())}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
        const annualValues = [];
        const calculatedValues = [];

        rows.forEach(([inputId, previewId]) => {
            const input = document.getElementById(inputId);
            if (!input) {
                annualValues.push(0);
                calculatedValues.push(0);
                return;
            }
            const annual = Math.max(0, Number(input.dataset.hrPolicyAnnual ?? input.value ?? 0));
            annualValues.push(annual);
            let calculated = annual;

            if (joiningDate) {
                const join = new Date(`${joiningDate}T00:00:00`);
                if (!Number.isNaN(join.getTime())) {
                    const year = join.getFullYear();
                    const currentYear = new Date().getFullYear();
                    if (year > currentYear) {
                        calculated = 0;
                    } else if (year === currentYear) {
                        const yearStart = new Date(year, 0, 1);
                        const yearEndExclusive = new Date(year + 1, 0, 1);
                        const eligibleStart = join > yearStart ? join : yearStart;
                        const dayMs = 86400000;
                        const eligibleDays = Math.max(0, Math.round((yearEndExclusive - eligibleStart) / dayMs));
                        const yearDays = Math.round((yearEndExclusive - yearStart) / dayMs);
                        calculated = yearDays > 0 ? Math.round((annual * eligibleDays / yearDays) * 100) / 100 : annual;
                    }
                }
            }
            calculatedValues.push(calculated);

            // Date changes refresh the effective allocation from the annual policy value.
            // The allocation remains editable after calculation; it is not used as the next policy base.
            if (recalculate) input.value = calculated.toFixed(2).replace(/\.00$/, '');

            const effective = Math.max(0, Number(input.value || 0));
            const label = document.getElementById(previewId);
            if (label) {
                const customText = Math.abs(effective - calculated) > 0.009 ? ` · Custom allocation: ${formatDays(effective)}` : '';
                label.textContent = `Annual policy: ${formatDays(annual)} · Joining-date allocation: ${formatDays(calculated)}${customText}`;
            }
        });

        if (!preview) return;
        if (!joiningDate) {
            preview.textContent = `Select Date of Joining to calculate the initial-year allocation. Current values use the full annual policy quotas: CL ${formatDays(annualValues[0])}, PL ${formatDays(annualValues[1])}, SL ${formatDays(annualValues[2])}.`;
            return;
        }
        const start = new Date(`${joiningDate}T00:00:00`);
        if (Number.isNaN(start.getTime())) {
            preview.textContent = 'Enter a valid Date of Joining.';
            return;
        }
        const end = new Date(start);
        end.setFullYear(end.getFullYear() + 1);
        end.setDate(end.getDate() - 1);
        preview.textContent = `Leave cycle: ${dateLabel(start)} to ${dateLabel(end)} · Effective current-year allocation: CL ${formatDays(Number(document.getElementById('casualLeave')?.value || 0))}, PL ${formatDays(Number(document.getElementById('paidLeave')?.value || 0))}, SL ${formatDays(Number(document.getElementById('sickLeave')?.value || 0))}. Changing the joining date recalculates these values.`;
    }

    async function loadLeavePolicyDefaults() {
        try {
            const response = await request(`${api}/leave/${type}/policies`);
            state.leavePolicies = response.data || [];
            const policyMap = new Map(state.leavePolicies.map(policy => [normalizeLeavePolicyType(policy.leave_type), policy]));
            const findPolicy = aliases => aliases.map(alias => policyMap.get(alias)).find(Boolean);
            const defaults = [
                ['casualLeave', findPolicy(['casualleave', 'casual'])],
                ['paidLeave', findPolicy(['paidleave', 'privilegeleave', 'paid', 'privilege'])],
                ['sickLeave', findPolicy(['sickleave', 'sick'])],
            ];
            defaults.forEach(([id, policy]) => {
                const input = document.getElementById(id);
                if (input && policy && policy.annual_days !== undefined && input.dataset.hrPolicyLoaded !== '1') {
                    input.dataset.hrPolicyAnnual = String(Math.max(0, Number(policy.annual_days || 0)));
                    input.value = input.dataset.hrPolicyAnnual;
                    input.dataset.hrPolicyLoaded = '1';
                }
            });
            updateWorkplaceLeaveBalanceConfiguration({ recalculate: true });
        } catch (error) {
            console.warn('Could not load leave allocation settings:', error.message);
        }
    }

    async function loadOptions() {
        const response = await request(`${api}/staff/options`); state.options = response.data || {}; window.hrStaffOptions = state.options;
        const departments = state.options.departments || [];
        const departmentHost = document.querySelector('.department-scroll');
        if (departmentHost) departmentHost.innerHTML = `<button type="button" data-department="ALL" class="btn btn-sm text-nowrap rounded-3 fw-semibold dept-filter-btn active">All Roles</button>${departments.map(department => `<button type="button" data-department="${esc(department.name)}" data-department-id="${esc(department.id)}" class="btn btn-sm text-nowrap rounded-3 fw-semibold dept-filter-btn">${esc(department.name)}</button>`).join('')}`;
        setOptions(document.getElementById('bloodGroup'), state.options.blood_groups, 'Select blood group');
        setOptions(document.getElementById('department'), departments, 'Select department');
        setOptions(document.getElementById('role_designation'), state.options.designations, 'Select designation');
        setOptions(document.getElementById('user_role'), state.options.roles, 'Select user role');
        setOptions(document.getElementById('languages'), state.options.languages, 'Select languages');
        // Keep the same form controls, but use Settings-backed options instead of static relations.
        document.querySelectorAll('select[name*="[relation]"], select.family-input-relation, #newFamilyRelation').forEach(select => setOptions(select, state.options.relations, 'Select relation'));
        document.querySelectorAll('input.family-input-relation').forEach(input => {
        const select = document.createElement('select'); select.className = `${input.className} form-select`; select.id = input.id || '';
        select.setAttribute('aria-label', 'Family relation'); input.replaceWith(select); setOptions(select, state.options.relations, 'Select relation');
        });
        setupRemunerationRows();
        initializeWagesModal();
        await loadLeavePolicyDefaults();
    }
    function setupRemunerationRows() {
        const panel = document.querySelector('[data-panel="remuneration"]');
        if (panel && !document.getElementById('dynamicRemunerationRows')) {
        const wrap = document.createElement('div'); wrap.className = 'card border rounded-3 p-3 mb-3 bg-white';
        wrap.innerHTML = `<div class="d-flex align-items-center justify-content-between mb-2"><strong>Wage Components from Settings</strong><button type="button" class="btn btn-sm btn-outline-primary" id="addRemunerationRow">Add component</button></div><div id="dynamicRemunerationRows"></div>`;
        panel.prepend(wrap); document.getElementById('addRemunerationRow').addEventListener('click', addRemunerationRow);
        }
    }
    function addRemunerationRow(item = null) {
        const host = document.getElementById('dynamicRemunerationRows'); if (!host || !state.options) return;
        const row = document.createElement('div'); row.className = 'row g-2 align-items-end mb-2 remuneration-row';
        row.innerHTML = `<div class="col-md-7"><label class="form-label small">Remuneration type</label><select class="form-select remuneration-type"><option value="">Select component</option>${(state.options.remuneration_types || []).map(component => `<option value="${esc(component.id)}">${esc(component.name)}</option>`).join('')}</select></div><div class="col-md-4"><label class="form-label small">Amount (₹)</label><input type="number" min="0" step="0.01" class="form-control remuneration-amount" value="${esc(item?.amount ?? 0)}"></div><div class="col-md-1"><button type="button" class="btn btn-sm btn-outline-danger remove-remuneration" aria-label="Remove">×</button></div>`;
        row.querySelector('.remuneration-type').value = String(item?.type_id ?? '');
        row.querySelector('.remove-remuneration').addEventListener('click', () => row.remove()); host.appendChild(row);
    }
    function statusPresentation(statusValue) {
        const status = Number(statusValue);
        if (status === 1) return { label: 'Inactive', bg: '#fef2f2', color: '#dc2626', icon: 'mdi-pause-circle-outline' };
        if (status === 3) return { label: 'Exit', bg: '#fff7ed', color: '#ea580c', icon: 'mdi-exit-run' };
        if (status === 2) return { label: 'Deleted', bg: '#f1f5f9', color: '#64748b', icon: 'mdi-delete-outline' };
        return { label: 'Active', bg: '#ecfdf5', color: '#059669', icon: 'mdi-check-circle-outline' };
    }

    function renderRows(rows) {
        const body = document.querySelector('#staff-table tbody');
        if (!body) return;
        if (!rows.length) {
            body.innerHTML = noDataFound();
            return;
        }

        body.innerHTML = rows.map(row => {
            const status = statusPresentation(row.status);
            const wage = Number(row.basic_salary || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
            const staff_profile_src = row.staff_image_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(row.name || 'Staff')}&background=f8f9fa&color=0d6efd&size=100`;
            return `
                <tr class="employee-row" data-id="${esc(row.id)}" data-department="${esc(row.department || '')}">
                    <td class="px-4 py-3 staff-open" data-id="${esc(row.id)}" style="cursor:pointer">
                        <div class="d-flex align-items-center gap-3">
                            <div class="avatar  d-flex align-items-center justify-content-center flex-shrink-0" style="">
                                <img src="${staff_profile_src}" style="width:40px;height:40px;background:#eff6ff;color:#16659E" class="rounded-circle" alt="Profile" >
                            </div>
                            
                            <div>
                                <span class="d-block fw-semibold">${esc(row.name || '—')}</span>
                                <small class="text-muted">${esc(row.email || row.mobile || '')}</small>
                                <small class="d-block text-muted">${esc(row.staff_id || '')}</small>
                            </div>
                        </div>
                    </td>
                    <td class="px-4 py-3">
                        <span class="d-block text-secondary">${esc(row.designation || '—')}</span>
                        <small class="text-primary">${esc(row.department || '—')}</small>
                    </td>
                    <td class="px-4 py-3">
                        <span class="fw-semibold text-secondary">${esc(row.department || '—')}</span>
                        <small class="d-block text-muted">${esc(row.date_of_joining || '')}</small>
                    </td>
                    <td class="px-4 py-3 text-start">
                        <span class="fw-semibold" style="color:#0C3C62">₹${wage}</span>
                        <small class="d-block text-muted" style="font-size:10px">Monthly</small>
                    </td>
                    <td class="px-4 py-3 text-start">
                        <div class="dropdown">
                            <button type="button" class="btn dropdown-toggle rounded-2 border-0 fw-semibold" data-bs-toggle="dropdown" aria-expanded="false" style="background-color:${status.bg};color:${status.color};font-size:10px;padding:6px 10px">
                                <i class="mdi ${status.icon} me-1"></i>${status.label}
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3 p-1" style="min-width:145px">
                                <li><a href="#" class="dropdown-item rounded-2 fw-semibold employee-status-option" data-status="Active" data-employee-id="${esc(row.id)}" style="font-size:11px;color:#059669"><i class="mdi mdi-check-circle-outline me-2"></i>Active</a></li>
                                <li><a href="#" class="dropdown-item rounded-2 fw-semibold employee-status-option" data-status="Inactive" data-employee-id="${esc(row.id)}" style="font-size:11px;color:#dc2626"><i class="mdi mdi-pause-circle-outline me-2"></i>Inactive</a></li>
                                <li><a href="#" class="dropdown-item rounded-2 fw-semibold employee-status-option" data-status="Exit" data-employee-id="${esc(row.id)}" style="font-size:11px;color:#ea580c"><i class="mdi mdi-exit-run me-2"></i>Exit</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><button type="button" class="dropdown-item text-danger staff-delete" data-id="${esc(row.id)}"><i class="mdi mdi-delete-outline me-2"></i>Delete</button></li>
                            </ul>
                        </div>
                    </td>
                </tr>`;
        }).join('');
    }

    // function skeletonRow() {
    //     return `<tr class="skeleton-loader"><td colspan="5" class="py-4"><div class="placeholder-glow"><span class="placeholder col-12 mb-2"></span><span class="placeholder col-10 mb-2"></span><span class="placeholder col-7"></span></div></td></tr>`;
    // }

    function skeletonRow() {
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function noDataFound() {
        return `<tr><td colspan="5" class="text-center py-5 text-muted">No staff records found.</td></tr>`;
    }

    function renderPagination(meta) {
        let host = document.getElementById('staff-ajax-pagination');
        if (!host) {
            host = document.createElement('div');
            host.id = 'staff-ajax-pagination';
            host.className = 'd-flex flex-wrap align-items-center justify-content-between gap-2 p-3';
            document.querySelector('#staff-table')?.closest('.card')?.appendChild(host);
        }
        if (!host) return;

        const currentPage = Number(meta.current_page || 1);
        const lastPage = Math.max(1, Number(meta.last_page || 1));
        const total = Number(meta.total || 0);
        const perPage = Number(meta.per_page || state.per_page);
        const start = total === 0 ? 0 : ((currentPage - 1) * perPage) + 1;
        const end = Math.min(currentPage * perPage, total);
        const firstPage = Math.max(1, currentPage - 2);
        const finalPage = Math.min(lastPage, currentPage + 2);
        const pageButtons = Array.from({ length: finalPage - firstPage + 1 }, (_, index) => {
            const page = firstPage + index;
            return `<li class="page-item ${page === currentPage ? 'active' : ''}"><button type="button" class="page-link" data-staff-page="${page}" ${page === currentPage ? 'aria-current="page"' : ''}>${page}</button></li>`;
        }).join('');

        host.innerHTML = `
            <div class="small text-muted">Showing ${start} to ${end} of ${total} results</div>
            <div class="d-flex flex-wrap align-items-center gap-2">
                <label for="staffPageSize" class="small text-muted mb-0">Rows</label>
                <select id="staffPageSize" class="form-select form-select-sm" style="width:82px">
                    <option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option>
                </select>
                <nav aria-label="Staff table pagination"><ul class="pagination pagination-sm mb-0">
                    <li class="page-item ${currentPage === 1 ? 'disabled' : ''}"><button type="button" class="page-link" data-staff-page="1" aria-label="First page" ${currentPage === 1 ? 'disabled' : ''}>«</button></li>
                    <li class="page-item ${currentPage === 1 ? 'disabled' : ''}"><button type="button" class="page-link" data-staff-page="${Math.max(1, currentPage - 1)}" aria-label="Previous page" ${currentPage === 1 ? 'disabled' : ''}>‹</button></li>
                    ${pageButtons}
                    <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}"><button type="button" class="page-link" data-staff-page="${Math.min(lastPage, currentPage + 1)}" aria-label="Next page" ${currentPage === lastPage ? 'disabled' : ''}>›</button></li>
                    <li class="page-item ${currentPage === lastPage ? 'disabled' : ''}"><button type="button" class="page-link" data-staff-page="${lastPage}" aria-label="Last page" ${currentPage === lastPage ? 'disabled' : ''}>»</button></li>
                </ul></nav>
            </div>`;

        host.querySelector('#staffPageSize').value = String(perPage);
        host.querySelector('#staffPageSize').addEventListener('change', event => {
            state.per_page = Number(event.currentTarget.value);
            state.page = 1;
            loadRows();
        });
        host.querySelectorAll('[data-staff-page]').forEach(button => button.addEventListener('click', () => {
            if (button.disabled) return;
            state.page = Number(button.dataset.staffPage);
            loadRows();
        }));
    }

    let isLoading = false;
    let abortController = new AbortController();

    async function loadRows() {
        const body = document.querySelector('#staff-table tbody');
        if (!body) return;
        abortController.abort();
        abortController = new AbortController();
        isLoading = true;
        body.innerHTML = skeletonRow();

        const params = new URLSearchParams({
            page: String(state.page),
            per_page: String(state.per_page),
            search: state.search,
            sort: state.sort,
            direction: state.direction,
        });
        if (state.department_id) params.set('department_id', String(state.department_id));
        $('#total_employees_dash').text(0);
        try {
            const result = await request(`${api}/staff/${type}?${params.toString()}`, { signal: abortController.signal });
            renderRows(result.data || []);
            renderPagination(result.meta || {});
            const badge = document.querySelector('.card-header .badge');
            if (badge) badge.textContent = `${Number(result.meta?.total || 0)} Staff`;
            $('#total_employees_dash').text(Number(result.meta?.total || 0));
        } catch (error) {
            if (error.name !== 'AbortError' && body.isConnected) {
                body.innerHTML = `<tr><td colspan="5" class="text-danger text-center py-4">${esc(error.message)}</td></tr>`;
                $('#total_employees_dash').text(0);
            }
        } finally {
            isLoading = false;
        }
    }

    function getWageComponentGroup(component) {
        const configuredType = String(component.component_type ?? '').trim().toLowerCase().replace(/[_-]+/g, ' ');
        const componentText = `${component.name ?? ''} ${component.description ?? ''}`.toLowerCase();

        if (['c', '3', 'component c', 'component 3'].includes(configuredType)
            || configuredType.includes('employer') || configuredType.includes('contribution') || configuredType.includes('benefit')) {
            return 'C';
        }
        if (['b', '2', 'component b', 'component 2'].includes(configuredType)) return 'B';
        if (['a', '1', 'component a', 'component 1'].includes(configuredType)) return 'A';
        if (configuredType.includes('deduct') || configuredType.includes('detection') || configuredType.includes('employee deduction')) return 'B';
        if (configuredType.includes('earning') || configuredType.includes('gross')) return 'A';

        if (componentText.includes('employer share') || componentText.includes('employer contribution')
            || componentText.includes('employer benefit') || componentText.includes('employer')
            || componentText.includes('contribution') || componentText.includes('benefit')) {
            return 'C';
        }
        if (componentText.includes('deduction') || componentText.includes('employee share')
            || componentText.includes('income tax') || componentText.includes('professional tax')
            || componentText.includes('tds') || componentText.includes('epf') || componentText.includes('esi')) {
            return 'B';
        }
        if (componentText.includes('basic pay') || componentText.includes('earning')
            || componentText.includes('gross') || componentText.includes('allowance')) {
            return 'A';
        }
        return 'A';
    }

    function formatWageCurrency(value) {
        const amount = Number(value || 0);
        return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
    }

    function renderWageComponentCard(component, group) {
        const draft = state.remunerationDraft.find(item => Number(item.type_id) === Number(component.id));
        const amount = draft ? Number(draft.amount) : 0;
        const description = component.description || 'Configured in Settings > Remuneration Type';
        const groupColour = group === 'A' ? 'primary' : group === 'B' ? 'danger' : 'info';

        return `
            <div class="col-md-6" data-wage-card="${group}">
                <div class="p-3 border rounded-3 bg-white h-100 d-flex flex-column justify-content-between">
                    <div>
                        <div class="d-flex justify-content-between align-items-start mb-1">
                            <label class="fw-bold text-dark text-uppercase" style="font-size:12px;letter-spacing:.5px;" for="wageComponent${Number(component.id)}">${esc(component.name)}</label>
                            <span class="badge bg-${groupColour}-subtle text-${groupColour}">${group}</span>
                        </div>
                        <div class="text-muted mb-3" style="font-size:11px;">${esc(description)}</div>
                    </div>
                    <div class="input-group input-group-sm rounded-2 overflow-hidden border">
                        <span class="input-group-text bg-light text-secondary border-0 px-3">₹</span>
                        <input id="wageComponent${Number(component.id)}" class="form-control border-0 shadow-none fw-bold text-dark bg-white hr-wage-component-amount" type="number" min="0" step="0.01" value="${amount}" data-type-id="${Number(component.id)}" data-group="${group}" aria-label="${esc(component.name)} calculated monthly amount" readonly aria-readonly="true">
                    </div>
                </div>
            </div>`;
    }

    function getWageModalComponents() {
        const modal = document.getElementById('wagesModal');
        if (!modal) return [];
        return [...modal.querySelectorAll('.hr-wage-component-amount')].map(input => ({
            type_id: Number(input.dataset.typeId),
            amount: Math.max(0, Number(input.value || 0)),
            group: input.dataset.group
        }));
    }

    function updateWageTotals() {
        const components = getWageModalComponents();
        const totals = components.reduce((summary, component) => {
            summary[component.group] += component.amount;
            return summary;
        }, { A: 0, B: 0, C: 0 });
        const net = totals.A - totals.B;
        const ctc = totals.A + totals.C;
        const totalA = document.getElementById('wagesTotalALabel');
        const totalB = document.getElementById('wagesTotalBLabel');
        const totalC = document.getElementById('wagesTotalCLabel');
        if (totalA) totalA.textContent = `Total A: ${formatWageCurrency(totals.A)}/mo`;
        if (totalB) totalB.textContent = `Total Deductions B: ${formatWageCurrency(totals.B)}/mo`;
        if (totalC) totalC.textContent = `Total Employer Share C: ${formatWageCurrency(totals.C)}/mo`;
        const netValue = document.getElementById('wagesNetTakeHome');
        const dailyValue = document.getElementById('wagesNetDaily');
        const previewCtc = document.getElementById('wagesPreviewCtc');
        const totalCtc = document.getElementById('wagesTotalCtc');
        if (netValue) netValue.textContent = `${formatWageCurrency(net)}/month`;
        if (dailyValue) dailyValue.textContent = `${formatWageCurrency(net / 30)}/day (30-day estimate)`;
        if (previewCtc) previewCtc.textContent = `${formatWageCurrency(ctc)}/month`;
        if (totalCtc) totalCtc.textContent = `${formatWageCurrency(ctc)}/month`;
        return { totals, net, ctc, components };
    }

    async function calculateWageStructure() {
        const calculationVersion = ++state.wagesCalculationVersion;
        const gross = Number(document.getElementById('wagesTargetGross')?.value || 0);
        const notice = document.getElementById('wagesDraftNotice');
        if (gross <= 0) {
            state.remunerationDraft = [];
            state.wagesDraftTouched = false;
            document.querySelectorAll('#wagesModal .hr-wage-component-amount').forEach(input => { input.value = '0.00'; });
            updateWageTotals();
            if (notice) {
                notice.className = 'alert alert-info py-2 small';
                notice.textContent = 'Enter a positive gross salary to calculate the configured component split.';
            }
            return null;
        }
        try {
            const response = await request(`${api}/payroll/calculate`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ gross_amount: gross })
            });
            if (calculationVersion !== state.wagesCalculationVersion) return null;
            const result = response.data || {};
            state.remunerationDraft = (result.components || []).map(component => ({ type_id: Number(component.type_id), amount: Number(component.amount || 0) }));
            const amountMap = new Map(state.remunerationDraft.map(component => [component.type_id, component.amount]));
            document.querySelectorAll('#wagesModal .hr-wage-component-amount').forEach(input => {
                input.value = Number(amountMap.get(Number(input.dataset.typeId)) || 0).toFixed(2);
            });
            state.wagesDraftTouched = true;
            const totals = result.totals || { A: 0, B: 0, C: 0 };
            const ctc = Number(result.ctc || 0);
            const setText = (id, value) => { const node = document.getElementById(id); if (node) node.textContent = value; };
            setText('wagesTotalALabel', `Total A: ${formatWageCurrency(totals.A)}/mo`);
            setText('wagesTotalBLabel', `Total Deductions B: ${formatWageCurrency(totals.B)}/mo`);
            setText('wagesTotalCLabel', `Total Employer Share C: ${formatWageCurrency(totals.C)}/mo`);
            setText('wagesNetTakeHome', `${formatWageCurrency(result.net_pay)}/month`);
            setText('wagesNetDaily', `${formatWageCurrency(Number(result.net_pay || 0) / 30)}/day (30-day estimate)`);
            setText('wagesPreviewCtc', `${formatWageCurrency(ctc)}/month`);
            setText('wagesTotalCtc', `${formatWageCurrency(ctc)}/month`);
            if (notice) {
                notice.className = 'alert alert-success py-2 small';
                notice.textContent = `Calculated from ${formatWageCurrency(gross)} gross using current Payroll Configuration. Review the preview, then apply the structure.`;
            }
            return result;
        } catch (error) {
            if (calculationVersion !== state.wagesCalculationVersion) return null;
            if (notice) {
                notice.className = 'alert alert-danger py-2 small';
                notice.textContent = `Payroll calculation failed: ${error.message}`;
            }
            throw error;
        }
    }

    function updateWageEmployeeContext() {
        const name = document.getElementById('employeeName')?.value?.trim() || 'New staff member';
        const department = document.getElementById('department');
        const designation = document.getElementById('role_designation');
        const grade = document.getElementById('grade');
        const joiningDate = document.getElementById('dateOfJoining')?.value || '';
        const nameNode = document.getElementById('wagesEmployeeName');
        const initialsNode = document.getElementById('wagesEmployeeInitials');
        const metaNode = document.getElementById('wagesEmployeeMeta');
        if (nameNode) nameNode.textContent = name;
        if (initialsNode) initialsNode.textContent = name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0].toUpperCase()).join('') || 'NS';
        if (metaNode) metaNode.textContent = `New staff · ${designation?.selectedOptions?.[0]?.textContent?.trim() || 'Designation not selected'}`;
        const departmentNode = document.getElementById('wagesDepartment');
        const designationNode = document.getElementById('wagesDesignation');
        const gradeNode = document.getElementById('wagesGrade');
        const joiningNode = document.getElementById('wagesJoiningDate');
        if (departmentNode) departmentNode.textContent = department?.selectedOptions?.[0]?.textContent?.trim() || 'Not selected';
        if (designationNode) designationNode.textContent = designation?.selectedOptions?.[0]?.textContent?.trim() || 'Not selected';
        if (gradeNode) gradeNode.textContent = grade?.selectedOptions?.[0]?.textContent?.trim() || 'Not selected';
        if (joiningNode) joiningNode.textContent = joiningDate || 'Not selected';
    }

    function renderWageModalComponents() {
        const components = state.options?.remuneration_types || [];
        const groups = {
            A: document.getElementById('wagesComponentA'),
            B: document.getElementById('wagesComponentB'),
            C: document.getElementById('wagesComponentC')
        };
        Object.values(groups).forEach(host => {
            if (host) host.innerHTML = `<div class="col-12"><div class="placeholder-glow"><span class="placeholder col-12"></span></div></div>`;
        });
        if (!components.length) {
            Object.entries(groups).forEach(([group, host]) => {
                if (host) host.innerHTML = `<div class="col-12"><div class="alert alert-warning mb-0">No active remuneration types are configured for this component group in Settings.</div></div>`;
            });
            updateWageTotals();
            return;
        }
        for (const [group, host] of Object.entries(groups)) {
            if (!host) continue;
            const rows = components.filter(component => getWageComponentGroup(component) === group);
            host.innerHTML = rows.length
                ? rows.map(component => renderWageComponentCard(component, group)).join('')
                : `<div class="col-12"><p class="small text-muted mb-0">No active Component ${group} types configured.</p></div>`;
        }
        updateWageTotals();
    }

    function initializeWagesModal() {
        const modal = document.getElementById('wagesModal');
        if (!modal || state.wagesModalReady) return;
        state.wagesModalReady = true;
        document.getElementById('hr-add-staff-btn')?.addEventListener('click', () => {
            // A new staff record must never inherit another person's unsaved gross salary.
            state.wagesCalculationVersion += 1;
            state.remunerationDraft = [];
            state.wagesDraftTouched = false;
            const grossInput = document.getElementById('wagesTargetGross');
            if (grossInput) grossInput.value = '';
            const ctcInput = document.getElementById('ctcInput');
            if (ctcInput) ctcInput.value = '';
            const notice = document.getElementById('wagesDraftNotice');
            if (notice) {
                notice.className = 'alert alert-info py-2 small';
                notice.textContent = 'This is a draft for the new staff member. Enter gross salary and apply the structure before saving staff.';
            }
            document.querySelectorAll('#wagesModal .hr-wage-component-amount').forEach(input => { input.value = '0.00'; });
            updateWageTotals();
        });
        modal.addEventListener('show.bs.modal', async () => {
            updateWageEmployeeContext();
            if (!state.options) {
                try {
                    await loadOptions();
                } catch (error) {
                    const notice = document.getElementById('wagesDraftNotice');
                    if (notice) {
                        notice.className = 'alert alert-danger py-2 small';
                        notice.textContent = `Could not load remuneration settings: ${error.message}`;
                    }
                }
            }
            renderWageModalComponents();
        });
        let payrollInputTimer = null;
        document.getElementById('wagesTargetGross')?.addEventListener('input', () => {
            window.clearTimeout(payrollInputTimer);
            payrollInputTimer = window.setTimeout(() => calculateWageStructure().catch(() => {}), 250);
        });
        modal.addEventListener('click', async event => {
            const applyButton = event.target.closest('#wagesApplyStructureBtn');
            if (!applyButton) return;
            event.preventDefault();
            applyButton.disabled = true;
            try {
                const calculated = await calculateWageStructure();
                if (!calculated || Number(calculated.gross_amount || 0) <= 0) {
                    window.alert('Enter a positive monthly gross salary before applying the structure.');
                    return;
                }
                const ctcInput = document.getElementById('ctcInput');
                if (ctcInput) ctcInput.value = Number(calculated.ctc || 0).toFixed(2).replace(/\.00$/, '');
                const notice = document.getElementById('wagesDraftNotice');
                if (notice) {
                    notice.className = 'alert alert-success py-2 small';
                    notice.textContent = `Structure applied. Gross ${formatWageCurrency(calculated.gross_amount)}; CTC ${formatWageCurrency(calculated.ctc)} per month. Save Staff will store the server-calculated breakdown.`;
                }
                if (window.bootstrap) bootstrap.Modal.getOrCreateInstance(modal).hide();
            } catch (error) {
                window.alert(error.message);
            } finally {
                applyButton.disabled = false;
            }
        });
        ['employeeName', 'dateOfJoining'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', updateWageEmployeeContext);
        });
        document.getElementById('dateOfJoining')?.addEventListener('change', () => updateWorkplaceLeaveBalanceConfiguration({ recalculate: true }));
        document.getElementById('dateOfJoining')?.addEventListener('input', () => updateWorkplaceLeaveBalanceConfiguration({ recalculate: true }));
        ['casualLeave', 'paidLeave', 'sickLeave'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', () => updateWorkplaceLeaveBalanceConfiguration({ recalculate: false }));
        });
        ['department', 'role_designation', 'grade'].forEach(id => {
            document.getElementById(id)?.addEventListener('change', updateWageEmployeeContext);
        });
        document.getElementById('monthlyWages')?.addEventListener('click', updateWageEmployeeContext);
    }

    function labelFor(valueNode) {
        const wrapper = valueNode.closest('.col-md-6, .col-md-4, .col-md-3, .col-12, .col-md-12, .col');
        return (wrapper?.querySelector('.employee-label')?.textContent || valueNode.previousElementSibling?.textContent || '').trim().replace(/\s+/g, ' ');
    }
    const coreKeys = {
        'Full Name':'staff_name','Employee Name':'staff_name','Staff Name':'staff_name','Email':'email_id','Phone':'mobile_no','Mobile':'mobile_no',
        'Date of Birth':'dob','Gender':'gender','Marital Status':'martial_status','Address':'address','Residential Address':'residential_address',
        'Date of Joining':'date_of_joining','Date of Exit':'staff_last_date','Department':'department_id','Department / Unit':'department_id',
        'Designation':'designation_id','Role Designation':'designation_id','User Role':'role_id','Blood Group':'blood_group_id','Relation':'relation_id',
        'Alternative Mobile Number':'alternative_no','Alternate Mobile Number':'alternative_no','Emergency Contact Name':'contact_person_name','Emergency Contact Number':'contact_person_no'
    };
    function normalizedValue(key, value) {
        const val = String(value ?? '').trim();
        if (key === 'gender') { const map = {'1':'Male','2':'Female','3':'Other','male':'Male','female':'Female','other':'Other'}; return map[val.toLowerCase()] || val; }
        if (key === 'martial_status') { const map = {'0':'Single','1':'Married','2':'Divorced','3':'Widowed','4':'Other'}; return map[val] || val; }
        return val;
    }
    function setValueByLabel(panel, labelText, value) {
        const label = [...panel.querySelectorAll('.employee-label')].find(el => el.textContent.trim().replace(/\s+/g, ' ') === labelText);
        const valueNode = label?.nextElementSibling;
        if (valueNode?.classList.contains('employee-value')) valueNode.textContent = value === null || value === undefined || value === '' ? '—' : String(value);
    }
    function renderDetail(detail) {
        state.current = detail;
        const avatar = document.getElementById('staffProfilePreview');
        if (avatar) avatar.src = detail.staff_image_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(detail.staff_name || 'Staff')}&background=f8f9fa&color=0d6efd&size=100`;
        const drawer = document.getElementById('employeeDrawer'); if (!drawer) return;
        drawer.dataset.staffId = String(detail.sno || detail.id || ''); drawer.dataset.hrEditing = 'false';
        document.getElementById('employeePhotoEditControl')?.classList.add('d-none');
        const selectedPhoto = document.getElementById('employeeProfilePhoto');
        if (selectedPhoto) selectedPhoto.value = '';
        const header = drawer.querySelector('.offcanvas-header');
        const title = header?.querySelector('h5'); if (title) title.textContent = detail.staff_name || 'Staff profile';
        const spans = header?.querySelectorAll('.d-flex.flex-column > span');
        if (spans?.[0]) spans[0].textContent = detail.designation_name || detail.designation || '—';
        if (spans?.[1]) spans[1].textContent = detail.department_name || '—';
        // Replace all demo text values with saved data (or an em dash) before setting known fields.
        drawer.querySelectorAll('.employee-value').forEach(el => { el.dataset.hrKey = safeLabel(labelFor(el)); el.textContent = '—'; });
        const personal = drawer.querySelector('[data-panel="personal"]');
        if (personal) {
        const gender = normalizedValue('gender', detail.gender);
        const marital = normalizedValue('martial_status', detail.martial_status);
        const map = {'Full Name':detail.staff_name,'Email':detail.email_id,'Phone':detail.mobile_no,'Date of Birth':detail.dob,'Gender':gender,
            'Marital Status':marital,'Address':detail.address,'Residential Address':detail.residential_address,'Alternative Mobile Number':detail.alternative_no,
            'Alternate Mobile Number':detail.alternative_no,'Date of Joining':detail.date_of_joining,'Date of Exit':detail.staff_last_date,'Department':detail.department_name,
            'Department / Unit':detail.department_name,'Designation':detail.designation_name,'Role Designation':detail.designation_name,'User Role':detail.user_role_name};
        Object.entries(map).forEach(([label, value]) => setValueByLabel(personal, label, value));
        const supplemental = detail.profile?.supplemental_fields || {};
        personal.querySelectorAll('.employee-value').forEach(el => { const key = el.dataset.hrKey; if (Object.prototype.hasOwnProperty.call(supplemental, key)) el.textContent = supplemental[key] || '—'; });
        }
        renderEducation(detail.education || []); renderExperience(detail.experience || []); renderFamily(detail.profile?.family_members || []); renderAttachments(detail.attachments || []);
        const remHost = document.getElementById('dynamicRemunerationRows');
        if (remHost) { remHost.innerHTML = ''; (detail.remuneration || []).forEach(x => addRemunerationRow(x)); if (!(detail.remuneration || []).length) addRemunerationRow(); }
        const ctc = document.getElementById('ctcInput'); if (ctc && detail.basic_salary !== undefined) ctc.value = detail.basic_salary || '';
        updateWorkplaceLeaveBalanceConfiguration({ recalculate: true });
    }
    function renderEducation(items) {
        const panel = document.querySelector('[data-panel="education"]'); if (!panel) return;
        panel.querySelectorAll('.education-card[data-hr-generated="1"]').forEach(el => el.remove());
        const addBox = panel.querySelector('.education-add-box');
        (items || []).forEach(item => {
        const card = document.createElement('div'); card.className = 'employee-card education-card mb-3'; card.dataset.hrGenerated = '1';
        const fields = [['Qualification','degree_name',item.degree_name],['Institution','university_name',item.university_name],['Passing Year','year',item.year],['Grade','grade',item.grade]];
        card.innerHTML = `<div class="row g-4">${fields.map(([label, key, value]) => `<div class="col-md-6"><span class="employee-label">${esc(label)}</span><span class="employee-value" data-hr-key="education.${esc(key)}" data-row-key="${esc(key)}">${esc(value || '—')}</span></div>`).join('')}</div>`;
        card.dataset.educationId = item.id || ''; addBox ? panel.insertBefore(card, addBox) : panel.appendChild(card);
        });
    }
    function renderExperience(items) {
        const host = document.getElementById('experienceContainer'); if (!host) return; host.innerHTML = '';
        (items || []).forEach(item => {
        const start = item.start_date ? String(item.start_date).slice(0,4) : '';
        const end = item.end_date ? String(item.end_date).slice(0,4) : '';
        const period = start || end ? [start, end].filter(Boolean).join(' - ') : (item.year_of_experience ? `${item.year_of_experience} years` : '—');
        const card = document.createElement('div'); card.className = 'card mb-3 p-3 position-relative experience-item bg-white'; card.dataset.experienceId = item.id || ''; card.style.border = '1px solid #1e293b'; card.style.borderRadius = '8px';
        card.innerHTML = `<button type="button" class="btn btn-sm btn-outline-danger position-absolute top-0 end-0 m-2 d-none delete-exp-btn py-0 px-1" title="Delete Experience"><i class="mdi mdi-trash-can-outline"></i></button>
            <div class="exp-view-mode"><div class="d-flex justify-content-between align-items-center"><span class="fw-bold exp-view-designation">${esc(item.position || '—')}</span><span class="badge rounded-1 exp-view-duration">${esc(period)}</span></div><div class="exp-view-company">${esc(item.company_name || '—')}</div><div class="exp-view-roles mt-2">${esc(item.responsibilities || item.exit_reason || '—')}</div></div>
            <div class="exp-edit-mode d-none mt-2 pe-4"><div class="row g-2"><div class="col-md-6"><label class="form-label small">Designation</label><input type="text" class="form-control form-control-sm exp-input-designation" value="${esc(item.position || '')}"></div><div class="col-md-6"><label class="form-label small">Company Name</label><input type="text" class="form-control form-control-sm exp-input-company" value="${esc(item.company_name || '')}"></div><div class="col-12"><label class="form-label small">Duration</label><input type="text" class="form-control form-control-sm exp-input-duration" value="${esc(period)}" placeholder="2014 - 2018"></div><div class="col-12"><label class="form-label small">Key Roles & Responsibilities</label><textarea class="form-control form-control-sm exp-input-roles" rows="2">${esc(item.responsibilities || item.exit_reason || '')}</textarea></div></div></div>`;
        host.appendChild(card);
        });
        if (!items.length) host.innerHTML = '<div class="text-muted small py-3">No work experience records saved.</div>';
    }
    function renderFamily(items) {
        const host = document.getElementById('familyContainer') || document.querySelector('[data-panel="family"] #familyContainer');
        if (!host) return;
        host.querySelectorAll('.family-item').forEach(el => el.remove());
        (items || []).forEach(member => {
        const card = document.createElement('div'); card.className = 'family-member-card mb-3 family-item position-relative'; card.dataset.hrFamily = '1';
        card.innerHTML = `<button type="button" class="family-delete-btn d-none position-absolute top-0 end-0 m-3 delete-family-btn" title="Remove Family Member"><i class="mdi mdi-trash-can-outline"></i></button><div class="family-view-mode"><div class="d-flex justify-content-between align-items-start"><div><div class="d-flex align-items-center gap-2 mb-2"><span class="family-member-name family-view-name">${esc(member.name || '—')}</span><span class="family-relation-badge family-view-relation">${esc(member.relation || '—')}</span></div><div class="family-member-details"><span><small>Age:</small> <span class="family-view-age">${esc(member.age || '—')}</span></span><span class="family-divider"></span><span><small>Occupation:</small> <span class="family-view-occupation">${esc(member.occupation || '—')}</span></span></div></div></div></div><div class="family-edit-mode d-none pe-4"><div class="row g-2"><div class="col-md-6"><label class="form-label small">Full Name</label><input type="text" class="form-control form-control-sm family-input-name" value="${esc(member.name || '')}"></div><div class="col-md-6"><label class="form-label small">Relation</label><select class="form-select form-select-sm family-input-relation"><option value="">Select relation</option></select></div><div class="col-md-6"><label class="form-label small">Age</label><input type="number" class="form-control form-control-sm family-input-age" value="${esc(member.age || '')}"></div><div class="col-md-6"><label class="form-label small">Occupation</label><input type="text" class="form-control form-control-sm family-input-occupation" value="${esc(member.occupation || '')}"></div></div></div>`;
        setOptions(card.querySelector('.family-input-relation'), state.options?.relations || [], 'Select relation');
        const relationSelect = card.querySelector('.family-input-relation'); if (relationSelect) { const found = (state.options?.relations || []).find(x => String(x.id) === String(member.relation_id || '')) || (state.options?.relations || []).find(x => String(x.name).toLowerCase() === String(member.relation || '').toLowerCase()); if (found) relationSelect.value = String(found.id); else if (member.relation) { const opt = document.createElement('option'); opt.value = `legacy:${member.relation}`; opt.textContent = member.relation; opt.selected = true; relationSelect.appendChild(opt); } }
        host.appendChild(card);
        });
        if (!items.length) host.innerHTML = '<div class="text-muted small py-3">No family members saved.</div>';
    }
    function renderAttachments(items) {
        const panel = document.querySelector('[data-panel="documents"]'); if (!panel) return;
        let host = panel.querySelector('#hr-attachment-records');
        if (!host) { host = document.createElement('div'); host.id = 'hr-attachment-records'; host.className = 'card p-3'; panel.appendChild(host); }
        host.innerHTML = `<h6 class="fw-bold">Saved staff documents</h6>${(items || []).length ? `<div class="list-group">${items.map(item => `<div class="list-group-item d-flex align-items-center justify-content-between gap-3"><span>${esc(item.document_name || 'Staff document')}</span><small class="text-muted">${esc(String(item.attachment_name || '').split('/').pop())}</small></div>`).join('')}</div>` : '<p class="small text-muted mb-0">No staff documents saved.</p>'}`;
    }
    function toInput(valueNode, key, label) {
        if (!valueNode || valueNode.querySelector('input,select,textarea')) return;
        let value = valueNode.textContent.trim(); if (value === '—') value = '';
        let control;
        const labelKey = coreKeys[label] || '';
        const isDate = ['dob','date_of_joining','staff_last_date'].includes(labelKey);
        if (label === 'Gender') { control = document.createElement('select'); control.innerHTML = '<option value="">Select gender</option><option>Male</option><option>Female</option><option>Other</option>'; control.value = normalizedValue('gender', value); }
        else if (label === 'Marital Status') { control = document.createElement('select'); control.innerHTML = '<option value="">Select marital status</option><option value="0">Single</option><option value="1">Married</option><option value="2">Divorced</option><option value="3">Widowed</option><option value="4">Other</option>'; const marital = {'Single':'0','Married':'1','Divorced':'2','Widowed':'3','Other':'4'}; control.value = marital[value] ?? value; }
        else if (label === 'Blood Group') { control = document.createElement('select'); setOptions(control, state.options?.blood_groups || [], 'Select blood group', state.current?.profile?.blood_group_id); }
        else if (['Relation','Relationship'].includes(label)) { control = document.createElement('select'); setOptions(control, state.options?.relations || [], 'Select relation', state.current?.profile?.relation_id); }
        else if (['Department','Department / Unit'].includes(label)) { control = document.createElement('select'); setOptions(control, state.options?.departments || [], 'Select department', state.current?.department_id); }
        else if (['Designation','Role Designation'].includes(label)) { control = document.createElement('select'); setOptions(control, state.options?.designations || [], 'Select designation', state.current?.designation_id); }
        else if (label === 'User Role') { control = document.createElement('select'); setOptions(control, state.options?.roles || [], 'Select user role', state.current?.role_id); }
        else if (valueNode.tagName.toLowerCase() === 'p' || value.length > 100) { control = document.createElement('textarea'); control.rows = 2; control.value = value; }
        else { control = document.createElement('input'); control.type = isDate ? 'date' : 'text'; control.value = value; }
        control.className = 'form-control form-control-sm employee-edit-input'; control.dataset.hrKey = key; control.dataset.hrLabel = label;
        valueNode.dataset.hrOriginal = valueNode.innerHTML; valueNode.innerHTML = ''; valueNode.appendChild(control);
    }
    function startEditing() {
        const drawer = document.getElementById('employeeDrawer'); if (!drawer || !state.current) return;
        drawer.dataset.hrEditing = 'true'; drawer.classList.add('employee-editing');
        document.getElementById('employeePhotoEditControl')?.classList.remove('d-none');
        drawer.querySelectorAll('.employee-value').forEach(el => toInput(el, el.dataset.hrKey || safeLabel(labelFor(el)), labelFor(el)));
        const title = drawer.querySelector('.offcanvas-header h5'); if (title && !title.querySelector('input')) { const old = title.textContent.trim(); title.dataset.hrOriginal = old; title.innerHTML = `<input class="form-control form-control-sm employee-edit-input" data-hr-key="staff_name" value="${esc(old)}">`; }
        drawer.querySelectorAll('.offcanvas-header .d-flex.flex-column > span').forEach((span,index) => { const old=span.textContent.trim(); span.dataset.hrOriginal=old; const key=index===0?'designation_name':'department_name'; span.innerHTML = `<input class="form-control form-control-sm employee-edit-input" data-hr-key="${key}" value="${esc(old)}">`; });
        drawer.querySelectorAll('.experience-item').forEach(card => { card.querySelector('.exp-view-mode')?.classList.add('d-none'); card.querySelector('.exp-edit-mode')?.classList.remove('d-none'); card.querySelector('.delete-exp-btn')?.classList.remove('d-none'); });
        drawer.querySelectorAll('.family-item').forEach(card => { card.querySelector('.family-view-mode')?.classList.add('d-none'); card.querySelector('.family-edit-mode')?.classList.remove('d-none'); card.querySelector('.delete-family-btn')?.classList.remove('d-none'); });
        document.getElementById('familyAddBox')?.classList.remove('d-none');
        const button = document.getElementById('employeeEditBtn'); const text = document.getElementById('employeeEditText'); const icon = document.getElementById('employeeEditIcon'); if (text) text.textContent='Save'; if (icon) { icon.classList.remove('mdi-pencil-outline'); icon.classList.add('mdi-content-save-outline'); } if (button) button.classList.add('is-saving');
    }
    function readInput(node) { const input = node?.querySelector('input,select,textarea'); return input ? input.value.trim() : (node?.textContent.trim() || ''); }
    function collectPayload() {
        const drawer = document.getElementById('employeeDrawer'); const payload = { profile_data: { supplemental_fields: {} } };
        const labels = drawer.querySelectorAll('.employee-label');
        labels.forEach(labelNode => {
        const label = labelNode.textContent.trim().replace(/\s+/g, ' '); const valueNode = labelNode.nextElementSibling;
        if (!valueNode?.classList.contains('employee-value')) return;
        const value = readInput(valueNode); const key = coreKeys[label];
        if (key) {
            if (['gender','martial_status'].includes(key) || !['department_id','designation_id','role_id','blood_group_id','relation_id'].includes(key)) payload[key] = value;
            else if (value !== '') payload[key] = value;
        } else {
            const extraKey = safeLabel(label); if (extraKey) payload.profile_data.supplemental_fields[extraKey] = value;
        }
        });
        const controls = drawer.querySelectorAll('.employee-edit-input[data-hr-key]');
        controls.forEach(input => {
        const key = input.dataset.hrKey; if (!key || key.startsWith('education.') || key.startsWith('profile.')) return;
        if (['department_id','designation_id','role_id','blood_group_id','relation_id'].includes(key)) { if (input.value !== '') payload[key] = input.value; }
        else if (['staff_name','email_id','mobile_no','dob','gender','martial_status','address','residential_address','date_of_joining','staff_last_date','alternative_no','contact_person_name','contact_person_no'].includes(key)) payload[key] = input.value;
        });
        payload.profile_data.family_members = [...drawer.querySelectorAll('.family-item')].map(card => ({
        name: card.querySelector('.family-input-name')?.value?.trim() || '', relation_id: card.querySelector('.family-input-relation')?.value || '',
        relation: card.querySelector('.family-input-relation')?.selectedOptions?.[0]?.textContent || card.querySelector('.family-input-relation')?.value || '',
        age: card.querySelector('.family-input-age')?.value || '', occupation: card.querySelector('.family-input-occupation')?.value?.trim() || ''
        })).filter(x => x.name || x.relation || x.occupation || x.age);
        payload.education = [...drawer.querySelectorAll('.education-card')].map(card => {
        const out = { qualification_type: 0 };
        card.querySelectorAll('.employee-value[data-row-key]').forEach(el => { out[el.dataset.rowKey] = readInput(el); });
        if (!out.degree_name) { const labelsMap = {}; card.querySelectorAll('.employee-label').forEach(l => labelsMap[l.textContent.trim()] = readInput(l.nextElementSibling)); out.degree_name = labelsMap.Qualification || labelsMap['Degree']; out.university_name = labelsMap.Institution; out.year = labelsMap['Passing Year']; out.grade = labelsMap.Grade; }
        return out;
        }).filter(x => x.degree_name || x.university_name);
        payload.experience = [...drawer.querySelectorAll('.experience-item')].map(card => {
        const period = card.querySelector('.exp-input-duration')?.value?.trim() || '';
        return { position: card.querySelector('.exp-input-designation')?.value?.trim() || '', company_name: card.querySelector('.exp-input-company')?.value?.trim() || '', period, responsibilities: card.querySelector('.exp-input-roles')?.value?.trim() || '' };
        }).filter(x => x.position || x.company_name);
        payload.remuneration = [...drawer.querySelectorAll('.remuneration-row')].map(row => ({ type_id: row.querySelector('.remuneration-type')?.value, amount: row.querySelector('.remuneration-amount')?.value || 0 })).filter(x => x.type_id);
        return payload;
    }
    function appendNestedFormData(formData, value, key) {
        if (value === undefined) return;
        if (value === null) { formData.append(key, ''); return; }
        if (Array.isArray(value)) {
            value.forEach((item, index) => appendNestedFormData(formData, item, `${key}[${index}]`));
            return;
        }
        if (typeof value === 'object' && !(value instanceof File) && !(value instanceof Blob)) {
            Object.entries(value).forEach(([childKey, childValue]) => appendNestedFormData(formData, childValue, key ? `${key}[${childKey}]` : childKey));
            return;
        }
        formData.append(key, String(value));
    }
    async function saveEditing() {
        const drawer = document.getElementById('employeeDrawer');
        const id = drawer?.dataset.staffId;
        if (!id) throw new Error('Staff profile ID is missing.');
        const payload = collectPayload();
        const photoInput = document.getElementById('employeeProfilePhoto');
        const photo = photoInput?.files?.[0];
        let response;
        if (photo) {
            const formData = new FormData();
            appendNestedFormData(formData, payload, '');
            formData.append('_method', 'PATCH');
            formData.append('profile_photo', photo);
            response = await request(`${api}/staff/${id}`, { method: 'POST', body: formData });
        } else {
            response = await request(`${api}/staff/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        }
        const detail = await request(`${api}/staff/${id}`);
        renderDetail(detail.data);
        await loadRows();
        document.getElementById('familyAddBox')?.classList.add('d-none');
        toastr.success(response.message || 'Staff profile saved.');
    }
    function endEditing() {
        const drawer = document.getElementById('employeeDrawer'); if (!drawer) return;
        drawer.dataset.hrEditing = 'false'; drawer.classList.remove('employee-editing');
        document.getElementById('employeePhotoEditControl')?.classList.add('d-none');
        const photoInput = document.getElementById('employeeProfilePhoto');
        if (photoInput) photoInput.value = '';
        drawer.querySelectorAll('.employee-edit-input').forEach(input => { const parent=input.parentElement; if(parent?.classList.contains('employee-value')) parent.textContent=input.value || '—'; });
        const title=drawer.querySelector('.offcanvas-header h5'); if(title?.querySelector('input')) title.textContent=title.querySelector('input').value;
        drawer.querySelectorAll('.offcanvas-header .d-flex.flex-column > span').forEach(span=>{const i=span.querySelector('input');if(i)span.textContent=i.value;});
        drawer.querySelectorAll('.experience-item').forEach(card=>{const d=card.querySelector('.exp-input-designation')?.value||'—',c=card.querySelector('.exp-input-company')?.value||'—',p=card.querySelector('.exp-input-duration')?.value||'—',r=card.querySelector('.exp-input-roles')?.value||'—';const view=card.querySelector('.exp-view-mode');if(view){view.querySelector('.exp-view-designation').textContent=d;view.querySelector('.exp-view-company').textContent=c;view.querySelector('.exp-view-duration').textContent=p;view.querySelector('.exp-view-roles').textContent=r;}card.querySelector('.exp-view-mode')?.classList.remove('d-none');card.querySelector('.exp-edit-mode')?.classList.add('d-none');card.querySelector('.delete-exp-btn')?.classList.add('d-none');});
        drawer.querySelectorAll('.family-item').forEach(card=>{const name=card.querySelector('.family-input-name')?.value||'—',rel=card.querySelector('.family-input-relation')?.selectedOptions?.[0]?.textContent||'—',age=card.querySelector('.family-input-age')?.value||'—',occ=card.querySelector('.family-input-occupation')?.value||'—';const view=card.querySelector('.family-view-mode');if(view){view.querySelector('.family-view-name').textContent=name;view.querySelector('.family-view-relation').textContent=rel;view.querySelector('.family-view-age').textContent=age;view.querySelector('.family-view-occupation').textContent=occ;}card.querySelector('.family-view-mode')?.classList.remove('d-none');card.querySelector('.family-edit-mode')?.classList.add('d-none');card.querySelector('.delete-family-btn')?.classList.add('d-none');});
        document.getElementById('familyAddBox')?.classList.add('d-none');
        const button=document.getElementById('employeeEditBtn'),text=document.getElementById('employeeEditText'),icon=document.getElementById('employeeEditIcon'); if(text)text.textContent='Edit';if(icon){icon.classList.remove('mdi-content-save-outline');icon.classList.add('mdi-pencil-outline');}if(button)button.classList.remove('is-saving');
    }
    function buildCreatePayload() {
        const form = document.getElementById('staffForm'); const data = new FormData();
        const map = {employeeName:'staff_name',employeeDob:'dob',employeeGender:'gender',employeeMaritalStatus:'martial_status',employeeMobile:'mobile_no',employeeAltMobile:'alternative_no',employeeEmail:'email_id',dateOfJoining:'date_of_joining',dateOfExit:'staff_last_date',employeeAddress:'address',department:'department_id',role_designation:'designation_id',user_role:'role_id',bloodGroup:'blood_group_id',isLoginRequired:'login_access',loginUsername:'username',loginPin:'login_pin',casualLeave:'casual_leave',paidLeave:'paid_leave',sickLeave:'sick_leave'};
        Object.entries(map).forEach(([id,key])=>{const el=document.getElementById(id);if(!el)return;if(el.type==='checkbox')data.append(key,el.checked?'1':'0');else if(el.value!=='')data.append(key,el.value);});
        const relation = form?.querySelector('select[name*="[relation]"]'); if(relation?.value) data.append('relation_id', relation.value);
        const languages = document.getElementById('languages'); if(languages) [...languages.selectedOptions].forEach(option=>{if(option.value)data.append('languages[]',option.value);});
        const photo=document.getElementById('profilePhoto')?.files?.[0]; if(photo)data.append('profile_photo',photo);
        const grossInput = document.getElementById('wagesTargetGross');
        if (state.wagesDraftTouched && grossInput && Number(grossInput.value || 0) > 0) {
            // Gross is the only salary input accepted from the browser. The server recalculates every component.
            data.append('gross_amount', grossInput.value);
        }
        const extra={}; form?.querySelectorAll('input[id],select[id],textarea[id]').forEach(el=>{if(!Object.prototype.hasOwnProperty.call(map,el.id)&&el.id!=='ctcInput'&&el.id!=='languages'&&el.id!=='profilePhoto'&&el.type!=='file'&&el.value)extra[safeLabel(el.id)]=el.value;});
        Object.entries(extra).forEach(([key, value]) => data.append(`profile_data[supplemental_fields][${key}]`, value));
        return data;
    }
    function localDateToday() {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, '0');
        const day = String(today.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    function openExitModal(employeeId) {
        const modalElement = document.getElementById('employeeExitModal');
        const employeeIdInput = document.getElementById('exit_employee_id');
        const exitDateInput = document.getElementById('exit_date');
        const exitRemarkInput = document.getElementById('exit_remark');
        if (!modalElement || !employeeIdInput || !exitDateInput || !exitRemarkInput) {
            toastr.error('The employee exit form is not available. Please reload this page.');
            return;
        }
        employeeIdInput.value = employeeId;
        exitDateInput.value = localDateToday();
        exitRemarkInput.value = '';
        bootstrap.Modal.getOrCreateInstance(modalElement).show();
    }

    async function updateEmployeeStatus(employeeId, status, exitDate = null, remark = null) {
        const statusCode = status === 'Exit' ? 3 : status === 'Inactive' ? 1 : status === 'Active' ? 0 : Number(status);
        const payload = { status: statusCode };
        if (statusCode === 3) {
            payload.staff_last_date = exitDate;
            payload.exit_reason = remark;
        }
        const result = await request(`${api}/staff/${employeeId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        state.page = Math.max(1, state.page);
        await loadRows();
        return result;
    }

    async function confirmEmployeeExit() {
        const employeeId = document.getElementById('exit_employee_id')?.value;
        const exitDate = document.getElementById('exit_date')?.value;
        const remark = document.getElementById('exit_remark')?.value.trim();
        const confirmButton = document.getElementById('confirmEmployeeExit');
        const modalElement = document.getElementById('employeeExitModal');
        if (!employeeId) {
            toastr.error('Please select a staff member first.');
            return;
        }
        if (!exitDate) {
            toastr.error('Please select the Date of Exit.');
            document.getElementById('exit_date')?.focus();
            return;
        }
        if (!remark) {
            toastr.error('Please enter the exit remark.');
            document.getElementById('exit_remark')?.focus();
            return;
        }

        if (confirmButton) {
            confirmButton.disabled = true;
            confirmButton.dataset.originalText = confirmButton.textContent.trim();
            confirmButton.textContent = 'Saving...';
        }
        try {
            const result = await updateEmployeeStatus(employeeId, 'Exit', exitDate, remark);
            bootstrap.Modal.getInstance(modalElement)?.hide();
            document.getElementById('employeeExitForm')?.reset();
            toastr.success(result.message || 'Employee exit details saved.');
        } catch (error) {
            toastr.error(error.message || 'Unable to update employee exit status.');
        } finally {
            if (confirmButton) {
                confirmButton.disabled = false;
                confirmButton.textContent = confirmButton.dataset.originalText || 'Confirm Exit';
            }
        }
    }

    async function handleHrDocumentClick(event) {
        const editButton = event.target.closest('#employeeEditBtn');
        if (editButton) {
            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation();
            const drawer = document.getElementById('employeeDrawer');
            if (drawer?.dataset.hrEditing === 'true') {
                editButton.disabled = true;
                try {
                    await saveEditing();
                    endEditing();
                } catch (error) {
                    toastr.error(error.message);
                } finally {
                    editButton.disabled = false;
                }
            } else {
                startEditing();
            }
            return;
        }

        const statusOption = event.target.closest('.employee-status-option');
        if (statusOption) {
            event.preventDefault();
            event.stopPropagation();
            const employeeId = statusOption.dataset.employeeId;
            const status = statusOption.dataset.status;
            if (!employeeId || !status) return;
            if (status === 'Exit') {
                openExitModal(employeeId);
                return;
            }
            try {
                await updateEmployeeStatus(employeeId, status);
            } catch (error) {
                toastr.error(error.message || 'Unable to update employee status.');
            }
            return;
        }

        const legacyStatusButton = event.target.closest('.staff-status');
        if (legacyStatusButton) {
            event.preventDefault();
            const employeeId = legacyStatusButton.dataset.id;
            const statusCode = Number(legacyStatusButton.dataset.status);
            if (statusCode === 3) {
                openExitModal(employeeId);
                return;
            }
            try {
                await updateEmployeeStatus(employeeId, statusCode === 1 ? 'Inactive' : 'Active');
            } catch (error) {
                toastr.error(error.message || 'Unable to update employee status.');
            }
            return;
        }

        const deleteButton = event.target.closest('.staff-delete');
        if (deleteButton && confirm('Move this staff record to deleted status?')) {
            try {
                await request(`${api}/staff/${deleteButton.dataset.id}`, { method: 'DELETE' });
                await loadRows();
            } catch (error) {
                toastr.error(error.message || 'Unable to delete staff record.');
            }
            return;
        }

        const staffOpen = event.target.closest('.staff-open');
        if (staffOpen) {
            try {
                const result = await request(`${api}/staff/${staffOpen.dataset.id}`);
                renderDetail(result.data);
                bootstrap.Offcanvas.getOrCreateInstance(document.getElementById('employeeDrawer')).show();
            } catch (error) {
                toastr.error(error.message || 'Unable to load the staff profile.');
            }
            return;
        }

        const departmentButton = event.target.closest('.dept-filter-btn');
        if (departmentButton) {
            document.querySelectorAll('.dept-filter-btn').forEach(button => button.classList.toggle('active', button === departmentButton));
            state.department_id = departmentButton.dataset.department === 'ALL' ? '' : (departmentButton.dataset.departmentId || '');
            state.page = 1;
            loadRows();
        }
    }

    let staffDirectoryInitialized = false;

    async function initializeStaffDirectory() {
        if (staffDirectoryInitialized) return;
        staffDirectoryInitialized = true;
        try {
            await loadOptions();
        } catch (error) {
            console.error('HR settings dropdowns failed:', error);
        }
        await loadRows();

        const search = document.getElementById('hr-search-field');
        let searchTimer = null;
        if (search) {
            search.addEventListener('input', () => {
                clearTimeout(searchTimer);
                searchTimer = setTimeout(() => {
                    state.search = search.value.trim();
                    state.page = 1;
                    loadRows();
                }, 300);
            });
        }

        document.querySelectorAll('#staff-table thead th').forEach((header, index) => {
            header.style.cursor = 'pointer';
            header.title = 'Click to sort';
            header.addEventListener('click', event => {
                if (event.target.closest('button, a, input, select')) return;
                const sortKeys = ['name', 'designation', 'department', 'wage', 'status'];
                const sortKey = sortKeys[index] || 'name';
                state.direction = state.sort === sortKey && state.direction === 'asc' ? 'desc' : 'asc';
                state.sort = sortKey;
                state.page = 1;
                loadRows();
            });
        });

        const form = document.getElementById('staffForm');
        document.getElementById('saveStaff')?.addEventListener('click', () => form?.requestSubmit());
        if (form) {
            form.addEventListener('submit', async event => {
                event.preventDefault();
                const grossInput = document.getElementById('wagesTargetGross');
                if (!state.wagesDraftTouched || !grossInput || Number(grossInput.value || 0) <= 0) {
                    toastr.error('Open Wages, enter a monthly gross salary, apply the calculated structure, then save staff.');
                    return;
                }
                const button = document.getElementById('saveStaff');
                if (button) {
                    button.disabled = true;
                    button.dataset.oldText = button.textContent;
                    button.textContent = 'Saving...';
                }
                try {
                    const result = await request(`${api}/staff/${type}`, { method: 'POST', body: buildCreatePayload() });
                    toastr.success(result.message || 'Staff created successfully.');
                    form.reset();
                    state.remunerationDraft = [];
                    state.wagesDraftTouched = false;
                    const wagesGrossInput = document.getElementById('wagesTargetGross');
                    if (wagesGrossInput) wagesGrossInput.value = '';
                    const ctcInput = document.getElementById('ctcInput');
                    if (ctcInput) ctcInput.value = '';
                    document.getElementById('loginCredentialFields')?.classList.add('d-none');
                    const wagesNotice = document.getElementById('wagesDraftNotice');
                    if (wagesNotice) {
                        wagesNotice.className = 'alert alert-info py-2 small';
                        wagesNotice.textContent = 'This is a draft for the new staff member. The structure is stored when you click Save Staff.';
                    }
                    bootstrap.Offcanvas.getInstance(document.getElementById('staffDrawer'))?.hide();
                    state.page = 1;
                    await loadRows();
                } catch (error) {
                    toastr.error(error.message || 'Unable to create staff.');
                } finally {
                    if (button) {
                        button.disabled = false;
                        button.textContent = button.dataset.oldText || 'Save Staff';
                    }
                }
            });
        }

        document.getElementById('profilePhoto')?.addEventListener('change', event => {
            const file = event.target.files?.[0];
            if (!file) return;
            const url = URL.createObjectURL(file);
            const image = document.getElementById('avatarImage');
            if (image) image.src = url;
        });

        document.getElementById('employeeProfilePhoto')?.addEventListener('change', event => {
            const file = event.target.files?.[0];
            if (!file) return;
            if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
                event.target.value = '';
                toastr.error('Choose a JPG, PNG or WEBP image.');
                return;
            }
            if (file.size > 5 * 1024 * 1024) {
                event.target.value = '';
                toastr.error('Profile photo must be 5 MB or smaller.');
                return;
            }
            const url = URL.createObjectURL(file);
            const image = document.getElementById('staffProfilePreview');
            if (image) image.src = url;
        });

        document.getElementById('employeeDrawer')?.addEventListener('hidden.bs.offcanvas', () => {
            const drawer = document.getElementById('employeeDrawer');
            if (drawer?.dataset.hrEditing === 'true') {
                const id = drawer.dataset.staffId;
                drawer.dataset.hrEditing = 'false';
                if (id) request(`${api}/staff/${id}`).then(result => renderDetail(result.data)).catch(() => {});
            }
        });

        document.getElementById('confirmEmployeeExit')?.addEventListener('click', confirmEmployeeExit);
        document.getElementById('employeeExitForm')?.addEventListener('submit', event => {
            event.preventDefault();
            confirmEmployeeExit();
        });
    }

    document.addEventListener('click', handleHrDocumentClick, true);
    document.addEventListener('DOMContentLoaded', initializeStaffDirectory);
    if (document.readyState !== 'loading') initializeStaffDirectory();

</script>


<script>
    const hrClassCsrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

    function hrClassEscape(value) {
        return String(value ?? '').replace(/[&<>"']/g, character => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        })[character]);
    }

    async function hrClassRequest(url, options = {}) {
        const response = await fetch(url, {
            credentials: 'same-origin',
            ...options,
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                ...(hrClassCsrf ? { 'X-CSRF-TOKEN': hrClassCsrf } : {}),
                ...(options.headers || {}),
            },
        });
        const body = await response.json().catch(() => ({}));
        if (!response.ok || body.success === false) {
            throw new Error(body.message || Object.values(body.errors || {}).flat()[0] || `Request failed (${response.status}).`);
        }
        return body;
    }

    async function loadUnclassifiedStaff() {
        const modal = document.getElementById('hrUnclassifiedModal');
        const target = modal?.querySelector('#hrUnclassifiedBody');
        if (!modal || !target) return;
        target.innerHTML = `<div class="placeholder-glow"><span class="placeholder col-12 mb-2"></span><span class="placeholder col-10"></span></div>`;
        try {
            const result = await hrClassRequest('/admin-hr/api/staff/unclassified?per_page=100');
            const rows = result.data || [];
            target.innerHTML = rows.length ? `
                <div class="table-responsive">
                    <table class="table table-sm align-middle">
                        <thead><tr><th>Staff</th><th>Department</th><th>Designation</th><th>Assign employment</th></tr></thead>
                        <tbody>${rows.map(row => `
                            <tr>
                                <td><strong>${hrClassEscape(row.name)}</strong><small class="d-block text-muted">${hrClassEscape(row.staff_id || '')}</small></td>
                                <td>${hrClassEscape(row.department || '—')}</td>
                                <td>${hrClassEscape(row.designation || '—')}</td>
                                <td><div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-primary" data-classify="permanent" data-id="${hrClassEscape(row.id)}">Permanent</button>
                                    <button type="button" class="btn btn-outline-success" data-classify="contract" data-id="${hrClassEscape(row.id)}">Contract</button>
                                </div></td>
                            </tr>`).join('')}
                        </tbody>
                    </table>
                </div>` : `<div class="alert alert-success mb-0">All existing staff have a verified employment category.</div>`;

            target.querySelectorAll('[data-classify]').forEach(button => {
                button.addEventListener('click', async () => {
                    button.disabled = true;
                    try {
                        await hrClassRequest(`/admin-hr/api/staff/${button.dataset.id}/employment-type`, {
                            method: 'PATCH',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ employment_type: button.dataset.classify }),
                        });
                        await loadUnclassifiedStaff();
                        document.dispatchEvent(new CustomEvent('hr:staff-category-updated'));
                    } catch (error) {
                        toastr.error(error.message || 'Unable to assign employment type.');
                        button.disabled = false;
                    }
                });
            });
        } catch (error) {
            target.innerHTML = `<div class="alert alert-danger">${hrClassEscape(error.message)}</div>`;
        }
    }

    function initializeLegacyStaffClassification() {
        const anchor = document.getElementById('hr-add-staff-btn');
        if (!anchor || document.getElementById('hr-unclassified-btn')) return;

        const button = document.createElement('button');
        button.type = 'button';
        button.id = 'hr-unclassified-btn';
        button.className = anchor.className.replace('text-white', 'text-primary').replace('shadow-sm', '').replace('border-0', 'border');
        button.classList.add('w-100');
        button.style.cssText = 'width:100%;height:40px;margin-top:6px;background:#f8fafc;color:#0C3C62;border:1px solid #cbd5e1;font-size:.76rem;white-space:nowrap;';
        button.innerHTML = `<span>Classify Legacy Staff</span>`;
        anchor.insertAdjacentElement('afterend', button);

        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.id = 'hrUnclassifiedModal';
        modal.tabIndex = -1;
        modal.setAttribute('aria-hidden', 'true');
        modal.innerHTML = `
            <div class="modal-dialog modal-lg modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Classify Existing Staff</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p class="small text-muted">Staff without a verified Permanent/Contract category are not guessed from the legacy management/business field. Assign a category based on HR records.</p>
                        <div id="hrUnclassifiedBody"><span class="placeholder col-12"></span></div>
                    </div>
                    <div class="modal-footer"><button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button></div>
                </div>
            </div>`;
        document.body.appendChild(modal);

        button.addEventListener('click', () => {
            bootstrap.Modal.getOrCreateInstance(modal).show();
            loadUnclassifiedStaff();
        });
        document.addEventListener('hr:staff-category-updated', () => {
            const search = document.getElementById('hr-search-field');
            if (search) search.dispatchEvent(new Event('input'));
        });
    }

    let legacyClassificationInitialized = false;
    function bootLegacyStaffClassification() {
        if (legacyClassificationInitialized) return;
        legacyClassificationInitialized = true;
        // initializeLegacyStaffClassification();
    }
    document.addEventListener('DOMContentLoaded', bootLegacyStaffClassification);
    if (document.readyState !== 'loading') bootLegacyStaffClassification();
</script>

<script>
        function mobile_chk(val) {
            if (val != "") {
                $.ajaxSetup({
                    headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
                });

                $.ajax({
                    url: "{{ route('checkStaffMobileExists') }}",
                    type: 'POST',
                    data: { mobile: val },
                    dataType: 'json',
                    success: function(response) {
                        console.log(response);
                        if (response.data !== 0) {
                            $('#employeeMobile_err').text('Mobile Number is already assigned!');
                            toastr.error('Mobile Number is already assigned!');
                            $('#employeeMobile').addClass('err_border');
                            $('#saveStaff').prop('disabled', true);
                        } else {
                            $('#employeeMobile_err').text('');
                            $('#employeeMobile').removeClass('err_border');
                            $('#saveStaff').prop('disabled', false);
                        }
                    },
                    error: function() {
                        $('#saveStaff').prop('disabled', true);
                        
                    }
                });
            }
        }
    </script>
@endsection
