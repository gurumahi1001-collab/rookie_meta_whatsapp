-- Additive HR Leave / Attendance / Payroll enhancement migration
-- Target: MariaDB 10.4+ (database: ryans_infra)
-- Safe to re-run. Back up the database before applying to production.
-- Do NOT re-import the complete database dump to deploy these changes.

USE `ryans_infra`;

-- Leave request full/half day support (older installations only).
SET @hr_leave_mode_sql = IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ryans_leave_requests' AND COLUMN_NAME = 'leave_mode') = 0,
    'ALTER TABLE `ryans_leave_requests` ADD COLUMN `leave_mode` VARCHAR(20) NOT NULL DEFAULT ''full'' AFTER `days`',
    'SELECT ''ryans_leave_requests.leave_mode already exists'' AS migration_status'
);
PREPARE hr_leave_mode_stmt FROM @hr_leave_mode_sql;
EXECUTE hr_leave_mode_stmt;
DEALLOCATE PREPARE hr_leave_mode_stmt;

SET @hr_attendance_mode_sql = IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ryans_staff_attendance' AND COLUMN_NAME = 'leave_mode') = 0,
    'ALTER TABLE `ryans_staff_attendance` ADD COLUMN `leave_mode` VARCHAR(20) NULL DEFAULT NULL AFTER `time_end`',
    'SELECT ''ryans_staff_attendance.leave_mode already exists'' AS migration_status'
);
PREPARE hr_attendance_mode_stmt FROM @hr_attendance_mode_sql;
EXECUTE hr_attendance_mode_stmt;
DEALLOCATE PREPARE hr_attendance_mode_stmt;

-- Persist gross separately from legacy basic_salary (which continues to represent monthly CTC in this feature).
SET @hr_gross_salary_sql = IF(
    (SELECT COUNT(*) FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ryans_staff' AND COLUMN_NAME = 'gross_salary') = 0,
    'ALTER TABLE `ryans_staff` ADD COLUMN `gross_salary` DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER `basic_salary`',
    'SELECT ''ryans_staff.gross_salary already exists'' AS migration_status'
);
PREPARE hr_gross_salary_stmt FROM @hr_gross_salary_sql;
EXECUTE hr_gross_salary_stmt;
DEALLOCATE PREPARE hr_gross_salary_stmt;

-- Ensure Basic Salary is identified as an earning without changing its existing description or amounts.
UPDATE `ryans_renumeration_type`
SET `component_type` = 'earning', `updated_at` = CURRENT_DATE(), `updated_by` = 1
WHERE LOWER(TRIM(`renumeration_name`)) = 'basic salary'
  AND `status` = 0
  AND TRIM(COALESCE(`component_type`, '')) = '';

-- Seed the common payroll components only when no row of that name already exists.
-- Component names and rates remain editable through the new Payroll Configuration screen.
INSERT INTO `ryans_renumeration_type`
    (`renumeration_name`, `component_type`, `renumeration_desc`, `created_by`, `updated_by`, `created_at`, `updated_at`, `status`)
SELECT seed.`renumeration_name`, seed.`component_type`, seed.`renumeration_desc`, 1, 1, CURRENT_DATE(), CURRENT_DATE(), 0
FROM (
    SELECT 'House Rent Allowance (HRA)' AS `renumeration_name`, 'earning' AS `component_type`, 'Configurable earning component allocated from monthly gross.' AS `renumeration_desc`
    UNION ALL SELECT 'Dearness Allowance (DA)', 'earning', 'Configurable earning component allocated from monthly gross.'
    UNION ALL SELECT 'Special Allowance', 'earning', 'Configurable balancing or percentage earning component.'
    UNION ALL SELECT 'Employee Provident Fund (PF)', 'detection', 'Employee PF deduction; rate, wage base and ceiling are configurable.'
    UNION ALL SELECT 'Employee State Insurance (ESI)', 'detection', 'Employee ESI deduction; rate and wage eligibility threshold are configurable.'
    UNION ALL SELECT 'TDS', 'detection', 'Configured monthly TDS preview only; not a statutory annual income-tax calculation.'
    UNION ALL SELECT 'Professional Tax', 'detection', 'State-specific professional tax; configure only if applicable.'
    UNION ALL SELECT 'Employer PF Contribution', 'employer_contribution', 'Employer PF cost component; rate and contribution base are configurable.'
    UNION ALL SELECT 'Employer ESI Contribution', 'employer_contribution', 'Employer ESI cost component; rate and wage eligibility threshold are configurable.'
) AS seed
WHERE NOT EXISTS (
    SELECT 1 FROM `ryans_renumeration_type` existing_type
    WHERE LOWER(TRIM(existing_type.`renumeration_name`)) = LOWER(TRIM(seed.`renumeration_name`))
);

-- Component-level payroll rules. No FK is used intentionally because legacy remuneration type ids
-- are maintained by existing Settings workflows; the application validates active component ids.
CREATE TABLE IF NOT EXISTS `ryans_payroll_component_rules` (
    `sno` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `remuneration_type_id` INT NOT NULL,
    `calculation_method` VARCHAR(40) NOT NULL DEFAULT 'none',
    `rate` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
    `base_component_id` INT DEFAULT NULL,
    `threshold_amount` DECIMAL(14,2) DEFAULT NULL,
    `wage_ceiling` DECIMAL(14,2) DEFAULT NULL,
    `cap_amount` DECIMAL(14,2) DEFAULT NULL,
    `enabled` TINYINT(1) NOT NULL DEFAULT 1,
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_by` BIGINT UNSIGNED DEFAULT NULL,
    `updated_by` BIGINT UNSIGNED DEFAULT NULL,
    `created_at` DATETIME DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`sno`),
    UNIQUE KEY `uk_ryans_payroll_component_type` (`remuneration_type_id`),
    KEY `idx_ryans_payroll_component_enabled` (`enabled`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The current database has a Basic Salary earning. Set it to absorb the remaining gross amount
-- until HR configures a more detailed Component A split in the Payroll Configuration modal.
INSERT INTO `ryans_payroll_component_rules`
    (`remuneration_type_id`, `calculation_method`, `rate`, `enabled`, `sort_order`, `created_by`, `updated_by`, `created_at`, `updated_at`)
SELECT rt.`sno`, 'remainder', 0.0000, 1, rt.`sno`, 1, 1, NOW(), NOW()
FROM `ryans_renumeration_type` rt
WHERE rt.`status` = 0
  AND LOWER(rt.`renumeration_name`) LIKE '%basic%'
  AND NOT EXISTS (
      SELECT 1 FROM `ryans_payroll_component_rules` existing_rule
      WHERE existing_rule.`remuneration_type_id` = rt.`sno`
  );

-- Existing rows remain intact. Leave-cycle service owns joining-anniversary ledger/carry-forward rules.
-- PR and OD continue using the existing time_start/time_end columns for start/end time.
-- PF/ESI suggestions are editable; TDS is a monthly rate/threshold preview, not a full annual tax engine.
