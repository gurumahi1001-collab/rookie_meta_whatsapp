# HR Leave, Attendance & Gross-Based Payroll — Deployment Notes

## Bundle contents
- `hr_leave_attendance_production_patch.zip`: changed/new Laravel-relative files compared with the supplied MVC source, plus this note and the SQL migration.
- `updated_mvc_leave_attendance_enhancements.zip`: current `app/`, `resources/`, and `routes/` subtree with the new changes applied, plus this note and the SQL migration.
- `hr_leave_attendance_enhancements.sql`: additive, rerunnable MariaDB migration.

## Deployment
1. Take a full database backup and back up the existing files that the patch replaces.
2. The source ZIP supplied to this task contains only `app/`, `resources/`, and `routes/`, not a full Laravel root (`artisan`, `composer.json`, or `vendor/`). These archives are overlays for your existing full Laravel project, not standalone Laravel installs.
3. Read the SQL script. It currently selects `ryans_infra`; change `USE` to the production schema name if needed. Apply the SQL migration once against the intended DB (it is guarded to be re-runnable).
4. Extract the patch over the Laravel application root, preserving the relative paths. Review the deployment diff before replacing files.
5. From your actual full Laravel root, run `php artisan optimize:clear` and your normal cache/deployment commands. Run route/view smoke tests in staging before production.

## Changed behavior
- Leave policy save normalizes stable keys and historical label variants for Casual, Paid and Sick. If a cached older Blade/JS bundle sends duplicated legacy display labels, the fixed three-field settings form is normalized by its CL/PL/SL field order rather than incorrectly rejecting the save. Annual quotas remain staff-category-specific; carry-forward caps remain shared between permanent and contract staff.
- Staff Add leave quotas can be edited. The live preview updates for date of joining and quota edits. The initial calendar-year allocation is prorated as `annual quota × eligible days from joining date through 31 December ÷ days in that calendar year`; prior joining years use the full annual quota and a future joining year previews zero for the current year. The anniversary cycle remains visible separately.
- Attendance Leave now collects a separate required reason after Leave Mode; the leave type is persisted as the attendance type rather than misused as the reason.
- Payroll Configuration is added to both Wages screens. Admins can configure earnings, employee deductions and employer contribution components using gross percentage, percentage of Basic/another selected component, fixed amount, PF/ESI formulas, TDS percentage preview, remainder or no calculation. Dependent earnings are calculated after their selected base; circular formulas that depend on a Remainder component are rejected with a clear validation message. The Wages menu takes monthly gross as input and calculates the breakdown server-side before saving. In Staff Add, the CTC field is read-only and derived from calculated gross plus employer contributions; the browser does not submit manually edited component values.
- `gross_salary` is stored separately. Legacy `basic_salary` retains its existing column and is updated to monthly CTC (gross + employer contributions) for the new gross-based workflow.

## Payroll configuration caveats
- The SQL marks the existing Basic Salary type as an earning when its component type is blank, seeds common HRA, DA and Special Allowance earnings, employee PF/ESI/TDS/Professional Tax deduction types, and employer PF/ESI contribution types only when an exact component name does not already exist. It seeds Basic Salary as `Remainder`; additional earning components default to 0% until HR configures the earning split. All component classifications, percentages, thresholds, caps and enabled states remain editable in Payroll Configuration.
- PF/ESI initial values (where the component name allows inference) are editable suggestions, not universal legal applicability rules. The current suggested PF/ESI rates and caps are defaults only; verify the wage base, establishment eligibility, caps, state and current notifications before enabling them in production. `Professional Tax` defaults to no calculation because state slabs and eligibility vary; configure it only under the applicable state rule.
- TDS is a configured monthly rate/threshold preview only. It does not compute a statutory annual Indian tax projection from tax regime, annual income, declarations, exemptions, or employee investment data. Do not treat it as a full tax-compliance engine.
- The component configuration is effective for calculation after the SQL migration creates `ryans_payroll_component_rules` and the full app deploys the matching routes/service. Apply the migration before exposing the new payroll endpoints.

## Staging smoke tests
- Save leave settings with new CL/Paid/SL amounts and carry-forward caps in both permanent and contract pages. Confirm no duplicate-category alert and verify the same carry-forward limits on the other staff category.
- Add/edit a staff member: change Date of Joining and each leave quota; check prorata previews update immediately and that the saved current-year allocation matches the preview.
- Attendance: save Leave with Full/First half/Second half and a reason; verify after reload. Also test Permission and On Duty start time/end time/reason.
- Payroll: open Payroll Configuration, save a Basic Salary remainder rule and (if available) add/configure earning, PF, ESI and TDS types. Enter a gross salary, verify Components A total equals gross, Component B deductions do not exceed gross, net pay equals A − B, CTC equals A + C, then save and reload.
- Verify existing staff without saved remuneration rows retain their prior values until an admin deliberately saves a new gross-driven structure.
- Verify staff photo editing, existing staff profile data, Leave Management filters/review, attendance matrix, and ordinary wage list navigation.

## Validation limits
PHP syntax checks passed for 25 changed/new PHP and Blade files. Fourteen standalone JavaScript blocks passed Node syntax checks; four staff-view blocks contain Blade expressions and need Laravel rendering for runtime validation. ZIP integrity checks passed. Full Laravel route execution, rendered-view tests, database migration execution and payroll acceptance against your live DB cannot be run here because the provided archive has no Laravel root/dependencies and no live database connection was supplied.

## Data safety
Do not import the full database dump for deployment; use only the additive SQL. The uploaded database dump contains personal access-token/login data. Keep it private and rotate tokens if it was shared outside trusted access.
