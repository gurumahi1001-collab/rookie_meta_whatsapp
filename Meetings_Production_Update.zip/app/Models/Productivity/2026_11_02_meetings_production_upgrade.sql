-- Meetings production upgrade
-- Run once against the existing application database before deploying the PHP files.
-- Existing egc_tool_meetings rows and the legacy `category` text column are preserved.

CREATE TABLE IF NOT EXISTS egc_tool_meeting_categories (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    category_name VARCHAR(160) NOT NULL,
    color VARCHAR(7) NOT NULL DEFAULT '#51439A',
    description VARCHAR(500) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    status TINYINT NOT NULL DEFAULT 0 COMMENT '0=Active, 1=Inactive',
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_meeting_category_company (company_id, status, deleted_at),
    KEY idx_meeting_category_name (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_tool_meeting_teams (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    company_id BIGINT UNSIGNED NULL,
    team_name VARCHAR(160) NOT NULL,
    description VARCHAR(500) NULL,
    status TINYINT NOT NULL DEFAULT 0 COMMENT '0=Active, 1=Inactive',
    created_by BIGINT UNSIGNED NULL,
    updated_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,
    PRIMARY KEY (sno),
    KEY idx_meeting_team_company (company_id, status, deleted_at),
    KEY idx_meeting_team_name (team_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_tool_meeting_team_members (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    team_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_meeting_team_member (team_id, user_id),
    KEY idx_meeting_team_member_user (user_id, team_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_tool_meeting_team_map (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    meeting_id BIGINT UNSIGNED NOT NULL,
    team_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_meeting_team_map (meeting_id, team_id),
    KEY idx_meeting_team_map_team (team_id, meeting_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_tool_meeting_department_map (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    meeting_id BIGINT UNSIGNED NOT NULL,
    department_id BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    UNIQUE KEY uq_meeting_department_map (meeting_id, department_id),
    KEY idx_meeting_department_map_department (department_id, meeting_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS egc_tool_meeting_attachments (
    sno BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    meeting_id BIGINT UNSIGNED NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    storage_path VARCHAR(1000) NOT NULL,
    mime_type VARCHAR(150) NULL,
    file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
    uploaded_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (sno),
    KEY idx_meeting_attachment_meeting (meeting_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add new columns only when they are missing (compatible with MySQL/MariaDB versions
-- that do not support ADD COLUMN IF NOT EXISTS).
SET @meeting_column_exists = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'egc_tool_meetings' AND COLUMN_NAME = 'category_id'
);
SET @meeting_sql = IF(@meeting_column_exists = 0,
    'ALTER TABLE egc_tool_meetings ADD COLUMN category_id BIGINT UNSIGNED NULL AFTER category',
    'SELECT 1');
PREPARE meeting_stmt FROM @meeting_sql; EXECUTE meeting_stmt; DEALLOCATE PREPARE meeting_stmt;

-- The legacy category label remains available for integrations and old screens.
ALTER TABLE egc_tool_meetings MODIFY COLUMN category VARCHAR(160) NULL;

SET @meeting_column_exists = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'egc_tool_meetings' AND COLUMN_NAME = 'reminder_sent_at'
);
SET @meeting_sql = IF(@meeting_column_exists = 0,
    'ALTER TABLE egc_tool_meetings ADD COLUMN reminder_sent_at DATETIME NULL AFTER reminder_minutes',
    'SELECT 1');
PREPARE meeting_stmt FROM @meeting_sql; EXECUTE meeting_stmt; DEALLOCATE PREPARE meeting_stmt;

SET @meeting_column_exists = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'egc_tool_meetings' AND COLUMN_NAME = 'cancellation_reason'
);
SET @meeting_sql = IF(@meeting_column_exists = 0,
    'ALTER TABLE egc_tool_meetings ADD COLUMN cancellation_reason VARCHAR(500) NULL AFTER notes',
    'SELECT 1');
PREPARE meeting_stmt FROM @meeting_sql; EXECUTE meeting_stmt; DEALLOCATE PREPARE meeting_stmt;

SET @meeting_index_exists = (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'egc_tool_meetings' AND INDEX_NAME = 'idx_meeting_category_start'
);
SET @meeting_sql = IF(@meeting_index_exists = 0,
    'ALTER TABLE egc_tool_meetings ADD KEY idx_meeting_category_start (category_id, start_at)',
    'SELECT 1');
PREPARE meeting_stmt FROM @meeting_sql; EXECUTE meeting_stmt; DEALLOCATE PREPARE meeting_stmt;

-- Keep the current rows untouched; this only standardises the default for new records.
ALTER TABLE egc_tool_meetings ALTER COLUMN status SET DEFAULT 'Scheduled';
