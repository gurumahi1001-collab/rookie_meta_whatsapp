<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Throwable;

class SendMeetingReminders extends Command
{
    protected $signature = 'meetings:send-reminders';

    protected $description = 'Send due in-app reminders for scheduled meetings';

    public function handle(): int
    {
        $now = now();
        $ids = DB::table('egc_tool_meetings')
            ->whereNull('deleted_at')
            ->whereNull('reminder_sent_at')
            ->where('reminder_minutes', '>', 0)
            ->where('start_at', '>', $now->toDateTimeString())
            ->whereRaw('DATE_SUB(start_at, INTERVAL reminder_minutes MINUTE) <= ?', [$now->toDateTimeString()])
            ->whereNotIn(DB::raw('LOWER(status)'), ['cancelled', 'completed'])
            ->orderBy('start_at')
            ->limit(200)
            ->pluck('sno');

        $sent = 0;
        foreach ($ids as $meetingId) {
            try {
                $didSend = DB::transaction(function () use ($meetingId) {
                    $meeting = DB::table('egc_tool_meetings')
                        ->where('sno', $meetingId)
                        ->whereNull('deleted_at')
                        ->whereNull('reminder_sent_at')
                        ->whereNotIn(DB::raw('LOWER(status)'), ['cancelled', 'completed'])
                        ->lockForUpdate()
                        ->first(['sno', 'company_id', 'owner_user_id', 'title', 'start_at']);

                    if (!$meeting) return false;

                    $recipients = DB::table('egc_tool_meeting_participants')
                        ->where('meeting_id', $meetingId)
                        ->whereNotNull('user_id')
                        ->pluck('user_id')
                        ->map(fn ($id) => (int) $id)
                        ->all();
                    $recipients[] = (int) $meeting->owner_user_id;
                    $recipients = array_values(array_unique(array_filter($recipients)));

                    if ($recipients) {
                        $time = \Illuminate\Support\Carbon::parse($meeting->start_at)->format('g:i A');
                        $message = 'Your meeting "' . $meeting->title . '" starts at ' . $time . '.';
                        $rows = [];
                        foreach ($recipients as $userId) {
                            $rows[] = [
                                'user_id' => $userId,
                                'company_id' => $meeting->company_id,
                                'module_name' => 'Meetings',
                                'resource_type' => 'meeting',
                                'resource_id' => $meeting->sno,
                                'notification_type' => 'meeting_reminder',
                                'title' => 'Meeting reminder',
                                'message' => $message,
                                'action_url' => '/productivity/meetings',
                                'icon' => 'mdi-calendar-clock',
                                'icon_color' => '#51439A',
                                'is_read' => 0,
                                'created_at' => now(),
                            ];
                        }
                        DB::table('egc_tool_productivity_notifications')->insert($rows);
                    }

                    DB::table('egc_tool_meetings')->where('sno', $meetingId)->update([
                        'reminder_sent_at' => now(),
                        'updated_at' => now(),
                    ]);

                    return true;
                });

                if ($didSend) $sent++;
            } catch (Throwable $exception) {
                report($exception);
                $this->error('Meeting reminder failed for meeting #' . $meetingId . ': ' . $exception->getMessage());
            }
        }

        $this->info('Meeting reminders sent: ' . $sent);
        return self::SUCCESS;
    }
}
