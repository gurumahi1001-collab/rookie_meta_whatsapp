MEETINGS MODULE — PRODUCTION OVERLAY

Base: updatedMvc.zip supplied in this conversation.

Deployment:
1. Back up the application and database.
2. Run app/Models/Productivity/2026_11_02_meetings_production_upgrade.sql against the existing application database.
3. Copy the ZIP contents into the MVC project root, preserving the folder structure.
4. Confirm the Laravel scheduler is active (cron should run `php artisan schedule:run` every minute).
5. Clear application caches: `php artisan optimize:clear`.
6. Test meeting create/edit, participant invitations, RSVP, conflicts, category/team management,
   calendar scopes, attachments, reschedule, cancellation, and reminder delivery.

Notes:
- Existing meeting records are preserved; the legacy category text column remains available.
- The SQL patch adds the category reference, reminder timestamp, cancellation reason, and the
  supporting category/team/participant/attachment tables.
- Category/team management is limited to company/group administrators. Company administrators
  can manage their own company settings; global settings are read-only to them.
- Meeting reminders are in-app notifications. Email/WhatsApp delivery is not included.
- The patch does not alter unrelated modules or menu definitions. The Meetings menu entry
  already exists in the supplied vertical menu configuration.
- Run the SQL patch before deploying the updated PHP/controller/view files.
