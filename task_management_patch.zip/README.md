# ARGUS Vendor Task Management — Targeted Production Patch

This is a **modified-files-only source overlay** based on the supplied latest UI source, Vendor Panel, and backend archives. It restores the screenshot-based task interface and adds tenant-scoped task access and persisted project/task notifications. It intentionally excludes complete projects, build output, dependencies, and environment files.

## Files included

### Vendor Panel

1. `vendor/src/components/myTask/List.tsx`
   - Keeps the UI-source List view, summary cards, filters, and task drawer styling while connecting it to real task/project APIs.
   - Vendor admins see tasks for all projects belonging to their vendor, including tasks assigned to other team members. Other vendor users see only tasks assigned to them.
   - The Create/Edit Task modal is backed by create/update APIs. Project selection loads that project's actual phases and resets the phase when the project changes. Vendor admin assignee options come from active vendor users.
   - Task details, task status/work updates, and deletion use the task APIs and refresh the visible list. Vendor staff are not shown administrative create/edit/delete controls.

2. `vendor/src/components/myTask/Kanban.tsx`
   - Preserves the UI-source Kanban layout and supports Mongo/string task IDs without coercing them to numbers.
   - Restricts create/edit/delete controls to vendor admins while allowing permitted assignees to update task status through the backend.

3. `vendor/src/offcanvas/mytask/edit.tsx`
   - Adds project and phase identifiers to task drawer data, passes real vendor staff records, and hides assignment-management controls from users who cannot manage assignments.

4. `vendor/src/api/vendorWorkflow.ts`
   - Adds typed task list/detail/create/update/delete requests using the existing authenticated Vendor Portal API. The list helper handles the current nested response envelope.

5. `vendor/src/router/routes.tsx`
   - Routes `/tasks` to the UI-source-aligned task screen rather than the simplified workflow placeholder.

### Backend

6. `backend/src/routes/vendorPortal.routes.js`
   - Exposes vendor-authenticated POST/PATCH/DELETE task endpoints alongside the existing GET task endpoints.

7. `backend/src/services/task/taskService.js`
   - Makes task-list scope role-aware: vendor administrators can view every task within their own vendor's projects, while vendor staff are restricted to tasks assigned to them.
   - Enforces vendor-admin permissions for task creation, administrative edits, and deletion; checks project/phase ownership and assigned vendor staff on the server.
   - Emits in-app notifications for task creation, task details/assignment/status/progress and other work updates, and deletion. Notifications are not sent back to the actor who performed the change.

8. `backend/src/services/notification/notificationService.js`
   - Adds tenant-scoped notification helpers that target active vendor administrators for the project's vendor and active vendor users assigned to project tasks. Each record is stored for its intended recipient and uses the existing notification model/inbox.

9. `backend/src/services/project/projectService.js`
   - Sends project-flow notifications on supported project updates/status changes, creation/deletion, phase and scope changes, deliverable changes, and payment-schedule due-date updates to the project's vendor administrators and staff assigned to that project's tasks.

## Notification scope

- Vendor admins receive updates for their vendor's project/task flow across that vendor's projects.
- Assigned staff receive relevant updates for projects/tasks to which they are assigned.
- Other vendors' users are excluded by the backend vendor ID filter; notification records are recipient-specific.
- Existing notification/inbox routes and UI are reused; no unrelated notification screen has been replaced.

## Validation performed

- Backend JavaScript syntax checks: **passed for all backend source files**.
- TypeScript/TSX syntax transpilation: **passed for the five changed frontend files**.
- Relative local import-path check for changed frontend files: **passed**.
- A full frontend production build and authenticated end-to-end staging test were **not run** in this workspace. Syntax validation does not certify a full production build.

## Apply and test

1. Back up the matching files in the actual source repositories.
2. Extract the ZIP at the repository root so only the listed paths are overwritten.
3. Install/build using the dependency lockfiles from your own repositories; those manifests and lockfiles are deliberately not replaced here.
4. In staging, test vendor-admin login with multiple projects and staff, staff login with only assigned tasks, project-dependent phases, create/edit/delete permissions, Kanban status updates, project status/phase/scope/deliverable changes, and notification delivery/read states.

Do not deploy without running the normal production build and staging acceptance checks in the real application environment.
