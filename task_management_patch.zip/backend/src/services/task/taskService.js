import mongoose from "mongoose";
import Task from "../../models/Task.js";
import Project from "../../models/Project.js";
import User from "../../models/User.js";
import auditService from "../audit/auditService.js";
import { notifyVendorTaskStakeholders } from "../notification/notificationService.js";

const INTERNAL_TYPES = ["admin", "internal"];
const PRIORITIES = ["low", "medium", "high", "urgent"];
const STATUSES = ["pending", "inprogress", "onhold", "completed"];

export class TaskServiceError extends Error {
    constructor(message, { code = "TASK_ERROR", statusCode = 400, details = undefined } = {}) { super(message); this.name = "TaskServiceError"; this.code = code; this.statusCode = statusCode; this.details = details; }
}
function text(v) { return typeof v === "string" ? v.trim() : ""; }
function num(v, d = 0) { const n = Number(v); return Number.isFinite(n) ? n : d; }
function oid(v, field = "id") { if (!mongoose.isValidObjectId(v)) throw new TaskServiceError(`Invalid ${field}.`, { code: `INVALID_${field.toUpperCase()}`, statusCode: 422 }); return new mongoose.Types.ObjectId(v); }
function dt(v, field) { if (v === undefined || v === null || v === "") return null; const d = new Date(v); if (Number.isNaN(d.getTime())) throw new TaskServiceError(`Invalid ${field}.`, { code: `INVALID_${field.toUpperCase()}`, statusCode: 422 }); return d; }
function internal(a) { return INTERNAL_TYPES.includes(String(a?.userType || "").toLowerCase()); }
function vendor(a) { return String(a?.userType || "").toLowerCase() === "vendor"; }
function actorId(a) {
    const value = a?.userId ?? a?.id ?? a?._id;
    return value && mongoose.isValidObjectId(value)
        ? new mongoose.Types.ObjectId(value)
        : null;
}
function vendorAdmin(a) {
    if (!vendor(a)) return false;
    return text(a?.role).toLowerCase() === "vendor_admin";
}
function normalizeStatus(v) { const s = text(v).toLowerCase().replace(/\s+/g, ""); const map = { "pending": "pending", "inprogress": "inprogress", "in_progress": "inprogress", "onhold": "onhold", "on_hold": "onhold", "completed": "completed", "due_date": "pending" }; const out = map[s] || map[text(v).toLowerCase().replace(/\s+/g, "_")]; if (!out || !STATUSES.includes(out)) throw new TaskServiceError("Invalid task status.", { code: "INVALID_TASK_STATUS", statusCode: 422 }); return out; }
function normalizePriority(v) { const p = text(v).toLowerCase(); if (!PRIORITIES.includes(p)) throw new TaskServiceError("Invalid task priority.", { code: "INVALID_TASK_PRIORITY", statusCode: 422 }); return p; }
function serialize(task) { return task?.toSafeJSON ? task.toSafeJSON() : task; }
async function audit(action, task, actor, request, metadata = {}) { try { await auditService.recordAudit({ action, module: "task", title: `Task ${action.replace(/_/g, " ")}`, description: task?.title || "", actor: actor?.actor || actor || null, request, entityType: "task", entityId: task?._id ? String(task._id) : "", entityName: task?.title || "", vendorId: actor?.vendorId || null, metadata }); } catch (e) { console.error("[taskService] audit write failed", e); } }
async function notifyTaskSafely(task, project, actor, { eventType, title, message, assignedUserIds = [] } = {}) {
    if (!project?.vendorId) return;
    const ids = [
        ...(task?.ownerIds || []).map((id) => String(id)),
        ...(task?.assignedStaff || []).map((staff) => String(staff.userId || "")),
        ...(assignedUserIds || []).map((id) => String(id || "")),
    ].filter(Boolean);
    try {
        await notifyVendorTaskStakeholders({
            vendorId: project.vendorId,
            assignedUserIds: ids,
            excludeUserId: actorId(actor) ? String(actorId(actor)) : null,
            eventType,
            title,
            message,
            payload: { projectId: String(project._id), taskId: task?._id ? String(task._id) : "", taskTitle: task?.title || "", status: task?.status || "" },
        });
    } catch (error) {
        console.error("[taskService] task notification failed", error?.message || error);
    }
}

function isAssignedToActor(task, actor) {
    const currentUserId = actorId(actor);
    if (!currentUserId) return false;
    return (task.ownerIds || []).some((id) => String(id) === String(currentUserId))
        || (task.assignedStaff || []).some((staff) => String(staff.userId || "") === String(currentUserId));
}

const VENDOR_STAFF_EDITABLE_FIELDS = new Set([
    "status", "progress", "progressPercentage", "actualHours", "totalWorkedSeconds",
    "timerStartedAt", "isTimerRunning", "workLogs", "materials", "materialCost",
    "otherExpenses", "otherExpensesBreakdown", "comments", "attachments",
]);

async function getProject(projectId) { const p = await Project.findById(oid(projectId, "projectId")); if (!p) throw new TaskServiceError("Project was not found.", { code: "PROJECT_NOT_FOUND", statusCode: 404 }); return p; }
function canView(project, actor) {
    if (internal(actor)) {
        const role = text(actor?.role).toLowerCase().replace(/[-\s]+/g, "_");
        const currentUserId = actorId(actor);
        if (["project_manager", "projectmanager", "pm"].includes(role)) {
            return Boolean(currentUserId) && String(project.managerId || "") === String(currentUserId);
        }
        return true;
    }
    if (vendor(actor)) return String(project.vendorId || "") === String(actor.vendorId || "");
    return false;
}
async function assignedStaff(value, fallbackRate, fallbackHours, actor = {}) {
    const names = Array.isArray(value) ? value : text(value).split(",").map((x) => x.trim()).filter(Boolean);
    const unique = [...new Set(names.map((x) => typeof x === "object" ? text(x.name) : text(x)).filter(Boolean))];
    if (!unique.length) return { ownerIds: [], ownerNames: [], staff: [] };
    const userFilter = vendor(actor)
        ? (actor.vendorId ? { userType: "vendor", vendorId: oid(actor.vendorId, "vendorId"), status: "active" } : { _id: null })
        : { status: "active" };
    const users = await User.find({ displayName: { $in: unique }, ...userFilter }).select("_id displayName hourlyRate").lean();
    const byName = new Map(users.map((u) => [u.displayName, u]));
    if (vendor(actor)) {
        const unresolved = unique.filter((name) => !byName.has(name));
        if (unresolved.length) throw new TaskServiceError(`Some assigned staff are inactive or do not belong to this vendor: ${unresolved.join(", ")}.`, { code: "TASK_ASSIGNEE_INVALID", statusCode: 422, details: { unresolved } });
    }
    return {
        ownerIds: unique.map((n) => byName.get(n)?._id).filter(Boolean),
        ownerNames: unique,
        staff: unique.map((name) => {
            const supplied = Array.isArray(value) ? value.find((v) => typeof v === "object" && text(v.name) === name) : null;
            const rate = Math.max(0, num(supplied?.rate, num(byName.get(name)?.hourlyRate, fallbackRate)));
            const hours = Math.max(0, num(supplied?.hours, fallbackHours));
            return { userId: byName.get(name)?._id || null, name, rate, hours, amount: Math.max(0, num(supplied?.amount, rate * hours)) };
        }),
    };
}
function normalizeArray(value, mapper) { return Array.isArray(value) ? value.map(mapper).filter(Boolean) : undefined; }

export async function listTasks({ actor, projectId, page = 1, limit = 200 } = {}) {
    if (!projectId) throw new TaskServiceError("Project ID is required.", { code: "PROJECT_ID_REQUIRED", statusCode: 422 });
    const project = await getProject(projectId); if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to view these tasks.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const p = Math.max(1, parseInt(String(page), 10) || 1); const l = Math.min(500, Math.max(1, parseInt(String(limit), 10) || 200));
    const [rows, total] = await Promise.all([Task.find({ projectId: project._id }).sort({ createdAt: 1, _id: 1 }).skip((p - 1) * l).limit(l), Task.countDocuments({ projectId: project._id})]);
    return { data: rows.map(serialize), pagination: { page: p, limit: l, total, totalPages: Math.ceil(total / l) } };
}

export async function listVendorTasks({ actor, page = 1, limit = 200 } = {}) {
    if (!vendor(actor)) throw new TaskServiceError("Only vendor users can access vendor task lists.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const vendorId = actor?.vendorId && mongoose.isValidObjectId(actor.vendorId) ? new mongoose.Types.ObjectId(actor.vendorId) : null;
    const currentUserId = actorId(actor);
    if (!vendorId) throw new TaskServiceError("Vendor user identity is incomplete.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
    if (!currentUserId && !vendorAdmin(actor)) {
        throw new TaskServiceError("Vendor user identity is incomplete.", { code: "VENDOR_SCOPE_FORBIDDEN", statusCode: 403 });
    }
    const projects = await Project.find({ vendorId }).select("_id name").lean();
    const projectIds = projects.map((row) => row._id);
    const p = Math.max(1, parseInt(String(page), 10) || 1);
    const l = Math.min(500, Math.max(1, parseInt(String(limit), 10) || 200));
    if (!projectIds.length) return { data: [], pagination: { page: p, limit: l, total: 0, totalPages: 0 } };
    // Vendor admins see every task across projects belonging to their vendor.
    // Other vendor accounts see only tasks assigned directly to them.
    const assignment = !vendorAdmin(actor) && currentUserId
        ? { $or: [{ ownerIds: currentUserId }, { "assignedStaff.userId": currentUserId }] }
        : null;
    const filter = assignment
        ? { projectId: { $in: projectIds }, ...assignment }
        : { projectId: { $in: projectIds } };
    const [rows, total] = await Promise.all([
        Task.find(filter).sort({ dueDate: 1, createdAt: -1, _id: -1 }).skip((p - 1) * l).limit(l),
        Task.countDocuments(filter),
    ]);
    const projectMap = new Map(projects.map((row) => [String(row._id), row]));
    const data = rows.map((task) => {
        const safe = serialize(task);
        const project = projectMap.get(String(task.projectId));
        return {
            ...safe,
            reference: `TSK-${String(task._id).slice(-8).toUpperCase()}`,
            project: project?.name || "",
            projectReference: project ? String(project._id) : "",
            phase: safe?.phaseName || "",
        };
    });
    return { data, pagination: { page: p, limit: l, total, totalPages: Math.ceil(total / l) } };
}

export async function getVendorTask(id, { actor } = {}) {
    if (!vendor(actor)) throw new TaskServiceError("Only vendor users can access vendor task details.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const task = await Task.findById(oid(id, "taskId"));
    if (!task) throw new TaskServiceError("Task was not found.", { code: "TASK_NOT_FOUND", statusCode: 404 });
    const project = await Project.findById(task.projectId).select("_id name vendorId").lean();
    const vendorId = actor?.vendorId && mongoose.isValidObjectId(actor.vendorId) ? String(actor.vendorId) : "";
    if (!project || String(project.vendorId) !== vendorId) throw new TaskServiceError("You are not authorized to view this task.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const currentUserId = actorId(actor);
    const assigned = vendorAdmin(actor) || (
        Boolean(currentUserId) && (
            (task.ownerIds || []).some((ownerId) => String(ownerId) === String(currentUserId))
            || (task.assignedStaff || []).some((staff) => String(staff.userId || "") === String(currentUserId))
        )
    );
    if (!assigned) throw new TaskServiceError("You are not authorized to view this task.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const safe = serialize(task);
    return {
        ...safe,
        reference: `TSK-${String(task._id).slice(-8).toUpperCase()}`,
        project: project.name || "",
        projectReference: String(project._id),
        phase: safe?.phaseName || "",
    };
}

export async function getTask(id, { actor } = {}) {
    const task = await Task.findById(oid(id, "taskId")); if (!task) throw new TaskServiceError("Task was not found.", { code: "TASK_NOT_FOUND", statusCode: 404 });
    const project = await getProject(task.projectId); if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to view this task.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 }); return serialize(task);
}

export async function createTask(payload, { actor, request = null } = {}) {
    if (!internal(actor) && !vendorAdmin(actor)) throw new TaskServiceError("Only vendor administrators can create project tasks.", { code: "TASK_CREATE_FORBIDDEN", statusCode: 403 });
    const project = await getProject(payload.projectId); if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to add tasks to this project.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const title = text(payload.title ?? payload.name); if (!title) throw new TaskServiceError("Task title is required.", { code: "TASK_TITLE_REQUIRED", statusCode: 422 });
    const phaseId = payload.phaseId && mongoose.isValidObjectId(payload.phaseId) ? new mongoose.Types.ObjectId(payload.phaseId) : null;
    const phase = phaseId ? project.phases.id(phaseId) : null;
    if (phaseId && !phase) throw new TaskServiceError("Selected phase does not belong to this project.", { code: "TASK_PHASE_PROJECT_MISMATCH", statusCode: 422 });
    if (vendorAdmin(actor) && !(Array.isArray(payload.assignedStaff ?? payload.Assignstaff ?? payload.assignStaff) ? (payload.assignedStaff ?? payload.Assignstaff ?? payload.assignStaff).length : text(payload.assignedStaff ?? payload.Assignstaff ?? payload.assignStaff))) {
        throw new TaskServiceError("Assign at least one staff member to this task.", { code: "TASK_ASSIGNEE_REQUIRED", statusCode: 422 });
    }
    const assigned = await assignedStaff(payload.assignedStaff ?? payload.Assignstaff ?? payload.assignStaff, num(payload.hourlyRate), num(payload.estimatedHours), actor);
    const status = normalizeStatus(payload.status ?? "pending");
    const progress = Math.max(0, Math.min(100, num(payload.progress ?? 0)));
    const task = new Task({
        projectId: project._id,
        phaseId: phase?._id || null,
        phaseName: phase?.name || text(payload.phaseName),
        title,
        description: text(payload.description),
        ownerIds: assigned.ownerIds,
        ownerNames: assigned.ownerNames,
        assignedStaff: assigned.staff,
        startDate: dt(payload.startDate, "startDate"),
        dueDate: dt(payload.dueDate, "dueDate"),
        priority: normalizePriority(payload.priority ?? "medium"),
        status,
        progressPercentage: progress,
        estimatedHours: Math.max(0, num(payload.estimatedHours)),
        actualHours: Math.max(0, num(payload.actualHours ?? (num(payload.totalWorkedSeconds) / 3600))),
        hourlyRate: Math.max(0, num(payload.hourlyRate)),
        materialCost: Math.max(0, num(payload.materialCost)),
        otherExpenses: Math.max(0, num(payload.otherExpenses)),
        createdBy: actorId(actor),
        updatedBy: actorId(actor),
    });
    await task.save(); await recalculateProjectProgress(project._id, actor); await audit("created", task, actor, request, { projectId: String(project._id) });
    await notifyTaskSafely(task, project, actor, { eventType: "task_created", title: "New project task", message: `${task.title} was added to ${project.name}.` });
    return serialize(task);
}

export async function updateTask(id, payload, { actor, request = null } = {}) {
    if (!internal(actor) && !vendor(actor)) throw new TaskServiceError("You are not authorized to update project tasks.", { code: "TASK_EDIT_FORBIDDEN", statusCode: 403 });
    const task = await Task.findById(oid(id, "taskId")); if (!task) throw new TaskServiceError("Task was not found.", { code: "TASK_NOT_FOUND", statusCode: 404 });
    const originalProject = await getProject(task.projectId);
    if (!canView(originalProject, actor)) throw new TaskServiceError("You are not authorized to update this task.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const project = payload.projectId && String(payload.projectId) !== String(task.projectId)
        ? await getProject(payload.projectId)
        : originalProject;
    if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to move this task to the selected project.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    const originalProjectId = String(task.projectId);
    const currentVendorAdmin = vendorAdmin(actor);
    if (vendor(actor) && !currentVendorAdmin) {
        if (!isAssignedToActor(task, actor)) throw new TaskServiceError("You can update only tasks assigned to you.", { code: "TASK_ASSIGNMENT_FORBIDDEN", statusCode: 403 });
        const forbidden = Object.keys(payload || {}).filter((key) => !VENDOR_STAFF_EDITABLE_FIELDS.has(key));
        if (forbidden.length) throw new TaskServiceError("Assigned staff can update task progress, work logs, materials, expenses, comments and attachments only.", { code: "TASK_STAFF_EDIT_LIMITED", statusCode: 403, details: { fields: forbidden } });
    }
    const before = { title: task.title, description: task.description, phaseId: task.phaseId ? String(task.phaseId) : null, phaseName: task.phaseName, startDate: task.startDate, dueDate: task.dueDate, priority: task.priority, projectId: String(task.projectId), status: task.status, progress: task.progressPercentage, assignedStaff: task.assignedStaff, ownerIds: (task.ownerIds || []).map(String), commentCount: (task.comments || []).length, estimatedHours: task.estimatedHours, actualHours: task.actualHours, materialCost: task.materialCost, otherExpenses: task.otherExpenses };
    if (payload.projectId !== undefined) task.projectId = project._id;
    if (payload.title !== undefined || payload.name !== undefined) task.title = text(payload.title ?? payload.name) || task.title;
    if (payload.description !== undefined) task.description = text(payload.description);
    if (payload.phaseId !== undefined) { task.phaseId = payload.phaseId && mongoose.isValidObjectId(payload.phaseId) ? new mongoose.Types.ObjectId(payload.phaseId) : null; const phase = task.phaseId ? project.phases.id(task.phaseId) : null; if (task.phaseId && !phase) throw new TaskServiceError("Selected phase does not belong to this project.", { code: "TASK_PHASE_PROJECT_MISMATCH", statusCode: 422 }); task.phaseName = phase?.name || text(payload.phaseName); }
    if (payload.startDate !== undefined) task.startDate = dt(payload.startDate, "startDate");
    if (payload.dueDate !== undefined) task.dueDate = dt(payload.dueDate, "dueDate");
    if (payload.priority !== undefined) task.priority = normalizePriority(payload.priority);
    if (payload.status !== undefined) task.status = normalizeStatus(payload.status);
    if (payload.progress !== undefined || payload.progressPercentage !== undefined) task.progressPercentage = Math.max(0, Math.min(100, num(payload.progress ?? payload.progressPercentage)));
    if (payload.estimatedHours !== undefined) task.estimatedHours = Math.max(0, num(payload.estimatedHours));
    if (payload.actualHours !== undefined) task.actualHours = Math.max(0, num(payload.actualHours));
    if (payload.hourlyRate !== undefined) task.hourlyRate = Math.max(0, num(payload.hourlyRate));
    if (payload.materialCost !== undefined) task.materialCost = Math.max(0, num(payload.materialCost));
    if (payload.otherExpenses !== undefined) task.otherExpenses = Math.max(0, num(payload.otherExpenses));
    if (payload.totalWorkedSeconds !== undefined) task.totalWorkedSeconds = Math.max(0, num(payload.totalWorkedSeconds));
    if (payload.timerStartedAt !== undefined) task.timerStartedAt = dt(payload.timerStartedAt, "timerStartedAt");
    if (payload.isTimerRunning !== undefined) task.isTimerRunning = Boolean(payload.isTimerRunning);
    if (payload.assignedStaff !== undefined || payload.Assignstaff !== undefined || payload.assignStaff !== undefined) {
        const assigned = await assignedStaff(payload.assignedStaff ?? payload.Assignstaff ?? payload.assignStaff, task.hourlyRate, task.estimatedHours, actor); task.ownerIds = assigned.ownerIds; task.ownerNames = assigned.ownerNames; task.assignedStaff = assigned.staff;
    }
    const workLogs = normalizeArray(payload.workLogs, (log) => ({ startedAt: dt(log?.startedAt, "workLog.startedAt"), stoppedAt: dt(log?.stoppedAt, "workLog.stoppedAt"), duration: Math.max(0, num(log?.duration)) }));
    if (workLogs) task.workLogs = workLogs;
    const materials = normalizeArray(payload.materials, (item) => ({ name: text(item?.name), unitCost: Math.max(0, num(item?.unitCost)), quantity: Math.max(0, num(item?.quantity)) }));
    if (materials) task.materials = materials;
    const expenses = normalizeArray(payload.otherExpensesBreakdown, (item) => ({ name: text(item?.name), amount: Math.max(0, num(item?.amount)), description: text(item?.description) }));
    if (expenses) task.otherExpensesBreakdown = expenses;
    const commentsRaw = normalizeArray(payload.comments, (item) => ({ type: ["update", "question", "image"].includes(item?.type) ? item.type : "update", text: text(item?.text), image: item?.image ? text(item.image) : null, authorId: item?.authorId && mongoose.isValidObjectId(item.authorId) ? new mongoose.Types.ObjectId(item.authorId) : actorId(actor), authorName: text(item?.authorName) || text(actor?.displayName), createdAt: dt(item?.createdAt, "comment.createdAt") || new Date() }));
    if (commentsRaw) task.comments = commentsRaw.filter((item) => item.text);
    const attachments = normalizeArray(payload.attachments, (item) => {
        const name = text(item?.name);
        const url = text(item?.url);
        if (!name || !url) return null;
        return { name, url, mimeType: text(item?.mimeType) || "application/octet-stream", size: Math.max(0, num(item?.size)), createdAt: dt(item?.createdAt, "attachment.createdAt") || new Date() };
    });
    if (attachments) task.attachments = attachments;
    const materialsTotal = task.materials.reduce((s, item) => s + num(item.unitCost) * num(item.quantity), 0);
    if (payload.materials !== undefined) task.materialCost = materialsTotal;
    const expenseTotal = task.otherExpensesBreakdown.reduce((s, item) => s + num(item.amount), 0);
    if (payload.otherExpensesBreakdown !== undefined) task.otherExpenses = expenseTotal;
    if (payload.totalWorkedSeconds !== undefined || payload.workLogs !== undefined) {
        task.actualHours = Math.max(0, num(task.totalWorkedSeconds) / 3600);
    }
    task.updatedBy = actorId(actor); await task.save();
    if (originalProjectId !== String(project._id)) await recalculateProjectProgress(originalProjectId, actor);
    await recalculateProjectProgress(project._id, actor);
    const after = { title: task.title, description: task.description, phaseId: task.phaseId ? String(task.phaseId) : null, phaseName: task.phaseName, startDate: task.startDate, dueDate: task.dueDate, priority: task.priority, projectId: String(task.projectId), status: task.status, progress: task.progressPercentage, assignedStaff: task.assignedStaff, estimatedHours: task.estimatedHours, actualHours: task.actualHours, materialCost: task.materialCost, otherExpenses: task.otherExpenses, commentCount: (task.comments || []).length };
    await audit("updated", task, actor, request, { projectId: String(project._id) }, { before, after });
    const previousAssignedIds = before.ownerIds || [];
    const nextAssignedIds = (task.ownerIds || []).map(String);
    const reassigned = previousAssignedIds.slice().sort().join(",") !== nextAssignedIds.slice().sort().join(",");
    const notifications = [];
    if (before.status !== after.status) notifications.push({ eventType: "task_status_changed", title: "Task status updated", message: `${task.title} status changed from ${before.status} to ${after.status}.` });
    if (before.progress !== after.progress) notifications.push({ eventType: "task_progress_updated", title: "Task progress updated", message: `${task.title} progress is now ${after.progress}%.` });
    if (reassigned) notifications.push({ eventType: "task_assignees_changed", title: "Task assignment updated", message: `Staff assignment changed for ${task.title}.` });
    if (after.commentCount > before.commentCount) notifications.push({ eventType: "task_comment_added", title: "Task conversation updated", message: `A new update was posted on ${task.title}.` });
    if (before.estimatedHours !== after.estimatedHours || before.actualHours !== after.actualHours || before.materialCost !== after.materialCost || before.otherExpenses !== after.otherExpenses) notifications.push({ eventType: "task_worklog_updated", title: "Task work details updated", message: `Work logs or expenses were updated for ${task.title}.` });
    const taskDetailsChanged = ["title", "description", "phaseId", "phaseName", "startDate", "dueDate", "priority", "projectId"].some((key) => String(before[key] ?? "") !== String(after[key] ?? ""));
    if (taskDetailsChanged) notifications.push({ eventType: "task_details_updated", title: "Task details updated", message: `Details for ${task.title} were updated.` });
    for (const notification of notifications) await notifyTaskSafely(task, project, actor, { ...notification, assignedUserIds: previousAssignedIds });
    return serialize(task);
}

export async function deleteTask(id, { actor, request = null } = {}) {
    if (!internal(actor) && !vendorAdmin(actor)) throw new TaskServiceError("Only internal users or vendor administrators can delete project tasks.", { code: "TASK_DELETE_FORBIDDEN", statusCode: 403 });
    const task = await Task.findById(oid(id, "taskId")); if (!task) throw new TaskServiceError("Task was not found.", { code: "TASK_NOT_FOUND", statusCode: 404 });
    const project = await getProject(task.projectId); if (!canView(project, actor)) throw new TaskServiceError("You are not authorized to delete this task.", { code: "TASK_ACCESS_FORBIDDEN", statusCode: 403 });
    await notifyTaskSafely(task, project, actor, { eventType: "task_deleted", title: "Project task removed", message: `${task.title} was removed from ${project.name}.` });
    await Task.deleteOne({ _id: task._id }); await recalculateProjectProgress(project._id, actor); await audit("deleted", task, actor, request, { projectId: String(project._id) }); return { id: String(task._id) };
}

export async function recalculateProjectProgress(projectId, actor = null) {
    const project = await Project.findById(projectId); if (!project) return null;
    const previousStatus = project.status;
    const tasks = await Task.find({ projectId }).select("progressPercentage status ownerIds assignedStaff");
    const progress = tasks.length ? tasks.reduce((s, t) => s + num(t.progressPercentage), 0) / tasks.length : 0;
    project.progressPercentage = Math.max(0, Math.min(100, Math.round(progress * 100) / 100));
    if (tasks.length && tasks.every((t) => t.status === "completed")) project.status = "completed";
    await project.save();
    if (project.vendorId && previousStatus !== project.status) {
        const assignedUserIds = tasks.flatMap((task) => [
            ...(task.ownerIds || []).map((id) => String(id)),
            ...(task.assignedStaff || []).map((staff) => String(staff.userId || "")),
        ]).filter(Boolean);
        try {
            await notifyVendorTaskStakeholders({
                vendorId: project.vendorId,
                assignedUserIds,
                excludeUserId: actorId(actor) ? String(actorId(actor)) : null,
                eventType: "project_status_changed",
                title: "Project status changed",
                message: `${project.name} was automatically marked ${String(project.status).replace(/_/g, " ")} based on task completion.`,
                payload: { projectId: String(project._id), projectName: project.name || "", status: project.status },
            });
        } catch (error) { console.error("[taskService] project status notification failed", error?.message || error); }
    }
    return project;
}

export async function updateProgress(id, payload, options = {}) { return updateTask(id, payload, options); }
