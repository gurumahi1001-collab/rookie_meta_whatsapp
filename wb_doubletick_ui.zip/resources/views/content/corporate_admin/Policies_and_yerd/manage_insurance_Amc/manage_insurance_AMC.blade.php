@extends('layouts/layoutMaster')

@section('title', 'Manage AMC')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/dropzone/dropzone.scss', 
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
    'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/dropzone/dropzone.js', 
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
<style>
    .custom-dropzone {
        border: 2px dashed #d9d9d9;
        border-radius: 12px;
        background: #fafafa;
        padding: 20px;
        transition: 0.3s;
    }

    .custom-dropzone:hover {
        border-color: #850525;
        background: #f5f5ff;
    }

    .upload-icon {
        font-size: 40px;
        color: #850525;
        margin-bottom: 10px;
    }

    .dz-preview {
        border-radius: 10px;
        padding: 10px;
        background: #fff;
        margin-top: 10px;
    }
    /* Apply to all dropzones */
    .custom-dropzone {
        display: flex;
        flex-wrap: wrap;   /* multiple rows */
        gap: 10px;
    }

    /* Each file preview card */
    .custom-dropzone .dz-preview {
        width: calc(33.33% - 10px);  /* 3 per row */
        min-width: 220px;
        box-sizing: border-box;
    }

    /* Tablet */
    @media (max-width: 768px) {
        .custom-dropzone .dz-preview {
            width: calc(50% - 10px); /* 2 per row */
        }
    }

    /* Mobile */
    @media (max-width: 425px) {
        .custom-dropzone .dz-preview {
            width: 100%; /* 1 per row */
        }
    }

    .dz-remove {
        width: 28px;
        height: 28px;
        border-radius: 50%;          /* 🔥 makes it fully round */
        background: #f1f1f1;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: 0.2s;
    }

    .dz-remove:hover {
        background: #ff4d4f;
        color: #fff;
    }

    .dz-progress {
        height: 6px;
        background: #eee;
        border-radius: 10px;
        overflow: hidden;
        margin-top: 6px;
    }
    .dz-success .dz-upload {
        background: #28c76f;
    }

    .dz-upload {
        display: block;              /* 🔥 REQUIRED */
        height: 100%;                /* 🔥 REQUIRED */
        width: 0%;
        background: #850525;
        transition: width 0.3s ease; /* smooth animation */
    }
</style>
<style>
  .table-wrapper {
    max-height: 380px;
    overflow-y: auto;
    overflow-x: hidden;
    border: 1px solid #eee;
}

/* Sticky Header */
.table-header th {
    position: sticky;
    top: 0;
    z-index: 5;
    background: #AB2B22 !important;
    color: white;
    padding-top: 10px;
    padding-bottom: 10px;
}
</style>

<style>
    

    .stars {
    display: flex;
    gap: 5px;
    cursor: pointer;
    }

    .stars span {
    font-size: 22px;
    color: #ccc;
    transition: 0.2s;
    }

    .stars span.active {
    color: #c77700; /* golden brown like your image */
    }

    .value {
    color: #666;
    font-size: 14px;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action mb-4">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Manage Insurance & AMC</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home me-1"></i>Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-shield-crown-outline me-1"></i>Corporate Admin
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                           Policies & RD Accounts
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
                    <span><i class="mdi mdi-filter-outline"></i></span>
                </a> -->
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white"  data-bs-toggle="modal" data-bs-target="#kt_modal_add_policy">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add New Policy
                </a>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white"  data-bs-toggle="modal" data-bs-target="#kt_modal_add_amc">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add New AMC
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row ">
            <div class="col-lg-12 mb-2">
                <div class="row g-2">
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                        <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                            <div class="d-flex align-items-center justify-content-between gap-2">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-dark">Active Policies</label>
                                    <label class="fs-2 fw-semibold text-black">06</label>
                                </div>
                                <label>
                                    <span class="badge bg-label-secondary rounded-circle">
                                        <i class="mdi mdi-file-document-outline fs-3"></i>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                        <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                            <div class="d-flex align-items-center justify-content-between gap-2">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-dark">Active AMCS</label>
                                    <label class="fs-2 fw-semibold text-black">06</label>
                                </div>
                                <label>
                                    <span class="badge bg-label-danger rounded-circle">
                                        <i class="mdi mdi-text-box-outline fs-3"></i>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                        <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                            <div class="d-flex align-items-center justify-content-between gap-2">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-dark">Premium ( Annual )</label>
                                    <label class="fs-2 fw-semibold text-black">&#8377; 4,29,000 </label>
                                </div>
                                <label>
                                    <span class="badge bg-label-secondary rounded-circle">
                                        <i class="mdi mdi-currency-rupee fs-3"></i>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                        <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                            <div class="d-flex align-items-center justify-content-between gap-2">
                                <div class="d-flex flex-column">
                                    <label class="fs-7 fw-semibold text-dark">AMC value ( Annual )</label>
                                    <label class="fs-2 fw-semibold text-black">&#8377; 51,4000</label>
                                </div>
                                <label>
                                    <span class="badge bg-label-danger rounded-circle">
                                        <i class="mdi mdi-currency-rupee fs-3"></i>
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row g-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="d-flex align-items-center justify-content-between mb-1 gap-2">
                            <div class="badge d-flex align-items-center gap-2 rounded-2 fw-semibold  fs-6 " style="background:#FDEBD2; color:#C47A1B;">
                                <i class="mdi mdi-file-document-outline fs-3"></i>
                                <label class="text-black" >Insurance Policy</label>
                            </div>
                            <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                <div class="searchBar">
                                    <input class="searchQueryInput" type="text" name="searchQueryInput"
                                        placeholder="Enter Policy / Provider / Owner" value=""
                                        oninput="toggleIcons(this)" />
                                    <a href="{{url('/manage_amc-contract')}}"
                                    class="searchQuerySubmit searchIcon">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                                C16,11.11 15.41,12.59 14.44,13.73
                                                L14.71,14H15.5L20.5,19L19,20.5
                                                L14,15.5V14.71L13.73,14.44
                                                C12.59,15.41 11.11,16
                                                9.5,16A6.5,6.5 0 0,1 3,9.5
                                                A6.5,6.5 0 0,1 9.5,3
                                                M9.5,5C7,5 5,7 5,9.5
                                                C5,12 7,14 9.5,14
                                                C12,14 14,12 14,9.5
                                                C14,7 12,5 9.5,5Z"/>
                                        </svg>
                                    </a>
                                    <button class="searchQuerySubmit refreshIcon" onclick="clearInput()" style="display:none;">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                                A8,8 0 0,0 4,12H1L4.89,16.89
                                                L9,12H6A6,6 0 0,1 12,6
                                                C13.66,6 15.14,6.69 16.22,7.78
                                                L17.65,6.35M19.11,7.11L15,12
                                                H18A6,6 0 0,1 12,18
                                                C10.34,18 8.86,17.31 7.78,16.22
                                                L6.35,17.65C7.8,19.1 9.79,20
                                                12,20A8,8 0 0,0 20,12H23L19.11,7.11Z"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="table-wrapper mt-4">
                            <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                                <thead class="table-header">
                                    <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">Policy ID</th>
                                        <th class="min-w-100px">Name / Type</th>
                                        <th class="min-w-100px">Provider/Owner</th>
                                        <th class="min-w-100px">File Claim</th>
                                        <th class="min-w-100px text-center">Assets</th>
                                        <th class="min-w-100px">Premium</th>
                                        <th class="min-w-100px">Expires</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="table-body text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">INS-0481</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Global fleet vehicle policy</div>
                                            <div>
                                                <label class="badge bg-label-dark fw-semibold fs-7">Vehicle</label>
                                            </div>
                                        </td>
                                        
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-truncate" style="max-width:150px;">Meridian Assurance</label>
                                                <label class="text-truncate fs-8 text-dark" style="max-width:150px;">Nithish Kumar M K</label>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-info text-black border border-info" 
                                                style=" color:#fff; border-radius:50px; width:40px; height:40px;">02
                                            </span>
                                        </td>
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary" 
                                                style=" color:#fff; border-radius:50px; width:40px; height:40px;">34
                                            </span>
                                        </td>
                                        <td>
                                            <label >&#8377; 48,2000</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">04-Apr-2026</label>
                                                <label class="text-danger">In 12 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Renewal Due
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">INS-0481</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Global fleet vehicle policy</div>
                                            <div>
                                                <label class="badge bg-label-dark fw-semibold fs-7">Vehicle</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-truncate" style="max-width:150px;">Meridian Assurance</label>
                                                <label class="text-truncate fs-8 text-dark" style="max-width:150px;">Nithish Kumar M K</label>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-info text-black border border-info" 
                                                style=" color:#fff; border-radius:50px; width:40px; height:40px;">00
                                            </span>
                                        </td>
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary" 
                                                style="color:#fff; border-radius:50px; width:40px; height:40px;">34
                                            </span>
                                        </td>
                                        <td>
                                            <label>&#8377; 48,2000</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">04-Apr-2026</label>
                                                <label class="text-danger">In 12 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Renewal Due
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><label class="text-truncate max-w-175px">INS-0482</label></td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Employee health coverage plan</div>
                                            <div><label class="badge bg-label-dark fw-semibold fs-7">Health</label></div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-truncate" style="max-width:150px;">Sunrise Insurance</label>
                                                <label class="text-truncate fs-8 text-dark" style="max-width:150px;">Arjun Babu G G</label>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-info text-black border border-info" 
                                                style=" color:#fff; border-radius:50px; width:40px; height:40px;">01
                                            </span>
                                        </td>
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary"
                                                style="color:#fff; border-radius:50px; width:40px; height:40px;">18</span>
                                        </td>
                                        <td><label>&#8377; 1,25,000</label></td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">10-Apr-2026</label>
                                                <label class="text-danger">In 18 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2 bg-label-success" >
                                                Active
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><label class="text-truncate max-w-175px">INS-0483</label></td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Office property insurance</div>
                                            <div><label class="badge bg-label-dark fw-semibold fs-7">Property</label></div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-truncate" style="max-width:150px;">Prime Shield Co</label>
                                                <label class="text-truncate fs-8 text-dark" style="max-width:150px;">Karthik S</label>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-info text-black border border-info" 
                                                style=" color:#fff; border-radius:50px; width:40px; height:40px;">00
                                            </span>
                                        </td>
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary"
                                                style="color:#fff; border-radius:50px; width:40px; height:40px;">52</span>
                                        </td>
                                        <td><label>&#8377; 3,80,000</label></td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">22-Apr-2026</label>
                                                <label class="text-danger">In 30 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2 bg-label-success" >
                                                Active
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><label class="text-truncate max-w-175px">INS-0484</label></td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Travel insurance corporate plan</div>
                                            <div><label class="badge bg-label-dark fw-semibold fs-7">Travel</label></div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-truncate" style="max-width:150px;">Orbit Secure</label>
                                                <label class="text-truncate" style="max-width:150px;">Sesha Anand K</label>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-info text-black border border-info" 
                                                style=" color:#fff; border-radius:50px; width:40px; height:40px;">02
                                            </span>
                                        </td>
                                        <td align="center">
                                            <span class="badge p-2 fw-semibold fs-6 d-flex align-items-center justify-content-center bg-label-primary"
                                                style="color:#fff; border-radius:50px; width:40px; height:40px;">12</span>
                                        </td>
                                        <td><label>&#8377; 92,500</label></td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">28-Apr-2026</label>
                                                <label class="text-danger">In 36 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2 bg-label-primary" >
                                                Expired
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>        
                </div>        
            </div>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12 " >
                        <div class="d-flex align-items-center justify-content-between mb-1 gap-2">

                            <div class="badge d-flex align-items-center gap-2 rounded-2 fw-semibold  fs-6 bg-label-danger" >
                                <i class="mdi mdi-text-box-outline fs-3"></i>
                                <label class="text-black" >AMC Contracts</label>
                            </div>

                            <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                <div class="searchBar">
                                    <input class="searchQueryInput" type="text" name="searchQueryInput"
                                        placeholder="Enter Contract / Asset / Vendor" value=""
                                        oninput="toggleIcons(this)" />
                                    <a href="{{url('/manage_amc-contract')}}"
                                    class="searchQuerySubmit searchIcon">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                                C16,11.11 15.41,12.59 14.44,13.73
                                                L14.71,14H15.5L20.5,19L19,20.5
                                                L14,15.5V14.71L13.73,14.44
                                                C12.59,15.41 11.11,16
                                                9.5,16A6.5,6.5 0 0,1 3,9.5
                                                A6.5,6.5 0 0,1 9.5,3
                                                M9.5,5C7,5 5,7 5,9.5
                                                C5,12 7,14 9.5,14
                                                C12,14 14,12 14,9.5
                                                C14,7 12,5 9.5,5Z"/>
                                        </svg>
                                    </a>
                                    <button class="searchQuerySubmit refreshIcon" onclick="clearInput()" style="display:none;">
                                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                            <path fill="#ab2b22"
                                                d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                                A8,8 0 0,0 4,12H1L4.89,16.89
                                                L9,12H6A6,6 0 0,1 12,6
                                                C13.66,6 15.14,6.69 16.22,7.78
                                                L17.65,6.35M19.11,7.11L15,12
                                                H18A6,6 0 0,1 12,18
                                                C10.34,18 8.86,17.31 7.78,16.22
                                                L6.35,17.65C7.8,19.1 9.79,20
                                                12,20A8,8 0 0,0 20,12H23L19.11,7.11Z"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="table-wrapper mt-4">
                            <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 ">
                                <thead class="table-header">
                                    <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">Contract</th>
                                        <th class="min-w-100px">Asset / Vendor</th>
                                        <th class="min-w-100px">Frequency</th>
                                        
                                        <th class="min-w-100px text-center">Annual</th>
                                        <th class="min-w-100px">Next Service</th>
                                        <th class="min-w-100px">On-Time</th>
                                        <th class="min-w-100px">Ends</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="table-body text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">AMC-2024-118</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Passenger Lift At Tower A</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">Kinetic Vertical System</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="badge bg-label-dark fw-semibold fs-7">Quarterly</label>
                                        </td>
                                        <td>
                                            <label >&#8377; 48,2000</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">04-Apr-2026</label>
                                                <label class="text-danger">In 1 day</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column align-items-end ">
                                                <label class="text-primary">96%</label>
                                                <div class="progress bg-label-primary rounded" style="width:80px;">
                                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 96%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold text-nowrap">16-May-2026</label>
                                                <label class="text-danger">In 26 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge  rounded px-2 py-2"  style="background:#FDEBD2; color:#C47A1B;">
                                                Renewal Due
                                            </label>
                                        </td>
                                        
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEndAMC"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">AMC-2024-119</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Fire Alarm System - Block B</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">SafeGuard Technologies</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="badge bg-label-dark fw-semibold fs-7">Monthly</label>
                                        </td>
                                        <td>
                                            <label>&#8377; 1,15,000</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">02-Apr-2026</label>
                                                <label class="text-danger">In 3 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column align-items-end">
                                                <label class="text-primary">78%</label>
                                                <div class="progress bg-label-primary rounded" style="width:80px;">
                                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 78%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold text-nowrap">12-May-2026</label>
                                                <label class="text-danger">In 22 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E8F5E9; color:#2E7D32;">
                                                Active
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEndAMC"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">AMC-2024-120</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Diesel Generator Maintenance</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">PowerMax Solutions</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="badge bg-label-dark fw-semibold fs-7">Yearly</label>
                                        </td>
                                        <td>
                                            <label>&#8377; 2,80,000</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">15-Mar-2026</label>
                                                <label class="text-danger">Expired 5 days ago</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column align-items-end">
                                                <label class="text-primary">100%</label>
                                                <div class="progress bg-label-primary rounded" style="width:80px;">
                                                    <div class="progress-bar bg-primary" style="width: 100%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold text-nowrap">15-Mar-2027</label>
                                                <label class="text-danger">In 330 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E8F5E9; color:#2E7D32;">
                                                Active
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEndAMC"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">AMC-2024-121</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">CCTV Surveillance System</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">VisionTech Security</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="badge bg-label-dark fw-semibold fs-7">Half-Yearly</label>
                                        </td>
                                        <td>
                                            <label>&#8377; 95,000</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">20-Apr-2026</label>
                                                <label class="text-danger">In 10 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column align-items-end">
                                                <label class="text-primary">64%</label>
                                                <div class="progress bg-label-primary rounded" style="width:80px;">
                                                    <div class="progress-bar bg-primary" style="width: 64%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold text-nowrap">20-Oct-2026</label>
                                                <label class="text-danger">In 180 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#FDEBD2; color:#C47A1B;">
                                                Renewal Due
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEndAMC"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="text-truncate max-w-175px">AMC-2024-122</label>
                                        </td>
                                        <td>
                                            <div class="text-truncate" style="max-width:150px;">Air Conditioning Units - Floor 3</div>
                                            <div>
                                                <label class="text-dark text-truncate" style="max-width:150px;">CoolBreeze Services</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="badge bg-label-dark fw-semibold fs-7">Quarterly</label>
                                        </td>
                                        <td>
                                            <label>&#8377; 1,75,000</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold">05-Apr-2026</label>
                                                <label class="text-danger">In 2 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column align-items-end">
                                                <label class="text-primary">88%</label>
                                                <div class="progress bg-label-primary rounded" style="width:80px;">
                                                    <div class="progress-bar bg-primary" style="width: 88%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fw-semibold text-nowrap">05-Jul-2026</label>
                                                <label class="text-danger">In 75 days</label>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="fs-8 badge rounded px-2 py-2" style="background:#E8F5E9; color:#2E7D32;">
                                                Active
                                            </label>
                                        </td>
                                        <td align="center"> 
                                            <span data-bs-toggle="offcanvas" data-bs-target="#offcanvasEndAMC"> 
                                                <i class="mdi mdi-eye fs-4 text-black me-1 cursor-pointer"></i>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<div class="offcanvas offcanvas-end viewEdit" style="width:565px;" tabindex="-1" id="offcanvasEnd" aria-labelledby="offcanvasEndLabel">
  <div class="offcanvas-header border-bottom">
    <div class="d-flex align-items-center gap-2">
        <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
            ISAMM
        </label>
        <div class="d-flex flex-column">
            <label class="text-black fs-6 fw-semibold text-truncate" style="max-width:200px;">Global Fleet Vehicle Policy</label>
            <label class="text-dark fs-8">INS-0481</label>
        </div>
    </div>
    <button type="button" class="btn-close text-reset border border-dark" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>

  <div class="offcanvas-body ">
    <div class="row g-3">
        <div class="col-lg-12 d-flex align-items-end justify-content-between">
            <div class="d-flex flex-column">
                <label class="text-dark fs-8">Annual Premium</label>
                 <label class="text-black fs-3 fw-semibold ">&#8377; 48,200</label>
            </div>
            <label class="fs-8 badge rounded px-2 py-2" style="background:#FDEBD2; color:#C47A1B;">
                Renewal Due
            </label>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="d-flex align-items-center justify-content-between gap-2">
                            <div class="d-flex flex-column">
                                <label class="fs-8 fw-semibold text-dark">Covered Assets</label>
                                <label class="fs-6 fw-semibold text-black">34</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="d-flex align-items-center justify-content-between gap-2">
                            <div class="d-flex flex-column">
                                <label class="fs-8 fw-semibold text-dark">Policy Term</label>
                                <label class="fs-6 fw-semibold text-black">Annual</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                          <div class="col-lg-12 pb-2 mb-2 border-bottom">
                                <div class="text-black fs-6 fw-semibold">
                                    Policy Detials
                                </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Policy No.</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Ins-0481
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Type</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Vehicle
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Insurer</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Meridian Assurance
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Owner</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Nithish Kumar M K
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Start Date</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              01-Apr-2025
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">End Date</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              01-Apr-2026
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Premium Freq.</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Annual
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Documents
                                </div>
                                <span class="badge bg-dark text-white">02</span>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <div class="row">
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2 border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="mdi mdi-file-document-outline fs-4"></span>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">Policy_schedule_2025.pdf</label>
                                                <label class="text-dark fs-8">2.1 MB . V3</label>
                                            </div>
                                        </div>
                                        <span class="mdi mdi-download cursor-pointer fs-4"></span>                                        
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between py-2  border-bottom">
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="mdi mdi-file-document-outline fs-4"></span>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">Endorsemwnt_add_vehicle.pdf</label>
                                                <label class="text-dark fs-8">184 KB . V1</label>
                                            </div>
                                        </div>
                                        <span class="mdi mdi-download cursor-pointer fs-4"></span>                                        
                                    </div>
                                    <div class="col-lg-12 d-flex align-items-center justify-content-between pt-2 ">
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="mdi mdi-file-document-outline fs-4"></span>
                                            <div class="d-flex flex-column">
                                                <label class="text-black fs-7 fw-semibold text-truncate" style="max-width:200px;">Renewal_quote_2026.pdf</label>
                                                <label class="text-dark fs-8">412 KB . V1</label>
                                            </div>
                                        </div>
                                        <span class="mdi mdi-download cursor-pointer fs-4"></span>                                        
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Claims
                                </div>
                                <span class="badge bg-dark text-white">02</span>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1">
                                    <thead>
                                        <tr class="text-start align-top  fw-bold fs-7 gs-0 bg-label-dark">
                                            <th class="min-w-100px text-black">Claims</th>
                                            <th class="min-w-100px text-black">Incident</th>
                                            <th class="min-w-100px text-black">Amount</th>
                                            <th class="min-w-100px text-black">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-medium fs-7">
                                        <tr>
                                            <td>
                                                <label class="">CLM-240918</label>
                                            </td>
                                            <td>
                                                <label class="">18-Sep-2026</label>
                                            </td>
                                            <td>
                                                <label class="">&#8377; 16,870</label>
                                            </td>
                                            <td>
                                                <label class="fs-7 badge rounded px-3 py-2 bg-label-success" >
                                                    Paid
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="">CLM-230412</label>
                                            </td>
                                            <td>
                                                <label class="">12-Apr-2026</label>
                                            </td>
                                            <td>
                                                <label class="">&#8377; 5,784</label>
                                            </td>
                                            <td>
                                                <label class="fs-7 badge rounded px-3 py-2 bg-label-success" >
                                                    Paid
                                                </label>
                                            </td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Renewal History
                                </div>
                                <span class="badge bg-dark text-white">03</span>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1">
                                    <thead>
                                        <tr class="text-start align-top  fw-bold fs-7 gs-0 bg-label-dark">
                                            <th class="min-w-100px text-black">Date</th>
                                            <th class="min-w-100px text-black">Action</th>
                                            <th class="min-w-100px text-black">Actor</th>
                                            <th class="min-w-100px text-black">Premium</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-medium fs-7">
                                        <tr>
                                            <td>
                                                <label class="">12-Apr-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Renewed</label>
                                            </td>
                                            <td>
                                                 <label class="">R. Malhotra</label>
                                            </td>
                                            <td>
                                                <label class="">&#8377; 16,870</label>
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td>
                                                <label class="">10-Apr-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Renewed</label>
                                            </td>
                                            <td>
                                                 <label class="">R. Malhotra</label>
                                            </td>
                                            <td>
                                                <label class="">&#8377; 48,870</label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="">10-May-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Created</label>
                                            </td>
                                            <td>
                                                 <label class="">Priya Shah</label>
                                            </td>
                                            <td>
                                                <label class="">&#8377; 42,417</label>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
    <div class="offcanvas-footer border-top p-3 pt-4 d-flex justify-content-end gap-2">
        
        <button type="button" class="btn btn-sm btn-light"  data-bs-toggle="modal" data-bs-target="#kt_modal_add_document" >
            Export
        </button>
        <button type="button" class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#kt_modal_file_insurance_claim">
            File Claim
        </button>
        <button type="button" class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#kt_modal_surrender " >
            Surrender
        </button>
        <button type="button" class="btn btn-sm btn-primary">
            Initiate Renewal
        </button>
    </div>
</div>

<div class="offcanvas offcanvas-end " style="width:626px;" tabindex="-1" id="offcanvasEndAMC" aria-labelledby="offcanvasEndLabel">
  <div class="offcanvas-header border-bottom">
    <div class="d-flex align-items-center gap-2">
        <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
            ISAMM
        </label>
        <div class="d-flex flex-column">
            <label class="text-black fs-6 fw-semibold text-truncate" style="max-width:200px;">Passenger Lift - Tower A AMC</label>
            <label class="text-dark fs-8">AMC-2024-118</label>
        </div>
    </div>
    <button type="button" class="btn-close text-reset border border-dark" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>

  <div class="offcanvas-body ">
    <div class="row g-3">
        <div class="col-lg-12 d-flex align-items-end justify-content-between">
            <div class="d-flex flex-column">
                <label class="text-dark fs-8">Annual Contract Value</label>
                 <label class="text-black fs-3 fw-semibold ">&#8377; 8,400</label>
            </div>
            <div class="d-flex flex-column">
                <label class="text-dark fs-8">On Time Delivery</label>
                 <label class="text-black fs-3 fw-semibold ">96%</label>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                          <div class="col-lg-12 pb-2 mb-2 border-bottom">
                                <div class="text-black fs-6 fw-semibold">
                                    Contract Detials
                                </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Contract Ref.</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              AMC-2024-118
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Asset</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Passenger Lift - Tower A
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Vendor</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Kinetic Vertical Systems
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Service Freq</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                                Quarterly
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">End Date</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              16-May-2026
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Next Date</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              21-Apr-2026
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Work Schedule
                                </div>
                                <span class="badge bg-dark text-white">04</span>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1">
                                    <thead>
                                        <tr class="text-start align-top  fw-bold fs-7 gs-0 bg-label-dark">
                                            <th class="min-w-100px text-black">Date</th>
                                            <th class="min-w-100px text-black">Techinician</th>
                                            <th class="min-w-100px text-black">Scope</th>
                                            <th class="min-w-100px text-black">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-medium fs-7">
                                        <tr>
                                            <td>
                                                <label class="text-nowrap">21-Apr-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Praveen S</label>
                                            </td>
                                            <td>
                                                <label class="">Quarterly Inspection</label>
                                            </td>
                                            <td>
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                    Planned
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="text-nowrap">25-Apr-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Arjun Babu G G</label>
                                            </td>
                                            <td>
                                                <label class="">Routine Maintenance</label>
                                            </td>
                                            <td>
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                    Planned
                                                </label>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <label class="text-nowrap">30-Apr-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Karthik S</label>
                                            </td>
                                            <td>
                                                <label class="">Safety Check</label>
                                            </td>
                                            <td>
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                    Planned
                                                </label>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <label class="text-nowrap">05-May-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Sesha Anand K</label>
                                            </td>
                                            <td>
                                                <label class="">Emergency System Test</label>
                                            </td>
                                            <td>
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#FDEBD2; color:#C47A1B;">
                                                    Schedule
                                                </label>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Service History
                                </div>
                                <span class="badge bg-dark text-white">04</span>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1">
                                    <thead>
                                        <tr class="text-start align-top  fw-bold fs-7 gs-0 bg-label-dark">
                                            <th class="min-w-100px text-black">Date</th>
                                            <th class="min-w-100px text-black">Techinician</th>
                                            <th class="min-w-100px text-black">Scope</th>
                                            <th class="min-w-100px text-black">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-medium fs-7">
                                        <tr>
                                            <td>
                                                <label class="text-nowrap">21-Apr-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Praveen S</label>
                                            </td>
                                            <td>
                                                <label class="">Quarterly Inspection</label>
                                            </td>
                                            <td>
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E8F5E9; color:#2E7D32;">
                                                    Completed
                                                </label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label class="text-nowrap">25-Apr-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Arjun Babu G G</label>
                                            </td>
                                            <td>
                                                <label class="">Routine Maintenance</label>
                                            </td>
                                            <td>
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E8F5E9; color:#2E7D32;">
                                                    Completed
                                                </label>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <label class="text-nowrap">30-Apr-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Karthik S</label>
                                            </td>
                                            <td>
                                                <label class="">Safety Check</label>
                                            </td>
                                            <td>
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
                                                    Ad Hoc
                                                </label>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <label class="text-nowrap">05-May-2026</label>
                                            </td>
                                            <td>
                                                <label class="">Sesha Anand K</label>
                                            </td>
                                            <td>
                                                <label class="">Emergency System Test</label>
                                            </td>
                                            <td>
                                                <label class="fs-8 badge rounded px-2 py-2" style="background:#E8F5E9; color:#2E7D32;">
                                                    Completed
                                                </label>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
    <div class="offcanvas-footer border-top p-3 pt-4 d-flex justify-content-end gap-2">
        
        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="offcanvas" >
            Export
        </button>
        <button type="button" class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#kt_modal_schedule_maintenance">
            Schedule Visit
        </button>
        <button type="button" class="btn btn-sm btn-light"  data-bs-toggle="modal" data-bs-target="#kt_modal_service_report">
            Service Report
        </button>
        <button type="button" class="btn btn-sm btn-primary">
            Initiate Renewal
        </button>
    </div>
</div>

<!--begin::Modal - Add Policy -->
<div class="modal fade" id="kt_modal_add_policy" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Create Policy</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Policy name<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Policy name">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Policy number<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Policy number">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                        <select class="select3 form-select" onchange="changeType(this.value)">
                            <option value="">Select Type</option>
                            <option value="1">Life</option>
                            <option value="2">Medical</option>
                            <option value="3">Vehicle</option>
                            <option value="4">Business</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Insurer<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Insurer">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Premium (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Premium (₹)">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Sum assured (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Sum assured (₹)">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Registered date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Start<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">End<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Nominee<span
                                class="text-danger  nominee_type">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Nominee">
                    </div>
                    <div class="col-lg-6 mb-3 vehical_type d-none">
                        <label class="text-black mb-1 fs-6 fw-semibold">Vehicle number<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Vehicle number">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1"  placeholder="Enter Description"></textarea>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold mt-2">Attachment</label>
                        <div class="dropzone custom-dropzone" data-dropzone="amc">
                            <div class="dz-message needsclick">
                                <div class="upload-box text-center d-flex align-items-center justify-content-center gap-2">
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="mdi mdi-cloud-upload-outline upload-icon fs-1"></i>
                                        <h6 class="mb-1">Drop files here</h6>
                                    </div>
                                    <p class="text-muted mb-1 fs-7">or</p>
                                    <a type="button" class="text-primary browse-btn fs-6">
                                        Browse Files
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Create Policy</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add  Policy-->


<!--begin::Modal - Add AMC -->
<div class="modal fade" id="kt_modal_add_amc" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Create AMC</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contract Id<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Contract Id">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Asset Name<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Asset Name">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Vendor<span class="text-danger">*</span></label>
                        <select class="select3 form-select" onchange="changeType(this.value)">
                            <option value="">Select Vendor</option>
                            <option value="1">G.S Electronics and Fittings</option>
                            <option value="2">Premium Gadget World</option>
                            <option value="3">Wood & furnitures</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service Frequency<span class="text-danger">*</span></label>
                        <select class="select3 form-select" onchange="changeType(this.value)">
                            <option value="">Select Service Frequency</option>
                            <option value="1">Monthly</option>
                            <option value="2">Quarterly</option>
                            <option value="3">Yearly</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Annual Value (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Annual Value (₹)">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">End Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Next Service date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1"  placeholder="Enter Description"></textarea>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold mt-2">Attachment</label>
                        <div class="dropzone custom-dropzone" data-dropzone="amc">
                            <div class="dz-message needsclick">
                                <div class="upload-box text-center d-flex align-items-center justify-content-center gap-2">
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="mdi mdi-cloud-upload-outline upload-icon fs-1"></i>
                                        <h6 class="mb-1">Drop files here</h6>
                                    </div>
                                    <p class="text-muted mb-1 fs-7">or</p>
                                    <a type="button" class="text-primary browse-btn fs-6">
                                        Browse Files
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Create AMC</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add AMC-->

<!--begin::Modal - Update Policy -->
<div class="modal fade" id="kt_modal_edit_policy" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update Policy</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Policy name<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Policy name" value="Life Secure Future Plan"> 
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Policy number<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Policy number" value="LIC-PL-784512963">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                        <select class="select3 form-select" onchange="changeTypeedit(this.value)">
                            <option value="">Select Type</option>
                            <option value="1" selected>Life</option>
                            <option value="2">Medical</option>
                            <option value="3">Vehicle</option>
                            <option value="4">Business</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Insurer<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Insurer" value="LIC of India">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Premium (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Premium (₹)" value="12,500">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Sum assured (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Sum assured (₹)" value="5,00,000">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Registered date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="15-Mar-2026" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Start<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="01-Apr-2026" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">End<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="31-Mar-2036" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Nominee<span
                                class="text-danger  nominee_typeedit">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Nominee" value="Arjun Kumar (Father)">
                    </div>
                    <div class="col-lg-6 mb-3 vehical_typeedit d-none">
                        <label class="text-black mb-1 fs-6 fw-semibold">Vehicle number<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Vehicle number">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1"  placeholder="Enter Description">This policy provides long-term life coverage with maturity benefits and financial protection for the nominee in case of any unforeseen event.</textarea>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold mt-2">Attachment</label>
                        <div class="dropzone custom-dropzone" data-dropzone="amc">
                            <div class="dz-message needsclick">
                                <div class="upload-box text-center d-flex align-items-center justify-content-center gap-2">
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="mdi mdi-cloud-upload-outline upload-icon fs-1"></i>
                                        <h6 class="mb-1">Drop files here</h6>
                                    </div>
                                    <p class="text-muted mb-1 fs-7">or</p>
                                    <a type="button" class="text-primary browse-btn fs-6">
                                        Browse Files
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Update Policy</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update  Policy-->


<!--begin::Modal - Surrender policy -->
<div class="modal fade" id="kt_modal_surrender" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Surrender Policy</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">
                    <!-- Basic -->
                     <div class="col-lg-12 mb-3">
                        <div class="p-3 d-flex align-items-center gap-3  rounded " style="background:#FFEBD2;">
                            <span class="mdi mdi-alert" style="color:#C4914A;"></span>
                            <label class="fs-7" style="color:#C4914A;">Surrender ends coverage from the effective date. Pro-rata premium refund (if any) is processed by the insurer.</label>
                        </div>
                     </div>
                     <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Effective date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Estimated surrender value (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Estimated surrender value (₹)">
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Reason</option>
                            <option value="1">Consolidating coverage</option>
                            <option value="2">Cost optimisation</option>
                            <option value="3">Asset disposed / not in use</option>
                            <option value="4">Switching insurer</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="form-check mt-2">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1" />
                            <label class="form-check-label" for="defaultCheck1">
                                I confirm the policy will be surrendered on the date above.
                            </label>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Submit Surrender</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Surrender policy -->

<!--begin::Modal - File insurance claim -->
<div class="modal fade" id="kt_modal_file_insurance_claim" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">File Insurance Claim</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="row">
                    <!-- Basic -->
                     
                     <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Incident date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Claim type<span class="text-danger">*</span></label>
                        <select class="select3 form-select" onchange="HandelclaimType(this.value)" >
                            <option value="">Select Claim type</option>
                            <option value="1" selected>Accident</option>
                            <option value="2">Hospitalisation</option>
                            <option value="3">Theft</option>
                            <option value="4">Damage</option>
                            <option value="5">Death</option>
                            <option value="6">Other</option>
                        </select>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Amount claimed (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Amount claimed (₹)">
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1"  placeholder="Enter Description"></textarea>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold mt-2">Attachment</label>
                        <div class="dropzone custom-dropzone" data-dropzone="amc">
                            <div class="dz-message needsclick">
                                <div class="upload-box text-center d-flex align-items-center justify-content-center gap-2">
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="mdi mdi-cloud-upload-outline upload-icon fs-1"></i>
                                        <h6 class="mb-1">Drop files here</h6>
                                    </div>
                                    <p class="text-muted mb-1 fs-7">or</p>
                                    <a type="button" class="text-primary browse-btn fs-6">
                                        Browse Files
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="p-3  rounded " style="background:#FFEBD2;">
                            <div class="row g-0">
                                <div class="col-lg-12 ">
                                    <label >Insurer: <label class="text-black">Meridian Assurance</label> · Policy: <label class="text-black">INS-0481</label></label>
                                </div>
                                <div class="col-lg-12 mb-0">
                                    <label >Claim <label class="text-black" id="claimtype">#CLM-657332</label> will be assigned on submission.</label>
                                </div>
                            </div>
                        </div>
                     </div>
                    
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Submit Claim</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - File insurance claim -->


<!--begin::Modal -  Service report -->
<div class="modal fade" id="kt_modal_service_report" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Service Report</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Visit date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Technician<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Technician">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Outcome<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Outcome</option>
                            <option value="1">Completed</option>
                            <option value="2">Partial</option>
                            <option value="3">Follow-up required</option>
                            <option value="4">Cancelled</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Parts replaced </label>
                        <input type="text" class="form-control" placeholder="Enter Parts replaced ">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Next service due<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <div class="rating-container d-flex aling-items-center justify-content-between">
                            <div class="d-flex flex-column">
                                <label class="text-black mb-1 fs-6 fw-semibold">Service rating</label>
                                <div class="d-flex align-items-center gap-3"> 
                                    <div class="stars" id="stars">
                                        <span class="mdi mdi-star-outline fs-2" data-value="1"></span>
                                        <span class="mdi mdi-star-outline fs-2" data-value="2"></span>
                                        <span class="mdi mdi-star-outline fs-2" data-value="3"></span>
                                        <span class="mdi mdi-star-outline fs-2" data-value="4"></span>
                                        <span class="mdi mdi-star-outline fs-2" data-value="5"></span>
                                    </div>
                                    <div class="value fs-4 pt-1" id="ratingValue">0/5</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1"  placeholder="Enter Description"></textarea>
                    </div>

                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold mt-2">Attachment</label>
                        <div class="dropzone custom-dropzone" data-dropzone="amc">
                            <div class="dz-message needsclick">
                                <div class="upload-box text-center d-flex align-items-center justify-content-center gap-2">
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="mdi mdi-cloud-upload-outline upload-icon fs-1"></i>
                                        <h6 class="mb-1">Drop files here</h6>
                                    </div>
                                    <p class="text-muted mb-1 fs-7">or</p>
                                    <a type="button" class="text-primary browse-btn fs-6">
                                        Browse Files
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Save Report</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Service report-->

<!--begin::Modal - Schedule maintenance visit  -->
<div class="modal fade" id="kt_modal_schedule_maintenance" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Schedule Maintenance Visit</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">
                    <!-- Basic -->
                     
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Date" class="form-control common_datepicker" readonly value="" />
                        </div>
                    </div>

                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Time slot<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-clock-outline fs-4"></i></span>
                            <input type="text" id="policy_end_date" name="policy_end_date" placeholder="Select Time" class="form-control common_timepicker" readonly value="" />
                        </div>
                    </div>
                   
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Technician<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Technician</option>
                            <option value="1">Seshanand k</option>
                            <option value="2">Praveen M</option>
                            <option value="3">Arun L</option>
                            <option value="4">Ram J</option>
                        </select>
                    </div>

                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Scope<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Scope</option>
                            <option value="1">Quarterly inspection</option>
                            <option value="2">Semi-annual service</option>
                            <option value="3">Annual overhaul</option>
                            <option value="4">Parts replacement</option>
                        </select>
                    </div>


                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="2"  placeholder="Enter Description"></textarea>
                    </div>
                    
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal"> Submit Schedule</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Schedule maintenance visit -->


<script>
    $(".list_page").DataTable({
        "ordering": false,
        "pageLength": 25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {

        Dropzone.autoDiscover = false;

        function initDropzones(context = document) {
            context.querySelectorAll(".custom-dropzone").forEach((dzElement) => {

                // ✅ Prevent re-initialization
                if (dzElement.dropzone) return;

                new Dropzone(dzElement, {
                    url: "/upload",
                    paramName: "attachment",
                    maxFilesize: 5,
                    uploadMultiple: true,
                    parallelUploads: 10,
                    acceptedFiles: ".jpg,.jpeg,.png,.pdf,.doc,.docx",

                    clickable: [
                        dzElement,
                        dzElement.querySelector(".browse-btn")
                    ],

                    previewTemplate: `
                        <div class="dz-preview dz-file-preview d-flex align-items-center justify-content-between">
                            <div class="d-flex flex-column flex-grow-1">
                                <span data-dz-name class="text-truncate"></span>
                                <div class="dz-progress mt-1">
                                    <span class="dz-upload" data-dz-uploadprogress></span>
                                </div>
                            </div>

                            <button type="button" class="dz-remove ms-2" data-dz-remove>
                                <i class="mdi mdi-close"></i>
                            </button>
                        </div>
                    `,

                    init: function () {
                        let dz = this;

                        dz.on("addedfile", function () {
                            console.log("File added");
                        });

                        dz.on("uploadprogress", function (file, progress) {
                            let el = file.previewElement.querySelector("[data-dz-uploadprogress]");
                            if (el) el.style.width = progress + "%";
                        });

                        dz.on("success", function () {
                            console.log("Upload success");
                        });
                    }
                });

            });
        }

        // ✅ Initialize on page load
        initDropzones();

        // ✅ Re-init when modal opens (important for dynamic content)
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('shown.bs.modal', function () {
                initDropzones(modal);
            });
        });

    });
</script>

<script>
    function changeType(val){
        const vehical_type = document.querySelector(".vehical_type");
        const nominee_type = document.querySelector(".nominee_type");

        if(val === "3"){
            vehical_type.classList.remove("d-none");
            nominee_type.classList.add("d-none");
        }else{
            vehical_type.classList.add("d-none");
            nominee_type.classList.remove("d-none");
        }
        if(val === "4"){
            vehical_type.classList.add("d-none");
            nominee_type.classList.add("d-none");
        }
    }
</script>


<script>
    function changeTypeedit(val){
        const vehical_typeedit = document.querySelector(".vehical_typeedit");
        const nominee_typeedit = document.querySelector(".nominee_typeedit");

        if(val === "3"){
            vehical_typeedit.classList.remove("d-none");
            nominee_typeedit.classList.add("d-none");
        }else{
            vehical_typeedit.classList.add("d-none");
            nominee_typeedit.classList.remove("d-none");
        }
        if(val === "4"){
            vehical_typeedit.classList.add("d-none");
            nominee_typeedit.classList.add("d-none");
        }
    }
</script>





<script>
    const OffcanvasModalManager = (() => {

    function openModal(targetSelector) {
        const modalEl = document.querySelector(targetSelector.trim());
        if (!modalEl) return;
        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();
    }

    function init() {
        document.addEventListener('click', function (e) {
            const trigger = e.target.closest('[data-bs-toggle="modal"]');
            if (!trigger) return;

            const modalTarget = trigger.getAttribute('data-bs-target');
            if (!modalTarget) return;

            const parentOffcanvas = trigger.closest('.offcanvas');
            if (!parentOffcanvas) return;

            e.preventDefault();
            e.stopPropagation();

            const offcanvasInstance = bootstrap.Offcanvas.getInstance(parentOffcanvas);

            if (offcanvasInstance) {
                parentOffcanvas.addEventListener('hidden.bs.offcanvas', function handler() {
                    parentOffcanvas.removeEventListener('hidden.bs.offcanvas', handler);

                    // ✅ Only remove backdrop, let Bootstrap handle body scroll itself
                    document.querySelectorAll('.offcanvas-backdrop').forEach(el => el.remove());
                    document.body.classList.remove('offcanvas-open');

                    openModal(modalTarget);
                });

                offcanvasInstance.hide();
            } else {
                openModal(modalTarget);
            }
        });
    }

    return { init };
})();

document.addEventListener('DOMContentLoaded', () => {
    OffcanvasModalManager.init();
});
</script>


<script>
    function HandelclaimType(val){
        
        const claimtype = document.getElementById("claimtype");
        if(val === "1"){
            claimtype.innerText = "#CLM-657332"
        }
        if(val === "2"){
            claimtype.innerText = "#CLM-974654"
        }
        if(val === "3"){
            claimtype.innerText = "#CLM-393103"
        }
        if(val === "4"){
            claimtype.innerText = "#CLM-503018"
        }
        if(val === "5"){
            claimtype.innerText = "#CLM-334320"
        }
        if(val === "6"){
            claimtype.innerText = "#CLM-556424"
        }
        
    }
</script>


<script>
    const stars = document.querySelectorAll("#stars span");
    const ratingValue = document.getElementById("ratingValue");

    let currentRating = 0;

    stars.forEach(star => {
    star.addEventListener("click", () => {
        currentRating = star.getAttribute("data-value");
        updateStars(currentRating);
    });
    });

    function updateStars(rating) {
    stars.forEach(star => {
        const value = star.getAttribute("data-value");

        if (value <= rating) {
        star.classList.remove("mdi-star-outline");
        star.classList.add("mdi-star", "active");
        } else {
        star.classList.remove("mdi-star", "active");
        star.classList.add("mdi-star-outline");
        }
    });

    ratingValue.innerText = rating + "/5";
    }
</script>

@endsection
