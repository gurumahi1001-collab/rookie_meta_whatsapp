@extends('layouts/layoutMaster')

@section('title', 'Manage RD Accounts')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/dropzone/dropzone.scss', 
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
    'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 
    'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/dropzone/dropzone.js', 
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Manage RD Accounts</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home me-1"></i>Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-shield-crown-outline me-1"></i>Corporate Admin
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                          Policies & RD Accounts
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white"  data-bs-toggle="modal" data-bs-target="#kt_modal_add_yerd">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add New RD Plan
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                        <div class="d-flex flex-column">
                            <label class="fs-7 fw-semibold text-dark">Annual commitment</label>
                            <label class="fs-2 fw-semibold text-black">₹ 6,51,000</label>
                        </div>
                        <label>
                            <span class="badge bg-label-secondary rounded-circle">
                                <i class="mdi mdi-currency-rupee fs-3"></i>
                            </span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                        <div class="d-flex flex-column">
                            <label class="fs-7 fw-semibold text-dark">Accumulated to date</label>
                            <label class="fs-2 fw-semibold text-black">₹ 4,88,000</label>
                        </div>
                        <label>
                            <span class="badge bg-label-danger rounded-circle">
                                <i class="mdi mdi-calendar-month fs-3"></i>
                            </span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                        <div class="d-flex flex-column">
                            <label class="fs-7 fw-semibold text-dark">Monthly allocation</label>
                            <label class="fs-2 fw-semibold text-black">₹ 54,300 </label>
                        </div>
                        <label>
                            <span class="badge bg-label-success rounded-circle">
                                <i class="mdi mdi-calendar-today fs-3"></i>
                            </span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                        <div class="d-flex flex-column">
                            <label class="fs-7 fw-semibold text-dark">Shortfall alerts</label>
                            <div class="d-flex align-items-center gap-2">
                                <label class="fs-2 fw-semibold text-black">1</label>
                                <small class="pt-2">Active</small>
                            </div>
                        </div>
                        <label>
                            <span class="badge bg-label-dark rounded-circle">
                                <i class=" mdi mdi-alert fs-3"></i>
                            </span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="col-lg-12 mt-4">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span style="display:flex;align-items:center;gap:4px;">8-month cashflow forecast</span>
                    <div style="display:flex;gap:16px;margin-bottom:10px;font-size:12px;color:var(--color-text-secondary);">
                        <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#3a7d44;"></span>Inflow (RD)</span>
                        <span style="display:flex;align-items:center;gap:4px;"><span style="width:10px;height:10px;border-radius:2px;background:#b07d1a;"></span>Outflow (disbursals)</span>
                    </div>
                    
                </div>
                <div style="position:relative;width:100%;height:200px;">
                    <canvas id="inflowChart" role="img" aria-label="Grouped bar chart showing monthly inflow and outflow from May to December">Monthly inflow RD and outflow disbursals from May to December.</canvas>
                </div>
            </div>
            <div class="col-lg-12 mt-4">
                <div class="d-flex align-items-center justify-content-between mb-1 gap-2">
                    <div class="badge d-flex align-items-center gap-2 rounded-2 fw-semibold  fs-6 bg-label-primary">
                        <i class="mdi mdi-widgets fs-3"></i>
                        <label class="text-black">Virtual RD accounts</label>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <div class="searchBar">
                            <input class="searchQueryInput" type="text" name="searchQueryInput" placeholder="Enter Type / Status" value="" oninput="toggleIcons(this)">
                            <a href="http://192.168.30.6/Jegan/ERP/ERP-Elysium-Groups/public/manage_amc-contract" class="searchQuerySubmit searchIcon">
                                <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                    <path fill="#ab2b22" d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                        C16,11.11 15.41,12.59 14.44,13.73
                                        L14.71,14H15.5L20.5,19L19,20.5
                                        L14,15.5V14.71L13.73,14.44
                                        C12.59,15.41 11.11,16
                                        9.5,16A6.5,6.5 0 0,1 3,9.5
                                        A6.5,6.5 0 0,1 9.5,3
                                        M9.5,5C7,5 5,7 5,9.5
                                        C5,12 7,14 9.5,14
                                        C12,14 14,12 14,9.5
                                        C14,7 12,5 9.5,5Z"></path>
                                </svg>
                            </a>
                            <button class="searchQuerySubmit refreshIcon" onclick="clearInput()" style="display:none;">
                                <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                    <path fill="#ab2b22" d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                        A8,8 0 0,0 4,12H1L4.89,16.89
                                        L9,12H6A6,6 0 0,1 12,6
                                        C13.66,6 15.14,6.69 16.22,7.78
                                        L17.65,6.35M19.11,7.11L15,12
                                        H18A6,6 0 0,1 12,18
                                        C10.34,18 8.86,17.31 7.78,16.22
                                        L6.35,17.65C7.8,19.1 9.79,20
                                        12,20A8,8 0 0,0 20,12H23L19.11,7.11Z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="p-3 border rounded d-flex flex-column gap-2">
                    <div class="d-flex align-items-center justify-content-between">
                        <div class="d-flex gap-2 align-items-center">
                            <small>RD-F26-01</small>
                            <span class="badge bg-label-dark">Insurance</span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-label-info text-black">Active</span>
                            <div class="text-center">
                                
                                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important">
                                    <a href="javascript:;" class="dropdown-item"  data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd" >
                                        <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label class="text-dark fw-medium fs-5">Group Medical Premium Renewal</label>
                    <div class="d-flex flex-column">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <label class="fw-semibold text-dark fs-3">₹ 6,51,000</label>
                            <label class="fw-semibold text-dark">/</label>
                            <label class="fw-medium text-dark">₹ 1,86,400</label>
                        </div>
                        <div class="progress bg-label-primary rounded">
                            <div class="progress-bar " role="progressbar" style="width: 30%; background:#954c47;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-3">
                            <small class="fs-7">Due Jan 1 2026 In 38d</small>
                            <small class="fs-7">₹ 15,533 / mo</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="p-3 border rounded d-flex flex-column gap-2">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-2">
                            <small>RD-F26-02</small>
                            <span class="badge bg-label-dark">Advance Tax</span>
                        </div>
                       
                        <div class="d-flex align-items-center gap-2">
                             <span class="badge bg-label-danger text-black">Short Fall</span>
                            <div class="text-center">
                                
                                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important">
                                    <a href="javascript:;" class="dropdown-item"  data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd" >
                                        <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label class="fw-medium fs-5">Quarterly Advance Tax</label>
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <label class="fw-semibold text-dark fs-3">₹ 2,10,000</label>
                            <label class="fw-semibold text-dark">/</label>
                            <label class="fw-medium text-dark">₹ 3,00,000</label>
                        </div>
                        <div class="progress bg-label-primary rounded">
                            <div class="progress-bar " role="progressbar" style="width: 30%; background:#954c47;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="d-flex justify-content-between mt-2">
                            <small>Due Feb 10 2026</small>
                            <small>₹ 25,000 / mo</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="p-3 border rounded d-flex flex-column gap-2">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-2">
                            <small>RD-F26-03</small>
                            <span class="badge bg-label-dark">Subscription</span>
                        </div>
                        
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-label-info text-black">Active</span>
                            <div class="text-center">
                                
                                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important">
                                    <a href="javascript:;" class="dropdown-item"  data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd" >
                                        <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label class="fw-medium fs-5">Software Subscription Renewal</label>
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <label class="fw-semibold text-dark fs-3">₹ 80,000</label>
                            <label class="fw-semibold text-dark">/</label>
                            <label class="fw-medium text-dark">₹ 1,20,000</label>
                        </div>
                        <div class="progress bg-label-primary rounded">
                            <div class="progress-bar " role="progressbar" style="width: 30%; background:#954c47;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="d-flex justify-content-between mt-2">
                            <small>Due Mar 5 2026</small>
                            <small>₹ 6,500 / mo</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="p-3 border rounded d-flex flex-column gap-2">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-2">
                            <small>RD-F26-04</small>
                            <span class="badge bg-label-dark">Auditor Fees</span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                             <span class="badge bg-label-danger text-black">Short Fall</span>
                            <div class="text-center">
                                
                                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important">
                                    <a href="javascript:;" class="dropdown-item"  data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd" >
                                        <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label class="fw-medium fs-5">Annual Audit Charges</label>
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <label class="fw-semibold text-dark fs-3">₹ 50,000</label>
                            <label class="fw-semibold text-dark">/</label>
                            <label class="fw-medium text-dark">₹ 1,00,000</label>
                        </div>
                        <div class="progress bg-label-primary rounded">
                            <div class="progress-bar " role="progressbar" style="width: 30%; background:#954c47;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="d-flex justify-content-between mt-2">
                            <small>Due Apr 15 2026</small>
                            <small>₹ 8,000 / mo</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="p-3 border rounded d-flex flex-column gap-2">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-2">
                            <small>RD-F26-05</small>
                            <span class="badge bg-label-dark">Prof. Tax</span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-label-info text-black">Active</span>
                            <div class="text-center">
                                
                                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important">
                                    <a href="javascript:;" class="dropdown-item"  data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd" >
                                        <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label class="fw-medium fs-5">Professional Tax Payment</label>
                    <div>
                        
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <label class="fw-semibold text-dark fs-3">₹ 30,000</label>
                            <label class="fw-semibold text-dark">/</label>
                            <label class="fw-medium text-dark">₹ 40,000</label>
                        </div>
                        <div class="progress bg-label-primary rounded">
                            <div class="progress-bar " role="progressbar" style="width: 30%; background:#954c47;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="d-flex justify-content-between mt-2">
                            <small>Due May 1 2026</small>
                            <small>₹ 3,500 / mo</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="p-3 border rounded d-flex flex-column gap-2">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex gap-2">
                            <small>RD-F26-06</small>
                            <span class="badge bg-label-dark">Insurance</span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                             <span class="badge bg-label-danger text-black">Short Fall</span>
                            <div class="text-center">
                                
                                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important">
                                    <a href="javascript:;" class="dropdown-item"  data-bs-toggle="offcanvas" data-bs-target="#offcanvasEnd" >
                                        <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label class="fw-medium fs-5">Vehicle Insurance Renewal</label>
                    <div>
                        
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <label class="fw-semibold text-dark fs-3">₹ 20,000</label>
                            <label class="fw-semibold text-dark">/</label>
                            <label class="fw-medium text-dark">₹ 50,000</label>
                        </div>
                        <div class="progress bg-label-primary rounded">
                            <div class="progress-bar " role="progressbar" style="width: 30%; background:#954c47;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <div class="d-flex justify-content-between mt-2">
                            <small>Due Jun 10 2026</small>
                            <small>₹ 2,000 / mo</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="offcanvas offcanvas-end " style="width:700px;" tabindex="-1" id="offcanvasEnd" aria-labelledby="offcanvasEndLabel">
  <div class="offcanvas-header border-bottom">
    <div class="d-flex align-items-center gap-2">
        <label class="fs-8 badge rounded px-2 py-2" style="background:#E3F2FD; color:#1E88E5;">
            YERD
        </label>
        <div class="d-flex flex-column">
            <label class="text-black fs-6 fw-semibold text-truncate" style="max-width:700px;">Group Medical Premium Renewal</label>
            <label class="text-dark fs-8">RD-F26-01</label>
        </div>
    </div>
    <button type="button" class="btn-close text-reset border border-dark" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>

  <div class="offcanvas-body ">
    <div class="row g-3">
        <div class="col-lg-12 d-flex align-items-center justify-content-between">
            <div class="d-flex flex-column">
                <label class="text-dark fs-8">Accumulated / target</label>
                <div class="d-flex align-items-center gap-2">
                    <label class="fw-semibold text-dark fs-3">₹ 6,51,000</label>
                    <label class="fw-semibold text-dark">/</label>
                    <label class="fw-medium text-dark">₹ 1,86,400</label>
                </div>
            </div>
            <label class="fw-semibold text-dark fs-3">75.0%</label>
        </div>
        <div class="col-lg-12">
            <div class="progress bg-label-primary rounded">
                <div class="progress-bar " role="progressbar" style="width: 30%; background:#954c47;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-4">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="d-flex align-items-center justify-content-between gap-2">
                            <div class="d-flex flex-column">
                                <label class="fs-8 fw-semibold text-dark">Monthly</label>
                                <label class="fs-6 fw-semibold text-black">₹ 15,533</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="d-flex align-items-center justify-content-between gap-2">
                            <div class="d-flex flex-column">
                                <label class="fs-8 fw-semibold text-dark">Due in</label>
                                <label class="fs-6 fw-semibold text-black">38d</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="d-flex align-items-center justify-content-between gap-2">
                            <div class="d-flex flex-column">
                                <label class="fs-8 fw-semibold text-dark">Remaining target</label>
                                <label class="fs-6 fw-semibold text-black">₹ 46,600</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                          <div class="col-lg-12 pb-2 mb-2 border-bottom">
                                <div class="text-black fs-6 fw-semibold">
                                    Configuration
                                </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Expense</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Group Medical Premium Renewal
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Category</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Insurance
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Target amount</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              ₹ 1,86,400
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Due date</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Jun 1, 2026
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Contribution start</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Jul 1, 2025
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 mb-4">
                            <div class="row">
                              <div class="col-4 text-dark fs-6 fw-semibold">Owner</div>
                              <div class="col-1 text-black fs-6 fw-bold">:</div>
                              <div class="col-7 text-black fs-6 fw-semibold">
                              Finance
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card rounded border p-3" style="box-shadow: none; background:#F8F9FA;">
                        <div class="row">
                            <div class="col-lg-12 pb-2 mb-2 border-bottom d-flex align-items-center justify-content-between">
                                <div class="text-black fs-6 fw-semibold">
                                    Contribution ledger
                                </div>
                                <span class="badge bg-dark text-white">02</span>
                            </div>

                            <div class="col-lg-12 mb-4">
                                <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1">
                                    <thead>
                                        <tr class="text-start align-top  fw-bold fs-7 gs-0 bg-label-dark">
                                            <th class="min-w-100px text-black">Month</th>
                                            <th class="min-w-100px text-black">Due</th>
                                            <th class="min-w-100px text-black">Required</th>
                                            <th class="min-w-100px text-black">Paid</th>
                                            <th class="min-w-100px text-black">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-black fw-medium fs-7">
                                        <tr>
                                            <td>
                                                <label class="text-nowrap">09-May-2025</label>
                                            </td>
                                            <td>
                                                <label class="text-nowrap">12-May-2025</label>
                                            </td>
                                            <td>
                                                <label class="">₹ 15,533	</label>
                                            </td>
                                            <td>
                                                <label > &#8377; 15,533</label>
                                            </td>
                                            <td>
                                                <span class="badge bg-label-success px-3 fw-semibold fs-7">Paid</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">09-May-2025</label></td>
                                            <td><label class="text-nowrap">12-May-2025</label></td>
                                            <td><label>&#8377; 15,533</label></td>
                                            <td><label>&#8377; 15,533</label></td>
                                            <td><span class="badge bg-label-success px-3 fw-semibold fs-7">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">14-May-2025</label></td>
                                            <td><label class="text-nowrap">17-May-2025</label></td>
                                            <td><label>&#8377; 22,100</label></td>
                                            <td><label>&#8377; 11,050</label></td>
                                            <td><span class="badge bg-label-warning px-3 fw-semibold fs-6">Partial</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">18-May-2025</label></td>
                                            <td><label class="text-nowrap">21-May-2025</label></td>
                                            <td><label>&#8377; 8,750</label></td>
                                            <td><label>&#8377; 0</label></td>
                                            <td><span class="badge bg-label-danger px-3 fw-semibold fs-6">Pending</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">22-May-2025</label></td>
                                            <td><label class="text-nowrap">25-May-2025</label></td>
                                            <td><label>&#8377; 31,200</label></td>
                                            <td><label>&#8377; 31,200</label></td>
                                            <td><span class="badge bg-label-success px-3 fw-semibold fs-7">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">26-May-2025</label></td>
                                            <td><label class="text-nowrap">29-May-2025</label></td>
                                            <td><label>&#8377; 18,450</label></td>
                                            <td><label>&#8377; 9,225</label></td>
                                            <td><span class="badge bg-label-warning px-3 fw-semibold fs-6">Partial</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">01-Jun-2025</label></td>
                                            <td><label class="text-nowrap">04-Jun-2025</label></td>
                                            <td><label>&#8377; 12,800</label></td>
                                            <td><label>&#8377; 0</label></td>
                                            <td><span class="badge bg-label-danger px-3 fw-semibold fs-6">Pending</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">05-Jun-2025</label></td>
                                            <td><label class="text-nowrap">08-Jun-2025</label></td>
                                            <td><label>&#8377; 27,650</label></td>
                                            <td><label>&#8377; 27,650</label></td>
                                            <td><span class="badge bg-label-success px-3 fw-semibold fs-7">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">09-Jun-2025</label></td>
                                            <td><label class="text-nowrap">12-Jun-2025</label></td>
                                            <td><label>&#8377; 9,300</label></td>
                                            <td><label>&#8377; 0</label></td>
                                            <td><span class="badge bg-label-danger px-3 fw-semibold fs-6">Pending</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">13-Jun-2025</label></td>
                                            <td><label class="text-nowrap">16-Jun-2025</label></td>
                                            <td><label>&#8377; 44,000</label></td>
                                            <td><label>&#8377; 44,000</label></td>
                                            <td><span class="badge bg-label-success px-3 fw-semibold fs-7">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">17-Jun-2025</label></td>
                                            <td><label class="text-nowrap">20-Jun-2025</label></td>
                                            <td><label>&#8377; 16,900</label></td>
                                            <td><label>&#8377; 8,450</label></td>
                                            <td><span class="badge bg-label-warning px-3 fw-semibold fs-6">Partial</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">21-Jun-2025</label></td>
                                            <td><label class="text-nowrap">24-Jun-2025</label></td>
                                            <td><label>&#8377; 33,750</label></td>
                                            <td><label>&#8377; 33,750</label></td>
                                            <td><span class="badge bg-label-success px-3 fw-semibold fs-7">Paid</span></td>
                                        </tr>
                                        <tr>
                                            <td><label class="text-nowrap">25-Jun-2025</label></td>
                                            <td><label class="text-nowrap">28-Jun-2025</label></td>
                                            <td><label>&#8377; 5,600</label></td>
                                            <td><label>&#8377; 0</label></td>
                                            <td><span class="badge bg-label-danger px-3 fw-semibold fs-6">Pending</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
  </div>
    <div class="offcanvas-footer border-top p-3 pt-4 d-flex justify-content-end gap-2">
        <i class="mdi mdi-square-edit-outline fs-3 text-black me-1 cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_yerd"></i>
        <button type="button" class="btn btn-sm btn-light" data-bs-dismiss="offcanvas">
            Export
        </button>
        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_rd_closing">
            Mark Contribution Paid
        </button>
    </div>
</div>


<!--begin::Modal -  Add YERD -->
<div class="modal fade" id="kt_modal_add_yerd" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">New RD plan</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">

                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Plan name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Plan name ">
                    </div>

                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Category</option>
                            <option value="1">Insurance</option>
                            <option value="2">AMC</option>
                            <option value="3">Advance Tax</option>
                            <option value="4">Auditor Fees</option>
                            <option value="5">Membership</option>
                            <option value="6">Other</option>
                        </select>
                    </div>


                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Linked account<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Linked account</option>
                            <option value="1">HDFC RD · Ops</option>
                            <option value="2">ICICI RD · Admin</option>
                            <option value="3">Axis RD · Treasury</option>
                        </select>
                    </div>

                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Annual target (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Annual target (₹)">
                    </div>


                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Visit date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                           <input type="text" name="month" placeholder="Select Month" class="form-control month_picker" readonly />
                        </div>
                    </div>

                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Duration (months)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Duration (months)">
                    </div>
                    
                    
                    <div class="col-lg-12 mb-3">
                        <div class="bg-label-primary p-3 d-flex align-items-center justify-content-between rounded">
                            <label class="">Monthly contribution</label>
                            <label class="fw-semibold">₹ 0</label>
                        </div>
                    </div>
                    
                   
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1"  placeholder="Enter Description"></textarea>
                    </div>

                    
                    
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Create Plan</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add YERD-->


<!--begin::Modal -  Renewal Closing -->
<div class="modal fade" id="kt_modal_rd_closing" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">RD Closing</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <div class="bg-label-secondary border border-secondary rounded-3 p-2">
                            <div class="d-flex align-items-center justify-content-between mb-2 gap-2">
                                <div class="d-flex flex-column">
                                    <label class="fs-6 text-black fw-semibold">Group Medical Premium Renewal</label>
                                    <label class="fs-7 text-dark">RD-F26-01</label>
                                </div>
                                <label>
                                    <span class="badge bg-label-dark rounded-3 fw-semibold text-black">
                                        Insurance
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Closing date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                           <input type="text" name="month" placeholder="Select Date" class="form-control common_datepicker" readonly />
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Closing Amount (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Closing Amount (₹)">
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Company<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Company</option>
                            <option value="1">Elysium Groups</option>
                            <option value="2">Elysian Intelligence Business Solution</option>
                            <option value="3">Elysium Technologies Private Limited</option>
                            <option value="3">Elysian Skill Training Private Limited</option>
                        </select>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Bank<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Bank</option>
                            <option value="1">HDFC Bank</option>
                            <option value="2">SBI Bank</option>
                            <option value="3">ICICI Bank</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Close RD Account</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Renewal Closing-->


<!--begin::Modal -  Edit YERD -->
<div class="modal fade" id="kt_modal_edit_yerd" tabindex="-1" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div
                class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                <div class="text-center mt-4">
                    <h3 class="text-center text-black">Update RD plan</h3>
                </div>
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->

                <div class="row">

                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Plan name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Plan name " value="Growth Savings Plan">
                    </div>

                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Category</option>
                            <option value="1" selected>Insurance</option>
                            <option value="2">AMC</option>
                            <option value="3">Advance Tax</option>
                            <option value="4">Auditor Fees</option>
                            <option value="5">Membership</option>
                            <option value="6">Other</option>
                        </select>
                    </div>


                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Linked account<span class="text-danger">*</span></label>
                        <select class="select3 form-select" >
                            <option value="">Select Linked account</option>
                            <option value="1" selected>HDFC RD · Ops</option>
                            <option value="2">ICICI RD · Admin</option>
                            <option value="3">Axis RD · Treasury</option>
                        </select>
                    </div>

                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Annual target (₹)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Annual target (₹)" value="120000">
                    </div>


                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Visit date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                           <input type="text" name="month" placeholder="Select Month" class="form-control month_picker" readonly value="Apr-2026" />
                        </div>
                    </div>

                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Duration (months)<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Duration (months)" value="12">
                    </div>
                    
                    
                    <div class="col-lg-12 mb-3">
                        <div class="bg-label-primary p-3 d-flex align-items-center justify-content-between rounded">
                            <label class="">Monthly contribution</label>
                            <label class="fw-semibold">₹ 10,000</label>
                        </div>
                    </div>
                    
                   
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1"  placeholder="Enter Description">Monthly investment plan for long-term wealth growth</textarea>
                    </div>

                    
                    
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4">
                    <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="create_sms_btn" class="btn btn-primary"
                        data-bs-dismiss="modal">Update Plan</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit YERD-->



<script>
    const OffcanvasModalManager = (() => {

    function openModal(targetSelector) {
        const modalEl = document.querySelector(targetSelector.trim());
        if (!modalEl) return;
        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();
    }

    function init() {
        document.addEventListener('click', function (e) {
            const trigger = e.target.closest('[data-bs-toggle="modal"]');
            if (!trigger) return;

            const modalTarget = trigger.getAttribute('data-bs-target');
            if (!modalTarget) return;

            const parentOffcanvas = trigger.closest('.offcanvas');
            if (!parentOffcanvas) return;

            e.preventDefault();
            e.stopPropagation();

            const offcanvasInstance = bootstrap.Offcanvas.getInstance(parentOffcanvas);

            if (offcanvasInstance) {
                parentOffcanvas.addEventListener('hidden.bs.offcanvas', function handler() {
                    parentOffcanvas.removeEventListener('hidden.bs.offcanvas', handler);

                    // ✅ Only remove backdrop, let Bootstrap handle body scroll itself
                    document.querySelectorAll('.offcanvas-backdrop').forEach(el => el.remove());
                    document.body.classList.remove('offcanvas-open');

                    openModal(modalTarget);
                });

                offcanvasInstance.hide();
            } else {
                openModal(modalTarget);
            }
        });
    }

    return { init };
})();

document.addEventListener('DOMContentLoaded', () => {
    OffcanvasModalManager.init();
});
</script>




<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>
<script>
new Chart(document.getElementById('inflowChart'), {
    type: 'bar',
    data: {
        labels: ['May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
        datasets: [
        {
            label: 'Inflow (RD)',
            data: [60, 70, 55, 60, 55, 50, 60, 55],
            backgroundColor: '#3a7d44',
            barPercentage: 0.5,
            categoryPercentage: 0.6
        },
        {
            label: 'Outflow (disbursals)',
            data: [0, 30, 0, 0, 40, 0, 90, 0],
            backgroundColor: '#b07d1a',
            barPercentage: 0.5,
            categoryPercentage: 0.6
        }
        ]
    },
    options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
            x: { grid: { display: false }, ticks: { color: '#888', font: { size: 12 } } },
            y: { display: false, grid: { display: false } }
        }
    }
    });
</script>

<script>
    $(document).ready(function () {
        $('.month_picker').datepicker({
            format: "M-yyyy",
            startView: "months",
            minViewMode: "months",
            autoclose: true
        });
    });
</script>
@endsection
