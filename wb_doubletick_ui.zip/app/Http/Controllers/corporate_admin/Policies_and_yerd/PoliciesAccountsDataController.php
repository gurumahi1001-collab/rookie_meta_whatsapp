<?php
namespace App\Http\Controllers\corporate_admin\Policies_and_yerd;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

class PoliciesAccountsDataController extends Controller
{
    private function entity(): int {
        $id=(int)(session('selected_entity_id') ?: session('entity_id') ?: (auth()->user()->entity_id ?? 0));
        abort_if($id<1,403,'Select an active entity first.'); return $id;
    }
    private function table(string $type): string {
        $map=['insurance'=>'egc_policy_insurance_amc','amc'=>'egc_policy_insurance_amc','subscription'=>'egc_policy_subscriptions','rd'=>'egc_policy_rd_accounts'];
        abort_unless(isset($map[$type]),404); return $map[$type];
    }
    private function scope(string $type) {
        $q=DB::table($this->table($type))->where('entity_id',$this->entity())->where('status',1);
        if(in_array($type,['insurance','amc'])) $q->where('record_type',$type);
        return $q;
    }
    public function listing(Request $r,string $type) {
        $page=max(1,(int)$r->input('page',1)); $per=min(100,max(5,(int)$r->input('per_page',10)));
        $q=$this->scope($type); $search=trim((string)$r->input('search',''));
        if($search!=='') $q->where(function($w)use($search){foreach(['title','provider_name','policy_number','reference_no','description'] as $f)$w->orWhere($f,'like',"%{$search}%");});
        if($r->filled('record_status'))$q->where('record_status',$r->record_status);
        if($r->filled('category_id'))$q->where('category_id',$r->category_id);
        $total=(clone $q)->count(); $rows=$q->orderByDesc('id')->offset(($page-1)*$per)->limit($per)->get();
        $rows=$rows->map(function($x)use($type){$a=(array)$x;if($type==='rd'&&!empty($a['account_number'])){try{$v=Crypt::decryptString($a['account_number']);$a['account_number']='••••'.substr($v,-4);}catch(\Throwable $e){$a['account_number']='••••';}}unset($a['login_password']);return $a;});
        return response()->json(['status'=>true,'data'=>$rows,'pagination'=>['current_page'=>$page,'per_page'=>$per,'total'=>$total,'last_page'=>max(1,(int)ceil($total/$per)),'from'=>$total?($page-1)*$per+1:null,'to'=>min($page*$per,$total)]]);
    }
    public function store(Request $r,string $type) {
        $table=$this->table($type);
        $rules=['title'=>'required|string|max:190','provider_name'=>'nullable|string|max:190','policy_number'=>'nullable|string|max:120','reference_no'=>'nullable|string|max:120','category_id'=>'nullable|integer','start_date'=>'nullable|date','end_date'=>'nullable|date|after_or_equal:start_date','renewal_date'=>'nullable|date','amount'=>'nullable|numeric|min:0','frequency'=>'nullable|string|max:40','record_status'=>'nullable|in:active,expired,cancelled,pending,matured','description'=>'nullable|string|max:5000','contact_person'=>'nullable|string|max:190','contact_email'=>'nullable|email|max:190','contact_phone'=>'nullable|string|max:40'];
        if($type==='rd'){$rules['account_number']='required|string|max:120';$rules['monthly_installment']='required|numeric|min:0.01';$rules['tenure_months']='nullable|integer|min:1|max:600';}
        if($type==='subscription'){$rules['login_url']='nullable|url|max:500';$rules['login_username']='nullable|string|max:190';$rules['login_password']='nullable|string|max:500';}
        $v=Validator::make($r->all(),$rules);if($v->fails())return response()->json(['status'=>false,'errors'=>$v->errors()],422);
        $data=$r->only(['title','provider_name','policy_number','reference_no','category_id','start_date','end_date','renewal_date','amount','frequency','record_status','description','contact_person','contact_email','contact_phone','monthly_installment','maturity_date','login_url','login_username']);
        $data+=['entity_id'=>$this->entity(),'record_type'=>$type,'status'=>1,'created_by'=>auth()->id(),'created_at'=>now(),'updated_at'=>now()];
        if($type==='rd')$data['account_number']=Crypt::encryptString($r->account_number);
        if($type==='subscription'&&$r->filled('login_password'))$data['login_password']=Crypt::encryptString($r->login_password);
        $id=DB::table($table)->insertGetId($data);
        if($type==='rd'){$months=(int)$r->input('tenure_months',12);$start=Carbon::parse($r->input('start_date',now()))->startOfMonth();$rows=[];for($i=0;$i<$months;$i++)$rows[]=['entity_id'=>$this->entity(),'rd_account_id'=>$id,'installment_no'=>$i+1,'due_date'=>$start->copy()->addMonths($i)->toDateString(),'due_amount'=>$r->monthly_installment,'paid_amount'=>0,'payment_status'=>'due','created_at'=>now(),'updated_at'=>now()];foreach(array_chunk($rows,100) as $c)DB::table('egc_policy_rd_installments')->insert($c);}
        $this->syncRenewal($type,$id);return response()->json(['status'=>true,'message'=>'Saved successfully.','id'=>$id],201);
    }
    public function detail(string $type,int $id) {
        $row=$this->scope($type)->where('id',$id)->first();abort_unless($row,404);
        $a=(array)$row;if($type==='rd'&&!empty($a['account_number']))$a['account_number']=Crypt::decryptString($a['account_number']);unset($a['login_password']);
        return response()->json(['status'=>true,'data'=>$a]);
    }
    public function update(Request $r,string $type,int $id) {
        $row=$this->scope($type)->where('id',$id)->first();abort_unless($row,404);
        $v=Validator::make($r->all(),['title'=>'sometimes|required|string|max:190','provider_name'=>'nullable|string|max:190','policy_number'=>'nullable|string|max:120','reference_no'=>'nullable|string|max:120','category_id'=>'nullable|integer','start_date'=>'nullable|date','end_date'=>'nullable|date|after_or_equal:start_date','renewal_date'=>'nullable|date','amount'=>'nullable|numeric|min:0','frequency'=>'nullable|string|max:40','record_status'=>'nullable|in:active,expired,cancelled,pending,matured','description'=>'nullable|string|max:5000','account_number'=>'nullable|string|max:120','monthly_installment'=>'nullable|numeric|min:0.01','login_password'=>'nullable|string|max:500','login_url'=>'nullable|url|max:500']);
        if($v->fails())return response()->json(['status'=>false,'errors'=>$v->errors()],422);
        $data=$r->only(['title','provider_name','policy_number','reference_no','category_id','start_date','end_date','renewal_date','amount','frequency','record_status','description','monthly_installment','maturity_date','login_url','login_username','contact_person','contact_email','contact_phone']);
        if($type==='rd'&&$r->filled('account_number'))$data['account_number']=Crypt::encryptString($r->account_number);
        if($type==='subscription'&&$r->filled('login_password'))$data['login_password']=Crypt::encryptString($r->login_password);
        $data['updated_at']=now();$this->scope($type)->where('id',$id)->update($data);$this->syncRenewal($type,$id);
        return response()->json(['status'=>true,'message'=>'Updated successfully.']);
    }
    public function archive(string $type,int $id) {
        $n=$this->scope($type)->where('id',$id)->update(['status'=>0,'updated_at'=>now()]);abort_unless($n,404);
        DB::table('egc_policy_renewals')->where('entity_id',$this->entity())->where('source_type',$type)->where('source_id',$id)->update(['status'=>0,'updated_at'=>now()]);
        return response()->json(['status'=>true,'message'=>'Archived successfully.']);
    }
    private function syncRenewal(string $type,int $id):void {
        $row=$this->scope($type)->where('id',$id)->first();if(!$row)return;$date=$row->renewal_date??$row->end_date??null;if(!$date)return;
        DB::table('egc_policy_renewals')->updateOrInsert(['entity_id'=>$this->entity(),'source_type'=>$type,'source_id'=>$id],['title'=>$row->title,'provider_name'=>$row->provider_name??null,'renewal_date'=>$date,'amount'=>$row->amount??0,'record_status'=>$row->record_status??'active','status'=>1,'created_at'=>now(),'updated_at'=>now()]);
    }
    public function dashboard() {
        $e=$this->entity();$count=function($t,$kind=null)use($e){$q=DB::table($t)->where('entity_id',$e)->where('status',1);if($kind)$q->where('record_type',$kind);return $q->count();};
        $today=now()->toDateString();$end=now()->addDays(30)->toDateString();
        $due=DB::table('egc_policy_renewals')->where('entity_id',$e)->where('status',1)->whereBetween('renewal_date',[$today,$end])->count();
        $expired=DB::table('egc_policy_renewals')->where('entity_id',$e)->where('status',1)->whereDate('renewal_date','<',$today)->count();
        $upcoming=DB::table('egc_policy_renewals')->where('entity_id',$e)->where('status',1)->whereDate('renewal_date','>=',$today)->orderBy('renewal_date')->limit(10)->get();
        return response()->json(['status'=>true,'data'=>['insurance'=>$count('egc_policy_insurance_amc','insurance'),'amc'=>$count('egc_policy_insurance_amc','amc'),'subscriptions'=>$count('egc_policy_subscriptions'),'rd'=>$count('egc_policy_rd_accounts'),'renewals_due'=>$due,'expired'=>$expired,'upcoming'=>$upcoming]]);
    }
    public function renewals(Request $r) {
        $e=$this->entity();$p=max(1,(int)$r->input('page',1));$n=min(100,max(5,(int)$r->input('per_page',10)));
        $q=DB::table('egc_policy_renewals')->where('entity_id',$e)->where('status',1);
        if($r->filled('from_date'))$q->whereDate('renewal_date','>=',$r->from_date);if($r->filled('to_date'))$q->whereDate('renewal_date','<=',$r->to_date);
        if($r->filled('source_type'))$q->where('source_type',$r->source_type);if($r->filled('search'))$q->where('title','like','%'.$r->search.'%');
        $total=(clone $q)->count();$data=$q->orderBy('renewal_date')->offset(($p-1)*$n)->limit($n)->get();
        return response()->json(['status'=>true,'data'=>$data,'pagination'=>['current_page'=>$p,'per_page'=>$n,'total'=>$total,'last_page'=>max(1,(int)ceil($total/$n))]]);
    }
    public function masters(Request $r) {
        $q=DB::table('egc_policy_masters')->where('entity_id',$this->entity())->where('status',1);if($r->filled('type'))$q->where('master_type',$r->type);
        return response()->json(['status'=>true,'data'=>$q->orderBy('name')->get()]);
    }
    public function saveMaster(Request $r) {
        $v=Validator::make($r->all(),['id'=>'nullable|integer','master_type'=>'required|in:provider,category,frequency,subscription_type,rd_bank','name'=>'required|string|max:120','description'=>'nullable|string|max:500']);
        if($v->fails())return response()->json(['status'=>false,'errors'=>$v->errors()],422);$e=$this->entity();
        $d=['name'=>trim($r->name),'description'=>$r->description,'updated_at'=>now()];$id=(int)$r->input('id');
        if($id){$n=DB::table('egc_policy_masters')->where('entity_id',$e)->where('id',$id)->where('status',1)->update($d);abort_unless($n,404);}
        else{$exists=DB::table('egc_policy_masters')->where('entity_id',$e)->where('master_type',$r->master_type)->whereRaw('LOWER(name)=?', [mb_strtolower(trim($r->name))])->where('status',1)->exists();abort_if($exists,422,'Option already exists.');$d+=['entity_id'=>$e,'master_type'=>$r->master_type,'status'=>1,'created_at'=>now()];$id=DB::table('egc_policy_masters')->insertGetId($d);}
        return response()->json(['status'=>true,'message'=>'Setting saved.','id'=>$id]);
    }
    public function deleteMaster(int $id) {$n=DB::table('egc_policy_masters')->where('entity_id',$this->entity())->where('id',$id)->where('status',1)->update(['status'=>0,'updated_at'=>now()]);abort_unless($n,404);return response()->json(['status'=>true,'message'=>'Deactivated.']);}
    public function installments(Request $r,int $id) {
        $e=$this->entity();abort_unless(DB::table('egc_policy_rd_accounts')->where('entity_id',$e)->where('id',$id)->where('status',1)->exists(),404);
        $p=DB::table('egc_policy_rd_installments')->where('entity_id',$e)->where('rd_account_id',$id)->orderBy('installment_no')->paginate(min(100,max(5,(int)$r->input('per_page',10))));
        return response()->json(['status'=>true,'data'=>$p->items(),'pagination'=>['current_page'=>$p->currentPage(),'last_page'=>$p->lastPage(),'total'=>$p->total()]]);
    }
    public function payInstallment(Request $r,int $id,int $installment) {
        $v=Validator::make($r->all(),['paid_amount'=>'required|numeric|min:0.01','paid_on'=>'required|date','payment_reference'=>'nullable|string|max:120','remarks'=>'nullable|string|max:1000']);if($v->fails())return response()->json(['status'=>false,'errors'=>$v->errors()],422);
        return DB::transaction(function()use($r,$id,$installment){$e=$this->entity();$x=DB::table('egc_policy_rd_installments')->where('entity_id',$e)->where('rd_account_id',$id)->where('id',$installment)->lockForUpdate()->first();abort_unless($x,404);
            $paid=(float)$x->paid_amount+(float)$r->paid_amount;abort_if($paid>(float)$x->due_amount,422,'Payment exceeds outstanding amount.');
            DB::table('egc_policy_rd_installments')->where('id',$installment)->update(['paid_amount'=>$paid,'payment_status'=>$paid >= (float)$x->due_amount?'paid':'partial','paid_on'=>$r->paid_on,'payment_reference'=>$r->payment_reference,'remarks'=>$r->remarks,'updated_at'=>now()]);
            return response()->json(['status'=>true,'message'=>'Payment recorded.']);});
    }
}
