/**
 * Policies & RD Accounts AJAX helpers.
 * Keep the existing Blade markup intact; bind the page's existing tbody/forms to
 * these helpers from the page-specific script. All requests use Laravel CSRF.
 */
(function (window, $) {
    'use strict';
    const base = `${window.location.origin}/policies-data`;
    const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

    function request(url, method = 'GET', data = null) {
        return $.ajax({
            url, method, data: data || {}, dataType: 'json',
            headers: { 'X-CSRF-TOKEN': token, 'X-Requested-With': 'XMLHttpRequest' }
        });
    }

    function skeleton(columns, rows = 5) {
        return Array.from({ length: rows }, () =>
            `<tr class="policy-skeleton-row">${Array.from({ length: columns }, () =>
                '<td><span class="placeholder-glow d-block"><span class="placeholder col-8"></span></span></td>'
            ).join('')}</tr>`
        ).join('');
    }

    function renderPagination(target, pagination, onPage) {
        const $target = $(target);
        if (!$target.length) return;
        const page = Number(pagination.current_page || 1);
        const last = Number(pagination.last_page || 1);
        const total = Number(pagination.total || 0);
        $target.html(`
          <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mt-3">
            <small class="text-muted">Showing ${total ? ((page - 1) * pagination.per_page + 1) : 0}
              to ${Math.min(page * (pagination.per_page || 10), total)} of ${total} entries</small>
            <div class="d-flex align-items-center gap-1">
              <button type="button" class="btn btn-sm btn-outline-secondary" data-policy-page="${Math.max(1, page - 1)}" ${page <= 1 ? 'disabled' : ''}>Previous</button>
              <span class="small px-2">Page ${page} of ${last}</span>
              <button type="button" class="btn btn-sm btn-outline-secondary" data-policy-page="${Math.min(last, page + 1)}" ${page >= last ? 'disabled' : ''}>Next</button>
            </div>
          </div>`);
        $target.off('click.policyPage').on('click.policyPage', '[data-policy-page]', function () {
            onPage(Number($(this).data('policy-page')));
        });
    }

    function loadList(options) {
        const cfg = Object.assign({ type: 'insurance', page: 1, per_page: 10, tbody: null, columns: 8, render: null, pagination: null }, options || {});
        const $body = $(cfg.tbody);
        if (!$body.length) return $.Deferred().reject('Missing tbody target').promise();
        $body.html(skeleton(cfg.columns));
        return request(`${base}/${encodeURIComponent(cfg.type)}`, 'GET', {
            page: cfg.page, per_page: cfg.per_page, search: cfg.search || '',
            record_status: cfg.record_status || '', category_id: cfg.category_id || ''
        }).done(function (response) {
            if (!response.status) throw new Error(response.message || 'Unable to load records.');
            $body.html(response.data.length
                ? response.data.map(cfg.render).join('')
                : `<tr><td colspan="${cfg.columns}" class="text-center py-4 text-muted">No records found</td></tr>`);
            if (cfg.pagination) renderPagination(cfg.pagination, response.pagination, function (page) {
                loadList(Object.assign({}, cfg, { page }));
            });
        }).fail(function (xhr) {
            const message = xhr.responseJSON?.message || 'Unable to load records. Please retry.';
            $body.html(`<tr><td colspan="${cfg.columns}" class="text-center text-danger py-4">${$('<div>').text(message).html()}</td></tr>`);
        });
    }

    function save(type, id, payload) {
        return request(`${base}/${type}${id ? `/${id}` : ''}`, id ? 'PUT' : 'POST', payload);
    }
    function detail(type, id) { return request(`${base}/${type}/${id}`); }
    function archive(type, id) { return request(`${base}/${type}/${id}`, 'DELETE'); }
    function dashboard() { return request(`${base}/dashboard`); }
    function renewals(filters) { return request(`${base}/renewals`, 'GET', filters || {}); }
    function masters(type) { return request(`${base}/masters`, 'GET', { type: type || '' }); }
    function saveMaster(payload) { return request(`${base}/masters`, 'POST', payload); }
    function deleteMaster(id) { return request(`${base}/masters/${id}`, 'DELETE'); }
    function rdInstallments(id, page = 1) { return request(`${base}/rd/${id}/installments`, 'GET', { page }); }
    function payRdInstallment(id, installmentId, payload) {
        return request(`${base}/rd/${id}/installments/${installmentId}/payment`, 'POST', payload);
    }

    window.PoliciesRD = {
        request, skeleton, renderPagination, loadList, save, detail, archive,
        dashboard, renewals, masters, saveMaster, deleteMaster, rdInstallments, payRdInstallment
    };
})(window, window.jQuery);
