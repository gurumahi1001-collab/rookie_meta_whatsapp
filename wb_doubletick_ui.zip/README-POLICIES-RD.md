# Policies & RD Accounts — deployment package

## What this package contains
- `app/Http/Controllers/corporate_admin/Policies_and_yerd/PoliciesAccountsDataController.php`: isolated JSON API for insurance, AMC, subscriptions, RD accounts, renewal calendar, dashboard aggregates, dropdown masters and RD installment payments.
- `routes/web.php`: the existing five page routes are retained; new `policies-data/*` endpoints are added.
- `database/policies_rd_accounts.sql`: six new `egc_policy_*` tables only. No existing ERP table is altered.
- `public/js/policies-rd-accounts.js`: reusable AJAX functions with staff-style skeleton rows and pagination.
- Existing five Blade pages and their original controllers are included unchanged to preserve the uploaded UI.

## Important production integration notes
1. Back up the production database and deploy code to staging first.
2. Run `database/policies_rd_accounts.sql` once.
3. Ensure the authenticated user has an active entity. The API tenant resolver currently checks `session('selected_entity_id')`, then `session('entity_id')`, then `auth()->user()->entity_id`. Confirm which of these is the actual active-entity source in your deployment before release; do not remove entity scoping.
4. Include `public/js/policies-rd-accounts.js` in the five existing Blade pages after jQuery and the CSRF meta tag are loaded. It exposes `window.PoliciesRD`.
5. Bind each page's existing form fields and current table/card containers to `PoliciesRD` methods. The uploaded Blade screens contain hard-coded demo rows and page-specific operational modals (claims, service reports, surrender/closing, etc.). Those workflows are not silently replaced by generic CRUD because their existing markup does not expose a consistent field/row contract. Their full persistence needs explicit mapping to the original modal fields and supporting tables.
6. Confirm your production authorization middleware/permission slugs cover all five existing page routes and the new data endpoints. The API endpoints inherit the route group's middleware.
7. Set a valid Laravel `APP_KEY`; RD account numbers and subscription passwords are encrypted with Laravel `Crypt`. Do not rotate `APP_KEY` without a planned re-encryption/migration.
8. Run `php artisan route:clear && php artisan config:clear && php artisan cache:clear`; then verify `php artisan route:list --path=policies-data`.

## API endpoints
- `GET /policies-data/dashboard`
- `GET /policies-data/{insurance|amc|subscription|rd}?page=1&per_page=10&search=`
- `POST /policies-data/{type}` and `GET|PUT|DELETE /policies-data/{type}/{id}`
- `GET /policies-data/renewals`
- `GET|POST /policies-data/masters`, `DELETE /policies-data/masters/{id}`
- `GET /policies-data/rd/{id}/installments`
- `POST /policies-data/rd/{id}/installments/{installment}/payment`

All list endpoints are entity-scoped and paginated. Delete means archive (`status=0`), not physical deletion. Password values are never returned by list/detail APIs; an update only changes a password when a new value is supplied.

## Scope limitation — please verify before production
This archive provides the API/data foundation and leaves all original UI source intact. It does **not** claim the five existing prototype screens are fully wired: their current demo rows, multiple operational modals, and non-uniform forms require page-specific field mapping. The helper JS is deliberately reusable, but is not auto-bound to arbitrary forms. Also verify the entity-session source and permission middleware in your deployment before exposing the new endpoints.
